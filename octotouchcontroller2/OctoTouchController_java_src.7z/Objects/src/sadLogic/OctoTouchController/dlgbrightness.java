package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgbrightness extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgbrightness");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgbrightness.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public Object _mcallback = null;
public String _meventname = "";
public sadLogic.OctoTouchController.sadroundslider _sadroundslider1 = null;
public sadLogic.OctoTouchController.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgBrightness\"";
_mmodule = "dlgBrightness";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 12;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 13;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 15;BA.debugLine="Private sadRoundSlider1 As sadRoundSlider";
_sadroundslider1 = new sadLogic.OctoTouchController.sadroundslider();
 //BA.debugLineNum = 16;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 17;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 22;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,String _title,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize( title As String, Callback A";
 //BA.debugLineNum = 27;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 28;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 29;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 30;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 31;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public void  _show(int _defaultvalue) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_defaultvalue);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgbrightness parent,int _defaultvalue) {
this.parent = parent;
this._defaultvalue = _defaultvalue;
}
sadLogic.OctoTouchController.dlgbrightness parent;
int _defaultvalue;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _h = 0f;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 40;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 41;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 42;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 44;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 45;BA.debugLine="Dim h As Float = 280dip";
_h = (float) (parent.__c.DipToCurrent((int) (280)));
 //BA.debugLineNum = 46;BA.debugLine="If guiHelpers.gIsLandScape And guiHelpers.gScreen";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gislandscape /*boolean*/  && parent._guihelpers._gscreensizeaprox /*double*/ <5.1) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
_h = parent._guihelpers._maxverticalheight_landscape /*float*/ (ba);
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 47;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 280dip,h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (280)),(int) (_h));
 //BA.debugLineNum = 48;BA.debugLine="p.LoadLayout(\"viewRoundSlider\")";
_p.LoadLayout("viewRoundSlider",ba);
 //BA.debugLineNum = 50;BA.debugLine="pnlMain.Color = clrTheme.Background";
parent._pnlmain.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 51;BA.debugLine="sadRoundSlider1.Value = defaultValue";
parent._sadroundslider1._setvalue /*int*/ (_defaultvalue);
 //BA.debugLineNum = 52;BA.debugLine="sadRoundSlider1.xlbl.TextColor = clrTheme.Backgro";
parent._sadroundslider1._xlbl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(parent._clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 53;BA.debugLine="sadRoundSlider1.xlbl.Font = xui.CreateDefaultFont";
parent._sadroundslider1._xlbl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setFont(parent._xui.CreateDefaultFont((float) (52)));
 //BA.debugLineNum = 54;BA.debugLine="sadRoundSlider1.ValueColor = clrTheme.Background2";
parent._sadroundslider1._valuecolor /*int*/  = parent._clrtheme._background2 /*int*/ ;
 //BA.debugLineNum = 55;BA.debugLine="sadRoundSlider1.SetCircleColor(clrTheme.Backgroun";
parent._sadroundslider1._setcirclecolor /*String*/ (parent._clrtheme._backgroundheader /*int*/ ,parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 56;BA.debugLine="sadRoundSlider1.SetThumbColor(clrTheme.Background";
parent._sadroundslider1._setthumbcolor /*String*/ (parent._clrtheme._backgroundheader /*int*/ ,parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 57;BA.debugLine="sadRoundSlider1.Draw";
parent._sadroundslider1._draw /*String*/ ();
 //BA.debugLineNum = 59;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 60;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"O";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("OK"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 61;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 63;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 11;
return;
case 11:
//C
this.state = 7;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 64;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 7:
//if
this.state = 10;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 65;BA.debugLine="CallSub2(mCallback,mEventName,sadRoundSlider1.Va";
parent.__c.CallSubNew2(ba,parent._mcallback,parent._meventname,(Object)(((float) (parent._sadroundslider1._getvalue /*int*/ ()))));
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 67;BA.debugLine="mMainObj.pObjCurrentDlg1 = Null";
parent._mmainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
