package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_dlgvolumesettings{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)(0d));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnltimervol").vw.setLeft((int)((10d * scale)));
views.get("pnltimervol").vw.setWidth((int)((100d / 100 * width)-(10d * scale) - ((10d * scale))));
views.get("lbltmrvol").vw.setLeft((int)((views.get("pnltimervol").vw.getWidth())-(4d * scale) - (views.get("lbltmrvol").vw.getWidth())));
//BA.debugLineNum = 10;BA.debugLine="sbTimerVol.SetLeftAndRight(6dip,lblTmrVol.Left-6dip)"[dlgVolumeSettings/General script]
views.get("sbtimervol").vw.setLeft((int)((6d * scale)));
views.get("sbtimervol").vw.setWidth((int)((views.get("lbltmrvol").vw.getLeft())-(6d * scale) - ((6d * scale))));
//BA.debugLineNum = 15;BA.debugLine="cboSounds.SetLeftAndRight(10dip,100%x-btnTest.Width-16dip)"[dlgVolumeSettings/General script]
views.get("cbosounds").vw.setLeft((int)((10d * scale)));
views.get("cbosounds").vw.setWidth((int)((100d / 100 * width)-(views.get("btntest").vw.getWidth())-(16d * scale) - ((10d * scale))));
//BA.debugLineNum = 16;BA.debugLine="btnTest.Left = cboSounds.Width + 16dip"[dlgVolumeSettings/General script]
views.get("btntest").vw.setLeft((int)((views.get("cbosounds").vw.getWidth())+(16d * scale)));

}
}