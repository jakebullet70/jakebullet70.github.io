package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgthemeselect extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgthemeselect");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgthemeselect.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbg = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.b4xmainpage _mmain = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltext2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltext1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltext = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltextacc = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcustom = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbldisabled = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlthememenu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlthemeheader = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlthemebg = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spinner1 = null;
public sadLogic.OctoTouchController.sadb4xcolortemplate _colortemplate = null;
public sadLogic.OctoTouchController.b4xdialog _dgclr = null;
public String _custom_selection = "";
public anywheresoftware.b4a.objects.SpinnerWrapper _spnpicker = null;
public anywheresoftware.b4a.objects.PanelWrapper _parent = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnclose = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsave = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblthemebg = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _btnclose_click() throws Exception{
 //BA.debugLineNum = 230;BA.debugLine="Private Sub btnClose_Click '--- class method";
 //BA.debugLineNum = 231;BA.debugLine="Close_Me";
_close_me();
 //BA.debugLineNum = 232;BA.debugLine="End Sub";
return "";
}
public String  _btnsave_click() throws Exception{
 //BA.debugLineNum = 240;BA.debugLine="Private Sub btnSave_Click";
 //BA.debugLineNum = 241;BA.debugLine="Main.kvs.Put(gblConst.SELECTED_CLR_THEME,Spinner1";
_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (_gblconst._selected_clr_theme /*String*/ ,(Object)(_spinner1.getSelectedItem()));
 //BA.debugLineNum = 242;BA.debugLine="If Spinner1.SelectedItem = CUSTOM_SELECTION Then";
if ((_spinner1.getSelectedItem()).equals(_custom_selection)) { 
 //BA.debugLineNum = 243;BA.debugLine="SaveCustomClrs";
_savecustomclrs();
 };
 //BA.debugLineNum = 245;BA.debugLine="guiHelpers.Show_toast2(\"Restart App To Change The";
_guihelpers._show_toast2 /*String*/ (ba,"Restart App To Change Theme",(int) (2200));
 //BA.debugLineNum = 246;BA.debugLine="btnClose_Click";
_btnclose_click();
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
String _defaultcolor = "";
 //BA.debugLineNum = 50;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 52;BA.debugLine="pnlBG.Color = clrTheme.Background";
_pnlbg.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 53;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnClose,bt";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnclose,_btnsave});
 //BA.debugLineNum = 57;BA.debugLine="Dim DefaultColor As String = Main.kvs.Get(gblCons";
_defaultcolor = BA.ObjectToString(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (_gblconst._selected_clr_theme /*String*/ ));
 //BA.debugLineNum = 58;BA.debugLine="Spinner1.AddAll(Array As String(\"Green\",\"Blue\",\"R";
_spinner1.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Green","Blue","Red","Dark","Dark-Blue","Dark-Green","Gray","Prusa","Rose",_custom_selection}));
 //BA.debugLineNum = 59;BA.debugLine="Spinner1.Prompt = \"Theme\"";
_spinner1.setPrompt(BA.ObjectToCharSequence("Theme"));
 //BA.debugLineNum = 60;BA.debugLine="Spinner1.SelectedIndex = Spinner1.IndexOf(Default";
_spinner1.setSelectedIndex(_spinner1.IndexOf(_defaultcolor));
 //BA.debugLineNum = 61;BA.debugLine="Spinner1.DropdownTextColor = clrTheme.txtNormal";
_spinner1.setDropdownTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 62;BA.debugLine="Spinner1.TextColor = clrTheme.txtNormal";
_spinner1.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 63;BA.debugLine="Spinner1.DropdownBackgroundColor = clrTheme.Backg";
_spinner1.setDropdownBackgroundColor(_clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 65;BA.debugLine="lblCustom.Visible = (Spinner1.SelectedItem = CUST";
_lblcustom.setVisible(((_spinner1.getSelectedItem()).equals(_custom_selection)));
 //BA.debugLineNum = 68;BA.debugLine="pnlThemeMenu.Tag = \"BGround 2\" :";
_pnlthememenu.setTag((Object)("BGround 2"));
 //BA.debugLineNum = 69;BA.debugLine="pnlThemeBG.Tag = \"BGround\"";
_pnlthemebg.setTag((Object)("BGround"));
 //BA.debugLineNum = 70;BA.debugLine="lblThemeBG.Tag = pnlThemeBG.Tag";
_lblthemebg.setTag(_pnlthemebg.getTag());
 //BA.debugLineNum = 71;BA.debugLine="pnlThemeHeader.Tag = \"BGround Header\"";
_pnlthemeheader.setTag((Object)("BGround Header"));
 //BA.debugLineNum = 72;BA.debugLine="lblText1.Tag = \"Text Main\" : lblText.Tag = lblTex";
_lbltext1.setTag((Object)("Text Main"));
 //BA.debugLineNum = 72;BA.debugLine="lblText1.Tag = \"Text Main\" : lblText.Tag = lblTex";
_lbltext.setTag(_lbltext1.getTag());
 //BA.debugLineNum = 72;BA.debugLine="lblText1.Tag = \"Text Main\" : lblText.Tag = lblTex";
_lbltext2.setTag(_lbltext1.getTag());
 //BA.debugLineNum = 73;BA.debugLine="lblTextAcc.Tag = \"Text 2\"";
_lbltextacc.setTag((Object)("Text 2"));
 //BA.debugLineNum = 74;BA.debugLine="lblDisabled.Tag = \"Disabled\"";
_lbldisabled.setTag((Object)("Disabled"));
 //BA.debugLineNum = 76;BA.debugLine="ThemeMe(DefaultColor)";
_thememe(_defaultcolor);
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgThemeSelect";
_mmodule = "dlgThemeSelect";
 //BA.debugLineNum = 9;BA.debugLine="Private pnlBG As B4XView";
_pnlbg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mMain As B4XMainPage";
_mmain = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 14;BA.debugLine="Private lblText2,lblText1,lblText As B4XView";
_lbltext2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltext1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltext = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private lblTextAcc As B4XView";
_lbltextacc = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblCustom As B4XView";
_lblcustom = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lblDisabled As B4XView";
_lbldisabled = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private pnlThemeMenu,pnlThemeHeader,pnlThemeBG As";
_pnlthememenu = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlthemeheader = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlthemebg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private Spinner1 As Spinner";
_spinner1 = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private ColorTemplate As sadB4XColorTemplate";
_colortemplate = new sadLogic.OctoTouchController.sadb4xcolortemplate();
 //BA.debugLineNum = 21;BA.debugLine="Private dgClr As B4XDialog";
_dgclr = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 22;BA.debugLine="Private Const CUSTOM_SELECTION As String = \"Custo";
_custom_selection = "Custom";
 //BA.debugLineNum = 23;BA.debugLine="Private spnPicker As Spinner";
_spnpicker = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private parent As Panel";
_parent = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private btnClose As Button";
_btnclose = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private btnSave As Button";
_btnsave = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private lblThemeBG As Label";
_lblthemebg = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 234;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 235;BA.debugLine="parent.SetVisibleAnimated(500,False)";
_parent.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 236;BA.debugLine="parent.RemoveAllViews";
_parent.RemoveAllViews();
 //BA.debugLineNum = 237;BA.debugLine="End Sub";
return "";
}
public String  _clrselected_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 173;BA.debugLine="Private Sub clrSelected_ItemClick (Position As Int";
 //BA.debugLineNum = 174;BA.debugLine="Select Case Value";
switch (BA.switchObjectToInt(_value,_pnlthemebg.getTag(),_lblthemebg.getTag(),_pnlthememenu.getTag(),_pnlthemeheader.getTag(),_lbltext.getTag(),_lbltextacc.getTag(),_lbldisabled.getTag())) {
case 0: 
case 1: {
 //BA.debugLineNum = 176;BA.debugLine="ColorTemplate.SelectedColor = pnlThemeBG.Color";
_colortemplate._setselectedcolor /*int*/ (_pnlthemebg.getColor());
 break; }
case 2: {
 //BA.debugLineNum = 177;BA.debugLine="Case pnlThemeMenu.Tag 	: 	ColorTemplate.Selected";
_colortemplate._setselectedcolor /*int*/ (_pnlthememenu.getColor());
 break; }
case 3: {
 //BA.debugLineNum = 178;BA.debugLine="Case pnlThemeHeader.Tag 	: 	ColorTemplate.Select";
_colortemplate._setselectedcolor /*int*/ (_pnlthemeheader.getColor());
 break; }
case 4: {
 //BA.debugLineNum = 179;BA.debugLine="Case lblText.Tag		 		: 	ColorTemplate.SelectedCo";
_colortemplate._setselectedcolor /*int*/ (_lbltext1.getTextColor());
 break; }
case 5: {
 //BA.debugLineNum = 180;BA.debugLine="Case lblTextAcc.Tag			: 	ColorTemplate.SelectedC";
_colortemplate._setselectedcolor /*int*/ (_lbltextacc.getTextColor());
 break; }
case 6: {
 //BA.debugLineNum = 181;BA.debugLine="Case lblDisabled.Tag 			: 	ColorTemplate.Selecte";
_colortemplate._setselectedcolor /*int*/ (_lbldisabled.getTextColor());
 break; }
}
;
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return "";
}
public String  _createcbocolorselector(String _selected) throws Exception{
 //BA.debugLineNum = 159;BA.debugLine="Private Sub CreateCboColorSelector(selected As Str";
 //BA.debugLineNum = 160;BA.debugLine="spnPicker.Initialize(\"clrSelected\")";
_spnpicker.Initialize(ba,"clrSelected");
 //BA.debugLineNum = 161;BA.debugLine="spnPicker.AddAll(Array As String( _ 					pnlTheme";
_spnpicker.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{BA.ObjectToString(_pnlthemebg.getTag()),BA.ObjectToString(_pnlthememenu.getTag()),BA.ObjectToString(_pnlthemeheader.getTag()),BA.ObjectToString(_lbltext.getTag()),BA.ObjectToString(_lbltextacc.getTag()),BA.ObjectToString(_lbldisabled.getTag())}));
 //BA.debugLineNum = 163;BA.debugLine="spnPicker.Prompt = \"Load Color\"";
_spnpicker.setPrompt(BA.ObjectToCharSequence("Load Color"));
 //BA.debugLineNum = 164;BA.debugLine="spnPicker.DropdownTextColor = clrTheme.txtNormal";
_spnpicker.setDropdownTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 165;BA.debugLine="spnPicker.TextColor = clrTheme.txtNormal";
_spnpicker.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 166;BA.debugLine="spnPicker.DropdownBackgroundColor = clrTheme.Back";
_spnpicker.setDropdownBackgroundColor(_clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 167;BA.debugLine="spnPicker.SelectedIndex = spnPicker.IndexOf(selec";
_spnpicker.setSelectedIndex(_spnpicker.IndexOf(_selected));
 //BA.debugLineNum = 169;BA.debugLine="dgClr.Base.AddView(spnPicker,4dip,dgClr.Base.Heig";
_dgclr._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .AddView((android.view.View)(_spnpicker.getObject()),__c.DipToCurrent((int) (4)),(int) (_dgclr._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()-__c.DipToCurrent((int) (50))),(int) (_dgclr._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-(_dgclr._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive).getWidth()*2)-__c.DipToCurrent((int) (24))),__c.DipToCurrent((int) (36)));
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public void  _lbldisabled_click() throws Exception{
ResumableSub_lblDisabled_Click rsub = new ResumableSub_lblDisabled_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblDisabled_Click extends BA.ResumableSub {
public ResumableSub_lblDisabled_Click(sadLogic.OctoTouchController.dlgthemeselect parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgthemeselect parent;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 212;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 212;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 213;BA.debugLine="Wait For (ShowColorPicker(lbl.TextColor,lbl.tag))";
parent.__c.WaitFor("complete", ba, this, parent._showcolorpicker(_lbl.getTextColor(),BA.ObjectToString(_lbl.getTag())));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 214;BA.debugLine="If i <> 0 Then lblDisabled.TextColor = i";
if (true) break;

case 1:
//if
this.state = 6;
if (_i!=0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._lbldisabled.setTextColor(_i);
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public void  _lbltext_click() throws Exception{
ResumableSub_lblText_Click rsub = new ResumableSub_lblText_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblText_Click extends BA.ResumableSub {
public ResumableSub_lblText_Click(sadLogic.OctoTouchController.dlgthemeselect parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgthemeselect parent;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 189;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 189;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 190;BA.debugLine="Wait For (ShowColorPicker(lbl.TextColor,lbl.Tag))";
parent.__c.WaitFor("complete", ba, this, parent._showcolorpicker(_lbl.getTextColor(),BA.ObjectToString(_lbl.getTag())));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 191;BA.debugLine="If i <> 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_i!=0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 192;BA.debugLine="lblText1.TextColor = i";
parent._lbltext1.setTextColor(_i);
 //BA.debugLineNum = 193;BA.debugLine="lblText2.TextColor = i";
parent._lbltext2.setTextColor(_i);
 //BA.debugLineNum = 194;BA.debugLine="lblText.TextColor = i";
parent._lbltext.setTextColor(_i);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _lbltextacc_click() throws Exception{
ResumableSub_lblTextAcc_Click rsub = new ResumableSub_lblTextAcc_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblTextAcc_Click extends BA.ResumableSub {
public ResumableSub_lblTextAcc_Click(sadLogic.OctoTouchController.dlgthemeselect parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgthemeselect parent;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 202;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 202;BA.debugLine="Dim lbl As B4XView : lbl = Sender";
_lbl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 203;BA.debugLine="Wait For (ShowColorPicker(lbl.TextColor,lbl.tag))";
parent.__c.WaitFor("complete", ba, this, parent._showcolorpicker(_lbl.getTextColor(),BA.ObjectToString(_lbl.getTag())));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 204;BA.debugLine="If i <> 0 Then lblTextAcc.TextColor = i";
if (true) break;

case 1:
//if
this.state = 6;
if (_i!=0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._lbltextacc.setTextColor(_i);
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 205;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _pnlbgrounds_click() throws Exception{
ResumableSub_pnlBGrounds_Click rsub = new ResumableSub_pnlBGrounds_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_pnlBGrounds_Click extends BA.ResumableSub {
public ResumableSub_pnlBGrounds_Click(sadLogic.OctoTouchController.dlgthemeselect parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgthemeselect parent;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 221;BA.debugLine="Dim pnl As B4XView : pnl = Sender";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 221;BA.debugLine="Dim pnl As B4XView : pnl = Sender";
_pnl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 222;BA.debugLine="If pnl = lblThemeBG Then pnl = pnlThemeBG";
if (true) break;

case 1:
//if
this.state = 6;
if ((_pnl).equals((java.lang.Object)(parent._lblthemebg.getObject()))) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
_pnl = parent._pnlthemebg;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 223;BA.debugLine="Wait For (ShowColorPicker(pnl.Color,pnl.tag)) Com";
parent.__c.WaitFor("complete", ba, this, parent._showcolorpicker(_pnl.getColor(),BA.ObjectToString(_pnl.getTag())));
this.state = 13;
return;
case 13:
//C
this.state = 7;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 224;BA.debugLine="If i <> 0 Then 	pnl.Color = i";
if (true) break;

case 7:
//if
this.state = 12;
if (_i!=0) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
_pnl.setColor(_i);
if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 226;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _savecustomclrs() throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Private Sub SaveCustomClrs";
 //BA.debugLineNum = 118;BA.debugLine="clrTheme.CustomColors.Initialize";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .Initialize();
 //BA.debugLineNum = 119;BA.debugLine="clrTheme.CustomColors.bg = pnlThemeBG.Color";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .bg /*int*/  = _pnlthemebg.getColor();
 //BA.debugLineNum = 120;BA.debugLine="clrTheme.CustomColors.bgHeader = pnlThemeHeader.C";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .bgheader /*int*/  = _pnlthemeheader.getColor();
 //BA.debugLineNum = 121;BA.debugLine="clrTheme.CustomColors.bgMenu = pnlThemeMenu.Color";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .bgmenu /*int*/  = _pnlthememenu.getColor();
 //BA.debugLineNum = 122;BA.debugLine="clrTheme.CustomColors.txtNormal = lblText1.TextCo";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .txtNormal /*int*/  = _lbltext1.getTextColor();
 //BA.debugLineNum = 123;BA.debugLine="clrTheme.CustomColors.txtAcc = lblTextAcc.TextCol";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .txtacc /*int*/  = _lbltextacc.getTextColor();
 //BA.debugLineNum = 124;BA.debugLine="clrTheme.CustomColors.Disabled = lblDisabled.Text";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .disabled /*int*/  = _lbldisabled.getTextColor();
 //BA.debugLineNum = 125;BA.debugLine="clrTheme.CustomColors.Divider = clrTheme.DividerC";
_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ .divider /*int*/  = _clrtheme._dividercolor /*int*/ ;
 //BA.debugLineNum = 127;BA.debugLine="Main.kvs.Put(gblConst.CUSTOM_THEME_COLORS,clrThem";
_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (_gblconst._custom_theme_colors /*String*/ ,(Object)(_clrtheme._customcolors /*sadLogic.OctoTouchController.clrtheme._tthemecolors*/ ));
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
return "";
}
public Object  _show(anywheresoftware.b4a.objects.PanelWrapper _p) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Show(p As Panel) As Object";
 //BA.debugLineNum = 38;BA.debugLine="p.RemoveAllViews";
_p.RemoveAllViews();
 //BA.debugLineNum = 39;BA.debugLine="parent = p";
_parent = _p;
 //BA.debugLineNum = 40;BA.debugLine="mMain = B4XPages.MainPage";
_mmain = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 42;BA.debugLine="parent.SetLayoutAnimated(0, 0, 0, parent.Width, p";
_parent.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_parent.getWidth(),_parent.getHeight());
 //BA.debugLineNum = 43;BA.debugLine="parent.LoadLayout(\"dlgThemeSelect\")";
_parent.LoadLayout("dlgThemeSelect",ba);
 //BA.debugLineNum = 44;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 45;BA.debugLine="parent.Visible = True";
_parent.setVisible(__c.True);
 //BA.debugLineNum = 46;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _showcolorpicker(int _callerclr,String _clrname) throws Exception{
ResumableSub_ShowColorPicker rsub = new ResumableSub_ShowColorPicker(this,_callerclr,_clrname);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ShowColorPicker extends BA.ResumableSub {
public ResumableSub_ShowColorPicker(sadLogic.OctoTouchController.dlgthemeselect parent,int _callerclr,String _clrname) {
this.parent = parent;
this._callerclr = _callerclr;
this._clrname = _clrname;
}
sadLogic.OctoTouchController.dlgthemeselect parent;
int _callerclr;
String _clrname;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _obj = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 137;BA.debugLine="dgClr.Initialize(mMain.Root)";
parent._dgclr._initialize /*String*/ (ba,parent._mmain._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 138;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 139;BA.debugLine="dlgHelper.Initialize(dgClr)";
_dlghelper._initialize /*String*/ (ba,parent._dgclr);
 //BA.debugLineNum = 141;BA.debugLine="ColorTemplate.Initialize";
parent._colortemplate._initialize /*String*/ (ba);
 //BA.debugLineNum = 142;BA.debugLine="ColorTemplate.SelectedColor = callerClr";
parent._colortemplate._setselectedcolor /*int*/ (_callerclr);
 //BA.debugLineNum = 144;BA.debugLine="dlgHelper.ThemeDialogForm(\"Select Color: \" & clrN";
_dlghelper._themedialogform /*String*/ ((Object)("Select Color: "+_clrname));
 //BA.debugLineNum = 145;BA.debugLine="Dim obj As ResumableSub = dgClr.ShowTemplate(Colo";
_obj = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_obj = parent._dgclr._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(parent._colortemplate),(Object)("OK"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 146;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 148;BA.debugLine="CreateCboColorSelector(clrName)";
parent._createcbocolorselector(_clrname);
 //BA.debugLineNum = 150;BA.debugLine="Wait For (obj) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _obj);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 151;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 152;BA.debugLine="Log(ColorTemplate.SelectedColor)";
parent.__c.LogImpl("26476560",BA.NumberToString(parent._colortemplate._getselectedcolor /*int*/ ()),0);
 //BA.debugLineNum = 153;BA.debugLine="Return  ColorTemplate.SelectedColor";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._colortemplate._getselectedcolor /*int*/ ()));return;};
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 155;BA.debugLine="Return 0";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(0));return;};
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _spinner1_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Private Sub Spinner1_ItemClick (Position As Int, V";
 //BA.debugLineNum = 81;BA.debugLine="ThemeMe(Value.As(String))";
_thememe((BA.ObjectToString(_value)));
 //BA.debugLineNum = 82;BA.debugLine="lblCustom.Visible = (Value = \"Custom\").As(Boolean";
_lblcustom.setVisible((((_value).equals((Object)("Custom")))));
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _thememe(String _clr) throws Exception{
int _txtnormaltmp = 0;
int _txtaccenttmp = 0;
int _btndisabletexttmp = 0;
int _dividercolortmp = 0;
int _backgroundtmp = 0;
int _backgroundheadertmp = 0;
int _background2tmp = 0;
 //BA.debugLineNum = 85;BA.debugLine="Private Sub ThemeMe(clr As String)";
 //BA.debugLineNum = 88;BA.debugLine="Dim txtNormalTmp As Int = clrTheme.txtNormal";
_txtnormaltmp = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 89;BA.debugLine="Dim txtAccentTmp As Int = clrTheme.txtAccent";
_txtaccenttmp = _clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 90;BA.debugLine="Dim btnDisableTextTmp As Int = clrTheme.btnDisabl";
_btndisabletexttmp = _clrtheme._btndisabletext /*int*/ ;
 //BA.debugLineNum = 91;BA.debugLine="Dim DividerColorTmp As Int = clrTheme.DividerColo";
_dividercolortmp = _clrtheme._dividercolor /*int*/ ;
 //BA.debugLineNum = 92;BA.debugLine="Dim BackgroundTmp As Int = clrTheme.Background";
_backgroundtmp = _clrtheme._background /*int*/ ;
 //BA.debugLineNum = 93;BA.debugLine="Dim BackgroundHeaderTmp As Int = clrTheme.Backgro";
_backgroundheadertmp = _clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 94;BA.debugLine="Dim Background2Tmp As Int = clrTheme.Background2";
_background2tmp = _clrtheme._background2 /*int*/ ;
 //BA.debugLineNum = 96;BA.debugLine="clrTheme.InitTheme(clr) '--- one place for settin";
_clrtheme._inittheme /*String*/ (ba,_clr);
 //BA.debugLineNum = 98;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblText,";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lbltext,_lbltext1,_lbltext2,_lblcustom,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblthemebg.getObject()))});
 //BA.debugLineNum = 99;BA.debugLine="lblTextAcc.TextColor = clrTheme.txtAccent";
_lbltextacc.setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 100;BA.debugLine="pnlThemeMenu.Color = clrTheme.Background2";
_pnlthememenu.setColor(_clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 101;BA.debugLine="pnlThemeHeader.Color = clrTheme.BackgroundHeader";
_pnlthemeheader.setColor(_clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 102;BA.debugLine="pnlThemeBG.Color = clrTheme.Background";
_pnlthemebg.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 103;BA.debugLine="lblDisabled.TextColor = clrTheme.btnDisableText";
_lbldisabled.setTextColor(_clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 106;BA.debugLine="clrTheme.txtNormal = txtNormalTmp";
_clrtheme._txtnormal /*int*/  = _txtnormaltmp;
 //BA.debugLineNum = 107;BA.debugLine="clrTheme.txtAccent = txtAccentTmp";
_clrtheme._txtaccent /*int*/  = _txtaccenttmp;
 //BA.debugLineNum = 108;BA.debugLine="clrTheme.btnDisableText = btnDisableTextTmp";
_clrtheme._btndisabletext /*int*/  = _btndisabletexttmp;
 //BA.debugLineNum = 109;BA.debugLine="clrTheme.DividerColor = DividerColorTmp";
_clrtheme._dividercolor /*int*/  = _dividercolortmp;
 //BA.debugLineNum = 110;BA.debugLine="clrTheme.Background = BackgroundTmp";
_clrtheme._background /*int*/  = _backgroundtmp;
 //BA.debugLineNum = 111;BA.debugLine="clrTheme.BackgroundHeader = BackgroundHeaderTmp";
_clrtheme._backgroundheader /*int*/  = _backgroundheadertmp;
 //BA.debugLineNum = 112;BA.debugLine="clrTheme.Background2 = Background2Tmp";
_clrtheme._background2 /*int*/  = _background2tmp;
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
if (BA.fastSubCompare(sub, "SHOW"))
	return _show((anywheresoftware.b4a.objects.PanelWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
