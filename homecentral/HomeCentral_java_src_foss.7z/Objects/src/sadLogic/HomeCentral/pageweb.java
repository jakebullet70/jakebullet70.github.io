package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pageweb extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pageweb");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pageweb.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public String _homepage = "";
public String _currentpage = "";
public anywheresoftware.b4a.objects.WebViewWrapper _wv = null;
public uk.co.martinpearman.b4a.webviewsettings.WebViewSettings _wvs = null;
public uk.co.martinpearman.b4a.webkit.WebViewExtras _webviewextras1 = null;
public uk.co.martinpearman.b4a.webkit.DefaultWebChromeClient _webchromeclient1 = null;
public uk.co.martinpearman.b4a.webkit.DefaultJavascriptInterface _javascriptinterface1 = null;
public uk.co.martinpearman.b4a.webkit.DefaultWebViewClient _webviewclient1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmoveh = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmoveb = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmovef = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmover = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btnmove_click() throws Exception{
String _b = "";
 //BA.debugLineNum = 99;BA.debugLine="Private Sub btnMove_Click";
 //BA.debugLineNum = 100;BA.debugLine="Dim b As String = Sender.As(B4XView).Tag";
_b = BA.ObjectToString(((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)))).getTag());
 //BA.debugLineNum = 101;BA.debugLine="Select Case b";
switch (BA.switchObjectToInt(_b,"f","h","b","r")) {
case 0: {
 //BA.debugLineNum = 103;BA.debugLine="wv.Forward";
_wv.Forward();
 break; }
case 1: {
 //BA.debugLineNum = 105;BA.debugLine="CallSubDelayed2(Me,\"Load_page\",homePage)";
__c.CallSubDelayed2(ba,this,"Load_page",(Object)(_homepage));
 break; }
case 2: {
 //BA.debugLineNum = 107;BA.debugLine="wv.Back";
_wv.Back();
 break; }
case 3: {
 //BA.debugLineNum = 109;BA.debugLine="If CurrentPage = \"\" Then Return";
if ((_currentpage).equals("")) { 
if (true) return "";};
 //BA.debugLineNum = 110;BA.debugLine="CallSubDelayed2(Me,\"Load_page\",CurrentPage)";
__c.CallSubDelayed2(ba,this,"Load_page",(Object)(_currentpage));
 break; }
}
;
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Private Sub Build_Side_Menu";
 //BA.debugLineNum = 81;BA.debugLine="Menus.BuildSideMenu(Array As String(\"\"),Array As";
_menus._buildsidemenu /*String*/ (ba,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}));
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 10;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private homePage As String = \"\"";
_homepage = "";
 //BA.debugLineNum = 12;BA.debugLine="Private CurrentPage As String";
_currentpage = "";
 //BA.debugLineNum = 15;BA.debugLine="Private wv As WebView,  wvs As WebViewSettings";
_wv = new anywheresoftware.b4a.objects.WebViewWrapper();
_wvs = new uk.co.martinpearman.b4a.webviewsettings.WebViewSettings();
 //BA.debugLineNum = 16;BA.debugLine="Private WebViewExtras1 As WebViewExtras";
_webviewextras1 = new uk.co.martinpearman.b4a.webkit.WebViewExtras();
 //BA.debugLineNum = 17;BA.debugLine="Private WebChromeClient1 As DefaultWebChromeClien";
_webchromeclient1 = new uk.co.martinpearman.b4a.webkit.DefaultWebChromeClient();
 //BA.debugLineNum = 18;BA.debugLine="Private JavascriptInterface1 As DefaultJavascript";
_javascriptinterface1 = new uk.co.martinpearman.b4a.webkit.DefaultJavascriptInterface();
 //BA.debugLineNum = 19;BA.debugLine="Private WebViewClient1 As DefaultWebViewClient";
_webviewclient1 = new uk.co.martinpearman.b4a.webkit.DefaultWebViewClient();
 //BA.debugLineNum = 22;BA.debugLine="Private btnMoveH,btnMoveB,btnMoveF,btnMoveR As Bu";
_btnmoveh = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnmoveb = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnmovef = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnmover = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _get_homepage() throws Exception{
 //BA.debugLineNum = 84;BA.debugLine="Private Sub Get_homepage";
 //BA.debugLineNum = 85;BA.debugLine="homePage = Main.kvs.Get(gblConst.INI_WEB_HOME)";
_homepage = BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_web_home /*String*/ ));
 //BA.debugLineNum = 86;BA.debugLine="If strHelpers.IsNullOrEmpty(homePage) Then";
if (_strhelpers._isnullorempty /*boolean*/ (ba,_homepage)) { 
 //BA.debugLineNum = 87;BA.debugLine="Main.kvs.Put(gblConst.INI_WEB_HOME,\"http://sadlo";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_web_home /*String*/ ,(Object)("http://sadlogic.com"));
 //BA.debugLineNum = 88;BA.debugLine="homePage = Main.kvs.Get(gblConst.INI_WEB_HOME)";
_homepage = BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_web_home /*String*/ ));
 };
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.phone.Phone _ph = null;
 //BA.debugLineNum = 26;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 27;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 28;BA.debugLine="pnlMain.LoadLayout(\"pageWebBase\")";
_pnlmain.LoadLayout("pageWebBase",ba);
 //BA.debugLineNum = 30;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnMoveB,bt";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnmoveb,_btnmovef,_btnmoveh,_btnmover});
 //BA.debugLineNum = 31;BA.debugLine="Get_homepage";
_get_homepage();
 //BA.debugLineNum = 33;BA.debugLine="guiHelpers.ResizeText(Chr(0xE88A),btnMoveH)";
_guihelpers._resizetext /*String*/ (ba,BA.ObjectToString(__c.Chr(((int)0xe88a))),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_btnmoveh.getObject())));
 //BA.debugLineNum = 34;BA.debugLine="btnMoveH.TextSize = btnMoveH.TextSize - IIf(guiHe";
_btnmoveh.setTextSize((float) (_btnmoveh.getTextSize()-(double)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >7.5) ? ((Object)(22)) : ((Object)(14)))))));
 //BA.debugLineNum = 35;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(btnMoveB,";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnmoveb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnmovef.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnmover.getObject()))},_btnmoveh.getTextSize());
 //BA.debugLineNum = 37;BA.debugLine="Dim ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 40;BA.debugLine="Dim JavascriptInterface1 As DefaultJavascriptInte";
_javascriptinterface1 = new uk.co.martinpearman.b4a.webkit.DefaultJavascriptInterface();
 //BA.debugLineNum = 41;BA.debugLine="JavascriptInterface1.Initialize";
_javascriptinterface1.Initialize(ba);
 //BA.debugLineNum = 42;BA.debugLine="WebViewExtras1.Initialize(wv)";
_webviewextras1.Initialize((android.webkit.WebView)(_wv.getObject()));
 //BA.debugLineNum = 46;BA.debugLine="Dim WebViewClient1 As DefaultWebViewClient";
_webviewclient1 = new uk.co.martinpearman.b4a.webkit.DefaultWebViewClient();
 //BA.debugLineNum = 47;BA.debugLine="WebViewClient1.Initialize(\"WebViewClient1\")";
_webviewclient1.Initialize(ba,"WebViewClient1");
 //BA.debugLineNum = 48;BA.debugLine="Try";
try { //BA.debugLineNum = 49;BA.debugLine="If ph.SdkVersion >= gblConst.API_ANDROID_4_2 The";
if (_ph.getSdkVersion()>=_gblconst._api_android_4_2 /*int*/ ) { 
 //BA.debugLineNum = 50;BA.debugLine="WebViewExtras1.JavaScriptEnabled = True";
_webviewextras1.setJavaScriptEnabled(__c.True);
 };
 } 
       catch (Exception e19) {
			ba.setLastException(e19); //BA.debugLineNum = 53;BA.debugLine="LogIt.LogWrite(\"WebViewExtras1.JavaScriptEnabled";
_logit._logwrite /*String*/ (ba,"WebViewExtras1.JavaScriptEnabled FAILED: "+BA.ObjectToString(__c.LastException(ba)),(int) (0));
 };
 //BA.debugLineNum = 55;BA.debugLine="WebViewExtras1.SetWebViewClient(WebViewClient1)";
_webviewextras1.SetWebViewClient((android.webkit.WebViewClient)(_webviewclient1.getObject()));
 //BA.debugLineNum = 56;BA.debugLine="wvs.setUseWideViewPort(wv, True)";
_wvs.setUseWideViewPort((android.webkit.WebView)(_wv.getObject()),__c.True);
 //BA.debugLineNum = 57;BA.debugLine="wvs.setDisplayZoomControls(wv, False)";
_wvs.setDisplayZoomControls((android.webkit.WebView)(_wv.getObject()),__c.False);
 //BA.debugLineNum = 58;BA.debugLine="wvs.setLoadsImagesAutomatically(wv, True)";
_wvs.setLoadsImagesAutomatically((android.webkit.WebView)(_wv.getObject()),__c.True);
 //BA.debugLineNum = 60;BA.debugLine="CallSubDelayed2(Me,\"Load_Page\",homePage)";
__c.CallSubDelayed2(ba,this,"Load_Page",(Object)(_homepage));
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
public String  _load_page(String _page) throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Private Sub Load_page(page As String)";
 //BA.debugLineNum = 93;BA.debugLine="wv.LoadUrl(page)";
_wv.LoadUrl(_page);
 //BA.debugLineNum = 94;BA.debugLine="CurrentPage = page";
_currentpage = _page;
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 73;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 67;BA.debugLine="Get_homepage";
_get_homepage();
 //BA.debugLineNum = 68;BA.debugLine="Menus.SetHeader(\"Web\",\"main_menu_web.png\")";
_menus._setheader /*String*/ (ba,"Web","main_menu_web.png");
 //BA.debugLineNum = 69;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 70;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "LOAD_PAGE"))
	return _load_page((String) args[0]);
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
return BA.SubDelegator.SubNotFound;
}
}
