package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class kt {
private static kt mostCurrent = new kt();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.sql.SQL _osql = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static class _typtimers{
public boolean IsInitialized;
public sadLogic.HomeCentral.kt._typalarmtypes alarmType;
public boolean Firing;
public String txt;
public int nHr;
public int nMin;
public int nSec;
public boolean active;
public long endTime;
public boolean paused;
public void Initialize() {
IsInitialized = true;
alarmType = new sadLogic.HomeCentral.kt._typalarmtypes();
Firing = false;
txt = "";
nHr = 0;
nMin = 0;
nSec = 0;
active = false;
endTime = 0L;
paused = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _typalarmtypes{
public boolean IsInitialized;
public boolean sendGrowl;
public boolean sendTxtMSG;
public boolean beepMe;
public boolean playFile;
public boolean ShowScreenSmall;
public boolean ShowScreenBig;
public void Initialize() {
IsInitialized = true;
sendGrowl = false;
sendTxtMSG = false;
beepMe = false;
playFile = false;
ShowScreenSmall = false;
ShowScreenBig = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static boolean  _anytimersfiring(anywheresoftware.b4a.BA _ba) throws Exception{
int _xx = 0;
 //BA.debugLineNum = 95;BA.debugLine="Public Sub AnyTimersFiring() As Boolean";
 //BA.debugLineNum = 96;BA.debugLine="Dim xx As Int";
_xx = 0;
 //BA.debugLineNum = 97;BA.debugLine="For xx = 1 To 5";
{
final int step2 = 1;
final int limit2 = (int) (5);
_xx = (int) (1) ;
for (;_xx <= limit2 ;_xx = _xx + step2 ) {
 //BA.debugLineNum = 98;BA.debugLine="If B4XPages.MainPage.oPageTimers.clsKTimers.time";
if (mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ._clsktimers /*sadLogic.HomeCentral.kitchentmrs*/ ._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_xx].Firing /*boolean*/ ) { 
 //BA.debugLineNum = 99;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 };
 }
};
 //BA.debugLineNum = 102;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return false;
}
public static String  _clear_timer(anywheresoftware.b4a.BA _ba,int _x) throws Exception{
sadLogic.HomeCentral.kitchentmrs _o = null;
 //BA.debugLineNum = 67;BA.debugLine="Public Sub Clear_Timer(x As Int)";
 //BA.debugLineNum = 69;BA.debugLine="Dim o As KitchenTmrs = B4XPages.MainPage.oPageTim";
_o = mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ._clsktimers /*sadLogic.HomeCentral.kitchentmrs*/ ;
 //BA.debugLineNum = 70;BA.debugLine="o.timers(x).active = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].active /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 71;BA.debugLine="o.timers(x).nHr = 0";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nHr /*int*/  = (int) (0);
 //BA.debugLineNum = 72;BA.debugLine="o.timers(x).nSec = 0";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nSec /*int*/  = (int) (0);
 //BA.debugLineNum = 73;BA.debugLine="o.timers(x).nMin = 0";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nMin /*int*/  = (int) (0);
 //BA.debugLineNum = 74;BA.debugLine="o.timers(x).txt= \"Open\"";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].txt /*String*/  = "Open";
 //BA.debugLineNum = 75;BA.debugLine="o.timers(x).endTime = 0";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].endTime /*long*/  = (long) (0);
 //BA.debugLineNum = 76;BA.debugLine="o.timers(x).Firing = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].Firing /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 77;BA.debugLine="o.timers(x).paused = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].paused /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 78;BA.debugLine="InitAlarmTypes(o,x)";
_initalarmtypes(_ba,_o,_x);
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static String  _initalarmtypes(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.kitchentmrs _o,int _x) throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Private Sub InitAlarmTypes(o As KitchenTmrs,x As I";
 //BA.debugLineNum = 86;BA.debugLine="o.timers(x).alarmType.beepMe = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .beepMe /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 87;BA.debugLine="o.timers(x).alarmType.playFile = True";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .playFile /*boolean*/  = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 88;BA.debugLine="o.timers(x).alarmType.ShowScreenBig = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .ShowScreenBig /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 89;BA.debugLine="o.timers(x).alarmType.ShowScreenSmall = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .ShowScreenSmall /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 90;BA.debugLine="o.timers(x).alarmType.sendGrowl = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .sendGrowl /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 91;BA.debugLine="o.timers(x).alarmType.sendTxtMSG = False";
_o._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .sendTxtMSG /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public static String  _initsql(anywheresoftware.b4a.BA _ba) throws Exception{
int _count = 0;
 //BA.debugLineNum = 106;BA.debugLine="Public Sub InitSql";
 //BA.debugLineNum = 107;BA.debugLine="oSQL = B4XPages.MainPage.sql";
_osql = mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._sql /*anywheresoftware.b4a.sql.SQL*/ ;
 //BA.debugLineNum = 113;BA.debugLine="oSQL.ExecNonQuery($\"CREATE TABLE IF NOT EXISTS \"t";
_osql.ExecNonQuery(("CREATE TABLE IF NOT EXISTS \"timers\" (\n"+"		\"id\"	INTEGER,\n"+"		\"description\"	TEXT,\"time\" TEXT,\n"+"		PRIMARY KEY(\"id\" AUTOINCREMENT));"));
 //BA.debugLineNum = 118;BA.debugLine="Dim count As Int = oSQL.ExecQuerySingleResult($\"S";
_count = (int)(Double.parseDouble(_osql.ExecQuerySingleResult(("SELECT COUNT(*) FROM timers"))));
 //BA.debugLineNum = 119;BA.debugLine="If count = 0 Then";
if (_count==0) { 
 //BA.debugLineNum = 120;BA.debugLine="oSQL.ExecNonQuery($\"CREATE INDEX \"ndx_desc\" ON \"";
_osql.ExecNonQuery(("CREATE INDEX \"ndx_desc\" ON \"timers\" (\"description\");"));
 //BA.debugLineNum = 121;BA.debugLine="timers_insert_new(\"Long Pasta\",\"00:09:00\")";
_timers_insert_new(_ba,"Long Pasta","00:09:00");
 //BA.debugLineNum = 122;BA.debugLine="timers_insert_new(\"Bake Bread\",\"00:45:00\")";
_timers_insert_new(_ba,"Bake Bread","00:45:00");
 //BA.debugLineNum = 123;BA.debugLine="timers_insert_new(\"Boiled Eggs\",\"00:08:30\")";
_timers_insert_new(_ba,"Boiled Eggs","00:08:30");
 };
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return "";
}
public static String  _padzero(anywheresoftware.b4a.BA _ba,int _n) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Public Sub PadZero(n As Int) As String";
 //BA.debugLineNum = 56;BA.debugLine="Return strHelpers.PadLeft(n,\"0\",2)";
if (true) return mostCurrent._strhelpers._padleft /*String*/ (_ba,BA.NumberToString(_n),"0",(int) (2));
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private oSQL As SQL";
_osql = new anywheresoftware.b4a.sql.SQL();
 //BA.debugLineNum = 14;BA.debugLine="Type typTimers (alarmType As typAlarmTypes, _";
;
 //BA.debugLineNum = 24;BA.debugLine="Type typAlarmTypes (sendGrowl As Boolean , _";
;
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public static int  _returnnegnum(anywheresoftware.b4a.BA _ba,int _num) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Public Sub returnNegNum(num As Int) As Int";
 //BA.debugLineNum = 60;BA.debugLine="num = Abs(num)";
_num = (int) (anywheresoftware.b4a.keywords.Common.Abs(_num));
 //BA.debugLineNum = 61;BA.debugLine="Return (num - (num * 2))";
if (true) return (int) ((_num-(_num*2)));
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return 0;
}
public static String  _setimages(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.lmb4ximageviewx[] _arr,String _imgname) throws Exception{
sadLogic.HomeCentral.lmb4ximageviewx _o = null;
 //BA.debugLineNum = 36;BA.debugLine="Public Sub SetImages(Arr() As lmB4XImageViewX,imgN";
 //BA.debugLineNum = 37;BA.debugLine="For Each o As lmB4XImageViewX In Arr";
{
final sadLogic.HomeCentral.lmb4ximageviewx[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 38;BA.debugLine="o.Bitmap = XUI.LoadBitmap(File.DirAssets, imgNam";
_o._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),_imgname));
 }
};
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public static String  _timers_delete(anywheresoftware.b4a.BA _ba,String _id) throws Exception{
 //BA.debugLineNum = 131;BA.debugLine="Public Sub timers_delete(id As String)";
 //BA.debugLineNum = 132;BA.debugLine="oSQL.ExecNonQuery(\"DELETE FROM timers WHERE id=\"";
_osql.ExecNonQuery("DELETE FROM timers WHERE id="+_id);
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.sql.SQL.CursorWrapper  _timers_get_all(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 135;BA.debugLine="Public Sub timers_get_all() As Cursor";
 //BA.debugLineNum = 136;BA.debugLine="Return oSQL.ExecQuery(\"SELECT * FROM timers ORDER";
if (true) return (anywheresoftware.b4a.sql.SQL.CursorWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.sql.SQL.CursorWrapper(), (android.database.Cursor)(_osql.ExecQuery("SELECT * FROM timers ORDER BY description")));
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return null;
}
public static String  _timers_insert_new(anywheresoftware.b4a.BA _ba,String _desc,String _thetime) throws Exception{
 //BA.debugLineNum = 127;BA.debugLine="Public Sub timers_insert_new(desc As String, theTi";
 //BA.debugLineNum = 128;BA.debugLine="oSQL.ExecNonQuery2($\"INSERT INTO timers (\"descrip";
_osql.ExecNonQuery2(("INSERT INTO timers (\"description\",\"time\") VALUES (?,?);"),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_desc,_thetime}));
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return "";
}
public static String  _xintsstr(anywheresoftware.b4a.BA _ba,int _n) throws Exception{
String _s = "";
 //BA.debugLineNum = 46;BA.debugLine="Public Sub xIntsStr(n As Int) As String";
 //BA.debugLineNum = 47;BA.debugLine="Dim s As String = n";
_s = BA.NumberToString(_n);
 //BA.debugLineNum = 48;BA.debugLine="If s.Length = 2 Then";
if (_s.length()==2) { 
 //BA.debugLineNum = 49;BA.debugLine="Return n";
if (true) return BA.NumberToString(_n);
 }else {
 //BA.debugLineNum = 51;BA.debugLine="Return \"0\" & n";
if (true) return "0"+BA.NumberToString(_n);
 };
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public static int  _xstr2int(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Public Sub xStr2Int(s As String) As Int";
 //BA.debugLineNum = 43;BA.debugLine="Return s";
if (true) return (int)(Double.parseDouble(_s));
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return 0;
}
}
