package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_scrnconvbutter{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padlr="";
String _padtb="";
String _items="";
String _split="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
_padlr = BA.NumberToString((80d * scale));
_padtb = BA.NumberToString((20d * scale));
views.get("pnlbutter").vw.setLeft((int)(0d));
views.get("pnlbutter").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbutter").vw.setTop((int)(0d));
views.get("pnlbutter").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("panel0").vw.setLeft((int)((views.get("pnlbutter").vw.getLeft())+Double.parseDouble(_padlr)));
views.get("panel0").vw.setWidth((int)((views.get("pnlbutter").vw.getLeft() + views.get("pnlbutter").vw.getWidth())-Double.parseDouble(_padlr) - ((views.get("pnlbutter").vw.getLeft())+Double.parseDouble(_padlr))));
views.get("panel0").vw.setTop((int)((views.get("pnlbutter").vw.getTop())+Double.parseDouble(_padtb)+(30d * scale)));
views.get("panel0").vw.setHeight((int)((views.get("pnlbutter").vw.getTop() + views.get("pnlbutter").vw.getHeight())-Double.parseDouble(_padtb) - ((views.get("pnlbutter").vw.getTop())+Double.parseDouble(_padtb)+(30d * scale))));
_items = BA.NumberToString((((views.get("panel0").vw.getHeight()))/5d));
_split = ".40";
views.get("panel1").vw.setLeft((int)(0d));
views.get("panel1").vw.setWidth((int)((views.get("panel0").vw.getWidth()) - (0d)));
views.get("panel1").vw.setTop((int)(0d));
views.get("panel1").vw.setHeight((int)(Double.parseDouble(_items) - (0d)));
views.get("lblgramsb").vw.setLeft((int)(0d));
views.get("lblgramsb").vw.setWidth((int)((views.get("panel1").vw.getWidth()) - (0d)));
views.get("lblgramsb").vw.setTop((int)(0d));
views.get("lblgramsb").vw.setHeight((int)((views.get("panel1").vw.getHeight())*Double.parseDouble(_split) - (0d)));
views.get("txtgramsb").vw.setLeft((int)(0d));
views.get("txtgramsb").vw.setWidth((int)((views.get("panel1").vw.getWidth()) - (0d)));
views.get("txtgramsb").vw.setTop((int)((views.get("lblgramsb").vw.getTop() + views.get("lblgramsb").vw.getHeight())));
views.get("txtgramsb").vw.setHeight((int)((views.get("panel1").vw.getHeight()) - ((views.get("lblgramsb").vw.getTop() + views.get("lblgramsb").vw.getHeight()))));
views.get("panel2").vw.setLeft((int)(0d));
views.get("panel2").vw.setWidth((int)((views.get("panel0").vw.getWidth()) - (0d)));
views.get("panel2").vw.setTop((int)((views.get("panel1").vw.getTop() + views.get("panel1").vw.getHeight())));
views.get("panel2").vw.setHeight((int)(Double.parseDouble(_items)*2d - ((views.get("panel1").vw.getTop() + views.get("panel1").vw.getHeight()))));
views.get("lbltbsp").vw.setLeft((int)(0d));
views.get("lbltbsp").vw.setWidth((int)((views.get("panel2").vw.getWidth()) - (0d)));
views.get("lbltbsp").vw.setTop((int)(0d));
views.get("lbltbsp").vw.setHeight((int)((views.get("panel2").vw.getHeight())*Double.parseDouble(_split) - (0d)));
views.get("txttbsp").vw.setLeft((int)(0d));
views.get("txttbsp").vw.setWidth((int)((views.get("panel2").vw.getWidth()) - (0d)));
views.get("txttbsp").vw.setTop((int)((views.get("lbltbsp").vw.getTop() + views.get("lbltbsp").vw.getHeight())));
views.get("txttbsp").vw.setHeight((int)((views.get("panel2").vw.getHeight()) - ((views.get("lbltbsp").vw.getTop() + views.get("lbltbsp").vw.getHeight()))));
views.get("panel3").vw.setLeft((int)(0d));
views.get("panel3").vw.setWidth((int)((views.get("panel0").vw.getWidth()) - (0d)));
views.get("panel3").vw.setTop((int)((views.get("panel2").vw.getTop() + views.get("panel2").vw.getHeight())));
views.get("panel3").vw.setHeight((int)(Double.parseDouble(_items)*3d - ((views.get("panel2").vw.getTop() + views.get("panel2").vw.getHeight()))));
views.get("lblozb").vw.setLeft((int)(0d));
views.get("lblozb").vw.setWidth((int)((views.get("panel3").vw.getWidth()) - (0d)));
views.get("lblozb").vw.setTop((int)(0d));
views.get("lblozb").vw.setHeight((int)((views.get("panel3").vw.getHeight())*Double.parseDouble(_split) - (0d)));
views.get("txtozb").vw.setLeft((int)(0d));
views.get("txtozb").vw.setWidth((int)((views.get("panel3").vw.getWidth()) - (0d)));
views.get("txtozb").vw.setTop((int)((views.get("lblozb").vw.getTop() + views.get("lblozb").vw.getHeight())));
views.get("txtozb").vw.setHeight((int)((views.get("panel3").vw.getHeight()) - ((views.get("lblozb").vw.getTop() + views.get("lblozb").vw.getHeight()))));
views.get("panel4").vw.setLeft((int)(0d));
views.get("panel4").vw.setWidth((int)((views.get("panel0").vw.getWidth()) - (0d)));
views.get("panel4").vw.setTop((int)((views.get("panel3").vw.getTop() + views.get("panel3").vw.getHeight())));
views.get("panel4").vw.setHeight((int)(Double.parseDouble(_items)*4d - ((views.get("panel3").vw.getTop() + views.get("panel3").vw.getHeight()))));
views.get("lblcup").vw.setLeft((int)(0d));
views.get("lblcup").vw.setWidth((int)((views.get("panel4").vw.getWidth()) - (0d)));
views.get("lblcup").vw.setTop((int)(0d));
views.get("lblcup").vw.setHeight((int)((views.get("panel4").vw.getHeight())*Double.parseDouble(_split) - (0d)));
views.get("txtcup").vw.setLeft((int)(0d));
views.get("txtcup").vw.setWidth((int)((views.get("panel4").vw.getWidth()) - (0d)));
views.get("txtcup").vw.setTop((int)((views.get("lblcup").vw.getTop() + views.get("lblcup").vw.getHeight())));
views.get("txtcup").vw.setHeight((int)((views.get("panel4").vw.getHeight()) - ((views.get("lblcup").vw.getTop() + views.get("lblcup").vw.getHeight()))));
views.get("panel5").vw.setLeft((int)(0d));
views.get("panel5").vw.setWidth((int)((views.get("panel0").vw.getWidth()) - (0d)));
views.get("panel5").vw.setTop((int)((views.get("panel4").vw.getTop() + views.get("panel4").vw.getHeight())));
views.get("panel5").vw.setHeight((int)(Double.parseDouble(_items)*5d - ((views.get("panel4").vw.getTop() + views.get("panel4").vw.getHeight()))));
views.get("lblstick").vw.setLeft((int)(0d));
views.get("lblstick").vw.setWidth((int)((views.get("panel5").vw.getWidth()) - (0d)));
views.get("lblstick").vw.setTop((int)(0d));
views.get("lblstick").vw.setHeight((int)((views.get("panel5").vw.getHeight())*Double.parseDouble(_split) - (0d)));
views.get("txtstick").vw.setLeft((int)(0d));
views.get("txtstick").vw.setWidth((int)((views.get("panel5").vw.getWidth()) - (0d)));
views.get("txtstick").vw.setTop((int)((views.get("lblstick").vw.getTop() + views.get("lblstick").vw.getHeight())));
views.get("txtstick").vw.setHeight((int)((views.get("panel5").vw.getHeight()) - ((views.get("lblstick").vw.getTop() + views.get("lblstick").vw.getHeight()))));

}
}