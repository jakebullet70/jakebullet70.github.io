package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class strhelpers {
private static strhelpers mostCurrent = new strhelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _convertlinuxlineendings2windows(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="public Sub ConvertLinuxLineEndings2Windows(s As St";
 //BA.debugLineNum = 28;BA.debugLine="Return s.Replace(Chr(10),Chr(13) & Chr(10))";
if (true) return _s.replace(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10))));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public static boolean  _isnullorempty(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Public Sub IsNullOrEmpty(s As String) As Boolean";
 //BA.debugLineNum = 76;BA.debugLine="Return s = Null Or s.CompareTo(Null) = 0 Or s = \"";
if (true) return _s== null || _s.compareTo(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Null))==0 || (_s).equals("");
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return false;
}
public static String  _join(anywheresoftware.b4a.BA _ba,String _sepchar,anywheresoftware.b4a.objects.collections.List _strings) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _s = "";
 //BA.debugLineNum = 44;BA.debugLine="Public Sub Join(sepChar As String, Strings As List";
 //BA.debugLineNum = 46;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 47;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 49;BA.debugLine="For Each s As String In Strings";
{
final anywheresoftware.b4a.BA.IterableList group3 = _strings;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_s = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 50;BA.debugLine="sb.Append(s).Append(sepChar)";
_sb.Append(_s).Append(_sepchar);
 }
};
 //BA.debugLineNum = 53;BA.debugLine="If sb.Length > 0 Then";
if (_sb.getLength()>0) { 
 //BA.debugLineNum = 54;BA.debugLine="sb.Remove(sb.Length - sepChar.Length, sb.Length)";
_sb.Remove((int) (_sb.getLength()-_sepchar.length()),_sb.getLength());
 };
 //BA.debugLineNum = 57;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public static String  _padleft(anywheresoftware.b4a.BA _ba,String _source,String _padchar,int _length) throws Exception{
int _i = 0;
 //BA.debugLineNum = 12;BA.debugLine="Public Sub PadLeft(Source As String, PadChar As St";
 //BA.debugLineNum = 15;BA.debugLine="For i = 0 To Length-1";
{
final int step1 = 1;
final int limit1 = (int) (_length-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 16;BA.debugLine="If Source.Length = Length Then";
if (_source.length()==_length) { 
 //BA.debugLineNum = 17;BA.debugLine="Exit";
if (true) break;
 };
 //BA.debugLineNum = 19;BA.debugLine="Source = PadChar & Source";
_source = _padchar+_source;
 }
};
 //BA.debugLineNum = 22;BA.debugLine="Return Source";
if (true) return _source;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public static String  _propercase(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
int _i = 0;
 //BA.debugLineNum = 32;BA.debugLine="Public Sub ProperCase(s As String) As String";
 //BA.debugLineNum = 33;BA.debugLine="s = s.ToLowerCase";
_s = _s.toLowerCase();
 //BA.debugLineNum = 34;BA.debugLine="Dim m As Matcher = Regex.Matcher(\"\\b(\\w)\", s)";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = anywheresoftware.b4a.keywords.Common.Regex.Matcher("\\b(\\w)",_s);
 //BA.debugLineNum = 35;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 36;BA.debugLine="Dim i As Int = m.GetStart(1)";
_i = _m.GetStart((int) (1));
 //BA.debugLineNum = 37;BA.debugLine="s = s.SubString2(0, i) & s.SubString2(i, i + 1).";
_s = _s.substring((int) (0),_i)+_s.substring(_i,(int) (_i+1)).toUpperCase()+_s.substring((int) (_i+1));
 }
;
 //BA.debugLineNum = 39;BA.debugLine="Return s";
if (true) return _s;
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public static String  _trimlast(anywheresoftware.b4a.BA _ba,String _s,String _trimchar) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="public Sub TrimLast(s As String, trimchar As Strin";
 //BA.debugLineNum = 65;BA.debugLine="If s.EndsWith(trimchar) Then";
if (_s.endsWith(_trimchar)) { 
 //BA.debugLineNum = 66;BA.debugLine="Return s.SubString2(0,s.Length - trimchar.Length";
if (true) return _s.substring((int) (0),(int) (_s.length()-_trimchar.length()));
 }else {
 //BA.debugLineNum = 68;BA.debugLine="Return s";
if (true) return _s;
 };
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
}
