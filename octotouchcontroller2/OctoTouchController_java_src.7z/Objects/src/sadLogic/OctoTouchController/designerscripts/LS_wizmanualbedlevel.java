package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_wizmanualbedlevel{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _pad="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbg").vw.setLeft((int)(0d));
views.get("pnlbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbg").vw.setTop((int)(0d));
views.get("pnlbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
if ((BA.ObjectToBoolean( String.valueOf(!anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
_pad = BA.NumberToString((6d * scale));
views.get("alblheader").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("alblheader").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())*.76d - (Double.parseDouble(_pad))));
views.get("pnlhost").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("pnlhost").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())*.76d - (Double.parseDouble(_pad))));
views.get("pnlhost").vw.setTop((int)((views.get("alblheader").vw.getTop() + views.get("alblheader").vw.getHeight())));
views.get("pnlhost").vw.setHeight((int)((views.get("pnlbg").vw.getHeight())-(1d * scale) - ((views.get("alblheader").vw.getTop() + views.get("alblheader").vw.getHeight()))));
views.get("alblmenu").vw.setTop((int)(0d));
views.get("alblmenu").vw.setLeft((int)((views.get("pnlhost").vw.getLeft() + views.get("pnlhost").vw.getWidth())));
views.get("alblmenu").vw.setWidth((int)((views.get("pnlbg").vw.getLeft() + views.get("pnlbg").vw.getWidth()) - ((views.get("pnlhost").vw.getLeft() + views.get("pnlhost").vw.getWidth()))));
views.get("pnlbottom").vw.setLeft((int)((views.get("pnlhost").vw.getLeft() + views.get("pnlhost").vw.getWidth())));
views.get("pnlbottom").vw.setWidth((int)((views.get("pnlbg").vw.getWidth()) - ((views.get("pnlhost").vw.getLeft() + views.get("pnlhost").vw.getWidth()))));
views.get("pnlbottom").vw.setTop((int)((views.get("alblmenu").vw.getTop() + views.get("alblmenu").vw.getHeight())));
views.get("pnlbottom").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight()) - ((views.get("alblmenu").vw.getTop() + views.get("alblmenu").vw.getHeight()))));
views.get("pnlheater").vw.setLeft((int)(0d));
views.get("pnlheater").vw.setWidth((int)((views.get("pnlbottom").vw.getWidth()) - (0d)));
views.get("pnlheater").vw.setTop((int)(0d));
views.get("pnlheater").vw.setHeight((int)((110d * scale) - (0d)));
views.get("pnlbtns").vw.setLeft((int)(0d));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlbottom").vw.getWidth()) - (0d)));
views.get("pnlbtns").vw.setTop((int)((views.get("pnlheater").vw.getHeight())));
views.get("pnlbtns").vw.setHeight((int)((views.get("pnlbottom").vw.getHeight()) - ((views.get("pnlheater").vw.getHeight()))));
views.get("lblheatertool").vw.setLeft((int)(0d));
views.get("lblheatertool").vw.setWidth((int)((views.get("pnlbtns").vw.getWidth())/2d - (0d)));
views.get("lblheaterbed").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d));
views.get("lblheaterbed").vw.setWidth((int)((views.get("pnlbtns").vw.getWidth()) - ((views.get("pnlbtns").vw.getWidth())/2d)));
views.get("btnpreheat").vw.setTop((int)((views.get("lblheaterbed").vw.getTop() + views.get("lblheaterbed").vw.getHeight())+(4d * scale)));
views.get("btnclose").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btnclose").vw.getWidth() / 2)));
views.get("btn1").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btn1").vw.getWidth() / 2)));
views.get("btn2").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btn2").vw.getWidth() / 2)));
views.get("btnpreheat").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btnpreheat").vw.getWidth() / 2)));
views.get("btnclose").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())-(views.get("btnclose").vw.getHeight())-(4d * scale)));
views.get("btn2").vw.setTop((int)((views.get("btnclose").vw.getTop())-(12d * scale) - (views.get("btn2").vw.getHeight())));
views.get("btn1").vw.setTop((int)((views.get("btn2").vw.getTop())-(4d * scale) - (views.get("btn1").vw.getHeight())));
;}else{ 
;
views.get("pnlbottom").vw.setLeft((int)(0d));
views.get("pnlbottom").vw.setWidth((int)((views.get("pnlbg").vw.getLeft() + views.get("pnlbg").vw.getWidth()) - (0d)));
views.get("pnlbottom").vw.setTop((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(140d * scale)));
views.get("pnlbottom").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight()) - ((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(140d * scale))));
views.get("pnlbtns").vw.setLeft((int)(0d));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlbottom").vw.getLeft() + views.get("pnlbottom").vw.getWidth()) - (0d)));
views.get("pnlbtns").vw.setTop((int)((views.get("pnlbottom").vw.getHeight())/2d));
views.get("pnlbtns").vw.setHeight((int)((views.get("pnlbottom").vw.getHeight()) - ((views.get("pnlbottom").vw.getHeight())/2d)));
views.get("pnlheater").vw.setLeft((int)(0d));
views.get("pnlheater").vw.setWidth((int)((views.get("pnlbottom").vw.getLeft() + views.get("pnlbottom").vw.getWidth()) - (0d)));
views.get("pnlheater").vw.setTop((int)(0d));
views.get("pnlheater").vw.setHeight((int)((views.get("pnlbottom").vw.getHeight())/2d - (0d)));
views.get("btnpreheat").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btnpreheat").vw.setLeft((int)((views.get("btn1").vw.getLeft())));
views.get("lblheatertool").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("lblheaterbed").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("lblheatertool").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("lblheatertool").vw.getWidth())));
views.get("lblheaterbed").vw.setLeft((int)((views.get("lblheatertool").vw.getLeft())-(10d * scale) - (views.get("lblheaterbed").vw.getWidth())));
views.get("btnclose").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btn1").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btn2").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btnclose").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnclose").vw.getWidth())));
views.get("btnclose").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnclose").vw.getHeight() / 2)));
views.get("btn1").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btn1").vw.getHeight() / 2)));
views.get("btn2").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btn2").vw.getHeight() / 2)));
views.get("btnpreheat").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnpreheat").vw.getHeight() / 2)));
views.get("lblheatertool").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("lblheatertool").vw.getHeight() / 2)));
views.get("lblheaterbed").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("lblheaterbed").vw.getHeight() / 2)));
_pad = BA.NumberToString((6d * scale));
views.get("pnlhost").vw.setTop((int)((views.get("alblheader").vw.getTop() + views.get("alblheader").vw.getHeight())));
views.get("pnlhost").vw.setHeight((int)((views.get("pnlbottom").vw.getTop()) - ((views.get("alblheader").vw.getTop() + views.get("alblheader").vw.getHeight()))));
views.get("pnlhost").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("pnlhost").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())-Double.parseDouble(_pad) - (Double.parseDouble(_pad))));
views.get("alblheader").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("alblheader").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())-Double.parseDouble(_pad) - (Double.parseDouble(_pad))));
;};
views.get("pnlsteps").vw.setLeft((int)((views.get("pnlhost").vw.getLeft())));
views.get("pnlsteps").vw.setWidth((int)((views.get("pnlhost").vw.getLeft() + views.get("pnlhost").vw.getWidth()) - ((views.get("pnlhost").vw.getLeft()))));
views.get("pnlsteps").vw.setTop((int)((views.get("pnlhost").vw.getTop())));
views.get("pnlsteps").vw.setHeight((int)((views.get("pnlhost").vw.getTop() + views.get("pnlhost").vw.getHeight()) - ((views.get("pnlhost").vw.getTop()))));

}
}