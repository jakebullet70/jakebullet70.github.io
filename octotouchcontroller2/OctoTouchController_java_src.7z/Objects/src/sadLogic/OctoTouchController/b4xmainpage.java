package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.mastercontroller _omastercontroller = null;
public sadLogic.OctoTouchController.bctoast _toast = null;
public anywheresoftware.b4a.objects.CSBuilder _cshdr = null;
public String _strtmp = "";
public int _iitmp = 0;
public anywheresoftware.b4a.objects.PanelWrapper _pnlscreenoff = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _ivspash = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlsplash = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblsplash = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmaster = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlheader = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnslidermenu = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpageaction = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblstatus = null;
public Object _opagecurrent = null;
public sadLogic.OctoTouchController.pagemenu _opagemenu = null;
public sadLogic.OctoTouchController.pagefiles _opagefiles = null;
public sadLogic.OctoTouchController.pageprinting _opageprinting = null;
public sadLogic.OctoTouchController.pagemovement _opagemovement = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmovement = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlprinting = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlfiles = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmenu = null;
public boolean _mconnectionerrdlgshowingflag = false;
public boolean _pprintercfgdlgshowingflag = false;
public boolean _promptexittwice = false;
public int _mtoasttxtsize = 0;
public anywheresoftware.b4a.objects.collections.Map _mapmasterpreheatermenu = null;
public sadLogic.OctoTouchController.sadb4xdraweradvancedhelper _sidemenu = null;
public sadLogic.OctoTouchController.sadb4xdraweradvanced _drawer = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnstop = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnfrestart = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnrestart = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtnsdrawer = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmaindrawer = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnllinebreakdrawer = null;
public b4a.example3.customlistview _clvdrawer = null;
public Object _pobjcurrentdlg1 = null;
public Object _pobjcurrentdlg2 = null;
public sadLogic.OctoTouchController.dlglistbox _pobjpreheatdlg1 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlwizards = null;
public sadLogic.OctoTouchController.dlgfilamentsetup _pdlgfilsetup = null;
public Object _pobjwizards = null;
public sadLogic.OctoTouchController.dlgoctosetup _pdlgprintersetup = null;
public sadLogic.OctoTouchController.dlgmsgbox _merrordlg = null;
public sadLogic.OctoTouchController.dlgmsgbox2 _pmbox2 = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _b4apage_disappear() throws Exception{
 //BA.debugLineNum = 243;BA.debugLine="Private Sub B4APage_Disappear";
 //BA.debugLineNum = 244;BA.debugLine="Log(\"B4APage_Disappear\")";
__c.LogImpl("4521985","B4APage_Disappear",0);
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_appear() throws Exception{
 //BA.debugLineNum = 239;BA.debugLine="Private Sub B4XPage_Appear";
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_background() throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Private Sub B4XPage_Background";
 //BA.debugLineNum = 254;BA.debugLine="CallSub2(Main,\"TurnOnOff_MainTmr\",False)";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"TurnOnOff_MainTmr",(Object)(__c.False));
 //BA.debugLineNum = 255;BA.debugLine="CallSub2(Main,\"TurnOnOff_ScreenTmr\",False)";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"TurnOnOff_ScreenTmr",(Object)(__c.False));
 //BA.debugLineNum = 256;BA.debugLine="Log(\"B4XPage_Background - timers off\")";
__c.LogImpl("4653059","B4XPage_Background - timers off",0);
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _b4xpage_closerequest() throws Exception{
ResumableSub_B4XPage_CloseRequest rsub = new ResumableSub_B4XPage_CloseRequest(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_B4XPage_CloseRequest extends BA.ResumableSub {
public ResumableSub_B4XPage_CloseRequest(sadLogic.OctoTouchController.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 149;BA.debugLine="logMe.LogDebug2(\"B4XPage_CloseRequest\",mModule)";
parent._logme._logdebug2 /*String*/ (ba,"B4XPage_CloseRequest",parent._mmodule);
 //BA.debugLineNum = 154;BA.debugLine="If Drawer.RightOpen Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._drawer._getrightopen /*boolean*/ ()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 155;BA.debugLine="Drawer.RightOpen = False";
parent._drawer._setrightopen /*boolean*/ (parent.__c.False);
 //BA.debugLineNum = 156;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 159;BA.debugLine="If mConnectionErrDlgShowingFLAG Then";

case 4:
//if
this.state = 7;
if (parent._mconnectionerrdlgshowingflag) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 160;BA.debugLine="CallSubDelayed(mErrorDlg,\"Close_Me\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._merrordlg),"Close_Me");
 //BA.debugLineNum = 161;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 163;BA.debugLine="If pPrinterCfgDlgShowingFLAG Then";

case 7:
//if
this.state = 10;
if (parent._pprintercfgdlgshowingflag) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 164;BA.debugLine="CallSubDelayed(pDlgPrinterSetup,\"Close_Me\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._pdlgprintersetup),"Close_Me");
 //BA.debugLineNum = 165;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 168;BA.debugLine="If pDlgFilSetup.IsInitialized And pDlgFilSetup.pP";

case 10:
//if
this.state = 13;
if (parent._pdlgfilsetup.IsInitialized /*boolean*/ () && parent._pdlgfilsetup._pprefdlg /*sadLogic.OctoTouchController.sadpreferencesdialog*/ ._dialog /*sadLogic.OctoTouchController.b4xdialog*/ ._getvisible /*boolean*/ ()) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 169;BA.debugLine="CallSubDelayed(pDlgFilSetup,\"Close_Me\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._pdlgfilsetup),"Close_Me");
 //BA.debugLineNum = 170;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 173;BA.debugLine="If pMBox2.IsInitialized And pMBox2.Visible Then";

case 13:
//if
this.state = 16;
if (parent._pmbox2.IsInitialized /*boolean*/ () && parent._pmbox2._getvisible /*boolean*/ ()) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 174;BA.debugLine="CallSubDelayed(pMBox2,\"Close_Me\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._pmbox2),"Close_Me");
 //BA.debugLineNum = 175;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 178;BA.debugLine="If pObjPreHeatDlg1 <> Null And SubExists(pObjPreH";

case 16:
//if
this.state = 25;
if (parent._pobjpreheatdlg1!= null && parent.__c.SubExists(ba,(Object)(parent._pobjpreheatdlg1),"Close_Me")) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 179;BA.debugLine="CallSubDelayed(pObjPreHeatDlg1,\"Close_Me\") 'igno";
parent.__c.CallSubDelayed(ba,(Object)(parent._pobjpreheatdlg1),"Close_Me");
 //BA.debugLineNum = 180;BA.debugLine="pObjPreHeatDlg1 = Null";
parent._pobjpreheatdlg1 = (sadLogic.OctoTouchController.dlglistbox)(parent.__c.Null);
 //BA.debugLineNum = 181;BA.debugLine="If oPageCurrent = oPageMovement Then pObjCurrent";
if (true) break;

case 19:
//if
this.state = 24;
if ((parent._opagecurrent).equals((Object)(parent._opagemovement))) { 
this.state = 21;
;}if (true) break;

case 21:
//C
this.state = 24;
parent._pobjcurrentdlg1 = parent.__c.Null;
if (true) break;

case 24:
//C
this.state = 25;
;
 //BA.debugLineNum = 182;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 186;BA.debugLine="If (pObjWizards <> Null) And SubExists(pObjWizard";

case 25:
//if
this.state = 28;
if ((parent._pobjwizards!= null) && parent.__c.SubExists(ba,parent._pobjwizards,"Close_Me")) { 
this.state = 27;
}if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 187;BA.debugLine="CallSubDelayed(pObjWizards,\"Close_Me\") 'ignore";
parent.__c.CallSubDelayed(ba,parent._pobjwizards,"Close_Me");
 //BA.debugLineNum = 188;BA.debugLine="pObjWizards = Null";
parent._pobjwizards = parent.__c.Null;
 //BA.debugLineNum = 189;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 195;BA.debugLine="If pObjCurrentDlg2 <> Null And SubExists(pObjCurr";

case 28:
//if
this.state = 31;
if (parent._pobjcurrentdlg2!= null && parent.__c.SubExists(ba,parent._pobjcurrentdlg2,"Close_Me")) { 
this.state = 30;
}if (true) break;

case 30:
//C
this.state = 31;
 //BA.debugLineNum = 196;BA.debugLine="Log(\"maybe i will log something - closing pObjCu";
parent.__c.LogImpl("4390960","maybe i will log something - closing pObjCurrentDlg2",0);
 //BA.debugLineNum = 197;BA.debugLine="CallSubDelayed(pObjCurrentDlg2,\"Close_Me\") 'igno";
parent.__c.CallSubDelayed(ba,parent._pobjcurrentdlg2,"Close_Me");
 //BA.debugLineNum = 198;BA.debugLine="pObjCurrentDlg2 = Null";
parent._pobjcurrentdlg2 = parent.__c.Null;
 //BA.debugLineNum = 199;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 201;BA.debugLine="If pObjCurrentDlg1 <> Null And SubExists(pObjCurr";

case 31:
//if
this.state = 34;
if (parent._pobjcurrentdlg1!= null && parent.__c.SubExists(ba,parent._pobjcurrentdlg1,"Close_Me")) { 
this.state = 33;
}if (true) break;

case 33:
//C
this.state = 34;
 //BA.debugLineNum = 202;BA.debugLine="Log(\"maybe i will log something - closing pObjCu";
parent.__c.LogImpl("4390966","maybe i will log something - closing pObjCurrentDlg1",0);
 //BA.debugLineNum = 203;BA.debugLine="CallSubDelayed(pObjCurrentDlg1,\"Close_Me\") 'igno";
parent.__c.CallSubDelayed(ba,parent._pobjcurrentdlg1,"Close_Me");
 //BA.debugLineNum = 204;BA.debugLine="pObjCurrentDlg1 = Null";
parent._pobjcurrentdlg1 = parent.__c.Null;
 //BA.debugLineNum = 205;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 211;BA.debugLine="If oPageCurrent <> oPageMenu Then";

case 34:
//if
this.state = 37;
if ((parent._opagecurrent).equals((Object)(parent._opagemenu)) == false) { 
this.state = 36;
}if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 212;BA.debugLine="Switch_Pages(gblConst.PAGE_MENU)";
parent._switch_pages(parent._gblconst._page_menu /*String*/ );
 //BA.debugLineNum = 213;BA.debugLine="Return False '--- cancel close request";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 216;BA.debugLine="If PromptExitTwice = False Then";

case 37:
//if
this.state = 40;
if (parent._promptexittwice==parent.__c.False) { 
this.state = 39;
}if (true) break;

case 39:
//C
this.state = 40;
 //BA.debugLineNum = 217;BA.debugLine="Show_toast(\"Tap again to exit\",2200)";
parent._show_toast("Tap again to exit",(int) (2200));
 //BA.debugLineNum = 218;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Prom";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Prompt_Exit_Reset",(int) (2200));
 //BA.debugLineNum = 219;BA.debugLine="PromptExitTwice = True";
parent._promptexittwice = parent.__c.True;
 //BA.debugLineNum = 220;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 40:
//C
this.state = -1;
;
 //BA.debugLineNum = 223;BA.debugLine="powerHelpers.ReleaseLocks";
parent._powerhelpers._releaselocks /*String*/ (ba);
 //BA.debugLineNum = 225;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 226;BA.debugLine="CallSub2(Main,\"TurnOnOff_MainTmr\",False)";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"TurnOnOff_MainTmr",(Object)(parent.__c.False));
 //BA.debugLineNum = 227;BA.debugLine="Main.isAppClosing = True";
parent._main._isappclosing /*boolean*/  = parent.__c.True;
 //BA.debugLineNum = 228;BA.debugLine="guiHelpers.Show_toast(\"Shutting down...\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"Shutting down...",(int) (2000));
 //BA.debugLineNum = 229;BA.debugLine="oMasterController.oWS.wSocket.Close : Sleep(1500)";
parent._omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._wsocket /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .Close();
 //BA.debugLineNum = 229;BA.debugLine="oMasterController.oWS.wSocket.Close : Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 41;
return;
case 41:
//C
this.state = -1;
;
 //BA.debugLineNum = 233;BA.debugLine="B4XPages.GetNativeParent(Me).Finish";
parent._b4xpages._getnativeparent /*anywheresoftware.b4a.objects.ActivityWrapper*/ (ba,parent).Finish();
 //BA.debugLineNum = 235;BA.debugLine="Return True '--- exit app";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 237;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 111;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 112;BA.debugLine="Root.SetLayoutAnimated(0,0,0,Root.Width,Root.Heig";
_root.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_root.getWidth(),_root.getHeight());
 //BA.debugLineNum = 115;BA.debugLine="SideMenu.Initialize(Drawer)";
_sidemenu._initialize /*String*/ (ba,_drawer);
 //BA.debugLineNum = 116;BA.debugLine="Drawer.Initialize(SideMenu, \"mnuPanel\", Root, 260";
_drawer._initialize /*String*/ (ba,(Object)(_sidemenu),"mnuPanel",_root,__c.DipToCurrent((int) (260)));
 //BA.debugLineNum = 117;BA.debugLine="Drawer.CenterPanel.LoadLayout(\"MainPage2\")";
_drawer._getcenterpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().LoadLayout("MainPage2",ba);
 //BA.debugLineNum = 118;BA.debugLine="Drawer.RightPanel.LoadLayout(\"viewSlidingWindow\")";
_drawer._getrightpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().LoadLayout("viewSlidingWindow",ba);
 //BA.debugLineNum = 119;BA.debugLine="Drawer.RightPanelEnabled = True";
_drawer._setrightpanelenabled /*boolean*/ (__c.True);
 //BA.debugLineNum = 120;BA.debugLine="Drawer.LeftPanelEnabled = False";
_drawer._setleftpanelenabled /*boolean*/ (__c.False);
 //BA.debugLineNum = 122;BA.debugLine="toast.Initialize(Root)";
_toast._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 123;BA.debugLine="toast.pnl.Color = clrTheme.txtNormal";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 124;BA.debugLine="toast.DefaultTextColor = clrTheme.Background";
_toast._defaulttextcolor /*int*/  = _clrtheme._background /*int*/ ;
 //BA.debugLineNum = 125;BA.debugLine="toast.MaxHeight = 120dip";
_toast._maxheight /*int*/  = __c.DipToCurrent((int) (120));
 //BA.debugLineNum = 129;BA.debugLine="LoadSplashPic";
_loadsplashpic();
 //BA.debugLineNum = 130;BA.debugLine="pnlMaster.Visible = False";
_pnlmaster.setVisible(__c.False);
 //BA.debugLineNum = 131;BA.debugLine="pnlSplash.Visible = True";
_pnlsplash.setVisible(__c.True);
 //BA.debugLineNum = 136;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 138;BA.debugLine="TryPrinterConnection";
_tryprinterconnection();
 //BA.debugLineNum = 141;BA.debugLine="logMe.LogIt(\"Legacy\",\"\")";
_logme._logit /*String*/ (ba,"Legacy","");
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_foreground() throws Exception{
 //BA.debugLineNum = 247;BA.debugLine="Private Sub B4XPage_Foreground";
 //BA.debugLineNum = 248;BA.debugLine="CallSub(oPageCurrent,\"Set_Focus\")";
__c.CallSubNew(ba,_opagecurrent,"Set_Focus");
 //BA.debugLineNum = 249;BA.debugLine="If oc.isConnected Then CallSub2(Main,\"TurnOnOff_M";
if (_oc._isconnected /*boolean*/ ) { 
__c.CallSubNew2(ba,(Object)(_main.getObject()),"TurnOnOff_MainTmr",(Object)(__c.True));};
 //BA.debugLineNum = 250;BA.debugLine="Log(\"B4XPage_Foreground - calling Set_Focus, main";
__c.LogImpl("4587523","B4XPage_Foreground - calling Set_Focus, main tmr on",0);
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return "";
}
public String  _btnpageaction_click() throws Exception{
 //BA.debugLineNum = 431;BA.debugLine="Public Sub btnPageAction_Click";
 //BA.debugLineNum = 432;BA.debugLine="If oPageCurrent = oPageMenu Then";
if ((_opagecurrent).equals((Object)(_opagemenu))) { 
 //BA.debugLineNum = 433;BA.debugLine="PopupMainOptionMenu";
_popupmainoptionmenu();
 }else {
 //BA.debugLineNum = 435;BA.debugLine="Switch_Pages(gblConst.PAGE_MENU) '--- back key,";
_switch_pages(_gblconst._page_menu /*String*/ );
 };
 //BA.debugLineNum = 437;BA.debugLine="End Sub";
return "";
}
public String  _btnsidepnl_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
 //BA.debugLineNum = 998;BA.debugLine="Public Sub btnSidePnl_Click";
 //BA.debugLineNum = 999;BA.debugLine="Dim b As Button : b = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 999;BA.debugLine="Dim b As Button : b = Sender";
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 1000;BA.debugLine="SideMenu.BtnPressed(b)";
_sidemenu._btnpressed /*void*/ (_b);
 //BA.debugLineNum = 1001;BA.debugLine="End Sub";
return "";
}
public String  _btnslidermenu_click() throws Exception{
 //BA.debugLineNum = 1003;BA.debugLine="Private Sub btnSliderMenu_Click";
 //BA.debugLineNum = 1005;BA.debugLine="SideMenu.OpenRightMenu";
_sidemenu._openrightmenu /*String*/ ();
 //BA.debugLineNum = 1006;BA.debugLine="CallSubDelayed(SideMenu,\"Display_Btns\")";
__c.CallSubDelayed(ba,(Object)(_sidemenu),"Display_Btns");
 //BA.debugLineNum = 1007;BA.debugLine="End Sub";
return "";
}
public String  _build_rightsidemenu() throws Exception{
float _size = 0f;
Object _txt = null;
anywheresoftware.b4a.objects.collections.Map _datamap = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.collections.Map _datamapg = null;
 //BA.debugLineNum = 1010;BA.debugLine="Private Sub Build_RightSideMenu";
 //BA.debugLineNum = 1014;BA.debugLine="Log(\"Build_RightSideMenu\")";
__c.LogImpl("6750212","Build_RightSideMenu",0);
 //BA.debugLineNum = 1016;BA.debugLine="clvDrawer.Clear";
_clvdrawer._clear();
 //BA.debugLineNum = 1017;BA.debugLine="If oc.IsKlippyConnected = False Then Return";
if (_oc._isklippyconnected /*boolean*/ (ba)==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 1018;BA.debugLine="Dim size As Float = IIf(guiHelpers.gIsLandScape,2";
_size = (float)(BA.ObjectToNumber(((_guihelpers._gislandscape /*boolean*/ ) ? ((Object)(20)) : ((Object)(22)))));
 //BA.debugLineNum = 1019;BA.debugLine="Dim txt As Object, dataMap As Map";
_txt = new Object();
_datamap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 1020;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 1022;BA.debugLine="Dim dataMapG As Map = File.ReadMap(xui.DefaultFol";
_datamapg = new anywheresoftware.b4a.objects.collections.Map();
_datamapg = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._general_options_file /*String*/ );
 //BA.debugLineNum = 1028;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).Ap";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("Filament Cooling Menu")).PopAll().getObject()),(Object)("fcm"));
 //BA.debugLineNum = 1030;BA.debugLine="If dataMapG.GetDefault(\"m600\",False).As(Boolean)";
if ((BA.ObjectToBoolean(_datamapg.GetDefault((Object)("m600"),(Object)(__c.False))))) { 
 //BA.debugLineNum = 1031;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("Filament Change M600")).PopAll().getObject()),(Object)("m600"));
 };
 //BA.debugLineNum = 1034;BA.debugLine="If (oPageFiles.IsInitialized) And (oPageCurrent =";
if ((_opagefiles.IsInitialized /*boolean*/ ()) && ((_opagecurrent).equals((Object)(_opagefiles)))) { 
 //BA.debugLineNum = 1035;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("Force Refresh Of Files")).PopAll().getObject()),(Object)("refl"));
 };
 //BA.debugLineNum = 1040;BA.debugLine="For iiTMP = 0 To 7";
{
final int step15 = 1;
final int limit15 = (int) (7);
_iitmp = (int) (0) ;
for (;_iitmp <= limit15 ;_iitmp = _iitmp + step15 ) {
 //BA.debugLineNum = 1041;BA.debugLine="strTMP = iiTMP & gblConst.GCODE_CUSTOM_SETUP_FIL";
_strtmp = BA.NumberToString(_iitmp)+_gblconst._gcode_custom_setup_file /*String*/ ;
 //BA.debugLineNum = 1042;BA.debugLine="dataMap = File.ReadMap(xui.DefaultFolder,strTMP)";
_datamap = __c.File.ReadMap(_xui.getDefaultFolder(),_strtmp);
 //BA.debugLineNum = 1043;BA.debugLine="If dataMap.GetDefault(\"rmenu\",False).As(Boolean)";
if ((BA.ObjectToBoolean(_datamap.GetDefault((Object)("rmenu"),(Object)(__c.False))))==__c.True) { 
 //BA.debugLineNum = 1044;BA.debugLine="txt = dataMap.Get(\"desc\")";
_txt = _datamap.Get((Object)("desc"));
 //BA.debugLineNum = 1045;BA.debugLine="If strHelpers.IsNullOrEmpty(txt) Then";
if (_strhelpers._isnullorempty /*boolean*/ (ba,BA.ObjectToString(_txt))) { 
 //BA.debugLineNum = 1046;BA.debugLine="txt = \"GCode \" & iiTMP & \"Menu\"";
_txt = (Object)("GCode "+BA.NumberToString(_iitmp)+"Menu");
 };
 //BA.debugLineNum = 1048;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("g"+BA.NumberToString(_iitmp)));
 };
 }
};
 //BA.debugLineNum = 1053;BA.debugLine="For iiTMP = 1 To 8";
{
final int step26 = 1;
final int limit26 = (int) (8);
_iitmp = (int) (1) ;
for (;_iitmp <= limit26 ;_iitmp = _iitmp + step26 ) {
 //BA.debugLineNum = 1054;BA.debugLine="strTMP = iiTMP & gblConst.HTTP_ONOFF_SETUP_FILE";
_strtmp = BA.NumberToString(_iitmp)+_gblconst._http_onoff_setup_file /*String*/ ;
 //BA.debugLineNum = 1055;BA.debugLine="If File.Exists(xui.DefaultFolder,strTMP) = True";
if (__c.File.Exists(_xui.getDefaultFolder(),_strtmp)==__c.True) { 
 //BA.debugLineNum = 1056;BA.debugLine="dataMap  = File.ReadMap(xui.DefaultFolder,strTM";
_datamap = __c.File.ReadMap(_xui.getDefaultFolder(),_strtmp);
 //BA.debugLineNum = 1057;BA.debugLine="If dataMap.GetDefault(\"active\",False).As(Boolea";
if ((BA.ObjectToBoolean(_datamap.GetDefault((Object)("active"),(Object)(__c.False))))==__c.True) { 
 //BA.debugLineNum = 1058;BA.debugLine="txt = dataMap.Get(\"desc\")";
_txt = _datamap.Get((Object)("desc"));
 //BA.debugLineNum = 1059;BA.debugLine="If strHelpers.IsNullOrEmpty(txt) Then";
if (_strhelpers._isnullorempty /*boolean*/ (ba,BA.ObjectToString(_txt))) { 
 //BA.debugLineNum = 1060;BA.debugLine="txt = \"HTTP \" & iiTMP & \"Menu\"";
_txt = (Object)("HTTP "+BA.NumberToString(_iitmp)+"Menu");
 };
 //BA.debugLineNum = 1062;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size)";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)(_iitmp));
 };
 };
 }
};
 //BA.debugLineNum = 1067;BA.debugLine="If config.ReadPwrCfgFLAG Then";
if (_config._readpwrcfgflag /*boolean*/ (ba)) { 
 //BA.debugLineNum = 1068;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("Printer Power Menu")).PopAll().getObject()),(Object)("pwr"));
 };
 //BA.debugLineNum = 1071;BA.debugLine="If dataMapG.GetDefault(\"syscmds\",False).As(Boolea";
if ((BA.ObjectToBoolean(_datamapg.GetDefault((Object)("syscmds"),(Object)(__c.False))))) { 
 //BA.debugLineNum = 1072;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("OS Systems Menu")).PopAll().getObject()),(Object)("sys"));
 };
 //BA.debugLineNum = 1075;BA.debugLine="If oc.Klippy And oc.IsKlippyConnected Then";
if (_oc._klippy /*boolean*/  && _oc._isklippyconnected /*boolean*/ (ba)) { 
 //BA.debugLineNum = 1077;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("Klipper Full Restart")).PopAll().getObject()),(Object)("kst"));
 };
 //BA.debugLineNum = 1080;BA.debugLine="If clvDrawer.Size = 0 Then '--- nothing in the me";
if (_clvdrawer._getsize()==0) { 
 //BA.debugLineNum = 1081;BA.debugLine="clvDrawer.AddTextItem(cs.Initialize.Size(size).A";
_clvdrawer._addtextitem((Object)(_cs.Initialize().Size((int) (_size)).Append(BA.ObjectToCharSequence("About This Program")).PopAll().getObject()),(Object)("ab"));
 };
 //BA.debugLineNum = 1084;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
float _bs = 0f;
 //BA.debugLineNum = 261;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 263;BA.debugLine="pnlMaster.Color  = clrTheme.Background";
_pnlmaster.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 264;BA.debugLine="pnlHeader.Color = clrTheme.BackgroundHeader";
_pnlheader.setColor(_clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 267;BA.debugLine="guiHelpers.HidePageParentObjs(Array As B4XView(pn";
_guihelpers._hidepageparentobjs /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_pnlmenu,_pnlfiles,_pnlmovement,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlwizards.getObject()))});
 //BA.debugLineNum = 268;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblStatu";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblstatus.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnslidermenu.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnpageaction.getObject()))});
 //BA.debugLineNum = 270;BA.debugLine="guiHelpers.SkinButton_Pugin(Array As Button(btnSl";
_guihelpers._skinbutton_pugin /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnslidermenu,_btnpageaction});
 //BA.debugLineNum = 271;BA.debugLine="Dim bs As Float = 35";
_bs = (float) (35);
 //BA.debugLineNum = 272;BA.debugLine="If guiHelpers.gIsLandScape Then bs = 24";
if (_guihelpers._gislandscape /*boolean*/ ) { 
_bs = (float) (24);};
 //BA.debugLineNum = 273;BA.debugLine="btnSliderMenu.TextSize = bs";
_btnslidermenu.setTextSize(_bs);
 //BA.debugLineNum = 274;BA.debugLine="btnPageAction.TextSize = bs";
_btnpageaction.setTextSize(_bs);
 //BA.debugLineNum = 276;BA.debugLine="pnlMainDrawer.Color = clrTheme.Background2";
_pnlmaindrawer.setColor(_clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 277;BA.debugLine="SideMenu.SkinMe(Array As Button(btnSTOP,btnFRESTA";
_sidemenu._skinme /*String*/ (new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnstop,_btnfrestart,_btnrestart},_pnlmaindrawer,_pnlbtnsdrawer);
 //BA.debugLineNum = 278;BA.debugLine="pnlLineBreakDrawer.Color = clrTheme.txtNormal";
_pnllinebreakdrawer.setColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 279;BA.debugLine="btnFRESTART.Visible = False : 	btnRESTART.Visible";
_btnfrestart.setVisible(__c.False);
 //BA.debugLineNum = 279;BA.debugLine="btnFRESTART.Visible = False : 	btnRESTART.Visible";
_btnrestart.setVisible(__c.False);
 //BA.debugLineNum = 279;BA.debugLine="btnFRESTART.Visible = False : 	btnRESTART.Visible";
_btnstop.setVisible(__c.True);
 //BA.debugLineNum = 282;BA.debugLine="clvDrawer.DefaultTextBackgroundColor = clrTheme.B";
_clvdrawer._defaulttextbackgroundcolor = _clrtheme._background /*int*/ ;
 //BA.debugLineNum = 283;BA.debugLine="clvDrawer.PressedColor = clrTheme.BackgroundHeade";
_clvdrawer._pressedcolor = _clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 284;BA.debugLine="clvDrawer.DefaultTextColor = clrTheme.txtNormal";
_clvdrawer._defaulttextcolor = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 285;BA.debugLine="Build_RightSideMenu";
_build_rightsidemenu();
 //BA.debugLineNum = 287;BA.debugLine="Switch_Pages(gblConst.PAGE_MENU)";
_switch_pages(_gblconst._page_menu /*String*/ );
 //BA.debugLineNum = 288;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(_main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 290;BA.debugLine="End Sub";
return "";
}
public String  _buildpreheatmenu() throws Exception{
anywheresoftware.b4a.objects.collections.Map _mtmp = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
 //BA.debugLineNum = 874;BA.debugLine="Private Sub BuildPreHeatMenu";
 //BA.debugLineNum = 876;BA.debugLine="If mapMasterPreHeaterMenu.IsInitialized Then Retu";
if (_mapmasterpreheatermenu.IsInitialized()) { 
if (true) return "";};
 //BA.debugLineNum = 879;BA.debugLine="Dim mTmp As Map = objHelpers.ConcatMaps(Array As";
_mtmp = new anywheresoftware.b4a.objects.collections.Map();
_mtmp = _objhelpers._concatmaps /*anywheresoftware.b4a.objects.collections.Map*/ (ba,new anywheresoftware.b4a.objects.collections.Map[]{_omastercontroller._mapallheatingoptions /*anywheresoftware.b4a.objects.collections.Map*/ ,_omastercontroller._maptoolheatingoptions /*anywheresoftware.b4a.objects.collections.Map*/ });
 //BA.debugLineNum = 883;BA.debugLine="Dim m1 As Map : m1.Initialize : m1.Put(\"Enter Too";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 883;BA.debugLine="Dim m1 As Map : m1.Initialize : m1.Put(\"Enter Too";
_m1.Initialize();
 //BA.debugLineNum = 883;BA.debugLine="Dim m1 As Map : m1.Initialize : m1.Put(\"Enter Too";
_m1.Put((Object)("Enter Tool Value"),(Object)("evt"));
 //BA.debugLineNum = 884;BA.debugLine="mapMasterPreHeaterMenu = objHelpers.ConcatMaps(Ar";
_mapmasterpreheatermenu = _objhelpers._concatmaps /*anywheresoftware.b4a.objects.collections.Map*/ (ba,new anywheresoftware.b4a.objects.collections.Map[]{_mtmp,_m1,_omastercontroller._mapbedheatingoptions /*anywheresoftware.b4a.objects.collections.Map*/ });
 //BA.debugLineNum = 885;BA.debugLine="mapMasterPreHeaterMenu.Put(\"Enter Bed Value\",\"evb";
_mapmasterpreheatermenu.Put((Object)("Enter Bed Value"),(Object)("evb"));
 //BA.debugLineNum = 887;BA.debugLine="End Sub";
return "";
}
public void  _callsetuperrorconnecting(boolean _connectedbuterror) throws Exception{
ResumableSub_CallSetupErrorConnecting rsub = new ResumableSub_CallSetupErrorConnecting(this,_connectedbuterror);
rsub.resume(ba, null);
}
public static class ResumableSub_CallSetupErrorConnecting extends BA.ResumableSub {
public ResumableSub_CallSetupErrorConnecting(sadLogic.OctoTouchController.b4xmainpage parent,boolean _connectedbuterror) {
this.parent = parent;
this._connectedbuterror = _connectedbuterror;
}
sadLogic.OctoTouchController.b4xmainpage parent;
boolean _connectedbuterror;
String _powerctrlavail = "";
boolean _justify_button_2_left = false;
float _h = 0f;
float _w = 0f;
sadLogic.OctoTouchController.guimsgs _gui = null;
int _res = 0;
sadLogic.OctoTouchController.dlgoctopsuctrl _o = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 739;BA.debugLine="If mConnectionErrDlgShowingFLAG Or pPrinterCfgDlg";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._mconnectionerrdlgshowingflag || parent._pprintercfgdlgshowingflag) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 740;BA.debugLine="mConnectionErrDlgShowingFLAG = True";
parent._mconnectionerrdlgshowingflag = parent.__c.True;
 //BA.debugLineNum = 741;BA.debugLine="Log(\"starting error setup cfg\")";
parent.__c.LogImpl("5898244","starting error setup cfg",0);
 //BA.debugLineNum = 744;BA.debugLine="CallSub2(Main,\"TurnOnOff_MainTmr\",False)";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"TurnOnOff_MainTmr",(Object)(parent.__c.False));
 //BA.debugLineNum = 748;BA.debugLine="If oPageCurrent <> oPageMenu Then Switch_Pages(gb";
if (true) break;

case 7:
//if
this.state = 12;
if ((parent._opagecurrent).equals((Object)(parent._opagemenu)) == false) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
parent._switch_pages(parent._gblconst._page_menu /*String*/ );
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 750;BA.debugLine="If pnlScreenOff.Visible = True Then";
if (true) break;

case 13:
//if
this.state = 16;
if (parent._pnlscreenoff.getVisible()==parent.__c.True) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 751;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Scre";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"ScreenOff_2Front",(int) (600));
 if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 757;BA.debugLine="Dim PowerCtrlAvail As String = \"\"";
_powerctrlavail = "";
 //BA.debugLineNum = 758;BA.debugLine="If Main.kvs.GetDefault(gblConst.PWR_SONOFF_PLUGIN";
if (true) break;

case 17:
//if
this.state = 20;
if ((BA.ObjectToBoolean(parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._getdefault /*Object*/ (parent._gblconst._pwr_sonoff_plugin /*String*/ ,(Object)(parent.__c.False))))==parent.__c.True) { 
this.state = 19;
}if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 759;BA.debugLine="PowerCtrlAvail = \"POWER\"";
_powerctrlavail = "POWER";
 if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 763;BA.debugLine="Dim Const JUSTIFY_BUTTON_2_LEFT As Boolean = True";
_justify_button_2_left = parent.__c.True;
 //BA.debugLineNum = 764;BA.debugLine="Dim h,w As Float";
_h = 0f;
_w = 0f;
 //BA.debugLineNum = 765;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 21:
//if
this.state = 26;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 23;
}else {
this.state = 25;
}if (true) break;

case 23:
//C
this.state = 26;
 //BA.debugLineNum = 766;BA.debugLine="h = guiHelpers.MaxVerticalHeight_Landscape";
_h = parent._guihelpers._maxverticalheight_landscape /*float*/ (ba);
 //BA.debugLineNum = 767;BA.debugLine="w = 500dip";
_w = (float) (parent.__c.DipToCurrent((int) (500)));
 if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 769;BA.debugLine="h = 310dip : w = 88%x";
_h = (float) (parent.__c.DipToCurrent((int) (310)));
 //BA.debugLineNum = 769;BA.debugLine="h = 310dip : w = 88%x";
_w = (float) (parent.__c.PerXToCurrent((float) (88),ba));
 if (true) break;

case 26:
//C
this.state = 27;
;
 //BA.debugLineNum = 771;BA.debugLine="mErrorDlg.Initialize(Root,\"Connetion Problem\", w,";
parent._merrordlg._initialize /*String*/ (ba,parent._root,"Connetion Problem",_w,_h,_justify_button_2_left);
 //BA.debugLineNum = 772;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 772;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 773;BA.debugLine="Wait For (mErrorDlg.Show(gui.GetConnectionText(co";
parent.__c.WaitFor("complete", ba, this, parent._merrordlg._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_gui._getconnectiontext /*String*/ (_connectedbuterror),parent._gblconst._mb_icon_warning /*String*/ ,"RETRY",_powerctrlavail,"SETUP"));
this.state = 35;
return;
case 35:
//C
this.state = 27;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 776;BA.debugLine="Select Case res";
if (true) break;

case 27:
//select
this.state = 34;
switch (BA.switchObjectToInt(_res,parent._xui.DialogResponse_Positive,parent._xui.DialogResponse_Cancel,parent._xui.DialogResponse_Negative)) {
case 0: {
this.state = 29;
if (true) break;
}
case 1: {
this.state = 31;
if (true) break;
}
case 2: {
this.state = 33;
if (true) break;
}
}
if (true) break;

case 29:
//C
this.state = 34;
 //BA.debugLineNum = 778;BA.debugLine="Show_toast(\"Retrying connection...\",1300)";
parent._show_toast("Retrying connection...",(int) (1300));
 //BA.debugLineNum = 779;BA.debugLine="oMasterController.Start";
parent._omastercontroller._start /*String*/ ();
 if (true) break;

case 31:
//C
this.state = 34;
 //BA.debugLineNum = 782;BA.debugLine="mConnectionErrDlgShowingFLAG = False";
parent._mconnectionerrdlgshowingflag = parent.__c.False;
 //BA.debugLineNum = 783;BA.debugLine="OptionsMenu_Event(\"oc\",\"oc\")";
parent._optionsmenu_event("oc",(Object)("oc"));
 if (true) break;

case 33:
//C
this.state = 34;
 //BA.debugLineNum = 786;BA.debugLine="Dim o As dlgOctoPsuCtrl : o.Initialize(Me)";
_o = new sadLogic.OctoTouchController.dlgoctopsuctrl();
 //BA.debugLineNum = 786;BA.debugLine="Dim o As dlgOctoPsuCtrl : o.Initialize(Me)";
_o._initialize /*Object*/ (ba,(sadLogic.OctoTouchController.b4xmainpage)(parent));
 //BA.debugLineNum = 787;BA.debugLine="o.mRunMasterCtrlrStart = True";
_o._mrunmasterctrlrstart /*boolean*/  = parent.__c.True;
 //BA.debugLineNum = 788;BA.debugLine="o.Show";
_o._show /*void*/ ();
 if (true) break;

case 34:
//C
this.state = -1;
;
 //BA.debugLineNum = 792;BA.debugLine="CfgAndroidPowerOptions";
parent._cfgandroidpoweroptions();
 //BA.debugLineNum = 793;BA.debugLine="mConnectionErrDlgShowingFLAG = False";
parent._mconnectionerrdlgshowingflag = parent.__c.False;
 //BA.debugLineNum = 794;BA.debugLine="Log(\"exiting error connecting setup cfg\")";
parent.__c.LogImpl("5898297","exiting error connecting setup cfg",0);
 //BA.debugLineNum = 796;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public String  _cfgandroidpoweroptions() throws Exception{
 //BA.debugLineNum = 802;BA.debugLine="Private Sub CfgAndroidPowerOptions";
 //BA.debugLineNum = 804;BA.debugLine="If config.AndroidTakeOverSleepFLAG = False Then";
if (_config._androidtakeoversleepflag /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 805;BA.debugLine="powerHelpers.ScreenON(False) '--- power options";
_powerhelpers._screenon /*String*/ (ba,__c.False);
 //BA.debugLineNum = 806;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 809;BA.debugLine="fnc.ProcessPowerFlags";
_fnc._processpowerflags /*String*/ (ba);
 //BA.debugLineNum = 811;BA.debugLine="End Sub";
return "";
}
public void  _check4_update() throws Exception{
ResumableSub_Check4_Update rsub = new ResumableSub_Check4_Update(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Check4_Update extends BA.ResumableSub {
public ResumableSub_Check4_Update(sadLogic.OctoTouchController.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.b4xmainpage parent;
sadLogic.OctoTouchController.dlgappupdate _obj = null;
boolean _yes = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 841;BA.debugLine="Dim obj As dlgAppUpdate : obj.Initialize(Null)";
_obj = new sadLogic.OctoTouchController.dlgappupdate();
 //BA.debugLineNum = 841;BA.debugLine="Dim obj As dlgAppUpdate : obj.Initialize(Null)";
_obj._initialize /*Object*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Null)));
 //BA.debugLineNum = 842;BA.debugLine="Wait For (obj.CheckIfNewDownloadAvail()) Complete";
parent.__c.WaitFor("complete", ba, this, _obj._checkifnewdownloadavail /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 5;
return;
case 5:
//C
this.state = 1;
_yes = (Boolean) result[0];
;
 //BA.debugLineNum = 843;BA.debugLine="If yes Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_yes) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 844;BA.debugLine="guiHelpers.Show_toast2(\"App update available\", 3";
parent._guihelpers._show_toast2 /*String*/ (ba,"App update available",(int) (3600));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 847;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private Const mModule As String = \"B4XMainPage\" '";
_mmodule = "B4XMainPage";
 //BA.debugLineNum = 18;BA.debugLine="Public Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 20;BA.debugLine="Public oMasterController As MasterController";
_omastercontroller = new sadLogic.OctoTouchController.mastercontroller();
 //BA.debugLineNum = 21;BA.debugLine="Private toast As BCToast";
_toast = new sadLogic.OctoTouchController.bctoast();
 //BA.debugLineNum = 22;BA.debugLine="Private csHdr As CSBuilder";
_cshdr = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 23;BA.debugLine="Private strTMP As String, iiTMP As Int";
_strtmp = "";
_iitmp = 0;
 //BA.debugLineNum = 26;BA.debugLine="Public pnlScreenOff As Panel";
_pnlscreenoff = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private ivSpash As ImageView, pnlSplash As Panel,";
_ivspash = new anywheresoftware.b4a.objects.ImageViewWrapper();
_pnlsplash = new anywheresoftware.b4a.objects.PanelWrapper();
_lblsplash = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private pnlMaster As B4XView";
_pnlmaster = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private pnlHeader As B4XView";
_pnlheader = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private btnSliderMenu, btnPageAction As Button";
_btnslidermenu = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpageaction = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Public lblStatus As Label";
_lblstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Public oPageCurrent As Object = Null";
_opagecurrent = __c.Null;
 //BA.debugLineNum = 41;BA.debugLine="Public oPageMenu As pageMenu, oPageFiles As pageF";
_opagemenu = new sadLogic.OctoTouchController.pagemenu();
_opagefiles = new sadLogic.OctoTouchController.pagefiles();
 //BA.debugLineNum = 42;BA.debugLine="Public oPagePrinting As pagePrinting, oPageMoveme";
_opageprinting = new sadLogic.OctoTouchController.pageprinting();
_opagemovement = new sadLogic.OctoTouchController.pagemovement();
 //BA.debugLineNum = 43;BA.debugLine="Private pnlMovement, pnlPrinting, pnlFiles, pnlMe";
_pnlmovement = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlprinting = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlfiles = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlmenu = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private mConnectionErrDlgShowingFLAG As Boolean =";
_mconnectionerrdlgshowingflag = __c.False;
 //BA.debugLineNum = 48;BA.debugLine="Public pPrinterCfgDlgShowingFLAG As Boolean = Fal";
_pprintercfgdlgshowingflag = __c.False;
 //BA.debugLineNum = 49;BA.debugLine="Private PromptExitTwice As Boolean = False";
_promptexittwice = __c.False;
 //BA.debugLineNum = 50;BA.debugLine="Private mToastTxtSize As Int";
_mtoasttxtsize = 0;
 //BA.debugLineNum = 52;BA.debugLine="Private mapMasterPreHeaterMenu As Map";
_mapmasterpreheatermenu = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 55;BA.debugLine="Public SideMenu As sadB4XDrawerAdvancedHelper";
_sidemenu = new sadLogic.OctoTouchController.sadb4xdraweradvancedhelper();
 //BA.debugLineNum = 56;BA.debugLine="Private Drawer As sadB4XDrawerAdvanced";
_drawer = new sadLogic.OctoTouchController.sadb4xdraweradvanced();
 //BA.debugLineNum = 57;BA.debugLine="Private btnSTOP,btnFRESTART,btnRESTART As Button";
_btnstop = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnfrestart = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnrestart = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 58;BA.debugLine="Private pnlBtnsDrawer,pnlMainDrawer As B4XView";
_pnlbtnsdrawer = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlmaindrawer = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 59;BA.debugLine="Private pnlLineBreakDrawer As Panel";
_pnllinebreakdrawer = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Private clvDrawer As CustomListView";
_clvdrawer = new b4a.example3.customlistview();
 //BA.debugLineNum = 63;BA.debugLine="Public pObjCurrentDlg1 As Object = Null";
_pobjcurrentdlg1 = __c.Null;
 //BA.debugLineNum = 64;BA.debugLine="Public pObjCurrentDlg2 As Object = Null";
_pobjcurrentdlg2 = __c.Null;
 //BA.debugLineNum = 65;BA.debugLine="Public pObjPreHeatDlg1 As dlgListbox";
_pobjpreheatdlg1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 66;BA.debugLine="Public pnlWizards As Panel";
_pnlwizards = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 67;BA.debugLine="Public pDlgFilSetup As dlgFilamentSetup";
_pdlgfilsetup = new sadLogic.OctoTouchController.dlgfilamentsetup();
 //BA.debugLineNum = 68;BA.debugLine="Public pObjWizards As Object = Null";
_pobjwizards = __c.Null;
 //BA.debugLineNum = 69;BA.debugLine="Public pDlgPrinterSetup As dlgOctoSetup";
_pdlgprintersetup = new sadLogic.OctoTouchController.dlgoctosetup();
 //BA.debugLineNum = 70;BA.debugLine="Private mErrorDlg As dlgMsgBox";
_merrordlg = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 71;BA.debugLine="Public pMBox2 As dlgMsgBox2";
_pmbox2 = new sadLogic.OctoTouchController.dlgmsgbox2();
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public String  _cleangcodestring(String _s) throws Exception{
 //BA.debugLineNum = 1290;BA.debugLine="Private Sub CleanGcodeString(s As String) As Strin";
 //BA.debugLineNum = 1291;BA.debugLine="s = s.Trim";
_s = _s.trim();
 //BA.debugLineNum = 1292;BA.debugLine="If s.StartsWith(\";\") Or s.StartsWith(\"#\") Then";
if (_s.startsWith(";") || _s.startsWith("#")) { 
 //BA.debugLineNum = 1293;BA.debugLine="Return \"\"";
if (true) return "";
 }else {
 //BA.debugLineNum = 1295;BA.debugLine="Return s";
if (true) return _s;
 };
 //BA.debugLineNum = 1297;BA.debugLine="End Sub";
return "";
}
public void  _clvdrawer_itemclick(int _index,Object _value) throws Exception{
ResumableSub_clvDrawer_ItemClick rsub = new ResumableSub_clvDrawer_ItemClick(this,_index,_value);
rsub.resume(ba, null);
}
public static class ResumableSub_clvDrawer_ItemClick extends BA.ResumableSub {
public ResumableSub_clvDrawer_ItemClick(sadLogic.OctoTouchController.b4xmainpage parent,int _index,Object _value) {
this.parent = parent;
this._index = _index;
this._value = _value;
}
sadLogic.OctoTouchController.b4xmainpage parent;
int _index;
Object _value;
String _txt = "";
float _w = 0f;
int _res = 0;
sadLogic.OctoTouchController.dlgabout _o2 = null;
sadLogic.OctoTouchController.dlgoctosyscmds _oa = null;
sadLogic.OctoTouchController.dlgoctopsuctrl _o1 = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 1092;BA.debugLine="Dim txt As String = \"\", w As Float";
_txt = "";
_w = 0f;
 //BA.debugLineNum = 1094;BA.debugLine="SideMenu.CloseRightMenu";
parent._sidemenu._closerightmenu /*String*/ ();
 //BA.debugLineNum = 1095;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 1096;BA.debugLine="Select Case Value.As(String)";
if (true) break;

case 1:
//select
this.state = 62;
switch (BA.switchObjectToInt((BA.ObjectToString(_value)),"fcm","kst","m600","refl","ab","sys","pwr","1","2","3","4","5","6","7","8","g0","g1","g2","g3","g4","g5","g6","g7","rcnt")) {
case 0: {
this.state = 3;
if (true) break;
}
case 1: {
this.state = 5;
if (true) break;
}
case 2: {
this.state = 27;
if (true) break;
}
case 3: {
this.state = 45;
if (true) break;
}
case 4: {
this.state = 47;
if (true) break;
}
case 5: {
this.state = 49;
if (true) break;
}
case 6: {
this.state = 51;
if (true) break;
}
case 7: 
case 8: 
case 9: 
case 10: 
case 11: 
case 12: 
case 13: 
case 14: {
this.state = 57;
if (true) break;
}
case 15: 
case 16: 
case 17: 
case 18: 
case 19: 
case 20: 
case 21: 
case 22: {
this.state = 59;
if (true) break;
}
case 23: {
this.state = 61;
if (true) break;
}
}
if (true) break;

case 3:
//C
this.state = 62;
 //BA.debugLineNum = 1099;BA.debugLine="Case \"fcm\"  : Cooling_Fan";
parent._cooling_fan();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 1102;BA.debugLine="w = 400dip";
_w = (float) (parent.__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 1103;BA.debugLine="If guiHelpers.gIsLandScape = False Then w = 90%";
if (true) break;

case 6:
//if
this.state = 11;
if (parent._guihelpers._gislandscape /*boolean*/ ==parent.__c.False) { 
this.state = 8;
;}if (true) break;

case 8:
//C
this.state = 11;
_w = (float) (parent.__c.PerXToCurrent((float) (90),ba));
if (true) break;

case 11:
//C
this.state = 12;
;
 //BA.debugLineNum = 1104;BA.debugLine="pMBox2.Initialize(B4XPages.MainPage.Root,\"Quest";
parent._pmbox2._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,(float) (parent.__c.DipToCurrent((int) (150))),parent.__c.False);
 //BA.debugLineNum = 1105;BA.debugLine="pMBox2.NewTextSize = 24";
parent._pmbox2._newtextsize /*float*/  = (float) (24);
 //BA.debugLineNum = 1106;BA.debugLine="txt = \"Touch RESTART to fully\" & CRLF & \"restar";
_txt = "Touch RESTART to fully"+parent.__c.CRLF+"restart klipper";
 //BA.debugLineNum = 1107;BA.debugLine="If guiHelpers.gIsLandScape Then txt = txt.Repla";
if (true) break;

case 12:
//if
this.state = 17;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 14;
;}if (true) break;

case 14:
//C
this.state = 17;
_txt = _txt.replace(parent.__c.CRLF," ");
if (true) break;

case 17:
//C
this.state = 18;
;
 //BA.debugLineNum = 1108;BA.debugLine="Wait For (pMBox2.Show(txt,gblConst.MB_ICON_QUES";
parent.__c.WaitFor("complete", ba, this, parent._pmbox2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_txt,parent._gblconst._mb_icon_question /*String*/ ,"RESTART","","CANCEL"));
this.state = 63;
return;
case 63:
//C
this.state = 18;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 1109;BA.debugLine="If res = xui.DialogResponse_Cancel Then";
if (true) break;

case 18:
//if
this.state = 21;
if (_res==parent._xui.DialogResponse_Cancel) { 
this.state = 20;
}if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 1110;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 21:
//C
this.state = 22;
;
 //BA.debugLineNum = 1112;BA.debugLine="SideMenu.BtnPressed(btnFRESTART)";
parent._sidemenu._btnpressed /*void*/ (parent._btnfrestart);
 //BA.debugLineNum = 1113;BA.debugLine="If B4XPages.MainPage.oPageCurrent <> B4XPages.M";
if (true) break;

case 22:
//if
this.state = 25;
if ((parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._opagecurrent /*Object*/ ).equals((Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._opagemenu /*sadLogic.OctoTouchController.pagemenu*/ )) == false) { 
this.state = 24;
}if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 1115;BA.debugLine="btnPageAction_Click";
parent._btnpageaction_click();
 if (true) break;

case 25:
//C
this.state = 62;
;
 if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 1120;BA.debugLine="w = 400dip";
_w = (float) (parent.__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 1121;BA.debugLine="If guiHelpers.gIsLandScape = False Then w = 90%";
if (true) break;

case 28:
//if
this.state = 33;
if (parent._guihelpers._gislandscape /*boolean*/ ==parent.__c.False) { 
this.state = 30;
;}if (true) break;

case 30:
//C
this.state = 33;
_w = (float) (parent.__c.PerXToCurrent((float) (90),ba));
if (true) break;

case 33:
//C
this.state = 34;
;
 //BA.debugLineNum = 1122;BA.debugLine="pMBox2.Initialize(B4XPages.MainPage.Root,\"Quest";
parent._pmbox2._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,(float) (parent.__c.DipToCurrent((int) (150))),parent.__c.False);
 //BA.debugLineNum = 1123;BA.debugLine="pMBox2.NewTextSize = 24";
parent._pmbox2._newtextsize /*float*/  = (float) (24);
 //BA.debugLineNum = 1124;BA.debugLine="txt = \"Touch RUN to start M600\" & CRLF & \"Filam";
_txt = "Touch RUN to start M600"+parent.__c.CRLF+"Filament change";
 //BA.debugLineNum = 1125;BA.debugLine="If guiHelpers.gIsLandScape Then txt = txt.Repla";
if (true) break;

case 34:
//if
this.state = 39;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 36;
;}if (true) break;

case 36:
//C
this.state = 39;
_txt = _txt.replace(parent.__c.CRLF," ");
if (true) break;

case 39:
//C
this.state = 40;
;
 //BA.debugLineNum = 1126;BA.debugLine="Wait For (pMBox2.Show(txt,gblConst.MB_ICON_QUES";
parent.__c.WaitFor("complete", ba, this, parent._pmbox2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_txt,parent._gblconst._mb_icon_question /*String*/ ,"RUN","","CANCEL"));
this.state = 64;
return;
case 64:
//C
this.state = 40;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 1127;BA.debugLine="If res = xui.DialogResponse_Cancel Then";
if (true) break;

case 40:
//if
this.state = 43;
if (_res==parent._xui.DialogResponse_Cancel) { 
this.state = 42;
}if (true) break;

case 42:
//C
this.state = 43;
 //BA.debugLineNum = 1128;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 43:
//C
this.state = 62;
;
 //BA.debugLineNum = 1130;BA.debugLine="Send_Gcode(\"M600\")";
parent._send_gcode("M600");
 if (true) break;

case 45:
//C
this.state = 62;
 //BA.debugLineNum = 1132;BA.debugLine="Case \"refl\" : FilesCheckChange";
parent._filescheckchange();
 if (true) break;

case 47:
//C
this.state = 62;
 //BA.debugLineNum = 1135;BA.debugLine="Dim o2 As dlgAbout : pObjCurrentDlg1 = o2.Initi";
_o2 = new sadLogic.OctoTouchController.dlgabout();
 //BA.debugLineNum = 1135;BA.debugLine="Dim o2 As dlgAbout : pObjCurrentDlg1 = o2.Initi";
parent._pobjcurrentdlg1 = _o2._initialize /*Object*/ (ba);
 //BA.debugLineNum = 1136;BA.debugLine="o2.Show";
_o2._show /*void*/ ();
 if (true) break;

case 49:
//C
this.state = 62;
 //BA.debugLineNum = 1139;BA.debugLine="Dim oa As dlgOctoSysCmds";
_oa = new sadLogic.OctoTouchController.dlgoctosyscmds();
 //BA.debugLineNum = 1140;BA.debugLine="pObjCurrentDlg1 = oa.Initialize(oMasterControll";
parent._pobjcurrentdlg1 = _oa._initialize /*Object*/ (ba,parent._omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ());
 //BA.debugLineNum = 1141;BA.debugLine="oa.Initialize(oMasterController.CN)";
_oa._initialize /*Object*/ (ba,parent._omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ());
 //BA.debugLineNum = 1142;BA.debugLine="oa.Show";
_oa._show /*void*/ ();
 if (true) break;

case 51:
//C
this.state = 52;
 //BA.debugLineNum = 1145;BA.debugLine="If oc.isConnected = False And Main.kvs.GetDefau";
if (true) break;

case 52:
//if
this.state = 55;
if (parent._oc._isconnected /*boolean*/ ==parent.__c.False && (BA.ObjectToBoolean(parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._getdefault /*Object*/ (parent._gblconst._pwr_sonoff_plugin /*String*/ ,(Object)(parent.__c.False))))==parent.__c.False) { 
this.state = 54;
}if (true) break;

case 54:
//C
this.state = 55;
 //BA.debugLineNum = 1146;BA.debugLine="guiHelpers.Show_toast(gblConst.NOT_CONNECTED,1";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._not_connected /*String*/ ,(int) (1000));
 //BA.debugLineNum = 1147;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 55:
//C
this.state = 62;
;
 //BA.debugLineNum = 1149;BA.debugLine="Dim o1 As dlgOctoPsuCtrl";
_o1 = new sadLogic.OctoTouchController.dlgoctopsuctrl();
 //BA.debugLineNum = 1150;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(Me)";
parent._pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,(sadLogic.OctoTouchController.b4xmainpage)(parent));
 //BA.debugLineNum = 1151;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 if (true) break;

case 57:
//C
this.state = 62;
 //BA.debugLineNum = 1154;BA.debugLine="RunHTTPOnOff_Menu(Value.As(String) & gblConst.H";
parent._runhttponoff_menu((BA.ObjectToString(_value))+parent._gblconst._http_onoff_setup_file /*String*/ );
 if (true) break;

case 59:
//C
this.state = 62;
 //BA.debugLineNum = 1157;BA.debugLine="RunGCodeOnOff_Menu(Value.As(String).Replace(\"g\"";
parent._rungcodeonoff_menu((BA.ObjectToString(_value)).replace("g","")+parent._gblconst._gcode_custom_setup_file /*String*/ );
 if (true) break;

case 61:
//C
this.state = 62;
 //BA.debugLineNum = 1160;BA.debugLine="lblStatus_Click";
parent._lblstatus_click();
 if (true) break;

case 62:
//C
this.state = -1;
;
 //BA.debugLineNum = 1165;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _cooling_fan() throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
sadLogic.OctoTouchController.guimsgs _gui = null;
anywheresoftware.b4a.objects.collections.Map _po = null;
Object _title = null;
sadLogic.OctoTouchController.dlglistbox _o1 = null;
float _h = 0f;
 //BA.debugLineNum = 1169;BA.debugLine="Public Sub Cooling_Fan";
 //BA.debugLineNum = 1170;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 1171;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 1171;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 1172;BA.debugLine="Dim po As Map = gui.BuildCoolingFanMnu";
_po = new anywheresoftware.b4a.objects.collections.Map();
_po = _gui._buildcoolingfanmnu /*anywheresoftware.b4a.objects.collections.Map*/ ();
 //BA.debugLineNum = 1174;BA.debugLine="Dim title As Object = cs.Initialize.Typeface(Type";
_title = (Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe24a)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("  Cooling Fan Menu")).PopAll().getObject());
 //BA.debugLineNum = 1177;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 1178;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(title,Me,\"CoolMen";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,_title,this,"CoolMenu_Event",_pobjcurrentdlg1);
 //BA.debugLineNum = 1179;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 1180;BA.debugLine="Dim h As Float = 300dip";
_h = (float) (__c.DipToCurrent((int) (300)));
 //BA.debugLineNum = 1181;BA.debugLine="If guiHelpers.gIsLandScape Then h = guiHelpers.Ma";
if (_guihelpers._gislandscape /*boolean*/ ) { 
_h = _guihelpers._maxverticalheight_landscape /*float*/ (ba);};
 //BA.debugLineNum = 1182;BA.debugLine="o1.Show(h,300dip,po)";
_o1._show /*void*/ (_h,(float) (__c.DipToCurrent((int) (300))),_po);
 //BA.debugLineNum = 1183;BA.debugLine="End Sub";
return "";
}
public String  _coolmenu_event(String _selectedmsg,Object _tag) throws Exception{
sadLogic.OctoTouchController.b4xeval _o = null;
String _g = "";
String _txt = "";
int _v = 0;
 //BA.debugLineNum = 1184;BA.debugLine="Public Sub CoolMenu_Event(selectedMsg As String, t";
 //BA.debugLineNum = 1186;BA.debugLine="If selectedMsg.Length = 0 Then Return";
if (_selectedmsg.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 1187;BA.debugLine="Dim o As B4XEval : o.Initialize(Me,\"\")";
_o = new sadLogic.OctoTouchController.b4xeval();
 //BA.debugLineNum = 1187;BA.debugLine="Dim o As B4XEval : o.Initialize(Me,\"\")";
_o._initialize /*String*/ (ba,this,"");
 //BA.debugLineNum = 1188;BA.debugLine="Dim g As String = \"M106 S\"";
_g = "M106 S";
 //BA.debugLineNum = 1189;BA.debugLine="Dim txt As String, v As Int";
_txt = "";
_v = 0;
 //BA.debugLineNum = 1190;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,(_selectedmsg).equals("0"),(_selectedmsg).equals("100"))) {
case 0: {
 //BA.debugLineNum = 1192;BA.debugLine="Case selectedMsg = \"0\"   : txt = \"M107\"";
_txt = "M107";
 break; }
case 1: {
 //BA.debugLineNum = 1193;BA.debugLine="Case selectedMsg = \"100\" : txt = g & \"255\"";
_txt = _g+"255";
 break; }
default: {
 //BA.debugLineNum = 1195;BA.debugLine="v = o.Eval(\"255 * .\" & selectedMsg)";
_v = (int) (_o._eval /*double*/ ("255 * ."+_selectedmsg));
 //BA.debugLineNum = 1196;BA.debugLine="txt = (g & v)";
_txt = (_g+BA.NumberToString(_v));
 break; }
}
;
 //BA.debugLineNum = 1199;BA.debugLine="Send_Gcode(txt)";
_send_gcode(_txt);
 //BA.debugLineNum = 1200;BA.debugLine="pObjCurrentDlg1 = Null";
_pobjcurrentdlg1 = __c.Null;
 //BA.debugLineNum = 1202;BA.debugLine="End Sub";
return "";
}
public String  _ev_filament_change_rec(String _msg) throws Exception{
anywheresoftware.b4a.objects.collections.Map _datamapg = null;
sadLogic.OctoTouchController.soundsbeeps _b = null;
sadLogic.OctoTouchController.dlgfilamentctrl _o = null;
boolean _areweinthemiddleofprint = false;
 //BA.debugLineNum = 1357;BA.debugLine="Private Sub ev_filament_change_rec(msg As String)";
 //BA.debugLineNum = 1358;BA.debugLine="Log(\"ev_filament_change_rec\")";
__c.LogImpl("7667713","ev_filament_change_rec",0);
 //BA.debugLineNum = 1360;BA.debugLine="Dim dataMapG As Map = File.ReadMap(xui.DefaultFol";
_datamapg = new anywheresoftware.b4a.objects.collections.Map();
_datamapg = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._filament_change_file /*String*/ );
 //BA.debugLineNum = 1361;BA.debugLine="If dataMapG.GetDefault(gblConst.filM600Show,False";
if ((BA.ObjectToBoolean(_datamapg.GetDefault((Object)(_gblconst._film600show /*String*/ ),(Object)(__c.False))))) { 
 //BA.debugLineNum = 1362;BA.debugLine="Dim b As SoundsBeeps : b.Initialize";
_b = new sadLogic.OctoTouchController.soundsbeeps();
 //BA.debugLineNum = 1362;BA.debugLine="Dim b As SoundsBeeps : b.Initialize";
_b._initialize /*String*/ (ba);
 //BA.debugLineNum = 1363;BA.debugLine="b.Beeps(300,500,5)";
_b._beeps /*void*/ ((long) (300),(long) (500),(int) (5));
 //BA.debugLineNum = 1364;BA.debugLine="Dim o As dlgFilamentCtrl";
_o = new sadLogic.OctoTouchController.dlgfilamentctrl();
 //BA.debugLineNum = 1365;BA.debugLine="Dim AreWeInTheMiddleOfPrint As Boolean = True";
_areweinthemiddleofprint = __c.True;
 //BA.debugLineNum = 1366;BA.debugLine="If oc.JobPrintState.EqualsIgnoreCase(\"Operationa";
if (_oc._jobprintstate /*String*/ .equalsIgnoreCase("Operational")) { 
_areweinthemiddleofprint = __c.False;};
 //BA.debugLineNum = 1367;BA.debugLine="pObjCurrentDlg2 = o.Initialize(AreWeInTheMiddleO";
_pobjcurrentdlg2 = _o._initialize /*Object*/ (ba,_areweinthemiddleofprint);
 //BA.debugLineNum = 1368;BA.debugLine="o.Show";
_o._show /*void*/ ();
 };
 //BA.debugLineNum = 1371;BA.debugLine="End Sub";
return "";
}
public String  _ev_file_change(String _msg) throws Exception{
 //BA.debugLineNum = 1304;BA.debugLine="Private Sub ev_file_change(msg As String)";
 //BA.debugLineNum = 1305;BA.debugLine="logMe.LogDebug2(\"WS-ev_file_change\",\"\")";
_logme._logdebug2 /*String*/ (ba,"WS-ev_file_change","");
 //BA.debugLineNum = 1306;BA.debugLine="If oPageFiles.IsInitialized = False Then Return";
if (_opagefiles.IsInitialized /*boolean*/ ()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 1307;BA.debugLine="If oPageCurrent <> oPageFiles Then";
if ((_opagecurrent).equals((Object)(_opagefiles)) == false) { 
 //BA.debugLineNum = 1308;BA.debugLine="oPageFiles.FileEvent = True";
_opagefiles._fileevent /*boolean*/  = __c.True;
 }else {
 //BA.debugLineNum = 1324;BA.debugLine="If Main.tmrTimerCallSub.Exists(Me,\"FilesCheckCha";
if (_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._exists /*anywheresoftware.b4a.objects.Timer*/ (this,"FilesCheckChange")!= null) { 
if (true) return "";};
 //BA.debugLineNum = 1327;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"File";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"FilesCheckChange",(int) (1200));
 };
 //BA.debugLineNum = 1329;BA.debugLine="End Sub";
return "";
}
public String  _ev_file_del(String _msg) throws Exception{
 //BA.debugLineNum = 1330;BA.debugLine="Private Sub ev_file_del(msg As String)";
 //BA.debugLineNum = 1331;BA.debugLine="logMe.LogDebug2(\"WS-ev_file_del\",\"\")";
_logme._logdebug2 /*String*/ (ba,"WS-ev_file_del","");
 //BA.debugLineNum = 1332;BA.debugLine="If oPageFiles.IsInitialized = False Then Return";
if (_opagefiles.IsInitialized /*boolean*/ ()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 1333;BA.debugLine="If oPageCurrent <> oPageFiles Then";
if ((_opagecurrent).equals((Object)(_opagefiles)) == false) { 
 //BA.debugLineNum = 1334;BA.debugLine="oPageFiles.FileEvent = True";
_opagefiles._fileevent /*boolean*/  = __c.True;
 }else {
 //BA.debugLineNum = 1337;BA.debugLine="If Main.tmrTimerCallSub.Exists(Me,\"FilesCheckCha";
if (_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._exists /*anywheresoftware.b4a.objects.Timer*/ (this,"FilesCheckChange")!= null) { 
if (true) return "";};
 //BA.debugLineNum = 1340;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"File";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"FilesCheckChange",(int) (1200));
 };
 //BA.debugLineNum = 1342;BA.debugLine="End Sub";
return "";
}
public String  _ev_print_done(String _msg) throws Exception{
 //BA.debugLineNum = 1354;BA.debugLine="Private Sub ev_print_done(msg As String)";
 //BA.debugLineNum = 1356;BA.debugLine="End Sub";
return "";
}
public String  _ev_print_started(String _msg) throws Exception{
 //BA.debugLineNum = 1351;BA.debugLine="Private Sub ev_print_started(msg As String)";
 //BA.debugLineNum = 1353;BA.debugLine="End Sub";
return "";
}
public String  _filescheckchange() throws Exception{
 //BA.debugLineNum = 1344;BA.debugLine="Private Sub FilesCheckChange";
 //BA.debugLineNum = 1345;BA.debugLine="oPageFiles.FilesCheckChange(False)";
_opagefiles._filescheckchange /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (__c.False);
 //BA.debugLineNum = 1346;BA.debugLine="End Sub";
return "";
}
public String  _fncmenu_event(String _value,Object _tag) throws Exception{
boolean _onoff = false;
String _msg = "";
sadLogic.OctoTouchController.dlgbltouchsetup _ob7 = null;
sadLogic.OctoTouchController.dlgbedlevelsetup _o1 = null;
sadLogic.OctoTouchController.dlggcodecustsetup _o23 = null;
 //BA.debugLineNum = 621;BA.debugLine="Private Sub FncMenu_Event(value As String, tag As";
 //BA.debugLineNum = 623;BA.debugLine="If value.Length = 0 Then";
if (_value.length()==0) { 
 //BA.debugLineNum = 624;BA.debugLine="PopupMainOptionMenu";
_popupmainoptionmenu();
 //BA.debugLineNum = 625;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 628;BA.debugLine="Dim onOff As Boolean";
_onoff = false;
 //BA.debugLineNum = 629;BA.debugLine="Dim msg As String = \"\"";
_msg = "";
 //BA.debugLineNum = 631;BA.debugLine="Select Case value";
switch (BA.switchObjectToInt(_value,"mms","zo","blcr","fl","bl","g0","g1","g2","g3","g4","g5","g6","g7")) {
case 0: {
 //BA.debugLineNum = 634;BA.debugLine="onOff = Main.kvs.Get(gblConst.MANUAL_MESH_FLAG)";
_onoff = (BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (_gblconst._manual_mesh_flag /*String*/ )));
 //BA.debugLineNum = 635;BA.debugLine="msg = \"Manual mesh wizard turned \"";
_msg = "Manual mesh wizard turned ";
 //BA.debugLineNum = 636;BA.debugLine="If onOff Then";
if (_onoff) { 
 //BA.debugLineNum = 637;BA.debugLine="msg = msg & \"off\"";
_msg = _msg+"off";
 }else {
 //BA.debugLineNum = 639;BA.debugLine="msg = msg & \"on\"";
_msg = _msg+"on";
 };
 //BA.debugLineNum = 641;BA.debugLine="Main.kvs.Put(gblConst.MANUAL_MESH_FLAG, Not (on";
_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (_gblconst._manual_mesh_flag /*String*/ ,(Object)(__c.Not(_onoff)));
 //BA.debugLineNum = 642;BA.debugLine="CallSubDelayed(Me,\"PopupFunctionOptionsMnu\")";
__c.CallSubDelayed(ba,this,"PopupFunctionOptionsMnu");
 break; }
case 1: {
 //BA.debugLineNum = 646;BA.debugLine="onOff = Main.kvs.Get(gblConst.Z_OFFSET_FLAG).As";
_onoff = (BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (_gblconst._z_offset_flag /*String*/ )));
 //BA.debugLineNum = 647;BA.debugLine="msg = \"Z Offset wizard turned \"";
_msg = "Z Offset wizard turned ";
 //BA.debugLineNum = 648;BA.debugLine="If onOff Then";
if (_onoff) { 
 //BA.debugLineNum = 649;BA.debugLine="msg = msg & \"off\"";
_msg = _msg+"off";
 }else {
 //BA.debugLineNum = 651;BA.debugLine="msg = msg & \"on\"";
_msg = _msg+"on";
 };
 //BA.debugLineNum = 653;BA.debugLine="Main.kvs.Put(gblConst.Z_OFFSET_FLAG, Not (onOff";
_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (_gblconst._z_offset_flag /*String*/ ,(Object)(__c.Not(_onoff)));
 //BA.debugLineNum = 654;BA.debugLine="CallSubDelayed(Me,\"PopupFunctionOptionsMnu\")";
__c.CallSubDelayed(ba,this,"PopupFunctionOptionsMnu");
 break; }
case 2: {
 //BA.debugLineNum = 657;BA.debugLine="Dim oB7 As dlgBLTouchSetup";
_ob7 = new sadLogic.OctoTouchController.dlgbltouchsetup();
 //BA.debugLineNum = 658;BA.debugLine="oB7.Initialize : oB7.Show";
_ob7._initialize /*Object*/ (ba);
 //BA.debugLineNum = 658;BA.debugLine="oB7.Initialize : oB7.Show";
_ob7._show /*void*/ ();
 break; }
case 3: {
 //BA.debugLineNum = 661;BA.debugLine="pDlgFilSetup.Initialize";
_pdlgfilsetup._initialize /*Object*/ (ba);
 //BA.debugLineNum = 662;BA.debugLine="pDlgFilSetup.Show";
_pdlgfilsetup._show /*void*/ ();
 break; }
case 4: {
 //BA.debugLineNum = 665;BA.debugLine="If oc.PrinterCustomBoundingBox = True Then";
if (_oc._printercustomboundingbox /*boolean*/ ==__c.True) { 
 //BA.debugLineNum = 666;BA.debugLine="Show_toast(\"Custom bounding box not supported";
_show_toast("Custom bounding box not supported at this time.",(int) (4500));
 //BA.debugLineNum = 667;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 669;BA.debugLine="Dim o1 As dlgBedLevelSetup";
_o1 = new sadLogic.OctoTouchController.dlgbedlevelsetup();
 //BA.debugLineNum = 670;BA.debugLine="o1.Initialize : o1.Show";
_o1._initialize /*Object*/ (ba);
 //BA.debugLineNum = 670;BA.debugLine="o1.Initialize : o1.Show";
_o1._show /*void*/ ();
 break; }
case 5: 
case 6: 
case 7: 
case 8: 
case 9: 
case 10: 
case 11: 
case 12: {
 //BA.debugLineNum = 673;BA.debugLine="strTMP = value.Replace(\"g\",\"\")";
_strtmp = _value.replace("g","");
 //BA.debugLineNum = 674;BA.debugLine="Dim o23 As dlgGCodeCustSetup";
_o23 = new sadLogic.OctoTouchController.dlggcodecustsetup();
 //BA.debugLineNum = 675;BA.debugLine="pObjCurrentDlg2 = o23.Initialize(Me,\"Rebuild_Ri";
_pobjcurrentdlg2 = _o23._initialize /*Object*/ (ba,this,"Rebuild_RightMnu");
 //BA.debugLineNum = 676;BA.debugLine="o23.Show(\"GCode Control Config - \" & strTMP,str";
_o23._show /*void*/ ("GCode Control Config - "+_strtmp,_strtmp+_gblconst._gcode_custom_setup_file /*String*/ );
 break; }
}
;
 //BA.debugLineNum = 680;BA.debugLine="If msg.Length <> 0 Then";
if (_msg.length()!=0) { 
 //BA.debugLineNum = 681;BA.debugLine="Show_toast(msg,2400)";
_show_toast(_msg,(int) (2400));
 };
 //BA.debugLineNum = 684;BA.debugLine="End Sub";
return "";
}
public String  _hidesplash_startup() throws Exception{
 //BA.debugLineNum = 305;BA.debugLine="Public Sub HideSplash_StartUp";
 //BA.debugLineNum = 306;BA.debugLine="pnlSplash.Visible = False";
_pnlsplash.setVisible(__c.False);
 //BA.debugLineNum = 307;BA.debugLine="pnlMaster.Visible = True";
_pnlmaster.setVisible(__c.True);
 //BA.debugLineNum = 308;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 82;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 84;BA.debugLine="config.Init";
_config._init /*String*/ (ba);
 //BA.debugLineNum = 85;BA.debugLine="logMe.Init(xui.DefaultFolder,\"_OCTOTC_\",\"log\")";
_logme._init /*String*/ (ba,_xui.getDefaultFolder(),"_OCTOTC_","log");
 //BA.debugLineNum = 86;BA.debugLine="clrTheme.Init(Main.kvs.Get(gblConst.SELECTED_CLR_";
_clrtheme._init /*String*/ (ba,(BA.ObjectToString(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (_gblconst._selected_clr_theme /*String*/ ))).toLowerCase());
 //BA.debugLineNum = 88;BA.debugLine="CallSub(Main,\"InitLog_Cleanup\")";
__c.CallSubNew(ba,(Object)(_main.getObject()),"InitLog_Cleanup");
 //BA.debugLineNum = 95;BA.debugLine="fileHelpers.DeleteFiles(xui.DefaultFolder,\"sad_*.";
_filehelpers._deletefiles /*String*/ (ba,_xui.getDefaultFolder(),"sad_*.png");
 //BA.debugLineNum = 96;BA.debugLine="logMe.LogIt(\"App Startup...\",\"\")";
_logme._logit /*String*/ (ba,"App Startup...","");
 //BA.debugLineNum = 98;BA.debugLine="powerHelpers.Init(config.AndroidTakeOverSleepFLAG";
_powerhelpers._init /*String*/ (ba,_config._androidtakeoversleepflag /*boolean*/ );
 //BA.debugLineNum = 99;BA.debugLine="CfgAndroidPowerOptions";
_cfgandroidpoweroptions();
 //BA.debugLineNum = 102;BA.debugLine="mToastTxtSize = IIf(guiHelpers.gScreenSizeAprox >";
_mtoasttxtsize = (int)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >5) ? ((Object)(24)) : ((Object)(22)))));
 //BA.debugLineNum = 104;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Check";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"Check4_Update",(int) (8000));
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public void  _is_octoklipper() throws Exception{
ResumableSub_Is_OctoKlipper rsub = new ResumableSub_Is_OctoKlipper(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Is_OctoKlipper extends BA.ResumableSub {
public ResumableSub_Is_OctoKlipper(sadLogic.OctoTouchController.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.b4xmainpage parent;
sadLogic.OctoTouchController.octoklippymisc _oo = null;
boolean _i = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 345;BA.debugLine="Dim oo As OctoKlippyMisc : oo.Initialize";
_oo = new sadLogic.OctoTouchController.octoklippymisc();
 //BA.debugLineNum = 345;BA.debugLine="Dim oo As OctoKlippyMisc : oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 346;BA.debugLine="Wait For (oo.IsOctoKlipper) Complete(i As Boolean";
parent.__c.WaitFor("complete", ba, this, _oo._isoctoklipper /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 5;
return;
case 5:
//C
this.state = 1;
_i = (Boolean) result[0];
;
 //BA.debugLineNum = 347;BA.debugLine="oo.CreateDefGCodeFiles";
_oo._createdefgcodefiles /*String*/ ();
 //BA.debugLineNum = 348;BA.debugLine="If oc.Klippy Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._oc._klippy /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 350;BA.debugLine="SideMenu.SkinMe(Array As Button(btnSTOP,btnFREST";
parent._sidemenu._skinme /*String*/ (new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnstop,parent._btnfrestart,parent._btnrestart},parent._pnlmaindrawer,parent._pnlbtnsdrawer);
 //BA.debugLineNum = 351;BA.debugLine="SideMenu.Display_Btns";
parent._sidemenu._display_btns /*String*/ ();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 353;BA.debugLine="Build_RightSideMenu";
parent._build_rightsidemenu();
 //BA.debugLineNum = 354;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _lblstatus_click() throws Exception{
 //BA.debugLineNum = 832;BA.debugLine="Private Sub lblStatus_Click";
 //BA.debugLineNum = 834;BA.debugLine="If lblStatus.Text.ToLowerCase.Contains(\"no c\") Or";
if (_lblstatus.getText().toLowerCase().contains("no c") || _oc._isconnected /*boolean*/ ==__c.False || _omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pconnected /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 835;BA.debugLine="CallSetupErrorConnecting(False)";
_callsetuperrorconnecting(__c.False);
 };
 //BA.debugLineNum = 837;BA.debugLine="End Sub";
return "";
}
public String  _loadsplashpic() throws Exception{
String _fname = "";
 //BA.debugLineNum = 292;BA.debugLine="Private Sub LoadSplashPic";
 //BA.debugLineNum = 299;BA.debugLine="Dim fname As String = \"splash.png\"";
_fname = "splash.png";
 //BA.debugLineNum = 301;BA.debugLine="ivSpash.Bitmap = LoadBitmapResize(File.DirAssets,";
_ivspash.setBitmap((android.graphics.Bitmap)(__c.LoadBitmapResize(__c.File.getDirAssets(),_fname,_ivspash.getWidth(),_ivspash.getHeight(),__c.True).getObject()));
 //BA.debugLineNum = 303;BA.debugLine="End Sub";
return "";
}
public String  _optionsmenu_event(String _value,Object _tag) throws Exception{
sadLogic.OctoTouchController.dlgthemeselect _oo9 = null;
sadLogic.OctoTouchController.dlgabout _o2 = null;
sadLogic.OctoTouchController.dlggeneraloptions _o3 = null;
sadLogic.OctoTouchController.dlgandroidpoweroptions _o1 = null;
String _f = "";
sadLogic.OctoTouchController.dlgviewtext _vt = null;
sadLogic.OctoTouchController.dlgappupdate _up = null;
 //BA.debugLineNum = 528;BA.debugLine="Private Sub OptionsMenu_Event(value As String, tag";
 //BA.debugLineNum = 531;BA.debugLine="pObjCurrentDlg1 = Null";
_pobjcurrentdlg1 = __c.Null;
 //BA.debugLineNum = 532;BA.debugLine="If value = Null Or value.Length = 0 Then";
if (_value== null || _value.length()==0) { 
 //BA.debugLineNum = 533;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 536;BA.debugLine="Select Case value";
switch (BA.switchObjectToInt(_value,"thm1","ab","gn","oc","pw","plg","fn","rt","cup")) {
case 0: {
 //BA.debugLineNum = 538;BA.debugLine="Dim oo9 As dlgThemeSelect";
_oo9 = new sadLogic.OctoTouchController.dlgthemeselect();
 //BA.debugLineNum = 539;BA.debugLine="pObjWizards = oo9.Initialize";
_pobjwizards = (Object)(_oo9._initialize /*String*/ (ba));
 //BA.debugLineNum = 540;BA.debugLine="oo9.Show(pnlWizards)";
_oo9._show /*Object*/ (_pnlwizards);
 break; }
case 1: {
 //BA.debugLineNum = 543;BA.debugLine="Dim o2 As dlgAbout";
_o2 = new sadLogic.OctoTouchController.dlgabout();
 //BA.debugLineNum = 544;BA.debugLine="pObjCurrentDlg1 = o2.Initialize";
_pobjcurrentdlg1 = _o2._initialize /*Object*/ (ba);
 //BA.debugLineNum = 545;BA.debugLine="o2.Show";
_o2._show /*void*/ ();
 break; }
case 2: {
 //BA.debugLineNum = 548;BA.debugLine="Dim o3 As dlgGeneralOptions";
_o3 = new sadLogic.OctoTouchController.dlggeneraloptions();
 //BA.debugLineNum = 549;BA.debugLine="pObjCurrentDlg1 = o3.Initialize";
_pobjcurrentdlg1 = _o3._initialize /*Object*/ (ba);
 //BA.debugLineNum = 550;BA.debugLine="o3.Show";
_o3._show /*void*/ ();
 break; }
case 3: {
 //BA.debugLineNum = 554;BA.debugLine="pDlgPrinterSetup.Initialize(\"Printer Connection";
_pdlgprintersetup._initialize /*Object*/ (ba,"Printer Connection","PrinterSetup_Closed");
 //BA.debugLineNum = 555;BA.debugLine="pDlgPrinterSetup.Show(False)";
_pdlgprintersetup._show /*void*/ (__c.False);
 break; }
case 4: {
 //BA.debugLineNum = 558;BA.debugLine="Dim o1 As dlgAndroidPowerOptions";
_o1 = new sadLogic.OctoTouchController.dlgandroidpoweroptions();
 //BA.debugLineNum = 559;BA.debugLine="pObjCurrentDlg1 = o1.Initialize";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba);
 //BA.debugLineNum = 560;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 break; }
case 5: {
 //BA.debugLineNum = 563;BA.debugLine="PopupPluginOptionMenu";
_popuppluginoptionmenu();
 break; }
case 6: {
 //BA.debugLineNum = 566;BA.debugLine="PopupFunctionOptionsMnu";
_popupfunctionoptionsmnu();
 break; }
case 7: {
 //BA.debugLineNum = 569;BA.debugLine="Dim f As String = fnc.GetTxtLogFile";
_f = _fnc._gettxtlogfile /*String*/ (ba);
 //BA.debugLineNum = 570;BA.debugLine="If f = \"\" Then";
if ((_f).equals("")) { 
 //BA.debugLineNum = 571;BA.debugLine="Show_toast(\"no log file found\",6000)";
_show_toast("no log file found",(int) (6000));
 //BA.debugLineNum = 572;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 574;BA.debugLine="Dim vt As dlgViewText";
_vt = new sadLogic.OctoTouchController.dlgviewtext();
 //BA.debugLineNum = 575;BA.debugLine="pObjCurrentDlg1 = vt.Initialize(\"Read Text\")";
_pobjcurrentdlg1 = (Object)(_vt._initialize /*String*/ (ba,"Read Text"));
 //BA.debugLineNum = 576;BA.debugLine="vt.Show(f)";
_vt._show /*void*/ (_f);
 break; }
case 8: {
 //BA.debugLineNum = 579;BA.debugLine="Dim up As dlgAppUpdate";
_up = new sadLogic.OctoTouchController.dlgappupdate();
 //BA.debugLineNum = 580;BA.debugLine="pObjCurrentDlg1 = up.Initialize(B4XPages.MainPa";
_pobjcurrentdlg1 = _up._initialize /*Object*/ (ba,_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 581;BA.debugLine="up.Show";
_up._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ();
 break; }
}
;
 //BA.debugLineNum = 586;BA.debugLine="End Sub";
return "";
}
public String  _pluginsmenu_event(String _value,Object _tag) throws Exception{
sadLogic.OctoTouchController.dlgoctopsusetup _oa = null;
sadLogic.OctoTouchController.dlgiponoffsetup _oa1 = null;
 //BA.debugLineNum = 709;BA.debugLine="Private Sub PluginsMenu_Event(value As String, tag";
 //BA.debugLineNum = 711;BA.debugLine="pObjCurrentDlg1 = Null";
_pobjcurrentdlg1 = __c.Null;
 //BA.debugLineNum = 712;BA.debugLine="If value.Length = 0 Then";
if (_value.length()==0) { 
 //BA.debugLineNum = 713;BA.debugLine="PopupMainOptionMenu";
_popupmainoptionmenu();
 //BA.debugLineNum = 714;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 717;BA.debugLine="Select Case value";
switch (BA.switchObjectToInt(_value,"psu","1","2","3","4","5","6","7","8")) {
case 0: {
 //BA.debugLineNum = 720;BA.debugLine="Dim oA As dlgOctoPsuSetup";
_oa = new sadLogic.OctoTouchController.dlgoctopsusetup();
 //BA.debugLineNum = 721;BA.debugLine="pObjCurrentDlg2 = oA.Initialize(\"PSU Config\")";
_pobjcurrentdlg2 = _oa._initialize /*Object*/ (ba,"PSU Config");
 //BA.debugLineNum = 722;BA.debugLine="oA.Show";
_oa._show /*void*/ ();
 break; }
case 1: 
case 2: 
case 3: 
case 4: 
case 5: 
case 6: 
case 7: 
case 8: {
 //BA.debugLineNum = 725;BA.debugLine="Dim oA1 As dlgIpOnOffSetup";
_oa1 = new sadLogic.OctoTouchController.dlgiponoffsetup();
 //BA.debugLineNum = 726;BA.debugLine="pObjCurrentDlg2 = oA1.Initialize(Me,\"Rebuild_Ri";
_pobjcurrentdlg2 = _oa1._initialize /*Object*/ (ba,this,"Rebuild_RightMnu");
 //BA.debugLineNum = 727;BA.debugLine="oA1.Show(\"HTTP Control Config - \" & value,value";
_oa1._show /*void*/ ("HTTP Control Config - "+_value,_value+_gblconst._http_onoff_setup_file /*String*/ );
 break; }
}
;
 //BA.debugLineNum = 733;BA.debugLine="End Sub";
return "";
}
public String  _pnlscreenoff_click() throws Exception{
 //BA.debugLineNum = 813;BA.debugLine="Private Sub pnlScreenOff_Click";
 //BA.debugLineNum = 816;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"screen off pa";
if (_config._logpower_events /*boolean*/ ) { 
__c.LogImpl("6094851","screen off panel click - show screen",0);};
 //BA.debugLineNum = 817;BA.debugLine="pnlScreenOff.Visible = False";
_pnlscreenoff.setVisible(__c.False);
 //BA.debugLineNum = 818;BA.debugLine="pnlScreenOff.SendToBack";
_pnlscreenoff.SendToBack();
 //BA.debugLineNum = 819;BA.debugLine="powerHelpers.SetScreenBrightness2";
_powerhelpers._setscreenbrightness2 /*String*/ (ba);
 //BA.debugLineNum = 820;BA.debugLine="fnc.ProcessPowerFlags";
_fnc._processpowerflags /*String*/ (ba);
 //BA.debugLineNum = 823;BA.debugLine="End Sub";
return "";
}
public String  _popupfunctionoptionsmnu() throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
sadLogic.OctoTouchController.guimsgs _gui = null;
anywheresoftware.b4a.objects.collections.Map _po = null;
Object _title = null;
sadLogic.OctoTouchController.dlglistbox _o1 = null;
float _h = 0f;
 //BA.debugLineNum = 601;BA.debugLine="Private Sub PopupFunctionOptionsMnu";
 //BA.debugLineNum = 603;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 604;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 604;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 605;BA.debugLine="Dim po As Map = gui.BuildFunctionSetupMenu";
_po = new anywheresoftware.b4a.objects.collections.Map();
_po = _gui._buildfunctionsetupmenu /*anywheresoftware.b4a.objects.collections.Map*/ ();
 //BA.debugLineNum = 607;BA.debugLine="Dim title As Object = cs.Initialize.Typeface(Type";
_title = (Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe24a)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("  Movement Functions Menu")).PopAll().getObject());
 //BA.debugLineNum = 610;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 611;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(title,Me,\"FncMenu";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,_title,this,"FncMenu_Event",_pobjcurrentdlg1);
 //BA.debugLineNum = 612;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 613;BA.debugLine="Dim h As Float = 300dip";
_h = (float) (__c.DipToCurrent((int) (300)));
 //BA.debugLineNum = 614;BA.debugLine="If guiHelpers.gIsLandScape Then h = guiHelpers.Ma";
if (_guihelpers._gislandscape /*boolean*/ ) { 
_h = _guihelpers._maxverticalheight_landscape /*float*/ (ba);};
 //BA.debugLineNum = 615;BA.debugLine="o1.Show(h,300dip,po)";
_o1._show /*void*/ (_h,(float) (__c.DipToCurrent((int) (300))),_po);
 //BA.debugLineNum = 618;BA.debugLine="End Sub";
return "";
}
public String  _popupmainoptionmenu() throws Exception{
anywheresoftware.b4a.objects.collections.Map _popupmemuitems = null;
sadLogic.OctoTouchController.guimsgs _gui = null;
sadLogic.OctoTouchController.dlglistbox _o1 = null;
 //BA.debugLineNum = 497;BA.debugLine="Private Sub PopupMainOptionMenu";
 //BA.debugLineNum = 499;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 501;BA.debugLine="Dim popUpMemuItems As Map";
_popupmemuitems = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 503;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 503;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 504;BA.debugLine="popUpMemuItems = gui.BuildOptionsMenu(False)";
_popupmemuitems = _gui._buildoptionsmenu /*anywheresoftware.b4a.objects.collections.Map*/ (__c.False);
 //BA.debugLineNum = 506;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 507;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(\"Options Menu\",Me";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,(Object)("Options Menu"),this,"OptionsMenu_Event",_pobjcurrentdlg1);
 //BA.debugLineNum = 508;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 515;BA.debugLine="If guiHelpers.gIsLandScape Then '- TODO needs ref";
if (_guihelpers._gislandscape /*boolean*/ ) { 
 //BA.debugLineNum = 516;BA.debugLine="o1.Show(guiHelpers.gHeight*.8, 340dip,popUpMemuI";
_o1._show /*void*/ ((float) (_guihelpers._gheight /*float*/ *.8),(float) (__c.DipToCurrent((int) (340))),_popupmemuitems);
 }else {
 //BA.debugLineNum = 518;BA.debugLine="If guiHelpers.gScreenSizeAprox < 5 Then";
if (_guihelpers._gscreensizeaprox /*double*/ <5) { 
 //BA.debugLineNum = 519;BA.debugLine="o1.Show(IIf(guiHelpers.gScreenSizeAprox > 6.5,4";
_o1._show /*void*/ ((float)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >6.5) ? ((Object)(__c.DipToCurrent((int) (436)))) : ((Object)(__c.DipToCurrent((int) (340))))))),(float) (_guihelpers._gwidth /*float*/ -__c.DipToCurrent((int) (10))),_popupmemuitems);
 }else {
 //BA.debugLineNum = 521;BA.debugLine="o1.Show(IIf(guiHelpers.gScreenSizeAprox > 6.5,4";
_o1._show /*void*/ ((float)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >6.5) ? ((Object)(__c.DipToCurrent((int) (436)))) : ((Object)(__c.DipToCurrent((int) (340))))))),(float) (__c.DipToCurrent((int) (354))),_popupmemuitems);
 };
 };
 //BA.debugLineNum = 526;BA.debugLine="End Sub";
return "";
}
public String  _popuppluginoptionmenu() throws Exception{
sadLogic.OctoTouchController.guimsgs _o = null;
anywheresoftware.b4a.objects.collections.Map _popupmemuitems = null;
Object _title = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
sadLogic.OctoTouchController.dlglistbox _o1 = null;
float _h = 0f;
 //BA.debugLineNum = 690;BA.debugLine="Private Sub PopupPluginOptionMenu";
 //BA.debugLineNum = 692;BA.debugLine="Dim o As guiMsgs : 	o.Initialize";
_o = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 692;BA.debugLine="Dim o As guiMsgs : 	o.Initialize";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 693;BA.debugLine="Dim popUpMemuItems As Map = o.BuildPluginOptionsM";
_popupmemuitems = new anywheresoftware.b4a.objects.collections.Map();
_popupmemuitems = _o._buildpluginoptionsmenu /*anywheresoftware.b4a.objects.collections.Map*/ ();
 //BA.debugLineNum = 694;BA.debugLine="Dim title As Object = \"  Plugins Menu\"";
_title = (Object)("  Plugins Menu");
 //BA.debugLineNum = 696;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 697;BA.debugLine="Dim title As Object = cs.Initialize.Typeface(Type";
_title = (Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe8c1)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_title)).PopAll().getObject());
 //BA.debugLineNum = 699;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 700;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(title,Me,\"Plugins";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,_title,this,"PluginsMenu_Event",_pobjcurrentdlg1);
 //BA.debugLineNum = 701;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 702;BA.debugLine="Dim h As Float = 300dip";
_h = (float) (__c.DipToCurrent((int) (300)));
 //BA.debugLineNum = 703;BA.debugLine="If guiHelpers.gIsLandScape Then h = guiHelpers.gH";
if (_guihelpers._gislandscape /*boolean*/ ) { 
_h = (float) (_guihelpers._gheight /*float*/ *.8);};
 //BA.debugLineNum = 704;BA.debugLine="o1.Show(h,300dip,popUpMemuItems)";
_o1._show /*void*/ (_h,(float) (__c.DipToCurrent((int) (300))),_popupmemuitems);
 //BA.debugLineNum = 706;BA.debugLine="End Sub";
return "";
}
public String  _printersetup_closed() throws Exception{
 //BA.debugLineNum = 590;BA.debugLine="Public Sub PrinterSetup_Closed";
 //BA.debugLineNum = 592;BA.debugLine="If oc.IsConnectionValid Then";
if (_oc._isconnectionvalid /*boolean*/ ) { 
 //BA.debugLineNum = 593;BA.debugLine="Show_toast(\"Trying to connect... This might take";
_show_toast("Trying to connect... This might take a few moments...",(int) (3000));
 //BA.debugLineNum = 594;BA.debugLine="TryPrinterConnection";
_tryprinterconnection();
 };
 //BA.debugLineNum = 597;BA.debugLine="End Sub";
return "";
}
public String  _prompt_exit_reset() throws Exception{
 //BA.debugLineNum = 825;BA.debugLine="Private Sub Prompt_Exit_Reset";
 //BA.debugLineNum = 828;BA.debugLine="PromptExitTwice = False";
_promptexittwice = __c.False;
 //BA.debugLineNum = 829;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 830;BA.debugLine="End Sub";
return "";
}
public String  _rebuild_rightmnu(anywheresoftware.b4a.objects.collections.Map _editdata) throws Exception{
 //BA.debugLineNum = 1086;BA.debugLine="Private Sub Rebuild_RightMnu(editdata As Map)";
 //BA.debugLineNum = 1087;BA.debugLine="Build_RightSideMenu";
_build_rightsidemenu();
 //BA.debugLineNum = 1088;BA.debugLine="End Sub";
return "";
}
public void  _rungcodeonoff_menu(String _fname) throws Exception{
ResumableSub_RunGCodeOnOff_Menu rsub = new ResumableSub_RunGCodeOnOff_Menu(this,_fname);
rsub.resume(ba, null);
}
public static class ResumableSub_RunGCodeOnOff_Menu extends BA.ResumableSub {
public ResumableSub_RunGCodeOnOff_Menu(sadLogic.OctoTouchController.b4xmainpage parent,String _fname) {
this.parent = parent;
this._fname = _fname;
}
sadLogic.OctoTouchController.b4xmainpage parent;
String _fname;
anywheresoftware.b4a.objects.collections.Map _data = null;
String _gc = "";
String _desc = "";
sadLogic.OctoTouchController.dlgmsgbox2 _mb2 = null;
float _w = 0f;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 1227;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = parent.__c.File.ReadMap(parent._xui.getDefaultFolder(),_fname);
 //BA.debugLineNum = 1228;BA.debugLine="Dim gc As String = Data.GetDefault(\"gcode\",\"\")";
_gc = BA.ObjectToString(_data.GetDefault((Object)("gcode"),(Object)("")));
 //BA.debugLineNum = 1229;BA.debugLine="Dim desc As String = Data.GetDefault(\"desc\",\"\")";
_desc = BA.ObjectToString(_data.GetDefault((Object)("desc"),(Object)("")));
 //BA.debugLineNum = 1231;BA.debugLine="If gc.Trim = \"\" Then";
if (true) break;

case 1:
//if
this.state = 4;
if ((_gc.trim()).equals("")) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 1232;BA.debugLine="guiHelpers.Show_toast2(\"No GCODE found\",2600)";
parent._guihelpers._show_toast2 /*String*/ (ba,"No GCODE found",(int) (2600));
 //BA.debugLineNum = 1233;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 1236;BA.debugLine="If Data.GetDefault(\"prompt\",False).As(Boolean) =";

case 4:
//if
this.state = 17;
if ((BA.ObjectToBoolean(_data.GetDefault((Object)("prompt"),(Object)(parent.__c.False))))==parent.__c.True) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 1237;BA.debugLine="Dim mb2 As dlgMsgBox2";
_mb2 = new sadLogic.OctoTouchController.dlgmsgbox2();
 //BA.debugLineNum = 1238;BA.debugLine="Dim w As Float = 400dip";
_w = (float) (parent.__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 1239;BA.debugLine="If guiHelpers.gIsLandScape = False Then w = 90%x";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._guihelpers._gislandscape /*boolean*/ ==parent.__c.False) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
_w = (float) (parent.__c.PerXToCurrent((float) (90),ba));
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 1240;BA.debugLine="mb2.Initialize(B4XPages.MainPage.Root,\"Question\"";
_mb2._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,(float) (parent.__c.DipToCurrent((int) (150))),parent.__c.False);
 //BA.debugLineNum = 1241;BA.debugLine="mb2.NewTextSize = 24";
_mb2._newtextsize /*float*/  = (float) (24);
 //BA.debugLineNum = 1242;BA.debugLine="Wait For (mb2.Show(\"Touch RUN to start:\" & CRLF";
parent.__c.WaitFor("complete", ba, this, _mb2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Touch RUN to start:"+parent.__c.CRLF+_desc,parent._gblconst._mb_icon_question /*String*/ ,"RUN","","CANCEL"));
this.state = 18;
return;
case 18:
//C
this.state = 13;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 1243;BA.debugLine="If res = xui.DialogResponse_Cancel Then";
if (true) break;

case 13:
//if
this.state = 16;
if (_res==parent._xui.DialogResponse_Cancel) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 1244;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 16:
//C
this.state = 17;
;
 if (true) break;

case 17:
//C
this.state = -1;
;
 //BA.debugLineNum = 1248;BA.debugLine="guiHelpers.Show_toast2(\"Runnning...\" & CRLF & des";
parent._guihelpers._show_toast2 /*String*/ (ba,"Runnning..."+parent.__c.CRLF+_desc,(int) (3500));
 //BA.debugLineNum = 1249;BA.debugLine="Send_Gcode(gc)";
parent._send_gcode(_gc);
 //BA.debugLineNum = 1250;BA.debugLine="Wait For Send_Gcode";
parent.__c.WaitFor("send_gcode", ba, this, null);
this.state = 19;
return;
case 19:
//C
this.state = -1;
;
 //BA.debugLineNum = 1252;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _runhttponoff_menu(String _fname) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
sadLogic.OctoTouchController.dlgonoffctrl _o1 = null;
 //BA.debugLineNum = 1211;BA.debugLine="Private Sub RunHTTPOnOff_Menu(fname As String)";
 //BA.debugLineNum = 1212;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = __c.File.ReadMap(_xui.getDefaultFolder(),_fname);
 //BA.debugLineNum = 1213;BA.debugLine="If  Data.GetDefault(\"tgl\",False).As(Boolean) Then";
if ((BA.ObjectToBoolean(_data.GetDefault((Object)("tgl"),(Object)(__c.False))))) { 
 //BA.debugLineNum = 1214;BA.debugLine="oMasterController.cn.PostRequest2(Data.Get(\"ipon";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (BA.ObjectToString(_data.Get((Object)("ipon"))),"");
 //BA.debugLineNum = 1215;BA.debugLine="guiHelpers.Show_toast2(\"Toggle Command Sent\",130";
_guihelpers._show_toast2 /*String*/ (ba,"Toggle Command Sent",(int) (1300));
 //BA.debugLineNum = 1216;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 1218;BA.debugLine="Dim o1 As dlgOnOffCtrl";
_o1 = new sadLogic.OctoTouchController.dlgonoffctrl();
 //BA.debugLineNum = 1219;BA.debugLine="pObjCurrentDlg1 = o1.Initialize(Data.GetDefault(\"";
_pobjcurrentdlg1 = _o1._initialize /*Object*/ (ba,BA.ObjectToString(_data.GetDefault((Object)("desc"),(Object)("On / Off"))));
 //BA.debugLineNum = 1220;BA.debugLine="o1.Data = Data";
_o1._data /*anywheresoftware.b4a.objects.collections.Map*/  = _data;
 //BA.debugLineNum = 1221;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 //BA.debugLineNum = 1222;BA.debugLine="End Sub";
return "";
}
public String  _screenoff_2front() throws Exception{
 //BA.debugLineNum = 798;BA.debugLine="Private Sub ScreenOff_2Front";
 //BA.debugLineNum = 799;BA.debugLine="pnlScreenOff.BringToFront";
_pnlscreenoff.BringToFront();
 //BA.debugLineNum = 800;BA.debugLine="End Sub";
return "";
}
public void  _send_gcode(String _code) throws Exception{
ResumableSub_Send_Gcode rsub = new ResumableSub_Send_Gcode(this,_code);
rsub.resume(ba, null);
}
public static class ResumableSub_Send_Gcode extends BA.ResumableSub {
public ResumableSub_Send_Gcode(sadLogic.OctoTouchController.b4xmainpage parent,String _code) {
this.parent = parent;
this._code = _code;
}
sadLogic.OctoTouchController.b4xmainpage parent;
String _code;
String[] _cd = null;
String _s = "";
String[] group4;
int index4;
int groupLen4;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 1256;BA.debugLine="If strHelpers.IsNullOrEmpty(code.Trim) Then Retur";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,_code.trim())) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 1263;BA.debugLine="If code.Contains(CRLF) Then";
if (true) break;

case 7:
//if
this.state = 28;
if (_code.contains(parent.__c.CRLF)) { 
this.state = 9;
}else {
this.state = 21;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 1264;BA.debugLine="Dim cd() As String = Regex.Split(CRLF, code)";
_cd = parent.__c.Regex.Split(parent.__c.CRLF,_code);
 //BA.debugLineNum = 1266;BA.debugLine="For Each s As String In cd";
if (true) break;

case 10:
//for
this.state = 19;
group4 = _cd;
index4 = 0;
groupLen4 = group4.length;
this.state = 29;
if (true) break;

case 29:
//C
this.state = 19;
if (index4 < groupLen4) {
this.state = 12;
_s = group4[index4];}
if (true) break;

case 30:
//C
this.state = 29;
index4++;
if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 1267;BA.debugLine="s = CleanGcodeString(s)";
_s = parent._cleangcodestring(_s);
 //BA.debugLineNum = 1268;BA.debugLine="If strHelpers.IsNullOrEmpty(s) Then Continue";
if (true) break;

case 13:
//if
this.state = 18;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,_s)) { 
this.state = 15;
;}if (true) break;

case 15:
//C
this.state = 18;
this.state = 30;
if (true) break;;
if (true) break;

case 18:
//C
this.state = 30;
;
 //BA.debugLineNum = 1272;BA.debugLine="B4XPages.MainPage.oMasterController.cn.PostRequ";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cpost_gcode_command /*String*/ .replace("!CMD!",_s.toUpperCase()));
 //BA.debugLineNum = 1274;BA.debugLine="Sleep(250) '--- 1/4 second between";
parent.__c.Sleep(ba,this,(int) (250));
this.state = 31;
return;
case 31:
//C
this.state = 30;
;
 if (true) break;
if (true) break;

case 19:
//C
this.state = 28;
;
 if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 1277;BA.debugLine="code = CleanGcodeString(code)";
_code = parent._cleangcodestring(_code);
 //BA.debugLineNum = 1278;BA.debugLine="If strHelpers.IsNullOrEmpty(code) Then Return";
if (true) break;

case 22:
//if
this.state = 27;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,_code)) { 
this.state = 24;
;}if (true) break;

case 24:
//C
this.state = 27;
if (true) return ;
if (true) break;

case 27:
//C
this.state = 28;
;
 //BA.debugLineNum = 1282;BA.debugLine="B4XPages.MainPage.oMasterController.cn.PostReque";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cpost_gcode_command /*String*/ .replace("!CMD!",_code));
 if (true) break;

case 28:
//C
this.state = -1;
;
 //BA.debugLineNum = 1286;BA.debugLine="Return";
if (true) return ;
 //BA.debugLineNum = 1288;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _show_toast(String _msg,int _ms) throws Exception{
 //BA.debugLineNum = 485;BA.debugLine="Public Sub Show_toast(msg As String, ms As Int)";
 //BA.debugLineNum = 486;BA.debugLine="toast.DurationMs = ms";
_toast._durationms /*int*/  = _ms;
 //BA.debugLineNum = 487;BA.debugLine="toast.Show($\"[TextSize=${mToastTxtSize}][b][FontA";
_toast._show /*void*/ (("[TextSize="+__c.SmartStringFormatter("",(Object)(_mtoasttxtsize))+"][b][FontAwesome=0xF05A/]  "+__c.SmartStringFormatter("",(Object)(_msg))+"[/b][/TextSize]"));
 //BA.debugLineNum = 488;BA.debugLine="End Sub";
return "";
}
public String  _showpreheatmenu_all() throws Exception{
 //BA.debugLineNum = 851;BA.debugLine="Public Sub ShowPreHeatMenu_All";
 //BA.debugLineNum = 852;BA.debugLine="ShowPreHeatMenu_All2(\"Pre-Heat\")";
_showpreheatmenu_all2("Pre-Heat");
 //BA.debugLineNum = 853;BA.debugLine="End Sub";
return "";
}
public String  _showpreheatmenu_all2(String _titletxt) throws Exception{
sadLogic.OctoTouchController.dlglistbox _ht = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
Object _title = null;
float _w = 0f;
float _h = 0f;
 //BA.debugLineNum = 854;BA.debugLine="Public Sub ShowPreHeatMenu_All2(titleTxt As String";
 //BA.debugLineNum = 855;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 856;BA.debugLine="If oc.isConnected = False Or oMasterController.ma";
if (_oc._isconnected /*boolean*/ ==__c.False || _omastercontroller._mapallheatingoptions /*anywheresoftware.b4a.objects.collections.Map*/ .IsInitialized()==__c.False) { 
 //BA.debugLineNum = 857;BA.debugLine="guiHelpers.Show_toast(gblConst.NOT_CONNECTED,100";
_guihelpers._show_toast /*String*/ (ba,_gblconst._not_connected /*String*/ ,(int) (1000));
 //BA.debugLineNum = 858;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 860;BA.debugLine="Dim ht As dlgListbox";
_ht = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 861;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 862;BA.debugLine="Dim title As Object = cs.Initialize.Typeface(Type";
_title = (Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf2ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("  "+_titletxt)).PopAll().getObject());
 //BA.debugLineNum = 865;BA.debugLine="pObjPreHeatDlg1 = ht.Initialize(title,Me,\"TempCha";
_pobjpreheatdlg1 = (sadLogic.OctoTouchController.dlglistbox)(_ht._initialize /*Object*/ (ba,_title,this,"TempChange_Presets",(Object)(_pobjpreheatdlg1)));
 //BA.debugLineNum = 866;BA.debugLine="Dim w As Float = IIf(guiHelpers.gIsLandScape,450d";
_w = (float)(BA.ObjectToNumber(((_guihelpers._gislandscape /*boolean*/ ) ? ((Object)(__c.DipToCurrent((int) (450)))) : ((Object)(_guihelpers._gwidth /*float*/ -__c.DipToCurrent((int) (10)))))));
 //BA.debugLineNum = 867;BA.debugLine="Dim h As Float = IIf(guiHelpers.gIsLandScape,guiH";
_h = (float)(BA.ObjectToNumber(((_guihelpers._gislandscape /*boolean*/ ) ? ((Object)(_guihelpers._maxverticalheight_landscape /*float*/ (ba))) : ((Object)(_guihelpers._gheight /*float*/ *.7)))));
 //BA.debugLineNum = 869;BA.debugLine="BuildPreHeatMenu";
_buildpreheatmenu();
 //BA.debugLineNum = 870;BA.debugLine="ht.Show(h,w,mapMasterPreHeaterMenu)";
_ht._show /*void*/ (_h,_w,_mapmasterpreheatermenu);
 //BA.debugLineNum = 871;BA.debugLine="End Sub";
return "";
}
public String  _switch_pages(String _action) throws Exception{
 //BA.debugLineNum = 441;BA.debugLine="Public Sub Switch_Pages(action As String)";
 //BA.debugLineNum = 444;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 447;BA.debugLine="If oPageCurrent <> Null Then";
if (_opagecurrent!= null) { 
 //BA.debugLineNum = 448;BA.debugLine="CallSub(oPageCurrent,\"Lost_Focus\")";
__c.CallSubNew(ba,_opagecurrent,"Lost_Focus");
 };
 //BA.debugLineNum = 452;BA.debugLine="btnPageAction.Text = Chr(0xE5C4)  '--- back butto";
_btnpageaction.setText(BA.ObjectToCharSequence(__c.Chr(((int)0xe5c4))));
 //BA.debugLineNum = 454;BA.debugLine="Select Case action";
switch (BA.switchObjectToInt(_action,_gblconst._page_menu /*String*/ ,_gblconst._page_files /*String*/ ,_gblconst._page_printing /*String*/ ,_gblconst._page_movement /*String*/ )) {
case 0: {
 //BA.debugLineNum = 456;BA.debugLine="If oPageMenu.IsInitialized = False Then oPageMe";
if (_opagemenu.IsInitialized /*boolean*/ ()==__c.False) { 
_opagemenu._initialize /*String*/ (ba,_pnlmenu,"Switch_Pages");};
 //BA.debugLineNum = 458;BA.debugLine="If oPageCurrent = Null Or oPageCurrent <> oPage";
if (_opagecurrent== null || (_opagecurrent).equals((Object)(_opagemenu)) == false) { 
 //BA.debugLineNum = 459;BA.debugLine="oPageCurrent = oPageMenu";
_opagecurrent = (Object)(_opagemenu);
 //BA.debugLineNum = 460;BA.debugLine="btnPageAction.Text = Chr(0xE5D2)";
_btnpageaction.setText(BA.ObjectToCharSequence(__c.Chr(((int)0xe5d2))));
 }else {
 //BA.debugLineNum = 462;BA.debugLine="Return";
if (true) return "";
 };
 break; }
case 1: {
 //BA.debugLineNum = 466;BA.debugLine="If oPageFiles.IsInitialized = False Then oPageF";
if (_opagefiles.IsInitialized /*boolean*/ ()==__c.False) { 
_opagefiles._initialize /*String*/ (ba,_pnlfiles,"");};
 //BA.debugLineNum = 467;BA.debugLine="oPageCurrent = oPageFiles";
_opagecurrent = (Object)(_opagefiles);
 break; }
case 2: {
 //BA.debugLineNum = 470;BA.debugLine="If oPagePrinting.IsInitialized = False Then oPa";
if (_opageprinting.IsInitialized /*boolean*/ ()==__c.False) { 
_opageprinting._initialize /*String*/ (ba,_pnlprinting,"");};
 //BA.debugLineNum = 471;BA.debugLine="oPageCurrent = oPagePrinting";
_opagecurrent = (Object)(_opageprinting);
 break; }
case 3: {
 //BA.debugLineNum = 474;BA.debugLine="If oPageMovement.IsInitialized = False Then oPa";
if (_opagemovement.IsInitialized /*boolean*/ ()==__c.False) { 
_opagemovement._initialize /*String*/ (ba,_pnlmovement,"");};
 //BA.debugLineNum = 475;BA.debugLine="oPageCurrent = oPageMovement";
_opagecurrent = (Object)(_opagemovement);
 break; }
}
;
 //BA.debugLineNum = 480;BA.debugLine="CallSub(oPageCurrent,\"Set_Focus\")";
__c.CallSubNew(ba,_opagecurrent,"Set_Focus");
 //BA.debugLineNum = 482;BA.debugLine="End Sub";
return "";
}
public String  _tempchange_presets(String _selectedmsg,Object _tag) throws Exception{
String _msg = "";
String _gettemp = "";
int _startndx = 0;
int _endndx = 0;
sadLogic.OctoTouchController.heaterroutines _oo1 = null;
sadLogic.OctoTouchController.heaterroutines _oo2 = null;
String _toolmsg = "";
String _bedmsg = "";
 //BA.debugLineNum = 889;BA.debugLine="Public Sub TempChange_Presets(selectedMsg As Strin";
 //BA.debugLineNum = 894;BA.debugLine="If selectedMsg.Length = 0 Then Return";
if (_selectedmsg.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 896;BA.debugLine="If selectedMsg = \"alloff\" Then";
if ((_selectedmsg).equals("alloff")) { 
 //BA.debugLineNum = 902;BA.debugLine="oMasterController.AllHeaters_Off";
_omastercontroller._allheaters_off /*String*/ ();
 //BA.debugLineNum = 905;BA.debugLine="Show_toast(\"Tool / Bed Off\",1200)";
_show_toast("Tool / Bed Off",(int) (1200));
 //BA.debugLineNum = 906;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 911;BA.debugLine="Dim msg, getTemp As String";
_msg = "";
_gettemp = "";
 //BA.debugLineNum = 912;BA.debugLine="Dim startNDX, endNDX As Int";
_startndx = 0;
_endndx = 0;
 //BA.debugLineNum = 914;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,(_selectedmsg).equals("bedoff"),(_selectedmsg).equals("tooloff"),(_selectedmsg).equals("evb"),(_selectedmsg).equals("evt"),_selectedmsg.contains("Tool") && __c.Not(_selectedmsg.contains("Bed")),_selectedmsg.contains("Bed") && __c.Not(_selectedmsg.contains("Tool")))) {
case 0: {
 //BA.debugLineNum = 920;BA.debugLine="oMasterController.CN.PostRequest(oc.cCMD_SET_BE";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",BA.NumberToString(0)));
 //BA.debugLineNum = 922;BA.debugLine="msg = \"Bed Off\"";
_msg = "Bed Off";
 break; }
case 1: {
 //BA.debugLineNum = 928;BA.debugLine="oMasterController.cn.PostRequest(oc.cCMD_SET_TO";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",BA.NumberToString(0)).replace("!VAL1!",BA.NumberToString(0)));
 //BA.debugLineNum = 930;BA.debugLine="msg = \"Tool Off\"";
_msg = "Tool Off";
 break; }
case 2: {
 //BA.debugLineNum = 933;BA.debugLine="Dim oo1 As HeaterRoutines : oo1.Initialize";
_oo1 = new sadLogic.OctoTouchController.heaterroutines();
 //BA.debugLineNum = 933;BA.debugLine="Dim oo1 As HeaterRoutines : oo1.Initialize";
_oo1._initialize /*String*/ (ba);
 //BA.debugLineNum = 934;BA.debugLine="oo1.ChangeTempBed";
_oo1._changetempbed /*String*/ ();
 break; }
case 3: {
 //BA.debugLineNum = 937;BA.debugLine="Dim oo2 As HeaterRoutines : oo2.Initialize";
_oo2 = new sadLogic.OctoTouchController.heaterroutines();
 //BA.debugLineNum = 937;BA.debugLine="Dim oo2 As HeaterRoutines : oo2.Initialize";
_oo2._initialize /*String*/ (ba);
 //BA.debugLineNum = 938;BA.debugLine="oo2.ChangeTempTool";
_oo2._changetemptool /*String*/ ();
 break; }
case 4: {
 //BA.debugLineNum = 942;BA.debugLine="startNDX = selectedMsg.IndexOf(\": \")";
_startndx = _selectedmsg.indexOf(": ");
 //BA.debugLineNum = 943;BA.debugLine="endNDX   = selectedMsg.IndexOf(gblConst.DEGREE_";
_endndx = _selectedmsg.indexOf(_gblconst._degree_symbol /*String*/ );
 //BA.debugLineNum = 944;BA.debugLine="getTemp  = selectedMsg.SubString2(startNDX + 2,";
_gettemp = _selectedmsg.substring((int) (_startndx+2),_endndx).trim();
 //BA.debugLineNum = 948;BA.debugLine="oMasterController.cn.PostRequest(oc.cCMD_SET_TO";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",BA.NumberToString(((int)(Double.parseDouble(_gettemp))))));
 //BA.debugLineNum = 950;BA.debugLine="msg = selectedMsg.Replace(\"Set\",\"Setting\")";
_msg = _selectedmsg.replace("Set","Setting");
 break; }
case 5: {
 //BA.debugLineNum = 954;BA.debugLine="startNDX = selectedMsg.IndexOf(\": \")";
_startndx = _selectedmsg.indexOf(": ");
 //BA.debugLineNum = 955;BA.debugLine="endNDX   = selectedMsg.IndexOf(gblConst.DEGREE_";
_endndx = _selectedmsg.indexOf(_gblconst._degree_symbol /*String*/ );
 //BA.debugLineNum = 956;BA.debugLine="getTemp  = selectedMsg.SubString2(startNDX + 2,";
_gettemp = _selectedmsg.substring((int) (_startndx+2),_endndx).trim();
 //BA.debugLineNum = 960;BA.debugLine="oMasterController.CN.PostRequest(oc.cCMD_SET_BE";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",BA.NumberToString(((int)(Double.parseDouble(_gettemp))))));
 //BA.debugLineNum = 962;BA.debugLine="msg = selectedMsg.Replace(\"Set\",\"Setting\")";
_msg = _selectedmsg.replace("Set","Setting");
 break; }
default: {
 //BA.debugLineNum = 966;BA.debugLine="Dim toolMSG As String = Regex.Split(\"/\",selecte";
_toolmsg = __c.Regex.Split("/",_selectedmsg)[(int) (0)];
 //BA.debugLineNum = 967;BA.debugLine="Dim bedMSG  As String = Regex.Split(\"/\",selecte";
_bedmsg = __c.Regex.Split("/",_selectedmsg)[(int) (1)];
 //BA.debugLineNum = 969;BA.debugLine="startNDX = toolMSG.IndexOf(\": \")";
_startndx = _toolmsg.indexOf(": ");
 //BA.debugLineNum = 970;BA.debugLine="endNDX   = toolMSG.IndexOf(gblConst.DEGREE_SYMB";
_endndx = _toolmsg.indexOf(_gblconst._degree_symbol /*String*/ );
 //BA.debugLineNum = 971;BA.debugLine="getTemp  = toolMSG.SubString2(startNDX + 2,endN";
_gettemp = _toolmsg.substring((int) (_startndx+2),_endndx).trim();
 //BA.debugLineNum = 975;BA.debugLine="oMasterController.cn.PostRequest(oc.cCMD_SET_TO";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",BA.NumberToString(((int)(Double.parseDouble(_gettemp))))));
 //BA.debugLineNum = 978;BA.debugLine="startNDX = bedMSG.IndexOf(\": \")";
_startndx = _bedmsg.indexOf(": ");
 //BA.debugLineNum = 979;BA.debugLine="endNDX   = bedMSG.IndexOf(gblConst.DEGREE_SYMBO";
_endndx = _bedmsg.indexOf(_gblconst._degree_symbol /*String*/ );
 //BA.debugLineNum = 980;BA.debugLine="getTemp  = bedMSG.SubString2(startNDX + 2,endND";
_gettemp = _bedmsg.substring((int) (_startndx+2),_endndx).trim();
 //BA.debugLineNum = 984;BA.debugLine="oMasterController.CN.PostRequest(oc.cCMD_SET_BE";
_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",BA.NumberToString(((int)(Double.parseDouble(_gettemp))))));
 //BA.debugLineNum = 986;BA.debugLine="msg = selectedMsg.Replace(\"Set\",\"Setting\")";
_msg = _selectedmsg.replace("Set","Setting");
 break; }
}
;
 //BA.debugLineNum = 990;BA.debugLine="If msg.Length <> 0 Then Show_toast(msg,3000)";
if (_msg.length()!=0) { 
_show_toast(_msg,(int) (3000));};
 //BA.debugLineNum = 992;BA.debugLine="End Sub";
return "";
}
public String  _tryprinterconnection() throws Exception{
 //BA.debugLineNum = 310;BA.debugLine="Private Sub TryPrinterConnection";
 //BA.debugLineNum = 312;BA.debugLine="If oMasterController.IsInitialized = False Then";
if (_omastercontroller.IsInitialized /*boolean*/ ()==__c.False) { 
 //BA.debugLineNum = 313;BA.debugLine="oMasterController.Initialize";
_omastercontroller._initialize /*String*/ (ba);
 };
 //BA.debugLineNum = 315;BA.debugLine="If fnc.ReadConnectionFile(oMasterController.CN) =";
if (_fnc._readconnectionfile /*boolean*/ (ba,_omastercontroller._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ())==__c.False) { 
 //BA.debugLineNum = 317;BA.debugLine="pDlgPrinterSetup.Initialize(\"Printer Connection\"";
_pdlgprintersetup._initialize /*Object*/ (ba,"Printer Connection","PrinterSetup_Closed");
 //BA.debugLineNum = 318;BA.debugLine="pDlgPrinterSetup.Show(True)";
_pdlgprintersetup._show /*void*/ (__c.True);
 }else {
 //BA.debugLineNum = 320;BA.debugLine="If oc.IsConnectionValid Then";
if (_oc._isconnectionvalid /*boolean*/ ) { 
 //BA.debugLineNum = 321;BA.debugLine="oMasterController.SetCallbackTargets(Me,\"Update";
_omastercontroller._setcallbacktargets /*String*/ (this,"Update_Printer_Temps","Update_Printer_Status","Update_Printer_Btns");
 //BA.debugLineNum = 322;BA.debugLine="oMasterController.Start";
_omastercontroller._start /*String*/ ();
 //BA.debugLineNum = 323;BA.debugLine="oMasterController.oWS.pParserWO.EventAdd(\"Metad";
_omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.websocketparse*/ ._eventadd /*String*/ ("MetadataAnalysisFinished",this,"ev_file_change");
 //BA.debugLineNum = 324;BA.debugLine="oMasterController.oWS.pParserWO.EventAdd(\"FileR";
_omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.websocketparse*/ ._eventadd /*String*/ ("FileRemoved",this,"ev_file_del");
 //BA.debugLineNum = 325;BA.debugLine="oMasterController.oWS.pParserWO.EventAdd(\"Filam";
_omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.websocketparse*/ ._eventadd /*String*/ ("FilamentChange",this,"ev_filament_change_rec");
 //BA.debugLineNum = 326;BA.debugLine="oMasterController.oWS.pParserWO.EventAdd(\"Print";
_omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.websocketparse*/ ._eventadd /*String*/ ("PrintStarted",this,"ev_print_started");
 //BA.debugLineNum = 327;BA.debugLine="oMasterController.oWS.pParserWO.EventAdd(\"Print";
_omastercontroller._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.websocketparse*/ ._eventadd /*String*/ ("PrintFailed",this,"ev_print_done");
 //BA.debugLineNum = 332;BA.debugLine="If Main.kvs.ContainsKey(gblConst.IS_OCTO_KLIPPY";
if (_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._containskey /*boolean*/ (_gblconst._is_octo_klippy /*String*/ )==__c.False) { 
 //BA.debugLineNum = 333;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Is";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"Is_OctoKlipper",(int) (800));
 }else {
 //BA.debugLineNum = 335;BA.debugLine="oc.Klippy = Main.kvs.Get(gblConst.IS_OCTO_KLIP";
_oc._klippy /*boolean*/  = BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (_gblconst._is_octo_klippy /*String*/ ));
 };
 };
 };
 //BA.debugLineNum = 341;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_btns() throws Exception{
 //BA.debugLineNum = 420;BA.debugLine="Public Sub Update_Printer_Btns";
 //BA.debugLineNum = 423;BA.debugLine="If SubExists(oPageCurrent,\"Update_Printer_Btns\")";
if (__c.SubExists(ba,_opagecurrent,"Update_Printer_Btns")) { 
 //BA.debugLineNum = 424;BA.debugLine="CallSub(oPageCurrent,\"Update_Printer_Btns\")";
__c.CallSubNew(ba,_opagecurrent,"Update_Printer_Btns");
 };
 //BA.debugLineNum = 427;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_status() throws Exception{
 //BA.debugLineNum = 369;BA.debugLine="Public Sub Update_Printer_Status";
 //BA.debugLineNum = 372;BA.debugLine="If oc.isConnected Then";
if (_oc._isconnected /*boolean*/ ) { 
 //BA.debugLineNum = 373;BA.debugLine="If guiHelpers.gIsLandScape = False Then lblStatu";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False) { 
_lblstatus.setTextSize((float) (32));}
else {
_lblstatus.setTextSize((float) (28));};
 //BA.debugLineNum = 377;BA.debugLine="lblStatus.Text = oc.FormatedStatus";
_lblstatus.setText(BA.ObjectToCharSequence(_oc._formatedstatus /*String*/ ));
 //BA.debugLineNum = 381;BA.debugLine="If oPageCurrent Is pageMovement Or oPageCurrent";
if (_opagecurrent instanceof sadLogic.OctoTouchController.pagemovement || _opagecurrent instanceof sadLogic.OctoTouchController.pagefiles) { 
 //BA.debugLineNum = 382;BA.debugLine="If guiHelpers.gIsLandScape = False Then";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 383;BA.debugLine="lblStatus.TextSize = 18";
_lblstatus.setTextSize((float) (18));
 }else {
 //BA.debugLineNum = 385;BA.debugLine="lblStatus.TextSize = 22";
_lblstatus.setTextSize((float) (22));
 };
 //BA.debugLineNum = 391;BA.debugLine="lblStatus.Text = csHdr.Initialize.Append(lblSta";
_lblstatus.setText(BA.ObjectToCharSequence(_cshdr.Initialize().Append(BA.ObjectToCharSequence(_lblstatus.getText())).Append(BA.ObjectToCharSequence("  ")).Append(BA.ObjectToCharSequence(_oc._formatedtemps /*Object*/ )).PopAll().getObject()));
 };
 }else {
 //BA.debugLineNum = 402;BA.debugLine="lblStatus.TextSize = 30";
_lblstatus.setTextSize((float) (30));
 //BA.debugLineNum = 403;BA.debugLine="lblStatus.Text = gblConst.NOT_CONNECTED";
_lblstatus.setText(BA.ObjectToCharSequence(_gblconst._not_connected /*String*/ ));
 };
 //BA.debugLineNum = 407;BA.debugLine="If SubExists(oPageCurrent,\"Update_Printer_Stats\")";
if (__c.SubExists(ba,_opagecurrent,"Update_Printer_Stats")) { 
 //BA.debugLineNum = 408;BA.debugLine="CallSub(oPageCurrent,\"Update_Printer_Stats\")";
__c.CallSubNew(ba,_opagecurrent,"Update_Printer_Stats");
 };
 //BA.debugLineNum = 418;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_temps() throws Exception{
 //BA.debugLineNum = 360;BA.debugLine="Public Sub Update_Printer_Temps";
 //BA.debugLineNum = 363;BA.debugLine="If SubExists(oPageCurrent,\"Update_Printer_Temps\")";
if (__c.SubExists(ba,_opagecurrent,"Update_Printer_Temps")) { 
 //BA.debugLineNum = 364;BA.debugLine="CallSubDelayed(oPageCurrent,\"Update_Printer_Temp";
__c.CallSubDelayed(ba,_opagecurrent,"Update_Printer_Temps");
 };
 //BA.debugLineNum = 367;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
if (BA.fastSubCompare(sub, "BTNPAGEACTION_CLICK"))
	return _btnpageaction_click();
if (BA.fastSubCompare(sub, "BUILD_RIGHTSIDEMENU"))
	return _build_rightsidemenu();
if (BA.fastSubCompare(sub, "COOLING_FAN"))
	return _cooling_fan();
if (BA.fastSubCompare(sub, "FILESCHECKCHANGE"))
	return _filescheckchange();
if (BA.fastSubCompare(sub, "HIDESPLASH_STARTUP"))
	return _hidesplash_startup();
if (BA.fastSubCompare(sub, "POPUPFUNCTIONOPTIONSMNU"))
	return _popupfunctionoptionsmnu();
if (BA.fastSubCompare(sub, "POPUPPLUGINOPTIONMENU"))
	return _popuppluginoptionmenu();
if (BA.fastSubCompare(sub, "PROMPT_EXIT_RESET"))
	return _prompt_exit_reset();
if (BA.fastSubCompare(sub, "SCREENOFF_2FRONT"))
	return _screenoff_2front();
if (BA.fastSubCompare(sub, "SHOW_TOAST"))
	return _show_toast((String) args[0], ((Number)args[1]).intValue());
if (BA.fastSubCompare(sub, "SHOWPREHEATMENU_ALL"))
	return _showpreheatmenu_all();
if (BA.fastSubCompare(sub, "SWITCH_PAGES"))
	return _switch_pages((String) args[0]);
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_BTNS"))
	return _update_printer_btns();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_TEMPS"))
	return _update_printer_temps();
return BA.SubDelegator.SubNotFound;
}
}
