package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgsetupmain extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgsetupmain");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgsetupmain.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.sadpreferencesdialog _pf = null;
public sadLogic.HomeCentral.sadpreferencesdialoghelper _prefhelper = null;
public String _oldtheme = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private pf As sadPreferencesDialog";
_pf = new sadLogic.HomeCentral.sadpreferencesdialog();
 //BA.debugLineNum = 11;BA.debugLine="Private prefHelper As sadPreferencesDialogHelper";
_prefhelper = new sadLogic.HomeCentral.sadpreferencesdialoghelper();
 //BA.debugLineNum = 12;BA.debugLine="Private oldTheme As String";
_oldtheme = "";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _createdefaultfile() throws Exception{
b4a.example.dateutils._period _d1 = null;
b4a.example.dateutils._period _d2 = null;
 //BA.debugLineNum = 21;BA.debugLine="public Sub CreateDefaultFile";
 //BA.debugLineNum = 23;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.FILE_MA";
if (__c.File.Exists(_xui.getDefaultFolder(),_gblconst._file_main_setup /*String*/ )==__c.False) { 
 //BA.debugLineNum = 24;BA.debugLine="Dim d1,d2 As Period";
_d1 = new b4a.example.dateutils._period();
_d2 = new b4a.example.dateutils._period();
 //BA.debugLineNum = 25;BA.debugLine="d1.Hours = 6 : d1.Minutes = 45";
_d1.Hours = (int) (6);
 //BA.debugLineNum = 25;BA.debugLine="d1.Hours = 6 : d1.Minutes = 45";
_d1.Minutes = (int) (45);
 //BA.debugLineNum = 26;BA.debugLine="d2.Hours = 19 : d2.Minutes = 30";
_d2.Hours = (int) (19);
 //BA.debugLineNum = 26;BA.debugLine="d2.Hours = 19 : d2.Minutes = 30";
_d2.Minutes = (int) (30);
 //BA.debugLineNum = 29;BA.debugLine="objHelpers.Map2Disk2(xui.DefaultFolder, gblConst";
_objhelpers._map2disk2 /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._file_main_setup /*String*/ ,__c.createMap(new Object[] {(Object)(_gblconst._keys_main_setup_auto_boot /*String*/ ),(Object)(__c.False),(Object)(_gblconst._keys_main_setup_scrn_off_time /*String*/ ),(Object)(120),(Object)(_gblconst._keys_main_setup_scrn_ctrl_morning_time /*String*/ ),(Object)(_d1),(Object)(_gblconst._keys_main_setup_scrn_ctrl_evening_time /*String*/ ),(Object)(_d2),(Object)(_gblconst._keys_main_setup_scrn_ctrl_on /*String*/ ),(Object)(__c.False),(Object)(_gblconst._keys_main_setup_page_weather /*String*/ ),(Object)(__c.True),(Object)(_gblconst._keys_main_setup_page_photo /*String*/ ),(Object)(__c.False),(Object)(_gblconst._keys_main_setup_page_calc /*String*/ ),(Object)(__c.True),(Object)(_gblconst._keys_main_setup_page_conv /*String*/ ),(Object)(__c.True),(Object)(_gblconst._keys_main_setup_page_timers /*String*/ ),(Object)(__c.True),(Object)(_gblconst._keys_main_setup_page_web /*String*/ ),(Object)(__c.False),(Object)(_gblconst._keys_main_setup_scrn_check_4_updates /*String*/ ),(Object)(__c.False),(Object)(_gblconst._keys_main_setup_page_theme /*String*/ ),(Object)("Red")}));
 };
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _dlggeneral_beforedialogdisplayed(Object _template) throws Exception{
 //BA.debugLineNum = 139;BA.debugLine="Private Sub dlgGeneral_BeforeDialogDisplayed (Temp";
 //BA.debugLineNum = 140;BA.debugLine="prefHelper.SkinDialog(Template)";
_prefhelper._skindialog /*String*/ (_template);
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public boolean  _dlggeneral_isvalid(anywheresoftware.b4a.objects.collections.Map _tempdata) throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Private Sub dlgGeneral_IsValid (TempData As Map) A";
 //BA.debugLineNum = 119;BA.debugLine="Return True '--- all is good!";
if (true) return __c.True;
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return false;
}
public boolean  _doesmenuneedrebuild(anywheresoftware.b4a.objects.collections.Map _newdata,anywheresoftware.b4a.objects.collections.Map _olddata) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Private Sub DoesMenuNeedRebuild(newData As Map, Ol";
 //BA.debugLineNum = 51;BA.debugLine="Return _ 		(newData.Get(gblConst.KEYS_MAIN_SETUP_";
if (true) return ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_weather /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_weather /*String*/ ))) == false) || ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_photo /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_photo /*String*/ ))) == false) || ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_calc /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_calc /*String*/ ))) == false) || ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_conv /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_conv /*String*/ ))) == false) || ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_web /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_web /*String*/ ))) == false) || ((_newdata.Get((Object)(_gblconst._keys_main_setup_page_timers /*String*/ ))).equals(_olddata.Get((Object)(_gblconst._keys_main_setup_page_timers /*String*/ ))) == false);
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return false;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.sadpreferencesdialog _pfdlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize(pfdlg As sadPreferencesDialo";
 //BA.debugLineNum = 17;BA.debugLine="pf = pfdlg";
_pf = _pfdlg;
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _processautobootflag(boolean _enabled) throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Private Sub ProcessAutoBootFlag(Enabled As Boolean";
 //BA.debugLineNum = 146;BA.debugLine="If Enabled Then";
if (_enabled) { 
 //BA.debugLineNum = 147;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.FILE_A";
if (__c.File.Exists(_xui.getDefaultFolder(),_gblconst._file_auto_start_flag /*String*/ )) { 
if (true) return "";};
 //BA.debugLineNum = 148;BA.debugLine="File.WriteString(xui.DefaultFolder,gblConst.FILE";
__c.File.WriteString(_xui.getDefaultFolder(),_gblconst._file_auto_start_flag /*String*/ ,"boot");
 }else {
 //BA.debugLineNum = 150;BA.debugLine="fileHelpers.SafeKill(xui.DefaultFolder,gblConst.";
_filehelpers._safekill /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._file_auto_start_flag /*String*/ );
 };
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgsetupmain parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetupmain parent;
anywheresoftware.b4a.objects.collections.Map _data = null;
anywheresoftware.b4a.objects.collections.Map _prevdata = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;
int _gohome = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 64;BA.debugLine="oldTheme = config.MainSetupData.Get(gblConst.KEYS";
parent._oldtheme = BA.ObjectToString(parent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent._gblconst._keys_main_setup_page_theme /*String*/ )));
 //BA.debugLineNum = 66;BA.debugLine="pf.Initialize(mpage.root, \"General Settings\", 460";
parent._pf._initialize /*String*/ (ba,parent._mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,(Object)("General Settings"),(int) (460),(int) (440));
 //BA.debugLineNum = 68;BA.debugLine="pf.LoadFromJson(File.ReadString(File.DirAssets,\"s";
parent._pf._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"setup_main.json"));
 //BA.debugLineNum = 69;BA.debugLine="pf.SetEventsListener(Me,\"dlgGeneral\")";
parent._pf._seteventslistener /*String*/ (parent,"dlgGeneral");
 //BA.debugLineNum = 71;BA.debugLine="prefHelper.Initialize(pf)";
parent._prefhelper._initialize /*String*/ (ba,parent._pf);
 //BA.debugLineNum = 72;BA.debugLine="Dim data As Map = prefHelper.MapFromDisk2(xui.Def";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = parent._prefhelper._mapfromdisk2 /*anywheresoftware.b4a.objects.collections.Map*/ (parent._xui.getDefaultFolder(),parent._gblconst._file_main_setup /*String*/ );
 //BA.debugLineNum = 73;BA.debugLine="Dim PrevData As Map = objHelpers.CopyObject(data)";
_prevdata = new anywheresoftware.b4a.objects.collections.Map();
_prevdata = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(parent._objhelpers._copyobject /*Object*/ (ba,(Object)(_data.getObject()))));
 //BA.debugLineNum = 75;BA.debugLine="prefHelper.pDefaultFontSize = 18";
parent._prefhelper._pdefaultfontsize /*float*/  = (float) (18);
 //BA.debugLineNum = 76;BA.debugLine="prefHelper.ThemePrefDialogForm";
parent._prefhelper._themeprefdialogform /*String*/ ();
 //BA.debugLineNum = 77;BA.debugLine="pf.PutAtTop = False";
parent._pf._putattop /*Object*/  = (Object)(parent.__c.False);
 //BA.debugLineNum = 78;BA.debugLine="Dim RS As ResumableSub = pf.ShowDialog(data, \"SAV";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._pf._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_data,(Object)("SAVE"),(Object)("CANCEL"));
 //BA.debugLineNum = 81;BA.debugLine="Wait For (RS) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 12;
return;
case 12:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 82;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 11;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 84;BA.debugLine="guiHelpers.Show_toast(\"Data Saved\")";
parent._guihelpers._show_toast /*String*/ (ba,"Data Saved");
 //BA.debugLineNum = 85;BA.debugLine="prefHelper.Map2Disk2(xui.DefaultFolder, gblConst";
parent._prefhelper._map2disk2 /*String*/ (parent._xui.getDefaultFolder(),parent._gblconst._file_main_setup /*String*/ ,_data);
 //BA.debugLineNum = 87;BA.debugLine="ProcessAutoBootFlag(data.Get(gblConst.KEYS_MAIN_";
parent._processautobootflag((BA.ObjectToBoolean(_data.Get((Object)(parent._gblconst._keys_main_setup_auto_boot /*String*/ )))));
 //BA.debugLineNum = 89;BA.debugLine="config.ReadMainSetup";
parent._config._readmainsetup /*String*/ (ba);
 //BA.debugLineNum = 91;BA.debugLine="If DoesMenuNeedRebuild(data,PrevData) Then";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._doesmenuneedrebuild(_data,_prevdata)) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 93;BA.debugLine="Dim Const GoHome As Int = -2";
_gohome = (int) (-2);
 //BA.debugLineNum = 94;BA.debugLine="guiHelpers.Show_toast2(\"Rebulding Menu\",3000)";
parent._guihelpers._show_toast2 /*String*/ (ba,"Rebulding Menu",(int) (3000));
 //BA.debugLineNum = 95;BA.debugLine="CallSubDelayed2(mpage,\"segTabMenu_TabChanged\",G";
parent.__c.CallSubDelayed2(ba,(Object)(parent._mpage),"segTabMenu_TabChanged",(Object)(_gohome));
 //BA.debugLineNum = 96;BA.debugLine="mpage.segTabMenu.Index = 0";
parent._mpage._segtabmenu /*sadLogic.HomeCentral.assegmentedtab*/ ._setindex /*int*/ ((int) (0));
 //BA.debugLineNum = 97;BA.debugLine="Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 13;
return;
case 13:
//C
this.state = 7;
;
 //BA.debugLineNum = 98;BA.debugLine="Menus.BuildHeaderMenu(mpage.segTabMenu,mpage,\"s";
parent._menus._buildheadermenu /*void*/ (ba,parent._mpage._segtabmenu /*sadLogic.HomeCentral.assegmentedtab*/ ,(Object)(parent._mpage),"segTabMenu");
 //BA.debugLineNum = 99;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 14;
return;
case 14:
//C
this.state = 7;
;
 if (true) break;
;
 //BA.debugLineNum = 102;BA.debugLine="If oldTheme <> config.MainSetupData.Get(gblConst";

case 7:
//if
this.state = 10;
if ((parent._oldtheme).equals(BA.ObjectToString(parent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent._gblconst._keys_main_setup_page_theme /*String*/ )))) == false) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 103;BA.debugLine="guiHelpers.Show_toast2(\"Restart to apply theme";
parent._guihelpers._show_toast2 /*String*/ (ba,"Restart to apply theme change",(int) (2500));
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 106;BA.debugLine="CallSub(mpage.oPageCurrent,\"Set_focus\")";
parent.__c.CallSubNew(ba,parent._mpage._opagecurrent /*Object*/ ,"Set_focus");
 //BA.debugLineNum = 107;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"setup_on_off_s";
parent.__c.CallSubDelayed(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)),"setup_on_off_scrn_event");
 if (true) break;

case 11:
//C
this.state = -1;
;
 //BA.debugLineNum = 111;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Di";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 112;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
