package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class powercontrol extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.powercontrol");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.powercontrol.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.phone.Phone.PhoneWakeState _pws = null;
public anywheresoftware.b4a.phone.Phone _ph = null;
public boolean _isscreenoff = false;
public float _pscreenbrightness = 0f;
public float _auto_brightness = 0f;
public boolean _scrn_brightness_no_save = false;
public boolean _scrn_brightness_save = false;
public boolean _mtakeoverpower = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _brightness_change(float _value) throws Exception{
float _v = 0f;
 //BA.debugLineNum = 171;BA.debugLine="Private Sub Brightness_Change(value As Float)";
 //BA.debugLineNum = 174;BA.debugLine="Dim v As Float = value / 100";
_v = (float) (_value/(double)100);
 //BA.debugLineNum = 175;BA.debugLine="SetScreenBrightnessAndOptionalSave(v,SCRN_BRIGHTN";
_setscreenbrightnessandoptionalsave(_v,_scrn_brightness_save);
 //BA.debugLineNum = 176;BA.debugLine="pScreenBrightness = v";
_pscreenbrightness = _v;
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 19;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 21;BA.debugLine="Private pws As PhoneWakeState, ph As Phone";
_pws = new anywheresoftware.b4a.phone.Phone.PhoneWakeState();
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 22;BA.debugLine="Public IsScreenOff As Boolean = False";
_isscreenoff = __c.False;
 //BA.debugLineNum = 23;BA.debugLine="Public pScreenBrightness As Float = -1";
_pscreenbrightness = (float) (-1);
 //BA.debugLineNum = 24;BA.debugLine="Private Const AUTO_BRIGHTNESS As Float = -1";
_auto_brightness = (float) (-1);
 //BA.debugLineNum = 25;BA.debugLine="Private Const SCRN_BRIGHTNESS_NO_SAVE As Boolean";
_scrn_brightness_no_save = __c.False;
 //BA.debugLineNum = 26;BA.debugLine="Private Const SCRN_BRIGHTNESS_SAVE As Boolean = T";
_scrn_brightness_save = __c.True;
 //BA.debugLineNum = 27;BA.debugLine="Private mTakeOverPower As Boolean = False";
_mtakeoverpower = __c.False;
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _dimthescrnbysettingbrightness() throws Exception{
float _scrn_dim_pct1 = 0f;
float _f = 0f;
 //BA.debugLineNum = 182;BA.debugLine="Public Sub DimTheScrnBySettingBrightness";
 //BA.debugLineNum = 184;BA.debugLine="Dim SCRN_DIM_PCT1 As Float = .01";
_scrn_dim_pct1 = (float) (.01);
 //BA.debugLineNum = 188;BA.debugLine="Dim f As Float = SCRN_DIM_PCT1";
_f = _scrn_dim_pct1;
 //BA.debugLineNum = 189;BA.debugLine="ph.SetScreenBrightness(f)";
_ph.SetScreenBrightness(ba,_f);
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return "";
}
public String  _dobrightnessdlg() throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Public Sub DoBrightnessDlg";
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return "";
}
public float  _getscreenbrightness() throws Exception{
anywheresoftware.b4a.agraham.reflection.Reflection _ref = null;
float _brightness = 0f;
 //BA.debugLineNum = 131;BA.debugLine="Public Sub GetScreenBrightness() As Float";
 //BA.debugLineNum = 135;BA.debugLine="Dim ref As Reflector";
_ref = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 136;BA.debugLine="ref.Target = ref.GetActivity";
_ref.Target = (Object)(_ref.GetActivity(ba));
 //BA.debugLineNum = 137;BA.debugLine="ref.Target = ref.RunMethod(\"getWindow\")";
_ref.Target = _ref.RunMethod("getWindow");
 //BA.debugLineNum = 138;BA.debugLine="ref.Target = ref.RunMethod(\"getAttributes\")";
_ref.Target = _ref.RunMethod("getAttributes");
 //BA.debugLineNum = 139;BA.debugLine="Dim brightness As Float = ref.GetField(\"screenBri";
_brightness = (float)(BA.ObjectToNumber(_ref.GetField("screenBrightness")));
 //BA.debugLineNum = 140;BA.debugLine="If B4XPages.MainPage.DebugLog Then Log(\"screen br";
if (_b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (getActivityBA())._debuglog /*boolean*/ ) { 
__c.LogImpl("46596105","screen brightness is: "+BA.NumberToString(_brightness),0);};
 //BA.debugLineNum = 141;BA.debugLine="Return brightness";
if (true) return _brightness;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return 0f;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,boolean _takeoverpower) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 33;BA.debugLine="Public Sub Initialize(takeOverPower As Boolean)";
 //BA.debugLineNum = 35;BA.debugLine="mTakeOverPower = takeOverPower";
_mtakeoverpower = _takeoverpower;
 //BA.debugLineNum = 36;BA.debugLine="If takeOverPower = False Then Return";
if (_takeoverpower==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 38;BA.debugLine="pScreenBrightness = Main.kvs.GetDefault(gblConst.";
_pscreenbrightness = (float)(BA.ObjectToNumber(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (_gblconst._ini_screen_brightness_value /*String*/ ,(Object)(.5))));
 //BA.debugLineNum = 40;BA.debugLine="pScreenBrightness = GetScreenBrightness";
_pscreenbrightness = _getscreenbrightness();
 //BA.debugLineNum = 41;BA.debugLine="If pScreenBrightness = AUTO_BRIGHTNESS Then";
if (_pscreenbrightness==_auto_brightness) { 
 //BA.debugLineNum = 42;BA.debugLine="pScreenBrightness = 0.5";
_pscreenbrightness = (float) (0.5);
 //BA.debugLineNum = 43;BA.debugLine="SetScreenBrightnessAndOptionalSave(pScreenBright";
_setscreenbrightnessandoptionalsave(_pscreenbrightness,_scrn_brightness_save);
 //BA.debugLineNum = 44;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 46;BA.debugLine="SetScreenBrightnessAndOptionalSave(pScreenBrightn";
_setscreenbrightnessandoptionalsave(_pscreenbrightness,_scrn_brightness_no_save);
 //BA.debugLineNum = 48;BA.debugLine="Screen_ON(True)";
_screen_on(__c.True);
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _releaselocks() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Public Sub ReleaseLocks";
 //BA.debugLineNum = 91;BA.debugLine="pws.ReleaseKeepAlive";
_pws.ReleaseKeepAlive();
 //BA.debugLineNum = 92;BA.debugLine="pws.ReleasePartialLock";
_pws.ReleasePartialLock();
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public String  _screen_off() throws Exception{
 //BA.debugLineNum = 73;BA.debugLine="Public Sub Screen_Off";
 //BA.debugLineNum = 79;BA.debugLine="If mTakeOverPower Then";
if (_mtakeoverpower) { 
 //BA.debugLineNum = 80;BA.debugLine="ReleaseLocks";
_releaselocks();
 //BA.debugLineNum = 81;BA.debugLine="pws.KeepAlive(True)";
_pws.KeepAlive(ba,__c.True);
 //BA.debugLineNum = 82;BA.debugLine="pws.PartialLock";
_pws.PartialLock(ba);
 };
 //BA.debugLineNum = 85;BA.debugLine="ph.SetScreenBrightness(.01)";
_ph.SetScreenBrightness(ba,(float) (.01));
 //BA.debugLineNum = 86;BA.debugLine="IsScreenOff = True";
_isscreenoff = __c.True;
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _screen_on(boolean _takeoverpower) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Public Sub Screen_ON(takeOverPower As Boolean)";
 //BA.debugLineNum = 55;BA.debugLine="ReleaseLocks";
_releaselocks();
 //BA.debugLineNum = 57;BA.debugLine="If takeOverPower Then";
if (_takeoverpower) { 
 //BA.debugLineNum = 61;BA.debugLine="pws.KeepAlive(True)";
_pws.KeepAlive(ba,__c.True);
 //BA.debugLineNum = 62;BA.debugLine="SetScreenBrightnessAndOptionalSave(pScreenBright";
_setscreenbrightnessandoptionalsave(_pscreenbrightness,_scrn_brightness_no_save);
 }else {
 };
 //BA.debugLineNum = 67;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
__c.CallSubDelayed2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 68;BA.debugLine="IsScreenOff = False";
_isscreenoff = __c.False;
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _setscreenbrightness2() throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Public Sub SetScreenBrightness2";
 //BA.debugLineNum = 124;BA.debugLine="SetScreenBrightnessAndOptionalSave(pScreenBrightn";
_setscreenbrightnessandoptionalsave(_pscreenbrightness,_scrn_brightness_no_save);
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return "";
}
public String  _setscreenbrightnessandoptionalsave(float _value,boolean _saveme) throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Public Sub SetScreenBrightnessAndOptionalSave(valu";
 //BA.debugLineNum = 104;BA.debugLine="Try";
try { //BA.debugLineNum = 105;BA.debugLine="If pScreenBrightness = AUTO_BRIGHTNESS Then";
if (_pscreenbrightness==_auto_brightness) { 
 //BA.debugLineNum = 106;BA.debugLine="Log(\"cannot set brightness, brightness is in au";
__c.LogImpl("46465030","cannot set brightness, brightness is in automode",0);
 //BA.debugLineNum = 107;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 110;BA.debugLine="ph.SetScreenBrightness(value)";
_ph.SetScreenBrightness(ba,_value);
 //BA.debugLineNum = 111;BA.debugLine="If SaveMe Then";
if (_saveme) { 
 //BA.debugLineNum = 112;BA.debugLine="Main.kvs.Put(gblConst.INI_SCREEN_BRIGHTNESS_VAL";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_screen_brightness_value /*String*/ ,(Object)(_value));
 };
 } 
       catch (Exception e11) {
			ba.setLastException(e11); //BA.debugLineNum = 116;BA.debugLine="Log(LastException)";
__c.LogImpl("46465040",BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
