package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xeval extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.b4xeval");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.b4xeval.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _number_type = 0;
public int _operator_type = 0;
public sadLogic.OctoTouchController.foss.b4xeval._parsednode _root = null;
public int _parseindex = 0;
public anywheresoftware.b4a.objects.collections.List _nodes = null;
public anywheresoftware.b4a.objects.collections.Map _operatorlevel = null;
public boolean _error = false;
public Object _mcallback = null;
public String _meventname = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static class _parsednode{
public boolean IsInitialized;
public String Operator;
public sadLogic.OctoTouchController.foss.b4xeval._parsednode Left;
public sadLogic.OctoTouchController.foss.b4xeval._parsednode Right;
public int NodeType;
public double Value;
public void Initialize() {
IsInitialized = true;
Operator = "";
Left = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
Right = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
NodeType = 0;
Value = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _orderdata{
public boolean IsInitialized;
public int Index;
public int Level;
public int Added;
public void Initialize() {
IsInitialized = true;
Index = 0;
Level = 0;
Added = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public sadLogic.OctoTouchController.foss.b4xeval._parsednode  _buildtree() throws Exception{
sadLogic.OctoTouchController.foss.b4xeval._parsednode _rt = null;
sadLogic.OctoTouchController.foss.b4xeval._parsednode _pn = null;
boolean _built = false;
 //BA.debugLineNum = 137;BA.debugLine="private Sub BuildTree As ParsedNode";
 //BA.debugLineNum = 138;BA.debugLine="Dim rt As ParsedNode";
_rt = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
 //BA.debugLineNum = 139;BA.debugLine="Do While ParseIndex < Nodes.Size";
while (_parseindex<_nodes.getSize()) {
 //BA.debugLineNum = 140;BA.debugLine="Dim pn As ParsedNode = TakeNextNode";
_pn = _takenextnode();
 //BA.debugLineNum = 141;BA.debugLine="Dim built As Boolean";
_built = false;
 //BA.debugLineNum = 142;BA.debugLine="If pn.Operator = \")\" Then";
if ((_pn.Operator /*String*/ ).equals(")")) { 
 //BA.debugLineNum = 143;BA.debugLine="Exit";
if (true) break;
 }else if((_pn.Operator /*String*/ ).equals("(")) { 
 //BA.debugLineNum = 145;BA.debugLine="pn = BuildTree";
_pn = _buildtree();
 //BA.debugLineNum = 146;BA.debugLine="built = True";
_built = __c.True;
 };
 //BA.debugLineNum = 148;BA.debugLine="If pn.NodeType = NUMBER_TYPE Or built Then";
if (_pn.NodeType /*int*/ ==_number_type || _built) { 
 //BA.debugLineNum = 149;BA.debugLine="If rt.IsInitialized Then";
if (_rt.IsInitialized /*boolean*/ ) { 
 //BA.debugLineNum = 150;BA.debugLine="rt.Right = pn";
_rt.Right /*sadLogic.OctoTouchController.foss.b4xeval._parsednode*/  = _pn;
 }else {
 //BA.debugLineNum = 152;BA.debugLine="rt = pn";
_rt = _pn;
 };
 }else if(_pn.NodeType /*int*/ ==_operator_type) { 
 //BA.debugLineNum = 155;BA.debugLine="pn.Left = rt";
_pn.Left /*sadLogic.OctoTouchController.foss.b4xeval._parsednode*/  = _rt;
 //BA.debugLineNum = 156;BA.debugLine="rt = pn";
_rt = _pn;
 };
 }
;
 //BA.debugLineNum = 159;BA.debugLine="If rt.IsInitialized = False Then rt = pn";
if (_rt.IsInitialized /*boolean*/ ==__c.False) { 
_rt = _pn;};
 //BA.debugLineNum = 160;BA.debugLine="Return rt";
if (true) return _rt;
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return null;
}
public double  _calcsubexpression(String _expr) throws Exception{
sadLogic.OctoTouchController.foss.b4xeval _be = null;
double _d = 0;
 //BA.debugLineNum = 72;BA.debugLine="Private Sub CalcSubExpression (expr As String) As";
 //BA.debugLineNum = 73;BA.debugLine="Dim be As B4XEval";
_be = new sadLogic.OctoTouchController.foss.b4xeval();
 //BA.debugLineNum = 74;BA.debugLine="be.Initialize (mCallback, mEventName)";
_be._initialize /*String*/ (ba,_mcallback,_meventname);
 //BA.debugLineNum = 75;BA.debugLine="Dim d As Double = be.EvalHelper(expr)";
_d = _be._evalhelper /*double*/ (_expr);
 //BA.debugLineNum = 76;BA.debugLine="If be.Error Then";
if (_be._error /*boolean*/ ) { 
 //BA.debugLineNum = 77;BA.debugLine="Error = True";
_error = __c.True;
 //BA.debugLineNum = 78;BA.debugLine="Return 0";
if (true) return 0;
 };
 //BA.debugLineNum = 80;BA.debugLine="Return d";
if (true) return _d;
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return 0;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 4;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 5;BA.debugLine="Private Const NUMBER_TYPE = 1, OPERATOR_TYPE = 2";
_number_type = (int) (1);
_operator_type = (int) (2);
 //BA.debugLineNum = 6;BA.debugLine="Type ParsedNode (Operator As String, Left As Pars";
;
 //BA.debugLineNum = 8;BA.debugLine="Type OrderData (Index As Int, Level As Int, Added";
;
 //BA.debugLineNum = 9;BA.debugLine="Private root As ParsedNode";
_root = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
 //BA.debugLineNum = 10;BA.debugLine="Private ParseIndex As Int";
_parseindex = 0;
 //BA.debugLineNum = 11;BA.debugLine="Private Nodes As List";
_nodes = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 12;BA.debugLine="Private OperatorLevel As Map";
_operatorlevel = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 13;BA.debugLine="Public Error As Boolean";
_error = false;
 //BA.debugLineNum = 14;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 15;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public sadLogic.OctoTouchController.foss.b4xeval._parsednode  _createnumbernode(double _d) throws Exception{
sadLogic.OctoTouchController.foss.b4xeval._parsednode _pn = null;
 //BA.debugLineNum = 196;BA.debugLine="Private Sub CreateNumberNode (d As Double) As Pars";
 //BA.debugLineNum = 197;BA.debugLine="Dim pn As ParsedNode";
_pn = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
 //BA.debugLineNum = 198;BA.debugLine="pn.Initialize";
_pn.Initialize();
 //BA.debugLineNum = 199;BA.debugLine="pn.NodeType = NUMBER_TYPE";
_pn.NodeType /*int*/  = _number_type;
 //BA.debugLineNum = 200;BA.debugLine="pn.Value = d";
_pn.Value /*double*/  = _d;
 //BA.debugLineNum = 201;BA.debugLine="Return pn";
if (true) return _pn;
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return null;
}
public sadLogic.OctoTouchController.foss.b4xeval._parsednode  _createoperatornode(String _operator) throws Exception{
sadLogic.OctoTouchController.foss.b4xeval._parsednode _pn = null;
 //BA.debugLineNum = 188;BA.debugLine="Private Sub CreateOperatorNode(operator As String)";
 //BA.debugLineNum = 189;BA.debugLine="Dim pn As ParsedNode";
_pn = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
 //BA.debugLineNum = 190;BA.debugLine="pn.Initialize";
_pn.Initialize();
 //BA.debugLineNum = 191;BA.debugLine="pn.NodeType = OPERATOR_TYPE";
_pn.NodeType /*int*/  = _operator_type;
 //BA.debugLineNum = 192;BA.debugLine="pn.Operator = operator";
_pn.Operator /*String*/  = _operator;
 //BA.debugLineNum = 193;BA.debugLine="Return pn";
if (true) return _pn;
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return null;
}
public double  _eval(String _expression) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Eval(Expression As String) As Double";
 //BA.debugLineNum = 25;BA.debugLine="Error = False";
_error = __c.False;
 //BA.debugLineNum = 26;BA.debugLine="Expression = Expression.Replace(\" \", \"\").ToLowerC";
_expression = _expression.replace(" ","").toLowerCase().replace("-(","-1*(");
 //BA.debugLineNum = 27;BA.debugLine="Return EvalHelper(Expression)";
if (true) return _evalhelper(_expression);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return 0;
}
public double  _evalhelper(String _expr) throws Exception{
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
int _lastindex = 0;
sadLogic.OctoTouchController.foss.b4xeval._orderdata _currentorderdata = null;
String _operator = "";
String _rawnumber = "";
sadLogic.OctoTouchController.foss.b4xeval._parsednode _lastnode = null;
int _level = 0;
double _d = 0;
int _i = 0;
 //BA.debugLineNum = 84;BA.debugLine="Private Sub EvalHelper (expr As String) As Double";
 //BA.debugLineNum = 86;BA.debugLine="ParseIndex = 0";
_parseindex = (int) (0);
 //BA.debugLineNum = 87;BA.debugLine="Dim root As ParsedNode";
_root = new sadLogic.OctoTouchController.foss.b4xeval._parsednode();
 //BA.debugLineNum = 88;BA.debugLine="root.Initialize";
_root.Initialize();
 //BA.debugLineNum = 89;BA.debugLine="expr = PrepareExpression(expr)";
_expr = _prepareexpression(_expr);
 //BA.debugLineNum = 90;BA.debugLine="If Error Then Return 0";
if (_error) { 
if (true) return 0;};
 //BA.debugLineNum = 91;BA.debugLine="Dim m As Matcher = Regex.Matcher(\"[\\.\\d]+\", expr)";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = __c.Regex.Matcher("[\\.\\d]+",_expr);
 //BA.debugLineNum = 92;BA.debugLine="Nodes.Initialize";
_nodes.Initialize();
 //BA.debugLineNum = 93;BA.debugLine="Dim lastIndex As Int = 0";
_lastindex = (int) (0);
 //BA.debugLineNum = 94;BA.debugLine="Dim currentOrderData As OrderData";
_currentorderdata = new sadLogic.OctoTouchController.foss.b4xeval._orderdata();
 //BA.debugLineNum = 95;BA.debugLine="currentOrderData.Initialize";
_currentorderdata.Initialize();
 //BA.debugLineNum = 96;BA.debugLine="Nodes.Add(CreateOperatorNode(\"(\"))";
_nodes.Add((Object)(_createoperatornode("(")));
 //BA.debugLineNum = 97;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 98;BA.debugLine="Dim Operator As String = expr.SubString2(lastInd";
_operator = _expr.substring(_lastindex,_m.GetStart((int) (0)));
 //BA.debugLineNum = 99;BA.debugLine="Dim rawNumber As String = m.Match";
_rawnumber = _m.getMatch();
 //BA.debugLineNum = 100;BA.debugLine="If Operator.EndsWith(\"-\") Then";
if (_operator.endsWith("-")) { 
 //BA.debugLineNum = 101;BA.debugLine="Dim lastNode As ParsedNode = Nodes.Get(Nodes.Si";
_lastnode = (sadLogic.OctoTouchController.foss.b4xeval._parsednode)(_nodes.Get((int) (_nodes.getSize()-1)));
 //BA.debugLineNum = 102;BA.debugLine="If lastNode.Operator = \"(\" Or Operator.Length >";
if ((_lastnode.Operator /*String*/ ).equals("(") || _operator.length()>1) { 
 //BA.debugLineNum = 104;BA.debugLine="Operator = Operator.SubString2(0, Operator.Len";
_operator = _operator.substring((int) (0),(int) (_operator.length()-1));
 //BA.debugLineNum = 105;BA.debugLine="rawNumber = \"-\" & rawNumber";
_rawnumber = "-"+_rawnumber;
 };
 };
 //BA.debugLineNum = 108;BA.debugLine="lastIndex = m.GetEnd(0)";
_lastindex = _m.GetEnd((int) (0));
 //BA.debugLineNum = 109;BA.debugLine="If Operator.Length > 0 Then";
if (_operator.length()>0) { 
 //BA.debugLineNum = 110;BA.debugLine="Dim level As Int = OperatorLevel.Get(Operator)";
_level = (int)(BA.ObjectToNumber(_operatorlevel.Get((Object)(_operator))));
 //BA.debugLineNum = 111;BA.debugLine="If currentOrderData.Level > 0 Then";
if (_currentorderdata.Level /*int*/ >0) { 
 //BA.debugLineNum = 112;BA.debugLine="If currentOrderData.Level < level Then";
if (_currentorderdata.Level /*int*/ <_level) { 
 //BA.debugLineNum = 113;BA.debugLine="Nodes.InsertAt(currentOrderData.Index, Create";
_nodes.InsertAt(_currentorderdata.Index /*int*/ ,(Object)(_createoperatornode("(")));
 //BA.debugLineNum = 114;BA.debugLine="currentOrderData.Added = currentOrderData.Add";
_currentorderdata.Added /*int*/  = (int) (_currentorderdata.Added /*int*/ +1);
 }else if(_currentorderdata.Level /*int*/ >_level) { 
 //BA.debugLineNum = 116;BA.debugLine="If currentOrderData.Added > 0 Then";
if (_currentorderdata.Added /*int*/ >0) { 
 //BA.debugLineNum = 117;BA.debugLine="Nodes.Add(CreateOperatorNode(\")\"))";
_nodes.Add((Object)(_createoperatornode(")")));
 //BA.debugLineNum = 118;BA.debugLine="currentOrderData.Added = currentOrderData.Ad";
_currentorderdata.Added /*int*/  = (int) (_currentorderdata.Added /*int*/ -1);
 };
 };
 };
 //BA.debugLineNum = 122;BA.debugLine="currentOrderData.Level = level";
_currentorderdata.Level /*int*/  = _level;
 //BA.debugLineNum = 123;BA.debugLine="currentOrderData.Index = Nodes.Size + 1";
_currentorderdata.Index /*int*/  = (int) (_nodes.getSize()+1);
 //BA.debugLineNum = 124;BA.debugLine="Nodes.Add(CreateOperatorNode(Operator))";
_nodes.Add((Object)(_createoperatornode(_operator)));
 };
 //BA.debugLineNum = 126;BA.debugLine="Dim d As Double = rawNumber";
_d = (double)(Double.parseDouble(_rawnumber));
 //BA.debugLineNum = 127;BA.debugLine="Nodes.Add(CreateNumberNode(d))";
_nodes.Add((Object)(_createnumbernode(_d)));
 }
;
 //BA.debugLineNum = 129;BA.debugLine="For i = 1 To currentOrderData.Added";
{
final int step43 = 1;
final int limit43 = _currentorderdata.Added /*int*/ ;
_i = (int) (1) ;
for (;_i <= limit43 ;_i = _i + step43 ) {
 //BA.debugLineNum = 130;BA.debugLine="Nodes.Add(CreateOperatorNode(\")\"))";
_nodes.Add((Object)(_createoperatornode(")")));
 }
};
 //BA.debugLineNum = 132;BA.debugLine="Nodes.Add(CreateOperatorNode(\")\"))";
_nodes.Add((Object)(_createoperatornode(")")));
 //BA.debugLineNum = 133;BA.debugLine="root = BuildTree";
_root = _buildtree();
 //BA.debugLineNum = 134;BA.debugLine="Return EvalNode(root)";
if (true) return _evalnode(_root);
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return 0;
}
public double  _evalnode(sadLogic.OctoTouchController.foss.b4xeval._parsednode _pn) throws Exception{
double _left = 0;
double _right = 0;
 //BA.debugLineNum = 163;BA.debugLine="Private Sub EvalNode (pn As ParsedNode) As Double";
 //BA.debugLineNum = 164;BA.debugLine="If pn.NodeType = NUMBER_TYPE Then Return pn.Value";
if (_pn.NodeType /*int*/ ==_number_type) { 
if (true) return _pn.Value /*double*/ ;};
 //BA.debugLineNum = 165;BA.debugLine="Dim left As Double = EvalNode(pn.Left)";
_left = _evalnode(_pn.Left /*sadLogic.OctoTouchController.foss.b4xeval._parsednode*/ );
 //BA.debugLineNum = 166;BA.debugLine="Dim right As Double = EvalNode(pn.Right)";
_right = _evalnode(_pn.Right /*sadLogic.OctoTouchController.foss.b4xeval._parsednode*/ );
 //BA.debugLineNum = 167;BA.debugLine="Select pn.Operator";
switch (BA.switchObjectToInt(_pn.Operator /*String*/ ,"+","-","*","/")) {
case 0: {
 //BA.debugLineNum = 169;BA.debugLine="Return left + right";
if (true) return _left+_right;
 break; }
case 1: {
 //BA.debugLineNum = 171;BA.debugLine="Return left - right";
if (true) return _left-_right;
 break; }
case 2: {
 //BA.debugLineNum = 173;BA.debugLine="Return left * right";
if (true) return _left*_right;
 break; }
case 3: {
 //BA.debugLineNum = 175;BA.debugLine="Return left / right";
if (true) return _left/(double)_right;
 break; }
default: {
 //BA.debugLineNum = 177;BA.debugLine="Log(\"Syntax error: \" & pn.Operator)";
__c.LogImpl("3932174","Syntax error: "+_pn.Operator /*String*/ ,0);
 //BA.debugLineNum = 178;BA.debugLine="Return \"error\"";
if (true) return (double)(Double.parseDouble("error"));
 break; }
}
;
 //BA.debugLineNum = 180;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 19;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 20;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 21;BA.debugLine="OperatorLevel = CreateMap(\"+\": 1, \"-\": 1, \"*\":2,";
_operatorlevel = __c.createMap(new Object[] {(Object)("+"),(Object)(1),(Object)("-"),(Object)(1),(Object)("*"),(Object)(2),(Object)("/"),(Object)(2)});
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _prepareexpression(String _expr) throws Exception{
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _lastmatchend = 0;
int _currentstart = 0;
boolean _functioncall = false;
anywheresoftware.b4a.objects.collections.List _args = null;
int _level = 0;
int _start = 0;
int _i = 0;
double _d = 0;
 //BA.debugLineNum = 30;BA.debugLine="Private Sub PrepareExpression(expr As String) As S";
 //BA.debugLineNum = 31;BA.debugLine="Dim m As Matcher = Regex.Matcher(\"(\\w*)\\(\", expr)";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = __c.Regex.Matcher("(\\w*)\\(",_expr);
 //BA.debugLineNum = 32;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 33;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 34;BA.debugLine="Dim lastMatchEnd As Int = 0";
_lastmatchend = (int) (0);
 //BA.debugLineNum = 35;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 36;BA.debugLine="Dim currentStart As Int = m.GetStart(0)";
_currentstart = _m.GetStart((int) (0));
 //BA.debugLineNum = 37;BA.debugLine="If currentStart < lastMatchEnd Then Continue";
if (_currentstart<_lastmatchend) { 
if (true) continue;};
 //BA.debugLineNum = 38;BA.debugLine="sb.Append(expr.SubString2(lastMatchEnd, currentS";
_sb.Append(_expr.substring(_lastmatchend,_currentstart));
 //BA.debugLineNum = 39;BA.debugLine="Dim functionCall As Boolean";
_functioncall = false;
 //BA.debugLineNum = 40;BA.debugLine="Dim args As List";
_args = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 41;BA.debugLine="If m.Match.Length > 1 Then";
if (_m.getMatch().length()>1) { 
 //BA.debugLineNum = 42;BA.debugLine="args.Initialize";
_args.Initialize();
 //BA.debugLineNum = 43;BA.debugLine="functionCall = True";
_functioncall = __c.True;
 };
 //BA.debugLineNum = 45;BA.debugLine="Dim level As Int";
_level = 0;
 //BA.debugLineNum = 46;BA.debugLine="Dim start As Int = m.GetEnd(0)";
_start = _m.GetEnd((int) (0));
 //BA.debugLineNum = 47;BA.debugLine="For i = start To expr.Length - 1";
{
final int step17 = 1;
final int limit17 = (int) (_expr.length()-1);
_i = _start ;
for (;_i <= limit17 ;_i = _i + step17 ) {
 //BA.debugLineNum = 48;BA.debugLine="If expr.CharAt(i) = \"(\" Then";
if (_expr.charAt(_i)==BA.ObjectToChar("(")) { 
 //BA.debugLineNum = 49;BA.debugLine="level = level + 1";
_level = (int) (_level+1);
 }else if(_expr.charAt(_i)==BA.ObjectToChar(",") && _level==0) { 
 //BA.debugLineNum = 51;BA.debugLine="args.Add(CalcSubExpression(expr.SubString2(sta";
_args.Add((Object)(_calcsubexpression(_expr.substring(_start,_i))));
 //BA.debugLineNum = 52;BA.debugLine="start = i + 1";
_start = (int) (_i+1);
 }else if(_expr.charAt(_i)==BA.ObjectToChar(")")) { 
 //BA.debugLineNum = 54;BA.debugLine="level = level - 1";
_level = (int) (_level-1);
 //BA.debugLineNum = 55;BA.debugLine="If level = -1 Then";
if (_level==-1) { 
 //BA.debugLineNum = 56;BA.debugLine="Dim d As Double = CalcSubExpression(expr.SubS";
_d = _calcsubexpression(_expr.substring(_start,_i));
 //BA.debugLineNum = 57;BA.debugLine="If functionCall Then";
if (_functioncall) { 
 //BA.debugLineNum = 58;BA.debugLine="args.Add(d)";
_args.Add((Object)(_d));
 //BA.debugLineNum = 59;BA.debugLine="d = CallSub3(mCallback, mEventName & \"_Funct";
_d = (double)(BA.ObjectToNumber(__c.CallSubNew3(ba,_mcallback,_meventname+"_Function",(Object)(_m.getMatch().substring((int) (0),(int) (_m.getMatch().length()-1))),(Object)(_args))));
 };
 //BA.debugLineNum = 61;BA.debugLine="sb.Append(NumberFormat2(d, 1, 15, 0, False))";
_sb.Append(__c.NumberFormat2(_d,(int) (1),(int) (15),(int) (0),__c.False));
 //BA.debugLineNum = 62;BA.debugLine="lastMatchEnd = i + 1";
_lastmatchend = (int) (_i+1);
 //BA.debugLineNum = 63;BA.debugLine="Exit";
if (true) break;
 };
 };
 }
};
 }
;
 //BA.debugLineNum = 68;BA.debugLine="If lastMatchEnd < expr.Length Then sb.Append(expr";
if (_lastmatchend<_expr.length()) { 
_sb.Append(_expr.substring(_lastmatchend));};
 //BA.debugLineNum = 69;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public sadLogic.OctoTouchController.foss.b4xeval._parsednode  _takenextnode() throws Exception{
sadLogic.OctoTouchController.foss.b4xeval._parsednode _pn = null;
 //BA.debugLineNum = 182;BA.debugLine="private Sub TakeNextNode As ParsedNode";
 //BA.debugLineNum = 183;BA.debugLine="Dim pn As ParsedNode = Nodes.Get(ParseIndex)";
_pn = (sadLogic.OctoTouchController.foss.b4xeval._parsednode)(_nodes.Get(_parseindex));
 //BA.debugLineNum = 184;BA.debugLine="ParseIndex = ParseIndex + 1";
_parseindex = (int) (_parseindex+1);
 //BA.debugLineNum = 185;BA.debugLine="Return pn";
if (true) return _pn;
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
