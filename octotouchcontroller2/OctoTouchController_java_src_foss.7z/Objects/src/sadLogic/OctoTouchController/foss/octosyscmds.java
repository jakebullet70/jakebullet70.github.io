package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class octosyscmds extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.octosyscmds");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.octosyscmds.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.httpoctorestapi _ocn = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.collections.Map _mapshutdown = null;
public anywheresoftware.b4a.objects.collections.Map _maprestart = null;
public anywheresoftware.b4a.objects.collections.Map _mapreboot = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"OctoSysCmds\" '";
_mmodule = "OctoSysCmds";
 //BA.debugLineNum = 8;BA.debugLine="Private oCN As HttpOctoRestAPI";
_ocn = new sadLogic.OctoTouchController.foss.httpoctorestapi();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Public mapShutdown As Map";
_mapshutdown = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 12;BA.debugLine="Public mapRestart As Map";
_maprestart = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 13;BA.debugLine="Public mapReboot As Map";
_mapreboot = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _getsyscmds() throws Exception{
ResumableSub_GetSysCmds rsub = new ResumableSub_GetSysCmds(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_GetSysCmds extends BA.ResumableSub {
public ResumableSub_GetSysCmds(sadLogic.OctoTouchController.foss.octosyscmds parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.octosyscmds parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 26;BA.debugLine="mapReboot.Initialize";
parent._mapreboot.Initialize();
 //BA.debugLineNum = 27;BA.debugLine="mapShutdown.Initialize";
parent._mapshutdown.Initialize();
 //BA.debugLineNum = 28;BA.debugLine="mapRestart.Initialize";
parent._maprestart.Initialize();
 //BA.debugLineNum = 31;BA.debugLine="Dim rs As ResumableSub";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
 //BA.debugLineNum = 33;BA.debugLine="rs =  oCN.SendRequestGetInfo(\"/api/system/command";
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("/api/system/commands/core");
 //BA.debugLineNum = 46;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (String) result[0];
;
 //BA.debugLineNum = 47;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result.length()!=0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 48;BA.debugLine="ParseMeSys(Result)";
parent._parsemesys(_result);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _result) throws Exception{
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.foss.httpoctorestapi _cn) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(cn As HttpOctoRestAPI)";
 //BA.debugLineNum = 19;BA.debugLine="oCN = cn";
_ocn = _cn;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _parsemesys(String _txt) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.List _root = null;
anywheresoftware.b4a.objects.collections.Map _colroot = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
String _action = "";
 //BA.debugLineNum = 62;BA.debugLine="Private Sub ParseMeSys(txt As String)";
 //BA.debugLineNum = 64;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 65;BA.debugLine="parser.Initialize(txt)";
_parser.Initialize(_txt);
 //BA.debugLineNum = 67;BA.debugLine="Dim root As List = parser.NextArray";
_root = new anywheresoftware.b4a.objects.collections.List();
_root = _parser.NextArray();
 //BA.debugLineNum = 68;BA.debugLine="For Each colroot As Map In root";
_colroot = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group4 = _root;
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_colroot = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group4.Get(index4)));
 //BA.debugLineNum = 70;BA.debugLine="Try";
try { //BA.debugLineNum = 72;BA.debugLine="Dim m As Map : m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 72;BA.debugLine="Dim m As Map : m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 73;BA.debugLine="m.Put(\"confirm\", strHelpers.StripHTML(colroot.G";
_m.Put((Object)("confirm"),(Object)(_strhelpers._striphtml /*String*/ (getActivityBA(),BA.ObjectToString(_colroot.Get((Object)("confirm"))))));
 //BA.debugLineNum = 74;BA.debugLine="m.put(\"resource\",colroot.Get(\"resource\"))";
_m.Put((Object)("resource"),_colroot.Get((Object)("resource")));
 //BA.debugLineNum = 75;BA.debugLine="m.Put(\"name\",colroot.Get(\"name\"))";
_m.Put((Object)("name"),_colroot.Get((Object)("name")));
 //BA.debugLineNum = 77;BA.debugLine="Dim action As String = colroot.Get(\"action\")";
_action = BA.ObjectToString(_colroot.Get((Object)("action")));
 //BA.debugLineNum = 78;BA.debugLine="Select Case action";
switch (BA.switchObjectToInt(_action,"shutdown","restart","reboot","restart_safe")) {
case 0: {
 //BA.debugLineNum = 79;BA.debugLine="Case \"shutdown\"   		: mapShutdown = objHelpers";
_mapshutdown = _objhelpers._copymap /*anywheresoftware.b4a.objects.collections.Map*/ (getActivityBA(),_m);
 break; }
case 1: {
 //BA.debugLineNum = 80;BA.debugLine="Case \"restart\" 			: mapRestart    = objHelpers";
_maprestart = _objhelpers._copymap /*anywheresoftware.b4a.objects.collections.Map*/ (getActivityBA(),_m);
 break; }
case 2: {
 //BA.debugLineNum = 81;BA.debugLine="Case \"reboot\" 			: mapReboot	   = objHelpers.C";
_mapreboot = _objhelpers._copymap /*anywheresoftware.b4a.objects.collections.Map*/ (getActivityBA(),_m);
 break; }
case 3: {
 break; }
default: {
 //BA.debugLineNum = 85;BA.debugLine="logMe.LogIt2(\"case else: \" & action,mModule,\"";
_logme._logit2 /*String*/ (getActivityBA(),"case else: "+_action,_mmodule,"ParseMe");
 break; }
}
;
 } 
       catch (Exception e24) {
			ba.setLastException(e24); //BA.debugLineNum = 95;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,\"Par";
_logme._logit2 /*String*/ (getActivityBA(),__c.LastException(getActivityBA()).getMessage(),_mmodule,"ParseMeSys");
 };
 }
};
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public String  _reboot() throws Exception{
 //BA.debugLineNum = 150;BA.debugLine="Public Sub Reboot()";
 //BA.debugLineNum = 151;BA.debugLine="oCN.PostRequest2($\"${mapReboot.Get(\"resource\") &";
_ocn._postrequest2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((""+__c.SmartStringFormatter("",(Object)(BA.ObjectToString(_mapreboot.Get((Object)("resource")))+("?apikey="+__c.SmartStringFormatter("",(Object)(_oc._octokey /*String*/ ))+"")))+""),("{\"source\": \"core\", \"action\": \"reboot\"}"));
 //BA.debugLineNum = 152;BA.debugLine="guiHelpers.Show_toast(\"Rebooting system... \",3500";
_guihelpers._show_toast /*String*/ (getActivityBA(),"Rebooting system... ",(int) (3500));
 //BA.debugLineNum = 153;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tmrM";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
public String  _restart() throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Public Sub Restart()";
 //BA.debugLineNum = 137;BA.debugLine="oCN.PostRequest2($\"${mapRestart.Get(\"resource\") &";
_ocn._postrequest2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((""+__c.SmartStringFormatter("",(Object)(BA.ObjectToString(_maprestart.Get((Object)("resource")))+("?apikey="+__c.SmartStringFormatter("",(Object)(_oc._octokey /*String*/ ))+"")))+""),("{\"source\": \"core\", \"action\": \"restart\"}"));
 //BA.debugLineNum = 138;BA.debugLine="guiHelpers.Show_toast(\"Restarting Octoprint... \",";
_guihelpers._show_toast /*String*/ (getActivityBA(),"Restarting Octoprint... ",(int) (3500));
 //BA.debugLineNum = 139;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tmrM";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public String  _shutdown() throws Exception{
 //BA.debugLineNum = 143;BA.debugLine="Public Sub Shutdown()";
 //BA.debugLineNum = 144;BA.debugLine="oCN.PostRequest2($\"${mapShutdown.Get(\"resource\")";
_ocn._postrequest2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((""+__c.SmartStringFormatter("",(Object)(BA.ObjectToString(_mapshutdown.Get((Object)("resource")))+("?apikey="+__c.SmartStringFormatter("",(Object)(_oc._octokey /*String*/ ))+"")))+""),("{\"source\": \"core\", \"action\": \"shutdown\"}"));
 //BA.debugLineNum = 145;BA.debugLine="guiHelpers.Show_toast(\"Shutting down system... \",";
_guihelpers._show_toast /*String*/ (getActivityBA(),"Shutting down system... ",(int) (3500));
 //BA.debugLineNum = 146;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tmrM";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
