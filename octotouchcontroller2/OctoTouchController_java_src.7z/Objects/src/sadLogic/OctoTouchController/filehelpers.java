package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class filehelpers {
private static filehelpers mostCurrent = new filehelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static String  _bytestoreadablestring(anywheresoftware.b4a.BA _ba,String _bytes) throws Exception{
double _bytes1 = 0;
int _count = 0;
int _factor = 0;
double _workingnum = 0;
anywheresoftware.b4a.objects.collections.List _suffix = null;
 //BA.debugLineNum = 93;BA.debugLine="Public Sub BytesToReadableString(Bytes As String)";
 //BA.debugLineNum = 95;BA.debugLine="If IsNumber(Bytes) = False Then Return \"-\"";
if (anywheresoftware.b4a.keywords.Common.IsNumber(_bytes)==anywheresoftware.b4a.keywords.Common.False) { 
if (true) return "-";};
 //BA.debugLineNum = 96;BA.debugLine="Dim Bytes1 As Double = Bytes";
_bytes1 = (double)(Double.parseDouble(_bytes));
 //BA.debugLineNum = 98;BA.debugLine="Dim count As Int = 0";
_count = (int) (0);
 //BA.debugLineNum = 99;BA.debugLine="Dim factor As Int = 1024 '--- could be 1000 for H";
_factor = (int) (1024);
 //BA.debugLineNum = 100;BA.debugLine="Dim Workingnum As Double = Bytes1";
_workingnum = _bytes1;
 //BA.debugLineNum = 101;BA.debugLine="Dim  Suffix As List = Array(\"Bytes\", \"KB\", \"MB\",";
_suffix = new anywheresoftware.b4a.objects.collections.List();
_suffix = anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)("Bytes"),(Object)("KB"),(Object)("MB"),(Object)("GB"),(Object)("TB"),(Object)("PB")});
 //BA.debugLineNum = 103;BA.debugLine="Do While Workingnum > factor And count < 5";
while (_workingnum>_factor && _count<5) {
 //BA.debugLineNum = 104;BA.debugLine="Workingnum = Workingnum / factor";
_workingnum = _workingnum/(double)_factor;
 //BA.debugLineNum = 105;BA.debugLine="count = count + 1";
_count = (int) (_count+1);
 }
;
 //BA.debugLineNum = 108;BA.debugLine="Return $\"${NumberFormat(Workingnum,1,2)}${Suffix.";
if (true) return (""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(_workingnum,(int) (1),(int) (2))))+""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",_suffix.Get(_count))+"");
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public static String  _checkandcleanfilename(anywheresoftware.b4a.BA _ba,String _stringtocheck) throws Exception{
String _sillegal = "";
String[] _arillegal = null;
String _sreturn = "";
int _i = 0;
 //BA.debugLineNum = 30;BA.debugLine="public Sub CheckAndCleanFileName(StringToCheck As";
 //BA.debugLineNum = 35;BA.debugLine="Dim sIllegal As String = \"\\`/`:`*`?`\" & Chr(34) &";
_sillegal = "\\`/`:`*`?`"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (34)))+"`<`>`|";
 //BA.debugLineNum = 36;BA.debugLine="Dim arIllegal() As String = Regex.Split( \"`\",sIll";
_arillegal = anywheresoftware.b4a.keywords.Common.Regex.Split("`",_sillegal);
 //BA.debugLineNum = 37;BA.debugLine="Dim sReturn As String";
_sreturn = "";
 //BA.debugLineNum = 39;BA.debugLine="sReturn = StringToCheck";
_sreturn = _stringtocheck;
 //BA.debugLineNum = 41;BA.debugLine="For i = 0 To arIllegal.Length - 1";
{
final int step5 = 1;
final int limit5 = (int) (_arillegal.length-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
 //BA.debugLineNum = 42;BA.debugLine="sReturn = sReturn.Replace(arIllegal(i), \"_\")";
_sreturn = _sreturn.replace(_arillegal[_i],"_");
 }
};
 //BA.debugLineNum = 45;BA.debugLine="Return sReturn";
if (true) return _sreturn;
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public static String  _deletefiles(anywheresoftware.b4a.BA _ba,String _folder,String _filespec) throws Exception{
sadLogic.OctoTouchController.wildcardfileslist _o1 = null;
anywheresoftware.b4a.objects.collections.List _lstfolder = null;
String _filename = "";
 //BA.debugLineNum = 153;BA.debugLine="Public Sub DeleteFiles(folder As String, fileSpec";
 //BA.debugLineNum = 155;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1 = new sadLogic.OctoTouchController.wildcardfileslist();
 //BA.debugLineNum = 155;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 156;BA.debugLine="Dim lstFolder As List = o1.GetFiles(folder,fileSp";
_lstfolder = new anywheresoftware.b4a.objects.collections.List();
_lstfolder = _o1._getfiles /*anywheresoftware.b4a.objects.collections.List*/ (_folder,_filespec,anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 158;BA.debugLine="For Each filename As String In lstFolder";
{
final anywheresoftware.b4a.BA.IterableList group4 = _lstfolder;
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_filename = BA.ObjectToString(group4.Get(index4));
 //BA.debugLineNum = 159;BA.debugLine="If File.IsDirectory(folder, filename) Then";
if (anywheresoftware.b4a.keywords.Common.File.IsDirectory(_folder,_filename)) { 
 //BA.debugLineNum = 160;BA.debugLine="Continue";
if (true) continue;
 };
 //BA.debugLineNum = 162;BA.debugLine="File.Delete(folder,filename)";
anywheresoftware.b4a.keywords.Common.File.Delete(_folder,_filename);
 }
};
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static String  _getfilenamefrompath(anywheresoftware.b4a.BA _ba,String _pathandfname) throws Exception{
String _pathsepchar = "";
int _tt = 0;
 //BA.debugLineNum = 77;BA.debugLine="Public Sub GetFilenameFromPath(pathAndfname As Str";
 //BA.debugLineNum = 79;BA.debugLine="Dim PathSepChar As String  = \"/\"";
_pathsepchar = "/";
 //BA.debugLineNum = 81;BA.debugLine="Try";
try { //BA.debugLineNum = 82;BA.debugLine="Dim tt As Int = pathAndfname.LastIndexOf(PathSep";
_tt = _pathandfname.lastIndexOf(_pathsepchar);
 //BA.debugLineNum = 83;BA.debugLine="Return pathAndfname.SubString2(tt + 1,pathAndfna";
if (true) return _pathandfname.substring((int) (_tt+1),_pathandfname.length());
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 85;BA.debugLine="Return pathAndfname";
if (true) return _pathandfname;
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"fileHelpers\" '";
_mmodule = "fileHelpers";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _read_returnsinglevalue(anywheresoftware.b4a.BA _ba,String _filename) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Read_ReturnSingleValue(filename As Stri";
 //BA.debugLineNum = 15;BA.debugLine="If File.Exists(xui.DefaultFolder,filename) Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),_filename)) { 
 //BA.debugLineNum = 16;BA.debugLine="Dim lst As List = File.ReadList(xui.DefaultFolde";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst = anywheresoftware.b4a.keywords.Common.File.ReadList(_xui.getDefaultFolder(),_filename);
 //BA.debugLineNum = 17;BA.debugLine="Return lst.Get(0)";
if (true) return BA.ObjectToString(_lst.Get((int) (0)));
 };
 //BA.debugLineNum = 19;BA.debugLine="Return \"\"";
if (true) return "";
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _removeextfromefilename(anywheresoftware.b4a.BA _ba,String _fname) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="public Sub RemoveExtFromeFileName(fname As String)";
 //BA.debugLineNum = 68;BA.debugLine="Try";
try { //BA.debugLineNum = 69;BA.debugLine="Return fname.SubString2(0,fname.LastIndexOf(\".\")";
if (true) return _fname.substring((int) (0),_fname.lastIndexOf(".")).trim();
 } 
       catch (Exception e4) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e4); //BA.debugLineNum = 71;BA.debugLine="Return fname";
if (true) return _fname;
 };
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public static String  _safekill(anywheresoftware.b4a.BA _ba,String _fname) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Public Sub SafeKill(fname As String)";
 //BA.debugLineNum = 53;BA.debugLine="SafeKill2(xui.DefaultFolder, fname)";
_safekill2(_ba,_xui.getDefaultFolder(),_fname);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _safekill2(anywheresoftware.b4a.BA _ba,String _folder,String _fname) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Public Sub SafeKill2(folder As String, fname As St";
 //BA.debugLineNum = 59;BA.debugLine="If File.Exists(folder, fname) Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_folder,_fname)) { 
 //BA.debugLineNum = 60;BA.debugLine="File.Delete(folder, fname)";
anywheresoftware.b4a.keywords.Common.File.Delete(_folder,_fname);
 };
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static String  _write_singlevalue(anywheresoftware.b4a.BA _ba,String _filename,String _value) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Write_SingleValue(filename As String, v";
 //BA.debugLineNum = 23;BA.debugLine="SafeKill(filename)";
_safekill(_ba,_filename);
 //BA.debugLineNum = 24;BA.debugLine="Dim lst As List : lst.Initialize2(Array As String";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 24;BA.debugLine="Dim lst As List : lst.Initialize2(Array As String";
_lst.Initialize2(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_value}));
 //BA.debugLineNum = 25;BA.debugLine="File.WriteList(xui.DefaultFolder,filename,lst)";
anywheresoftware.b4a.keywords.Common.File.WriteList(_xui.getDefaultFolder(),_filename,_lst);
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _writetxt2disk(anywheresoftware.b4a.BA _ba,String _str,String _folder,String _filename) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _textwriter1 = null;
 //BA.debugLineNum = 169;BA.debugLine="Public Sub WriteTxt2Disk(str As String,folder As S";
 //BA.debugLineNum = 174;BA.debugLine="Dim TextWriter1 As TextWriter";
_textwriter1 = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 175;BA.debugLine="TextWriter1.Initialize(File.OpenOutput( folder, f";
_textwriter1.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(_folder,_filename,anywheresoftware.b4a.keywords.Common.True).getObject()));
 //BA.debugLineNum = 176;BA.debugLine="TextWriter1.WriteLine(str)";
_textwriter1.WriteLine(_str);
 //BA.debugLineNum = 177;BA.debugLine="TextWriter1.Close";
_textwriter1.Close();
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return "";
}
public static boolean  _writetxt2sharedfolder(anywheresoftware.b4a.BA _ba,String _filename,String _txt) throws Exception{
anywheresoftware.b4a.objects.RuntimePermissions _rp = null;
String _esdir = "";
 //BA.debugLineNum = 182;BA.debugLine="Public Sub WriteTxt2SharedFolder(filename As Strin";
 //BA.debugLineNum = 185;BA.debugLine="Dim rp As RuntimePermissions";
_rp = new anywheresoftware.b4a.objects.RuntimePermissions();
 //BA.debugLineNum = 186;BA.debugLine="Dim ESDir As String = rp.GetSafeDirDefaultExterna";
_esdir = _rp.GetSafeDirDefaultExternal("");
 //BA.debugLineNum = 189;BA.debugLine="If strHelpers.IsNullOrEmpty(ESDir) Then";
if (mostCurrent._strhelpers._isnullorempty /*boolean*/ (_ba,_esdir)) { 
 //BA.debugLineNum = 190;BA.debugLine="logMe.LogIt2(\"Getting external shared folder fai";
mostCurrent._logme._logit2 /*String*/ (_ba,"Getting external shared folder failed!",_mmodule,"WriteTxt2SharedFolder");
 //BA.debugLineNum = 191;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 193;BA.debugLine="SafeKill2(ESDir,filename)";
_safekill2(_ba,_esdir,_filename);
 //BA.debugLineNum = 194;BA.debugLine="WriteTxt2Disk(txt,ESDir,filename)";
_writetxt2disk(_ba,_txt,_esdir,_filename);
 //BA.debugLineNum = 195;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return false;
}
}
