package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagekitchentimersbase{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _dd="";
String _sp="";
String _pad="";
String _p1="";
String _cc="";
String _padsp="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlcontrol").vw.setLeft((int)(0d));
views.get("pnlcontrol").vw.setWidth((int)((100d / 100 * width)*.60d - (0d)));
views.get("pnlcontrol").vw.setTop((int)(0d));
views.get("pnlcontrol").vw.setHeight((int)((100d / 100 * height)-(3d * scale) - (0d)));
views.get("pnlsplitter").vw.setLeft((int)((views.get("pnlcontrol").vw.getWidth())));
views.get("pnlsplitter").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth())+(2d * scale) - ((views.get("pnlcontrol").vw.getWidth()))));
views.get("pnlsplitter").vw.setTop((int)(0d));
views.get("pnlsplitter").vw.setHeight((int)((100d / 100 * height)-(3d * scale) - (0d)));
views.get("pnltimers").vw.setLeft((int)((views.get("pnlcontrol").vw.getWidth())+(views.get("pnlsplitter").vw.getWidth())));
views.get("pnltimers").vw.setWidth((int)((100d / 100 * width) - ((views.get("pnlcontrol").vw.getWidth())+(views.get("pnlsplitter").vw.getWidth()))));
views.get("pnltimers").vw.setTop((int)(0d));
views.get("pnltimers").vw.setHeight((int)((100d / 100 * height)-(3d * scale) - (0d)));
views.get("pnlbtnstop").vw.setLeft((int)(0d));
views.get("pnlbtnstop").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
views.get("pnlbtnstop").vw.setTop((int)(0d));
views.get("pnlbtnstop").vw.setHeight((int)((views.get("pnlcontrol").vw.getHeight())*.2d - (0d)));
views.get("pnllcd").vw.setLeft((int)(0d));
views.get("pnllcd").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
views.get("pnllcd").vw.setTop((int)((views.get("pnlbtnstop").vw.getHeight())+(views.get("pnlhrsminsecslbl").vw.getHeight())));
views.get("pnllcd").vw.setHeight((int)((views.get("pnlcontrol").vw.getHeight())*.6d - ((views.get("pnlbtnstop").vw.getHeight())+(views.get("pnlhrsminsecslbl").vw.getHeight()))));
views.get("pnlbtnsbottom").vw.setLeft((int)(0d));
views.get("pnlbtnsbottom").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
views.get("pnlbtnsbottom").vw.setTop((int)((views.get("pnllcd").vw.getHeight())+(views.get("pnlbtnstop").vw.getHeight())+(views.get("pnlhrsminsecslbl").vw.getHeight())));
views.get("pnlbtnsbottom").vw.setHeight((int)((views.get("pnlcontrol").vw.getHeight())*.8d - ((views.get("pnllcd").vw.getHeight())+(views.get("pnlbtnstop").vw.getHeight())+(views.get("pnlhrsminsecslbl").vw.getHeight()))));
views.get("pnlsplittermnu").vw.setLeft((int)(0d));
views.get("pnlsplittermnu").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
views.get("pnlsplittermnu").vw.setTop((int)((views.get("pnlbtnsbottom").vw.getTop() + views.get("pnlbtnsbottom").vw.getHeight())));
views.get("pnlsplittermnu").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getTop() + views.get("pnlbtnsbottom").vw.getHeight())+(3d * scale) - ((views.get("pnlbtnsbottom").vw.getTop() + views.get("pnlbtnsbottom").vw.getHeight()))));
views.get("pnlbtnsmenu").vw.setLeft((int)(0d));
views.get("pnlbtnsmenu").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
views.get("pnlbtnsmenu").vw.setTop((int)((3d * scale)+(views.get("pnlhrsminsecslbl").vw.getHeight())+(views.get("pnlbtnsbottom").vw.getHeight())+(views.get("pnllcd").vw.getHeight())+(views.get("pnlbtnstop").vw.getHeight())+(1d * scale)));
views.get("pnlbtnsmenu").vw.setHeight((int)((views.get("pnlcontrol").vw.getHeight())*1d-(3d * scale) - ((3d * scale)+(views.get("pnlhrsminsecslbl").vw.getHeight())+(views.get("pnlbtnsbottom").vw.getHeight())+(views.get("pnllcd").vw.getHeight())+(views.get("pnlbtnstop").vw.getHeight())+(1d * scale))));
views.get("lbllisthdr").vw.setLeft((int)(0d));
views.get("lbllisthdr").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("lbllisthdr").vw.setTop((int)(0d));
views.get("lbllisthdr").vw.setHeight((int)((views.get("pnltimers").vw.getHeight())*.08d - (0d)));
views.get("lblhrs").vw.setLeft((int)(0d));
views.get("lblhrs").vw.setWidth((int)((views.get("pnllcd").vw.getWidth())*.330d-(10d * scale) - (0d)));
views.get("lblhrs").vw.setTop((int)(0d));
views.get("lblhrs").vw.setHeight((int)((views.get("pnllcd").vw.getHeight()) - (0d)));
views.get("lbldots1").vw.setLeft((int)((views.get("pnllcd").vw.getWidth())*.310d));
views.get("lbldots1").vw.setWidth((int)((views.get("pnllcd").vw.getWidth())*.333d+(5d * scale) - ((views.get("pnllcd").vw.getWidth())*.310d)));
views.get("lbldots1").vw.setTop((int)(0-(10d * scale)));
views.get("lbldots1").vw.setHeight((int)((views.get("pnllcd").vw.getHeight()) - (0-(10d * scale))));
views.get("lblmin").vw.setLeft((int)((views.get("pnllcd").vw.getWidth())*.333d+(5d * scale)));
views.get("lblmin").vw.setWidth((int)((views.get("pnllcd").vw.getWidth())*.666d-(5d * scale) - ((views.get("pnllcd").vw.getWidth())*.333d+(5d * scale))));
views.get("lblmin").vw.setTop((int)(0d));
views.get("lblmin").vw.setHeight((int)((views.get("pnllcd").vw.getHeight()) - (0d)));
views.get("lbldots2").vw.setLeft((int)((views.get("pnllcd").vw.getWidth())*.660d));
views.get("lbldots2").vw.setWidth((int)((views.get("pnllcd").vw.getWidth())*.666d+(8d * scale) - ((views.get("pnllcd").vw.getWidth())*.660d)));
views.get("lbldots2").vw.setTop((int)(0-(10d * scale)));
views.get("lbldots2").vw.setHeight((int)((views.get("pnllcd").vw.getHeight()) - (0-(10d * scale))));
views.get("lblsec").vw.setLeft((int)((views.get("pnllcd").vw.getWidth())*.666d+(10d * scale)));
views.get("lblsec").vw.setWidth((int)((views.get("pnllcd").vw.getWidth()) - ((views.get("pnllcd").vw.getWidth())*.666d+(10d * scale))));
views.get("lblsec").vw.setTop((int)(0d));
views.get("lblsec").vw.setHeight((int)((views.get("pnllcd").vw.getHeight()) - (0d)));
_dd = BA.NumberToString(.92d/5d);
views.get("pnltimers1").vw.setLeft((int)(0d));
views.get("pnltimers1").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("pnltimers1").vw.setTop((int)((views.get("lbllisthdr").vw.getTop() + views.get("lbllisthdr").vw.getHeight())));
views.get("pnltimers1").vw.setHeight((int)(((views.get("pnltimers").vw.getHeight())*Double.parseDouble(_dd))+(views.get("lbllisthdr").vw.getHeight()) - ((views.get("lbllisthdr").vw.getTop() + views.get("lbllisthdr").vw.getHeight()))));
views.get("pnltimers2").vw.setLeft((int)(0d));
views.get("pnltimers2").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("pnltimers2").vw.setTop((int)((views.get("pnltimers1").vw.getTop() + views.get("pnltimers1").vw.getHeight())));
views.get("pnltimers2").vw.setHeight((int)((views.get("pnltimers").vw.getHeight())*(Double.parseDouble(_dd)*2d)+(views.get("lbllisthdr").vw.getHeight()) - ((views.get("pnltimers1").vw.getTop() + views.get("pnltimers1").vw.getHeight()))));
views.get("pnltimers3").vw.setLeft((int)(0d));
views.get("pnltimers3").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("pnltimers3").vw.setTop((int)((views.get("pnltimers2").vw.getTop() + views.get("pnltimers2").vw.getHeight())));
views.get("pnltimers3").vw.setHeight((int)((views.get("pnltimers").vw.getHeight())*(Double.parseDouble(_dd)*3d)+(views.get("lbllisthdr").vw.getHeight()) - ((views.get("pnltimers2").vw.getTop() + views.get("pnltimers2").vw.getHeight()))));
views.get("pnltimers4").vw.setLeft((int)(0d));
views.get("pnltimers4").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("pnltimers4").vw.setTop((int)((views.get("pnltimers3").vw.getTop() + views.get("pnltimers3").vw.getHeight())));
views.get("pnltimers4").vw.setHeight((int)((views.get("pnltimers").vw.getHeight())*(Double.parseDouble(_dd)*4d)+(views.get("lbllisthdr").vw.getHeight()) - ((views.get("pnltimers3").vw.getTop() + views.get("pnltimers3").vw.getHeight()))));
views.get("pnltimers5").vw.setLeft((int)(0d));
views.get("pnltimers5").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("pnltimers5").vw.setTop((int)((views.get("pnltimers4").vw.getTop() + views.get("pnltimers4").vw.getHeight())));
views.get("pnltimers5").vw.setHeight((int)((views.get("pnltimers").vw.getHeight())*(Double.parseDouble(_dd)*5d)+(views.get("lbllisthdr").vw.getHeight()) - ((views.get("pnltimers4").vw.getTop() + views.get("pnltimers4").vw.getHeight()))));
_sp = BA.NumberToString((3d * scale));
_pad = BA.NumberToString((0d * scale));
_p1 = BA.NumberToString((32d * scale));
views.get("lbltimersdesc1").vw.setLeft((int)(0d));
views.get("lbltimersdesc1").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
views.get("lbltimersdesc1").vw.setTop((int)(0d));
views.get("lbltimersdesc1").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())*.5d - (0d)));
views.get("imgtimers1").vw.setLeft((int)(0d));
views.get("imgtimers1").vw.setWidth((int)((views.get("lbltimersdesc1").vw.getHeight()) - (0d)));
views.get("imgtimers1").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("imgtimers1").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
views.get("lbltimerstime1").vw.setLeft((int)((views.get("imgtimers1").vw.getWidth())));
views.get("lbltimerstime1").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - ((views.get("imgtimers1").vw.getWidth()))));
views.get("lbltimerstime1").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("lbltimerstime1").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())+Double.parseDouble(_pad) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
views.get("pnlsplitter1").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlsplitter1").vw.setWidth((int)((views.get("pnltimers").vw.getWidth())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 83;BA.debugLine="pnlSplitter1.SetTopAndBottom(pnlTimers1.Height-sp,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter1").vw.setTop((int)((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp)));
views.get("pnlsplitter1").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp))));
//BA.debugLineNum = 85;BA.debugLine="lblTimersDesc2.SetLeftAndRight(0,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc2").vw.setLeft((int)(0d));
views.get("lbltimersdesc2").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
//BA.debugLineNum = 86;BA.debugLine="lblTimersDesc2.SetTopAndBottom(0,pnlTimers1.Height*.5)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc2").vw.setTop((int)(0d));
views.get("lbltimersdesc2").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())*.5d - (0d)));
//BA.debugLineNum = 87;BA.debugLine="imgTimers2.SetLeftAndRight(0,lblTimersDesc2.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers2").vw.setLeft((int)(0d));
views.get("imgtimers2").vw.setWidth((int)((views.get("lbltimersdesc2").vw.getHeight()) - (0d)));
//BA.debugLineNum = 88;BA.debugLine="imgTimers2.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers2").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("imgtimers2").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 89;BA.debugLine="lblTimersTime2.SetLeftAndRight(imgTimers1.Width,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime2").vw.setLeft((int)((views.get("imgtimers1").vw.getWidth())));
views.get("lbltimerstime2").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - ((views.get("imgtimers1").vw.getWidth()))));
//BA.debugLineNum = 90;BA.debugLine="lblTimersTime2.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height+pad)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime2").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("lbltimerstime2").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())+Double.parseDouble(_pad) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 91;BA.debugLine="pnlSplitter2.SetLeftAndRight(p1,pnlTimers.Width-p1)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter2").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlsplitter2").vw.setWidth((int)((views.get("pnltimers").vw.getWidth())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 92;BA.debugLine="pnlSplitter2.SetTopAndBottom(pnlTimers1.Height-sp,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter2").vw.setTop((int)((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp)));
views.get("pnlsplitter2").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp))));
//BA.debugLineNum = 94;BA.debugLine="lblTimersDesc3.SetLeftAndRight(0,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc3").vw.setLeft((int)(0d));
views.get("lbltimersdesc3").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
//BA.debugLineNum = 95;BA.debugLine="lblTimersDesc3.SetTopAndBottom(0,pnlTimers1.Height*.5)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc3").vw.setTop((int)(0d));
views.get("lbltimersdesc3").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())*.5d - (0d)));
//BA.debugLineNum = 96;BA.debugLine="imgTimers3.SetLeftAndRight(0,lblTimersDesc3.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers3").vw.setLeft((int)(0d));
views.get("imgtimers3").vw.setWidth((int)((views.get("lbltimersdesc3").vw.getHeight()) - (0d)));
//BA.debugLineNum = 97;BA.debugLine="imgTimers3.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers3").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("imgtimers3").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 98;BA.debugLine="lblTimersTime3.SetLeftAndRight(imgTimers1.Width,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime3").vw.setLeft((int)((views.get("imgtimers1").vw.getWidth())));
views.get("lbltimerstime3").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - ((views.get("imgtimers1").vw.getWidth()))));
//BA.debugLineNum = 99;BA.debugLine="lblTimersTime3.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height+pad)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime3").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("lbltimerstime3").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())+Double.parseDouble(_pad) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 100;BA.debugLine="pnlSplitter3.SetLeftAndRight(p1,pnlTimers.Width-p1)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter3").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlsplitter3").vw.setWidth((int)((views.get("pnltimers").vw.getWidth())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 101;BA.debugLine="pnlSplitter3.SetTopAndBottom(pnlTimers1.Height-sp,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter3").vw.setTop((int)((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp)));
views.get("pnlsplitter3").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp))));
//BA.debugLineNum = 103;BA.debugLine="lblTimersDesc4.SetLeftAndRight(0,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc4").vw.setLeft((int)(0d));
views.get("lbltimersdesc4").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
//BA.debugLineNum = 104;BA.debugLine="lblTimersDesc4.SetTopAndBottom(0,pnlTimers1.Height*.5)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc4").vw.setTop((int)(0d));
views.get("lbltimersdesc4").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())*.5d - (0d)));
//BA.debugLineNum = 105;BA.debugLine="imgTimers4.SetLeftAndRight(0,lblTimersDesc4.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers4").vw.setLeft((int)(0d));
views.get("imgtimers4").vw.setWidth((int)((views.get("lbltimersdesc4").vw.getHeight()) - (0d)));
//BA.debugLineNum = 106;BA.debugLine="imgTimers4.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers4").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("imgtimers4").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 107;BA.debugLine="lblTimersTime4.SetLeftAndRight(imgTimers1.Width,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime4").vw.setLeft((int)((views.get("imgtimers1").vw.getWidth())));
views.get("lbltimerstime4").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - ((views.get("imgtimers1").vw.getWidth()))));
//BA.debugLineNum = 108;BA.debugLine="lblTimersTime4.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height+pad)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime4").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("lbltimerstime4").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())+Double.parseDouble(_pad) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 109;BA.debugLine="pnlSplitter4.SetLeftAndRight(p1,pnlTimers.Width-p1)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter4").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlsplitter4").vw.setWidth((int)((views.get("pnltimers").vw.getWidth())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 110;BA.debugLine="pnlSplitter4.SetTopAndBottom(pnlTimers1.Height-sp,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("pnlsplitter4").vw.setTop((int)((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp)));
views.get("pnlsplitter4").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("pnltimers1").vw.getHeight())-Double.parseDouble(_sp))));
//BA.debugLineNum = 113;BA.debugLine="lblTimersDesc5.SetLeftAndRight(0,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc5").vw.setLeft((int)(0d));
views.get("lbltimersdesc5").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - (0d)));
//BA.debugLineNum = 114;BA.debugLine="lblTimersDesc5.SetTopAndBottom(0,pnlTimers1.Height*.5)"[pageKitchenTimersBase/General script]
views.get("lbltimersdesc5").vw.setTop((int)(0d));
views.get("lbltimersdesc5").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())*.5d - (0d)));
//BA.debugLineNum = 115;BA.debugLine="imgTimers5.SetLeftAndRight(0,lblTimersDesc5.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers5").vw.setLeft((int)(0d));
views.get("imgtimers5").vw.setWidth((int)((views.get("lbltimersdesc5").vw.getHeight()) - (0d)));
//BA.debugLineNum = 116;BA.debugLine="imgTimers5.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height)"[pageKitchenTimersBase/General script]
views.get("imgtimers5").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("imgtimers5").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight()) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 117;BA.debugLine="lblTimersTime5.SetLeftAndRight(imgTimers1.Width,pnlTimers.Width)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime5").vw.setLeft((int)((views.get("imgtimers1").vw.getWidth())));
views.get("lbltimerstime5").vw.setWidth((int)((views.get("pnltimers").vw.getWidth()) - ((views.get("imgtimers1").vw.getWidth()))));
//BA.debugLineNum = 118;BA.debugLine="lblTimersTime5.SetTopAndBottom(lblTimersDesc1.Bottom,pnlTimers1.Height+pad)"[pageKitchenTimersBase/General script]
views.get("lbltimerstime5").vw.setTop((int)((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight())));
views.get("lbltimerstime5").vw.setHeight((int)((views.get("pnltimers1").vw.getHeight())+Double.parseDouble(_pad) - ((views.get("lbltimersdesc1").vw.getTop() + views.get("lbltimersdesc1").vw.getHeight()))));
//BA.debugLineNum = 124;BA.debugLine="pnlHrsMinSecsLbl.SetLeftAndRight(0,pnlControl.Width)"[pageKitchenTimersBase/General script]
views.get("pnlhrsminsecslbl").vw.setLeft((int)(0d));
views.get("pnlhrsminsecslbl").vw.setWidth((int)((views.get("pnlcontrol").vw.getWidth()) - (0d)));
//BA.debugLineNum = 125;BA.debugLine="pnlHrsMinSecsLbl.SetTopAndBottom(pnlBtnsTop.bottom,pnlBtnsTop.bottom+(100%y*.05))"[pageKitchenTimersBase/General script]
views.get("pnlhrsminsecslbl").vw.setTop((int)((views.get("pnlbtnstop").vw.getTop() + views.get("pnlbtnstop").vw.getHeight())));
views.get("pnlhrsminsecslbl").vw.setHeight((int)((views.get("pnlbtnstop").vw.getTop() + views.get("pnlbtnstop").vw.getHeight())+((100d / 100 * height)*.05d) - ((views.get("pnlbtnstop").vw.getTop() + views.get("pnlbtnstop").vw.getHeight()))));
//BA.debugLineNum = 129;BA.debugLine="cc=pnlHrsMinSecsLbl.Width / 3"[pageKitchenTimersBase/General script]
_cc = BA.NumberToString((views.get("pnlhrsminsecslbl").vw.getWidth())/3d);
//BA.debugLineNum = 130;BA.debugLine="lblLabelHr.SetTopAndBottom(0,pnlHrsMinSecsLbl.Height)"[pageKitchenTimersBase/General script]
views.get("lbllabelhr").vw.setTop((int)(0d));
views.get("lbllabelhr").vw.setHeight((int)((views.get("pnlhrsminsecslbl").vw.getHeight()) - (0d)));
//BA.debugLineNum = 131;BA.debugLine="lblLabelHr.SetLeftAndRight(0,cc)"[pageKitchenTimersBase/General script]
views.get("lbllabelhr").vw.setLeft((int)(0d));
views.get("lbllabelhr").vw.setWidth((int)(Double.parseDouble(_cc) - (0d)));
//BA.debugLineNum = 132;BA.debugLine="lblLabelMin.SetTopAndBottom(0,pnlHrsMinSecsLbl.Height)"[pageKitchenTimersBase/General script]
views.get("lbllabelmin").vw.setTop((int)(0d));
views.get("lbllabelmin").vw.setHeight((int)((views.get("pnlhrsminsecslbl").vw.getHeight()) - (0d)));
//BA.debugLineNum = 133;BA.debugLine="lblLabelMin.SetLeftAndRight(cc,cc*2)"[pageKitchenTimersBase/General script]
views.get("lbllabelmin").vw.setLeft((int)(Double.parseDouble(_cc)));
views.get("lbllabelmin").vw.setWidth((int)(Double.parseDouble(_cc)*2d - (Double.parseDouble(_cc))));
//BA.debugLineNum = 134;BA.debugLine="lblLabelSec.SetTopAndBottom(0,pnlHrsMinSecsLbl.Height)"[pageKitchenTimersBase/General script]
views.get("lbllabelsec").vw.setTop((int)(0d));
views.get("lbllabelsec").vw.setHeight((int)((views.get("pnlhrsminsecslbl").vw.getHeight()) - (0d)));
//BA.debugLineNum = 135;BA.debugLine="lblLabelSec.SetLeftAndRight(cc*2,cc*3)"[pageKitchenTimersBase/General script]
views.get("lbllabelsec").vw.setLeft((int)(Double.parseDouble(_cc)*2d));
views.get("lbllabelsec").vw.setWidth((int)(Double.parseDouble(_cc)*3d - (Double.parseDouble(_cc)*2d)));
//BA.debugLineNum = 137;BA.debugLine="pnlDecrH.SetTopAndBottom(0dip,pnlBtnsBottom.Height)"[pageKitchenTimersBase/General script]
views.get("pnldecrh").vw.setTop((int)((0d * scale)));
views.get("pnldecrh").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 138;BA.debugLine="pnlDecrM.SetTopAndBottom(0dip,pnlBtnsBottom.Height)"[pageKitchenTimersBase/General script]
views.get("pnldecrm").vw.setTop((int)((0d * scale)));
views.get("pnldecrm").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 139;BA.debugLine="pnlDecrS.SetTopAndBottom(0dip,pnlBtnsBottom.Height)"[pageKitchenTimersBase/General script]
views.get("pnldecrs").vw.setTop((int)((0d * scale)));
views.get("pnldecrs").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 140;BA.debugLine="pnlDecrH.SetLeftAndRight(lblLabelHr.Left,lblLabelHr.Right)"[pageKitchenTimersBase/General script]
views.get("pnldecrh").vw.setLeft((int)((views.get("lbllabelhr").vw.getLeft())));
views.get("pnldecrh").vw.setWidth((int)((views.get("lbllabelhr").vw.getLeft() + views.get("lbllabelhr").vw.getWidth()) - ((views.get("lbllabelhr").vw.getLeft()))));
//BA.debugLineNum = 141;BA.debugLine="pnlDecrM.SetLeftAndRight(lblLabelMin.Left,lblLabelMin.Right)"[pageKitchenTimersBase/General script]
views.get("pnldecrm").vw.setLeft((int)((views.get("lbllabelmin").vw.getLeft())));
views.get("pnldecrm").vw.setWidth((int)((views.get("lbllabelmin").vw.getLeft() + views.get("lbllabelmin").vw.getWidth()) - ((views.get("lbllabelmin").vw.getLeft()))));
//BA.debugLineNum = 142;BA.debugLine="pnlDecrS.SetLeftAndRight(lblLabelSec.Left,lblLabelSec.Right)"[pageKitchenTimersBase/General script]
views.get("pnldecrs").vw.setLeft((int)((views.get("lbllabelsec").vw.getLeft())));
views.get("pnldecrs").vw.setWidth((int)((views.get("lbllabelsec").vw.getLeft() + views.get("lbllabelsec").vw.getWidth()) - ((views.get("lbllabelsec").vw.getLeft()))));
//BA.debugLineNum = 144;BA.debugLine="pnlIncH.SetTopAndBottom(0dip,pnlBtnsTop.Height)"[pageKitchenTimersBase/General script]
views.get("pnlinch").vw.setTop((int)((0d * scale)));
views.get("pnlinch").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 145;BA.debugLine="pnlIncM.SetTopAndBottom(0dip,pnlBtnsTop.Height)"[pageKitchenTimersBase/General script]
views.get("pnlincm").vw.setTop((int)((0d * scale)));
views.get("pnlincm").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 146;BA.debugLine="pnlIncS.SetTopAndBottom(0dip,pnlBtnsTop.Height)"[pageKitchenTimersBase/General script]
views.get("pnlincs").vw.setTop((int)((0d * scale)));
views.get("pnlincs").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 147;BA.debugLine="pnlIncH.SetLeftAndRight(lblLabelHr.Left,lblLabelHr.Right)"[pageKitchenTimersBase/General script]
views.get("pnlinch").vw.setLeft((int)((views.get("lbllabelhr").vw.getLeft())));
views.get("pnlinch").vw.setWidth((int)((views.get("lbllabelhr").vw.getLeft() + views.get("lbllabelhr").vw.getWidth()) - ((views.get("lbllabelhr").vw.getLeft()))));
//BA.debugLineNum = 148;BA.debugLine="pnlIncM.SetLeftAndRight(lblLabelMin.Left,lblLabelMin.Right)"[pageKitchenTimersBase/General script]
views.get("pnlincm").vw.setLeft((int)((views.get("lbllabelmin").vw.getLeft())));
views.get("pnlincm").vw.setWidth((int)((views.get("lbllabelmin").vw.getLeft() + views.get("lbllabelmin").vw.getWidth()) - ((views.get("lbllabelmin").vw.getLeft()))));
//BA.debugLineNum = 149;BA.debugLine="pnlIncS.SetLeftAndRight(lblLabelSec.Left,lblLabelSec.Right)"[pageKitchenTimersBase/General script]
views.get("pnlincs").vw.setLeft((int)((views.get("lbllabelsec").vw.getLeft())));
views.get("pnlincs").vw.setWidth((int)((views.get("lbllabelsec").vw.getLeft() + views.get("lbllabelsec").vw.getWidth()) - ((views.get("lbllabelsec").vw.getLeft()))));
//BA.debugLineNum = 152;BA.debugLine="btnIncrH5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btnincrh5").vw.setLeft((int)((0d * scale)));
views.get("btnincrh5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 153;BA.debugLine="btnIncrH5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincrh5").vw.setTop((int)((0d * scale)));
views.get("btnincrh5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 154;BA.debugLine="btnIncrH1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btnincrh1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btnincrh1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 155;BA.debugLine="btnIncrH1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincrh1").vw.setTop((int)((0d * scale)));
views.get("btnincrh1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 157;BA.debugLine="BtnIncM5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btnincm5").vw.setLeft((int)((0d * scale)));
views.get("btnincm5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 158;BA.debugLine="BtnIncM5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincm5").vw.setTop((int)((0d * scale)));
views.get("btnincm5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 159;BA.debugLine="BtnIncM1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btnincm1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btnincm1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 160;BA.debugLine="BtnIncM1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincm1").vw.setTop((int)((0d * scale)));
views.get("btnincm1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 162;BA.debugLine="BtnIncS5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btnincs5").vw.setLeft((int)((0d * scale)));
views.get("btnincs5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 163;BA.debugLine="BtnIncS5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincs5").vw.setTop((int)((0d * scale)));
views.get("btnincs5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 164;BA.debugLine="BtnIncS1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btnincs1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btnincs1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 165;BA.debugLine="BtnIncS1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btnincs1").vw.setTop((int)((0d * scale)));
views.get("btnincs1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 168;BA.debugLine="btnDecrH5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btndecrh5").vw.setLeft((int)((0d * scale)));
views.get("btndecrh5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 169;BA.debugLine="btnDecrH5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrh5").vw.setTop((int)((0d * scale)));
views.get("btndecrh5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 170;BA.debugLine="btnDecrH1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btndecrh1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btndecrh1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 171;BA.debugLine="btnDecrH1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrh1").vw.setTop((int)((0d * scale)));
views.get("btndecrh1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 173;BA.debugLine="btnDecrM5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btndecrm5").vw.setLeft((int)((0d * scale)));
views.get("btndecrm5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 174;BA.debugLine="btnDecrM5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrm5").vw.setTop((int)((0d * scale)));
views.get("btndecrm5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 175;BA.debugLine="btnDecrM1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btndecrm1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btndecrm1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 176;BA.debugLine="btnDecrM1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrm1").vw.setTop((int)((0d * scale)));
views.get("btndecrm1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 178;BA.debugLine="btnDecrS5.SetLeftAndRight(0dip,pnlIncH.Width/2)"[pageKitchenTimersBase/General script]
views.get("btndecrs5").vw.setLeft((int)((0d * scale)));
views.get("btndecrs5").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())/2d - ((0d * scale))));
//BA.debugLineNum = 179;BA.debugLine="btnDecrS5.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrs5").vw.setTop((int)((0d * scale)));
views.get("btndecrs5").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 180;BA.debugLine="btnDecrS1.SetLeftAndRight(pnlIncH.Width/2,pnlIncH.Width)"[pageKitchenTimersBase/General script]
views.get("btndecrs1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())/2d));
views.get("btndecrs1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth()) - ((views.get("pnlinch").vw.getWidth())/2d)));
//BA.debugLineNum = 181;BA.debugLine="btnDecrS1.SetTopAndBottom(0dip,pnlIncH.Height)"[pageKitchenTimersBase/General script]
views.get("btndecrs1").vw.setTop((int)((0d * scale)));
views.get("btndecrs1").vw.setHeight((int)((views.get("pnlinch").vw.getHeight()) - ((0d * scale))));
//BA.debugLineNum = 183;BA.debugLine="btnReset.Left = 64dip"[pageKitchenTimersBase/General script]
views.get("btnreset").vw.setLeft((int)((64d * scale)));
//BA.debugLineNum = 184;BA.debugLine="btnPause.Right = pnlBtnsMenu.Width - 64dip"[pageKitchenTimersBase/General script]
views.get("btnpause").vw.setLeft((int)((views.get("pnlbtnsmenu").vw.getWidth())-(64d * scale) - (views.get("btnpause").vw.getWidth())));
//BA.debugLineNum = 185;BA.debugLine="btnReset.SetTopAndBottom(0,pnlBtnsBottom.Height-4dip)"[pageKitchenTimersBase/General script]
views.get("btnreset").vw.setTop((int)(0d));
views.get("btnreset").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight())-(4d * scale) - (0d)));
//BA.debugLineNum = 186;BA.debugLine="btnPause.SetTopAndBottom(0,pnlBtnsBottom.Height-4dip)"[pageKitchenTimersBase/General script]
views.get("btnpause").vw.setTop((int)(0d));
views.get("btnpause").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight())-(4d * scale) - (0d)));
//BA.debugLineNum = 188;BA.debugLine="padSP = 24dip"[pageKitchenTimersBase/General script]
_padsp = BA.NumberToString((24d * scale));
//BA.debugLineNum = 190;BA.debugLine="pnlSplitterTopBtn1.SetLeftAndRight(pnlIncH.Width-3dip,pnlIncH.Width+3dip)"[pageKitchenTimersBase/General script]
views.get("pnlsplittertopbtn1").vw.setLeft((int)((views.get("pnlinch").vw.getWidth())-(3d * scale)));
views.get("pnlsplittertopbtn1").vw.setWidth((int)((views.get("pnlinch").vw.getWidth())+(3d * scale) - ((views.get("pnlinch").vw.getWidth())-(3d * scale))));
//BA.debugLineNum = 191;BA.debugLine="pnlSplitterTopBtn1.SetTopAndBottom(padSP,pnlBtnsTop.Height-padSP)"[pageKitchenTimersBase/General script]
views.get("pnlsplittertopbtn1").vw.setTop((int)(Double.parseDouble(_padsp)));
views.get("pnlsplittertopbtn1").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight())-Double.parseDouble(_padsp) - (Double.parseDouble(_padsp))));
//BA.debugLineNum = 192;BA.debugLine="pnlSplitterTopBtn2.SetLeftAndRight(pnlIncM.Width-3dip,pnlIncM.Width+3dip)"[pageKitchenTimersBase/General script]
views.get("pnlsplittertopbtn2").vw.setLeft((int)((views.get("pnlincm").vw.getWidth())-(3d * scale)));
views.get("pnlsplittertopbtn2").vw.setWidth((int)((views.get("pnlincm").vw.getWidth())+(3d * scale) - ((views.get("pnlincm").vw.getWidth())-(3d * scale))));
//BA.debugLineNum = 193;BA.debugLine="pnlSplitterTopBtn2.SetTopAndBottom(padSP,pnlBtnsTop.Height-padSP)"[pageKitchenTimersBase/General script]
views.get("pnlsplittertopbtn2").vw.setTop((int)(Double.parseDouble(_padsp)));
views.get("pnlsplittertopbtn2").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight())-Double.parseDouble(_padsp) - (Double.parseDouble(_padsp))));
//BA.debugLineNum = 195;BA.debugLine="pnlSplitterBottomBtn1.SetLeftAndRight(pnlDecrH.Width-3dip,pnlDecrH.Width+3dip)"[pageKitchenTimersBase/General script]
views.get("pnlsplitterbottombtn1").vw.setLeft((int)((views.get("pnldecrh").vw.getWidth())-(3d * scale)));
views.get("pnlsplitterbottombtn1").vw.setWidth((int)((views.get("pnldecrh").vw.getWidth())+(3d * scale) - ((views.get("pnldecrh").vw.getWidth())-(3d * scale))));
//BA.debugLineNum = 196;BA.debugLine="pnlSplitterBottomBtn1.SetTopAndBottom(padSP,pnlBtnsTop.Height-padSP)"[pageKitchenTimersBase/General script]
views.get("pnlsplitterbottombtn1").vw.setTop((int)(Double.parseDouble(_padsp)));
views.get("pnlsplitterbottombtn1").vw.setHeight((int)((views.get("pnlbtnstop").vw.getHeight())-Double.parseDouble(_padsp) - (Double.parseDouble(_padsp))));
//BA.debugLineNum = 197;BA.debugLine="pnlSplitterBottomBtn2.SetLeftAndRight(pnlDecrM.Width-3dip,pnlDecrM.Width+3dip)"[pageKitchenTimersBase/General script]
views.get("pnlsplitterbottombtn2").vw.setLeft((int)((views.get("pnldecrm").vw.getWidth())-(3d * scale)));
views.get("pnlsplitterbottombtn2").vw.setWidth((int)((views.get("pnldecrm").vw.getWidth())+(3d * scale) - ((views.get("pnldecrm").vw.getWidth())-(3d * scale))));
//BA.debugLineNum = 198;BA.debugLine="pnlSplitterBottomBtn2.SetTopAndBottom(padSP,pnlBtnsBottom.Height-padSP)"[pageKitchenTimersBase/General script]
views.get("pnlsplitterbottombtn2").vw.setTop((int)(Double.parseDouble(_padsp)));
views.get("pnlsplitterbottombtn2").vw.setHeight((int)((views.get("pnlbtnsbottom").vw.getHeight())-Double.parseDouble(_padsp) - (Double.parseDouble(_padsp))));

}
}