package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainpage2{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlscreenoff").vw.setLeft((int)(0d));
views.get("pnlscreenoff").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlscreenoff").vw.setTop((int)(0d));
views.get("pnlscreenoff").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlsplash").vw.setLeft((int)(0d));
views.get("pnlsplash").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlsplash").vw.setTop((int)(0d));
views.get("pnlsplash").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlwizards").vw.setLeft((int)(0d));
views.get("pnlwizards").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlwizards").vw.setTop((int)(0d));
views.get("pnlwizards").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("ivspash").vw.setLeft((int)((50d / 100 * width) - (views.get("ivspash").vw.getWidth() / 2)));
views.get("ivspash").vw.setTop((int)((46d / 100 * height) - (views.get("ivspash").vw.getHeight() / 2)));
views.get("lblsplash").vw.setTop((int)((86d / 100 * height) - (views.get("lblsplash").vw.getHeight() / 2)));
views.get("lblsplash").vw.setLeft((int)((views.get("pnlsplash").vw.getLeft())+(10d * scale)));
views.get("lblsplash").vw.setWidth((int)((views.get("pnlsplash").vw.getLeft() + views.get("pnlsplash").vw.getWidth())-(10d * scale) - ((views.get("pnlsplash").vw.getLeft())+(10d * scale))));
views.get("pnlmaster").vw.setLeft((int)(0d));
views.get("pnlmaster").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmaster").vw.setTop((int)(0d));
views.get("pnlmaster").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlheader").vw.setLeft((int)(0d));
views.get("pnlheader").vw.setWidth((int)((views.get("pnlmaster").vw.getLeft() + views.get("pnlmaster").vw.getWidth()) - (0d)));
views.get("pnlheader").vw.setTop((int)(0d));
views.get("pnlheader").vw.setHeight((int)((12d / 100 * height) - (0d)));
views.get("pnlmenu").vw.setLeft((int)(0d));
views.get("pnlmenu").vw.setWidth((int)((views.get("pnlmaster").vw.getLeft() + views.get("pnlmaster").vw.getWidth()) - (0d)));
views.get("pnlmenu").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlmenu").vw.setHeight((int)((views.get("pnlmaster").vw.getTop() + views.get("pnlmaster").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlfiles").vw.setLeft((int)(0d));
views.get("pnlfiles").vw.setWidth((int)((views.get("pnlmaster").vw.getLeft() + views.get("pnlmaster").vw.getWidth()) - (0d)));
views.get("pnlfiles").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlfiles").vw.setHeight((int)((views.get("pnlmaster").vw.getTop() + views.get("pnlmaster").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlmovement").vw.setLeft((int)(0d));
views.get("pnlmovement").vw.setWidth((int)((views.get("pnlmaster").vw.getLeft() + views.get("pnlmaster").vw.getWidth()) - (0d)));
views.get("pnlmovement").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlmovement").vw.setHeight((int)((views.get("pnlmaster").vw.getTop() + views.get("pnlmaster").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlprinting").vw.setLeft((int)(0d));
views.get("pnlprinting").vw.setWidth((int)((views.get("pnlmaster").vw.getLeft() + views.get("pnlmaster").vw.getWidth()) - (0d)));
views.get("pnlprinting").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlprinting").vw.setHeight((int)((views.get("pnlmaster").vw.getTop() + views.get("pnlmaster").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
((anywheresoftware.b4a.keywords.LayoutBuilder.DesignerTextSizeMethod)views.get("btnpageaction").vw).setTextSize((float)(32d));
((anywheresoftware.b4a.keywords.LayoutBuilder.DesignerTextSizeMethod)views.get("btnslidermenu").vw).setTextSize((float)(28d));
views.get("btnslidermenu").vw.setTop((int)(0d));
views.get("btnslidermenu").vw.setHeight((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("btnslidermenu").vw.setLeft((int)((views.get("pnlheader").vw.getLeft() + views.get("pnlheader").vw.getWidth()) - (views.get("btnslidermenu").vw.getWidth())));
views.get("btnslidermenu").vw.setWidth((int)((60d * scale)));
views.get("btnpageaction").vw.setTop((int)(0d));
views.get("btnpageaction").vw.setHeight((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("btnpageaction").vw.setLeft((int)(0d));
views.get("btnpageaction").vw.setWidth((int)((60d * scale)));
views.get("lblstatus").vw.setLeft((int)((views.get("btnpageaction").vw.getLeft() + views.get("btnpageaction").vw.getWidth())));
views.get("lblstatus").vw.setWidth((int)((views.get("btnslidermenu").vw.getLeft()) - ((views.get("btnpageaction").vw.getLeft() + views.get("btnpageaction").vw.getWidth()))));
views.get("lblstatus").vw.setTop((int)(0d));
views.get("lblstatus").vw.setHeight((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()) - (0d)));

}
}