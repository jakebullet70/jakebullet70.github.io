package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class guimsgs extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.guimsgs");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.guimsgs.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.keywords.StringBuilderWrapper _msg = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public anywheresoftware.b4a.objects.collections.Map  _buildmainsetup() throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 15;BA.debugLine="Public Sub BuildMainSetup() As Map";
 //BA.debugLineNum = 17;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 18;BA.debugLine="Dim m As Map : m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 18;BA.debugLine="Dim m As Map : m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 20;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe30b)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   General Settings")).PopAll().getObject()),(Object)("gn"));
 //BA.debugLineNum = 26;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xeb46)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Weather Settings")).PopAll().getObject()),(Object)("wth"));
 //BA.debugLineNum = 29;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe425)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Timers Settings")).PopAll().getObject()),(Object)("tm"));
 //BA.debugLineNum = 32;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe894)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Web Page Settings")).PopAll().getObject()),(Object)("wb"));
 //BA.debugLineNum = 35;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe05e)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Check For Update")).PopAll().getObject()),(Object)("up"));
 //BA.debugLineNum = 38;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.Map  _buildpresets() throws Exception{
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
int _i = 0;
 //BA.debugLineNum = 43;BA.debugLine="Public Sub BuildPresets() As Map";
 //BA.debugLineNum = 44;BA.debugLine="Dim cursor As Cursor = kt.timers_get_all";
_cursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
_cursor = _kt._timers_get_all /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ (getActivityBA());
 //BA.debugLineNum = 45;BA.debugLine="Dim m As Map : m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 45;BA.debugLine="Dim m As Map : m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 46;BA.debugLine="For i = 0 To cursor.RowCount - 1";
{
final int step4 = 1;
final int limit4 = (int) (_cursor.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 47;BA.debugLine="cursor.Position = i";
_cursor.setPosition(_i);
 //BA.debugLineNum = 48;BA.debugLine="m.Put(cursor.GetString(\"time\") & \"-\" & cursor.Ge";
_m.Put((Object)(_cursor.GetString("time")+"-"+_cursor.GetString("description")),(Object)(_cursor.GetString("id")));
 }
};
 //BA.debugLineNum = 50;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private Const mModule As String = \"guiMsgs\" 'igno";
_mmodule = "guiMsgs";
 //BA.debugLineNum = 6;BA.debugLine="Dim Msg As StringBuilder 'ignore";
_msg = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
