package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class config {
private static config mostCurrent = new config();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static String _mmodule = "";
public static String _license_file = "";
public static boolean _isinit = false;
public static String _empw = "";
public static String _lastconnectedclient = "";
public static boolean _pturnondebugtabflag = false;
public static boolean _androidtakeoversleepflag = false;
public static boolean _androidnotprintingscrnoffflag = false;
public static int _androidnotprintingmintill = 0;
public static boolean _androidprintingscrnoffflag = false;
public static int _androidprintingmintill = 0;
public static boolean _logpower_events = false;
public static boolean _logfile_events = false;
public static boolean _logrequest_octo_key = false;
public static boolean _logrest_api = false;
public static boolean _logtimer_events = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static String  _init(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Public Sub Init";
 //BA.debugLineNum = 44;BA.debugLine="oc.Klippy = Main.kvs.GetDefault(gblConst.IS_OCTO_";
mostCurrent._oc._klippy /*boolean*/  = BA.ObjectToBoolean(mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._getdefault /*Object*/ (mostCurrent._gblconst._is_octo_klippy /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.False)));
 //BA.debugLineNum = 45;BA.debugLine="LoadCfgs";
_loadcfgs(_ba);
 //BA.debugLineNum = 46;BA.debugLine="IsInit = True";
_isinit = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 48;BA.debugLine="If File.Exists(xui.DefaultFolder,LICENSE_FILE) =";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),_license_file)==anywheresoftware.b4a.keywords.Common.False) { 
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),_license_file,_xui.getDefaultFolder(),_license_file);};
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public static String  _loadcfgs(anywheresoftware.b4a.BA _ba) throws Exception{
sadLogic.OctoTouchController.dlggeneraloptions _o3 = null;
sadLogic.OctoTouchController.dlgandroidpoweroptions _o2 = null;
sadLogic.OctoTouchController.dlgoctopsusetup _o1 = null;
sadLogic.OctoTouchController.dlgfilamentsetup _oiz = null;
sadLogic.OctoTouchController.dlgbedlevelsetup _oiy = null;
sadLogic.OctoTouchController.dlgiponoffsetup _oiw = null;
int _jj = 0;
sadLogic.OctoTouchController.dlggcodecustsetup _oi7 = null;
sadLogic.OctoTouchController.dlgbltouchsetup _oid = null;
 //BA.debugLineNum = 52;BA.debugLine="Private Sub LoadCfgs()";
 //BA.debugLineNum = 54;BA.debugLine="If Main.kvs.ContainsKey(gblConst.SELECTED_CLR_THE";
if (mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._selected_clr_theme /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 55;BA.debugLine="Main.kvs.Put(gblConst.SELECTED_CLR_THEME,\"Prusa\"";
mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._selected_clr_theme /*String*/ ,(Object)("Prusa"));
 };
 //BA.debugLineNum = 58;BA.debugLine="If Main.kvs.ContainsKey(gblConst.Z_OFFSET_FLAG) =";
if (mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._z_offset_flag /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 59;BA.debugLine="Main.kvs.Put(gblConst.Z_OFFSET_FLAG,False)";
mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._z_offset_flag /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.False));
 };
 //BA.debugLineNum = 62;BA.debugLine="If Main.kvs.ContainsKey(gblConst.MANUAL_MESH_FLAG";
if (mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._manual_mesh_flag /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 63;BA.debugLine="Main.kvs.Put(gblConst.MANUAL_MESH_FLAG,False)";
mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._manual_mesh_flag /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.False));
 };
 //BA.debugLineNum = 69;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.GENERAL";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._general_options_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 70;BA.debugLine="Dim o3 As dlgGeneralOptions";
_o3 = new sadLogic.OctoTouchController.dlggeneraloptions();
 //BA.debugLineNum = 71;BA.debugLine="o3.initialize";
_o3._initialize /*Object*/ (_ba);
 //BA.debugLineNum = 72;BA.debugLine="o3.createdefaultfile";
_o3._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 74;BA.debugLine="ReadGeneralCFG";
_readgeneralcfg(_ba);
 //BA.debugLineNum = 79;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.ANDROID";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._android_power_options_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 80;BA.debugLine="Dim o2 As dlgAndroidPowerOptions";
_o2 = new sadLogic.OctoTouchController.dlgandroidpoweroptions();
 //BA.debugLineNum = 81;BA.debugLine="o2.Initialize";
_o2._initialize /*Object*/ (_ba);
 //BA.debugLineNum = 82;BA.debugLine="o2.CreateDefaultFile";
_o2._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 84;BA.debugLine="ReadAndroidPowerCFG";
_readandroidpowercfg(_ba);
 //BA.debugLineNum = 89;BA.debugLine="If Main.kvs.ContainsKey(gblConst.PWR_CTRL_ON) = F";
if (mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._pwr_ctrl_on /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 90;BA.debugLine="Dim o1 As dlgOctoPsuSetup";
_o1 = new sadLogic.OctoTouchController.dlgoctopsusetup();
 //BA.debugLineNum = 91;BA.debugLine="o1.Initialize(\"\")";
_o1._initialize /*Object*/ (_ba,"");
 //BA.debugLineNum = 92;BA.debugLine="o1.CreateDefaultOctoPowerCfg";
_o1._createdefaultoctopowercfg /*String*/ ();
 };
 //BA.debugLineNum = 98;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.FILAMEN";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._filament_change_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 99;BA.debugLine="Dim oiz As dlgFilamentSetup";
_oiz = new sadLogic.OctoTouchController.dlgfilamentsetup();
 //BA.debugLineNum = 100;BA.debugLine="oiz.Initialize";
_oiz._initialize /*Object*/ (_ba);
 //BA.debugLineNum = 101;BA.debugLine="oiz.CreateDefaultFile";
_oiz._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 107;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.BED_MAN";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._bed_manual_level_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 108;BA.debugLine="Dim oiy As dlgBedLevelSetup";
_oiy = new sadLogic.OctoTouchController.dlgbedlevelsetup();
 //BA.debugLineNum = 109;BA.debugLine="oiy.Initialize";
_oiy._initialize /*Object*/ (_ba);
 //BA.debugLineNum = 110;BA.debugLine="oiy.CreateDefaultFile";
_oiy._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 119;BA.debugLine="If File.Exists(xui.DefaultFolder,\"1\" & gblConst.H";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),"1"+mostCurrent._gblconst._http_onoff_setup_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 120;BA.debugLine="Dim oiw As dlgIpOnOffSetup";
_oiw = new sadLogic.OctoTouchController.dlgiponoffsetup();
 //BA.debugLineNum = 121;BA.debugLine="oiw.Initialize(Null,Null)";
_oiw._initialize /*Object*/ (_ba,anywheresoftware.b4a.keywords.Common.Null,BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 122;BA.debugLine="For jj = 1 To 8";
{
final int step40 = 1;
final int limit40 = (int) (8);
_jj = (int) (1) ;
for (;_jj <= limit40 ;_jj = _jj + step40 ) {
 //BA.debugLineNum = 123;BA.debugLine="oiw.CreateDefaultDataFile(jj & gblConst.HTTP_ON";
_oiw._createdefaultdatafile /*String*/ (BA.NumberToString(_jj)+mostCurrent._gblconst._http_onoff_setup_file /*String*/ );
 }
};
 };
 //BA.debugLineNum = 136;BA.debugLine="If File.Exists(xui.DefaultFolder,\"7\" & gblConst.G";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),"7"+mostCurrent._gblconst._gcode_custom_setup_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 137;BA.debugLine="Dim oi7 As dlgGCodeCustSetup";
_oi7 = new sadLogic.OctoTouchController.dlggcodecustsetup();
 //BA.debugLineNum = 138;BA.debugLine="oi7.Initialize(Null,Null)";
_oi7._initialize /*Object*/ (_ba,anywheresoftware.b4a.keywords.Common.Null,BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 139;BA.debugLine="For jj = 0 To 7";
{
final int step47 = 1;
final int limit47 = (int) (7);
_jj = (int) (0) ;
for (;_jj <= limit47 ;_jj = _jj + step47 ) {
 //BA.debugLineNum = 140;BA.debugLine="If File.Exists(xui.DefaultFolder,jj & gblConst.";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),BA.NumberToString(_jj)+mostCurrent._gblconst._gcode_custom_setup_file /*String*/ )==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 141;BA.debugLine="Continue";
if (true) continue;
 };
 //BA.debugLineNum = 143;BA.debugLine="oi7.CreateDefaultDataFile(jj & gblConst.GCODE_C";
_oi7._createdefaultdatafile /*String*/ (BA.NumberToString(_jj)+mostCurrent._gblconst._gcode_custom_setup_file /*String*/ );
 }
};
 };
 //BA.debugLineNum = 150;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.BLCR_TO";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._blcr_touch_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 151;BA.debugLine="Dim oid As dlgBLTouchSetup";
_oid = new sadLogic.OctoTouchController.dlgbltouchsetup();
 //BA.debugLineNum = 152;BA.debugLine="oid.Initialize";
_oid._initialize /*Object*/ (_ba);
 //BA.debugLineNum = 153;BA.debugLine="oid.CreateDefaultFile";
_oid._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Const mModule As String = \"config\" 'ignor";
_mmodule = "config";
 //BA.debugLineNum = 11;BA.debugLine="Private Const LICENSE_FILE As String = \"LICENSE.t";
_license_file = "LICENSE.txt";
 //BA.debugLineNum = 12;BA.debugLine="Public IsInit As Boolean = False";
_isinit = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 15;BA.debugLine="Public empw As String = \"b4x!sadLogic512\" '--- ma";
_empw = "b4x!sadLogic512";
 //BA.debugLineNum = 17;BA.debugLine="Public LastConnectedClient As String";
_lastconnectedclient = "";
 //BA.debugLineNum = 18;BA.debugLine="Public pTurnOnDebugTabFLAG As Boolean";
_pturnondebugtabflag = false;
 //BA.debugLineNum = 21;BA.debugLine="Public AndroidTakeOverSleepFLAG As Boolean = Fals";
_androidtakeoversleepflag = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 22;BA.debugLine="Public AndroidNotPrintingScrnOffFLAG As Boolean =";
_androidnotprintingscrnoffflag = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 23;BA.debugLine="Public AndroidNotPrintingMinTill As Int";
_androidnotprintingmintill = 0;
 //BA.debugLineNum = 24;BA.debugLine="Public AndroidPrintingScrnOffFLAG As Boolean = Fa";
_androidprintingscrnoffflag = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 25;BA.debugLine="Public AndroidPrintingMinTill As Int";
_androidprintingmintill = 0;
 //BA.debugLineNum = 28;BA.debugLine="Public logPOWER_EVENTS As Boolean = False";
_logpower_events = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 29;BA.debugLine="Public logFILE_EVENTS As Boolean = False";
_logfile_events = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 30;BA.debugLine="Public logREQUEST_OCTO_KEY As Boolean = False";
_logrequest_octo_key = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 31;BA.debugLine="Public logREST_API As Boolean = False";
_logrest_api = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 34;BA.debugLine="Public logTIMER_EVENTS As Boolean = False '--- no";
_logtimer_events = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public static String  _readandroidpowercfg(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
 //BA.debugLineNum = 217;BA.debugLine="Public Sub ReadAndroidPowerCFG";
 //BA.debugLineNum = 219;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._android_power_options_file /*String*/ );
 //BA.debugLineNum = 221;BA.debugLine="AndroidTakeOverSleepFLAG = Data.Get(\"TakePwr\")";
_androidtakeoversleepflag = BA.ObjectToBoolean(_data.Get((Object)("TakePwr")));
 //BA.debugLineNum = 222;BA.debugLine="AndroidNotPrintingScrnOffFLAG = Data.Get(\"NotPrin";
_androidnotprintingscrnoffflag = BA.ObjectToBoolean(_data.Get((Object)("NotPrintingScrnOff")));
 //BA.debugLineNum = 223;BA.debugLine="AndroidNotPrintingMinTill  = Data.Get(\"NotPrintin";
_androidnotprintingmintill = (int)(BA.ObjectToNumber(_data.Get((Object)("NotPrintingMinTill"))));
 //BA.debugLineNum = 224;BA.debugLine="AndroidPrintingScrnOffFLAG  = Data.Get(\"PrintingS";
_androidprintingscrnoffflag = BA.ObjectToBoolean(_data.Get((Object)("PrintingScrnOff")));
 //BA.debugLineNum = 225;BA.debugLine="AndroidPrintingMinTill  = Data.Get(\"PrintingMinTi";
_androidprintingmintill = (int)(BA.ObjectToNumber(_data.Get((Object)("PrintingMinTill"))));
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return "";
}
public static boolean  _readblcrtouchflag(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
 //BA.debugLineNum = 165;BA.debugLine="Public Sub ReadBLCRtouchFLAG() As Boolean";
 //BA.debugLineNum = 166;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._blcr_touch_file /*String*/ );
 //BA.debugLineNum = 167;BA.debugLine="Return Data.Get(gblConst.probeShow).As(Boolean)";
if (true) return (BA.ObjectToBoolean(_data.Get((Object)(mostCurrent._gblconst._probeshow /*String*/ ))));
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return false;
}
public static String  _readgeneralcfg(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
 //BA.debugLineNum = 193;BA.debugLine="Public Sub ReadGeneralCFG";
 //BA.debugLineNum = 195;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._general_options_file /*String*/ );
 //BA.debugLineNum = 199;BA.debugLine="oc.PrinterProfileInvertedX = Data.GetDefault(\"axe";
mostCurrent._oc._printerprofileinvertedx /*boolean*/  = BA.ObjectToBoolean(_data.GetDefault((Object)("axesx"),(Object)(anywheresoftware.b4a.keywords.Common.False)));
 //BA.debugLineNum = 200;BA.debugLine="oc.PrinterProfileInvertedY = Data.GetDefault(\"axe";
mostCurrent._oc._printerprofileinvertedy /*boolean*/  = BA.ObjectToBoolean(_data.GetDefault((Object)("axesy"),(Object)(anywheresoftware.b4a.keywords.Common.False)));
 //BA.debugLineNum = 201;BA.debugLine="oc.PrinterProfileInvertedZ = Data.GetDefault(\"axe";
mostCurrent._oc._printerprofileinvertedz /*boolean*/  = BA.ObjectToBoolean(_data.GetDefault((Object)("axesz"),(Object)(anywheresoftware.b4a.keywords.Common.False)));
 //BA.debugLineNum = 203;BA.debugLine="If Data.Get(\"logall\").As(Boolean) Then";
if ((BA.ObjectToBoolean(_data.Get((Object)("logall"))))) { 
 //BA.debugLineNum = 204;BA.debugLine="logPOWER_EVENTS = True";
_logpower_events = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 205;BA.debugLine="logFILE_EVENTS = True";
_logfile_events = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 206;BA.debugLine="logREQUEST_OCTO_KEY = True";
_logrequest_octo_key = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 207;BA.debugLine="logREST_API = True";
_logrest_api = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 209;BA.debugLine="logPOWER_EVENTS = Data.Get(\"logpwr\").As(Boolean)";
_logpower_events = (BA.ObjectToBoolean(_data.Get((Object)("logpwr"))));
 //BA.debugLineNum = 210;BA.debugLine="logFILE_EVENTS = Data.Get(\"logfiles\").As(Boolean";
_logfile_events = (BA.ObjectToBoolean(_data.Get((Object)("logfiles"))));
 //BA.debugLineNum = 211;BA.debugLine="logREQUEST_OCTO_KEY = Data.Get(\"logoctokey\").As(";
_logrequest_octo_key = (BA.ObjectToBoolean(_data.Get((Object)("logoctokey"))));
 //BA.debugLineNum = 212;BA.debugLine="logREST_API = Data.Get(\"logrest\").As(Boolean)";
_logrest_api = (BA.ObjectToBoolean(_data.Get((Object)("logrest"))));
 };
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public static boolean  _readmanualbedmeshlevelflag(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 188;BA.debugLine="Public Sub ReadManualBedMeshLevelFLAG As Boolean";
 //BA.debugLineNum = 189;BA.debugLine="Return Main.kvs.Get(gblConst.MANUAL_MESH_FLAG).As";
if (true) return (BA.ObjectToBoolean(mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (mostCurrent._gblconst._manual_mesh_flag /*String*/ )));
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return false;
}
public static boolean  _readmanualbedscrewlevelflag(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
 //BA.debugLineNum = 170;BA.debugLine="Public Sub ReadManualBedScrewLevelFLAG As Boolean";
 //BA.debugLineNum = 171;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._bed_manual_level_file /*String*/ );
 //BA.debugLineNum = 172;BA.debugLine="Return Data.Get(gblConst.bedManualShow).As(Boolea";
if (true) return (BA.ObjectToBoolean(_data.Get((Object)(mostCurrent._gblconst._bedmanualshow /*String*/ ))));
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return false;
}
public static boolean  _readpwrcfgflag(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 180;BA.debugLine="Public Sub ReadPwrCfgFLAG As Boolean";
 //BA.debugLineNum = 181;BA.debugLine="Return Main.kvs.Get(gblConst.PWR_CTRL_ON).As(Bool";
if (true) return (BA.ObjectToBoolean(mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (mostCurrent._gblconst._pwr_ctrl_on /*String*/ )));
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return false;
}
public static boolean  _readwizardfilamentchangeflag(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
 //BA.debugLineNum = 175;BA.debugLine="Public Sub ReadWizardFilamentChangeFLAG As Boolean";
 //BA.debugLineNum = 176;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._filament_change_file /*String*/ );
 //BA.debugLineNum = 177;BA.debugLine="Return Data.Get(gblConst.filShow).As(Boolean)";
if (true) return (BA.ObjectToBoolean(_data.Get((Object)(mostCurrent._gblconst._filshow /*String*/ ))));
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return false;
}
public static boolean  _readzoffsetflag(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 184;BA.debugLine="Public Sub ReadZOffsetFLAG As Boolean";
 //BA.debugLineNum = 185;BA.debugLine="Return Main.kvs.Get(gblConst.Z_OFFSET_FLAG).As(Bo";
if (true) return (BA.ObjectToBoolean(mostCurrent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ (mostCurrent._gblconst._z_offset_flag /*String*/ )));
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return false;
}
}
