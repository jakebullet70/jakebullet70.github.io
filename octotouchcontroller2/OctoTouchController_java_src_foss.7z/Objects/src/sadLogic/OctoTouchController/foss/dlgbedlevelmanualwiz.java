package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgbedlevelmanualwiz extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.foss.sadpreferencesdialog _mwizdlg = null;
public sadLogic.OctoTouchController.foss.sadpreferencesdialoghelper _prefhelper = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblmsgsteps = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpreheat = null;
public anywheresoftware.b4a.objects.collections.Map _mdata = null;
public int _current_point = 0;
public int[] _point1 = null;
public int[] _point2 = null;
public int[] _point3 = null;
public int[] _point4 = null;
public int _min_x = 0;
public int _max_x = 0;
public int _min_y = 0;
public int _max_y = 0;
public String _endgcode = "";
public String _startgcode = "";
public int _zspeed = 0;
public int _xyspeed = 0;
public String _gcodesendlevelingpoint = "";
public String _gcode2send = "";
public String _movetext = "";
public anywheresoftware.b4a.objects.PanelWrapper _parent = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlsteps = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbg = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlhost = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnclose = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn2 = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _alblheader = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _alblmenu = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblheaterbed = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblheatertool = null;
public anywheresoftware.b4a.objects.Timer _tmrheateronoff = null;
public sadLogic.OctoTouchController.foss.soundsbeeps _obeepme = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _btnclose_click() throws Exception{
 //BA.debugLineNum = 435;BA.debugLine="Private Sub btnClose_Click";
 //BA.debugLineNum = 436;BA.debugLine="Close_Me";
_close_me();
 //BA.debugLineNum = 437;BA.debugLine="End Sub";
return "";
}
public String  _btnpreheat_click() throws Exception{
 //BA.debugLineNum = 445;BA.debugLine="Private Sub btnPreHeat_Click";
 //BA.debugLineNum = 446;BA.debugLine="CallSub(B4XPages.MainPage,\"ShowPreHeatMenu_All\")";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"ShowPreHeatMenu_All");
 //BA.debugLineNum = 447;BA.debugLine="End Sub";
return "";
}
public String  _btnstart_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
 //BA.debugLineNum = 151;BA.debugLine="Private Sub btnStart_Click";
 //BA.debugLineNum = 152;BA.debugLine="Dim b As Button : b = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 152;BA.debugLine="Dim b As Button : b = Sender";
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 153;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 155;BA.debugLine="btn1.RequestFocus";
_btn1.RequestFocus();
 //BA.debugLineNum = 158;BA.debugLine="If b.Text = \"START\" Then";
if ((_b.getText()).equals("START")) { 
 //BA.debugLineNum = 161;BA.debugLine="mData = mWizDlg.PeekEditedData";
_mdata = _mwizdlg._getpeekediteddata /*anywheresoftware.b4a.objects.collections.Map*/ ();
 //BA.debugLineNum = 162;BA.debugLine="If SetMinMaxAndSpeeds = False Or SetPoints = Fal";
if (_setminmaxandspeeds()==__c.False || _setpoints()==__c.False) { 
 //BA.debugLineNum = 163;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
__c.CallSubDelayed3(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("STOP! Error parsing offsets / speeds:  "+BA.NumberToString(_current_point)),(Object)(3500));
 //BA.debugLineNum = 164;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 167;BA.debugLine="current_point = 0";
_current_point = (int) (0);
 //BA.debugLineNum = 168;BA.debugLine="b.Text = \"NEXT\"";
_b.setText(BA.ObjectToCharSequence("NEXT"));
 //BA.debugLineNum = 169;BA.debugLine="btn2.Visible = True";
_btn2.setVisible(__c.True);
 //BA.debugLineNum = 170;BA.debugLine="btnClose.Visible = False";
_btnclose.setVisible(__c.False);
 //BA.debugLineNum = 174;BA.debugLine="pnlSteps.Visible = True";
_pnlsteps.setVisible(__c.True);
 //BA.debugLineNum = 175;BA.debugLine="ProcessSteps";
_processsteps();
 //BA.debugLineNum = 176;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 182;BA.debugLine="If b.Text = \"NEXT\" Then";
if ((_b.getText()).equals("NEXT")) { 
 //BA.debugLineNum = 183;BA.debugLine="current_point = current_point + 1";
_current_point = (int) (_current_point+1);
 //BA.debugLineNum = 184;BA.debugLine="ProcessSteps";
_processsteps();
 };
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public String  _btnstop_click() throws Exception{
 //BA.debugLineNum = 189;BA.debugLine="Private Sub btnStop_Click";
 //BA.debugLineNum = 191;BA.debugLine="btn2.Visible = False";
_btn2.setVisible(__c.False);
 //BA.debugLineNum = 193;BA.debugLine="btn1.Text = \"START\"";
_btn1.setText(BA.ObjectToCharSequence("START"));
 //BA.debugLineNum = 194;BA.debugLine="btnClose.Visible = True";
_btnclose.setVisible(__c.True);
 //BA.debugLineNum = 195;BA.debugLine="pnlSteps.Visible = False";
_pnlsteps.setVisible(__c.False);
 //BA.debugLineNum = 196;BA.debugLine="btnClose.RequestFocus";
_btnclose.RequestFocus();
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 71;BA.debugLine="pnlBG.Color = clrTheme.Background";
_pnlbg.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(alblHead";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_alblheader._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_alblmenu._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheaterbed.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheatertool.getObject()))});
 //BA.debugLineNum = 73;BA.debugLine="If guiHelpers.gIsLandScape = False Then  alblMenu";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False) { 
_alblmenu._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setVisible(__c.False);};
 //BA.debugLineNum = 74;BA.debugLine="alblHeader.Text = \"Manual Bed Leveling Wizard\"";
_alblheader._settext /*Object*/ ((Object)("Manual Bed Leveling Wizard"));
 //BA.debugLineNum = 75;BA.debugLine="parent.Visible = True";
_parent.setVisible(__c.True);
 //BA.debugLineNum = 76;BA.debugLine="pnlSteps.Color =clrTheme.Background";
_pnlsteps.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 77;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnClose,bt";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnclose,_btnpreheat,_btn1,_btn2});
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public Object  _buildhelptexthighlight(String _txt2hilight,String _maintxt) throws Exception{
String _m1 = "";
String _m2 = "";
anywheresoftware.b4a.objects.CSBuilder _cs = null;
 //BA.debugLineNum = 394;BA.debugLine="Private Sub BuildHelpTextHighlight(txt2hiLight As";
 //BA.debugLineNum = 396;BA.debugLine="Dim m1 As String = Regex.Split(\"!P!\",maintxt)(0)";
_m1 = __c.Regex.Split("!P!",_maintxt)[(int) (0)];
 //BA.debugLineNum = 397;BA.debugLine="Dim m2 As String = Regex.Split(\"!P!\",maintxt)(1)";
_m2 = __c.Regex.Split("!P!",_maintxt)[(int) (1)];
 //BA.debugLineNum = 399;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 400;BA.debugLine="Return cs.Initialize.Color(clrTheme.txtAccent).Ap";
if (true) return (Object)(_cs.Initialize().Color(_clrtheme._txtaccent /*int*/ ).Append(BA.ObjectToCharSequence(_m1)).Color(_clrtheme._txtnormal /*int*/ ).Append(BA.ObjectToCharSequence(_txt2hilight)).Color(_clrtheme._txtaccent /*int*/ ).Append(BA.ObjectToCharSequence(_m2)).PopAll().getObject());
 //BA.debugLineNum = 403;BA.debugLine="End Sub";
return null;
}
public String  _buildwizbtns() throws Exception{
 //BA.debugLineNum = 124;BA.debugLine="Private Sub BuildWizBtns";
 //BA.debugLineNum = 125;BA.debugLine="guiHelpers.ResizeText(\"Tool: \" & CRLF & \"200\",lbl";
_guihelpers._resizetext /*String*/ (ba,(Object)("Tool: "+__c.CRLF+"200"),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheatertool.getObject())));
 //BA.debugLineNum = 126;BA.debugLine="guiHelpers.ResizeText(\"Bed: \" &CRLF & \"100\",	lblH";
_guihelpers._resizetext /*String*/ (ba,(Object)("Bed: "+__c.CRLF+"100"),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheaterbed.getObject())));
 //BA.debugLineNum = 127;BA.debugLine="btn1.Text = \"START\"";
_btn1.setText(BA.ObjectToCharSequence("START"));
 //BA.debugLineNum = 128;BA.debugLine="btn2.Text = \"STOP\"";
_btn2.setText(BA.ObjectToCharSequence("STOP"));
 //BA.debugLineNum = 129;BA.debugLine="btn1.TextSize =  20'mWizDlg.Dialog.GetButton(xui.";
_btn1.setTextSize((float) (20));
 //BA.debugLineNum = 130;BA.debugLine="btn2.TextSize = btn1.TextSize";
_btn2.setTextSize(_btn1.getTextSize());
 //BA.debugLineNum = 133;BA.debugLine="lblMsgSteps.Initialize(\"\")";
_lblmsgsteps.Initialize(ba,"");
 //BA.debugLineNum = 134;BA.debugLine="lblMsgSteps.Color = clrTheme.Background";
_lblmsgsteps.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 135;BA.debugLine="lblMsgSteps.TextColor = clrTheme.txtAccent";
_lblmsgsteps.setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 136;BA.debugLine="lblMsgSteps.SetTextSizeAnimated(300,22)";
_lblmsgsteps.SetTextSizeAnimated((int) (300),(float) (22));
 //BA.debugLineNum = 137;BA.debugLine="lblMsgSteps.SingleLine = False";
_lblmsgsteps.setSingleLine(__c.False);
 //BA.debugLineNum = 138;BA.debugLine="lblMsgSteps.Gravity = Bit.Or(Gravity.CENTER_VERTI";
_lblmsgsteps.setGravity(__c.Bit.Or(__c.Gravity.CENTER_VERTICAL,__c.Gravity.CENTER_HORIZONTAL));
 //BA.debugLineNum = 139;BA.debugLine="lblMsgSteps.Text = \"Bed Leveling Wizard\"";
_lblmsgsteps.setText(BA.ObjectToCharSequence("Bed Leveling Wizard"));
 //BA.debugLineNum = 141;BA.debugLine="pnlSteps.AddView(lblMsgSteps, 2dip,  50dip,  _";
_pnlsteps.AddView((android.view.View)(_lblmsgsteps.getObject()),__c.DipToCurrent((int) (2)),__c.DipToCurrent((int) (50)),(int) (_mwizdlg._customlistview1 /*b4a.example3.customlistview*/ ._getbase().GetView((int) (0)).getWidth()-__c.DipToCurrent((int) (2))),__c.DipToCurrent((int) (160)));
 //BA.debugLineNum = 146;BA.debugLine="btn2.Visible = False";
_btn2.setVisible(__c.False);
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private Const mModule As String = \"dlgBedLevelMan";
_mmodule = "dlgBedLevelManualWiz";
 //BA.debugLineNum = 18;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 19;BA.debugLine="Private mWizDlg As sadPreferencesDialog";
_mwizdlg = new sadLogic.OctoTouchController.foss.sadpreferencesdialog();
 //BA.debugLineNum = 20;BA.debugLine="Private prefHelper As sadPreferencesDialogHelper";
_prefhelper = new sadLogic.OctoTouchController.foss.sadpreferencesdialoghelper();
 //BA.debugLineNum = 21;BA.debugLine="Private lblMsgSteps As Label, btnPreheat As Butto";
_lblmsgsteps = new anywheresoftware.b4a.objects.LabelWrapper();
_btnpreheat = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private mData As Map";
_mdata = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 24;BA.debugLine="Private current_point As Int  = 0";
_current_point = (int) (0);
 //BA.debugLineNum = 25;BA.debugLine="Private point1(),point2(),point3(),point4() As In";
_point1 = new int[(int) (0)];
;
_point2 = new int[(int) (0)];
;
_point3 = new int[(int) (0)];
;
_point4 = new int[(int) (0)];
;
 //BA.debugLineNum = 26;BA.debugLine="Private min_x, max_x,  min_y,max_y As Int 'ignore";
_min_x = 0;
_max_x = 0;
_min_y = 0;
_max_y = 0;
 //BA.debugLineNum = 27;BA.debugLine="Private endGCode, startGCode As String";
_endgcode = "";
_startgcode = "";
 //BA.debugLineNum = 28;BA.debugLine="Private zSpeed, xySpeed As Int";
_zspeed = 0;
_xyspeed = 0;
 //BA.debugLineNum = 29;BA.debugLine="Private gcodeSendLevelingPoint As String";
_gcodesendlevelingpoint = "";
 //BA.debugLineNum = 30;BA.debugLine="Private gcode2send,moveText As String";
_gcode2send = "";
_movetext = "";
 //BA.debugLineNum = 31;BA.debugLine="Private parent As Panel";
_parent = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private pnlSteps,pnlBG,pnlHost As Panel";
_pnlsteps = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlbg = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlhost = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private btnClose,btn1,btn2 As Button";
_btnclose = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn2 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private alblHeader,alblMenu As AutoTextSizeLabel";
_alblheader = new sadLogic.OctoTouchController.foss.autotextsizelabel();
_alblmenu = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 41;BA.debugLine="Private lblHeaterBed,lblHeaterTool As Label";
_lblheaterbed = new anywheresoftware.b4a.objects.LabelWrapper();
_lblheatertool = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private tmrHeaterOnOff As Timer";
_tmrheateronoff = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 44;BA.debugLine="Private oBeepMe As SoundsBeeps";
_obeepme = new sadLogic.OctoTouchController.foss.soundsbeeps();
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 439;BA.debugLine="Public Sub Close_Me '--- class method";
 //BA.debugLineNum = 440;BA.debugLine="parent.SetVisibleAnimated(500,False)";
_parent.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 441;BA.debugLine="mWizDlg.BackKeyPressed";
_mwizdlg._backkeypressed /*boolean*/ ();
 //BA.debugLineNum = 442;BA.debugLine="parent.RemoveAllViews";
_parent.RemoveAllViews();
 //BA.debugLineNum = 443;BA.debugLine="End Sub";
return "";
}
public String  _dlggeneral_beforedialogdisplayed(Object _template) throws Exception{
 //BA.debugLineNum = 431;BA.debugLine="Private Sub dlgGeneral_BeforeDialogDisplayed (Temp";
 //BA.debugLineNum = 432;BA.debugLine="prefHelper.SkinDialog(Template)";
_prefhelper._skindialog /*String*/ (_template);
 //BA.debugLineNum = 433;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.PanelWrapper _p) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Public Sub Initialize(p As Panel) As Object";
 //BA.debugLineNum = 56;BA.debugLine="p.RemoveAllViews";
_p.RemoveAllViews();
 //BA.debugLineNum = 57;BA.debugLine="parent = p";
_parent = _p;
 //BA.debugLineNum = 58;BA.debugLine="oBeepMe.Initialize";
_obeepme._initialize /*String*/ (ba);
 //BA.debugLineNum = 66;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public String  _pnlbg_click() throws Exception{
 //BA.debugLineNum = 406;BA.debugLine="Private Sub pnlBG_Click";
 //BA.debugLineNum = 409;BA.debugLine="End Sub";
return "";
}
public void  _processsteps() throws Exception{
ResumableSub_ProcessSteps rsub = new ResumableSub_ProcessSteps(this);
rsub.resume(ba, null);
}
public static class ResumableSub_ProcessSteps extends BA.ResumableSub {
public ResumableSub_ProcessSteps(sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz parent;
Object _txthelp = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 201;BA.debugLine="Dim txtHelp As Object";
_txthelp = new Object();
 //BA.debugLineNum = 203;BA.debugLine="mData = mWizDlg.PeekEditedData";
parent._mdata = parent._mwizdlg._getpeekediteddata /*anywheresoftware.b4a.objects.collections.Map*/ ();
 //BA.debugLineNum = 204;BA.debugLine="gcodeSendLevelingPoint = $\"G1 Z${mData.Get(gblCon";
parent._gcodesendlevelingpoint = ("G1 Z"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._bedmanuallevelheight /*String*/ )))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._zspeed))+"");
 //BA.debugLineNum = 205;BA.debugLine="logMe.LogDebug2(\"Point: \" & current_point,\"Proces";
parent._logme._logdebug2 /*String*/ (ba,"Point: "+BA.NumberToString(parent._current_point),"ProcessSteps");
 //BA.debugLineNum = 209;BA.debugLine="Select Case current_point";
if (true) break;

case 1:
//select
this.state = 36;
switch (parent._current_point) {
case 0: {
this.state = 3;
if (true) break;
}
case 1: 
case 2: 
case 3: 
case 4: 
case 5: 
case 6: {
this.state = 5;
if (true) break;
}
case 7: {
this.state = 35;
if (true) break;
}
}
if (true) break;

case 3:
//C
this.state = 36;
 //BA.debugLineNum = 211;BA.debugLine="oBeepMe.Beeps(300,500,1)";
parent._obeepme._beeps /*void*/ ((long) (300),(long) (500),(int) (1));
 //BA.debugLineNum = 213;BA.debugLine="lblMsgSteps.Text = \"Starting GCode sent... Touc";
parent._lblmsgsteps.setText(BA.ObjectToCharSequence("Starting GCode sent... Touch NEXT when complete to start the leveling sequence."));
 //BA.debugLineNum = 214;BA.debugLine="SendMGcode(startGCode) : Wait For SendMGcode";
parent._sendmgcode(parent._startgcode);
 //BA.debugLineNum = 214;BA.debugLine="SendMGcode(startGCode) : Wait For SendMGcode";
parent.__c.WaitFor("sendmgcode", ba, this, null);
this.state = 37;
return;
case 37:
//C
this.state = 36;
;
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 217;BA.debugLine="SendMGcode(\"G90\") : Sleep(100) '--- absolute po";
parent._sendmgcode("G90");
 //BA.debugLineNum = 217;BA.debugLine="SendMGcode(\"G90\") : Sleep(100) '--- absolute po";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 38;
return;
case 38:
//C
this.state = 6;
;
 //BA.debugLineNum = 219;BA.debugLine="Try";
if (true) break;

case 6:
//try
this.state = 33;
this.catchState = 32;
this.state = 8;
if (true) break;

case 8:
//C
this.state = 9;
this.catchState = 32;
 //BA.debugLineNum = 222;BA.debugLine="gcode2send = $\"G1 Z${mData.Get(gblConst.bedMan";
parent._gcode2send = ("G1 Z"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._bedmanualtravelheight /*String*/ )))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._zspeed))+"");
 //BA.debugLineNum = 223;BA.debugLine="SendMGcode(gcode2send) : Sleep(100)";
parent._sendmgcode(parent._gcode2send);
 //BA.debugLineNum = 223;BA.debugLine="SendMGcode(gcode2send) : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 39;
return;
case 39:
//C
this.state = 9;
;
 //BA.debugLineNum = 226;BA.debugLine="Select Case current_point";
if (true) break;

case 9:
//select
this.state = 30;
switch (parent._current_point) {
case 1: 
case 5: {
this.state = 11;
if (true) break;
}
case 2: 
case 6: {
this.state = 19;
if (true) break;
}
case 3: {
this.state = 27;
if (true) break;
}
case 4: {
this.state = 29;
if (true) break;
}
}
if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 228;BA.debugLine="gcode2send = $\"G1 X${point1(0)} Y${point1(1)";
parent._gcode2send = ("G1 X"+parent.__c.SmartStringFormatter("",(Object)(parent._point1[(int) (0)]))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._point1[(int) (1)]))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._xyspeed))+"");
 //BA.debugLineNum = 229;BA.debugLine="If current_point = 1 Then";
if (true) break;

case 12:
//if
this.state = 17;
if (parent._current_point==1) { 
this.state = 14;
}else {
this.state = 16;
}if (true) break;

case 14:
//C
this.state = 17;
 //BA.debugLineNum = 230;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"first\",mo";
_txthelp = parent._buildhelptexthighlight("first",parent._movetext);
 if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 232;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"fifth\",mo";
_txthelp = parent._buildhelptexthighlight("fifth",parent._movetext);
 if (true) break;

case 17:
//C
this.state = 30;
;
 //BA.debugLineNum = 234;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent._sendmgcode(parent._gcode2send);
 //BA.debugLineNum = 234;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 40;
return;
case 40:
//C
this.state = 30;
;
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 237;BA.debugLine="If current_point = 2 Then";
if (true) break;

case 20:
//if
this.state = 25;
if (parent._current_point==2) { 
this.state = 22;
}else {
this.state = 24;
}if (true) break;

case 22:
//C
this.state = 25;
 //BA.debugLineNum = 238;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"second\",m";
_txthelp = parent._buildhelptexthighlight("second",parent._movetext);
 if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 240;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"sixth and";
_txthelp = parent._buildhelptexthighlight("sixth and final",parent._movetext);
 if (true) break;

case 25:
//C
this.state = 30;
;
 //BA.debugLineNum = 242;BA.debugLine="gcode2send = $\"G1 X${point2(0)} Y${point2(1)";
parent._gcode2send = ("G1 X"+parent.__c.SmartStringFormatter("",(Object)(parent._point2[(int) (0)]))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._point2[(int) (1)]))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._xyspeed))+"");
 //BA.debugLineNum = 243;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent._sendmgcode(parent._gcode2send);
 //BA.debugLineNum = 243;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 41;
return;
case 41:
//C
this.state = 30;
;
 if (true) break;

case 27:
//C
this.state = 30;
 //BA.debugLineNum = 246;BA.debugLine="gcode2send = $\"G1 X${point3(0)} Y${point3(1)";
parent._gcode2send = ("G1 X"+parent.__c.SmartStringFormatter("",(Object)(parent._point3[(int) (0)]))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._point3[(int) (1)]))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._xyspeed))+"");
 //BA.debugLineNum = 247;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"third\",mov";
_txthelp = parent._buildhelptexthighlight("third",parent._movetext);
 //BA.debugLineNum = 248;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent._sendmgcode(parent._gcode2send);
 //BA.debugLineNum = 248;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 42;
return;
case 42:
//C
this.state = 30;
;
 if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 251;BA.debugLine="gcode2send = $\"G1 X${point4(0)} Y${point4(1)";
parent._gcode2send = ("G1 X"+parent.__c.SmartStringFormatter("",(Object)(parent._point4[(int) (0)]))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._point4[(int) (1)]))+" F"+parent.__c.SmartStringFormatter("",(Object)(parent._xyspeed))+"");
 //BA.debugLineNum = 252;BA.debugLine="txtHelp = BuildHelpTextHighlight(\"forth\",mov";
_txthelp = parent._buildhelptexthighlight("forth",parent._movetext);
 //BA.debugLineNum = 253;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent._sendmgcode(parent._gcode2send);
 //BA.debugLineNum = 253;BA.debugLine="SendMGcode(gcode2send) : Sleep(100) '--- mov";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 43;
return;
case 43:
//C
this.state = 30;
;
 if (true) break;

case 30:
//C
this.state = 33;
;
 //BA.debugLineNum = 258;BA.debugLine="SendMGcode(gcodeSendLevelingPoint) : Sleep(100";
parent._sendmgcode(parent._gcodesendlevelingpoint);
 //BA.debugLineNum = 258;BA.debugLine="SendMGcode(gcodeSendLevelingPoint) : Sleep(100";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 44;
return;
case 44:
//C
this.state = 33;
;
 if (true) break;

case 32:
//C
this.state = 33;
this.catchState = 0;
 //BA.debugLineNum = 261;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\"";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Something went wrong..."),(Object)(3500));
 //BA.debugLineNum = 262;BA.debugLine="logMe.LogIt2(LastException.Message, mModule,\"P";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,"ProcessSteps");
 //BA.debugLineNum = 263;BA.debugLine="oBeepMe.Beeps(300,500,3)";
parent._obeepme._beeps /*void*/ ((long) (300),(long) (500),(int) (3));
 //BA.debugLineNum = 264;BA.debugLine="btnStop_Click";
parent._btnstop_click();
 //BA.debugLineNum = 265;BA.debugLine="Return";
if (true) return ;
 if (true) break;
if (true) break;

case 33:
//C
this.state = 36;
this.catchState = 0;
;
 if (true) break;

case 35:
//C
this.state = 36;
 //BA.debugLineNum = 270;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Bed Leveling Complete... Sending end gcode."),(Object)(3500));
 //BA.debugLineNum = 271;BA.debugLine="SendMGcode(endGCode) : Sleep(200)";
parent._sendmgcode(parent._endgcode);
 //BA.debugLineNum = 271;BA.debugLine="SendMGcode(endGCode) : Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 45;
return;
case 45:
//C
this.state = 36;
;
 //BA.debugLineNum = 272;BA.debugLine="oBeepMe.Beeps(300,500,1)";
parent._obeepme._beeps /*void*/ ((long) (300),(long) (500),(int) (1));
 //BA.debugLineNum = 273;BA.debugLine="btnStop_Click";
parent._btnstop_click();
 //BA.debugLineNum = 274;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 36:
//C
this.state = -1;
;
 //BA.debugLineNum = 278;BA.debugLine="lblMsgSteps.Text = txtHelp";
parent._lblmsgsteps.setText(BA.ObjectToCharSequence(_txthelp));
 //BA.debugLineNum = 281;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _sendmgcode(String _code) throws Exception{
 //BA.debugLineNum = 286;BA.debugLine="Private Sub SendMGcode(code As String)";
 //BA.debugLineNum = 287;BA.debugLine="B4XPages.MainPage.Send_Gcode(code)";
_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._send_gcode /*void*/ (_code);
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
return "";
}
public boolean  _setminmaxandspeeds() throws Exception{
 //BA.debugLineNum = 324;BA.debugLine="Private Sub SetMinMaxAndSpeeds() As Boolean";
 //BA.debugLineNum = 325;BA.debugLine="If oc.PrinterCustomBoundingBox = True Then";
if (_oc._printercustomboundingbox /*boolean*/ ==__c.True) { 
 }else {
 //BA.debugLineNum = 332;BA.debugLine="min_x = 0 : min_y = 0";
_min_x = (int) (0);
 //BA.debugLineNum = 332;BA.debugLine="min_x = 0 : min_y = 0";
_min_y = (int) (0);
 //BA.debugLineNum = 333;BA.debugLine="max_x = oc.PrinterWidth";
_max_x = (int) (_oc._printerwidth /*double*/ );
 //BA.debugLineNum = 334;BA.debugLine="max_y = oc.PrinterDepth";
_max_y = (int) (_oc._printerdepth /*double*/ );
 };
 //BA.debugLineNum = 337;BA.debugLine="Try";
try { //BA.debugLineNum = 338;BA.debugLine="zSpeed   = mData.Get(gblConst.bedManualZspeed)";
_zspeed = (int) ((double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualzspeed /*String*/ ))))*60);
 //BA.debugLineNum = 339;BA.debugLine="xySpeed = mData.Get(gblConst.bedManualXYspeed) *";
_xyspeed = (int) ((double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyspeed /*String*/ ))))*60);
 } 
       catch (Exception e12) {
			ba.setLastException(e12); //BA.debugLineNum = 341;BA.debugLine="logMe.LogIt2(LastException.Message, mModule,\"Set";
_logme._logit2 /*String*/ (ba,__c.LastException(ba).getMessage(),_mmodule,"SetMinMaxAndSpeeds");
 //BA.debugLineNum = 342;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 345;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 347;BA.debugLine="End Sub";
return false;
}
public boolean  _setpoints() throws Exception{
 //BA.debugLineNum = 350;BA.debugLine="Private Sub SetPoints() As Boolean";
 //BA.debugLineNum = 352;BA.debugLine="Try";
try { //BA.debugLineNum = 360;BA.debugLine="point1 = Array As Int(min_x  + mData.Get(gblCons";
_point1 = new int[]{(int) (_min_x+(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ ))))),(int) (_min_y+(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ )))))};
 //BA.debugLineNum = 361;BA.debugLine="point2 = Array As Int(max_x - mData.Get(gblConst";
_point2 = new int[]{(int) (_max_x-(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ ))))),(int) (_max_y-(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ )))))};
 //BA.debugLineNum = 362;BA.debugLine="point3 = Array As Int(max_x - mData.Get(gblConst";
_point3 = new int[]{(int) (_max_x-(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ ))))),(int) (_min_y+(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ )))))};
 //BA.debugLineNum = 363;BA.debugLine="point4 = Array As Int(min_x  + mData.Get(gblCons";
_point4 = new int[]{(int) (_min_x+(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ ))))),(int) (_max_y-(double)(BA.ObjectToNumber(_mdata.Get((Object)(_gblconst._bedmanualxyoffset /*String*/ )))))};
 //BA.debugLineNum = 365;BA.debugLine="Return True";
if (true) return __c.True;
 } 
       catch (Exception e8) {
			ba.setLastException(e8); //BA.debugLineNum = 367;BA.debugLine="logMe.LogIt2(LastException.Message, mModule,\"Set";
_logme._logit2 /*String*/ (ba,__c.LastException(ba).getMessage(),_mmodule,"SetPoints");
 };
 //BA.debugLineNum = 370;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 372;BA.debugLine="End Sub";
return false;
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz parent;
anywheresoftware.b4a.objects.collections.Map _prefsaveddata = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 82;BA.debugLine="Dim prefSavedData As Map = File.ReadMap(xui.Defau";
_prefsaveddata = new anywheresoftware.b4a.objects.collections.Map();
_prefsaveddata = parent.__c.File.ReadMap(parent._xui.getDefaultFolder(),parent._gblconst._bed_manual_level_file /*String*/ );
 //BA.debugLineNum = 83;BA.debugLine="endGCode   = prefSavedData.Get(gblConst.bedManual";
parent._endgcode = BA.ObjectToString(_prefsaveddata.Get((Object)(parent._gblconst._bedmanualendgcode /*String*/ )));
 //BA.debugLineNum = 84;BA.debugLine="startGCode = prefSavedData.Get(gblConst.bedManual";
parent._startgcode = BA.ObjectToString(_prefsaveddata.Get((Object)(parent._gblconst._bedmanualstartgcode /*String*/ )));
 //BA.debugLineNum = 86;BA.debugLine="moveText = \"You are at the !P! leveling position.";
parent._movetext = "You are at the !P! leveling position. Adjust your bed and press Next.'";
 //BA.debugLineNum = 88;BA.debugLine="parent.SetLayoutAnimated(0, 0, 0, parent.Width, p";
parent._parent.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent._parent.getWidth(),parent._parent.getHeight());
 //BA.debugLineNum = 89;BA.debugLine="parent.LoadLayout(\"wizManualBedLevel\")";
parent._parent.LoadLayout("wizManualBedLevel",ba);
 //BA.debugLineNum = 90;BA.debugLine="BuildGUI";
parent._buildgui();
 //BA.debugLineNum = 92;BA.debugLine="mWizDlg.Initialize(pnlHost, \"\",pnlHost.Width , pn";
parent._mwizdlg._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnlhost.getObject())),(Object)(""),parent._pnlhost.getWidth(),parent._pnlhost.getHeight());
 //BA.debugLineNum = 93;BA.debugLine="mWizDlg.LoadFromJson(File.ReadString(File.DirAsse";
parent._mwizdlg._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"wizbedlevel.json"));
 //BA.debugLineNum = 94;BA.debugLine="mWizDlg.SetEventsListener(Me,\"dlgGeneral\")";
parent._mwizdlg._seteventslistener /*String*/ (parent,"dlgGeneral");
 //BA.debugLineNum = 96;BA.debugLine="prefHelper.Initialize(mWizDlg)";
parent._prefhelper._initialize /*String*/ (ba,parent._mwizdlg);
 //BA.debugLineNum = 97;BA.debugLine="prefHelper.ThemePrefDialogForm";
parent._prefhelper._themeprefdialogform /*String*/ ();
 //BA.debugLineNum = 99;BA.debugLine="Dim RS As ResumableSub = mWizDlg.ShowDialog(prefS";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mwizdlg._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_prefsaveddata,(Object)(""),(Object)(""));
 //BA.debugLineNum = 100;BA.debugLine="prefHelper.dlgHelper.NoCloseOn2ndDialog";
parent._prefhelper._dlghelper /*sadLogic.OctoTouchController.foss.sadb4xdialoghelper*/ ._nocloseon2nddialog /*String*/ ();
 //BA.debugLineNum = 101;BA.debugLine="prefHelper.dlgHelper.ThemeInputDialogBtnsResize";
parent._prefhelper._dlghelper /*sadLogic.OctoTouchController.foss.sadb4xdialoghelper*/ ._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 103;BA.debugLine="BuildWizBtns";
parent._buildwizbtns();
 //BA.debugLineNum = 105;BA.debugLine="tmrHeaterOnOff.Initialize(\"tmrHeater\",1500)";
parent._tmrheateronoff.Initialize(ba,"tmrHeater",(long) (1500));
 //BA.debugLineNum = 106;BA.debugLine="tmrHeater_Tick";
parent._tmrheater_tick();
 //BA.debugLineNum = 107;BA.debugLine="tmrHeaterOnOff.Enabled = True";
parent._tmrheateronoff.setEnabled(parent.__c.True);
 //BA.debugLineNum = 109;BA.debugLine="Wait For (RS) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 110;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 111;BA.debugLine="If tmrHeaterOnOff.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._tmrheateronoff.IsInitialized()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 112;BA.debugLine="tmrHeaterOnOff.Enabled = False";
parent._tmrheateronoff.setEnabled(parent.__c.False);
 //BA.debugLineNum = 113;BA.debugLine="tmrHeaterOnOff = Null";
parent._tmrheateronoff = (anywheresoftware.b4a.objects.Timer)(parent.__c.Null);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _tmrheater_tick() throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Private Sub tmrHeater_Tick";
 //BA.debugLineNum = 119;BA.debugLine="lblHeaterTool.Text =\"Tool: \" & CRLF & oc.Tool1Act";
_lblheatertool.setText(BA.ObjectToCharSequence("Tool: "+__c.CRLF+_oc._tool1actual /*String*/ .replace("C","")));
 //BA.debugLineNum = 120;BA.debugLine="lblHeaterBed.Text = \"Bed: \" & CRLF & oc.BedActual";
_lblheaterbed.setText(BA.ObjectToCharSequence("Bed: "+__c.CRLF+_oc._bedactual /*String*/ .replace("C","")));
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
