package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewmsgbox2{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbg").vw.setLeft((int)(0d));
views.get("pnlbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbg").vw.setTop((int)(0d));
views.get("pnlbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("lmb4ximageviewx1").vw.setVisible(BA.parseBoolean("false"));
views.get("lbltxt").vw.setLeft((int)((10d * scale)));
views.get("lbltxt").vw.setWidth((int)((views.get("pnlbg").vw.getLeft() + views.get("pnlbg").vw.getWidth())-(10d * scale) - ((10d * scale))));
views.get("lbltxt").vw.setTop((int)((views.get("pnlbg").vw.getTop())+(10d * scale)));
views.get("lbltxt").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(10d * scale) - ((views.get("pnlbg").vw.getTop())+(10d * scale))));
;}else{ 
;
views.get("lbltxt").vw.setLeft((int)((views.get("lmb4ximageviewx1").vw.getLeft() + views.get("lmb4ximageviewx1").vw.getWidth())+(16d * scale)));
views.get("lbltxt").vw.setWidth((int)((views.get("pnlbg").vw.getLeft() + views.get("pnlbg").vw.getWidth())-(10d * scale) - ((views.get("lmb4ximageviewx1").vw.getLeft() + views.get("lmb4ximageviewx1").vw.getWidth())+(16d * scale))));
views.get("lbltxt").vw.setTop((int)((views.get("pnlbg").vw.getTop())+(20d * scale)));
views.get("lbltxt").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(10d * scale) - ((views.get("pnlbg").vw.getTop())+(20d * scale))));
;};

}
}