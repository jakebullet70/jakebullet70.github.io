package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class requestapikey extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.requestapikey");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.requestapikey.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public Object _mcallback = null;
public String _meventname = "";
public String _mapptitle = "";
public String _mip = "";
public String _mport = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private Const mModule As String = \"RequestApiKey\"";
_mmodule = "RequestApiKey";
 //BA.debugLineNum = 13;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 14;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 15;BA.debugLine="Private mAppTitle As String";
_mapptitle = "";
 //BA.debugLineNum = 16;BA.debugLine="Private mIP As String";
_mip = "";
 //BA.debugLineNum = 17;BA.debugLine="Private mPort As String";
_mport = "";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname,String _appname,String _ip,String _port) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Initialize(Callback As Object, EventNam";
 //BA.debugLineNum = 23;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 24;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 25;BA.debugLine="mAppTitle = AppName";
_mapptitle = _appname;
 //BA.debugLineNum = 26;BA.debugLine="mIP = ip";
_mip = _ip;
 //BA.debugLineNum = 27;BA.debugLine="mPort = port";
_mport = _port;
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public void  _prompt4key() throws Exception{
ResumableSub_Prompt4Key rsub = new ResumableSub_Prompt4Key(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Prompt4Key extends BA.ResumableSub {
public ResumableSub_Prompt4Key(sadLogic.OctoTouchController.requestapikey parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.requestapikey parent;
String _insub = "";
boolean _allok = false;
String _sapimain = "";
String _sapi = "";
String _sdata = "";
sadLogic.OctoTouchController.httpjob _job = null;
String _retstr = "";
String _uniquestr = "";
anywheresoftware.b4a.objects.collections.List _retlist = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 84;BA.debugLine="Dim InSub As String = \"Prompt4Key\"";
_insub = "Prompt4Key";
 //BA.debugLineNum = 85;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 24;
this.catchState = 19;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 19;
 //BA.debugLineNum = 87;BA.debugLine="Dim allOK As Boolean = False '--- assume BAD!";
_allok = parent.__c.False;
 //BA.debugLineNum = 88;BA.debugLine="Dim sAPImain As String = $\"http://${mIP}:${mPort";
_sapimain = ("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._mip))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._mport))+""+parent.__c.SmartStringFormatter("",(Object)(parent._oc._capi_key_request /*String*/ ))+"");
 //BA.debugLineNum = 89;BA.debugLine="Dim sAPI As String = Regex.Split(\"!!\",sAPImain)(";
_sapi = parent.__c.Regex.Split("!!",_sapimain)[(int) (0)];
 //BA.debugLineNum = 90;BA.debugLine="Dim sData As String = Regex.Split(\"!!\",sAPImain)";
_sdata = parent.__c.Regex.Split("!!",_sapimain)[(int) (1)].replace("!APP!",parent._mapptitle);
 //BA.debugLineNum = 92;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 92;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 93;BA.debugLine="Dim retStr As String = \"\"";
_retstr = "";
 //BA.debugLineNum = 95;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 96;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 97;BA.debugLine="logMe.LogIt2($\"${UniqueStr}:-->${sAPI & CRLF &";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi+parent.__c.CRLF+_sdata+"<--:"))+""),parent._mmodule,_insub);
 if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 100;BA.debugLine="job.PostString(sAPI,sData)";
_job._poststring /*String*/ (_sapi,_sdata);
 //BA.debugLineNum = 101;BA.debugLine="job.GetRequest.SetContentType(\"application/json\"";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/json");
 //BA.debugLineNum = 103;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 31;
return;
case 31:
//C
this.state = 8;
_job = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 104;BA.debugLine="If job.Success And job.Response.StatusCode = 201";
if (true) break;

case 8:
//if
this.state = 17;
if (_job._success /*boolean*/  && _job._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .getStatusCode()==201) { 
this.state = 10;
}else {
this.state = 12;
}if (true) break;

case 10:
//C
this.state = 17;
 //BA.debugLineNum = 105;BA.debugLine="allOK = True";
_allok = parent.__c.True;
 //BA.debugLineNum = 106;BA.debugLine="retStr =  job.Response.GetHeaders.Get(\"location";
_retstr = BA.ObjectToString(_job._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .GetHeaders().Get((Object)("location")));
 //BA.debugLineNum = 107;BA.debugLine="retStr = retStr.Replace(\"[\",\"\").Replace(\"]\",\"\")";
_retstr = _retstr.replace("[","").replace("]","");
 if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 110;BA.debugLine="retStr = \"Octoprint key prompt request failed\"";
_retstr = "Octoprint key prompt request failed";
 //BA.debugLineNum = 111;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 13:
//if
this.state = 16;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 112;BA.debugLine="logMe.LogIt2($\"${UniqueStr}:-->${retStr}\"$,mMo";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_retstr))+""),parent._mmodule,_insub);
 if (true) break;

case 16:
//C
this.state = 17;
;
 if (true) break;

case 17:
//C
this.state = 24;
;
 if (true) break;

case 19:
//C
this.state = 20;
this.catchState = 0;
 //BA.debugLineNum = 118;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 20:
//if
this.state = 23;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 22;
}if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 119;BA.debugLine="logMe.LogIt2(LastException,mModule,InSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),BA.ObjectToString(parent.__c.LastException(parent.getActivityBA())),parent._mmodule,_insub);
 if (true) break;

case 23:
//C
this.state = 24;
;
 if (true) break;
if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 0;
;
 //BA.debugLineNum = 124;BA.debugLine="job.Release '--- free up resources";
_job._release /*String*/ ();
 //BA.debugLineNum = 126;BA.debugLine="If allOK Then";
if (true) break;

case 25:
//if
this.state = 30;
if (_allok) { 
this.state = 27;
}else {
this.state = 29;
}if (true) break;

case 27:
//C
this.state = 30;
 //BA.debugLineNum = 127;BA.debugLine="Wait4Key(retStr) '--- retStr has the location to";
parent._wait4key(_retstr);
 if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 129;BA.debugLine="Dim retList As List : retList.Initialize2(Array";
_retlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 129;BA.debugLine="Dim retList As List : retList.Initialize2(Array";
_retlist.Initialize2(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_retstr,((BA.ObjectToString(_allok)))}));
 //BA.debugLineNum = 130;BA.debugLine="RaiseEvent(\"RequestComplete\",retList)";
parent._raiseevent("RequestComplete",_retlist);
 //BA.debugLineNum = 131;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 30:
//C
this.state = -1;
;
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _jobdone(sadLogic.OctoTouchController.httpjob _job) throws Exception{
}
public String  _raiseevent(String _evname,anywheresoftware.b4a.objects.collections.List _params) throws Exception{
String _fullroutinename = "";
 //BA.debugLineNum = 226;BA.debugLine="Private Sub RaiseEvent(EvName As String, Params As";
 //BA.debugLineNum = 227;BA.debugLine="Dim FullRoutineName As String";
_fullroutinename = "";
 //BA.debugLineNum = 228;BA.debugLine="FullRoutineName = mEventName & \"_\" & EvName";
_fullroutinename = _meventname+"_"+_evname;
 //BA.debugLineNum = 229;BA.debugLine="If SubExists(mCallback, FullRoutineName) Then";
if (__c.SubExists(ba,_mcallback,_fullroutinename)) { 
 //BA.debugLineNum = 230;BA.debugLine="If Not(Params.IsInitialized) Or Params.Size = 0";
if (__c.Not(_params.IsInitialized()) || _params.getSize()==0) { 
 //BA.debugLineNum = 231;BA.debugLine="CallSubDelayed(mCallback, FullRoutineName)";
__c.CallSubDelayed(ba,_mcallback,_fullroutinename);
 }else {
 //BA.debugLineNum = 233;BA.debugLine="Select Params.Size";
switch (BA.switchObjectToInt(_params.getSize(),(int) (1),(int) (2))) {
case 0: {
 //BA.debugLineNum = 235;BA.debugLine="CallSubDelayed2(mCallback, FullRoutineName, P";
__c.CallSubDelayed2(ba,_mcallback,_fullroutinename,_params.Get((int) (0)));
 break; }
case 1: {
 //BA.debugLineNum = 237;BA.debugLine="CallSubDelayed3(mCallback, FullRoutineName, P";
__c.CallSubDelayed3(ba,_mcallback,_fullroutinename,_params.Get((int) (0)),_params.Get((int) (1)));
 break; }
}
;
 };
 };
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public void  _requestavailable() throws Exception{
ResumableSub_RequestAvailable rsub = new ResumableSub_RequestAvailable(this);
rsub.resume(ba, null);
}
public static class ResumableSub_RequestAvailable extends BA.ResumableSub {
public ResumableSub_RequestAvailable(sadLogic.OctoTouchController.requestapikey parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.requestapikey parent;
String _insub = "";
String _sapi = "";
sadLogic.OctoTouchController.httpjob _j = null;
String _resultstr = "";
boolean _allgood = false;
String _uniquestr = "";
sadLogic.OctoTouchController.guimsgs _oo = null;
anywheresoftware.b4a.objects.collections.List _retlist = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 35;BA.debugLine="Dim InSub As String = \"RequestAvailable\"";
_insub = "RequestAvailable";
 //BA.debugLineNum = 36;BA.debugLine="Dim sAPI As String = $\"http://${mIP}:${mPort}${oc";
_sapi = ("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._mip))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._mport))+""+parent.__c.SmartStringFormatter("",(Object)(parent._oc._capi_key_probe /*String*/ ))+"");
 //BA.debugLineNum = 38;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 38;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 39;BA.debugLine="Dim resultStr As String = \"\"";
_resultstr = "";
 //BA.debugLineNum = 40;BA.debugLine="Dim AllGood As Boolean = False";
_allgood = parent.__c.False;
 //BA.debugLineNum = 42;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 43;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As(";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 44;BA.debugLine="logMe.LogIt2($\"KeyRequestAvail: ${UniqueStr}:-->";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),("KeyRequestAvail: "+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi))+""),parent._mmodule,_insub);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 47;BA.debugLine="j.Download(sAPI)";
_j._download /*String*/ (_sapi);
 //BA.debugLineNum = 48;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 31;
return;
case 31:
//C
this.state = 5;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 49;BA.debugLine="If j.Success Then";
if (true) break;

case 5:
//if
this.state = 24;
if (_j._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 23;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 50;BA.debugLine="If j.Response.StatusCode = 204 Then '--- this is";
if (true) break;

case 8:
//if
this.state = 21;
if (_j._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .getStatusCode()==204) { 
this.state = 10;
}else {
this.state = 16;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 51;BA.debugLine="AllGood = True";
_allgood = parent.__c.True;
 //BA.debugLineNum = 52;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 11:
//if
this.state = 14;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 53;BA.debugLine="logMe.LogIt2($\"KeyRequestAvail: ${UniqueStr}:-";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),("KeyRequestAvail: "+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":--> Yeah!"),parent._mmodule,_insub);
 if (true) break;

case 14:
//C
this.state = 21;
;
 if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 56;BA.debugLine="resultStr = \"Request failed - Octoprint key req";
_resultstr = "Request failed - Octoprint key request service is not working";
 //BA.debugLineNum = 57;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 17:
//if
this.state = 20;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 19;
}if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 58;BA.debugLine="logMe.LogIt2($\"KeyRequestAvail: ${UniqueStr}:-";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),("KeyRequestAvail: "+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":--> Failure"),parent._mmodule,_insub);
 if (true) break;

case 20:
//C
this.state = 21;
;
 if (true) break;

case 21:
//C
this.state = 24;
;
 if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 63;BA.debugLine="Dim oo As guiMsgs : oo.Initialize";
_oo = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 63;BA.debugLine="Dim oo As guiMsgs : oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 64;BA.debugLine="resultStr = oo.GetConnectFailedMsg";
_resultstr = _oo._getconnectfailedmsg /*String*/ ();
 if (true) break;

case 24:
//C
this.state = 25;
;
 //BA.debugLineNum = 67;BA.debugLine="j.Release '--- free up resources";
_j._release /*String*/ ();
 //BA.debugLineNum = 69;BA.debugLine="If AllGood Then";
if (true) break;

case 25:
//if
this.state = 30;
if (_allgood) { 
this.state = 27;
}else {
this.state = 29;
}if (true) break;

case 27:
//C
this.state = 30;
 //BA.debugLineNum = 70;BA.debugLine="Prompt4Key";
parent._prompt4key();
 if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 73;BA.debugLine="Dim retList As List : retList.Initialize2(Array";
_retlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 73;BA.debugLine="Dim retList As List : retList.Initialize2(Array";
_retlist.Initialize2(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_resultstr,((BA.ObjectToString(_allgood)))}));
 //BA.debugLineNum = 74;BA.debugLine="RaiseEvent(\"RequestComplete\",retList)";
parent._raiseevent("RequestComplete",_retlist);
 //BA.debugLineNum = 75;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 30:
//C
this.state = -1;
;
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _wait4key(String _polelocation) throws Exception{
ResumableSub_Wait4Key rsub = new ResumableSub_Wait4Key(this,_polelocation);
rsub.resume(ba, null);
}
public static class ResumableSub_Wait4Key extends BA.ResumableSub {
public ResumableSub_Wait4Key(sadLogic.OctoTouchController.requestapikey parent,String _polelocation) {
this.parent = parent;
this._polelocation = _polelocation;
}
sadLogic.OctoTouchController.requestapikey parent;
String _polelocation;
String _insub = "";
int _loopnum = 0;
int _maxloop = 0;
boolean _allgood = false;
boolean _keydenied = false;
anywheresoftware.b4a.objects.collections.Map _mapout = null;
String _resultstr = "";
String _errmsgdeniedortimeout = "";
sadLogic.OctoTouchController.httpjob _j = null;
String _uniquestr = "";
anywheresoftware.b4a.objects.collections.List _retlist = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 140;BA.debugLine="Dim InSub As String = \"Wait4Key\"";
_insub = "Wait4Key";
 //BA.debugLineNum = 141;BA.debugLine="Dim loopNum As Int = 0";
_loopnum = (int) (0);
 //BA.debugLineNum = 142;BA.debugLine="Dim const MaxLoop As Int = 90 '--- about 2 minute";
_maxloop = (int) (90);
 //BA.debugLineNum = 143;BA.debugLine="Dim AllGood As Boolean = False";
_allgood = parent.__c.False;
 //BA.debugLineNum = 144;BA.debugLine="Dim KeyDenied As Boolean = False";
_keydenied = parent.__c.False;
 //BA.debugLineNum = 145;BA.debugLine="Dim mapOut As Map";
_mapout = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 146;BA.debugLine="Dim resultStr As String = \"\"";
_resultstr = "";
 //BA.debugLineNum = 147;BA.debugLine="Dim AllGood As Boolean = False";
_allgood = parent.__c.False;
 //BA.debugLineNum = 149;BA.debugLine="Dim ErrMsgDeniedOrTimeout As String = \"Octoprint";
_errmsgdeniedortimeout = "Octoprint Key Wait Error."+parent.__c.CRLF+"Request Denied Or Timed Out.";
 //BA.debugLineNum = 150;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 151;BA.debugLine="ErrMsgDeniedOrTimeout = ErrMsgDeniedOrTimeout.Re";
_errmsgdeniedortimeout = _errmsgdeniedortimeout.replace(parent.__c.CRLF," ");
 if (true) break;
;
 //BA.debugLineNum = 155;BA.debugLine="Do While (loopNum < MaxLoop) Or KeyDenied Or AllG";

case 4:
//do while
this.state = 35;
while ((_loopnum<_maxloop) || _keydenied || _allgood) {
this.state = 6;
if (true) break;
}
if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 159;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 159;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 161;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 162;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 163;BA.debugLine="logMe.LogIt2($\"KeyWait: ${UniqueStr}:-->${poleL";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),("KeyWait: "+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_polelocation))+""),parent._mmodule,_insub);
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 166;BA.debugLine="j.Download(poleLocation)";
_j._download /*String*/ (_polelocation);
 //BA.debugLineNum = 167;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 53;
return;
case 53:
//C
this.state = 11;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 169;BA.debugLine="If j.Success Then";
if (true) break;

case 11:
//if
this.state = 34;
if (_j._success /*boolean*/ ) { 
this.state = 13;
}else {
this.state = 29;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 171;BA.debugLine="Select Case j.Response.StatusCode";
if (true) break;

case 14:
//select
this.state = 27;
switch (BA.switchObjectToInt(_j._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .getStatusCode(),(int) (202),(int) (404),(int) (200))) {
case 0: {
this.state = 16;
if (true) break;
}
case 1: {
this.state = 18;
if (true) break;
}
case 2: {
this.state = 20;
if (true) break;
}
default: {
this.state = 22;
if (true) break;
}
}
if (true) break;

case 16:
//C
this.state = 27;
 if (true) break;

case 18:
//C
this.state = 27;
 //BA.debugLineNum = 175;BA.debugLine="KeyDenied = True";
_keydenied = parent.__c.True;
 //BA.debugLineNum = 176;BA.debugLine="resultStr = \"\" '--- msg set below";
_resultstr = "";
 if (true) break;

case 20:
//C
this.state = 27;
 //BA.debugLineNum = 179;BA.debugLine="mapOut = j.GetString.As(JSON).ToMap 'ignore";
_mapout = ((anywheresoftware.b4a.objects.collections.JSONParser.JSONConverter) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.JSONParser.JSONConverter(), (java.lang.Object)(_j._getstring /*String*/ ()))).ToMap();
 //BA.debugLineNum = 180;BA.debugLine="AllGood = True";
_allgood = parent.__c.True;
 if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 183;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 23:
//if
this.state = 26;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 25;
}if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 184;BA.debugLine="logMe.LogIt2(\"case else - \" & j.Response.Sta";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"case else - "+BA.NumberToString(_j._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .getStatusCode()),parent._mmodule,_insub);
 if (true) break;

case 26:
//C
this.state = 27;
;
 if (true) break;

case 27:
//C
this.state = 34;
;
 if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 191;BA.debugLine="resultStr = ErrMsgDeniedOrTimeout";
_resultstr = _errmsgdeniedortimeout;
 //BA.debugLineNum = 192;BA.debugLine="If config.logREQUEST_OCTO_KEY Then";
if (true) break;

case 30:
//if
this.state = 33;
if (parent._config._logrequest_octo_key /*boolean*/ ) { 
this.state = 32;
}if (true) break;

case 32:
//C
this.state = 33;
 //BA.debugLineNum = 193;BA.debugLine="logMe.LogIt2($\"KeyWait: ${UniqueStr}:--> Failu";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),("KeyWait: "+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":--> Failure: "+parent.__c.SmartStringFormatter("",(Object)(_j._errormessage /*String*/ ))+""),parent._mmodule,_insub);
 if (true) break;

case 33:
//C
this.state = 34;
;
 //BA.debugLineNum = 195;BA.debugLine="Exit";
this.state = 35;
if (true) break;
 if (true) break;

case 34:
//C
this.state = 4;
;
 //BA.debugLineNum = 199;BA.debugLine="j.Release '--- free up resources";
_j._release /*String*/ ();
 //BA.debugLineNum = 201;BA.debugLine="Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 54;
return;
case 54:
//C
this.state = 4;
;
 //BA.debugLineNum = 202;BA.debugLine="loopNum = loopNum + 1";
_loopnum = (int) (_loopnum+1);
 if (true) break;
;
 //BA.debugLineNum = 207;BA.debugLine="If j.IsInitialized Then j.Release";

case 35:
//if
this.state = 40;
if (_j.IsInitialized /*boolean*/ ()) { 
this.state = 37;
;}if (true) break;

case 37:
//C
this.state = 40;
_j._release /*String*/ ();
if (true) break;

case 40:
//C
this.state = 41;
;
 //BA.debugLineNum = 209;BA.debugLine="Dim retList As List";
_retlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 210;BA.debugLine="If AllGood Then";
if (true) break;

case 41:
//if
this.state = 52;
if (_allgood) { 
this.state = 43;
}else {
this.state = 45;
}if (true) break;

case 43:
//C
this.state = 52;
 //BA.debugLineNum = 211;BA.debugLine="retList.Initialize2(Array As String(mapOut.Get(\"";
_retlist.Initialize2(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{BA.ObjectToString(_mapout.Get((Object)("api_key"))),((BA.ObjectToString(_allgood)))}));
 if (true) break;

case 45:
//C
this.state = 46;
 //BA.debugLineNum = 214;BA.debugLine="If resultStr.Length = 0 Then resultStr = ErrMsgD";
if (true) break;

case 46:
//if
this.state = 51;
if (_resultstr.length()==0) { 
this.state = 48;
;}if (true) break;

case 48:
//C
this.state = 51;
_resultstr = _errmsgdeniedortimeout;
if (true) break;

case 51:
//C
this.state = 52;
;
 //BA.debugLineNum = 215;BA.debugLine="retList.Initialize2(Array As String(resultStr,(";
_retlist.Initialize2(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_resultstr,((BA.ObjectToString(_allgood)))}));
 if (true) break;

case 52:
//C
this.state = -1;
;
 //BA.debugLineNum = 218;BA.debugLine="RaiseEvent(\"RequestComplete\",retList)";
parent._raiseevent("RequestComplete",_retlist);
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
