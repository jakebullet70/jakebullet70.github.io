package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class httpdownloadstr extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.httpdownloadstr");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.httpdownloadstr.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"HttpDownloadSt";
_mmodule = "HttpDownloadStr";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendrequest(String _target) throws Exception{
ResumableSub_SendRequest rsub = new ResumableSub_SendRequest(this,_target);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendRequest extends BA.ResumableSub {
public ResumableSub_SendRequest(sadLogic.OctoTouchController.httpdownloadstr parent,String _target) {
this.parent = parent;
this._target = _target;
}
sadLogic.OctoTouchController.httpdownloadstr parent;
String _target;
String _insub = "";
sadLogic.OctoTouchController.httpjob _j = null;
String _retstr = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 18;BA.debugLine="Dim insub As String = \"SendRequest\"";
_insub = "SendRequest";
 //BA.debugLineNum = 19;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 19;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 20;BA.debugLine="Dim retStr As String = \"\"";
_retstr = "";
 //BA.debugLineNum = 22;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 23;BA.debugLine="logMe.logit2(target,mModule,insub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),_target,parent._mmodule,_insub);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 26;BA.debugLine="j.Download(target)";
_j._download /*String*/ (_target);
 //BA.debugLineNum = 27;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 11;
return;
case 11:
//C
this.state = 5;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 28;BA.debugLine="If j.Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_j._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 29;BA.debugLine="retStr = j.GetString";
_retstr = _j._getstring /*String*/ ();
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 31;BA.debugLine="logMe.logit2(\"ERROR: \" & j.ErrorMessage,mModule,";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"ERROR: "+_j._errormessage /*String*/ ,parent._mmodule,_insub);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 34;BA.debugLine="j.Release '--- free up resources";
_j._release /*String*/ ();
 //BA.debugLineNum = 36;BA.debugLine="Return retStr";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_retstr));return;};
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(sadLogic.OctoTouchController.httpjob _j) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
