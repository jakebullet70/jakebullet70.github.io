package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadb4xdraweradvancedhelper extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.sadb4xdraweradvancedhelper");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.sadb4xdraweradvancedhelper.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.sadb4xdraweradvanced _drawer = null;
public boolean _isopen = false;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnstop = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnfrestart = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnrestart = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnbrightness_f = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnscrnoff_r = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtnsdrawer = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _brightness_change(float _value) throws Exception{
float _v = 0f;
 //BA.debugLineNum = 170;BA.debugLine="Private Sub Brightness_Change(value As Float)";
 //BA.debugLineNum = 173;BA.debugLine="Dim v As Float = value / 100";
_v = (float) (_value/(double)100);
 //BA.debugLineNum = 174;BA.debugLine="powerHelpers.SetScreenBrightnessAndSave(v,True)";
_powerhelpers._setscreenbrightnessandsave /*String*/ (ba,_v,__c.True);
 //BA.debugLineNum = 175;BA.debugLine="powerHelpers.pScreenBrightness = v";
_powerhelpers._pscreenbrightness /*float*/  = _v;
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public void  _btnpressed(anywheresoftware.b4a.objects.ButtonWrapper _b) throws Exception{
ResumableSub_BtnPressed rsub = new ResumableSub_BtnPressed(this,_b);
rsub.resume(ba, null);
}
public static class ResumableSub_BtnPressed extends BA.ResumableSub {
public ResumableSub_BtnPressed(sadLogic.OctoTouchController.sadb4xdraweradvancedhelper parent,anywheresoftware.b4a.objects.ButtonWrapper _b) {
this.parent = parent;
this._b = _b;
}
sadLogic.OctoTouchController.sadb4xdraweradvancedhelper parent;
anywheresoftware.b4a.objects.ButtonWrapper _b;
String _msg = "";
int _dl = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 31;BA.debugLine="Dim msg As String = \"\"";
_msg = "";
 //BA.debugLineNum = 32;BA.debugLine="Dim dl As Int = 12000";
_dl = (int) (12000);
 //BA.debugLineNum = 34;BA.debugLine="Select Case b.Tag.As(String)";
if (true) break;

case 1:
//select
this.state = 12;
switch (BA.switchObjectToInt((BA.ObjectToString(_b.getTag())),"s","fr","r","br","soff")) {
case 0: {
this.state = 3;
if (true) break;
}
case 1: {
this.state = 5;
if (true) break;
}
case 2: {
this.state = 7;
if (true) break;
}
case 3: {
this.state = 9;
if (true) break;
}
case 4: {
this.state = 11;
if (true) break;
}
}
if (true) break;

case 3:
//C
this.state = 12;
 //BA.debugLineNum = 36;BA.debugLine="B4XPages.MainPage.Send_Gcode(\"M112\")";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._send_gcode /*void*/ ("M112");
 //BA.debugLineNum = 37;BA.debugLine="msg = \"EMERGENCY STOP!\"";
_msg = "EMERGENCY STOP!";
 if (true) break;

case 5:
//C
this.state = 12;
 //BA.debugLineNum = 40;BA.debugLine="B4XPages.MainPage.Send_Gcode(\"FIRMWARE_RESTART\"";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._send_gcode /*void*/ ("FIRMWARE_RESTART");
 //BA.debugLineNum = 41;BA.debugLine="msg = \"Firmware Restarting... Please wait a few";
_msg = "Firmware Restarting... Please wait a few moments...";
 //BA.debugLineNum = 42;BA.debugLine="oc.isConnected = False";
parent._oc._isconnected /*boolean*/  = parent.__c.False;
 //BA.debugLineNum = 43;BA.debugLine="Main.tmrTimerCallSub.CallSubPlus(B4XPages.MainP";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubplus /*String*/ ((Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ),"Start",(int) (10000));
 if (true) break;

case 7:
//C
this.state = 12;
 //BA.debugLineNum = 46;BA.debugLine="B4XPages.MainPage.Send_Gcode(\"RESTART\")";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._send_gcode /*void*/ ("RESTART");
 //BA.debugLineNum = 47;BA.debugLine="msg = \"Host Restarting... Please wait a few mom";
_msg = "Host Restarting... Please wait a few moments...";
 //BA.debugLineNum = 48;BA.debugLine="oc.isConnected = False";
parent._oc._isconnected /*boolean*/  = parent.__c.False;
 //BA.debugLineNum = 49;BA.debugLine="Main.tmrTimerCallSub.CallSubPlus(B4XPages.MainP";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubplus /*String*/ ((Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ),"Start",(int) (10000));
 if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 52;BA.debugLine="DoBrightnessDlg";
parent._dobrightnessdlg();
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 55;BA.debugLine="CallSub2(Main,\"TurnOnOff_ScreenTmr\",False)";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"TurnOnOff_ScreenTmr",(Object)(parent.__c.False));
 //BA.debugLineNum = 56;BA.debugLine="fnc.BlankScreen";
parent._fnc._blankscreen /*String*/ (ba);
 if (true) break;
;
 //BA.debugLineNum = 59;BA.debugLine="If msg.Length <> 0 Then '--- do we have a msg to";

case 12:
//if
this.state = 15;
if (_msg.length()!=0) { 
this.state = 14;
}if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 60;BA.debugLine="guiHelpers.Show_toast2(msg,dl)";
parent._guihelpers._show_toast2 /*String*/ (ba,_msg,_dl);
 //BA.debugLineNum = 61;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 16;
return;
case 16:
//C
this.state = 15;
;
 if (true) break;

case 15:
//C
this.state = -1;
;
 //BA.debugLineNum = 64;BA.debugLine="CloseRightMenu";
parent._closerightmenu();
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private mModule As String = \"sadB4XDrawerAdvanced";
_mmodule = "sadB4XDrawerAdvancedHelper";
 //BA.debugLineNum = 9;BA.debugLine="Public Drawer As sadB4XDrawerAdvanced 'ignore";
_drawer = new sadLogic.OctoTouchController.sadb4xdraweradvanced();
 //BA.debugLineNum = 10;BA.debugLine="Public IsOpen As Boolean 'ignore";
_isopen = false;
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private btnSTOP,btnFRESTART,btnRESTART As Button";
_btnstop = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnfrestart = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnrestart = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private btnBrightness_F, btnScrnOff_R As Button '";
_btnbrightness_f = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnscrnoff_r = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private pnlBtnsDrawer As B4XView";
_pnlbtnsdrawer = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public String  _closeleftmenu() throws Exception{
 //BA.debugLineNum = 157;BA.debugLine="Public Sub CloseLeftMenu";
 //BA.debugLineNum = 158;BA.debugLine="Drawer.setLeftOpen(False)";
_drawer._setleftopen /*String*/ (__c.False);
 //BA.debugLineNum = 159;BA.debugLine="End Sub";
return "";
}
public String  _closerightmenu() throws Exception{
 //BA.debugLineNum = 148;BA.debugLine="Public Sub CloseRightMenu";
 //BA.debugLineNum = 149;BA.debugLine="Drawer.setRightOpen(False)";
_drawer._setrightopen /*String*/ (__c.False);
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public String  _display_btns() throws Exception{
sadLogic.OctoTouchController.dse_layout _j = null;
 //BA.debugLineNum = 99;BA.debugLine="Public Sub Display_Btns";
 //BA.debugLineNum = 101;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 102;BA.debugLine="If oc.IsKlippyConnected = False Then";
if (_oc._isklippyconnected /*boolean*/ (ba)==__c.False) { 
 //BA.debugLineNum = 103;BA.debugLine="btnFRESTART.Visible = True";
_btnfrestart.setVisible(__c.True);
 //BA.debugLineNum = 104;BA.debugLine="btnRESTART.Visible = True";
_btnrestart.setVisible(__c.True);
 //BA.debugLineNum = 105;BA.debugLine="btnSTOP.Visible = False";
_btnstop.setVisible(__c.False);
 }else {
 //BA.debugLineNum = 107;BA.debugLine="btnFRESTART.Visible = False";
_btnfrestart.setVisible(__c.False);
 //BA.debugLineNum = 108;BA.debugLine="btnRESTART.Visible = False";
_btnrestart.setVisible(__c.False);
 //BA.debugLineNum = 109;BA.debugLine="btnSTOP.Visible = True";
_btnstop.setVisible(__c.True);
 };
 }else {
 //BA.debugLineNum = 115;BA.debugLine="btnBrightness_F.Visible = False '--- pointer to";
_btnbrightness_f.setVisible(__c.False);
 //BA.debugLineNum = 116;BA.debugLine="btnScrnOff_R.Visible = False '--- pointer to btn";
_btnscrnoff_r.setVisible(__c.False);
 //BA.debugLineNum = 117;BA.debugLine="btnSTOP.Visible = True";
_btnstop.setVisible(__c.True);
 };
 //BA.debugLineNum = 139;BA.debugLine="Dim j As DSE_Layout : j.Initialize";
_j = new sadLogic.OctoTouchController.dse_layout();
 //BA.debugLineNum = 139;BA.debugLine="Dim j As DSE_Layout : j.Initialize";
_j._initialize /*String*/ (ba);
 //BA.debugLineNum = 140;BA.debugLine="j.SpreadHorizontally2(pnlBtnsDrawer,140dip,6dip,\"";
_j._spreadhorizontally2 /*String*/ (_pnlbtnsdrawer,__c.DipToCurrent((int) (140)),__c.DipToCurrent((int) (6)),"center");
 //BA.debugLineNum = 141;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 142;BA.debugLine="CallSubDelayed(B4XPages.MainPage ,\"Build_RightSi";
__c.CallSubDelayed(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)),"Build_RightSideMenu");
 };
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return "";
}
public String  _dobrightnessdlg() throws Exception{
sadLogic.OctoTouchController.dlgbrightness _o1 = null;
 //BA.debugLineNum = 163;BA.debugLine="Public Sub DoBrightnessDlg";
 //BA.debugLineNum = 165;BA.debugLine="Dim o1 As dlgBrightness";
_o1 = new sadLogic.OctoTouchController.dlgbrightness();
 //BA.debugLineNum = 166;BA.debugLine="B4XPages.MainPage.pObjCurrentDlg1 = o1.Initialize";
_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._pobjcurrentdlg1 /*Object*/  = _o1._initialize /*Object*/ (ba,"Screen Brightness",this,"Brightness_Change");
 //BA.debugLineNum = 167;BA.debugLine="o1.Show(IIf(powerHelpers.pScreenBrightness < 0.05";
_o1._show /*void*/ ((int) ((double)(BA.ObjectToNumber(((_powerhelpers._pscreenbrightness /*float*/ <0.05) ? ((Object)(0.1)) : ((Object)(_powerhelpers._pscreenbrightness /*float*/ )))))*100));
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.sadb4xdraweradvanced _d) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(d As sadB4XDrawerAdvanced)";
 //BA.debugLineNum = 19;BA.debugLine="Drawer = d";
_drawer = _d;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _mnupanel_statechanged(boolean _open) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Private Sub mnuPanel_StateChanged (Open As Boolean";
 //BA.debugLineNum = 24;BA.debugLine="IsOpen = Open";
_isopen = _open;
 //BA.debugLineNum = 25;BA.debugLine="If Open Then Display_Btns";
if (_open) { 
_display_btns();};
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _openleftmenu() throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Public Sub OpenLeftMenu";
 //BA.debugLineNum = 155;BA.debugLine="Drawer.setLeftOpen(True)";
_drawer._setleftopen /*String*/ (__c.True);
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public String  _openrightmenu() throws Exception{
 //BA.debugLineNum = 151;BA.debugLine="Public Sub OpenRightMenu";
 //BA.debugLineNum = 152;BA.debugLine="Drawer.setRightOpen(True)";
_drawer._setrightopen /*String*/ (__c.True);
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public String  _skinme(anywheresoftware.b4a.objects.ButtonWrapper[] _b,anywheresoftware.b4a.objects.B4XViewWrapper _p,anywheresoftware.b4a.objects.B4XViewWrapper _pb) throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
Object _txt = null;
 //BA.debugLineNum = 71;BA.debugLine="Public Sub SkinMe(b() As Button, p As B4XView,pb A";
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.SkinButton(b)";
_guihelpers._skinbutton /*String*/ (ba,_b);
 //BA.debugLineNum = 74;BA.debugLine="btnSTOP = b(0)";
_btnstop = _b[(int) (0)];
 //BA.debugLineNum = 75;BA.debugLine="btnFRESTART = b(1)";
_btnfrestart = _b[(int) (1)];
 //BA.debugLineNum = 76;BA.debugLine="btnRESTART = b(2)";
_btnrestart = _b[(int) (2)];
 //BA.debugLineNum = 77;BA.debugLine="pnlBtnsDrawer = pb";
_pnlbtnsdrawer = _pb;
 //BA.debugLineNum = 78;BA.debugLine="p.SetColorAndBorder(clrTheme.Background,2dip, clr";
_p.SetColorAndBorder(_clrtheme._background /*int*/ ,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 80;BA.debugLine="If Not (oc.Klippy) Then";
if (__c.Not(_oc._klippy /*boolean*/ )) { 
 //BA.debugLineNum = 81;BA.debugLine="btnBrightness_F = btnFRESTART '--- pointer";
_btnbrightness_f = _btnfrestart;
 //BA.debugLineNum = 82;BA.debugLine="btnScrnOff_R = btnRESTART '--- pointer";
_btnscrnoff_r = _btnrestart;
 //BA.debugLineNum = 83;BA.debugLine="Dim cs As CSBuilder, txt As Object";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
_txt = new Object();
 //BA.debugLineNum = 84;BA.debugLine="txt = cs.Initialize.Typeface(Typeface.MATERIALIC";
_txt = (Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe327)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(__c.CRLF+"Screen Off")).PopAll().getObject());
 //BA.debugLineNum = 86;BA.debugLine="btnScrnOff_R.Text = txt : btnScrnOff_R.Tag = \"so";
_btnscrnoff_r.setText(BA.ObjectToCharSequence(_txt));
 //BA.debugLineNum = 86;BA.debugLine="btnScrnOff_R.Text = txt : btnScrnOff_R.Tag = \"so";
_btnscrnoff_r.setTag((Object)("soff"));
 //BA.debugLineNum = 87;BA.debugLine="txt = cs.Initialize.Typeface(Typeface.MATERIALIC";
_txt = (Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe430)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(__c.CRLF+"Brightness")).PopAll().getObject());
 //BA.debugLineNum = 89;BA.debugLine="btnBrightness_F.Text = txt : btnBrightness_F.Tag";
_btnbrightness_f.setText(BA.ObjectToCharSequence(_txt));
 //BA.debugLineNum = 89;BA.debugLine="btnBrightness_F.Text = txt : btnBrightness_F.Tag";
_btnbrightness_f.setTag((Object)("br"));
 }else {
 //BA.debugLineNum = 91;BA.debugLine="btnFRESTART.Text = \"RESTART FIRMWARE\"";
_btnfrestart.setText(BA.ObjectToCharSequence("RESTART FIRMWARE"));
 //BA.debugLineNum = 92;BA.debugLine="btnFRESTART.Tag = \"fr\"";
_btnfrestart.setTag((Object)("fr"));
 //BA.debugLineNum = 93;BA.debugLine="btnRESTART.Text = \"RESTART HOST\"";
_btnrestart.setText(BA.ObjectToCharSequence("RESTART HOST"));
 //BA.debugLineNum = 94;BA.debugLine="btnRESTART.Tag = \"r\"";
_btnrestart.setTag((Object)("r"));
 };
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "DISPLAY_BTNS"))
	return _display_btns();
return BA.SubDelegator.SubNotFound;
}
}
