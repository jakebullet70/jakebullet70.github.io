package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class config {
private static config mostCurrent = new config();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static boolean _isinit = false;
public static anywheresoftware.b4a.objects.collections.Map _mainsetupdata = null;
public static boolean _is1strun = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _change_appupdatecheck(anywheresoftware.b4a.BA _ba,boolean _check) throws Exception{
 //BA.debugLineNum = 111;BA.debugLine="Public Sub Change_AppUpdateCheck(check As Boolean)";
 //BA.debugLineNum = 113;BA.debugLine="MainSetupData.Put(gblConst.KEYS_MAIN_SETUP_SCRN_C";
_mainsetupdata.Put((Object)(mostCurrent._gblconst._keys_main_setup_scrn_check_4_updates /*String*/ ),(Object)(_check));
 //BA.debugLineNum = 115;BA.debugLine="objHelpers.Map2Disk2(xui.DefaultFolder, gblConst.";
mostCurrent._objhelpers._map2disk2 /*String*/ (_ba,_xui.getDefaultFolder(),mostCurrent._gblconst._file_main_setup /*String*/ ,_mainsetupdata);
 //BA.debugLineNum = 116;BA.debugLine="ReadMainSetup";
_readmainsetup(_ba);
 //BA.debugLineNum = 117;BA.debugLine="If check Then";
if (_check) { 
 //BA.debugLineNum = 118;BA.debugLine="B4XPages.MainPage.Check4Update";
mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._check4update /*String*/ ();
 }else {
 };
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public static String  _configme(anywheresoftware.b4a.BA _ba) throws Exception{
boolean _forcenew = false;
sadLogic.HomeCentral.checkversions _vo = null;
sadLogic.HomeCentral.dlgsetupmain _o3 = null;
 //BA.debugLineNum = 31;BA.debugLine="Private Sub ConfigMe()";
 //BA.debugLineNum = 33;BA.debugLine="Dim ForceNew As Boolean = False ' DEV stuff";
_forcenew = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 35;BA.debugLine="If Main.kvs.ContainsKey(gblConst.INI_INSTALL_DATE";
if (mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._ini_install_date /*String*/ )==anywheresoftware.b4a.keywords.Common.False || _forcenew) { 
 //BA.debugLineNum = 38;BA.debugLine="Is1stRun = True";
_is1strun = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 39;BA.debugLine="Main.kvs.Put(gblConst.INI_INSTALL_DATE,DateTime.";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_install_date /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.DateTime.getNow()));
 //BA.debugLineNum = 40;BA.debugLine="Main.kvs.Put(gblConst.INI_CURRENT_VER,gblConst.A";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_current_ver /*String*/ ,(Object)(mostCurrent._gblconst._app_file_version /*int*/ ));
 //BA.debugLineNum = 41;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_DEFAULT_CITY,\"";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_weather_default_city /*String*/ ,(Object)("Kherson, Ukraine"));
 //BA.debugLineNum = 42;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_USE_CELSIUS,Tr";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_weather_use_celsius /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.True));
 //BA.debugLineNum = 43;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_USE_METRIC,Fal";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_weather_use_metric /*String*/ ,(Object)(anywheresoftware.b4a.keywords.Common.False));
 //BA.debugLineNum = 44;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_CITY_LIST,\"Khe";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_weather_city_list /*String*/ ,(Object)("Kherson, Ukraine;;Seattle, Wa;;Paris, France"));
 //BA.debugLineNum = 46;BA.debugLine="Main.kvs.Put(gblConst.INI_TIMERS_ALARM_VOLUME,85";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_timers_alarm_volume /*String*/ ,(Object)(85));
 //BA.debugLineNum = 47;BA.debugLine="Main.kvs.Put(gblConst.INI_TIMERS_ALARM_FILE,\"kti";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_timers_alarm_file /*String*/ ,(Object)("ktimers_beep01.ogg"));
 //BA.debugLineNum = 49;BA.debugLine="Main.kvs.Put(gblConst.INI_WEB_HOME,\"http://sadlo";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_web_home /*String*/ ,(Object)("http://sadlogic.com"));
 //BA.debugLineNum = 52;BA.debugLine="Try";
try { //BA.debugLineNum = 53;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.LICEN";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._license_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 54;BA.debugLine="File.Copy(File.DirAssets,gblConst.LICENSE_FILE";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),mostCurrent._gblconst._license_file /*String*/ ,_xui.getDefaultFolder(),mostCurrent._gblconst._license_file /*String*/ );
 //BA.debugLineNum = 55;BA.debugLine="File.Copy(File.DirAssets,gblConst.LICENSE_FILE";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),mostCurrent._gblconst._license_file /*String*/ ,anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),mostCurrent._gblconst._license_file /*String*/ );
 };
 } 
       catch (Exception e19) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e19); };
 //BA.debugLineNum = 61;BA.debugLine="fileHelpers.SafeKill(xui.DefaultFolder,gblConst.";
mostCurrent._filehelpers._safekill /*String*/ (_ba,_xui.getDefaultFolder(),mostCurrent._gblconst._file_main_setup /*String*/ );
 }else {
 //BA.debugLineNum = 67;BA.debugLine="Dim vo As CheckVersions : vo.Initialize";
_vo = new sadLogic.HomeCentral.checkversions();
 //BA.debugLineNum = 67;BA.debugLine="Dim vo As CheckVersions : vo.Initialize";
_vo._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 68;BA.debugLine="vo.CheckAndUpgrade";
_vo._checkandupgrade /*String*/ ();
 };
 //BA.debugLineNum = 72;BA.debugLine="kt.InitSql '--- pointer for SQL engine for kitche";
mostCurrent._kt._initsql /*String*/ (_ba);
 //BA.debugLineNum = 77;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.FILE_MA";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._file_main_setup /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 78;BA.debugLine="Dim o3 As dlgSetupMain";
_o3 = new sadLogic.HomeCentral.dlgsetupmain();
 //BA.debugLineNum = 79;BA.debugLine="o3.initialize(Null)";
_o3._initialize /*String*/ (_ba,(sadLogic.HomeCentral.sadpreferencesdialog)(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 80;BA.debugLine="o3.createdefaultfile";
_o3._createdefaultfile /*String*/ ();
 };
 //BA.debugLineNum = 82;BA.debugLine="ReadMainSetup";
_readmainsetup(_ba);
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public static int  _getscreenofftime(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Public Sub getScreenOffTime() As Int";
 //BA.debugLineNum = 101;BA.debugLine="Return MainSetupData.Get(gblConst.KEYS_MAIN_SETUP";
if (true) return (int)(BA.ObjectToNumber(_mainsetupdata.Get((Object)(mostCurrent._gblconst._keys_main_setup_scrn_off_time /*String*/ ))));
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return 0;
}
public static String  _getweathericonset(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Public Sub getWeatherIconSet() As String";
 //BA.debugLineNum = 93;BA.debugLine="Return Main.kvs.GetDefault(gblConst.INI_WEATHER_I";
if (true) return BA.ObjectToString(mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (mostCurrent._gblconst._ini_weather_icons_path /*String*/ ,(Object)("cc01")));
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public static String  _init(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Init";
 //BA.debugLineNum = 25;BA.debugLine="ConfigMe";
_configme(_ba);
 //BA.debugLineNum = 26;BA.debugLine="IsInit = True";
_isinit = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Public IsInit As Boolean = False";
_isinit = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 14;BA.debugLine="Public MainSetupData As Map";
_mainsetupdata = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 15;BA.debugLine="Public Is1stRun As Boolean = False";
_is1strun = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _readmainsetup(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Public Sub ReadMainSetup";
 //BA.debugLineNum = 106;BA.debugLine="MainSetupData = objHelpers.MapFromDisk2(xui.Defau";
_mainsetupdata = mostCurrent._objhelpers._mapfromdisk2 /*anywheresoftware.b4a.objects.collections.Map*/ (_ba,_xui.getDefaultFolder(),mostCurrent._gblconst._file_main_setup /*String*/ );
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
}
