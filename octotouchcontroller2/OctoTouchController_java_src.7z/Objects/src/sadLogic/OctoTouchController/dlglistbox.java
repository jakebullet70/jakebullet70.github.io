package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlglistbox extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlglistbox");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlglistbox.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _mtitle = null;
public Object _mcallback = null;
public String _meventname = "";
public Object _mtag = null;
public sadLogic.OctoTouchController.b4xdialog _mdialog = null;
public boolean _ismenu = false;
public Object _backbtnref = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgListbox\"' '";
_mmodule = "dlgListbox";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mTitle As Object";
_mtitle = new Object();
 //BA.debugLineNum = 12;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 13;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 14;BA.debugLine="Private mTag As Object = Null 'ignore";
_mtag = __c.Null;
 //BA.debugLineNum = 16;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 18;BA.debugLine="Public IsMenu As Boolean = False";
_ismenu = __c.False;
 //BA.debugLineNum = 20;BA.debugLine="Private backBtnRef As Object";
_backbtnref = new Object();
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Close_Me '--- class method, called from";
 //BA.debugLineNum = 25;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 26;BA.debugLine="CallSubDelayed2(Main,\"SetObj_Null\",backBtnRef)";
__c.CallSubDelayed2(ba,(Object)(_main.getObject()),"SetObj_Null",_backbtnref);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _gettagfrommap(String _item,anywheresoftware.b4a.objects.collections.Map _d) throws Exception{
int _xx = 0;
 //BA.debugLineNum = 92;BA.debugLine="Private Sub GetTagFromMap(item As String,d As Map)";
 //BA.debugLineNum = 95;BA.debugLine="For xx = 0 To d.Size - 1";
{
final int step1 = 1;
final int limit1 = (int) (_d.getSize()-1);
_xx = (int) (0) ;
for (;_xx <= limit1 ;_xx = _xx + step1 ) {
 //BA.debugLineNum = 96;BA.debugLine="If d.GetKeyAt(xx).As(String).Contains(item) Then";
if ((BA.ObjectToString(_d.GetKeyAt(_xx))).contains(_item)) { 
 //BA.debugLineNum = 97;BA.debugLine="Return d.GetValueAt(xx)";
if (true) return BA.ObjectToString(_d.GetValueAt(_xx));
 };
 }
};
 //BA.debugLineNum = 100;BA.debugLine="Return \"\"";
if (true) return "";
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,Object _title,Object _callback,String _eventname,Object _ref) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 33;BA.debugLine="Public Sub Initialize( title As Object, Callback A";
 //BA.debugLineNum = 35;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 36;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 37;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 38;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 39;BA.debugLine="backBtnRef = ref";
_backbtnref = _ref;
 //BA.debugLineNum = 40;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public String  _settag(Object _v) throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Public Sub setTag(v As Object)";
 //BA.debugLineNum = 30;BA.debugLine="mTag = v";
_mtag = _v;
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public void  _show(float _height,float _width,anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_height,_width,_data);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlglistbox parent,float _height,float _width,anywheresoftware.b4a.objects.collections.Map _data) {
this.parent = parent;
this._height = _height;
this._width = _width;
this._data = _data;
}
sadLogic.OctoTouchController.dlglistbox parent;
float _height;
float _width;
anywheresoftware.b4a.objects.collections.Map _data;
sadLogic.OctoTouchController.b4xlisttemplate _listtemplate = null;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 48;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 49;BA.debugLine="Dim ListTemplate As B4XListTemplate : ListTemplat";
_listtemplate = new sadLogic.OctoTouchController.b4xlisttemplate();
 //BA.debugLineNum = 49;BA.debugLine="Dim ListTemplate As B4XListTemplate : ListTemplat";
_listtemplate._initialize /*String*/ (ba);
 //BA.debugLineNum = 50;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 51;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 54;BA.debugLine="ListTemplate.CustomListView1.DefaultTextBackgroun";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._clrtheme._background /*int*/ ;
 //BA.debugLineNum = 57;BA.debugLine="ListTemplate.Resize(width, height)";
_listtemplate._resize /*String*/ ((int) (_width),(int) (_height));
 //BA.debugLineNum = 58;BA.debugLine="ListTemplate.CustomListView1.AsView.width = width";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._asview().setWidth((int) (_width));
 //BA.debugLineNum = 59;BA.debugLine="ListTemplate.CustomListView1.AsView.Height = heig";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._asview().setHeight((int) (_height));
 //BA.debugLineNum = 60;BA.debugLine="ListTemplate.CustomListView1.PressedColor = clrTh";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._pressedcolor = parent._clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 61;BA.debugLine="ListTemplate.CustomListView1.DefaultTextColor = c";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 62;BA.debugLine="ListTemplate.options = objHelpers.Map2List(data,T";
_listtemplate._options /*anywheresoftware.b4a.objects.collections.List*/  = parent._objhelpers._map2list /*anywheresoftware.b4a.objects.collections.List*/ (ba,_data,parent.__c.True);
 //BA.debugLineNum = 65;BA.debugLine="Dim l As B4XView = ListTemplate.CustomListView1.D";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._designerlabel.getObject()));
 //BA.debugLineNum = 66;BA.debugLine="l.Font = xui.CreateDefaultFont(NumberFormat2(20 /";
_l.setFont(parent._xui.CreateDefaultFont((float)(Double.parseDouble(parent.__c.NumberFormat2(20/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))));
 //BA.debugLineNum = 68;BA.debugLine="If guiHelpers.gIsLandScape = False Then";
if (true) break;

case 1:
//if
this.state = 8;
if (parent._guihelpers._gislandscape /*boolean*/ ==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 69;BA.debugLine="If guiHelpers.gScreenSizeAprox > 6.2 Then";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._guihelpers._gscreensizeaprox /*double*/ >6.2) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 70;BA.debugLine="l.Font = xui.CreateDefaultFont(NumberFormat2(26";
_l.setFont(parent._xui.CreateDefaultFont((float)(Double.parseDouble(parent.__c.NumberFormat2(26/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))));
 if (true) break;

case 7:
//C
this.state = 8;
;
 if (true) break;

case 8:
//C
this.state = 9;
;
 //BA.debugLineNum = 74;BA.debugLine="dlgHelper.ThemeDialogForm( mTitle)";
_dlghelper._themedialogform /*String*/ (parent._mtitle);
 //BA.debugLineNum = 75;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowTemplate(Lis";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_listtemplate),(Object)(""),(Object)(""),((parent._ismenu) ? ((Object)("CLOSE")) : ((Object)("CANCEL"))));
 //BA.debugLineNum = 76;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 79;BA.debugLine="Wait For(rs) complete(i As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 15;
return;
case 15:
//C
this.state = 9;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 80;BA.debugLine="If i = xui.DialogResponse_Positive Then";
if (true) break;

case 9:
//if
this.state = 14;
if (_i==parent._xui.DialogResponse_Positive) { 
this.state = 11;
}else {
this.state = 13;
}if (true) break;

case 11:
//C
this.state = 14;
 //BA.debugLineNum = 81;BA.debugLine="CallSub3(mCallback,mEventName,GetTagFromMap(List";
parent.__c.CallSubNew3(ba,parent._mcallback,parent._meventname,(Object)(parent._gettagfrommap(_listtemplate._selecteditem /*String*/ ,_data)),parent._mtag);
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 83;BA.debugLine="CallSub3(mCallback,mEventName,\"\",\"\")";
parent.__c.CallSubNew3(ba,parent._mcallback,parent._meventname,(Object)(""),(Object)(""));
 if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 85;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 86;BA.debugLine="CallSubDelayed2(Main,\"SetObj_Null\",backBtnRef)";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"SetObj_Null",parent._backbtnref);
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
