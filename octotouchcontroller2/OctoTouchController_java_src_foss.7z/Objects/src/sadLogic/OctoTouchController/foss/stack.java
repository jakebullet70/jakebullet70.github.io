package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class stack extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.stack");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.stack.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.List _data = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private data As List";
_data = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _clear() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Clear";
 //BA.debugLineNum = 33;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public int  _getsize() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Public Sub getSize() As Int '--- property";
 //BA.debugLineNum = 11;BA.debugLine="Return data.Size";
if (true) return _data.getSize();
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 15;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public Object  _peak() throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Public Sub Peak() As Object";
 //BA.debugLineNum = 29;BA.debugLine="Return data.Get(data.Size - 1)";
if (true) return _data.Get((int) (_data.getSize()-1));
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public Object  _pop() throws Exception{
Object _o = null;
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Pop() As Object";
 //BA.debugLineNum = 23;BA.debugLine="Dim o As Object = data.Get(data.Size - 1)";
_o = _data.Get((int) (_data.getSize()-1));
 //BA.debugLineNum = 24;BA.debugLine="data.RemoveAt(data.Size - 1)";
_data.RemoveAt((int) (_data.getSize()-1));
 //BA.debugLineNum = 25;BA.debugLine="Return o";
if (true) return _o;
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return null;
}
public String  _push(Object _o) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Push(o As Object)";
 //BA.debugLineNum = 19;BA.debugLine="data.Add(o)";
_data.Add(_o);
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
