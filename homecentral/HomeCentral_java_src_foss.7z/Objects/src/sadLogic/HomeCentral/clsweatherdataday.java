package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clsweatherdataday extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.clsweatherdataday");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.clsweatherdataday.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _day = "";
public String _averagetemp_c = "";
public String _averagetemp_f = "";
public int _high_c = 0;
public int _low_c = 0;
public int _high_f = 0;
public int _low_f = 0;
public String _feelslike_c = "";
public String _feelslike_f = "";
public String _description = "";
public String _sunrise = "";
public String _sunset = "";
public int _iconid = 0;
public String _iconurl = "";
public int _apicode = 0;
public String _localtime = "";
public String _chanceofsnow = "";
public String _chanceofrain = "";
public String _willitrain = "";
public String _willitsnow = "";
public String _percip_mm = "";
public String _percip_inches = "";
public String _uv = "";
public String _snow_cm = "";
public String _snow_inches = "";
public String _max_wind_kph = "";
public String _max_wind_mph = "";
public String _humidity = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Public Day As String = \"N/A\"";
_day = "N/A";
 //BA.debugLineNum = 4;BA.debugLine="Public AverageTemp_c As String = \"N/A\"";
_averagetemp_c = "N/A";
 //BA.debugLineNum = 5;BA.debugLine="Public AverageTemp_f As String = \"N/A\"";
_averagetemp_f = "N/A";
 //BA.debugLineNum = 6;BA.debugLine="Public High_c As Int";
_high_c = 0;
 //BA.debugLineNum = 7;BA.debugLine="Public Low_c As Int";
_low_c = 0;
 //BA.debugLineNum = 8;BA.debugLine="Public High_f As Int";
_high_f = 0;
 //BA.debugLineNum = 9;BA.debugLine="Public Low_f As Int";
_low_f = 0;
 //BA.debugLineNum = 10;BA.debugLine="Public FeelsLike_c As String";
_feelslike_c = "";
 //BA.debugLineNum = 11;BA.debugLine="Public FeelsLike_f As String";
_feelslike_f = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Description As String = \"N/A\"";
_description = "N/A";
 //BA.debugLineNum = 13;BA.debugLine="Public Sunrise As String = \"N/A\"";
_sunrise = "N/A";
 //BA.debugLineNum = 14;BA.debugLine="Public Sunset As String = \"N/A\"";
_sunset = "N/A";
 //BA.debugLineNum = 15;BA.debugLine="Public IconID As Int = -1";
_iconid = (int) (-1);
 //BA.debugLineNum = 16;BA.debugLine="Public IconURL As String = \"N/A\"";
_iconurl = "N/A";
 //BA.debugLineNum = 17;BA.debugLine="Public APIcode As Int = -1";
_apicode = (int) (-1);
 //BA.debugLineNum = 18;BA.debugLine="Public LocalTime As String = \"N/A\"";
_localtime = "N/A";
 //BA.debugLineNum = 19;BA.debugLine="Public ChanceOfSnow As String = \"N/A\"";
_chanceofsnow = "N/A";
 //BA.debugLineNum = 20;BA.debugLine="Public ChanceOfRain As String = \"N/A\"";
_chanceofrain = "N/A";
 //BA.debugLineNum = 21;BA.debugLine="Public WillItRain As String = \"N/A\"";
_willitrain = "N/A";
 //BA.debugLineNum = 22;BA.debugLine="Public WillItSnow As String = \"N/A\"";
_willitsnow = "N/A";
 //BA.debugLineNum = 23;BA.debugLine="Public Percip_mm As String = \"N/A\"";
_percip_mm = "N/A";
 //BA.debugLineNum = 24;BA.debugLine="Public Percip_inches As String = \"N/A\"";
_percip_inches = "N/A";
 //BA.debugLineNum = 25;BA.debugLine="Public UV As String = \"N/A\"";
_uv = "N/A";
 //BA.debugLineNum = 26;BA.debugLine="Public Snow_cm As String = \"N/A\"";
_snow_cm = "N/A";
 //BA.debugLineNum = 27;BA.debugLine="Public Snow_inches As String = \"N/A\"";
_snow_inches = "N/A";
 //BA.debugLineNum = 28;BA.debugLine="Public Max_Wind_kph As String  = \"N/A\"";
_max_wind_kph = "N/A";
 //BA.debugLineNum = 29;BA.debugLine="Public Max_Wind_mph As String = \"N/A\"";
_max_wind_mph = "N/A";
 //BA.debugLineNum = 30;BA.debugLine="Public Humidity As String";
_humidity = "";
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
