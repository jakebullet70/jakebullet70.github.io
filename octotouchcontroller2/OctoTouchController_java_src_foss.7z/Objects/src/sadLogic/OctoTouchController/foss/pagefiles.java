package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagefiles extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.pagefiles");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.pagefiles.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _mpnlmain = null;
public String _mcallbackevent = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public String _displayedfilename = "";
public sadLogic.OctoTouchController.foss.sadclvselections _cselections = null;
public int _no_selection = 0;
public int _clvlastindexclicked = 0;
public b4a.example3.customlistview _clvfiles = null;
public sadLogic.OctoTouchController.foss.lmb4ximageviewx _ivpreview = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndelete = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnload = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnloadandprint = null;
public sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _mcurrentfileinfo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlportraitdivide = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblpnlfileviewtop = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblpnlfileviewbottom = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlfileviewbg = null;
public boolean _filescheckchangeisbusyflag = false;
public boolean _firstrun = false;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblfilename = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblheaderfilename = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblbusy = null;
public String _moldfilename = "";
public anywheresoftware.b4a.objects.LabelWrapper _lblsort2 = null;
public sadLogic.OctoTouchController.foss.b4xcombobox _cbosort = null;
public anywheresoftware.b4a.sql.SQL.ResultSetWrapper _rsfiles = null;
public boolean _sortascdesc = false;
public String _lastsort = "";
public boolean _fileevent = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public void  _btnaction_click() throws Exception{
ResumableSub_btnAction_Click rsub = new ResumableSub_btnAction_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnAction_Click extends BA.ResumableSub {
public ResumableSub_btnAction_Click(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
anywheresoftware.b4a.objects.B4XViewWrapper _btn = null;
sadLogic.OctoTouchController.foss.dlgmsgbox _mb = null;
int _res = 0;
sadLogic.OctoTouchController.foss.dlgmsgbox2 _mb2 = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 199;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 199;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 201;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 203;BA.debugLine="If clvLastIndexClicked = NO_SELECTION Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._clvlastindexclicked==parent._no_selection) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 204;BA.debugLine="guiHelpers.Show_toast(\"No item selected\",2500)";
parent._guihelpers._show_toast /*String*/ (ba,"No item selected",(int) (2500));
 //BA.debugLineNum = 205;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 208;BA.debugLine="Select Case btn.Tag";

case 4:
//select
this.state = 21;
switch (BA.switchObjectToInt(_btn.getTag(),(Object)("delete"),(Object)("load"),(Object)("loadandprint"))) {
case 0: {
this.state = 6;
if (true) break;
}
case 1: {
this.state = 12;
if (true) break;
}
case 2: {
this.state = 14;
if (true) break;
}
}
if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 212;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.foss.dlgmsgbox();
 //BA.debugLineNum = 213;BA.debugLine="mb.Initialize(mMainObj.Root,\"Question\", IIf(gui";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",(float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (500)))) : ((Object)(parent._guihelpers._gwidth /*float*/ -parent.__c.DipToCurrent((int) (40))))))),(float) (parent.__c.DipToCurrent((int) (170))),parent.__c.False);
 //BA.debugLineNum = 217;BA.debugLine="Wait For (mb.Show(\"Delete file from Octoprint?\"";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Delete file from Octoprint?",parent._gblconst._mb_icon_question /*String*/ ,"Yes - Delete It","","No"));
this.state = 22;
return;
case 22:
//C
this.state = 7;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 220;BA.debugLine="If res = xui.DialogResponse_Positive Then";
if (true) break;

case 7:
//if
this.state = 10;
if (_res==parent._xui.DialogResponse_Positive) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 221;BA.debugLine="SendDeleteCmdAndRemoveFromGrid";
parent._senddeletecmdandremovefromgrid();
 if (true) break;

case 10:
//C
this.state = 21;
;
 if (true) break;

case 12:
//C
this.state = 21;
 //BA.debugLineNum = 227;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cP";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cpost_files_select /*String*/ .replace("!LOC!",parent._mcurrentfileinfo.Origin /*String*/ ).replace("!PATH!",parent._mcurrentfileinfo.Name /*String*/ ));
 //BA.debugLineNum = 229;BA.debugLine="guiHelpers.Show_toast(\"Loading file...\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"Loading file...",(int) (2000));
 //BA.debugLineNum = 230;BA.debugLine="Sleep(500) '<--- needed";
parent.__c.Sleep(ba,this,(int) (500));
this.state = 23;
return;
case 23:
//C
this.state = 21;
;
 //BA.debugLineNum = 231;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tm";
parent.__c.CallSubNew(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 232;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Upd";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Update_LoadedFileName2Scrn",(int) (400));
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 236;BA.debugLine="Dim mb2 As dlgMsgBox2";
_mb2 = new sadLogic.OctoTouchController.foss.dlgmsgbox2();
 //BA.debugLineNum = 237;BA.debugLine="mb2.Initialize(mMainObj.Root,\"Question\",280dip,";
_mb2._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",(float) (parent.__c.DipToCurrent((int) (280))),(float) (parent.__c.DipToCurrent((int) (150))),parent.__c.False);
 //BA.debugLineNum = 238;BA.debugLine="mb2.NewTextSize = 32";
_mb2._newtextsize /*float*/  = (float) (32);
 //BA.debugLineNum = 239;BA.debugLine="Wait For (mb2.Show(\"Start print job?\",gblConst.";
parent.__c.WaitFor("complete", ba, this, _mb2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Start print job?",parent._gblconst._mb_icon_question /*String*/ ,"PRINT","","CANCEL"));
this.state = 24;
return;
case 24:
//C
this.state = 15;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 240;BA.debugLine="If res = xui.DialogResponse_Cancel Then Return";
if (true) break;

case 15:
//if
this.state = 20;
if (_res==parent._xui.DialogResponse_Cancel) { 
this.state = 17;
;}if (true) break;

case 17:
//C
this.state = 20;
if (true) return ;
if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 244;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cP";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cpost_files_print /*String*/ .replace("!LOC!",parent._mcurrentfileinfo.Origin /*String*/ ).replace("!PATH!",parent._mcurrentfileinfo.Name /*String*/ ));
 //BA.debugLineNum = 246;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(b";
parent._guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnload,parent._btnloadandprint,parent._btndelete},parent.__c.False);
 //BA.debugLineNum = 247;BA.debugLine="CallSubDelayed2(mMainObj,\"Switch_Pages\",gblCons";
parent.__c.CallSubDelayed2(ba,(Object)(parent._mmainobj),"Switch_Pages",(Object)(parent._gblconst._page_printing /*String*/ ));
 //BA.debugLineNum = 248;BA.debugLine="Sleep(10)";
parent.__c.Sleep(ba,this,(int) (10));
this.state = 25;
return;
case 25:
//C
this.state = 21;
;
 //BA.debugLineNum = 249;BA.debugLine="guiHelpers.Show_toast2(\"Starting Print\",2000)";
parent._guihelpers._show_toast2 /*String*/ (ba,"Starting Print",(int) (2000));
 //BA.debugLineNum = 250;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(mMainOb";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._mmainobj._opageprinting /*sadLogic.OctoTouchController.foss.pageprinting*/ ),"Show_Temp_Panel",(int) (500));
 if (true) break;

case 21:
//C
this.state = -1;
;
 //BA.debugLineNum = 254;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public String  _build_listviewfilelist() throws Exception{
int _ndx = 0;
String _fname = "";
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _o = null;
 //BA.debugLineNum = 278;BA.debugLine="Public Sub Build_ListViewFileList";
 //BA.debugLineNum = 282;BA.debugLine="clvFiles.Clear";
_clvfiles._clear();
 //BA.debugLineNum = 283;BA.debugLine="If rsFiles.IsInitialized Then rsFiles.Close";
if (_rsfiles.IsInitialized()) { 
_rsfiles.Close();};
 //BA.debugLineNum = 284;BA.debugLine="Main.db.BuildTable";
_main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._buildtable /*String*/ ();
 //BA.debugLineNum = 285;BA.debugLine="Main.db.SeedTable(mMainObj.oMasterController.gMap";
_main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._seedtable /*String*/ (_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ );
 //BA.debugLineNum = 287;BA.debugLine="CSelections.Initialize(clvFiles)";
_cselections._initialize /*String*/ (ba,_clvfiles);
 //BA.debugLineNum = 288;BA.debugLine="CSelections.Mode = CSelections.MODE_SINGLE_ITEM_P";
_cselections._setmode /*int*/ (_cselections._mode_single_item_permanent /*int*/ );
 //BA.debugLineNum = 290;BA.debugLine="Dim ndx As Int = 0";
_ndx = (int) (0);
 //BA.debugLineNum = 291;BA.debugLine="Dim fname As String";
_fname = "";
 //BA.debugLineNum = 293;BA.debugLine="If rsFiles.IsInitialized Then rsFiles.Close";
if (_rsfiles.IsInitialized()) { 
_rsfiles.Close();};
 //BA.debugLineNum = 294;BA.debugLine="rsFiles = Main.db.sql.ExecQuery( _ 					$\"SELECT";
_rsfiles = (anywheresoftware.b4a.sql.SQL.ResultSetWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.sql.SQL.ResultSetWrapper(), (android.database.Cursor)(_main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecQuery(("SELECT * FROM files ORDER BY "+__c.SmartStringFormatter("",(Object)(_getfilesortorder()))+" "+__c.SmartStringFormatter("",((_sortascdesc) ? ((Object)("ASC")) : ((Object)("DESC"))))+""))));
 //BA.debugLineNum = 297;BA.debugLine="Do While rsFiles.NextRow";
while (_rsfiles.NextRow()) {
 //BA.debugLineNum = 298;BA.debugLine="fname = rsFiles.GetString(\"file_name\")";
_fname = _rsfiles.GetString("file_name");
 //BA.debugLineNum = 299;BA.debugLine="Dim o As tOctoFileInfo  = mMainObj.oMasterContro";
_o = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_fname)));
 //BA.debugLineNum = 300;BA.debugLine="clvFiles.InsertAt(ndx, CreateListItem(o, clvFile";
_clvfiles._insertat(_ndx,_createlistitem(_o,_clvfiles._asview().getWidth(),__c.DipToCurrent((int) (60))),(Object)(_fname));
 //BA.debugLineNum = 301;BA.debugLine="ndx = ndx + 1";
_ndx = (int) (_ndx+1);
 }
;
 //BA.debugLineNum = 304;BA.debugLine="clvFiles.PressedColor = DimColor(clrTheme.txtNorm";
_clvfiles._pressedcolor = _dimcolor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 305;BA.debugLine="CSelections.SelectionColor = clvFiles.PressedColo";
_cselections._selectioncolor /*int*/  = _clvfiles._pressedcolor;
 //BA.debugLineNum = 306;BA.debugLine="clvFiles.DefaultTextColor  = clrTheme.txtNormal";
_clvfiles._defaulttextcolor = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 307;BA.debugLine="clvFiles.DefaultTextBackgroundColor = xui.Color_T";
_clvfiles._defaulttextbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 309;BA.debugLine="If clvFiles.Size > 0 Then";
if (_clvfiles._getsize()>0) { 
 //BA.debugLineNum = 311;BA.debugLine="CSelections.ItemClicked(0)";
_cselections._itemclicked /*String*/ ((int) (0));
 //BA.debugLineNum = 312;BA.debugLine="clvLastIndexClicked = 0";
_clvlastindexclicked = (int) (0);
 }else {
 //BA.debugLineNum = 314;BA.debugLine="clvLastIndexClicked = NO_SELECTION";
_clvlastindexclicked = _no_selection;
 };
 //BA.debugLineNum = 317;BA.debugLine="lblBusy.Visible = False";
_lblbusy.setVisible(__c.False);
 //BA.debugLineNum = 319;BA.debugLine="End Sub";
return "";
}
public String  _build_listviewfilelist_keep() throws Exception{
int _currentitem = 0;
 //BA.debugLineNum = 263;BA.debugLine="Private Sub Build_ListViewFileList_keep";
 //BA.debugLineNum = 264;BA.debugLine="Dim currentItem As Int = clvLastIndexClicked";
_currentitem = _clvlastindexclicked;
 //BA.debugLineNum = 265;BA.debugLine="Build_ListViewFileList";
_build_listviewfilelist();
 //BA.debugLineNum = 266;BA.debugLine="Try";
try { //BA.debugLineNum = 267;BA.debugLine="If clvFiles.Size > 0 Then";
if (_clvfiles._getsize()>0) { 
 //BA.debugLineNum = 268;BA.debugLine="CSelections.ItemClicked(currentItem)";
_cselections._itemclicked /*String*/ (_currentitem);
 //BA.debugLineNum = 269;BA.debugLine="clvLastIndexClicked = currentItem";
_clvlastindexclicked = _currentitem;
 };
 } 
       catch (Exception e9) {
			ba.setLastException(e9); //BA.debugLineNum = 272;BA.debugLine="CSelections.ItemClicked(0)";
_cselections._itemclicked /*String*/ ((int) (0));
 //BA.debugLineNum = 273;BA.debugLine="clvLastIndexClicked = 0";
_clvlastindexclicked = (int) (0);
 };
 //BA.debugLineNum = 276;BA.debugLine="End Sub";
return "";
}
public void  _buildgui() throws Exception{
ResumableSub_BuildGUI rsub = new ResumableSub_BuildGUI(this);
rsub.resume(ba, null);
}
public static class ResumableSub_BuildGUI extends BA.ResumableSub {
public ResumableSub_BuildGUI(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 149;BA.debugLine="guiHelpers.ReSkinB4XComboBox(Array As B4XComboBox";
parent._guihelpers._reskinb4xcombobox /*String*/ (ba,new sadLogic.OctoTouchController.foss.b4xcombobox[]{parent._cbosort});
 //BA.debugLineNum = 150;BA.debugLine="guiHelpers.SetTextColor2(Array As B4XView(lblFile";
parent._guihelpers._settextcolor2 /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{parent._lblfilename._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),parent._lblheaderfilename,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblsort2.getObject())),parent._lblbusy});
 //BA.debugLineNum = 151;BA.debugLine="guiHelpers.ResizeText(Chr(0xF175),lblSort2) : lbl";
parent._guihelpers._resizetext /*String*/ (ba,(Object)(parent.__c.Chr(((int)0xf175))),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblsort2.getObject())));
 //BA.debugLineNum = 151;BA.debugLine="guiHelpers.ResizeText(Chr(0xF175),lblSort2) : lbl";
parent._lblsort2.setTextSize((float) (parent._lblsort2.getTextSize()-6));
 //BA.debugLineNum = 153;BA.debugLine="cboSort.setitems(Array As String(\"File Name\",\"Dat";
parent._cbosort._setitems /*String*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"File Name","Date Added"}));
 //BA.debugLineNum = 155;BA.debugLine="cboSort.SelectedIndex = Main.kvs.GetDefault(\"fsor";
parent._cbosort._setselectedindex /*int*/ ((int)(BA.ObjectToNumber(parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ ("fsort-idx",(Object)(0)))));
 //BA.debugLineNum = 156;BA.debugLine="LastSort = Main.kvs.GetDefault(\"fsort-lbl\",\"File";
parent._lastsort = BA.ObjectToString(parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ ("fsort-lbl",(Object)("File Name")));
 //BA.debugLineNum = 157;BA.debugLine="SortAscDesc = Main.kvs.GetDefault(\"fsort-asc\",Tru";
parent._sortascdesc = BA.ObjectToBoolean(parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ ("fsort-asc",(Object)(parent.__c.True)));
 //BA.debugLineNum = 158;BA.debugLine="lblSort2.Text = IIf(SortAscDesc,Chr(0xF176),Chr(0";
parent._lblsort2.setText(BA.ObjectToCharSequence(((parent._sortascdesc) ? ((Object)(parent.__c.Chr(((int)0xf176)))) : ((Object)(parent.__c.Chr(((int)0xf175)))))));
 //BA.debugLineNum = 158;BA.debugLine="lblSort2.Text = IIf(SortAscDesc,Chr(0xF176),Chr(0";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 11;
return;
case 11:
//C
this.state = 1;
;
 //BA.debugLineNum = 160;BA.debugLine="cboSort.cmbBox.Prompt = \"Sort Order\"";
parent._cbosort._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setPrompt(BA.ObjectToCharSequence("Sort Order"));
 //BA.debugLineNum = 162;BA.debugLine="lblBusy.Visible = True";
parent._lblbusy.setVisible(parent.__c.True);
 //BA.debugLineNum = 163;BA.debugLine="lblBusy.SetColorAndBorder(clrTheme.BackgroundHead";
parent._lblbusy.SetColorAndBorder(parent._clrtheme._backgroundheader /*int*/ ,parent.__c.DipToCurrent((int) (1)),parent._clrtheme._txtnormal /*int*/ ,parent.__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 165;BA.debugLine="pnlPortraitDivide.SetColorAndBorder(clrTheme.txtA";
parent._pnlportraitdivide.SetColorAndBorder(parent._clrtheme._txtaccent /*int*/ ,parent.__c.DipToCurrent((int) (2)),parent._clrtheme._txtaccent /*int*/ ,parent.__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 167;BA.debugLine="If mMainObj.oMasterController.gMapOctoFilesList.I";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .IsInitialized() && parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()>0) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 168;BA.debugLine="Build_ListViewFileList";
parent._build_listviewfilelist();
 //BA.debugLineNum = 169;BA.debugLine="Show1stFile '--- select the 1st item and load im";
parent._show1stfile();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 171;BA.debugLine="clvFiles.Clear";
parent._clvfiles._clear();
 //BA.debugLineNum = 172;BA.debugLine="clvFiles_ItemClick(0,Null)";
parent._clvfiles_itemclick((int) (0),parent.__c.Null);
 //BA.debugLineNum = 173;BA.debugLine="lblBusy.Visible = False";
parent._lblbusy.setVisible(parent.__c.False);
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 176;BA.debugLine="btnLoadAndPrint.Text = \"Print\"";
parent._btnloadandprint.setText(BA.ObjectToCharSequence("Print"));
 //BA.debugLineNum = 177;BA.debugLine="btnLoad.Text = \"Load\"";
parent._btnload.setText(BA.ObjectToCharSequence("Load"));
 //BA.debugLineNum = 178;BA.debugLine="btnDelete.Text = \"Delete\"";
parent._btndelete.setText(BA.ObjectToCharSequence("Delete"));
 //BA.debugLineNum = 180;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnLoadAndP";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnloadandprint,parent._btnload,parent._btndelete});
 //BA.debugLineNum = 182;BA.debugLine="If guiHelpers.gScreenSizeAprox > 7.5 Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._guihelpers._gscreensizeaprox /*double*/ >7.5) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 183;BA.debugLine="btnDelete.TextSize = 52";
parent._btndelete.setTextSize((float) (52));
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 185;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnLoadAnd";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnloadandprint,parent._btnload,parent._btndelete},(float) ((double)(Double.parseDouble(parent.__c.NumberFormat2(parent._btndelete.getTextSize()/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))-(double)(BA.ObjectToNumber(((parent._guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _cbosort_selectedindexchanged(int _index) throws Exception{
ResumableSub_cboSort_SelectedIndexChanged rsub = new ResumableSub_cboSort_SelectedIndexChanged(this,_index);
rsub.resume(ba, null);
}
public static class ResumableSub_cboSort_SelectedIndexChanged extends BA.ResumableSub {
public ResumableSub_cboSort_SelectedIndexChanged(sadLogic.OctoTouchController.foss.pagefiles parent,int _index) {
this.parent = parent;
this._index = _index;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
int _index;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 673;BA.debugLine="If LastSort = cboSort.SelectedItem Then";
if (true) break;

case 1:
//if
this.state = 6;
if ((parent._lastsort).equals(parent._cbosort._getselecteditem /*String*/ ())) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 674;BA.debugLine="SortAscDesc = Not (SortAscDesc)";
parent._sortascdesc = parent.__c.Not(parent._sortascdesc);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 676;BA.debugLine="SortAscDesc = True";
parent._sortascdesc = parent.__c.True;
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 679;BA.debugLine="lblSort2.Text = IIf(SortAscDesc,Chr(0xF176),Chr(0";
parent._lblsort2.setText(BA.ObjectToCharSequence(((parent._sortascdesc) ? ((Object)(parent.__c.Chr(((int)0xf176)))) : ((Object)(parent.__c.Chr(((int)0xf175)))))));
 //BA.debugLineNum = 679;BA.debugLine="lblSort2.Text = IIf(SortAscDesc,Chr(0xF176),Chr(0";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 681;BA.debugLine="guiHelpers.Show_toast(\"File list sorted\" ,1200)";
parent._guihelpers._show_toast /*String*/ (ba,"File list sorted",(int) (1200));
 //BA.debugLineNum = 682;BA.debugLine="Build_ListViewFileList";
parent._build_listviewfilelist();
 //BA.debugLineNum = 683;BA.debugLine="Show1stFile";
parent._show1stfile();
 //BA.debugLineNum = 685;BA.debugLine="LastSort = cboSort.SelectedItem";
parent._lastsort = parent._cbosort._getselecteditem /*String*/ ();
 //BA.debugLineNum = 688;BA.debugLine="Main.kvs.Put(\"fsort-idx\",cboSort.SelectedIndex)";
parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ ("fsort-idx",(Object)(parent._cbosort._getselectedindex /*int*/ ()));
 //BA.debugLineNum = 689;BA.debugLine="Main.kvs.Put(\"fsort-lbl\",LastSort)";
parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ ("fsort-lbl",(Object)(parent._lastsort));
 //BA.debugLineNum = 690;BA.debugLine="Main.kvs.Put(\"fsort-asc\",SortAscDesc)";
parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ ("fsort-asc",(Object)(parent._sortascdesc));
 //BA.debugLineNum = 692;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _checkiffileschanged() throws Exception{
ResumableSub_CheckIfFilesChanged rsub = new ResumableSub_CheckIfFilesChanged(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_CheckIfFilesChanged extends BA.ResumableSub {
public ResumableSub_CheckIfFilesChanged(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
String _insub = "";
int _oldlistviewsize = 0;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparserfiles _o = null;
boolean _didsomethingchange = false;
boolean _incompletedata = false;
boolean _sizemismatch = false;
anywheresoftware.b4a.objects.collections.Map _mapnewfilelist = null;
int _ttlrecsindb = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 430;BA.debugLine="Dim inSub As String = \"CheckIfFilesChanged\"";
_insub = "CheckIfFilesChanged";
 //BA.debugLineNum = 431;BA.debugLine="If FilesCheckChangeIsBusyFLAG Then Return Null";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._filescheckchangeisbusyflag) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) {
parent.__c.ReturnFromResumableSub(this,parent.__c.Null);return;};
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 432;BA.debugLine="If mMainObj.oMasterController.gMapOctoFilesList.I";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .IsInitialized()==parent.__c.False) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 433;BA.debugLine="mMainObj.oMasterController.GetAllOctoFilesInfo";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getalloctofilesinfo /*void*/ ();
 //BA.debugLineNum = 434;BA.debugLine="Return Null";
if (true) {
parent.__c.ReturnFromResumableSub(this,parent.__c.Null);return;};
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 437;BA.debugLine="Dim oldListViewSize As Int = clvFiles.Size";
_oldlistviewsize = parent._clvfiles._getsize();
 //BA.debugLineNum = 440;BA.debugLine="FilesCheckChangeIsBusyFLAG = True";
parent._filescheckchangeisbusyflag = parent.__c.True;
 //BA.debugLineNum = 443;BA.debugLine="Dim rs As ResumableSub =  mMainObj.oMasterControl";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cfiles /*String*/ );
 //BA.debugLineNum = 444;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 54;
return;
case 54:
//C
this.state = 11;
_result = (String) result[0];
;
 //BA.debugLineNum = 446;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 11:
//if
this.state = 44;
if (_result.length()!=0) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 449;BA.debugLine="Dim o As JsonParserFiles";
_o = new sadLogic.OctoTouchController.foss.jsonparserfiles();
 //BA.debugLineNum = 450;BA.debugLine="o.Initialize(False) '--- DO NOT download thumbna";
_o._initialize /*String*/ (ba,parent.__c.False);
 //BA.debugLineNum = 451;BA.debugLine="Dim didSomethingChange As Boolean = o.CheckIfCha";
_didsomethingchange = _o._checkifchanged /*boolean*/ (_result,parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ );
 //BA.debugLineNum = 455;BA.debugLine="Dim IncompleteData As Boolean = mMainObj.oMaster";
_incompletedata = parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._isincompletefiledata /*boolean*/ ();
 //BA.debugLineNum = 458;BA.debugLine="Dim SizeMisMatch As Boolean = (clvFiles.Size <>";
_sizemismatch = (parent._clvfiles._getsize()!=parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .getSize());
 //BA.debugLineNum = 460;BA.debugLine="If didSomethingChange Or IncompleteData Or SizeM";
if (true) break;

case 14:
//if
this.state = 43;
if (_didsomethingchange || _incompletedata || _sizemismatch) { 
this.state = 16;
}else {
this.state = 36;
}if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 463;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2($\"di";
if (true) break;

case 17:
//if
this.state = 22;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 19;
;}if (true) break;

case 19:
//C
this.state = 22;
parent._logme._logit2 /*String*/ (ba,("did change:(incomplete:"+parent.__c.SmartStringFormatter("",(Object)(_incompletedata))+")(SizeMisMatch:"+parent.__c.SmartStringFormatter("",(Object)(_sizemismatch))+")"),parent._mmodule,_insub);
if (true) break;

case 22:
//C
this.state = 23;
;
 //BA.debugLineNum = 465;BA.debugLine="logMe.LogIt2($\"did change:(incomplete:${Incompl";
parent._logme._logit2 /*String*/ (ba,("did change:(incomplete:"+parent.__c.SmartStringFormatter("",(Object)(_incompletedata))+")(SizeMisMatch:"+parent.__c.SmartStringFormatter("",(Object)(_sizemismatch))+")"),parent._mmodule,_insub);
 //BA.debugLineNum = 470;BA.debugLine="Dim mapNewFileList As Map = o.StartParseAllFile";
_mapnewfilelist = new anywheresoftware.b4a.objects.collections.Map();
_mapnewfilelist = _o._startparseallfilesocto /*anywheresoftware.b4a.objects.collections.Map*/ (_result);
 //BA.debugLineNum = 474;BA.debugLine="ProcessNewOldThumbnails(mapNewFileList)";
parent._processnewoldthumbnails(_mapnewfilelist);
 //BA.debugLineNum = 477;BA.debugLine="mMainObj.oMasterController.gMapOctoFilesList =";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/  = parent._objhelpers._copymap /*anywheresoftware.b4a.objects.collections.Map*/ (ba,_mapnewfilelist);
 //BA.debugLineNum = 479;BA.debugLine="If IncompleteData = False Then";
if (true) break;

case 23:
//if
this.state = 34;
if (_incompletedata==parent.__c.False) { 
this.state = 25;
}else {
this.state = 27;
}if (true) break;

case 25:
//C
this.state = 34;
 //BA.debugLineNum = 480;BA.debugLine="Build_ListViewFileList";
parent._build_listviewfilelist();
 if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 482;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"In";
if (true) break;

case 28:
//if
this.state = 33;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 30;
;}if (true) break;

case 30:
//C
this.state = 33;
parent._logme._logit2 /*String*/ (ba,"Incomplete file data processed",parent._mmodule,_insub);
if (true) break;

case 33:
//C
this.state = 34;
;
 if (true) break;

case 34:
//C
this.state = 43;
;
 if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 488;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"did";
if (true) break;

case 37:
//if
this.state = 42;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 39;
;}if (true) break;

case 39:
//C
this.state = 42;
parent._logme._logit2 /*String*/ (ba,"did change --- NO!!!!!!!!!!",parent._mmodule,_insub);
if (true) break;

case 42:
//C
this.state = 43;
;
 if (true) break;

case 43:
//C
this.state = 44;
;
 if (true) break;

case 44:
//C
this.state = 45;
;
 //BA.debugLineNum = 494;BA.debugLine="FilesCheckChangeIsBusyFLAG = False";
parent._filescheckchangeisbusyflag = parent.__c.False;
 //BA.debugLineNum = 497;BA.debugLine="Dim ttlRecsInDB As Int = Main.db.GetTotalRecs";
_ttlrecsindb = parent._main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._gettotalrecs /*int*/ ();
 //BA.debugLineNum = 498;BA.debugLine="If oldListViewSize <> clvFiles.Size And ttlRecsIn";
if (true) break;

case 45:
//if
this.state = 48;
if (_oldlistviewsize!=parent._clvfiles._getsize() && _ttlrecsindb>0) { 
this.state = 47;
}if (true) break;

case 47:
//C
this.state = 48;
 //BA.debugLineNum = 500;BA.debugLine="Sleep(100) : Show1stFile";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 55;
return;
case 55:
//C
this.state = 48;
;
 //BA.debugLineNum = 500;BA.debugLine="Sleep(100) : Show1stFile";
parent._show1stfile();
 if (true) break;
;
 //BA.debugLineNum = 503;BA.debugLine="If ttlRecsInDB = 0 Then SetThumbnail2Nothing";

case 48:
//if
this.state = 53;
if (_ttlrecsindb==0) { 
this.state = 50;
;}if (true) break;

case 50:
//C
this.state = 53;
parent._setthumbnail2nothing();
if (true) break;

case 53:
//C
this.state = -1;
;
 //BA.debugLineNum = 505;BA.debugLine="Update_Printer_Btns";
parent._update_printer_btns();
 //BA.debugLineNum = 506;BA.debugLine="Return Null";
if (true) {
parent.__c.ReturnFromResumableSub(this,parent.__c.Null);return;};
 //BA.debugLineNum = 508;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"pageFiles\" 'ig";
_mmodule = "pageFiles";
 //BA.debugLineNum = 8;BA.debugLine="Private mPnlMain As B4XView";
_mpnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private mCallBackEvent As String 'ignore";
_mcallbackevent = "";
 //BA.debugLineNum = 10;BA.debugLine="Private mMainObj As B4XMainPage'ignore";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 11;BA.debugLine="Private DisplayedFileName As String '--- curently";
_displayedfilename = "";
 //BA.debugLineNum = 13;BA.debugLine="Private CSelections As sadClvSelections";
_cselections = new sadLogic.OctoTouchController.foss.sadclvselections();
 //BA.debugLineNum = 14;BA.debugLine="Private Const NO_SELECTION As Int = -1";
_no_selection = (int) (-1);
 //BA.debugLineNum = 15;BA.debugLine="Private clvLastIndexClicked As Int = NO_SELECTION";
_clvlastindexclicked = _no_selection;
 //BA.debugLineNum = 17;BA.debugLine="Private clvFiles As CustomListView";
_clvfiles = new b4a.example3.customlistview();
 //BA.debugLineNum = 18;BA.debugLine="Private ivPreview As lmB4XImageViewX";
_ivpreview = new sadLogic.OctoTouchController.foss.lmb4ximageviewx();
 //BA.debugLineNum = 19;BA.debugLine="Private btnDelete, btnLoad, btnLoadAndPrint As Bu";
_btndelete = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnload = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnloadandprint = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private mCurrentFileInfo As tOctoFileInfo";
_mcurrentfileinfo = new sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo();
 //BA.debugLineNum = 21;BA.debugLine="Private pnlPortraitDivide As B4XView";
_pnlportraitdivide = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private lblpnlFileViewTop,lblpnlFileViewBottom As";
_lblpnlfileviewtop = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblpnlfileviewbottom = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private pnlFileViewBG As B4XView";
_pnlfileviewbg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private FilesCheckChangeIsBusyFLAG As Boolean = F";
_filescheckchangeisbusyflag = __c.False;
 //BA.debugLineNum = 28;BA.debugLine="Private firstRun As Boolean = True";
_firstrun = __c.True;
 //BA.debugLineNum = 30;BA.debugLine="Private lblFileName As AutoTextSizeLabel, lblHead";
_lblfilename = new sadLogic.OctoTouchController.foss.autotextsizelabel();
_lblheaderfilename = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private lblBusy As B4XView";
_lblbusy = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private mOldFileName As String";
_moldfilename = "";
 //BA.debugLineNum = 35;BA.debugLine="Private lblSort2 As Label, cboSort As B4XComboBox";
_lblsort2 = new anywheresoftware.b4a.objects.LabelWrapper();
_cbosort = new sadLogic.OctoTouchController.foss.b4xcombobox();
_rsfiles = new anywheresoftware.b4a.sql.SQL.ResultSetWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private SortAscDesc As Boolean = True";
_sortascdesc = __c.True;
 //BA.debugLineNum = 37;BA.debugLine="Private LastSort As String";
_lastsort = "";
 //BA.debugLineNum = 39;BA.debugLine="Public FileEvent As Boolean = False";
_fileevent = __c.False;
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public void  _clvfiles_itemclick(int _index,Object _value) throws Exception{
ResumableSub_clvFiles_ItemClick rsub = new ResumableSub_clvFiles_ItemClick(this,_index,_value);
rsub.resume(ba, null);
}
public static class ResumableSub_clvFiles_ItemClick extends BA.ResumableSub {
public ResumableSub_clvFiles_ItemClick(sadLogic.OctoTouchController.foss.pagefiles parent,int _index,Object _value) {
this.parent = parent;
this._index = _index;
this._value = _value;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
int _index;
Object _value;
Object _i = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 360;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 363;BA.debugLine="If Value = Null Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_value== null) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 364;BA.debugLine="clvLastIndexClicked = NO_SELECTION";
parent._clvlastindexclicked = parent._no_selection;
 //BA.debugLineNum = 365;BA.debugLine="SetThumbnail2Nothing";
parent._setthumbnail2nothing();
 //BA.debugLineNum = 369;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 372;BA.debugLine="CSelections.ItemClicked(Index)";
parent._cselections._itemclicked /*String*/ (_index);
 //BA.debugLineNum = 373;BA.debugLine="clvLastIndexClicked = Index";
parent._clvlastindexclicked = _index;
 //BA.debugLineNum = 374;BA.debugLine="mCurrentFileInfo =  mMainObj.oMasterController.gM";
parent._mcurrentfileinfo = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get(_value));
 //BA.debugLineNum = 376;BA.debugLine="If mCurrentFileInfo.myThumbnail_filename_disk = \"";
if (true) break;

case 5:
//if
this.state = 8;
if ((parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ ).equals("")) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 377;BA.debugLine="SetThumbnail2Nothing";
parent._setthumbnail2nothing();
 //BA.debugLineNum = 381;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 384;BA.debugLine="If File.Exists(xui.DefaultFolder,mCurrentFileInfo";

case 8:
//if
this.state = 26;
if (parent.__c.File.Exists(parent._xui.getDefaultFolder(),parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ )==parent.__c.False) { 
this.state = 10;
}else {
this.state = 25;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 386;BA.debugLine="SetThumbnail2Nothing";
parent._setthumbnail2nothing();
 //BA.debugLineNum = 388;BA.debugLine="If mMainObj.oPageCurrent = mMainObj.oPageFiles T";
if (true) break;

case 11:
//if
this.state = 14;
if ((parent._mmainobj._opagecurrent /*Object*/ ).equals((Object)(parent._mmainobj._opagefiles /*sadLogic.OctoTouchController.foss.pagefiles*/ ))) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 389;BA.debugLine="guiHelpers.Show_toast(gblConst.THUMBNAIL_LOADIN";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._thumbnail_loading /*String*/ ,(int) (1000));
 if (true) break;
;
 //BA.debugLineNum = 393;BA.debugLine="If config.logFILE_EVENTS Then";

case 14:
//if
this.state = 17;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 16;
}if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 394;BA.debugLine="logMe.LogIt(\"downloading missing thumbnail file";
parent._logme._logit /*String*/ (ba,"downloading missing thumbnail file; "+parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ ,parent._mmodule);
 if (true) break;

case 17:
//C
this.state = 18;
;
 //BA.debugLineNum = 397;BA.debugLine="Wait For (mMainObj.oMasterController.cn.Download";
parent.__c.WaitFor("complete", ba, this, parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._download_andsavefile /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+"/")+parent._mcurrentfileinfo.Thumbnail /*String*/ ,parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ ));
this.state = 27;
return;
case 27:
//C
this.state = 18;
_i = (Object) result[0];
;
 //BA.debugLineNum = 403;BA.debugLine="If File.Exists(xui.DefaultFolder,mCurrentFileInf";
if (true) break;

case 18:
//if
this.state = 23;
if (parent.__c.File.Exists(parent._xui.getDefaultFolder(),parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ )==parent.__c.False) { 
this.state = 20;
}else {
this.state = 22;
}if (true) break;

case 20:
//C
this.state = 23;
 //BA.debugLineNum = 404;BA.debugLine="SetThumbnail2Nothing";
parent._setthumbnail2nothing();
 if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 406;BA.debugLine="ivPreview.Load(xui.DefaultFolder,mCurrentFileIn";
parent._ivpreview._load /*String*/ (parent._xui.getDefaultFolder(),parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ );
 if (true) break;

case 23:
//C
this.state = 26;
;
 if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 410;BA.debugLine="ivPreview.Load(xui.DefaultFolder,mCurrentFileInf";
parent._ivpreview._load /*String*/ (parent._xui.getDefaultFolder(),parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ );
 if (true) break;

case 26:
//C
this.state = -1;
;
 //BA.debugLineNum = 418;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createlistitem(sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _odata,int _width,int _height) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
 //BA.debugLineNum = 326;BA.debugLine="Private Sub CreateListItem(oData As tOctoFileInfo,";
 //BA.debugLineNum = 328;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 330;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, Width, Height + IIf(";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,(int) (_height+(double)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >7.8) ? ((Object)(__c.DipToCurrent((int) (20)))) : ((Object)(__c.DipToCurrent((int) (0)))))))));
 //BA.debugLineNum = 331;BA.debugLine="p.LoadLayout(\"viewFiles\")";
_p.LoadLayout("viewFiles",ba);
 //BA.debugLineNum = 333;BA.debugLine="lblpnlFileViewTop.TextColor = clrTheme.txtNormal";
_lblpnlfileviewtop.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 334;BA.debugLine="lblpnlFileViewTop.font = xui.CreateDefaultFont( _";
_lblpnlfileviewtop.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_lblpnlfileviewtop.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 337;BA.debugLine="lblpnlFileViewTop.Text = fileHelpers.RemoveExtFro";
_lblpnlfileviewtop.setText(BA.ObjectToCharSequence(_filehelpers._removeextfromefilename /*String*/ (ba,_odata.Name /*String*/ )));
 //BA.debugLineNum = 339;BA.debugLine="lblpnlFileViewBottom.TextColor = clrTheme.txtAcce";
_lblpnlfileviewbottom.setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 340;BA.debugLine="lblpnlFileViewBottom.Font = lblpnlFileViewTop.Fon";
_lblpnlfileviewbottom.setFont(_lblpnlfileviewtop.getFont());
 //BA.debugLineNum = 344;BA.debugLine="lblpnlFileViewBottom.Text = \"Size: \" &  fileHelpe";
_lblpnlfileviewbottom.setText(BA.ObjectToCharSequence("Size: "+_filehelpers._bytestoreadablestring /*String*/ (ba,_odata.Size /*String*/ )+("  "+__c.SmartStringFormatter("",(Object)((BA.NumberToString(_odata.Length /*double*/ ))))+"m / "+__c.SmartStringFormatter("",(Object)((BA.NumberToString(_odata.Volume /*double*/ ))))+"³")));
 //BA.debugLineNum = 348;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 350;BA.debugLine="End Sub";
return null;
}
public int  _dimcolor(int _clr) throws Exception{
int[] _argb = null;
 //BA.debugLineNum = 321;BA.debugLine="Private Sub DimColor(clr As Int) As Int";
 //BA.debugLineNum = 322;BA.debugLine="Dim argb() As Int = clrTheme.Int2ARGB(clr)";
_argb = _clrtheme._int2argb /*int[]*/ (ba,_clr);
 //BA.debugLineNum = 323;BA.debugLine="Return xui.Color_ARGB(18,argb(1),argb(2),argb(3))";
if (true) return _xui.Color_ARGB((int) (18),_argb[(int) (1)],_argb[(int) (2)],_argb[(int) (3)]);
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return 0;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _filescheckchange(boolean _force) throws Exception{
ResumableSub_FilesCheckChange rsub = new ResumableSub_FilesCheckChange(this,_force);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_FilesCheckChange extends BA.ResumableSub {
public ResumableSub_FilesCheckChange(sadLogic.OctoTouchController.foss.pagefiles parent,boolean _force) {
this.parent = parent;
this._force = _force;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
boolean _force;
Object _i = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 120;BA.debugLine="Log(\"FilesCheckChange\")";
parent.__c.LogImpl("42860545","FilesCheckChange",0);
 //BA.debugLineNum = 122;BA.debugLine="If mPnlMain.Visible = False Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._mpnlmain.getVisible()==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 125;BA.debugLine="Return 'ignore";
if (true) {
parent.__c.ReturnFromResumableSub(this,null);return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 128;BA.debugLine="Wait For (CheckIfFilesChanged) Complete (i As Obj";
parent.__c.WaitFor("complete", ba, this, parent._checkiffileschanged());
this.state = 17;
return;
case 17:
//C
this.state = 5;
_i = (Object) result[0];
;
 //BA.debugLineNum = 130;BA.debugLine="If (oc.JobFileName.Length = 0 And lblFileName.Tex";
if (true) break;

case 5:
//if
this.state = 8;
if ((parent._oc._jobfilename /*String*/ .length()==0 && (parent._lblfilename._gettext /*Object*/ ()).equals((Object)(parent._gblconst._no_file_loaded /*String*/ )) == false) || (parent._oc._jobfilename /*String*/ .length()!=0 && (parent._lblfilename._gettext /*Object*/ ()).equals((Object)(parent._gblconst._no_file_loaded /*String*/ ))) || ((parent._displayedfilename).equals(parent._oc._jobfilename /*String*/ ) == false)) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 133;BA.debugLine="Update_LoadedFileName2Scrn";
parent._update_loadedfilename2scrn();
 if (true) break;

case 8:
//C
this.state = 9;
;
 //BA.debugLineNum = 136;BA.debugLine="DisplayedFileName = oc.JobFileName";
parent._displayedfilename = parent._oc._jobfilename /*String*/ ;
 //BA.debugLineNum = 138;BA.debugLine="If mMainObj.oMasterController.IsIncompleteFileDat";
if (true) break;

case 9:
//if
this.state = 16;
if (parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._isincompletefiledata /*boolean*/ () || _force) { 
this.state = 11;
}if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 139;BA.debugLine="Log(\"---------> setting refresh for incomplete f";
parent.__c.LogImpl("42860564","---------> setting refresh for incomplete files",0);
 //BA.debugLineNum = 140;BA.debugLine="If Main.tmrTimerCallSub.Exists(Me,\"Build_ListVie";
if (true) break;

case 12:
//if
this.state = 15;
if (parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._exists /*anywheresoftware.b4a.objects.Timer*/ (parent,"Build_ListViewFileList_keep")== null) { 
this.state = 14;
}if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 141;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Bui";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Build_ListViewFileList_keep",(int) (6000));
 if (true) break;

case 15:
//C
this.state = 16;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _getfilesortorder() throws Exception{
 //BA.debugLineNum = 256;BA.debugLine="Private Sub GetFileSortOrder() As String 'ignore";
 //BA.debugLineNum = 257;BA.debugLine="Select Case cboSort.SelectedItem.ToLowerCase";
switch (BA.switchObjectToInt(_cbosort._getselecteditem /*String*/ ().toLowerCase(),"file name","date added")) {
case 0: {
 //BA.debugLineNum = 258;BA.debugLine="Case \"file name\" 	: Return \"file_name\"";
if (true) return "file_name";
 break; }
case 1: {
 //BA.debugLineNum = 259;BA.debugLine="Case \"date added\" 	: Return \"date_added\"";
if (true) return "date_added";
 break; }
}
;
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _masterpanel,String _callbackevent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Public Sub Initialize(masterPanel As B4XView,callB";
 //BA.debugLineNum = 45;BA.debugLine="mPnlMain = masterPanel";
_mpnlmain = _masterpanel;
 //BA.debugLineNum = 46;BA.debugLine="mCallBackEvent = callBackEvent";
_mcallbackevent = _callbackevent;
 //BA.debugLineNum = 47;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 49;BA.debugLine="mPnlMain.SetLayoutAnimated(0,0,masterPanel.top,ma";
_mpnlmain.SetLayoutAnimated((int) (0),(int) (0),_masterpanel.getTop(),_masterpanel.getWidth(),_masterpanel.getHeight());
 //BA.debugLineNum = 50;BA.debugLine="mPnlMain.LoadLayout(\"pageFiles\")";
_mpnlmain.LoadLayout("pageFiles",ba);
 //BA.debugLineNum = 52;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public String  _lblsort_click() throws Exception{
 //BA.debugLineNum = 694;BA.debugLine="Private Sub lblSort_Click";
 //BA.debugLineNum = 696;BA.debugLine="cboSort_SelectedIndexChanged(cboSort.SelectedInde";
_cbosort_selectedindexchanged(_cbosort._getselectedindex /*int*/ ());
 //BA.debugLineNum = 697;BA.debugLine="End Sub";
return "";
}
public String  _lblsort2_click() throws Exception{
 //BA.debugLineNum = 703;BA.debugLine="Private Sub lblSort2_Click";
 //BA.debugLineNum = 705;BA.debugLine="cboSort_SelectedIndexChanged(cboSort.SelectedInde";
_cbosort_selectedindexchanged(_cbosort._getselectedindex /*int*/ ());
 //BA.debugLineNum = 706;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="public Sub Lost_focus()";
 //BA.debugLineNum = 89;BA.debugLine="mPnlMain.SetVisibleAnimated(500,False)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 91;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _processnewoldthumbnails(anywheresoftware.b4a.objects.collections.Map _newmap) throws Exception{
String _insub = "";
int _deletedfiles = 0;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _oldmap = null;
String _oldmapkey = "";
int _changedfiles = 0;
int _newfiles = 0;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _onewmap = null;
String _mapkey = "";
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _fffiletoworkon = null;
 //BA.debugLineNum = 511;BA.debugLine="Private Sub ProcessNewOldThumbnails(NewMap As Map)";
 //BA.debugLineNum = 513;BA.debugLine="Dim InSub As String = \"ProcessNewOldThumbnails\"";
_insub = "ProcessNewOldThumbnails";
 //BA.debugLineNum = 514;BA.debugLine="Try";
try { //BA.debugLineNum = 517;BA.debugLine="Dim deletedFiles As Int = 0";
_deletedfiles = (int) (0);
 //BA.debugLineNum = 518;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt(\"Proce";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit /*String*/ (ba,"ProcessThumbnails - start - remove any old thumbnail files",_mmodule);};
 //BA.debugLineNum = 520;BA.debugLine="For Each oldMap As tOctoFileInfo In mMainObj.oMa";
{
final anywheresoftware.b4a.BA.IterableList group5 = _mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Values();
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_oldmap = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(group5.Get(index5));
 //BA.debugLineNum = 522;BA.debugLine="Dim oldMapKey As String = oldMap.Name";
_oldmapkey = _oldmap.Name /*String*/ ;
 //BA.debugLineNum = 523;BA.debugLine="If NewMap.ContainsKey(oldMapKey) = False Then";
if (_newmap.ContainsKey((Object)(_oldmapkey))==__c.False) { 
 //BA.debugLineNum = 525;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt(\"del";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit /*String*/ (ba,"deleted old thumbnail: "+_oldmap.myThumbnail_filename_disk /*String*/ ,_mmodule);};
 //BA.debugLineNum = 527;BA.debugLine="fileHelpers.SafeKill(oldMap.myThumbnail_filena";
_filehelpers._safekill /*String*/ (ba,_oldmap.myThumbnail_filename_disk /*String*/ );
 //BA.debugLineNum = 528;BA.debugLine="LogColor(\"del --> \" & oldMap.myThumbnail_filen";
__c.LogImpl("43581457","del --> "+_oldmap.myThumbnail_filename_disk /*String*/ ,__c.Colors.Yellow);
 //BA.debugLineNum = 529;BA.debugLine="deletedFiles = deletedFiles + 1";
_deletedfiles = (int) (_deletedfiles+1);
 };
 }
};
 } 
       catch (Exception e15) {
			ba.setLastException(e15); //BA.debugLineNum = 536;BA.debugLine="logMe.LogIt2(LastException,mModule,InSub)";
_logme._logit2 /*String*/ (ba,BA.ObjectToString(__c.LastException(ba)),_mmodule,_insub);
 };
 //BA.debugLineNum = 539;BA.debugLine="If config.logFILE_EVENTS Then";
if (_config._logfile_events /*boolean*/ ) { 
 //BA.debugLineNum = 540;BA.debugLine="logMe.LogIt2(\"END - remove any old thumbnail fil";
_logme._logit2 /*String*/ (ba,"END - remove any old thumbnail files: #"+BA.NumberToString(_deletedfiles),_mmodule,_insub);
 //BA.debugLineNum = 541;BA.debugLine="logMe.LogIt2(\"START - download new thumbnails fo";
_logme._logit2 /*String*/ (ba,"START - download new thumbnails for new and changed files",_mmodule,_insub);
 };
 //BA.debugLineNum = 544;BA.debugLine="Try";
try { //BA.debugLineNum = 546;BA.debugLine="Dim changedFiles = 0, NewFiles = 0 As Int";
_changedfiles = (int) (0);
_newfiles = (int) (0);
 //BA.debugLineNum = 549;BA.debugLine="For Each oNewMap As tOctoFileInfo In NewMap.Valu";
{
final anywheresoftware.b4a.BA.IterableList group23 = _newmap.Values();
final int groupLen23 = group23.getSize()
;int index23 = 0;
;
for (; index23 < groupLen23;index23++){
_onewmap = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(group23.Get(index23));
 //BA.debugLineNum = 551;BA.debugLine="Dim mapKey As String = oNewMap.Name";
_mapkey = _onewmap.Name /*String*/ ;
 //BA.debugLineNum = 552;BA.debugLine="If mMainObj.oMasterController.gMapOctoFilesList";
if (_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .ContainsKey((Object)(_mapkey))==__c.True) { 
 //BA.debugLineNum = 555;BA.debugLine="Dim ffFileToWorkOn As tOctoFileInfo = mMainObj";
_fffiletoworkon = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_mapkey)));
 //BA.debugLineNum = 556;BA.debugLine="If ffFileToWorkOn.Date <> oNewMap.Date Then '-";
if ((_fffiletoworkon.Date /*String*/ ).equals(_onewmap.Date /*String*/ ) == false) { 
 //BA.debugLineNum = 558;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"r";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit2 /*String*/ (ba,"refreshing old thumbnail: "+_onewmap.Name /*String*/ ,_mmodule,_insub);};
 //BA.debugLineNum = 559;BA.debugLine="fileHelpers.SafeKill(ffFileToWorkOn.myThumbna";
_filehelpers._safekill /*String*/ (ba,_fffiletoworkon.myThumbnail_filename_disk /*String*/ );
 //BA.debugLineNum = 560;BA.debugLine="changedFiles = changedFiles + 1";
_changedfiles = (int) (_changedfiles+1);
 //BA.debugLineNum = 561;BA.debugLine="mMainObj.oMasterController.Download_Thumbnail";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._download_thumbnailandcache2file /*String*/ (_onewmap.Thumbnail /*String*/ ,_onewmap.myThumbnail_filename_disk /*String*/ );
 };
 }else {
 //BA.debugLineNum = 568;BA.debugLine="NewFiles = NewFiles + 1";
_newfiles = (int) (_newfiles+1);
 //BA.debugLineNum = 569;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"do";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit2 /*String*/ (ba,"downloading new thumbnail; "+_onewmap.Name /*String*/ ,_mmodule,_insub);};
 //BA.debugLineNum = 571;BA.debugLine="mMainObj.oMasterController.Download_ThumbnailA";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._download_thumbnailandcache2file /*String*/ (_onewmap.Thumbnail /*String*/ ,_onewmap.myThumbnail_filename_disk /*String*/ );
 };
 }
};
 } 
       catch (Exception e40) {
			ba.setLastException(e40); //BA.debugLineNum = 578;BA.debugLine="logMe.LogIt2(LastException,mModule,InSub)";
_logme._logit2 /*String*/ (ba,BA.ObjectToString(__c.LastException(ba)),_mmodule,_insub);
 };
 //BA.debugLineNum = 581;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"files";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit2 /*String*/ (ba,"files changed #"+BA.NumberToString(_changedfiles)+"   files new #"+BA.NumberToString(_newfiles),_mmodule,_insub);};
 //BA.debugLineNum = 583;BA.debugLine="End Sub";
return "";
}
public void  _senddeletecmdandremovefromgrid() throws Exception{
ResumableSub_SendDeleteCmdAndRemoveFromGrid rsub = new ResumableSub_SendDeleteCmdAndRemoveFromGrid(this);
rsub.resume(ba, null);
}
public static class ResumableSub_SendDeleteCmdAndRemoveFromGrid extends BA.ResumableSub {
public ResumableSub_SendDeleteCmdAndRemoveFromGrid(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _ff = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 591;BA.debugLine="mMainObj.oMasterController.cn.DeleteRequest(oc.cD";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._deleterequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cdelete_files_delete /*String*/ .replace("!LOC!",parent._mcurrentfileinfo.Origin /*String*/ ).replace("!PATH!",parent._mcurrentfileinfo.Name /*String*/ ));
 //BA.debugLineNum = 596;BA.debugLine="guiHelpers.Show_toast(\"Deleting File\",1200)";
parent._guihelpers._show_toast /*String*/ (ba,"Deleting File",(int) (1200));
 //BA.debugLineNum = 599;BA.debugLine="fileHelpers.SafeKill(mCurrentFileInfo.myThumbnail";
parent._filehelpers._safekill /*String*/ (ba,parent._mcurrentfileinfo.myThumbnail_filename_disk /*String*/ );
 //BA.debugLineNum = 602;BA.debugLine="clvFiles.RemoveAt(clvLastIndexClicked)";
parent._clvfiles._removeat(parent._clvlastindexclicked);
 //BA.debugLineNum = 603;BA.debugLine="CSelections.SelectedItems.Remove(clvLastIndexClic";
parent._cselections._selecteditems /*sadLogic.OctoTouchController.foss.b4xset*/ ._remove /*String*/ ((Object)(parent._clvlastindexclicked));
 //BA.debugLineNum = 604;BA.debugLine="mMainObj.oMasterController.gMapOctoFilesList.Remo";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Remove((Object)(parent._mcurrentfileinfo.Name /*String*/ ));
 //BA.debugLineNum = 605;BA.debugLine="Main.db.DeleteFileRec(mCurrentFileInfo.Name)";
parent._main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._deletefilerec /*String*/ (parent._mcurrentfileinfo.Name /*String*/ );
 //BA.debugLineNum = 606;BA.debugLine="Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 13;
return;
case 13:
//C
this.state = 1;
;
 //BA.debugLineNum = 608;BA.debugLine="Dim ff As tOctoFileInfo";
_ff = new sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo();
 //BA.debugLineNum = 610;BA.debugLine="If clvFiles.Size > 1 Then";
if (true) break;

case 1:
//if
this.state = 12;
if (parent._clvfiles._getsize()>1) { 
this.state = 3;
}else if(parent._clvfiles._getsize()==1) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 611;BA.debugLine="If clvLastIndexClicked <> 0 Then";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._clvlastindexclicked!=0) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 612;BA.debugLine="clvLastIndexClicked = clvLastIndexClicked - 1";
parent._clvlastindexclicked = (int) (parent._clvlastindexclicked-1);
 if (true) break;

case 7:
//C
this.state = 12;
;
 //BA.debugLineNum = 614;BA.debugLine="ff = mMainObj.oMasterController.gMapOctoFilesLis";
_ff = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get(parent._clvfiles._getvalue(parent._clvlastindexclicked)));
 //BA.debugLineNum = 615;BA.debugLine="clvFiles_ItemClick(clvLastIndexClicked,ff.name)";
parent._clvfiles_itemclick(parent._clvlastindexclicked,(Object)(_ff.Name /*String*/ ));
 if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 617;BA.debugLine="clvLastIndexClicked = 0";
parent._clvlastindexclicked = (int) (0);
 //BA.debugLineNum = 618;BA.debugLine="ff = mMainObj.oMasterController.gMapOctoFilesLis";
_ff = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get(parent._clvfiles._getvalue(parent._clvlastindexclicked)));
 //BA.debugLineNum = 619;BA.debugLine="clvFiles_ItemClick(clvLastIndexClicked,ff.name)";
parent._clvfiles_itemclick(parent._clvlastindexclicked,(Object)(_ff.Name /*String*/ ));
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 621;BA.debugLine="clvFiles_ItemClick(0,Null)";
parent._clvfiles_itemclick((int) (0),parent.__c.Null);
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 624;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 14;
return;
case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 625;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tmrM";
parent.__c.CallSubNew(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 626;BA.debugLine="Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 15;
return;
case 15:
//C
this.state = -1;
;
 //BA.debugLineNum = 627;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Updat";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Update_LoadedFileName2Scrn",(int) (500));
 //BA.debugLineNum = 629;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _set_focus() throws Exception{
ResumableSub_Set_focus rsub = new ResumableSub_Set_focus(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Set_focus extends BA.ResumableSub {
public ResumableSub_Set_focus(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;
Object _i = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 58;BA.debugLine="mPnlMain.SetVisibleAnimated(500,True)";
parent._mpnlmain.SetVisibleAnimated((int) (500),parent.__c.True);
 //BA.debugLineNum = 59;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
parent._mpnlmain.setEnabled(parent._oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 60;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(firstR";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._logme._logit2 /*String*/ (ba,BA.ObjectToString(parent._firstrun),parent._mmodule,"Set_focus");
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 61;BA.debugLine="Update_LoadedFileName2Scrn";
parent._update_loadedfilename2scrn();
 //BA.debugLineNum = 62;BA.debugLine="DisplayedFileName = oc.JobFileName";
parent._displayedfilename = parent._oc._jobfilename /*String*/ ;
 //BA.debugLineNum = 63;BA.debugLine="Update_Printer_Btns";
parent._update_printer_btns();
 //BA.debugLineNum = 64;BA.debugLine="Wait For (FilesCheckChange(True)) Complete (i As";
parent.__c.WaitFor("complete", ba, this, parent._filescheckchange(parent.__c.True));
this.state = 13;
return;
case 13:
//C
this.state = 7;
_i = (Object) result[0];
;
 //BA.debugLineNum = 66;BA.debugLine="If firstRun = True Then '--- 1st showing of tab p";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._firstrun==parent.__c.True) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 70;BA.debugLine="Show1stFile";
parent._show1stfile();
 //BA.debugLineNum = 74;BA.debugLine="firstRun = False";
parent._firstrun = parent.__c.False;
 if (true) break;

case 11:
//C
this.state = 12;
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _setthumbnail2nothing() throws Exception{
 //BA.debugLineNum = 353;BA.debugLine="Private Sub SetThumbnail2Nothing";
 //BA.debugLineNum = 354;BA.debugLine="ivPreview.Load(File.DirAssets,gblConst.NO_THUMBNA";
_ivpreview._load /*String*/ (__c.File.getDirAssets(),_gblconst._no_thumbnail /*String*/ );
 //BA.debugLineNum = 355;BA.debugLine="End Sub";
return "";
}
public void  _show1stfile() throws Exception{
ResumableSub_Show1stFile rsub = new ResumableSub_Show1stFile(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show1stFile extends BA.ResumableSub {
public ResumableSub_Show1stFile(sadLogic.OctoTouchController.foss.pagefiles parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagefiles parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 663;BA.debugLine="If Main.db.GetTotalRecs = 0 Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._main._db /*sadLogic.OctoTouchController.foss.inmemdb*/ ._gettotalrecs /*int*/ ()==0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 664;BA.debugLine="rsFiles.Position = 0";
parent._rsfiles.setPosition((int) (0));
 //BA.debugLineNum = 665;BA.debugLine="clvFiles_ItemClick(0,rsFiles.GetString(\"file_name";
parent._clvfiles_itemclick((int) (0),(Object)(parent._rsfiles.GetString("file_name")));
 //BA.debugLineNum = 666;BA.debugLine="clvFiles.JumpToItem(0)";
parent._clvfiles._jumptoitem((int) (0));
 //BA.debugLineNum = 667;BA.debugLine="Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 668;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _update_loadedfilename2scrn() throws Exception{
 //BA.debugLineNum = 632;BA.debugLine="Public Sub Update_LoadedFileName2Scrn";
 //BA.debugLineNum = 635;BA.debugLine="If mCurrentFileInfo = Null Then Return";
if (_mcurrentfileinfo== null) { 
if (true) return "";};
 //BA.debugLineNum = 636;BA.debugLine="If mOldFileName = fileHelpers.RemoveExtFromeFileN";
if ((_moldfilename).equals(_filehelpers._removeextfromefilename /*String*/ (ba,_mcurrentfileinfo.Name /*String*/ ))) { 
 //BA.debugLineNum = 637;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 640;BA.debugLine="Try";
try { //BA.debugLineNum = 648;BA.debugLine="If oc.isFileLoaded Then";
if (_oc._isfileloaded /*boolean*/ ) { 
 //BA.debugLineNum = 649;BA.debugLine="lblFileName.Text = fileHelpers.RemoveExtFromeFi";
_lblfilename._settext /*Object*/ ((Object)(_filehelpers._removeextfromefilename /*String*/ (ba,_oc._jobfilename /*String*/ )));
 }else {
 //BA.debugLineNum = 651;BA.debugLine="lblFileName.Text = gblConst.NO_FILE_LOADED";
_lblfilename._settext /*Object*/ ((Object)(_gblconst._no_file_loaded /*String*/ ));
 };
 } 
       catch (Exception e12) {
			ba.setLastException(e12); //BA.debugLineNum = 655;BA.debugLine="Log(LastException)";
__c.LogImpl("43712535",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 658;BA.debugLine="mOldFileName = lblFileName.Text";
_moldfilename = BA.ObjectToString(_lblfilename._gettext /*Object*/ ());
 //BA.debugLineNum = 660;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_btns() throws Exception{
boolean _enabledisable = false;
 //BA.debugLineNum = 98;BA.debugLine="public Sub Update_Printer_Btns";
 //BA.debugLineNum = 108;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
_mpnlmain.setEnabled(_oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 112;BA.debugLine="Dim enableDisable As Boolean  = Not (oc.isCanceli";
_enabledisable = __c.Not(_oc._iscanceling /*boolean*/  || _oc._isprinting /*boolean*/  || _oc._ispaused2 /*boolean*/  || (_clvlastindexclicked==_no_selection));
 //BA.debugLineNum = 115;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(btn";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnload,_btnloadandprint,_btndelete},_enabledisable);
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_LISTVIEWFILELIST_KEEP"))
	return _build_listviewfilelist_keep();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "UPDATE_LOADEDFILENAME2SCRN"))
	return _update_loadedfilename2scrn();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_BTNS"))
	return _update_printer_btns();
return BA.SubDelegator.SubNotFound;
}
}
