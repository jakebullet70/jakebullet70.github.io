package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgthemedmsgbox extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgthemedmsgbox");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgthemedmsgbox.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 13;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 14;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 15;BA.debugLine="Private dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 20;BA.debugLine="dlg = B4XPages.MainPage.DialogMSGBOX";
_dlg = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._dialogmsgbox /*sadLogic.HomeCentral.b4xdialog*/ ;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _show(String _msgtext,String _title,String _yesbtn,String _nobtn,String _cancelbtn) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_msgtext,_title,_yesbtn,_nobtn,_cancelbtn);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgthemedmsgbox parent,String _msgtext,String _title,String _yesbtn,String _nobtn,String _cancelbtn) {
this.parent = parent;
this._msgtext = _msgtext;
this._title = _title;
this._yesbtn = _yesbtn;
this._nobtn = _nobtn;
this._cancelbtn = _cancelbtn;
}
sadLogic.HomeCentral.dlgthemedmsgbox parent;
String _msgtext;
String _title;
String _yesbtn;
String _nobtn;
String _cancelbtn;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 29;BA.debugLine="Wait For (Show2(msgText,title,yesBtn,noBtn,cancel";
parent.__c.WaitFor("complete", ba, this, parent._show2(_msgtext,_title,_yesbtn,_nobtn,_cancelbtn,(int) (0)));
this.state = 1;
return;
case 1:
//C
this.state = -1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 30;BA.debugLine="Return i";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_i));return;};
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _show2(String _msgtext,String _title,String _yesbtn,String _nobtn,String _cancelbtn,int _icon) throws Exception{
ResumableSub_Show2 rsub = new ResumableSub_Show2(this,_msgtext,_title,_yesbtn,_nobtn,_cancelbtn,_icon);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Show2 extends BA.ResumableSub {
public ResumableSub_Show2(sadLogic.HomeCentral.dlgthemedmsgbox parent,String _msgtext,String _title,String _yesbtn,String _nobtn,String _cancelbtn,int _icon) {
this.parent = parent;
this._msgtext = _msgtext;
this._title = _title;
this._yesbtn = _yesbtn;
this._nobtn = _nobtn;
this._cancelbtn = _cancelbtn;
this._icon = _icon;
}
sadLogic.HomeCentral.dlgthemedmsgbox parent;
String _msgtext;
String _title;
String _yesbtn;
String _nobtn;
String _cancelbtn;
int _icon;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 51;BA.debugLine="dlg.Initialize(B4XPages.MainPage.Root)";
parent._dlg._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 52;BA.debugLine="dlgHelper.Initialize(dlg)";
parent._dlghelper._initialize /*String*/ (ba,parent._dlg);
 //BA.debugLineNum = 54;BA.debugLine="dlgHelper.ThemeDialogForm( title)";
parent._dlghelper._themedialogform /*String*/ ((Object)(_title));
 //BA.debugLineNum = 55;BA.debugLine="Dim rs As ResumableSub = dlg.Show(msgText, yesBtn";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dlg._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_msgtext),(Object)(_yesbtn),(Object)(_nobtn),(Object)(_cancelbtn));
 //BA.debugLineNum = 56;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
parent._dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 59;BA.debugLine="Wait For (rs) Complete (i As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 60;BA.debugLine="Return i";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_i));return;};
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _showok(String _msgtext,String _title) throws Exception{
ResumableSub_ShowOK rsub = new ResumableSub_ShowOK(this,_msgtext,_title);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ShowOK extends BA.ResumableSub {
public ResumableSub_ShowOK(sadLogic.HomeCentral.dlgthemedmsgbox parent,String _msgtext,String _title) {
this.parent = parent;
this._msgtext = _msgtext;
this._title = _title;
}
sadLogic.HomeCentral.dlgthemedmsgbox parent;
String _msgtext;
String _title;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 37;BA.debugLine="Wait For (Show2(msgText,title,\"OK\",\"\",\"\",0)) Comp";
parent.__c.WaitFor("complete", ba, this, parent._show2(_msgtext,_title,"OK","","",(int) (0)));
this.state = 1;
return;
case 1:
//C
this.state = -1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 38;BA.debugLine="Return i";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_i));return;};
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
