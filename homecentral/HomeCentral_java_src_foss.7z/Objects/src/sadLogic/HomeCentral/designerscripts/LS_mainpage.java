package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainpage{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbg").vw.setLeft((int)(0d));
views.get("pnlbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbg").vw.setTop((int)(0d));
views.get("pnlbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlheader").vw.setLeft((int)(0d));
views.get("pnlheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnltimers").vw.setLeft((int)(0d));
views.get("pnltimers").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnltimers").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnltimers").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlphotos").vw.setLeft((int)(0d));
views.get("pnlphotos").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 16;BA.debugLine="pnlPhotos.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlphotos").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlphotos").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 18;BA.debugLine="pnlHome.SetLeftAndRight(0,100%x)"[MainPage/General script]
views.get("pnlhome").vw.setLeft((int)(0d));
views.get("pnlhome").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 19;BA.debugLine="pnlHome.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlhome").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlhome").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 21;BA.debugLine="pnlWeather.SetLeftAndRight(0,100%x)"[MainPage/General script]
views.get("pnlweather").vw.setLeft((int)(0d));
views.get("pnlweather").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 22;BA.debugLine="pnlWeather.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlweather").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlweather").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 24;BA.debugLine="pnlCalculator.SetLeftAndRight(0,100%x)"[MainPage/General script]
views.get("pnlcalculator").vw.setLeft((int)(0d));
views.get("pnlcalculator").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 25;BA.debugLine="pnlCalculator.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlcalculator").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlcalculator").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 27;BA.debugLine="pnlConversions.SetLeftAndRight(0,100%x)"[MainPage/General script]
views.get("pnlconversions").vw.setLeft((int)(0d));
views.get("pnlconversions").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 28;BA.debugLine="pnlConversions.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlconversions").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlconversions").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 30;BA.debugLine="pnlWEB.SetLeftAndRight(0,100%x)"[MainPage/General script]
views.get("pnlweb").vw.setLeft((int)(0d));
views.get("pnlweb").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 31;BA.debugLine="pnlWEB.SetTopAndBottom(pnlHeader.Bottom,100%y)"[MainPage/General script]
views.get("pnlweb").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlweb").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 34;BA.debugLine="pnlSideMenu.SetTopAndBottom(pnlHeader.Bottom.Top,pnlBG.Bottom)"[MainPage/General script]
views.get("pnlsidemenu").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlsidemenu").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
//BA.debugLineNum = 40;BA.debugLine="pnlMenuFooter.SetLeftAndRight(0,pnlSideMenu.Width)"[MainPage/General script]
views.get("pnlmenufooter").vw.setLeft((int)(0d));
views.get("pnlmenufooter").vw.setWidth((int)((views.get("pnlsidemenu").vw.getWidth()) - (0d)));
//BA.debugLineNum = 41;BA.debugLine="btnSetupMaster.Right =pnlMenuFooter.Right"[MainPage/General script]
views.get("btnsetupmaster").vw.setLeft((int)((views.get("pnlmenufooter").vw.getLeft() + views.get("pnlmenufooter").vw.getWidth()) - (views.get("btnsetupmaster").vw.getWidth())));
//BA.debugLineNum = 42;BA.debugLine="btnAboutMe.SetLeftAndRight(0, btnSetupMaster.left)"[MainPage/General script]
views.get("btnaboutme").vw.setLeft((int)(0d));
views.get("btnaboutme").vw.setWidth((int)((views.get("btnsetupmaster").vw.getLeft()) - (0d)));
//BA.debugLineNum = 46;BA.debugLine="pnlSideMenuTouchOverlay.SetLeftAndRight(0,pnlHome.Width)"[MainPage/General script]
views.get("pnlsidemenutouchoverlay").vw.setLeft((int)(0d));
views.get("pnlsidemenutouchoverlay").vw.setWidth((int)((views.get("pnlhome").vw.getWidth()) - (0d)));
//BA.debugLineNum = 47;BA.debugLine="pnlSideMenuTouchOverlay.SetTopAndBottom(0,100%y)"[MainPage/General script]
views.get("pnlsidemenutouchoverlay").vw.setTop((int)(0d));
views.get("pnlsidemenutouchoverlay").vw.setHeight((int)((100d / 100 * height) - (0d)));

}
}