package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jsonparserfiles extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.jsonparserfiles");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.jsonparserfiles.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.collections.Map _gmapfiles = null;
public boolean _mdownloadthumbnails = false;
public int _cachetarget = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static class _toctofileinfo{
public boolean IsInitialized;
public String Name;
public String Size;
public String Date;
public String Thumbnail;
public String Origin;
public String Path;
public String Thumbnail_src;
public double Volume;
public double Length;
public double Depth;
public double Width;
public double Height;
public String myThumbnail_filename_disk;
public String Thumbnail_original;
public boolean missingData;
public String hash;
public double filament_total;
public String total_layers;
public void Initialize() {
IsInitialized = true;
Name = "";
Size = "";
Date = "";
Thumbnail = "";
Origin = "";
Path = "";
Thumbnail_src = "";
Volume = 0;
Length = 0;
Depth = 0;
Width = 0;
Height = 0;
myThumbnail_filename_disk = "";
Thumbnail_original = "";
missingData = false;
hash = "";
filament_total = 0;
total_layers = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public boolean  _checkifchanged(String _jsontxt,anywheresoftware.b4a.objects.collections.Map _oldmap) throws Exception{
String _insub = "";
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
int _totalfiles = 0;
anywheresoftware.b4a.objects.collections.List _files = null;
String _filedate = "";
String _filename = "";
String _hash = "";
anywheresoftware.b4a.objects.collections.Map _colfiles = null;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _ff = null;
 //BA.debugLineNum = 49;BA.debugLine="Public Sub CheckIfChanged(jsonTXT As String,oldMap";
 //BA.debugLineNum = 58;BA.debugLine="Dim InSub As String = \"CheckIfChanged\"";
_insub = "CheckIfChanged";
 //BA.debugLineNum = 59;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 60;BA.debugLine="parser.Initialize(jsonTXT)";
_parser.Initialize(_jsontxt);
 //BA.debugLineNum = 61;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 62;BA.debugLine="Dim totalFiles As Int = 0";
_totalfiles = (int) (0);
 //BA.debugLineNum = 102;BA.debugLine="Dim files As List = root.Get(\"files\")";
_files = new anywheresoftware.b4a.objects.collections.List();
_files = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_root.Get((Object)("files"))));
 //BA.debugLineNum = 103;BA.debugLine="Dim fileDate As String, fileName As String, hash";
_filedate = "";
_filename = "";
_hash = "";
 //BA.debugLineNum = 105;BA.debugLine="For Each colfiles As Map In files";
_colfiles = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group8 = _files;
final int groupLen8 = group8.getSize()
;int index8 = 0;
;
for (; index8 < groupLen8;index8++){
_colfiles = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group8.Get(index8)));
 //BA.debugLineNum = 106;BA.debugLine="Try";
try { //BA.debugLineNum = 107;BA.debugLine="If colfiles.Get(\"type\") = \"folder\" Then";
if ((_colfiles.Get((Object)("type"))).equals((Object)("folder"))) { 
 //BA.debugLineNum = 110;BA.debugLine="Continue";
if (true) continue;
 };
 //BA.debugLineNum = 113;BA.debugLine="fileDate = colfiles.Get(\"date\")";
_filedate = BA.ObjectToString(_colfiles.Get((Object)("date")));
 //BA.debugLineNum = 114;BA.debugLine="fileName =  colfiles.Get(\"display\")";
_filename = BA.ObjectToString(_colfiles.Get((Object)("display")));
 //BA.debugLineNum = 115;BA.debugLine="hash = colfiles.Get(\"hash\")";
_hash = BA.ObjectToString(_colfiles.Get((Object)("hash")));
 } 
       catch (Exception e17) {
			ba.setLastException(e17); //BA.debugLineNum = 118;BA.debugLine="logMe.LogIt2(\"ParseComp00: \",mModule,InSub)";
_logme._logit2 /*String*/ (getActivityBA(),"ParseComp00: ",_mmodule,_insub);
 };
 //BA.debugLineNum = 123;BA.debugLine="Dim ff As tOctoFileInfo";
_ff = new sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo();
 //BA.debugLineNum = 124;BA.debugLine="ff = oldMap.Get(fileName)";
_ff = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(_oldmap.Get((Object)(_filename)));
 //BA.debugLineNum = 126;BA.debugLine="If ff = Null Then";
if (_ff== null) { 
 //BA.debugLineNum = 128;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"fil";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit2 /*String*/ (getActivityBA(),"file added",_mmodule,_insub);};
 //BA.debugLineNum = 129;BA.debugLine="Return True '--- bail out, something changed";
if (true) return __c.True;
 }else {
 //BA.debugLineNum = 132;BA.debugLine="If ((hash <> \"\") And ff.hash <> hash) Or ff.Dat";
if ((((_hash).equals("") == false) && (_ff.hash /*String*/ ).equals(_hash) == false) || (_ff.Date /*String*/ ).equals(_filedate) == false) { 
 //BA.debugLineNum = 134;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"sa";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit2 /*String*/ (getActivityBA(),"same file name, new hash/date",_mmodule,_insub);};
 //BA.debugLineNum = 135;BA.debugLine="Return True '--- bail out, something changed";
if (true) return __c.True;
 };
 };
 //BA.debugLineNum = 139;BA.debugLine="totalFiles = totalFiles + 1";
_totalfiles = (int) (_totalfiles+1);
 }
};
 //BA.debugLineNum = 144;BA.debugLine="If oldMap.Size <> totalFiles Then";
if (_oldmap.getSize()!=_totalfiles) { 
 //BA.debugLineNum = 145;BA.debugLine="Log(\"files have been removed or added\")";
__c.LogImpl("34078816","files have been removed or added",0);
 //BA.debugLineNum = 146;BA.debugLine="Return True '--- files have been removed, tell t";
if (true) return __c.True;
 }else {
 //BA.debugLineNum = 148;BA.debugLine="Return False '--- nothing has changed, all good!";
if (true) return __c.False;
 };
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return false;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"JsonParserFile";
_mmodule = "JsonParserFiles";
 //BA.debugLineNum = 10;BA.debugLine="Public gMapFiles As Map";
_gmapfiles = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 12;BA.debugLine="Type tOctoFileInfo(Name As String, Size As String";
;
 //BA.debugLineNum = 18;BA.debugLine="Private mDownloadThumbnails As Boolean 'ignore";
_mdownloadthumbnails = false;
 //BA.debugLineNum = 19;BA.debugLine="Public CacheTarget As Int = 4";
_cachetarget = (int) (4);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public double  _getlength(String _v) throws Exception{
 //BA.debugLineNum = 444;BA.debugLine="Private Sub GetLength(v As String) As Double 'igno";
 //BA.debugLineNum = 445;BA.debugLine="Try";
try { //BA.debugLineNum = 446;BA.debugLine="If (v <> Null And v <> \"null\" And v <> 0) Then";
if ((_v!= null && (_v).equals("null") == false && (_v).equals(BA.NumberToString(0)) == false)) { 
 //BA.debugLineNum = 447;BA.debugLine="Return Round2(v.As(Double) * .001,2)";
if (true) return __c.Round2(((double)(Double.parseDouble(_v)))*.001,(int) (2));
 };
 } 
       catch (Exception e6) {
			ba.setLastException(e6); };
 //BA.debugLineNum = 453;BA.debugLine="Return 0";
if (true) return 0;
 //BA.debugLineNum = 454;BA.debugLine="End Sub";
return 0;
}
public double  _getvolume(String _v) throws Exception{
 //BA.debugLineNum = 456;BA.debugLine="Private Sub GetVolume(v As String) As Double 'igno";
 //BA.debugLineNum = 457;BA.debugLine="Try";
try { //BA.debugLineNum = 458;BA.debugLine="If (v <> Null And v <> \"null\" And v <> 0) Then";
if ((_v!= null && (_v).equals("null") == false && (_v).equals(BA.NumberToString(0)) == false)) { 
 //BA.debugLineNum = 459;BA.debugLine="Return Round2(v.As(Double),2)";
if (true) return __c.Round2(((double)(Double.parseDouble(_v))),(int) (2));
 };
 } 
       catch (Exception e6) {
			ba.setLastException(e6); };
 //BA.debugLineNum = 465;BA.debugLine="Return 0";
if (true) return 0;
 //BA.debugLineNum = 466;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,boolean _downloadthumbnails) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 26;BA.debugLine="Public Sub Initialize(DownloadThumbnails As Boolea";
 //BA.debugLineNum = 27;BA.debugLine="mDownloadThumbnails = DownloadThumbnails";
_mdownloadthumbnails = _downloadthumbnails;
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _parseocto(String _jsontxt) throws Exception{
String _insub = "";
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.List _files = null;
int _cachettl = 0;
int _missingdata = 0;
anywheresoftware.b4a.objects.collections.Map _colfiles = null;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _ff = null;
anywheresoftware.b4a.objects.collections.Map _gcodeanalysis = null;
anywheresoftware.b4a.objects.collections.Map _filament = null;
anywheresoftware.b4a.objects.collections.Map _tool0 = null;
anywheresoftware.b4a.objects.collections.Map _dimensions = null;
 //BA.debugLineNum = 206;BA.debugLine="Private Sub ParseOcto(jsonTXT As String)";
 //BA.debugLineNum = 211;BA.debugLine="Dim InSub As String = \"Parse\"";
_insub = "Parse";
 //BA.debugLineNum = 212;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 213;BA.debugLine="parser.Initialize(jsonTXT)";
_parser.Initialize(_jsontxt);
 //BA.debugLineNum = 214;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 216;BA.debugLine="Dim files As List = root.Get(\"files\")";
_files = new anywheresoftware.b4a.objects.collections.List();
_files = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_root.Get((Object)("files"))));
 //BA.debugLineNum = 218;BA.debugLine="Dim cacheTTL As Int = 0";
_cachettl = (int) (0);
 //BA.debugLineNum = 219;BA.debugLine="Dim missingData As Int = 0";
_missingdata = (int) (0);
 //BA.debugLineNum = 221;BA.debugLine="For Each colfiles As Map In files";
_colfiles = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group8 = _files;
final int groupLen8 = group8.getSize()
;int index8 = 0;
;
for (; index8 < groupLen8;index8++){
_colfiles = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group8.Get(index8)));
 //BA.debugLineNum = 223;BA.debugLine="Dim ff As tOctoFileInfo";
_ff = new sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo();
 //BA.debugLineNum = 225;BA.debugLine="Try";
try { //BA.debugLineNum = 227;BA.debugLine="If colfiles.Get(\"type\") = \"folder\" Then";
if ((_colfiles.Get((Object)("type"))).equals((Object)("folder"))) { 
 //BA.debugLineNum = 228;BA.debugLine="Continue '--- its a folder";
if (true) continue;
 };
 //BA.debugLineNum = 231;BA.debugLine="Try";
try { //BA.debugLineNum = 232;BA.debugLine="ff.Date = colfiles.Get(\"date\")";
_ff.Date /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("date")));
 } 
       catch (Exception e17) {
			ba.setLastException(e17); //BA.debugLineNum = 234;BA.debugLine="logMe.LogIt2(\"Parse00: \" & LastException,mModu";
_logme._logit2 /*String*/ (getActivityBA(),"Parse00: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 236;BA.debugLine="Try";
try { //BA.debugLineNum = 237;BA.debugLine="ff.Thumbnail = colfiles.Get(\"thumbnail\")";
_ff.Thumbnail /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("thumbnail")));
 //BA.debugLineNum = 238;BA.debugLine="ff.Thumbnail_original = ff.Thumbnail '--- has";
_ff.Thumbnail_original /*String*/  = _ff.Thumbnail /*String*/ ;
 } 
       catch (Exception e23) {
			ba.setLastException(e23); //BA.debugLineNum = 240;BA.debugLine="logMe.LogIt2(\"Parse03: \" & LastException,mModu";
_logme._logit2 /*String*/ (getActivityBA(),"Parse03: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 242;BA.debugLine="Try";
try { //BA.debugLineNum = 243;BA.debugLine="ff.Name = colfiles.Get(\"display\")";
_ff.Name /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("display")));
 } 
       catch (Exception e28) {
			ba.setLastException(e28); //BA.debugLineNum = 245;BA.debugLine="logMe.LogIt2(\"Parse04: \" & LastException,mModu";
_logme._logit2 /*String*/ (getActivityBA(),"Parse04: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 247;BA.debugLine="Try";
try { //BA.debugLineNum = 248;BA.debugLine="ff.origin = colfiles.Get(\"origin\")";
_ff.Origin /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("origin")));
 } 
       catch (Exception e33) {
			ba.setLastException(e33); //BA.debugLineNum = 250;BA.debugLine="logMe.LogIt2(\"Parse05: \" & LastException,mModu";
_logme._logit2 /*String*/ (getActivityBA(),"Parse05: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 254;BA.debugLine="Try";
try { //BA.debugLineNum = 255;BA.debugLine="If ff.Thumbnail.Length <> 0 And ff.Thumbnail <";
if (_ff.Thumbnail /*String*/ .length()!=0 && (_ff.Thumbnail /*String*/ ).equals("null") == false) { 
 //BA.debugLineNum = 256;BA.debugLine="ff.Thumbnail =  ff.Thumbnail.SubString2(0,ff.";
_ff.Thumbnail /*String*/  = _ff.Thumbnail /*String*/ .substring((int) (0),_ff.Thumbnail /*String*/ .indexOf("?"));
 //BA.debugLineNum = 257;BA.debugLine="ff.myThumbnail_filename_disk = fnc.BuildThumb";
_ff.myThumbnail_filename_disk /*String*/  = _fnc._buildthumbnailtempfilename /*String*/ (getActivityBA(),_fnc._getfilenamefromhttp /*String*/ (getActivityBA(),_ff.Thumbnail /*String*/ ));
 }else {
 //BA.debugLineNum = 259;BA.debugLine="ff.Thumbnail = \"\"";
_ff.Thumbnail /*String*/  = "";
 //BA.debugLineNum = 260;BA.debugLine="ff.myThumbnail_filename_disk = \"\"";
_ff.myThumbnail_filename_disk /*String*/  = "";
 };
 } 
       catch (Exception e44) {
			ba.setLastException(e44); //BA.debugLineNum = 263;BA.debugLine="logMe.LogIt2(\"ParseFile 3: \" & LastException,m";
_logme._logit2 /*String*/ (getActivityBA(),"ParseFile 3: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 //BA.debugLineNum = 264;BA.debugLine="ff.Thumbnail = \"\"";
_ff.Thumbnail /*String*/  = "";
 //BA.debugLineNum = 265;BA.debugLine="ff.myThumbnail_filename_disk = \"\"";
_ff.myThumbnail_filename_disk /*String*/  = "";
 };
 //BA.debugLineNum = 273;BA.debugLine="Try";
try { //BA.debugLineNum = 274;BA.debugLine="ff.hash = colfiles.Get(\"hash\")";
_ff.hash /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("hash")));
 } 
       catch (Exception e51) {
			ba.setLastException(e51); //BA.debugLineNum = 276;BA.debugLine="logMe.LogIt2(\"Parse09x: \" & LastException,mMod";
_logme._logit2 /*String*/ (getActivityBA(),"Parse09x: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 278;BA.debugLine="Try";
try { //BA.debugLineNum = 279;BA.debugLine="ff.Size = colfiles.Get(\"size\")";
_ff.Size /*String*/  = BA.ObjectToString(_colfiles.Get((Object)("size")));
 } 
       catch (Exception e56) {
			ba.setLastException(e56); //BA.debugLineNum = 281;BA.debugLine="logMe.LogIt2(\"Parse00y: \" & LastException,mMod";
_logme._logit2 /*String*/ (getActivityBA(),"Parse00y: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 284;BA.debugLine="Try                                          'g";
try { //BA.debugLineNum = 286;BA.debugLine="Dim gcodeAnalysis As Map = colfiles.Get(\"gcode";
_gcodeanalysis = new anywheresoftware.b4a.objects.collections.Map();
_gcodeanalysis = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_colfiles.Get((Object)("gcodeAnalysis"))));
 //BA.debugLineNum = 288;BA.debugLine="Dim filament As Map = gcodeAnalysis.Get(\"filam";
_filament = new anywheresoftware.b4a.objects.collections.Map();
_filament = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_gcodeanalysis.Get((Object)("filament"))));
 //BA.debugLineNum = 289;BA.debugLine="Dim tool0 As Map = filament.Get(\"tool0\")";
_tool0 = new anywheresoftware.b4a.objects.collections.Map();
_tool0 = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_filament.Get((Object)("tool0"))));
 //BA.debugLineNum = 290;BA.debugLine="ff.Volume = GetVolume(tool0.Get(\"volume\"))";
_ff.Volume /*double*/  = _getvolume(BA.ObjectToString(_tool0.Get((Object)("volume"))));
 //BA.debugLineNum = 291;BA.debugLine="ff.Length = GetLength(tool0.Get(\"length\")) ' *";
_ff.Length /*double*/  = _getlength(BA.ObjectToString(_tool0.Get((Object)("length"))));
 //BA.debugLineNum = 293;BA.debugLine="Dim dimensions As Map = gcodeAnalysis.Get(\"dim";
_dimensions = new anywheresoftware.b4a.objects.collections.Map();
_dimensions = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_gcodeanalysis.Get((Object)("dimensions"))));
 //BA.debugLineNum = 294;BA.debugLine="ff.Depth = dimensions.Get(\"depth\")";
_ff.Depth /*double*/  = (double)(BA.ObjectToNumber(_dimensions.Get((Object)("depth"))));
 //BA.debugLineNum = 295;BA.debugLine="ff.Width = dimensions.Get(\"width\")";
_ff.Width /*double*/  = (double)(BA.ObjectToNumber(_dimensions.Get((Object)("width"))));
 //BA.debugLineNum = 296;BA.debugLine="ff.Height = dimensions.Get(\"height\")";
_ff.Height /*double*/  = (double)(BA.ObjectToNumber(_dimensions.Get((Object)("height"))));
 } 
       catch (Exception e69) {
			ba.setLastException(e69); //BA.debugLineNum = 300;BA.debugLine="ff.missingData = True";
_ff.missingData /*boolean*/  = __c.True;
 //BA.debugLineNum = 301;BA.debugLine="logMe.LogIt2(\"ParseFile-missingData=True\",mMod";
_logme._logit2 /*String*/ (getActivityBA(),"ParseFile-missingData=True",_mmodule,_insub);
 //BA.debugLineNum = 302;BA.debugLine="missingData = missingData + 1";
_missingdata = (int) (_missingdata+1);
 //BA.debugLineNum = 303;BA.debugLine="If missingData > 3 Then";
if (_missingdata>3) { 
 //BA.debugLineNum = 304;BA.debugLine="guiHelpers.Show_toast2(\"Octoprint Analyzing G";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),"Octoprint Analyzing GCode",(int) (800));
 };
 };
 } 
       catch (Exception e77) {
			ba.setLastException(e77); //BA.debugLineNum = 311;BA.debugLine="logMe.LogIt2(\"ParseFile 2: \" & LastException,mM";
_logme._logit2 /*String*/ (getActivityBA(),"ParseFile 2: "+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 314;BA.debugLine="If mDownloadThumbnails And (ff.Thumbnail.Length";
if (_mdownloadthumbnails && (_ff.Thumbnail /*String*/ .length()!=0 && (_ff.Thumbnail /*String*/ ).equals("null") == false) && _cachettl<_cachetarget) { 
 //BA.debugLineNum = 319;BA.debugLine="cacheTTL = cacheTTL + 1";
_cachettl = (int) (_cachettl+1);
 //BA.debugLineNum = 320;BA.debugLine="CallSub3(B4XPages.MainPage.oMasterController,\"D";
__c.CallSubNew3(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"Download_ThumbnailAndCache2File",(Object)(_ff.Thumbnail /*String*/ ),(Object)(_ff.myThumbnail_filename_disk /*String*/ ));
 };
 //BA.debugLineNum = 325;BA.debugLine="gMapFiles.Put(ff.Name,ff)";
_gmapfiles.Put((Object)(_ff.Name /*String*/ ),(Object)(_ff));
 }
};
 //BA.debugLineNum = 336;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _startparseallfilesocto(String _jsontxt) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Public Sub StartParseAllFilesOcto(jsonTXT As Strin";
 //BA.debugLineNum = 38;BA.debugLine="gMapFiles.Initialize";
_gmapfiles.Initialize();
 //BA.debugLineNum = 39;BA.debugLine="ParseOcto(jsonTXT)";
_parseocto(_jsontxt);
 //BA.debugLineNum = 40;BA.debugLine="Return gMapFiles";
if (true) return _gmapfiles;
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
