package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clskalarms extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.clskalarms");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.clskalarms.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public sadLogic.HomeCentral.kt._typtimers[] _mtimers = null;
public anywheresoftware.b4a.objects.Timer _mtmralarmfire = null;
public anywheresoftware.b4a.audio.Beeper _bpr = null;
public anywheresoftware.b4a.objects.MediaPlayerWrapper[] _mmediaplayer = null;
public anywheresoftware.b4a.phone.Phone _ph = null;
public boolean _mbactive = false;
public int _mpoldvol = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _alarmsoundplay(String _sfile,int _alarmnum) throws Exception{
int _vol = 0;
 //BA.debugLineNum = 119;BA.debugLine="Public Sub AlarmSoundPlay(sfile As String,alarmNum";
 //BA.debugLineNum = 120;BA.debugLine="Try";
try { //BA.debugLineNum = 121;BA.debugLine="Dim vol As Int = Main.kvs.Get(gblConst.INI_TIMER";
_vol = (int) ((double)(BA.ObjectToNumber(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_timers_alarm_volume /*String*/ )))*(double)(Double.parseDouble(("0."+BA.NumberToString(_ph.GetMaxVolume(_ph.VOLUME_MUSIC))))));
 //BA.debugLineNum = 122;BA.debugLine="mpOldVol = ph.GetVolume(ph.VOLUME_MUSIC) '--- sa";
_mpoldvol = _ph.GetVolume(_ph.VOLUME_MUSIC);
 //BA.debugLineNum = 123;BA.debugLine="ph.SetVolume(ph.VOLUME_MUSIC, vol, False)";
_ph.SetVolume(_ph.VOLUME_MUSIC,_vol,__c.False);
 //BA.debugLineNum = 124;BA.debugLine="mMediaPlayer(alarmNum).Initialize";
_mmediaplayer[_alarmnum].Initialize();
 //BA.debugLineNum = 125;BA.debugLine="mMediaPlayer(alarmNum).Load(File.DirAssets,sfile";
_mmediaplayer[_alarmnum].Load(__c.File.getDirAssets(),_sfile);
 //BA.debugLineNum = 126;BA.debugLine="mMediaPlayer(alarmNum).Looping = True";
_mmediaplayer[_alarmnum].setLooping(__c.True);
 //BA.debugLineNum = 127;BA.debugLine="mMediaPlayer(alarmNum).Play";
_mmediaplayer[_alarmnum].Play();
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 129;BA.debugLine="guiHelpers.Show_toast2(gblConst.VOLUME_ERR,4500)";
_guihelpers._show_toast2 /*String*/ (ba,_gblconst._volume_err /*String*/ ,(int) (4500));
 //BA.debugLineNum = 130;BA.debugLine="Log(LastException)";
__c.LogImpl("10485771",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return "";
}
public String  _alarmsoundstop(int _alarmnum) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Public Sub AlarmSoundStop(alarmNum As Int)";
 //BA.debugLineNum = 106;BA.debugLine="Try";
try { //BA.debugLineNum = 107;BA.debugLine="If mpage.DebugLog Then Log(\"AlarmSoundStop (alar";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10420227","AlarmSoundStop (alarmNum As Int)-->"+BA.NumberToString(_alarmnum),0);};
 //BA.debugLineNum = 108;BA.debugLine="mMediaPlayer(alarmNum).Stop";
_mmediaplayer[_alarmnum].Stop();
 //BA.debugLineNum = 109;BA.debugLine="mMediaPlayer(alarmNum).Release";
_mmediaplayer[_alarmnum].Release();
 //BA.debugLineNum = 110;BA.debugLine="ph.SetVolume(ph.VOLUME_MUSIC, mpOldVol, False)	'";
_ph.SetVolume(_ph.VOLUME_MUSIC,_mpoldvol,__c.False);
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 112;BA.debugLine="guiHelpers.Show_toast2(gblConst.VOLUME_ERR,4500)";
_guihelpers._show_toast2 /*String*/ (ba,_gblconst._volume_err /*String*/ ,(int) (4500));
 //BA.debugLineNum = 113;BA.debugLine="Log(LastException)";
__c.LogImpl("10420233",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
return "";
}
public String  _alarmstart(int _alarmnum) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Public Sub AlarmStart(alarmNum As Int)";
 //BA.debugLineNum = 52;BA.debugLine="mbActive = True";
_mbactive = __c.True;
 //BA.debugLineNum = 53;BA.debugLine="CallSub(mpage,\"Alarm_Fired_Before_Start\")";
__c.CallSubNew(ba,(Object)(_mpage),"Alarm_Fired_Before_Start");
 //BA.debugLineNum = 64;BA.debugLine="If mTimers(alarmNum).alarmType.beepMe Then";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .beepMe /*boolean*/ ) { 
 //BA.debugLineNum = 65;BA.debugLine="If mpage.DebugLog Then Log(\"AlarmFired-beepMe\")";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10223636","AlarmFired-beepMe",0);};
 //BA.debugLineNum = 66;BA.debugLine="InitBeeper";
_initbeeper();
 //BA.debugLineNum = 67;BA.debugLine="mTmrAlarmFire.Initialize(\"tmrBeep\",700)";
_mtmralarmfire.Initialize(ba,"tmrBeep",(long) (700));
 //BA.debugLineNum = 68;BA.debugLine="mTmrAlarmFire.Enabled = True";
_mtmralarmfire.setEnabled(__c.True);
 };
 //BA.debugLineNum = 71;BA.debugLine="If mTimers(alarmNum).alarmType.playFile Then";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .playFile /*boolean*/ ) { 
 //BA.debugLineNum = 72;BA.debugLine="If mpage.DebugLog Then Log(\"AlarmFired-playFile\"";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10223643","AlarmFired-playFile",0);};
 //BA.debugLineNum = 73;BA.debugLine="mMediaPlayer(alarmNum).Initialize2(\"mp\")";
_mmediaplayer[_alarmnum].Initialize2(ba,"mp");
 //BA.debugLineNum = 74;BA.debugLine="AlarmSoundPlay(Main.kvs.Get(gblConst.INI_TIMERS_";
_alarmsoundplay(BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_timers_alarm_file /*String*/ )),_alarmnum);
 };
 //BA.debugLineNum = 81;BA.debugLine="If mTimers(alarmNum).alarmType.ShowScreenBig Then";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .ShowScreenBig /*boolean*/ ) { 
 //BA.debugLineNum = 82;BA.debugLine="If mpage.DebugLog Then Log(\"AlarmFired-ShowScree";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10223653","AlarmFired-ShowScreenBig",0);};
 };
 //BA.debugLineNum = 85;BA.debugLine="If mTimers(alarmNum).alarmType.ShowScreenSmall Th";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .ShowScreenSmall /*boolean*/ ) { 
 //BA.debugLineNum = 86;BA.debugLine="If mpage.DebugLog Then Log(\"AlarmFired-ShowScree";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10223657","AlarmFired-ShowScreenSmall",0);};
 //BA.debugLineNum = 87;BA.debugLine="guiHelpers.Show_toast(\"Alarm #\" & alarmNum & \" H";
_guihelpers._show_toast /*String*/ (ba,"Alarm #"+BA.NumberToString(_alarmnum)+" Has fired: "+_mtimers[_alarmnum].txt /*String*/ );
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _alarmstop(int _alarmnum) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Public Sub AlarmStop(alarmNum As Int)";
 //BA.debugLineNum = 30;BA.debugLine="mbActive = False";
_mbactive = __c.False;
 //BA.debugLineNum = 31;BA.debugLine="If mTimers(alarmNum).alarmType.beepMe Then";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .beepMe /*boolean*/ ) { 
 //BA.debugLineNum = 32;BA.debugLine="mTmrAlarmFire.Enabled = False";
_mtmralarmfire.setEnabled(__c.False);
 //BA.debugLineNum = 33;BA.debugLine="bpr.Release";
_bpr.Release();
 };
 //BA.debugLineNum = 36;BA.debugLine="If mTimers(alarmNum).alarmType.playFile Then";
if (_mtimers[_alarmnum].alarmType /*sadLogic.HomeCentral.kt._typalarmtypes*/ .playFile /*boolean*/ ) { 
 //BA.debugLineNum = 37;BA.debugLine="AlarmSoundStop(alarmNum)";
_alarmsoundstop(_alarmnum);
 };
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 9;BA.debugLine="Private mTimers() As typTimers";
_mtimers = new sadLogic.HomeCentral.kt._typtimers[(int) (0)];
{
int d0 = _mtimers.length;
for (int i0 = 0;i0 < d0;i0++) {
_mtimers[i0] = new sadLogic.HomeCentral.kt._typtimers();
}
}
;
 //BA.debugLineNum = 10;BA.debugLine="Private mTmrAlarmFire As Timer";
_mtmralarmfire = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 11;BA.debugLine="Private bpr As Beeper";
_bpr = new anywheresoftware.b4a.audio.Beeper();
 //BA.debugLineNum = 12;BA.debugLine="Private mMediaPlayer(6) As MediaPlayer";
_mmediaplayer = new anywheresoftware.b4a.objects.MediaPlayerWrapper[(int) (6)];
{
int d0 = _mmediaplayer.length;
for (int i0 = 0;i0 < d0;i0++) {
_mmediaplayer[i0] = new anywheresoftware.b4a.objects.MediaPlayerWrapper();
}
}
;
 //BA.debugLineNum = 13;BA.debugLine="Private ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 15;BA.debugLine="Public mbActive As Boolean";
_mbactive = false;
 //BA.debugLineNum = 17;BA.debugLine="Private mpOldVol As Int";
_mpoldvol = 0;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initbeeper() throws Exception{
 //BA.debugLineNum = 99;BA.debugLine="Private Sub InitBeeper";
 //BA.debugLineNum = 100;BA.debugLine="bpr.Initialize(300,1000)";
_bpr.Initialize((int) (300),(int) (1000));
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.kt._typtimers[] _otimers) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize(oTimers() As typTimers)";
 //BA.debugLineNum = 24;BA.debugLine="mTimers = oTimers";
_mtimers = _otimers;
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public String  _tmrbeep_tick() throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Private Sub tmrBeep_Tick";
 //BA.debugLineNum = 93;BA.debugLine="bpr.Release";
_bpr.Release();
 //BA.debugLineNum = 94;BA.debugLine="InitBeeper";
_initbeeper();
 //BA.debugLineNum = 95;BA.debugLine="bpr.beep";
_bpr.Beep();
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
