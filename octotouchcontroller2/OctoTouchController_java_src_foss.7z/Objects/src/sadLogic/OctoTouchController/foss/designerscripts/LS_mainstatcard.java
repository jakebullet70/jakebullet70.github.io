package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainstatcard{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padlbltopbtm="";
String _padimagesides="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("mnucard2").vw.setLeft((int)(0d));
views.get("mnucard2").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("mnucard2").vw.setTop((int)(0d));
views.get("mnucard2").vw.setHeight((int)((100d / 100 * height) - (0d)));
_padlbltopbtm = BA.NumberToString((1d * scale));
views.get("lbltexttop").vw.setTop((int)(Double.parseDouble(_padlbltopbtm)));
views.get("lbltexttop").vw.setHeight((int)((22d / 100 * height)-Double.parseDouble(_padlbltopbtm) - (Double.parseDouble(_padlbltopbtm))));
views.get("lbltextbottom").vw.setTop((int)((78d / 100 * height)+Double.parseDouble(_padlbltopbtm)));
views.get("lbltextbottom").vw.setHeight((int)((100d / 100 * height)-Double.parseDouble(_padlbltopbtm) - ((78d / 100 * height)+Double.parseDouble(_padlbltopbtm))));
views.get("lblactualtemp").vw.setTop((int)(0-(10d * scale)));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
_padimagesides = BA.NumberToString((30d * scale));
;}else{ 
;
_padimagesides = BA.NumberToString((44d * scale));
;};
views.get("mnucardimg").vw.setLeft((int)(Double.parseDouble(_padimagesides)));
views.get("mnucardimg").vw.setWidth((int)((views.get("mnucard2").vw.getWidth())-Double.parseDouble(_padimagesides) - (Double.parseDouble(_padimagesides))));
views.get("mnucardimg").vw.setTop((int)((views.get("lbltexttop").vw.getTop() + views.get("lbltexttop").vw.getHeight())+(7d * scale)));
views.get("mnucardimg").vw.setHeight((int)((views.get("lbltextbottom").vw.getTop())-(3d * scale) - ((views.get("lbltexttop").vw.getTop() + views.get("lbltexttop").vw.getHeight())+(7d * scale))));

}
}