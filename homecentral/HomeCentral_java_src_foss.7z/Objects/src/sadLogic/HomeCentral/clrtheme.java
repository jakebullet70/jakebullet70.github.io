package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clrtheme {
private static clrtheme mostCurrent = new clrtheme();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static String _mmodule = "";
public static sadLogic.HomeCentral.clrtheme._tthemecolors _customcolors = null;
public static int _background = 0;
public static int _backgroundheader = 0;
public static int _background2 = 0;
public static int _txtaccent = 0;
public static int _txtnormal = 0;
public static int _txtnormal2 = 0;
public static int _btndisabletext = 0;
public static int _dividercolor = 0;
public static int _itemsbackgroundcolor = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static class _tthemecolors{
public boolean IsInitialized;
public int bg;
public int bgheader;
public int bgmenu;
public int txtNormal;
public int txtacc;
public int disabled;
public int divider;
public void Initialize() {
IsInitialized = true;
bg = 0;
bgheader = 0;
bgmenu = 0;
txtNormal = 0;
txtacc = 0;
disabled = 0;
divider = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _colortohex(anywheresoftware.b4a.BA _ba,int _clr) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
 //BA.debugLineNum = 172;BA.debugLine="Public Sub ColorToHex(clr As Int) As String";
 //BA.debugLineNum = 173;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 174;BA.debugLine="Return bc.HexFromBytes(bc.IntsToBytes(Array As In";
if (true) return _bc.HexFromBytes(_bc.IntsToBytes(new int[]{_clr}));
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public static String  _colortohex4bblabel(anywheresoftware.b4a.BA _ba,int _clr) throws Exception{
 //BA.debugLineNum = 168;BA.debugLine="Public Sub ColorToHex4BBLabel(clr As Int) As Strin";
 //BA.debugLineNum = 169;BA.debugLine="Return \"0x\" & ColorToHex(clr)";
if (true) return "0x"+_colortohex(_ba,_clr);
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return "";
}
public static int  _hextocolor(anywheresoftware.b4a.BA _ba,String _hex) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
int[] _ints = null;
 //BA.debugLineNum = 177;BA.debugLine="Public Sub HexToColor(Hex As String) As Int 'ignor";
 //BA.debugLineNum = 178;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 179;BA.debugLine="If Hex.StartsWith(\"#\") Then";
if (_hex.startsWith("#")) { 
 //BA.debugLineNum = 180;BA.debugLine="Hex = Hex.SubString(1)";
_hex = _hex.substring((int) (1));
 }else if(_hex.startsWith("0x")) { 
 //BA.debugLineNum = 182;BA.debugLine="Hex = Hex.SubString(2)";
_hex = _hex.substring((int) (2));
 };
 //BA.debugLineNum = 184;BA.debugLine="Dim ints() As Int = bc.IntsFromBytes(bc.HexToByte";
_ints = _bc.IntsFromBytes(_bc.HexToBytes(_hex));
 //BA.debugLineNum = 185;BA.debugLine="Return ints(0)";
if (true) return _ints[(int) (0)];
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return 0;
}
public static String  _init(anywheresoftware.b4a.BA _ba,String _theme) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Public Sub Init(theme As String)";
 //BA.debugLineNum = 39;BA.debugLine="InitTheme(theme)";
_inittheme(_ba,_theme);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _inittheme(anywheresoftware.b4a.BA _ba,String _theme) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Public Sub InitTheme(theme As String)";
 //BA.debugLineNum = 45;BA.debugLine="txtNormal = xui.Color_white";
_txtnormal = _xui.Color_White;
 //BA.debugLineNum = 46;BA.debugLine="txtAccent = 0xFF74C8C8";
_txtaccent = ((int)0xff74c8c8);
 //BA.debugLineNum = 47;BA.debugLine="btnDisableText = xui.Color_LightGray";
_btndisabletext = _xui.Color_LightGray;
 //BA.debugLineNum = 48;BA.debugLine="DividerColor = xui.Color_LightGray";
_dividercolor = _xui.Color_LightGray;
 //BA.debugLineNum = 49;BA.debugLine="txtNormal2 = xui.Color_Yellow";
_txtnormal2 = _xui.Color_Yellow;
 //BA.debugLineNum = 51;BA.debugLine="theme = theme.ToLowerCase";
_theme = _theme.toLowerCase();
 //BA.debugLineNum = 52;BA.debugLine="Log(\"Init Theme: \" & theme)";
anywheresoftware.b4a.keywords.Common.LogImpl("8912905","Init Theme: "+_theme,0);
 //BA.debugLineNum = 54;BA.debugLine="Select Case theme";
switch (BA.switchObjectToInt(_theme,"rose","custom","red","green","gray","dark","dark-blue","dark-green","orange")) {
case 0: {
 //BA.debugLineNum = 57;BA.debugLine="Background = -7177863";
_background = (int) (-7177863);
 //BA.debugLineNum = 58;BA.debugLine="BackgroundHeader = -3054235";
_backgroundheader = (int) (-3054235);
 //BA.debugLineNum = 59;BA.debugLine="Background2 = -7576990";
_background2 = (int) (-7576990);
 //BA.debugLineNum = 60;BA.debugLine="txtNormal = -15461870";
_txtnormal = (int) (-15461870);
 //BA.debugLineNum = 61;BA.debugLine="txtAccent = -395787";
_txtaccent = (int) (-395787);
 //BA.debugLineNum = 62;BA.debugLine="btnDisableText = 1715811894";
_btndisabletext = (int) (1715811894);
 //BA.debugLineNum = 63;BA.debugLine="DividerColor = 0xFF696969";
_dividercolor = ((int)0xff696969);
 break; }
case 1: {
 //BA.debugLineNum = 67;BA.debugLine="Background = customcolors.bg";
_background = _customcolors.bg /*int*/ ;
 //BA.debugLineNum = 68;BA.debugLine="BackgroundHeader = customcolors.bgHeader";
_backgroundheader = _customcolors.bgheader /*int*/ ;
 //BA.debugLineNum = 69;BA.debugLine="Background2 = customcolors.bgMenu";
_background2 = _customcolors.bgmenu /*int*/ ;
 //BA.debugLineNum = 70;BA.debugLine="txtNormal = customcolors.txtNormal";
_txtnormal = _customcolors.txtNormal /*int*/ ;
 //BA.debugLineNum = 71;BA.debugLine="txtAccent = customcolors.txtAcc";
_txtaccent = _customcolors.txtacc /*int*/ ;
 //BA.debugLineNum = 72;BA.debugLine="btnDisableText = customcolors.Disabled";
_btndisabletext = _customcolors.disabled /*int*/ ;
 //BA.debugLineNum = 73;BA.debugLine="DividerColor = customcolors.Divider";
_dividercolor = _customcolors.divider /*int*/ ;
 break; }
case 2: {
 //BA.debugLineNum = 76;BA.debugLine="Background = xui.Color_ARGB(255,131, 21, 25)";
_background = _xui.Color_ARGB((int) (255),(int) (131),(int) (21),(int) (25));
 //BA.debugLineNum = 77;BA.debugLine="BackgroundHeader = -5239520";
_backgroundheader = (int) (-5239520);
 //BA.debugLineNum = 78;BA.debugLine="Background2 = xui.Color_ARGB(255,162, 30, 25)";
_background2 = _xui.Color_ARGB((int) (255),(int) (162),(int) (30),(int) (25));
 //BA.debugLineNum = 79;BA.debugLine="btnDisableText = 1006303994";
_btndisabletext = (int) (1006303994);
 //BA.debugLineNum = 80;BA.debugLine="txtAccent = -1803140";
_txtaccent = (int) (-1803140);
 //BA.debugLineNum = 81;BA.debugLine="DividerColor = 0xFFDC143C";
_dividercolor = ((int)0xffdc143c);
 break; }
case 3: {
 //BA.debugLineNum = 84;BA.debugLine="Background = xui.Color_ARGB(255,19, 62, 11)";
_background = _xui.Color_ARGB((int) (255),(int) (19),(int) (62),(int) (11));
 //BA.debugLineNum = 85;BA.debugLine="BackgroundHeader = -16310780";
_backgroundheader = (int) (-16310780);
 //BA.debugLineNum = 86;BA.debugLine="Background2 = xui.Color_ARGB(255,10, 53, 2)";
_background2 = _xui.Color_ARGB((int) (255),(int) (10),(int) (53),(int) (2));
 //BA.debugLineNum = 87;BA.debugLine="btnDisableText = 720959736";
_btndisabletext = (int) (720959736);
 //BA.debugLineNum = 88;BA.debugLine="DividerColor = txtAccent";
_dividercolor = _txtaccent;
 break; }
case 4: {
 //BA.debugLineNum = 91;BA.debugLine="Background = xui.Color_ARGB(255,90, 90, 90)";
_background = _xui.Color_ARGB((int) (255),(int) (90),(int) (90),(int) (90));
 //BA.debugLineNum = 92;BA.debugLine="BackgroundHeader =-13487823";
_backgroundheader = (int) (-13487823);
 //BA.debugLineNum = 93;BA.debugLine="Background2 = xui.Color_ARGB(255,60, 60, 60)";
_background2 = _xui.Color_ARGB((int) (255),(int) (60),(int) (60),(int) (60));
 //BA.debugLineNum = 94;BA.debugLine="DividerColor = xui.Color_LightGray";
_dividercolor = _xui.Color_LightGray;
 break; }
case 5: {
 //BA.debugLineNum = 97;BA.debugLine="Background = xui.Color_ARGB(255,2, 2, 2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 98;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 99;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 100;BA.debugLine="btnDisableText = 1404812219";
_btndisabletext = (int) (1404812219);
 //BA.debugLineNum = 101;BA.debugLine="DividerColor = xui.Color_LightGray";
_dividercolor = _xui.Color_LightGray;
 break; }
case 6: {
 //BA.debugLineNum = 104;BA.debugLine="Background = xui.Color_ARGB(255,2,2,2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 105;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 106;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 107;BA.debugLine="txtNormal = -16739073";
_txtnormal = (int) (-16739073);
 //BA.debugLineNum = 108;BA.debugLine="txtAccent = -8472605";
_txtaccent = (int) (-8472605);
 //BA.debugLineNum = 109;BA.debugLine="btnDisableText = -12104360";
_btndisabletext = (int) (-12104360);
 //BA.debugLineNum = 110;BA.debugLine="DividerColor = xui.Color_Gray";
_dividercolor = _xui.Color_Gray;
 break; }
case 7: {
 //BA.debugLineNum = 113;BA.debugLine="Background = xui.Color_ARGB(255,2,2,2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 114;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 115;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 116;BA.debugLine="txtNormal = -11276022";
_txtnormal = (int) (-11276022);
 //BA.debugLineNum = 117;BA.debugLine="txtAccent = 0xFFB1E89A";
_txtaccent = ((int)0xffb1e89a);
 //BA.debugLineNum = 118;BA.debugLine="btnDisableText =0xFF425845";
_btndisabletext = ((int)0xff425845);
 break; }
case 8: {
 //BA.debugLineNum = 122;BA.debugLine="Background = -14672868";
_background = (int) (-14672868);
 //BA.debugLineNum = 123;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,11, 11, 1";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (11),(int) (11),(int) (11));
 //BA.debugLineNum = 124;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 125;BA.debugLine="txtNormal = -1551583";
_txtnormal = (int) (-1551583);
 //BA.debugLineNum = 126;BA.debugLine="txtAccent = 0xFFD77762";
_txtaccent = ((int)0xffd77762);
 //BA.debugLineNum = 127;BA.debugLine="btnDisableText = xui.Color_ARGB(50,192,192,192)";
_btndisabletext = _xui.Color_ARGB((int) (50),(int) (192),(int) (192),(int) (192));
 //BA.debugLineNum = 128;BA.debugLine="DividerColor = xui.Color_Black";
_dividercolor = _xui.Color_Black;
 break; }
default: {
 //BA.debugLineNum = 131;BA.debugLine="Log(\"Theme Else: \" & theme)";
anywheresoftware.b4a.keywords.Common.LogImpl("8912984","Theme Else: "+_theme,0);
 //BA.debugLineNum = 132;BA.debugLine="Background = xui.Color_ARGB(255,53, 69, 85)";
_background = _xui.Color_ARGB((int) (255),(int) (53),(int) (69),(int) (85));
 //BA.debugLineNum = 133;BA.debugLine="BackgroundHeader = -14932432";
_backgroundheader = (int) (-14932432);
 //BA.debugLineNum = 134;BA.debugLine="Background2 = xui.Color_ARGB(255,45, 62, 78)";
_background2 = _xui.Color_ARGB((int) (255),(int) (45),(int) (62),(int) (78));
 break; }
}
;
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
return "";
}
public static int[]  _int2argb(anywheresoftware.b4a.BA _ba,int _color) throws Exception{
int[] _res = null;
 //BA.debugLineNum = 188;BA.debugLine="Public Sub Int2ARGB(Color As Int) As Int()";
 //BA.debugLineNum = 189;BA.debugLine="Dim res(4) As Int";
_res = new int[(int) (4)];
;
 //BA.debugLineNum = 190;BA.debugLine="res(0) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (0)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff000000)),(int) (24));
 //BA.debugLineNum = 191;BA.debugLine="res(1) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (1)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff0000)),(int) (16));
 //BA.debugLineNum = 192;BA.debugLine="res(2) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (2)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff00)),(int) (8));
 //BA.debugLineNum = 193;BA.debugLine="res(3) = Bit.And(Color, 0xff)";
_res[(int) (3)] = anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff));
 //BA.debugLineNum = 194;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"clrTheme\" 'ign";
_mmodule = "clrTheme";
 //BA.debugLineNum = 11;BA.debugLine="Type tthemecolors (bg, bgheader, bgmenu, txtNorma";
;
 //BA.debugLineNum = 12;BA.debugLine="Public customcolors As tthemecolors";
_customcolors = new sadLogic.HomeCentral.clrtheme._tthemecolors();
 //BA.debugLineNum = 14;BA.debugLine="Public Background,BackgroundHeader,Background2 As";
_background = 0;
_backgroundheader = 0;
_background2 = 0;
 //BA.debugLineNum = 16;BA.debugLine="Public txtAccent,txtNormal,txtNormal2 As Int";
_txtaccent = 0;
_txtnormal = 0;
_txtnormal2 = 0;
 //BA.debugLineNum = 17;BA.debugLine="Public btnDisableText As Int";
_btndisabletext = 0;
 //BA.debugLineNum = 18;BA.debugLine="Public DividerColor As Int";
_dividercolor = 0;
 //BA.debugLineNum = 20;BA.debugLine="Public ItemsBackgroundColor As Int '--- used in s";
_itemsbackgroundcolor = 0;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public static String  _setthemeb4xlisttemplate(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xlisttemplate _l) throws Exception{
int _textcolor = 0;
 //BA.debugLineNum = 225;BA.debugLine="Public Sub SetThemeB4xListTemplate(l As B4XListTem";
 //BA.debugLineNum = 229;BA.debugLine="Dim TextColor As Int = xui.Color_ARGB(0xFF, 0x5B,";
_textcolor = _xui.Color_ARGB(((int)0xff),((int)0x5b),((int)0x5b),((int)0x5b));
 //BA.debugLineNum = 230;BA.debugLine="l.CustomListView1.sv.ScrollViewInnerPanel.Color =";
_l._customlistview1 /*b4a.example3.customlistview*/ ._sv.getScrollViewInnerPanel().setColor(_xui.Color_ARGB(((int)0xff),((int)0xdf),((int)0xdf),((int)0xdf)));
 //BA.debugLineNum = 231;BA.debugLine="l.CustomListView1.sv.Color = xui.Color_White";
_l._customlistview1 /*b4a.example3.customlistview*/ ._sv.setColor(_xui.Color_White);
 //BA.debugLineNum = 232;BA.debugLine="l.CustomListView1.DefaultTextBackgroundColor = xu";
_l._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = _xui.Color_White;
 //BA.debugLineNum = 233;BA.debugLine="l.CustomListView1.DefaultTextColor = TextColor";
_l._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = _textcolor;
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public static String  _setthemeb4xsearchtemplate(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xsearchtemplate _search) throws Exception{
int _textcolor = 0;
 //BA.debugLineNum = 268;BA.debugLine="Public Sub SetThemeB4xSearchTemplate(search As B4X";
 //BA.debugLineNum = 273;BA.debugLine="Dim TextColor As Int = xui.Color_ARGB(0xFF, 0x5B,";
_textcolor = _xui.Color_ARGB(((int)0xff),((int)0x5b),((int)0x5b),((int)0x5b));
 //BA.debugLineNum = 274;BA.debugLine="search.SearchField.TextField.TextColor = TextColo";
_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._gettextfield /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setTextColor(_textcolor);
 //BA.debugLineNum = 275;BA.debugLine="search.SearchField.NonFocusedHintColor = TextColo";
_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._nonfocusedhintcolor /*int*/  = _textcolor;
 //BA.debugLineNum = 276;BA.debugLine="search.CustomListView1.sv.ScrollViewInnerPanel.Co";
_search._customlistview1 /*b4a.example3.customlistview*/ ._sv.getScrollViewInnerPanel().setColor(_xui.Color_ARGB(((int)0xff),((int)0xdf),((int)0xdf),((int)0xdf)));
 //BA.debugLineNum = 277;BA.debugLine="search.CustomListView1.sv.Color = xui.Color_White";
_search._customlistview1 /*b4a.example3.customlistview*/ ._sv.setColor(_xui.Color_White);
 //BA.debugLineNum = 278;BA.debugLine="search.CustomListView1.DefaultTextBackgroundColor";
_search._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = _xui.Color_White;
 //BA.debugLineNum = 279;BA.debugLine="search.CustomListView1.DefaultTextColor = TextCol";
_search._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = _textcolor;
 //BA.debugLineNum = 280;BA.debugLine="If search.SearchField.lblV.IsInitialized Then sea";
if (_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._lblv /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .IsInitialized()) { 
_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._lblv /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(_textcolor);};
 //BA.debugLineNum = 281;BA.debugLine="If search.SearchField.lblClear.IsInitialized Then";
if (_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._lblclear /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .IsInitialized()) { 
_search._searchfield /*sadLogic.HomeCentral.b4xfloattextfield*/ ._lblclear /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(_textcolor);};
 //BA.debugLineNum = 283;BA.debugLine="End Sub";
return "";
}
public static String  _setthemecustomlistview(anywheresoftware.b4a.BA _ba,b4a.example3.customlistview _lv) throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Public Sub SetThemeCustomListView(lv As CustomList";
 //BA.debugLineNum = 238;BA.debugLine="lv.AsView.SetColorAndBorder(xui.Color_Transparent";
_lv._asview().SetColorAndBorder(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)),_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 239;BA.debugLine="lv.sv.ScrollViewInnerPanel.Color = xui.Color_Tran";
_lv._sv.getScrollViewInnerPanel().setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 240;BA.debugLine="lv.GetBase.Color = xui.Color_Transparent";
_lv._getbase().setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 241;BA.debugLine="lv.sv.Color = xui.Color_Transparent";
_lv._sv.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 243;BA.debugLine="lv.PressedColor = BackgroundHeader";
_lv._pressedcolor = _backgroundheader;
 //BA.debugLineNum = 244;BA.debugLine="lv.DefaultTextBackgroundColor = xui.Color_Transpa";
_lv._defaulttextbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 245;BA.debugLine="lv.DefaultTextColor = txtNormal";
_lv._defaulttextcolor = _txtnormal;
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public static String  _setthemeprefdialog(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.preferencesdialog _pf) throws Exception{
int _i = 0;
 //BA.debugLineNum = 301;BA.debugLine="Public Sub SetThemePrefDialog(pf As PreferencesDia";
 //BA.debugLineNum = 307;BA.debugLine="pf.CustomListView1.GetBase.Color =Background";
_pf._customlistview1 /*b4a.example3.customlistview*/ ._getbase().setColor(_background);
 //BA.debugLineNum = 308;BA.debugLine="pf.CustomListView1.sv.Color =Background";
_pf._customlistview1 /*b4a.example3.customlistview*/ ._sv.setColor(_background);
 //BA.debugLineNum = 309;BA.debugLine="pf.CustomListView1.sv.ScrollViewInnerPanel.Color";
_pf._customlistview1 /*b4a.example3.customlistview*/ ._sv.getScrollViewInnerPanel().setColor(_background);
 //BA.debugLineNum = 310;BA.debugLine="For i = 0 To pf.CustomListView1.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_pf._customlistview1 /*b4a.example3.customlistview*/ ._getsize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 311;BA.debugLine="pf.CustomListView1.GetPanel(i).Color = Backgroun";
_pf._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).setColor(_background);
 }
};
 //BA.debugLineNum = 313;BA.debugLine="End Sub";
return "";
}
public static String  _setthemesadb4xinputtemplate(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.sadb4xinputtemplate _input,String _prompt) throws Exception{
int _textcolor = 0;
 //BA.debugLineNum = 258;BA.debugLine="Public Sub SetThemeSadB4xInputTemplate(input As sa";
 //BA.debugLineNum = 260;BA.debugLine="Dim TextColor As Int = txtNormal";
_textcolor = _txtnormal;
 //BA.debugLineNum = 261;BA.debugLine="input.lblTitle.Text = prompt";
_input._lbltitle /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setText(BA.ObjectToCharSequence(_prompt));
 //BA.debugLineNum = 262;BA.debugLine="input.TextField1.TextColor = TextColor";
_input._textfield1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(_textcolor);
 //BA.debugLineNum = 263;BA.debugLine="input.lblTitle.TextColor = TextColor";
_input._lbltitle /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(_textcolor);
 //BA.debugLineNum = 264;BA.debugLine="input.SetBorderColor(TextColor, Background2)";
_input._setbordercolor /*String*/ (_textcolor,_background2);
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
}
