package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewroundslider{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)((0d * scale)));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - ((0d * scale))));
views.get("pnlmain").vw.setTop((int)((0d * scale)));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - ((0d * scale))));
views.get("sadroundslider1").vw.setLeft((int)((10d * scale)));
views.get("sadroundslider1").vw.setWidth((int)((100d / 100 * width)-(10d * scale) - ((10d * scale))));
views.get("sadroundslider1").vw.setTop((int)((10d * scale)));
views.get("sadroundslider1").vw.setHeight((int)((100d / 100 * height)-(10d * scale) - ((10d * scale))));

}
}