package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class eventcontroller extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.eventcontroller");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.eventcontroller.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.Map _eg = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private eg As Map";
_eg = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public int  _gethashcode(Object _o) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo2 = null;
 //BA.debugLineNum = 85;BA.debugLine="Private Sub GetHashCode(o As Object) As Int";
 //BA.debugLineNum = 86;BA.debugLine="Dim jo2 As JavaObject = o";
_jo2 = new anywheresoftware.b4j.object.JavaObject();
_jo2 = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_o));
 //BA.debugLineNum = 87;BA.debugLine="Return jo2.RunMethod(\"hashCode\", Null)";
if (true) return (int)(BA.ObjectToNumber(_jo2.RunMethod("hashCode",(Object[])(__c.Null))));
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 12;BA.debugLine="eg.Initialize";
_eg.Initialize();
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _raise(String _eventname) throws Exception{
String _en = "";
sadLogic.HomeCentral.clsevent _ov = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub Raise(eventName As String)";
 //BA.debugLineNum = 47;BA.debugLine="For Each en As String In eg.Keys";
{
final anywheresoftware.b4a.BA.IterableList group1 = _eg.Keys();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_en = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 48;BA.debugLine="If en.StartsWith(eventName & \"_\") Then";
if (_en.startsWith(_eventname+"_")) { 
 //BA.debugLineNum = 49;BA.debugLine="Dim ov As clsEvent";
_ov = new sadLogic.HomeCentral.clsevent();
 //BA.debugLineNum = 50;BA.debugLine="ov = eg.Get(en)";
_ov = (sadLogic.HomeCentral.clsevent)(_eg.Get((Object)(_en)));
 //BA.debugLineNum = 51;BA.debugLine="ov.Raise";
_ov._raise /*String*/ ();
 };
 }
};
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public String  _raise2(String _eventname,Object _arg1) throws Exception{
String _en = "";
sadLogic.HomeCentral.clsevent _ov = null;
 //BA.debugLineNum = 59;BA.debugLine="Public Sub Raise2(eventName As String,arg1 As Obje";
 //BA.debugLineNum = 60;BA.debugLine="For Each en As String In eg.Keys";
{
final anywheresoftware.b4a.BA.IterableList group1 = _eg.Keys();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_en = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 61;BA.debugLine="If en.StartsWith(eventName & \"_\") Then";
if (_en.startsWith(_eventname+"_")) { 
 //BA.debugLineNum = 62;BA.debugLine="Dim ov As clsEvent";
_ov = new sadLogic.HomeCentral.clsevent();
 //BA.debugLineNum = 63;BA.debugLine="ov = eg.Get(en)";
_ov = (sadLogic.HomeCentral.clsevent)(_eg.Get((Object)(_en)));
 //BA.debugLineNum = 64;BA.debugLine="ov.Raise2(arg1)";
_ov._raise2 /*String*/ (_arg1);
 };
 }
};
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public String  _raise3(String _eventname,Object _arg1,Object _arg2) throws Exception{
String _en = "";
sadLogic.HomeCentral.clsevent _ov = null;
 //BA.debugLineNum = 74;BA.debugLine="Public Sub Raise3(eventName As String,arg1 As Obje";
 //BA.debugLineNum = 75;BA.debugLine="For Each en As String In eg.Keys";
{
final anywheresoftware.b4a.BA.IterableList group1 = _eg.Keys();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_en = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 76;BA.debugLine="If en.StartsWith(eventName & \"_\") Then";
if (_en.startsWith(_eventname+"_")) { 
 //BA.debugLineNum = 77;BA.debugLine="Dim ov As clsEvent";
_ov = new sadLogic.HomeCentral.clsevent();
 //BA.debugLineNum = 78;BA.debugLine="ov = eg.Get(en)";
_ov = (sadLogic.HomeCentral.clsevent)(_eg.Get((Object)(_en)));
 //BA.debugLineNum = 79;BA.debugLine="ov.Raise3(arg1,arg2)";
_ov._raise3 /*String*/ (_arg1,_arg2);
 };
 }
};
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _subscribe(String _eventname,Object _callbackobj,String _callbacksub) throws Exception{
sadLogic.HomeCentral.clsevent _oo = null;
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Subscribe(eventName As String, CallBack";
 //BA.debugLineNum = 23;BA.debugLine="Unsubscribe(eventName,CallBackObj)";
_unsubscribe(_eventname,_callbackobj);
 //BA.debugLineNum = 26;BA.debugLine="Dim oo As clsEvent : oo.Initialize";
_oo = new sadLogic.HomeCentral.clsevent();
 //BA.debugLineNum = 26;BA.debugLine="Dim oo As clsEvent : oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 27;BA.debugLine="oo.Subscribe(CallBackObj,callbackSub)";
_oo._subscribe /*String*/ (_callbackobj,_callbacksub);
 //BA.debugLineNum = 30;BA.debugLine="eg.Put(eventName & \"_\" & GetHashCode(CallBackObj)";
_eg.Put((Object)(_eventname+"_"+(BA.NumberToString(_gethashcode(_callbackobj)))),(Object)(_oo));
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _unsubscribe(String _eventname,Object _callbackobj) throws Exception{
int _hc = 0;
 //BA.debugLineNum = 38;BA.debugLine="Public Sub Unsubscribe(eventName As String,CallBac";
 //BA.debugLineNum = 39;BA.debugLine="Dim hc As Int = GetHashCode(CallBackObj).As(Strin";
_hc = (int)(Double.parseDouble((BA.NumberToString(_gethashcode(_callbackobj)))));
 //BA.debugLineNum = 40;BA.debugLine="If eg.ContainsKey(eventName & \"_\" & hc) Then";
if (_eg.ContainsKey((Object)(_eventname+"_"+BA.NumberToString(_hc)))) { 
 //BA.debugLineNum = 41;BA.debugLine="eg.Remove(eventName & \"_\" & hc)";
_eg.Remove((Object)(_eventname+"_"+BA.NumberToString(_hc)));
 };
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
