package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class wildcardfileslist extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.wildcardfileslist");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.wildcardfileslist.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.List _emptylist = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private emptyList As List";
_emptylist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.List  _filter(anywheresoftware.b4a.objects.collections.List _filesfound,String _wildcards,boolean _sorted,boolean _ascending) throws Exception{
String[] _getcards = null;
anywheresoftware.b4a.objects.collections.List _filteredfiles = null;
int _i = 0;
int _l = 0;
String _testitem = "";
String _mask = "";
String _pattern = "";
 //BA.debugLineNum = 17;BA.debugLine="Private Sub Filter(FilesFound As List,WildCards As";
 //BA.debugLineNum = 19;BA.debugLine="Dim GetCards() As String = Regex.Split(\",\", WildC";
_getcards = __c.Regex.Split(",",_wildcards);
 //BA.debugLineNum = 20;BA.debugLine="Dim FilteredFiles As List : FilteredFiles.Initial";
_filteredfiles = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 20;BA.debugLine="Dim FilteredFiles As List : FilteredFiles.Initial";
_filteredfiles.Initialize();
 //BA.debugLineNum = 22;BA.debugLine="For i = 0 To FilesFound.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_filesfound.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 23;BA.debugLine="For l = 0 To GetCards.Length - 1";
{
final int step5 = 1;
final int limit5 = (int) (_getcards.length-1);
_l = (int) (0) ;
for (;_l <= limit5 ;_l = _l + step5 ) {
 //BA.debugLineNum = 25;BA.debugLine="Dim TestItem As String = FilesFound.Get(i)";
_testitem = BA.ObjectToString(_filesfound.Get(_i));
 //BA.debugLineNum = 26;BA.debugLine="Dim mask As String = GetCards(l).Trim";
_mask = _getcards[_l].trim();
 //BA.debugLineNum = 27;BA.debugLine="Dim pattern As String = \"^\" & mask.Replace(\".\",";
_pattern = "^"+_mask.replace(".","\\.").replace("*",".+").replace("?",".")+"$";
 //BA.debugLineNum = 29;BA.debugLine="If Regex.IsMatch(pattern,TestItem) = True Then";
if (__c.Regex.IsMatch(_pattern,_testitem)==__c.True) { 
 //BA.debugLineNum = 30;BA.debugLine="FilteredFiles.Add(TestItem.Trim)";
_filteredfiles.Add((Object)(_testitem.trim()));
 };
 }
};
 }
};
 //BA.debugLineNum = 36;BA.debugLine="If Sorted Then";
if (_sorted) { 
 //BA.debugLineNum = 37;BA.debugLine="FilteredFiles.SortCaseInsensitive(Ascending)";
_filteredfiles.SortCaseInsensitive(_ascending);
 };
 //BA.debugLineNum = 40;BA.debugLine="Return FilteredFiles";
if (true) return _filteredfiles;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getfiles(String _filespath,String _wildcards,boolean _sorted,boolean _ascending) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="public Sub GetFiles(FilesPath As String, WildCards";
 //BA.debugLineNum = 48;BA.debugLine="If File.IsDirectory(\"\", FilesPath) Then";
if (__c.File.IsDirectory("",_filespath)) { 
 //BA.debugLineNum = 50;BA.debugLine="Return Filter(File.ListFiles(FilesPath),WildCard";
if (true) return _filter(__c.File.ListFiles(_filespath),_wildcards,_sorted,_ascending);
 }else {
 //BA.debugLineNum = 54;BA.debugLine="Return emptyList";
if (true) return _emptylist;
 };
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _getfilesasync(String _filespath,String _wildcards,boolean _sorted,boolean _ascending) throws Exception{
ResumableSub_GetFilesAsync rsub = new ResumableSub_GetFilesAsync(this,_filespath,_wildcards,_sorted,_ascending);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_GetFilesAsync extends BA.ResumableSub {
public ResumableSub_GetFilesAsync(sadLogic.OctoTouchController.foss.wildcardfileslist parent,String _filespath,String _wildcards,boolean _sorted,boolean _ascending) {
this.parent = parent;
this._filespath = _filespath;
this._wildcards = _wildcards;
this._sorted = _sorted;
this._ascending = _ascending;
}
sadLogic.OctoTouchController.foss.wildcardfileslist parent;
String _filespath;
String _wildcards;
boolean _sorted;
boolean _ascending;
boolean _success = false;
anywheresoftware.b4a.objects.collections.List _filesfound = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 64;BA.debugLine="If File.IsDirectory(\"\", FilesPath) Then";
if (true) break;

case 1:
//if
this.state = 12;
if (parent.__c.File.IsDirectory("",_filespath)) { 
this.state = 3;
}else {
this.state = 11;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 66;BA.debugLine="Wait For (File.ListFilesAsync(FilesPath)) Comple";
parent.__c.WaitFor("complete", ba, this, parent.__c.File.ListFilesAsync(ba,_filespath));
this.state = 13;
return;
case 13:
//C
this.state = 4;
_success = (Boolean) result[0];
_filesfound = (anywheresoftware.b4a.objects.collections.List) result[1];
;
 //BA.debugLineNum = 67;BA.debugLine="If Success = False Then Return emptyList";
if (true) break;

case 4:
//if
this.state = 9;
if (_success==parent.__c.False) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._emptylist));return;};
if (true) break;

case 9:
//C
this.state = 12;
;
 //BA.debugLineNum = 69;BA.debugLine="Return Filter(FilesFound,WildCards,Sorted,Ascend";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._filter(_filesfound,_wildcards,_sorted,_ascending)));return;};
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 73;BA.debugLine="Return emptyList";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._emptylist));return;};
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(boolean _success,anywheresoftware.b4a.objects.collections.List _filesfound) throws Exception{
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="emptyList.Initialize";
_emptylist.Initialize();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
