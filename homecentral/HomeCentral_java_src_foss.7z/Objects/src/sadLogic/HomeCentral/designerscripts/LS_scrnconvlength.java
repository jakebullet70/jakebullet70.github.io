package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_scrnconvlength{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padtb="";
String _padlr="";
String _item="";
String _txth="";
String _lblh="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
_padtb = BA.NumberToString((50d * scale));
_padlr = BA.NumberToString((80d * scale));
views.get("pnllength").vw.setLeft((int)(0d));
views.get("pnllength").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnllength").vw.setTop((int)(0d));
views.get("pnllength").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnllenframe").vw.setLeft((int)((views.get("pnllength").vw.getLeft())+Double.parseDouble(_padlr)));
views.get("pnllenframe").vw.setWidth((int)((views.get("pnllength").vw.getWidth())-Double.parseDouble(_padlr) - ((views.get("pnllength").vw.getLeft())+Double.parseDouble(_padlr))));
views.get("pnllenframe").vw.setTop((int)((views.get("pnllength").vw.getTop())+Double.parseDouble(_padtb)));
views.get("pnllenframe").vw.setHeight((int)((views.get("pnllength").vw.getTop() + views.get("pnllength").vw.getHeight())-Double.parseDouble(_padtb) - ((views.get("pnllength").vw.getTop())+Double.parseDouble(_padtb))));
_item = BA.NumberToString((views.get("pnllenframe").vw.getHeight())/3d);
_txth = BA.NumberToString(Double.parseDouble(_item)*.6d);
_lblh = BA.NumberToString(Double.parseDouble(_item)*.4d);
views.get("lblmm").vw.setLeft((int)(0d));
views.get("lblmm").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("lblmm").vw.setTop((int)(0d));
views.get("lblmm").vw.setHeight((int)(Double.parseDouble(_lblh) - (0d)));
views.get("txtmm").vw.setLeft((int)(0d));
views.get("txtmm").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("txtmm").vw.setTop((int)((views.get("lblmm").vw.getTop() + views.get("lblmm").vw.getHeight())));
views.get("txtmm").vw.setHeight((int)((views.get("lblmm").vw.getTop() + views.get("lblmm").vw.getHeight())+Double.parseDouble(_txth) - ((views.get("lblmm").vw.getTop() + views.get("lblmm").vw.getHeight()))));
views.get("lblcm").vw.setLeft((int)(0d));
views.get("lblcm").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("lblcm").vw.setTop((int)((views.get("txtmm").vw.getTop() + views.get("txtmm").vw.getHeight())));
views.get("lblcm").vw.setHeight((int)((views.get("txtmm").vw.getTop() + views.get("txtmm").vw.getHeight())+Double.parseDouble(_lblh) - ((views.get("txtmm").vw.getTop() + views.get("txtmm").vw.getHeight()))));
views.get("txtcm").vw.setLeft((int)(0d));
views.get("txtcm").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("txtcm").vw.setTop((int)((views.get("lblcm").vw.getTop() + views.get("lblcm").vw.getHeight())));
views.get("txtcm").vw.setHeight((int)((views.get("lblcm").vw.getTop() + views.get("lblcm").vw.getHeight())+Double.parseDouble(_txth) - ((views.get("lblcm").vw.getTop() + views.get("lblcm").vw.getHeight()))));
views.get("lblinches").vw.setLeft((int)(0d));
views.get("lblinches").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("lblinches").vw.setTop((int)((views.get("txtcm").vw.getTop() + views.get("txtcm").vw.getHeight())));
views.get("lblinches").vw.setHeight((int)((views.get("txtcm").vw.getTop() + views.get("txtcm").vw.getHeight())+Double.parseDouble(_lblh) - ((views.get("txtcm").vw.getTop() + views.get("txtcm").vw.getHeight()))));
views.get("txtinches").vw.setLeft((int)(0d));
views.get("txtinches").vw.setWidth((int)((views.get("pnllenframe").vw.getWidth()) - (0d)));
views.get("txtinches").vw.setTop((int)((views.get("lblinches").vw.getTop() + views.get("lblinches").vw.getHeight())));
views.get("txtinches").vw.setHeight((int)((views.get("lblinches").vw.getTop() + views.get("lblinches").vw.getHeight())+Double.parseDouble(_txth) - ((views.get("lblinches").vw.getTop() + views.get("lblinches").vw.getHeight()))));

}
}