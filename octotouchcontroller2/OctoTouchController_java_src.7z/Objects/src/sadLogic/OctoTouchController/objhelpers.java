package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class objhelpers {
private static objhelpers mostCurrent = new objhelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4a.objects.collections.Map  _concatmaps(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map[] _maps) throws Exception{
anywheresoftware.b4a.objects.collections.Map _retmap = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
Object _k = null;
 //BA.debugLineNum = 64;BA.debugLine="Public Sub ConcatMaps(maps() As Map) As Map 'ignor";
 //BA.debugLineNum = 65;BA.debugLine="Dim retMap As Map : retMap.Initialize";
_retmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 65;BA.debugLine="Dim retMap As Map : retMap.Initialize";
_retmap.Initialize();
 //BA.debugLineNum = 66;BA.debugLine="For Each m As Map In maps";
{
final anywheresoftware.b4a.objects.collections.Map[] group3 = _maps;
final int groupLen3 = group3.length
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_m = group3[index3];
 //BA.debugLineNum = 67;BA.debugLine="For Each k As Object In m.Keys";
{
final anywheresoftware.b4a.BA.IterableList group4 = _m.Keys();
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_k = group4.Get(index4);
 //BA.debugLineNum = 68;BA.debugLine="retMap.Put(k, m.Get(k))";
_retmap.Put(_k,_m.Get(_k));
 }
};
 }
};
 //BA.debugLineNum = 71;BA.debugLine="Return retMap";
if (true) return _retmap;
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.Map  _copymap(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _original) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Public Sub CopyMap(original As Map) As Map 'ignore";
 //BA.debugLineNum = 55;BA.debugLine="Return CopyObject(original)";
if (true) return (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_copyobject(_ba,(Object)(_original.getObject()))));
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public static Object  _copyobject(anywheresoftware.b4a.BA _ba,Object _sourceobject) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _s = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub CopyObject(SourceObject As Object) As O";
 //BA.debugLineNum = 50;BA.debugLine="Dim s As B4XSerializator";
_s = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 51;BA.debugLine="Return s.ConvertBytesToObject(s.ConvertObjectToBy";
if (true) return _s.ConvertBytesToObject(_s.ConvertObjectToBytes(_sourceobject));
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public static String  _list2json(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _gen = null;
 //BA.debugLineNum = 21;BA.debugLine="public Sub List2Json(lst As List) As String";
 //BA.debugLineNum = 23;BA.debugLine="Dim gen As JSONGenerator";
_gen = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 24;BA.debugLine="gen.Initialize2(lst)";
_gen.Initialize2(_lst);
 //BA.debugLineNum = 25;BA.debugLine="Return gen.ToString";
if (true) return _gen.ToString();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public static String  _map2json(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _gen = null;
 //BA.debugLineNum = 13;BA.debugLine="public Sub Map2Json(m As Map) As String";
 //BA.debugLineNum = 15;BA.debugLine="Dim gen As JSONGenerator";
_gen = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 16;BA.debugLine="gen.Initialize(m)";
_gen.Initialize(_m);
 //BA.debugLineNum = 17;BA.debugLine="Return gen.ToString";
if (true) return _gen.ToString();
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.collections.List  _map2list(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _mymap,boolean _keylist) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
Object _item = null;
 //BA.debugLineNum = 31;BA.debugLine="public Sub Map2List(myMap As Map, KeyList As Boole";
 //BA.debugLineNum = 32;BA.debugLine="Dim lst As List : lst.Initialize";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 32;BA.debugLine="Dim lst As List : lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 33;BA.debugLine="If KeyList Then";
if (_keylist) { 
 //BA.debugLineNum = 34;BA.debugLine="For Each item As Object In myMap.Keys";
{
final anywheresoftware.b4a.BA.IterableList group4 = _mymap.Keys();
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_item = group4.Get(index4);
 //BA.debugLineNum = 35;BA.debugLine="lst.Add(item)";
_lst.Add(_item);
 }
};
 }else {
 //BA.debugLineNum = 38;BA.debugLine="For Each item As Object In myMap.Values";
{
final anywheresoftware.b4a.BA.IterableList group8 = _mymap.Values();
final int groupLen8 = group8.getSize()
;int index8 = 0;
;
for (; index8 < groupLen8;index8++){
_item = group8.Get(index8);
 //BA.debugLineNum = 39;BA.debugLine="lst.Add(item)";
_lst.Add(_item);
 }
};
 };
 //BA.debugLineNum = 42;BA.debugLine="Return lst";
if (true) return _lst;
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"objHelper\" 'ig";
_mmodule = "objHelper";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
}
