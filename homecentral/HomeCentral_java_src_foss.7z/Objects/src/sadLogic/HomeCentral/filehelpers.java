package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class filehelpers {
private static filehelpers mostCurrent = new filehelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _getfilenamefrompath(anywheresoftware.b4a.BA _ba,String _pathandfname) throws Exception{
String _pathsepchar = "";
int _tt = 0;
 //BA.debugLineNum = 73;BA.debugLine="Public Sub GetFilenameFromPath(pathAndfname As Str";
 //BA.debugLineNum = 75;BA.debugLine="Dim PathSepChar As String  = \"/\"";
_pathsepchar = "/";
 //BA.debugLineNum = 77;BA.debugLine="Try";
try { //BA.debugLineNum = 78;BA.debugLine="Dim tt As Int = pathAndfname.LastIndexOf(PathSep";
_tt = _pathandfname.lastIndexOf(_pathsepchar);
 //BA.debugLineNum = 79;BA.debugLine="Return pathAndfname.SubString2(tt + 1,pathAndfna";
if (true) return _pathandfname.substring((int) (_tt+1),_pathandfname.length());
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 81;BA.debugLine="Return pathAndfname";
if (true) return _pathandfname;
 };
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public static String  _safekill(anywheresoftware.b4a.BA _ba,String _folder,String _fname) throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Public Sub SafeKill(folder As String, fname As Str";
 //BA.debugLineNum = 31;BA.debugLine="If File.Exists(folder, fname) Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_folder,_fname)) { 
 //BA.debugLineNum = 32;BA.debugLine="File.Delete(folder, fname)";
anywheresoftware.b4a.keywords.Common.File.Delete(_folder,_fname);
 };
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
}
