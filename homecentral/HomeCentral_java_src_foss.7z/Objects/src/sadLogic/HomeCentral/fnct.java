package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class fnct {
private static fnct mostCurrent = new fnct();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static int  _countchar(anywheresoftware.b4a.BA _ba,String _searchme,char _findme) throws Exception{
int _countme = 0;
int _x = 0;
 //BA.debugLineNum = 27;BA.debugLine="Public Sub CountChar(searchMe As String, findMe As";
 //BA.debugLineNum = 28;BA.debugLine="If Not(searchMe.Contains(findMe)) Then Return 0";
if (anywheresoftware.b4a.keywords.Common.Not(_searchme.contains(BA.ObjectToString(_findme)))) { 
if (true) return (int) (0);};
 //BA.debugLineNum = 29;BA.debugLine="Dim CountMe As Int = 0";
_countme = (int) (0);
 //BA.debugLineNum = 31;BA.debugLine="For x = 0 To searchMe.Length - 1";
{
final int step3 = 1;
final int limit3 = (int) (_searchme.length()-1);
_x = (int) (0) ;
for (;_x <= limit3 ;_x = _x + step3 ) {
 //BA.debugLineNum = 32;BA.debugLine="If searchMe.CharAt(x) = findMe Then";
if (_searchme.charAt(_x)==_findme) { 
 //BA.debugLineNum = 33;BA.debugLine="CountMe = CountMe + 1";
_countme = (int) (_countme+1);
 };
 }
};
 //BA.debugLineNum = 36;BA.debugLine="Return CountMe";
if (true) return _countme;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return 0;
}
public static String  _init(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Init";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static boolean  _int2bool(anywheresoftware.b4a.BA _ba,int _i) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Public Sub int2bool(I As Int) As Boolean";
 //BA.debugLineNum = 16;BA.debugLine="Try";
try { //BA.debugLineNum = 17;BA.debugLine="If I = 0 Then Return False Else Return True";
if (_i==0) { 
if (true) return anywheresoftware.b4a.keywords.Common.False;}
else {
if (true) return anywheresoftware.b4a.keywords.Common.True;};
 } 
       catch (Exception e4) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e4); //BA.debugLineNum = 19;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("28442628",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 //BA.debugLineNum = 21;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
}
