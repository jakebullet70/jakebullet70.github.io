package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class kitchentmrs extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.kitchentmrs");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.kitchentmrs.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.phone.Phone.PhoneWakeState _phw = null;
public anywheresoftware.b4a.objects.Timer _tmrtimers = null;
public sadLogic.HomeCentral.kt._typtimers[] _timers = null;
public int _currenttimer = 0;
public sadLogic.HomeCentral.clskalarms[] _moalarm = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Public phw As PhoneWakeState";
_phw = new anywheresoftware.b4a.phone.Phone.PhoneWakeState();
 //BA.debugLineNum = 11;BA.debugLine="Public tmrTimers As Timer";
_tmrtimers = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 13;BA.debugLine="Public timers(6) As typTimers";
_timers = new sadLogic.HomeCentral.kt._typtimers[(int) (6)];
{
int d0 = _timers.length;
for (int i0 = 0;i0 < d0;i0++) {
_timers[i0] = new sadLogic.HomeCentral.kt._typtimers();
}
}
;
 //BA.debugLineNum = 14;BA.debugLine="Public CurrentTimer As Int = 1";
_currenttimer = (int) (1);
 //BA.debugLineNum = 15;BA.debugLine="Public moAlarm(6) As clsKAlarms";
_moalarm = new sadLogic.HomeCentral.clskalarms[(int) (6)];
{
int d0 = _moalarm.length;
for (int i0 = 0;i0 < d0;i0++) {
_moalarm[i0] = new sadLogic.HomeCentral.clskalarms();
}
}
;
 //BA.debugLineNum = 16;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 24;BA.debugLine="tmrTimers.Initialize(\"tmrTimers\",1000)";
_tmrtimers.Initialize(ba,"tmrTimers",(long) (1000));
 //BA.debugLineNum = 25;BA.debugLine="tmrTimers.Enabled = False";
_tmrtimers.setEnabled(__c.False);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _processtimercheck4expire(int _x) throws Exception{
ResumableSub_ProcessTimerCheck4Expire rsub = new ResumableSub_ProcessTimerCheck4Expire(this,_x);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ProcessTimerCheck4Expire extends BA.ResumableSub {
public ResumableSub_ProcessTimerCheck4Expire(sadLogic.HomeCentral.kitchentmrs parent,int _x) {
this.parent = parent;
this._x = _x;
}
sadLogic.HomeCentral.kitchentmrs parent;
int _x;
boolean _ret = false;
long _nnow = 0L;
b4a.example.dateutils._period _p1 = null;
boolean _scrnon = false;
String _s1 = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 83;BA.debugLine="Dim ret As Boolean = False";
_ret = parent.__c.False;
 //BA.debugLineNum = 84;BA.debugLine="Dim nNow As Long = DateTime.Now";
_nnow = parent.__c.DateTime.getNow();
 //BA.debugLineNum = 85;BA.debugLine="Dim P1 As Period = DateUtils.PeriodBetween(nNow,t";
_p1 = parent._dateutils._periodbetween(ba,_nnow,parent._timers[_x].endTime /*long*/ );
 //BA.debugLineNum = 88;BA.debugLine="Dim scrnOn As Boolean = Not (mpage.PowerCtrl.IsSc";
_scrnon = parent.__c.Not(parent._mpage._powerctrl /*sadLogic.HomeCentral.powercontrol*/ ._isscreenoff /*boolean*/ );
 //BA.debugLineNum = 90;BA.debugLine="If P1.Hours <= 0 And P1.Minutes <= 0 And P1.Secon";
if (true) break;

case 1:
//if
this.state = 34;
if (_p1.Hours<=0 && _p1.Minutes<=0 && _p1.Seconds<=0) { 
this.state = 3;
}else {
this.state = 21;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 96;BA.debugLine="scrnOn = True";
_scrnon = parent.__c.True;
 //BA.debugLineNum = 99;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 42;
return;
case 42:
//C
this.state = 4;
;
 //BA.debugLineNum = 101;BA.debugLine="If x = CurrentTimer Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_x==parent._currenttimer) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 102;BA.debugLine="If scrnOn Then";
if (true) break;

case 7:
//if
this.state = 14;
if (_scrnon) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 103;BA.debugLine="If Not (IsPaused(Main)) Then";
if (true) break;

case 10:
//if
this.state = 13;
if (parent.__c.Not(parent.__c.IsPaused(ba,(Object)(parent._main.getObject())))) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 104;BA.debugLine="CallSub(mpage.oPageTimers ,\"ClearLarge_TimerT";
parent.__c.CallSubNew(ba,(Object)(parent._mpage._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ),"ClearLarge_TimerTxt");
 if (true) break;

case 13:
//C
this.state = 14;
;
 if (true) break;

case 14:
//C
this.state = 15;
;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 109;BA.debugLine="timers(x).nHr = 0 : timers(x).nSec = 0 : timers(";
parent._timers[_x].nHr /*int*/  = (int) (0);
 //BA.debugLineNum = 109;BA.debugLine="timers(x).nHr = 0 : timers(x).nSec = 0 : timers(";
parent._timers[_x].nSec /*int*/  = (int) (0);
 //BA.debugLineNum = 109;BA.debugLine="timers(x).nHr = 0 : timers(x).nSec = 0 : timers(";
parent._timers[_x].nMin /*int*/  = (int) (0);
 //BA.debugLineNum = 110;BA.debugLine="If scrnOn Then";
if (true) break;

case 16:
//if
this.state = 19;
if (_scrnon) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 111;BA.debugLine="CallSubDelayed3(mpage.oPageTimers,\"Update_ListO";
parent.__c.CallSubDelayed3(ba,(Object)(parent._mpage._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ),"Update_ListOfTimersIMG",(Object)(_x),(Object)(parent._gblconst._timers_img_stop /*String*/ ));
 if (true) break;

case 19:
//C
this.state = 34;
;
 //BA.debugLineNum = 115;BA.debugLine="ret = True";
_ret = parent.__c.True;
 if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 118;BA.debugLine="If x = CurrentTimer Then";
if (true) break;

case 22:
//if
this.state = 33;
if (_x==parent._currenttimer) { 
this.state = 24;
}if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 119;BA.debugLine="Dim s1 As String = kt.PadZero(P1.Hours) & \":\" &";
_s1 = parent._kt._padzero /*String*/ (ba,_p1.Hours)+":"+parent._kt._padzero /*String*/ (ba,_p1.Minutes)+":"+parent._kt._padzero /*String*/ (ba,_p1.Seconds);
 //BA.debugLineNum = 120;BA.debugLine="If scrnOn Then";
if (true) break;

case 25:
//if
this.state = 32;
if (_scrnon) { 
this.state = 27;
}if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 121;BA.debugLine="If Not (IsPaused(Main)) Then";
if (true) break;

case 28:
//if
this.state = 31;
if (parent.__c.Not(parent.__c.IsPaused(ba,(Object)(parent._main.getObject())))) { 
this.state = 30;
}if (true) break;

case 30:
//C
this.state = 31;
 //BA.debugLineNum = 122;BA.debugLine="CallSubDelayed2(mpage.oPageTimers,\"UpdateRunn";
parent.__c.CallSubDelayed2(ba,(Object)(parent._mpage._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ),"UpdateRunning_Tmr",(Object)(_s1));
 if (true) break;

case 31:
//C
this.state = 32;
;
 if (true) break;

case 32:
//C
this.state = 33;
;
 if (true) break;

case 33:
//C
this.state = 34;
;
 //BA.debugLineNum = 129;BA.debugLine="timers(x).nHr = P1.Hours : timers(x).nSec = P1.S";
parent._timers[_x].nHr /*int*/  = _p1.Hours;
 //BA.debugLineNum = 129;BA.debugLine="timers(x).nHr = P1.Hours : timers(x).nSec = P1.S";
parent._timers[_x].nSec /*int*/  = _p1.Seconds;
 //BA.debugLineNum = 129;BA.debugLine="timers(x).nHr = P1.Hours : timers(x).nSec = P1.S";
parent._timers[_x].nMin /*int*/  = _p1.Minutes;
 if (true) break;
;
 //BA.debugLineNum = 132;BA.debugLine="If scrnOn Then";

case 34:
//if
this.state = 41;
if (_scrnon) { 
this.state = 36;
}if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 133;BA.debugLine="If Not (IsPaused(Main)) Then";
if (true) break;

case 37:
//if
this.state = 40;
if (parent.__c.Not(parent.__c.IsPaused(ba,(Object)(parent._main.getObject())))) { 
this.state = 39;
}if (true) break;

case 39:
//C
this.state = 40;
 //BA.debugLineNum = 134;BA.debugLine="CallSubDelayed2(mpage.oPageTimers,\"UpdateListOf";
parent.__c.CallSubDelayed2(ba,(Object)(parent._mpage._opagetimers /*sadLogic.HomeCentral.pagektimers*/ ),"UpdateListOfTimers",(Object)(_x));
 if (true) break;

case 40:
//C
this.state = 41;
;
 if (true) break;

case 41:
//C
this.state = -1;
;
 //BA.debugLineNum = 139;BA.debugLine="Return ret";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_ret));return;};
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _tmr_timerscheck() throws Exception{
ResumableSub_tmr_TimersCheck rsub = new ResumableSub_tmr_TimersCheck(this);
rsub.resume(ba, null);
}
public static class ResumableSub_tmr_TimersCheck extends BA.ResumableSub {
public ResumableSub_tmr_TimersCheck(sadLogic.HomeCentral.kitchentmrs parent) {
this.parent = parent;
}
sadLogic.HomeCentral.kitchentmrs parent;
int _xx = 0;
boolean _bisactive = false;
boolean _i = false;
int step4;
int limit4;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 56;BA.debugLine="Dim xx As Int";
_xx = 0;
 //BA.debugLineNum = 57;BA.debugLine="Dim bIsActive As Boolean = False";
_bisactive = parent.__c.False;
 //BA.debugLineNum = 58;BA.debugLine="tmrTimers.Enabled = False";
parent._tmrtimers.setEnabled(parent.__c.False);
 //BA.debugLineNum = 60;BA.debugLine="For xx = 1 To 5";
if (true) break;

case 1:
//for
this.state = 14;
step4 = 1;
limit4 = (int) (5);
_xx = (int) (1) ;
this.state = 15;
if (true) break;

case 15:
//C
this.state = 14;
if ((step4 > 0 && _xx <= limit4) || (step4 < 0 && _xx >= limit4)) this.state = 3;
if (true) break;

case 16:
//C
this.state = 15;
_xx = ((int)(0 + _xx + step4)) ;
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 61;BA.debugLine="If timers(xx).active = True Then";
if (true) break;

case 4:
//if
this.state = 13;
if (parent._timers[_xx].active /*boolean*/ ==parent.__c.True) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 63;BA.debugLine="wait for (ProcessTimerCheck4Expire(xx)) Complet";
parent.__c.WaitFor("complete", ba, this, parent._processtimercheck4expire(_xx));
this.state = 17;
return;
case 17:
//C
this.state = 7;
_i = (Boolean) result[0];
;
 //BA.debugLineNum = 64;BA.debugLine="If i Then";
if (true) break;

case 7:
//if
this.state = 12;
if (_i) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 65;BA.debugLine="timers(xx).active = False";
parent._timers[_xx].active /*boolean*/  = parent.__c.False;
 //BA.debugLineNum = 66;BA.debugLine="bIsActive = IIf(bIsActive,True,False)";
_bisactive = BA.ObjectToBoolean(((_bisactive) ? ((Object)(parent.__c.True)) : ((Object)(parent.__c.False))));
 //BA.debugLineNum = 68;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"Alarm_Fired";
parent.__c.CallSubDelayed2(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)),"Alarm_Fired_Start",(Object)(_xx));
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 70;BA.debugLine="bIsActive = True";
_bisactive = parent.__c.True;
 if (true) break;

case 12:
//C
this.state = 13;
;
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;
if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 77;BA.debugLine="tmrTimers.Enabled = bIsActive";
parent._tmrtimers.setEnabled(_bisactive);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(boolean _i) throws Exception{
}
public String  _tmrtimers_tick() throws Exception{
b4a.example.dateutils._period _p = null;
 //BA.debugLineNum = 41;BA.debugLine="Private Sub tmrTimers_Tick";
 //BA.debugLineNum = 42;BA.debugLine="tmrTimers.Enabled = False";
_tmrtimers.setEnabled(__c.False);
 //BA.debugLineNum = 43;BA.debugLine="tmrTimers.Interval = 1000";
_tmrtimers.setInterval((long) (1000));
 //BA.debugLineNum = 44;BA.debugLine="tmrTimers.Enabled = True";
_tmrtimers.setEnabled(__c.True);
 //BA.debugLineNum = 45;BA.debugLine="Dim p As Period : p.Initialize : p.Seconds = 1";
_p = new b4a.example.dateutils._period();
 //BA.debugLineNum = 45;BA.debugLine="Dim p As Period : p.Initialize : p.Seconds = 1";
_p.Initialize();
 //BA.debugLineNum = 45;BA.debugLine="Dim p As Period : p.Initialize : p.Seconds = 1";
_p.Seconds = (int) (1);
 //BA.debugLineNum = 47;BA.debugLine="tmr_TimersCheck";
_tmr_timerscheck();
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
