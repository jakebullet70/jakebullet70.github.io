package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class mastercontroller extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.mastercontroller");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.mastercontroller.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public String _meventnametemp = "";
public String _meventnamestatus = "";
public String _meventnamebtns = "";
public Object _mcallback = null;
public sadLogic.OctoTouchController.foss.b4xmainpage _mainobj = null;
public sadLogic.OctoTouchController.foss.httpoctorestapi _ocn = null;
public sadLogic.OctoTouchController.foss.jsonparsormain _parser = null;
public sadLogic.OctoTouchController.foss.octowebsocket _ows = null;
public anywheresoftware.b4a.objects.collections.Map _gmapoctofileslist = null;
public anywheresoftware.b4a.objects.collections.Map _mapmasteroctotempsettings = null;
public boolean _mgotprofileinfoflag = false;
public boolean _mgotprofileinfoflag_isbusy = false;
public boolean _mgotoctosettingflag = false;
public boolean _mgotoctosettingflag_isbusy = false;
public boolean _mgotfileslistflag = false;
public boolean _mgotfileslistflag_isbusy = false;
public anywheresoftware.b4a.objects.collections.Map _mapbedheatingoptions = null;
public anywheresoftware.b4a.objects.collections.Map _maptoolheatingoptions = null;
public anywheresoftware.b4a.objects.collections.Map _mapallheatingoptions = null;
public anywheresoftware.b4a.objects.collections.Map _maptoolheatvaluesonly = null;
public anywheresoftware.b4a.objects.collections.Map _mapbedheatvaluesonly = null;
public anywheresoftware.b4a.objects.CSBuilder _cshdr = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bedimg = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _toolimg = null;
public float _sizehdrpic = 0f;
public boolean _mgettempflag_busy = false;
public boolean _mjobstatusflag_busy = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _allheaters_off() throws Exception{
 //BA.debugLineNum = 422;BA.debugLine="public Sub AllHeaters_Off";
 //BA.debugLineNum = 427;BA.debugLine="oCN.PostRequest(oc.cCMD_SET_TOOL_TEMP.Replace(\"!V";
_ocn._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",BA.NumberToString(0)).replace("!VAL1!",BA.NumberToString(0)));
 //BA.debugLineNum = 428;BA.debugLine="oCN.PostRequest(oc.cCMD_SET_BED_TEMP.Replace(\"!VA";
_ocn._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",BA.NumberToString(0)));
 //BA.debugLineNum = 430;BA.debugLine="End Sub";
return "";
}
public String  _build_presetheateroption(anywheresoftware.b4a.objects.collections.Map _mapofoptions) throws Exception{
String _alloff = "";
String _s = "";
String _filamenttype = "";
String _tmp = "";
String _tooltemp = "";
String _bedtemp = "";
int _x = 0;
 //BA.debugLineNum = 356;BA.debugLine="Private Sub Build_PresetHeaterOption(mapOfOptions";
 //BA.debugLineNum = 359;BA.debugLine="mapBedHeatingOptions.Initialize";
_mapbedheatingoptions.Initialize();
 //BA.debugLineNum = 360;BA.debugLine="mapToolHeatingOptions.Initialize";
_maptoolheatingoptions.Initialize();
 //BA.debugLineNum = 361;BA.debugLine="mapAllHeatingOptions.Initialize";
_mapallheatingoptions.Initialize();
 //BA.debugLineNum = 362;BA.debugLine="mapToolHeatValuesOnly.Initialize";
_maptoolheatvaluesonly.Initialize();
 //BA.debugLineNum = 363;BA.debugLine="mapBedHeatValuesOnly.Initialize";
_mapbedheatvaluesonly.Initialize();
 //BA.debugLineNum = 365;BA.debugLine="Dim allOff As String = \"** All Off **\"";
_alloff = "** All Off **";
 //BA.debugLineNum = 367;BA.debugLine="mapBedHeatingOptions.Put(allOff,\"alloff\")";
_mapbedheatingoptions.Put((Object)(_alloff),(Object)("alloff"));
 //BA.debugLineNum = 368;BA.debugLine="mapBedHeatingOptions.Put(\"** Bed Off **\",\"bedoff\"";
_mapbedheatingoptions.Put((Object)("** Bed Off **"),(Object)("bedoff"));
 //BA.debugLineNum = 369;BA.debugLine="mapBedHeatValuesOnly.Put(\"Bed Off\",\"bedoff\")";
_mapbedheatvaluesonly.Put((Object)("Bed Off"),(Object)("bedoff"));
 //BA.debugLineNum = 371;BA.debugLine="mapToolHeatingOptions.Put(allOff,\"alloff\")";
_maptoolheatingoptions.Put((Object)(_alloff),(Object)("alloff"));
 //BA.debugLineNum = 372;BA.debugLine="mapToolHeatingOptions.Put(\"** Tool Off **\",\"toolo";
_maptoolheatingoptions.Put((Object)("** Tool Off **"),(Object)("tooloff"));
 //BA.debugLineNum = 373;BA.debugLine="mapToolHeatValuesOnly.Put(\"Tool Off\",\"tooloff\")";
_maptoolheatvaluesonly.Put((Object)("Tool Off"),(Object)("tooloff"));
 //BA.debugLineNum = 375;BA.debugLine="mapAllHeatingOptions.Put(allOff,\"alloff\")";
_mapallheatingoptions.Put((Object)(_alloff),(Object)("alloff"));
 //BA.debugLineNum = 377;BA.debugLine="Dim s As String";
_s = "";
 //BA.debugLineNum = 378;BA.debugLine="Dim FilamentType As String";
_filamenttype = "";
 //BA.debugLineNum = 379;BA.debugLine="Dim tmp,ToolTemp As String";
_tmp = "";
_tooltemp = "";
 //BA.debugLineNum = 380;BA.debugLine="Dim BedTemp As String";
_bedtemp = "";
 //BA.debugLineNum = 382;BA.debugLine="Try";
try { //BA.debugLineNum = 383;BA.debugLine="For x  = 0 To mapOfOptions.Size - 1";
{
final int step19 = 1;
final int limit19 = (int) (_mapofoptions.getSize()-1);
_x = (int) (0) ;
for (;_x <= limit19 ;_x = _x + step19 ) {
 //BA.debugLineNum = 385;BA.debugLine="FilamentType = mapOfOptions.GetKeyAt(x)";
_filamenttype = BA.ObjectToString(_mapofoptions.GetKeyAt(_x));
 //BA.debugLineNum = 386;BA.debugLine="tmp = mapOfOptions.GetValueAt(x)";
_tmp = BA.ObjectToString(_mapofoptions.GetValueAt(_x));
 //BA.debugLineNum = 387;BA.debugLine="ToolTemp = Regex.Split(\"!!\",tmp)(0)";
_tooltemp = __c.Regex.Split("!!",_tmp)[(int) (0)];
 //BA.debugLineNum = 388;BA.debugLine="BedTemp = Regex.Split(\"!!\",tmp)(1)";
_bedtemp = __c.Regex.Split("!!",_tmp)[(int) (1)];
 //BA.debugLineNum = 391;BA.debugLine="s = $\"Set ${FilamentType} (Tool: ${ToolTemp}${g";
_s = ("Set "+__c.SmartStringFormatter("",(Object)(_filamenttype))+" (Tool: "+__c.SmartStringFormatter("",(Object)(_tooltemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C )");
 //BA.debugLineNum = 392;BA.debugLine="mapToolHeatingOptions.Put(s,s)";
_maptoolheatingoptions.Put((Object)(_s),(Object)(_s));
 //BA.debugLineNum = 393;BA.debugLine="mapToolHeatValuesOnly.Put($\"${ToolTemp}${gblCon";
_maptoolheatvaluesonly.Put((Object)((""+__c.SmartStringFormatter("",(Object)(_tooltemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"")),(Object)(_tooltemp));
 //BA.debugLineNum = 396;BA.debugLine="If BedTemp <> 0 Then";
if ((_bedtemp).equals(BA.NumberToString(0)) == false) { 
 //BA.debugLineNum = 397;BA.debugLine="s = $\"Set ${FilamentType} (Bed: ${BedTemp}${gb";
_s = ("Set "+__c.SmartStringFormatter("",(Object)(_filamenttype))+" (Bed: "+__c.SmartStringFormatter("",(Object)(_bedtemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C )");
 //BA.debugLineNum = 398;BA.debugLine="mapBedHeatingOptions.Put(s,s)";
_mapbedheatingoptions.Put((Object)(_s),(Object)(_s));
 //BA.debugLineNum = 399;BA.debugLine="mapBedHeatValuesOnly.Put($\"${BedTemp}${gblCons";
_mapbedheatvaluesonly.Put((Object)((""+__c.SmartStringFormatter("",(Object)(_bedtemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"")),(Object)(_bedtemp));
 };
 //BA.debugLineNum = 402;BA.debugLine="s = $\"Set ${FilamentType} (Tool: ${ToolTemp}${g";
_s = ("Set "+__c.SmartStringFormatter("",(Object)(_filamenttype))+" (Tool: "+__c.SmartStringFormatter("",(Object)(_tooltemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C  / Bed: "+__c.SmartStringFormatter("",(Object)(_bedtemp))+""+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C )");
 //BA.debugLineNum = 403;BA.debugLine="mapAllHeatingOptions.Put(s,s)";
_mapallheatingoptions.Put((Object)(_s),(Object)(_s));
 }
};
 //BA.debugLineNum = 407;BA.debugLine="mapToolHeatValuesOnly.Put(\"Enter Value\",\"ev\")";
_maptoolheatvaluesonly.Put((Object)("Enter Value"),(Object)("ev"));
 //BA.debugLineNum = 408;BA.debugLine="mapBedHeatValuesOnly.Put(\"Enter Value\",\"ev\")";
_mapbedheatvaluesonly.Put((Object)("Enter Value"),(Object)("ev"));
 } 
       catch (Exception e38) {
			ba.setLastException(e38); //BA.debugLineNum = 412;BA.debugLine="logMe.LogIt2(LastException,mModule,\"Build_Preset";
_logme._logit2 /*String*/ (ba,BA.ObjectToString(__c.LastException(ba)),_mmodule,"Build_PresetHeaterOption");
 };
 //BA.debugLineNum = 416;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private Const mModule As String = \"MasterControll";
_mmodule = "MasterController";
 //BA.debugLineNum = 4;BA.debugLine="Private mEventNameTemp As String";
_meventnametemp = "";
 //BA.debugLineNum = 5;BA.debugLine="Private mEventNameStatus As String";
_meventnamestatus = "";
 //BA.debugLineNum = 6;BA.debugLine="Private mEventNameBtns As String";
_meventnamebtns = "";
 //BA.debugLineNum = 7;BA.debugLine="Private mCallBack As Object = Null";
_mcallback = __c.Null;
 //BA.debugLineNum = 8;BA.debugLine="Private mainObj As B4XMainPage 'ignore";
_mainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private oCN As HttpOctoRestAPI";
_ocn = new sadLogic.OctoTouchController.foss.httpoctorestapi();
 //BA.debugLineNum = 11;BA.debugLine="Public parser As JsonParsorMain";
_parser = new sadLogic.OctoTouchController.foss.jsonparsormain();
 //BA.debugLineNum = 12;BA.debugLine="Public oWS As OctoWebSocket";
_ows = new sadLogic.OctoTouchController.foss.octowebsocket();
 //BA.debugLineNum = 16;BA.debugLine="Public gMapOctoFilesList As Map";
_gmapoctofileslist = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 18;BA.debugLine="Private mapMasterOctoTempSettings As Map";
_mapmasteroctotempsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 21;BA.debugLine="Private mGotProfileInfoFLAG As Boolean = False";
_mgotprofileinfoflag = __c.False;
 //BA.debugLineNum = 22;BA.debugLine="Private mGotProfileInfoFLAG_IsBusy As Boolean = F";
_mgotprofileinfoflag_isbusy = __c.False;
 //BA.debugLineNum = 24;BA.debugLine="Private mGotOctoSettingFLAG As Boolean = False";
_mgotoctosettingflag = __c.False;
 //BA.debugLineNum = 25;BA.debugLine="Private mGotOctoSettingFLAG_IsBusy As Boolean = F";
_mgotoctosettingflag_isbusy = __c.False;
 //BA.debugLineNum = 27;BA.debugLine="Private mGotFilesListFLAG As Boolean = False";
_mgotfileslistflag = __c.False;
 //BA.debugLineNum = 28;BA.debugLine="Private mGotFilesListFLAG_IsBusy As Boolean = Fal";
_mgotfileslistflag_isbusy = __c.False;
 //BA.debugLineNum = 32;BA.debugLine="Public mapBedHeatingOptions, mapToolHeatingOption";
_mapbedheatingoptions = new anywheresoftware.b4a.objects.collections.Map();
_maptoolheatingoptions = new anywheresoftware.b4a.objects.collections.Map();
_mapallheatingoptions = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 33;BA.debugLine="Public mapToolHeatValuesOnly,mapBedHeatValuesOnly";
_maptoolheatvaluesonly = new anywheresoftware.b4a.objects.collections.Map();
_mapbedheatvaluesonly = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 36;BA.debugLine="Private csHdr As CSBuilder";
_cshdr = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 37;BA.debugLine="Private bedImg,toolImg As B4XBitmap";
_bedimg = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_toolimg = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private sizeHdrPic As Float";
_sizehdrpic = 0f;
 //BA.debugLineNum = 41;BA.debugLine="Private mGetTempFLAG_Busy, mJobStatusFLAG_Busy As";
_mgettempflag_busy = false;
_mjobstatusflag_busy = __c.False;
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _download_thumbnailandcache2file(String _jobfilename,String _outfilename) throws Exception{
String _link = "";
 //BA.debugLineNum = 433;BA.debugLine="public Sub Download_ThumbnailAndCache2File(JobFile";
 //BA.debugLineNum = 435;BA.debugLine="Try";
try { //BA.debugLineNum = 437;BA.debugLine="Dim link As String";
_link = "";
 //BA.debugLineNum = 439;BA.debugLine="link  = $\"http://${oc.OctoIp}:${oc.OctoPort}/\"$";
_link = ("http://"+__c.SmartStringFormatter("",(Object)(_oc._octoip /*String*/ ))+":"+__c.SmartStringFormatter("",(Object)(_oc._octoport /*String*/ ))+"/")+_jobfilename;
 //BA.debugLineNum = 441;BA.debugLine="oCN.Download_AndSaveFile(link,outFileName)";
_ocn._download_andsavefile /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_link,_outfilename);
 } 
       catch (Exception e6) {
			ba.setLastException(e6); //BA.debugLineNum = 446;BA.debugLine="logMe.LogIt2(LastException,mModule,\"Download_Thu";
_logme._logit2 /*String*/ (ba,BA.ObjectToString(__c.LastException(ba)),_mmodule,"Download_ThumbnailAndCache2File");
 };
 //BA.debugLineNum = 451;BA.debugLine="End Sub";
return "";
}
public void  _get_jobstatus() throws Exception{
ResumableSub_Get_JobStatus rsub = new ResumableSub_Get_JobStatus(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Get_JobStatus extends BA.ResumableSub {
public ResumableSub_Get_JobStatus(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
String _jobinfo = "";
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 231;BA.debugLine="If mJobStatusFLAG_Busy = True Then Return '--- st";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._mjobstatusflag_busy==parent.__c.True) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 232;BA.debugLine="mJobStatusFLAG_Busy = True";
parent._mjobstatusflag_busy = parent.__c.True;
 //BA.debugLineNum = 235;BA.debugLine="Dim jobInfo As String =  \"/api/job\"";
_jobinfo = "/api/job";
 //BA.debugLineNum = 237;BA.debugLine="Dim rs As ResumableSub =  oCN.SendRequestGetInfo(";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_jobinfo);
 //BA.debugLineNum = 238;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 29;
return;
case 29:
//C
this.state = 7;
_result = (String) result[0];
;
 //BA.debugLineNum = 239;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 7:
//if
this.state = 12;
if (_result.length()!=0) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 240;BA.debugLine="parser.JobStatus(Result)";
parent._parser._jobstatus /*String*/ (_result);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 242;BA.debugLine="oc.ResetJobVars";
parent._oc._resetjobvars /*String*/ (ba);
 if (true) break;
;
 //BA.debugLineNum = 246;BA.debugLine="If mCallBack <> Null Then CallSub(mCallBack,mEven";

case 12:
//if
this.state = 17;
if (parent._mcallback!= null) { 
this.state = 14;
;}if (true) break;

case 14:
//C
this.state = 17;
parent.__c.CallSubNew(ba,parent._mcallback,parent._meventnamebtns);
if (true) break;

case 17:
//C
this.state = 18;
;
 //BA.debugLineNum = 248;BA.debugLine="oc.FormatedJobPct = IIf(oc.isPrinting = True And";
parent._oc._formatedjobpct /*String*/  = BA.ObjectToString(((parent._oc._isprinting /*boolean*/ ==parent.__c.True && parent._oc._isheating /*boolean*/ ==parent.__c.False) ? ((Object)(parent._fnc._roundjobpctnodecimals /*String*/ (ba,parent._oc._jobcompletion /*String*/ ))) : ((Object)(""))));
 //BA.debugLineNum = 249;BA.debugLine="If oc.JobPrintState = \"Printing\" Then";
if (true) break;

case 18:
//if
this.state = 23;
if ((parent._oc._jobprintstate /*String*/ ).equals("Printing")) { 
this.state = 20;
}else {
this.state = 22;
}if (true) break;

case 20:
//C
this.state = 23;
 //BA.debugLineNum = 250;BA.debugLine="oc.FormatedStatus = oc.JobPrintState & \" \" & oc.";
parent._oc._formatedstatus /*String*/  = parent._oc._jobprintstate /*String*/ +" "+parent._oc._formatedjobpct /*String*/ ;
 if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 252;BA.debugLine="oc.FormatedStatus = oc.JobPrintState";
parent._oc._formatedstatus /*String*/  = parent._oc._jobprintstate /*String*/ ;
 if (true) break;
;
 //BA.debugLineNum = 256;BA.debugLine="If mCallBack <> Null Then CallSub(mCallBack,mEven";

case 23:
//if
this.state = 28;
if (parent._mcallback!= null) { 
this.state = 25;
;}if (true) break;

case 25:
//C
this.state = 28;
parent.__c.CallSubNew(ba,parent._mcallback,parent._meventnamestatus);
if (true) break;

case 28:
//C
this.state = -1;
;
 //BA.debugLineNum = 258;BA.debugLine="mJobStatusFLAG_Busy = False";
parent._mjobstatusflag_busy = parent.__c.False;
 //BA.debugLineNum = 260;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _result) throws Exception{
}
public void  _getalloctofilesinfo() throws Exception{
ResumableSub_GetAllOctoFilesInfo rsub = new ResumableSub_GetAllOctoFilesInfo(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GetAllOctoFilesInfo extends BA.ResumableSub {
public ResumableSub_GetAllOctoFilesInfo(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparserfiles _o = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 323;BA.debugLine="If mGotFilesListFLAG_IsBusy = True Then";
if (true) break;

case 1:
//if
this.state = 10;
if (parent._mgotfileslistflag_isbusy==parent.__c.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 324;BA.debugLine="If config.logFILE_EVENTS Then logMe.Logit(\"mGotF";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
parent._logme._logit /*String*/ (ba,"mGotFilesListFLAG_IsBusy = True",parent._mmodule);
if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 325;BA.debugLine="Return '---already been called";
if (true) return ;
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 328;BA.debugLine="mGotFilesListFLAG_IsBusy = True";
parent._mgotfileslistflag_isbusy = parent.__c.True;
 //BA.debugLineNum = 330;BA.debugLine="Dim rs As ResumableSub =  oCN.SendRequestGetInfo(";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cfiles /*String*/ );
 //BA.debugLineNum = 332;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 17;
return;
case 17:
//C
this.state = 11;
_result = (String) result[0];
;
 //BA.debugLineNum = 333;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 11:
//if
this.state = 16;
if (_result.length()!=0) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 334;BA.debugLine="gMapOctoFilesList.Initialize";
parent._gmapoctofileslist.Initialize();
 //BA.debugLineNum = 336;BA.debugLine="Dim o As JsonParserFiles";
_o = new sadLogic.OctoTouchController.foss.jsonparserfiles();
 //BA.debugLineNum = 337;BA.debugLine="o.Initialize(True) '--- download thumbnails";
_o._initialize /*String*/ (ba,parent.__c.True);
 //BA.debugLineNum = 338;BA.debugLine="gMapOctoFilesList = o.StartParseAllFilesOcto(Res";
parent._gmapoctofileslist = _o._startparseallfilesocto /*anywheresoftware.b4a.objects.collections.Map*/ (_result);
 //BA.debugLineNum = 339;BA.debugLine="mGotFilesListFLAG = True '--- will stop it from";
parent._mgotfileslistflag = parent.__c.True;
 if (true) break;

case 15:
//C
this.state = 16;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 347;BA.debugLine="mGotFilesListFLAG_IsBusy = False '--- reset the i";
parent._mgotfileslistflag_isbusy = parent.__c.False;
 //BA.debugLineNum = 350;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _getallprintersettings() throws Exception{
ResumableSub_GetAllPrinterSettings rsub = new ResumableSub_GetAllPrinterSettings(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GetAllPrinterSettings extends BA.ResumableSub {
public ResumableSub_GetAllPrinterSettings(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparsermasterprintersettings _o = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 122;BA.debugLine="If mGotOctoSettingFLAG_IsBusy = True Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._mgotoctosettingflag_isbusy==parent.__c.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 123;BA.debugLine="logMe.logDebug2(\"mGotOctoSettingFLAG_IsBusy = Tr";
parent._logme._logdebug2 /*String*/ (ba,"mGotOctoSettingFLAG_IsBusy = True",parent._mmodule);
 //BA.debugLineNum = 124;BA.debugLine="Return '---already been called";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 127;BA.debugLine="mGotOctoSettingFLAG_IsBusy = True ' TODO KLIPPER";
parent._mgotoctosettingflag_isbusy = parent.__c.True;
 //BA.debugLineNum = 130;BA.debugLine="Dim rs As ResumableSub =  oCN.SendRequestGetInfo(";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("/api/settings");
 //BA.debugLineNum = 132;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 11;
return;
case 11:
//C
this.state = 5;
_result = (String) result[0];
;
 //BA.debugLineNum = 133;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_result.length()!=0) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 135;BA.debugLine="Dim o As JsonParserMasterPrinterSettings  : o.In";
_o = new sadLogic.OctoTouchController.foss.jsonparsermasterprintersettings();
 //BA.debugLineNum = 135;BA.debugLine="Dim o As JsonParserMasterPrinterSettings  : o.In";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 136;BA.debugLine="mapMasterOctoTempSettings.Initialize";
parent._mapmasteroctotempsettings.Initialize();
 //BA.debugLineNum = 137;BA.debugLine="mapMasterOctoTempSettings = o.GetPresetHeaterSet";
parent._mapmasteroctotempsettings = _o._getpresetheatersettings /*anywheresoftware.b4a.objects.collections.Map*/ (_result);
 //BA.debugLineNum = 138;BA.debugLine="mGotOctoSettingFLAG = True '--- will stop it fro";
parent._mgotoctosettingflag = parent.__c.True;
 //BA.debugLineNum = 140;BA.debugLine="Build_PresetHeaterOption(mapMasterOctoTempSettin";
parent._build_presetheateroption(parent._mapmasteroctotempsettings);
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 145;BA.debugLine="oc.RestPrinterProfileVars";
parent._oc._restprinterprofilevars /*String*/ (ba);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 150;BA.debugLine="mGotOctoSettingFLAG_IsBusy = False";
parent._mgotoctosettingflag_isbusy = parent.__c.False;
 //BA.debugLineNum = 152;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public sadLogic.OctoTouchController.foss.httpoctorestapi  _getcn() throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Public Sub getCN() As HttpOctoRestAPI";
 //BA.debugLineNum = 47;BA.debugLine="If oCN.IsInitialized = False Then";
if (_ocn.IsInitialized /*boolean*/ ()==__c.False) { 
 //BA.debugLineNum = 48;BA.debugLine="GetConnectionPrinterStatus";
_getconnectionprinterstatus();
 };
 //BA.debugLineNum = 50;BA.debugLine="Return oCN";
if (true) return _ocn;
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public void  _getconnectionprinterstatus() throws Exception{
ResumableSub_GetConnectionPrinterStatus rsub = new ResumableSub_GetConnectionPrinterStatus(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GetConnectionPrinterStatus extends BA.ResumableSub {
public ResumableSub_GetConnectionPrinterStatus(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparsorconnectionstatus _o2 = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 271;BA.debugLine="If oCN.IsInitialized = False And oc.OctoIp <> \"\"";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._ocn.IsInitialized /*boolean*/ ()==parent.__c.False && (parent._oc._octoip /*String*/ ).equals("") == false) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 272;BA.debugLine="oCN.Initialize";
parent._ocn._initialize /*String*/ (ba);
 if (true) break;
;
 //BA.debugLineNum = 274;BA.debugLine="If oc.OctoIp = \"\" Then Return '--- trying to init";

case 4:
//if
this.state = 9;
if ((parent._oc._octoip /*String*/ ).equals("")) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
if (true) return ;
if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 276;BA.debugLine="Try";
if (true) break;

case 10:
//try
this.state = 19;
this.catchState = 18;
this.state = 12;
if (true) break;

case 12:
//C
this.state = 13;
this.catchState = 18;
 //BA.debugLineNum = 277;BA.debugLine="If oWS.IsInit = False Or oWS.pConnected = False";
if (true) break;

case 13:
//if
this.state = 16;
if (parent._ows._isinit /*boolean*/ ==parent.__c.False || parent._ows._pconnected /*boolean*/ ==parent.__c.False) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 278;BA.debugLine="InitWebSocket";
parent._initwebsocket();
 if (true) break;

case 16:
//C
this.state = 19;
;
 if (true) break;

case 18:
//C
this.state = 19;
this.catchState = 0;
 //BA.debugLineNum = 282;BA.debugLine="oWS.Initialize";
parent._ows._initialize /*sadLogic.OctoTouchController.foss.octowebsocket*/ (ba);
 //BA.debugLineNum = 283;BA.debugLine="InitWebSocket";
parent._initwebsocket();
 if (true) break;
if (true) break;

case 19:
//C
this.state = 20;
this.catchState = 0;
;
 //BA.debugLineNum = 289;BA.debugLine="Dim rs As ResumableSub = oCN.PostRequest(oc.cCMD_";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_auto_connect_startup /*String*/ );
 //BA.debugLineNum = 290;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 26;
return;
case 26:
//C
this.state = 20;
_result = (String) result[0];
;
 //BA.debugLineNum = 293;BA.debugLine="Dim rs As ResumableSub = oCN.SendRequestGetInfo(o";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cconnection_info /*String*/ );
 //BA.debugLineNum = 294;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 27;
return;
case 27:
//C
this.state = 20;
_result = (String) result[0];
;
 //BA.debugLineNum = 295;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 20:
//if
this.state = 25;
if (_result.length()!=0) { 
this.state = 22;
}else {
this.state = 24;
}if (true) break;

case 22:
//C
this.state = 25;
 //BA.debugLineNum = 297;BA.debugLine="Dim o2 As JsonParsorConnectionStatus";
_o2 = new sadLogic.OctoTouchController.foss.jsonparsorconnectionstatus();
 //BA.debugLineNum = 298;BA.debugLine="o2.Initialize";
_o2._initialize /*String*/ (ba);
 //BA.debugLineNum = 299;BA.debugLine="o2.ConnectionStatus(Result)";
_o2._connectionstatus /*String*/ (_result);
 //BA.debugLineNum = 302;BA.debugLine="CallSub2(Main,\"TurnOnOff_MainTmr\",True)";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"TurnOnOff_MainTmr",(Object)(parent.__c.True));
 //BA.debugLineNum = 303;BA.debugLine="tmrMain_Tick";
parent._tmrmain_tick();
 if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 306;BA.debugLine="oc.ResetStateVars";
parent._oc._resetstatevars /*String*/ (ba);
 if (true) break;

case 25:
//C
this.state = -1;
;
 //BA.debugLineNum = 311;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _getprinterprofileinfo() throws Exception{
ResumableSub_GetPrinterProfileInfo rsub = new ResumableSub_GetPrinterProfileInfo(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GetPrinterProfileInfo extends BA.ResumableSub {
public ResumableSub_GetPrinterProfileInfo(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
String _sendme = "";
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparsermasterprintersettings _o = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 157;BA.debugLine="If oc.PrinterProfile.Length = 0 Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._oc._printerprofile /*String*/ .length()==0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 159;BA.debugLine="If mGotProfileInfoFLAG_IsBusy = True Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._mgotprofileinfoflag_isbusy==parent.__c.True) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 160;BA.debugLine="logMe.logDebug2(\"mGotProfileInfoFLAG_IsBusy = Tr";
parent._logme._logdebug2 /*String*/ (ba,"mGotProfileInfoFLAG_IsBusy = True",parent._mmodule);
 //BA.debugLineNum = 161;BA.debugLine="Return '---already been called";
if (true) return ;
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 164;BA.debugLine="mGotProfileInfoFLAG_IsBusy = True";
parent._mgotprofileinfoflag_isbusy = parent.__c.True;
 //BA.debugLineNum = 166;BA.debugLine="Dim sendMe As String = oc.cPRINTER_PROFILES & \"\\\"";
_sendme = parent._oc._cprinter_profiles /*String*/ +"\\"+parent._oc._printerprofile /*String*/ ;
 //BA.debugLineNum = 167;BA.debugLine="Dim rs As ResumableSub =  oCN.SendRequestGetInfo(";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_sendme);
 //BA.debugLineNum = 169;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 17;
return;
case 17:
//C
this.state = 11;
_result = (String) result[0];
;
 //BA.debugLineNum = 170;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 11:
//if
this.state = 16;
if (_result.length()!=0) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 172;BA.debugLine="Dim o As JsonParserMasterPrinterSettings : o.Ini";
_o = new sadLogic.OctoTouchController.foss.jsonparsermasterprintersettings();
 //BA.debugLineNum = 172;BA.debugLine="Dim o As JsonParserMasterPrinterSettings : o.Ini";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 173;BA.debugLine="o.ParsePrinterProfile(Result)";
_o._parseprinterprofile /*String*/ (_result);
 //BA.debugLineNum = 174;BA.debugLine="mGotProfileInfoFLAG = True '--- will stop it fro";
parent._mgotprofileinfoflag = parent.__c.True;
 //BA.debugLineNum = 175;BA.debugLine="mGotProfileInfoFLAG_IsBusy = False";
parent._mgotprofileinfoflag_isbusy = parent.__c.False;
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 179;BA.debugLine="logMe.LogIt2(\"reseting vars\",mModule,\"GetPrinter";
parent._logme._logit2 /*String*/ (ba,"reseting vars",parent._mmodule,"GetPrinterProfileInfo");
 //BA.debugLineNum = 180;BA.debugLine="oc.RestPrinterProfileVars";
parent._oc._restprinterprofilevars /*String*/ (ba);
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _gettemps() throws Exception{
ResumableSub_GetTemps rsub = new ResumableSub_GetTemps(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GetTemps extends BA.ResumableSub {
public ResumableSub_GetTemps(sadLogic.OctoTouchController.foss.mastercontroller parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.mastercontroller parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 195;BA.debugLine="If mGetTempFLAG_Busy = True Then Return '--- stop";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._mgettempflag_busy==parent.__c.True) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 196;BA.debugLine="mGetTempFLAG_Busy = True";
parent._mgettempflag_busy = parent.__c.True;
 //BA.debugLineNum = 198;BA.debugLine="Dim rs As ResumableSub =  oCN.SendRequestGetInfo(";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._ocn._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cprinter_master_state /*String*/ );
 //BA.debugLineNum = 200;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 13;
return;
case 13:
//C
this.state = 7;
_result = (String) result[0];
;
 //BA.debugLineNum = 201;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 7:
//if
this.state = 12;
if (_result.length()!=0) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 202;BA.debugLine="parser.TempStatus(Result)";
parent._parser._tempstatus /*String*/ (_result);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 204;BA.debugLine="oc.ResetTempVars";
parent._oc._resettempvars /*String*/ (ba);
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 210;BA.debugLine="oc.FormatedTemps = csHdr.Initialize.Image(toolImg";
parent._oc._formatedtemps /*Object*/  = (Object)(parent._cshdr.Initialize().Image((android.graphics.Bitmap)(parent._toolimg.getObject()),(int) (parent._sizehdrpic),(int) (parent._sizehdrpic),parent.__c.False).Append(BA.ObjectToCharSequence((" "+parent.__c.SmartStringFormatter("",(Object)(parent._oc._tool1actual /*String*/ .replace("C","")))+" / "+parent.__c.SmartStringFormatter("",(((parent._oc._tool1target /*String*/ ).equals(("0"+parent.__c.SmartStringFormatter("",(Object)(parent._gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off ")) : ((Object)(parent._oc._tool1target /*String*/ .replace("C","")))))+""))).Append(BA.ObjectToCharSequence("   ")).Image((android.graphics.Bitmap)(parent._bedimg.getObject()),(int) (parent._sizehdrpic),(int) (parent._sizehdrpic),parent.__c.False).Append(BA.ObjectToCharSequence((" "+parent.__c.SmartStringFormatter("",(Object)(parent._oc._bedactual /*String*/ .replace("C","")))+" / "+parent.__c.SmartStringFormatter("",(((parent._oc._bedtarget /*String*/ ).equals(("0"+parent.__c.SmartStringFormatter("",(Object)(parent._gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off")) : ((Object)(parent._oc._bedtarget /*String*/ .replace("C","")))))+""))).PopAll().getObject());
 //BA.debugLineNum = 215;BA.debugLine="CallSub(mCallBack,mEventNameTemp)";
parent.__c.CallSubNew(ba,parent._mcallback,parent._meventnametemp);
 //BA.debugLineNum = 217;BA.debugLine="mGetTempFLAG_Busy = False";
parent._mgettempflag_busy = parent.__c.False;
 //BA.debugLineNum = 219;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 56;BA.debugLine="mainObj = B4XPages.MainPage";
_mainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 57;BA.debugLine="parser.Initialize() '--- init the rest parser";
_parser._initialize /*String*/ (ba);
 //BA.debugLineNum = 60;BA.debugLine="sizeHdrPic = IIf(guiHelpers.gIsLandScape,32dip,24";
_sizehdrpic = (float)(BA.ObjectToNumber(((_guihelpers._gislandscape /*boolean*/ ) ? ((Object)(__c.DipToCurrent((int) (32)))) : ((Object)(__c.DipToCurrent((int) (24)))))));
 //BA.debugLineNum = 61;BA.debugLine="bedImg.IsInitialized";
_bedimg.IsInitialized();
 //BA.debugLineNum = 62;BA.debugLine="bedImg = guiHelpers.ChangeColorBasedOnAlphaLevel(";
_bedimg = _guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapSample(__c.File.getDirAssets(),"bed_header.png",(int) (_sizehdrpic),(int) (_sizehdrpic)).getObject())),_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 64;BA.debugLine="toolImg.IsInitialized";
_toolimg.IsInitialized();
 //BA.debugLineNum = 65;BA.debugLine="toolImg = guiHelpers.ChangeColorBasedOnAlphaLevel";
_toolimg = _guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapSample(__c.File.getDirAssets(),"hotend_header.png",(int) (_sizehdrpic),(int) (_sizehdrpic)).getObject())),_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public String  _initwebsocket() throws Exception{
 //BA.debugLineNum = 262;BA.debugLine="Private Sub InitWebSocket'ignore";
 //BA.debugLineNum = 263;BA.debugLine="oWS.Initialize";
_ows._initialize /*sadLogic.OctoTouchController.foss.octowebsocket*/ (ba);
 //BA.debugLineNum = 264;BA.debugLine="oWS.Connect_Socket";
_ows._connect_socket /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ();
 //BA.debugLineNum = 265;BA.debugLine="End Sub";
return "";
}
public boolean  _isincompletefiledata() throws Exception{
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _o = null;
 //BA.debugLineNum = 456;BA.debugLine="Public Sub IsIncompleteFileData() As Boolean";
 //BA.debugLineNum = 457;BA.debugLine="For Each o As tOctoFileInfo In gMapOctoFilesList.";
{
final anywheresoftware.b4a.BA.IterableList group1 = _gmapoctofileslist.Values();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(group1.Get(index1));
 //BA.debugLineNum = 458;BA.debugLine="If o.missingData Then";
if (_o.missingData /*boolean*/ ) { 
 //BA.debugLineNum = 459;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt(\"Inco";
if (_config._logfile_events /*boolean*/ ) { 
_logme._logit /*String*/ (ba,"Incomplete data in files array",_mmodule);};
 //BA.debugLineNum = 461;BA.debugLine="Return True";
if (true) return __c.True;
 };
 }
};
 //BA.debugLineNum = 465;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 466;BA.debugLine="End Sub";
return false;
}
public String  _setcallbacktargets(Object _callback,String _eventnametemp,String _eventnamestatus,String _eventnamebtns) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Public Sub SetCallbackTargets(CallBack As Object,E";
 //BA.debugLineNum = 78;BA.debugLine="mEventNameTemp = EventNameTemp";
_meventnametemp = _eventnametemp;
 //BA.debugLineNum = 79;BA.debugLine="mEventNameStatus = EventNameStatus";
_meventnamestatus = _eventnamestatus;
 //BA.debugLineNum = 80;BA.debugLine="mEventNameBtns = EventNameBtns";
_meventnamebtns = _eventnamebtns;
 //BA.debugLineNum = 81;BA.debugLine="mCallBack = CallBack";
_mcallback = _callback;
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _start() throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Public Sub Start";
 //BA.debugLineNum = 71;BA.debugLine="GetConnectionPrinterStatus";
_getconnectionprinterstatus();
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public String  _tmrmain_tick() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Public Sub tmrMain_Tick";
 //BA.debugLineNum = 93;BA.debugLine="If mGotProfileInfoFLAG = False And mGotProfileInf";
if (_mgotprofileinfoflag==__c.False && _mgotprofileinfoflag_isbusy==__c.False) { 
 //BA.debugLineNum = 94;BA.debugLine="GetPrinterProfileInfo";
_getprinterprofileinfo();
 };
 //BA.debugLineNum = 98;BA.debugLine="If mGotOctoSettingFLAG = False And mGotOctoSettin";
if (_mgotoctosettingflag==__c.False && _mgotoctosettingflag_isbusy==__c.False) { 
 //BA.debugLineNum = 99;BA.debugLine="GetAllPrinterSettings";
_getallprintersettings();
 };
 //BA.debugLineNum = 103;BA.debugLine="If mGotFilesListFLAG = False And  mGotFilesListFL";
if (_mgotfileslistflag==__c.False && _mgotfileslistflag_isbusy==__c.False) { 
 //BA.debugLineNum = 104;BA.debugLine="GetAllOctoFilesInfo";
_getalloctofilesinfo();
 };
 //BA.debugLineNum = 110;BA.debugLine="GetTemps";
_gettemps();
 //BA.debugLineNum = 111;BA.debugLine="Get_JobStatus";
_get_jobstatus();
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "DOWNLOAD_THUMBNAILANDCACHE2FILE"))
	return _download_thumbnailandcache2file((String) args[0], (String) args[1]);
if (BA.fastSubCompare(sub, "START"))
	return _start();
if (BA.fastSubCompare(sub, "TMRMAIN_TICK"))
	return _tmrmain_tick();
return BA.SubDelegator.SubNotFound;
}
}
