package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class prompt4folder extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.prompt4folder");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.prompt4folder.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _ion = null;
public Object _callback = null;
public String _pselectedfolder = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 18;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 19;BA.debugLine="Private Ion As Object";
_ion = new Object();
 //BA.debugLineNum = 20;BA.debugLine="Private callback As Object";
_callback = new Object();
 //BA.debugLineNum = 21;BA.debugLine="Public pSelectedFolder As String = \"\"";
_pselectedfolder = "";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public Object  _getba() throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 71;BA.debugLine="Private Sub GetBA As Object";
 //BA.debugLineNum = 72;BA.debugLine="Dim jo As JavaObject = Me";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(this));
 //BA.debugLineNum = 73;BA.debugLine="Return jo.RunMethod(\"getBA\", Null)";
if (true) return _jo.RunMethod("getBA",(Object[])(__c.Null));
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public String  _handletreedirectorystring(String _tree) throws Exception{
String _storagepath = "";
String _realpath = "";
String _fullpath = "";
 //BA.debugLineNum = 95;BA.debugLine="Private Sub HandleTreeDirectoryString(Tree As Stri";
 //BA.debugLineNum = 96;BA.debugLine="Dim StoragePath As String = Tree.SubString2(0,Tre";
_storagepath = _tree.substring((int) (0),_tree.indexOf("%3A"));
 //BA.debugLineNum = 97;BA.debugLine="StoragePath = StoragePath.Replace(\"content://com.";
_storagepath = _storagepath.replace("content://com.android.externalstorage.documents/tree","")+"/";
 //BA.debugLineNum = 98;BA.debugLine="Dim RealPath As String = Tree.SubString2(Tree.Ind";
_realpath = _tree.substring(_tree.indexOf("%3A"),_tree.length());
 //BA.debugLineNum = 99;BA.debugLine="RealPath = RealPath.Replace(\"%3A\", \"\") 'StartSlas";
_realpath = _realpath.replace("%3A","");
 //BA.debugLineNum = 100;BA.debugLine="RealPath = RealPath.Replace(\"%2F\",\"/\") 'NormalSla";
_realpath = _realpath.replace("%2F","/");
 //BA.debugLineNum = 101;BA.debugLine="Dim FullPath As String = \"/storage\" & StoragePath";
_fullpath = "/storage"+_storagepath+_realpath;
 //BA.debugLineNum = 102;BA.debugLine="Return FullPath";
if (true) return _fullpath;
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public Object  _ion_event(String _methodname,Object[] _args) throws Exception{
String _treedirectory = "";
anywheresoftware.b4a.objects.IntentWrapper _i = null;
 //BA.debugLineNum = 77;BA.debugLine="Private Sub ion_Event(MethodName As String, Args()";
 //BA.debugLineNum = 78;BA.debugLine="Dim TreeDirectory As String = \"\"";
_treedirectory = "";
 //BA.debugLineNum = 79;BA.debugLine="If -1 = Args(0) Then 'resultCode = RESULT_OK";
if (-1==(double)(BA.ObjectToNumber(_args[(int) (0)]))) { 
 //BA.debugLineNum = 80;BA.debugLine="Dim i As Intent = Args(1)";
_i = new anywheresoftware.b4a.objects.IntentWrapper();
_i = (anywheresoftware.b4a.objects.IntentWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.IntentWrapper(), (android.content.Intent)(_args[(int) (1)]));
 //BA.debugLineNum = 81;BA.debugLine="TreeDirectory = i.GetData";
_treedirectory = _i.GetData();
 //BA.debugLineNum = 82;BA.debugLine="pSelectedFolder = HandleTreeDirectoryString(Tree";
_pselectedfolder = _handletreedirectorystring(_treedirectory);
 }else {
 };
 //BA.debugLineNum = 87;BA.debugLine="Stump";
_stump();
 //BA.debugLineNum = 88;BA.debugLine="Return Null";
if (true) return __c.Null;
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return null;
}
public void  _selectextfolder(Object _callbackobj) throws Exception{
ResumableSub_SelectExtFolder rsub = new ResumableSub_SelectExtFolder(this,_callbackobj);
rsub.resume(ba, null);
}
public static class ResumableSub_SelectExtFolder extends BA.ResumableSub {
public ResumableSub_SelectExtFolder(sadLogic.HomeCentral.prompt4folder parent,Object _callbackobj) {
this.parent = parent;
this._callbackobj = _callbackobj;
}
sadLogic.HomeCentral.prompt4folder parent;
Object _callbackobj;
anywheresoftware.b4a.objects.IntentWrapper _i = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 54;BA.debugLine="callback = callbackOBJ";
parent._callback = _callbackobj;
 //BA.debugLineNum = 55;BA.debugLine="Dim i As Intent";
_i = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 56;BA.debugLine="i.Initialize(\"android.intent.action.OPEN_DOCUMENT";
_i.Initialize("android.intent.action.OPEN_DOCUMENT_TREE","");
 //BA.debugLineNum = 57;BA.debugLine="StartActivityForResult(i)";
parent._startactivityforresult(_i);
 //BA.debugLineNum = 58;BA.debugLine="Log(\"dddddddddddddd!!!!!!!!!!!!!!!!\")";
parent.__c.LogImpl("47906823","dddddddddddddd!!!!!!!!!!!!!!!!",0);
 //BA.debugLineNum = 59;BA.debugLine="Wait For Stump";
parent.__c.WaitFor("stump", ba, this, null);
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 60;BA.debugLine="Log(\"ddddddddddddddddddddddddddddddd\")";
parent.__c.LogImpl("47906825","ddddddddddddddddddddddddddddddd",0);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _startactivityforresult(anywheresoftware.b4a.objects.IntentWrapper _i) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 64;BA.debugLine="Private Sub StartActivityForResult(i As Intent)";
 //BA.debugLineNum = 65;BA.debugLine="Dim jo As JavaObject = GetBA";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_getba()));
 //BA.debugLineNum = 66;BA.debugLine="Ion = jo.CreateEvent(\"anywheresoftware.b4a.IOnAct";
_ion = _jo.CreateEvent(ba,"anywheresoftware.b4a.IOnActivityResult","ion",__c.Null);
 //BA.debugLineNum = 67;BA.debugLine="jo.RunMethod(\"startActivityForResult\", Array As O";
_jo.RunMethod("startActivityForResult",new Object[]{_ion,(Object)(_i.getObject())});
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public String  _stump() throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Private Sub Stump";
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
