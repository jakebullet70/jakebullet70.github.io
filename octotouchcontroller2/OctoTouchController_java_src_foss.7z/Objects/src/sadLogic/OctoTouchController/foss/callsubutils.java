package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class callsubutils extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.callsubutils");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.callsubutils.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.Map _rundelayed = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static class _rundelayeddata{
public boolean IsInitialized;
public Object Module;
public String SubName;
public Object[] Arg;
public boolean Delayed;
public void Initialize() {
IsInitialized = true;
Module = new Object();
SubName = "";
Arg = new Object[0];
{
int d0 = Arg.length;
for (int i0 = 0;i0 < d0;i0++) {
Arg[i0] = new Object();
}
}
;
Delayed = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _callsubdelayedplus(Object _module,String _subname,int _delay) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Public Sub CallSubDelayedPlus(Module As Object, Su";
 //BA.debugLineNum = 45;BA.debugLine="CallSubDelayedPlus2(Module, SubName, Delay, Null)";
_callsubdelayedplus2(_module,_subname,_delay,(Object[])(__c.Null));
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _callsubdelayedplus2(Object _module,String _subname,int _delay,Object[] _arg) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Public Sub CallSubDelayedPlus2(Module As Object, S";
 //BA.debugLineNum = 52;BA.debugLine="PlusImpl(Module, SubName, Delay, Arg, True)";
_plusimpl(_module,_subname,_delay,_arg,__c.True);
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public String  _callsubplus(Object _module,String _subname,int _delay) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Public Sub CallSubPlus(Module As Object, SubName A";
 //BA.debugLineNum = 58;BA.debugLine="CallSubPlus2(Module, SubName, Delay, Null)";
_callsubplus2(_module,_subname,_delay,(Object[])(__c.Null));
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _callsubplus2(Object _module,String _subname,int _delay,Object[] _arg) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Public Sub CallSubPlus2(Module As Object, SubName";
 //BA.debugLineNum = 65;BA.debugLine="PlusImpl(Module, SubName, Delay, Arg, False)";
_plusimpl(_module,_subname,_delay,_arg,__c.False);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Private RunDelayed As Map";
_rundelayed = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 11;BA.debugLine="Type RunDelayedData (Module As Object, SubName As";
;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.Timer  _exists(Object _module,String _subname) throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata _dt = null;
 //BA.debugLineNum = 27;BA.debugLine="Public Sub Exists(Module As Object, SubName As Str";
 //BA.debugLineNum = 29;BA.debugLine="For Each t As Timer In RunDelayed.Keys";
{
final anywheresoftware.b4a.BA.IterableList group1 = _rundelayed.Keys();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_t = (anywheresoftware.b4a.objects.Timer)(group1.Get(index1));
 //BA.debugLineNum = 30;BA.debugLine="Dim dt As RunDelayedData = RunDelayed.Get(t)";
_dt = (sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata)(_rundelayed.Get((Object)(_t)));
 //BA.debugLineNum = 31;BA.debugLine="If dt.SubName = SubName And dt.Module = Module T";
if ((_dt.SubName /*String*/ ).equals(_subname) && (_dt.Module /*Object*/ ).equals(_module)) { 
 //BA.debugLineNum = 32;BA.debugLine="Log(\"tmr already here\")";
__c.LogImpl("7929861","tmr already here",0);
 //BA.debugLineNum = 33;BA.debugLine="Return t";
if (true) return _t;
 };
 }
};
 //BA.debugLineNum = 36;BA.debugLine="Return Null";
if (true) return (anywheresoftware.b4a.objects.Timer)(__c.Null);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return null;
}
public String  _existsremove(Object _module,String _subname) throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
 //BA.debugLineNum = 18;BA.debugLine="Public Sub ExistsRemove(Module As Object, SubName";
 //BA.debugLineNum = 20;BA.debugLine="Dim t As Timer = Exists(Module,SubName)";
_t = _exists(_module,_subname);
 //BA.debugLineNum = 21;BA.debugLine="If t <> Null Then";
if (_t!= null) { 
 //BA.debugLineNum = 22;BA.debugLine="t.Enabled = False";
_t.setEnabled(__c.False);
 //BA.debugLineNum = 23;BA.debugLine="RunDelayed.Remove(t)";
_rundelayed.Remove((Object)(_t));
 };
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _plusimpl(Object _module,String _subname,int _delay,Object[] _arg,boolean _delayed) throws Exception{
anywheresoftware.b4a.objects.Timer _tmr = null;
sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata _rdd = null;
 //BA.debugLineNum = 68;BA.debugLine="Private Sub PlusImpl(Module As Object, SubName As";
 //BA.debugLineNum = 69;BA.debugLine="If RunDelayed.IsInitialized = False Then RunDelay";
if (_rundelayed.IsInitialized()==__c.False) { 
_rundelayed.Initialize();};
 //BA.debugLineNum = 70;BA.debugLine="Dim tmr As Timer";
_tmr = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 71;BA.debugLine="tmr.Initialize(\"tmr\", Delay)";
_tmr.Initialize(ba,"tmr",(long) (_delay));
 //BA.debugLineNum = 72;BA.debugLine="Dim rdd As RunDelayedData";
_rdd = new sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata();
 //BA.debugLineNum = 73;BA.debugLine="rdd.Module = Module";
_rdd.Module /*Object*/  = _module;
 //BA.debugLineNum = 74;BA.debugLine="rdd.SubName = SubName";
_rdd.SubName /*String*/  = _subname;
 //BA.debugLineNum = 75;BA.debugLine="rdd.Arg = Arg";
_rdd.Arg /*Object[]*/  = _arg;
 //BA.debugLineNum = 76;BA.debugLine="rdd.delayed = delayed";
_rdd.Delayed /*boolean*/  = _delayed;
 //BA.debugLineNum = 77;BA.debugLine="RunDelayed.Put(tmr, rdd)";
_rundelayed.Put((Object)(_tmr),(Object)(_rdd));
 //BA.debugLineNum = 78;BA.debugLine="tmr.Enabled = True";
_tmr.setEnabled(__c.True);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public String  _tmr_tick() throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata _rdd = null;
 //BA.debugLineNum = 81;BA.debugLine="Private Sub tmr_Tick";
 //BA.debugLineNum = 82;BA.debugLine="Dim t As Timer = Sender";
_t = (anywheresoftware.b4a.objects.Timer)(__c.Sender(getActivityBA()));
 //BA.debugLineNum = 83;BA.debugLine="t.Enabled = False";
_t.setEnabled(__c.False);
 //BA.debugLineNum = 84;BA.debugLine="Dim rdd As RunDelayedData = RunDelayed.Get(t)";
_rdd = (sadLogic.OctoTouchController.foss.callsubutils._rundelayeddata)(_rundelayed.Get((Object)(_t)));
 //BA.debugLineNum = 85;BA.debugLine="RunDelayed.Remove(t)";
_rundelayed.Remove((Object)(_t));
 //BA.debugLineNum = 86;BA.debugLine="If rdd.Delayed Then";
if (_rdd.Delayed /*boolean*/ ) { 
 //BA.debugLineNum = 87;BA.debugLine="If rdd.Arg = Null Then";
if (_rdd.Arg /*Object[]*/ == null) { 
 //BA.debugLineNum = 88;BA.debugLine="CallSubDelayed(rdd.Module, rdd.SubName)";
__c.CallSubDelayed(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ );
 }else {
 //BA.debugLineNum = 90;BA.debugLine="CallSubDelayed2(rdd.Module, rdd.SubName, rdd.Ar";
__c.CallSubDelayed2(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ ,(Object)(_rdd.Arg /*Object[]*/ ));
 };
 }else {
 //BA.debugLineNum = 93;BA.debugLine="If rdd.Arg = Null Then";
if (_rdd.Arg /*Object[]*/ == null) { 
 //BA.debugLineNum = 94;BA.debugLine="CallSub(rdd.Module, rdd.SubName)";
__c.CallSubNew(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ );
 }else {
 //BA.debugLineNum = 96;BA.debugLine="CallSub2(rdd.Module, rdd.SubName, rdd.Arg)";
__c.CallSubNew2(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ ,(Object)(_rdd.Arg /*Object[]*/ ));
 };
 };
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
