package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class starter extends android.app.Service{
	public static class starter_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (starter) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, starter.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, true, BA.class);
		}

	}
    static starter mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return starter.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "sadLogic.OctoTouchController", "sadLogic.OctoTouchController.starter");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "sadLogic.OctoTouchController.starter", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!true && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (starter) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (true) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (starter) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (true)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (starter) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (true) {
            BA.LogInfo("** Service (starter) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (starter) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.phone.Phone.LogCat _logcat = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
 //BA.debugLineNum = 36;BA.debugLine="ProcessCrash(Error,StackTrace)";
_processcrash(_error,_stacktrace);
 //BA.debugLineNum = 37;BA.debugLine="Try";
try { //BA.debugLineNum = 38;BA.debugLine="B4XPages.MainPage.oMasterController.oWS.wSocket.";
mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (processBA)._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.octowebsocket*/ ._wsocket /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .Close();
 } 
       catch (Exception e5) {
			processBA.setLastException(e5); };
 //BA.debugLineNum = 41;BA.debugLine="CallSub3(\"Main\", \"Show_Unhandled_Error\", Error, S";
anywheresoftware.b4a.keywords.Common.CallSubNew3(processBA,(Object)("Main"),"Show_Unhandled_Error",(Object)(_error),(Object)(_stacktrace));
 //BA.debugLineNum = 43;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private logcat As LogCat";
_logcat = new anywheresoftware.b4a.phone.Phone.LogCat();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static void  _processcrash(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
ResumableSub_ProcessCrash rsub = new ResumableSub_ProcessCrash(null,_error,_stacktrace);
rsub.resume(processBA, null);
}
public static class ResumableSub_ProcessCrash extends BA.ResumableSub {
public ResumableSub_ProcessCrash(sadLogic.OctoTouchController.starter parent,anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) {
this.parent = parent;
this._error = _error;
this._stacktrace = _stacktrace;
}
sadLogic.OctoTouchController.starter parent;
anywheresoftware.b4a.objects.B4AException _error;
String _stacktrace;
String _win_crlf = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _logs = null;
String _spacer = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _tmp = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 51;BA.debugLine="Dim Const WIN_CRLF As String = Chr(10) & Chr(13)";
_win_crlf = BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)));
 //BA.debugLineNum = 54;BA.debugLine="Sleep(500)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (500));
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 55;BA.debugLine="Dim logs As StringBuilder : logs.Initialize";
_logs = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 55;BA.debugLine="Dim logs As StringBuilder : logs.Initialize";
_logs.Initialize();
 //BA.debugLineNum = 56;BA.debugLine="Dim spacer As String = $\"${WIN_CRLF}${WIN_CRLF}${";
_spacer = (""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_win_crlf))+""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_win_crlf))+""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_win_crlf))+"");
 //BA.debugLineNum = 57;BA.debugLine="logcat.LogCatStop";
parent._logcat.LogCatStop();
 //BA.debugLineNum = 58;BA.debugLine="logs.Append(Error.Message).Append(WIN_CRLF).Appen";
_logs.Append(_error.getMessage()).Append(_win_crlf).Append(_stacktrace);
 //BA.debugLineNum = 60;BA.debugLine="Dim tmp As StringBuilder : tmp.Initialize";
_tmp = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Dim tmp As StringBuilder : tmp.Initialize";
_tmp.Initialize();
 //BA.debugLineNum = 61;BA.debugLine="tmp.Append(logs.ToString.Replace(Chr(10),WIN_CRLF";
_tmp.Append(_logs.ToString().replace(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10))),_win_crlf)).Append(_spacer);
 //BA.debugLineNum = 64;BA.debugLine="File.WriteString(xui.DefaultFolder, DateTime.now";
anywheresoftware.b4a.keywords.Common.File.WriteString(parent._xui.getDefaultFolder(),BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow())+".crash",_tmp.ToString());
 //BA.debugLineNum = 67;BA.debugLine="Sleep(200)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (200));
this.state = 2;
return;
case 2:
//C
this.state = -1;
;
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Service_Create '--- This is the program entry";
 //BA.debugLineNum = 14;BA.debugLine="Log(\"Service_Create - starter\")";
anywheresoftware.b4a.keywords.Common.LogImpl("61931522","Service_Create - starter",0);
 //BA.debugLineNum = 17;BA.debugLine="logcat.LogCatStart(Array As String(\"-v\",\"raw\",\"*:";
_logcat.LogCatStart(processBA,new String[]{"-v","raw","*:F","B4A:v"},"logcat");
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 73;BA.debugLine="Log(\"Service_Destroy\")";
anywheresoftware.b4a.keywords.Common.LogImpl("62259201","Service_Destroy",0);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 23;BA.debugLine="Service.StopAutomaticForeground 'Starter service";
mostCurrent._service.StopAutomaticForeground();
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static String  _service_taskremoved() throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub Service_TaskRemoved";
 //BA.debugLineNum = 27;BA.debugLine="Log(\"Service_TaskRemoved\")";
anywheresoftware.b4a.keywords.Common.LogImpl("62062593","Service_TaskRemoved",0);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
}
