package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgviewtext extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgviewtext");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgviewtext.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittext1 = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgViewText\"'";
_mmodule = "dlgViewText";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 12;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 14;BA.debugLine="Private EditText1 As EditText";
_edittext1 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 27;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _title) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize(title As String)";
 //BA.debugLineNum = 21;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 22;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public void  _show(String _fname) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_fname);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgviewtext parent,String _fname) {
this.parent = parent;
this._fname = _fname;
}
sadLogic.OctoTouchController.foss.dlgviewtext parent;
String _fname;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 33;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 34;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 35;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 37;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 38;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 90%x, 88%y)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.PerXToCurrent((float) (90),ba),parent.__c.PerYToCurrent((float) (88),ba));
 //BA.debugLineNum = 39;BA.debugLine="p.LoadLayout(\"dlgViewText.bal\")";
_p.LoadLayout("dlgViewText.bal",ba);
 //BA.debugLineNum = 41;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 42;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 43;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 45;BA.debugLine="EditText1.TextColor = clrTheme.txtNormal";
parent._edittext1.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 46;BA.debugLine="EditText1.Text = File.ReadString(xui.DefaultFolde";
parent._edittext1.setText(BA.ObjectToCharSequence(parent.__c.File.ReadString(parent._xui.getDefaultFolder(),_fname)));
 //BA.debugLineNum = 48;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 49;BA.debugLine="mMainObj.pObjCurrentDlg1 = Null";
parent._mmainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
