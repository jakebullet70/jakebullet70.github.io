package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class assegmentedtab extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.assegmentedtab");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.assegmentedtab.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _tag = null;
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties _g_itemtextproperties = null;
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties _g_seperatorproperties = null;
public float _g_cornerradiusbackground = 0f;
public float _g_cornerradiusselectionpanel = 0f;
public float _g_paddingselectionpanel = 0f;
public boolean _g_showseperators = false;
public float _g_imageheight = 0f;
public int _g_index = 0;
public boolean _mautodecreasetextsize = false;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_background = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_seperators_background = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_selector = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static class _assegmentedtab_itemtextproperties{
public boolean IsInitialized;
public int TextColor;
public int SelectedTextColor;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont TextFont;
public String TextAlignment_Vertical;
public String TextAlignment_Horizontal;
public int BackgroundColor;
public void Initialize() {
IsInitialized = true;
TextColor = 0;
SelectedTextColor = 0;
TextFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
TextAlignment_Vertical = "";
TextAlignment_Horizontal = "";
BackgroundColor = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _assegmentedtab_seperatorproperties{
public boolean IsInitialized;
public int Color;
public float Width;
public int HeightPercentage;
public float CornerRadius;
public void Initialize() {
IsInitialized = true;
Color = 0;
Width = 0f;
HeightPercentage = 0;
CornerRadius = 0f;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _assegmentedtab_tab{
public boolean IsInitialized;
public String Text;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper Icon;
public Object Value;
public float Width;
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties ItemTextProperties;
public void Initialize() {
IsInitialized = true;
Text = "";
Icon = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
Value = new Object();
Width = 0f;
ItemTextProperties = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties();
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _addtab(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon) throws Exception{
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab = null;
 //BA.debugLineNum = 263;BA.debugLine="Public Sub AddTab(Text As String,icon As B4XBitmap";
 //BA.debugLineNum = 264;BA.debugLine="Dim xTab As ASSegmentedTab_Tab = CreateASSegmente";
_xtab = _createassegmentedtab_tab(_text,_icon,(Object)(""),_createassegmentedtab_itemtextproperties(_g_itemtextproperties.TextColor /*int*/ ,_g_itemtextproperties.SelectedTextColor /*int*/ ,_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ ,_g_itemtextproperties.TextAlignment_Vertical /*String*/ ,_g_itemtextproperties.TextAlignment_Horizontal /*String*/ ,_g_itemtextproperties.BackgroundColor /*int*/ ));
 //BA.debugLineNum = 265;BA.debugLine="AddTabIntern(xTab)";
_addtabintern(_xtab);
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public String  _addtab2(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon,Object _value) throws Exception{
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab = null;
 //BA.debugLineNum = 258;BA.debugLine="Public Sub AddTab2(Text As String,icon As B4XBitma";
 //BA.debugLineNum = 259;BA.debugLine="Dim xTab As ASSegmentedTab_Tab = CreateASSegmente";
_xtab = _createassegmentedtab_tab(_text,_icon,_value,_createassegmentedtab_itemtextproperties(_g_itemtextproperties.TextColor /*int*/ ,_g_itemtextproperties.SelectedTextColor /*int*/ ,_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ ,_g_itemtextproperties.TextAlignment_Vertical /*String*/ ,_g_itemtextproperties.TextAlignment_Horizontal /*String*/ ,_g_itemtextproperties.BackgroundColor /*int*/ ));
 //BA.debugLineNum = 260;BA.debugLine="AddTabIntern(xTab)";
_addtabintern(_xtab);
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return "";
}
public String  _addtabadvanced(sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab) throws Exception{
 //BA.debugLineNum = 268;BA.debugLine="Public Sub AddTabAdvanced(xTab As ASSegmentedTab_T";
 //BA.debugLineNum = 269;BA.debugLine="If xTab.ItemTextProperties.IsInitialized = False";
if (_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .IsInitialized /*boolean*/ ==__c.False) { 
_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/  = _createassegmentedtab_itemtextproperties(_g_itemtextproperties.TextColor /*int*/ ,_g_itemtextproperties.SelectedTextColor /*int*/ ,_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ ,_g_itemtextproperties.TextAlignment_Vertical /*String*/ ,_g_itemtextproperties.TextAlignment_Horizontal /*String*/ ,_g_itemtextproperties.BackgroundColor /*int*/ );};
 //BA.debugLineNum = 270;BA.debugLine="AddTabIntern(xTab)";
_addtabintern(_xtab);
 //BA.debugLineNum = 271;BA.debugLine="End Sub";
return "";
}
public String  _addtabintern(sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_tab_background = null;
anywheresoftware.b4a.objects.LabelWrapper _lbl_text = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xlbl_text = null;
anywheresoftware.b4a.objects.ImageViewWrapper _iv_icon = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xiv_icon = null;
 //BA.debugLineNum = 273;BA.debugLine="Private Sub AddTabIntern(xTab As ASSegmentedTab_Ta";
 //BA.debugLineNum = 274;BA.debugLine="Dim xpnl_tab_background As B4XView = xui.CreatePa";
_xpnl_tab_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_tab_background = _xui.CreatePanel(ba,"xpnl_tab_background");
 //BA.debugLineNum = 275;BA.debugLine="Dim lbl_text As Label";
_lbl_text = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 276;BA.debugLine="lbl_text.Initialize(\"\")";
_lbl_text.Initialize(ba,"");
 //BA.debugLineNum = 278;BA.debugLine="lbl_text.SingleLine = True";
_lbl_text.setSingleLine(__c.True);
 //BA.debugLineNum = 280;BA.debugLine="Dim xlbl_text As B4XView = lbl_text";
_xlbl_text = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xlbl_text = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbl_text.getObject()));
 //BA.debugLineNum = 281;BA.debugLine="xpnl_tab_background.AddView(xlbl_text,0,0,0,0)";
_xpnl_tab_background.AddView((android.view.View)(_xlbl_text.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 283;BA.debugLine="Dim iv_icon As ImageView";
_iv_icon = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 284;BA.debugLine="iv_icon.Initialize(\"\")";
_iv_icon.Initialize(ba,"");
 //BA.debugLineNum = 285;BA.debugLine="Dim xiv_icon As B4XView = iv_icon";
_xiv_icon = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xiv_icon = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_iv_icon.getObject()));
 //BA.debugLineNum = 287;BA.debugLine="xpnl_tab_background.AddView(xiv_icon,0,0,IIf(g_Im";
_xpnl_tab_background.AddView((android.view.View)(_xiv_icon.getObject()),(int) (0),(int) (0),(int)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_mbase.getHeight())) : ((Object)(_g_imageheight))))),(int)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_mbase.getHeight())) : ((Object)(_g_imageheight))))));
 //BA.debugLineNum = 291;BA.debugLine="If xTab.icon.IsInitialized = True And xTab.icon <";
if (_xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ .IsInitialized()==__c.True && _xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ != null) { 
 //BA.debugLineNum = 293;BA.debugLine="SetIconsWithColor(xiv_icon,xTab,xpnl_background.";
_seticonswithcolor(_xiv_icon,_xtab,_xpnl_background.getNumberOfViews()==0);
 //BA.debugLineNum = 295;BA.debugLine="xiv_icon.Visible = True";
_xiv_icon.setVisible(__c.True);
 //BA.debugLineNum = 296;BA.debugLine="xlbl_text.Visible = False";
_xlbl_text.setVisible(__c.False);
 }else {
 //BA.debugLineNum = 298;BA.debugLine="xiv_icon.Visible = False";
_xiv_icon.setVisible(__c.False);
 //BA.debugLineNum = 299;BA.debugLine="xlbl_text.Visible = True";
_xlbl_text.setVisible(__c.True);
 };
 //BA.debugLineNum = 302;BA.debugLine="xpnl_tab_background.Color = xui.Color_Transparent";
_xpnl_tab_background.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 304;BA.debugLine="xlbl_text.Text = xTab.Text";
_xlbl_text.setText(BA.ObjectToCharSequence(_xtab.Text /*String*/ ));
 //BA.debugLineNum = 306;BA.debugLine="If xpnl_background.NumberOfViews = 0 Then";
if (_xpnl_background.getNumberOfViews()==0) { 
 //BA.debugLineNum = 307;BA.debugLine="xlbl_text.TextColor = g_ItemTextProperties.Selec";
_xlbl_text.setTextColor(_g_itemtextproperties.SelectedTextColor /*int*/ );
 }else {
 //BA.debugLineNum = 309;BA.debugLine="xlbl_text.TextColor = g_ItemTextProperties.TextC";
_xlbl_text.setTextColor(_g_itemtextproperties.TextColor /*int*/ );
 };
 //BA.debugLineNum = 311;BA.debugLine="xlbl_text.SetColorAndBorder(g_ItemTextProperties.";
_xlbl_text.SetColorAndBorder(_g_itemtextproperties.BackgroundColor /*int*/ ,(int) (0),(int) (0),__c.DipToCurrent((int) (5)));
 //BA.debugLineNum = 312;BA.debugLine="xlbl_text.Font = g_ItemTextProperties.TextFont";
_xlbl_text.setFont(_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ );
 //BA.debugLineNum = 313;BA.debugLine="xlbl_text.SetTextAlignment(g_ItemTextProperties.T";
_xlbl_text.SetTextAlignment(_g_itemtextproperties.TextAlignment_Vertical /*String*/ ,_g_itemtextproperties.TextAlignment_Horizontal /*String*/ );
 //BA.debugLineNum = 315;BA.debugLine="xpnl_tab_background.Tag = xTab";
_xpnl_tab_background.setTag((Object)(_xtab));
 //BA.debugLineNum = 317;BA.debugLine="xpnl_background.AddView(xpnl_tab_background,0,0,0";
_xpnl_background.AddView((android.view.View)(_xpnl_tab_background.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 318;BA.debugLine="If g_ShowSeperators = True Then CreateSeperator";
if (_g_showseperators==__c.True) { 
_createseperator();};
 //BA.debugLineNum = 320;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 321;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
float _customtabwidths = 0f;
int _customtabwidthcounter = 0;
int _i = 0;
float _tab_width = 0f;
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_tab_background = null;
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xlbl_text = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xiv_icon = null;
float _thistabwidth = 0f;
 //BA.debugLineNum = 186;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 188;BA.debugLine="xpnl_background.SetLayoutAnimated(0,0,0,Width,Hei";
_xpnl_background.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_width),(int) (_height));
 //BA.debugLineNum = 189;BA.debugLine="xpnl_seperators_background.SetLayoutAnimated(0,0,";
_xpnl_seperators_background.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_width),(int) (_height));
 //BA.debugLineNum = 191;BA.debugLine="If xpnl_background.NumberOfViews > 0 Then";
if (_xpnl_background.getNumberOfViews()>0) { 
 //BA.debugLineNum = 193;BA.debugLine="Dim CustomTabWidths As Float = 0";
_customtabwidths = (float) (0);
 //BA.debugLineNum = 194;BA.debugLine="Dim CustomTabWidthCounter As Int = 0";
_customtabwidthcounter = (int) (0);
 //BA.debugLineNum = 195;BA.debugLine="For i = 0 To xpnl_background.NumberOfViews -1";
{
final int step6 = 1;
final int limit6 = (int) (_xpnl_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 196;BA.debugLine="If xpnl_background.GetView(i).Tag.As(ASSegmente";
if (((sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_background.GetView(_i).getTag())).Width /*float*/ >0) { 
 //BA.debugLineNum = 197;BA.debugLine="CustomTabWidths = CustomTabWidths + xpnl_backg";
_customtabwidths = (float) (_customtabwidths+((sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_background.GetView(_i).getTag())).Width /*float*/ );
 //BA.debugLineNum = 198;BA.debugLine="CustomTabWidthCounter = CustomTabWidthCounter";
_customtabwidthcounter = (int) (_customtabwidthcounter+1);
 };
 }
};
 //BA.debugLineNum = 202;BA.debugLine="Dim tab_width As Float = (Width-CustomTabWidths)";
_tab_width = (float) ((_width-_customtabwidths)/(double)(_xpnl_background.getNumberOfViews()-_customtabwidthcounter));
 //BA.debugLineNum = 203;BA.debugLine="For i = 0 To xpnl_background.NumberOfViews -1";
{
final int step13 = 1;
final int limit13 = (int) (_xpnl_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit13 ;_i = _i + step13 ) {
 //BA.debugLineNum = 204;BA.debugLine="Dim xpnl_tab_background As B4XView = xpnl_backg";
_xpnl_tab_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_tab_background = _xpnl_background.GetView(_i);
 //BA.debugLineNum = 205;BA.debugLine="Dim xTab As ASSegmentedTab_Tab = xpnl_tab_backg";
_xtab = (sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_tab_background.getTag());
 //BA.debugLineNum = 206;BA.debugLine="Dim xlbl_text As B4XView = xpnl_tab_background.";
_xlbl_text = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xlbl_text = _xpnl_tab_background.GetView((int) (0));
 //BA.debugLineNum = 207;BA.debugLine="Dim xiv_icon As B4XView = xpnl_tab_background.G";
_xiv_icon = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xiv_icon = _xpnl_tab_background.GetView((int) (1));
 //BA.debugLineNum = 209;BA.debugLine="Dim ThisTabWidth As Float = tab_width";
_thistabwidth = _tab_width;
 //BA.debugLineNum = 210;BA.debugLine="If xTab.Width > 0 Then ThisTabWidth = xTab.Widt";
if (_xtab.Width /*float*/ >0) { 
_thistabwidth = _xtab.Width /*float*/ ;};
 //BA.debugLineNum = 212;BA.debugLine="xpnl_tab_background.SetLayoutAnimated(0,IIf(i=0";
_xpnl_tab_background.SetLayoutAnimated((int) (0),(int)(BA.ObjectToNumber(((_i==0) ? ((Object)(0)) : ((Object)(_xpnl_background.GetView((int) (_i-1)).getLeft()+_xpnl_background.GetView((int) (_i-1)).getWidth()))))),(int) (0),(int) (_thistabwidth),(int) (_height));
 //BA.debugLineNum = 213;BA.debugLine="xlbl_text.SetLayoutAnimated(0,0,0,ThisTabWidth,";
_xlbl_text.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_thistabwidth),(int) (_height));
 //BA.debugLineNum = 214;BA.debugLine="xiv_icon.SetLayoutAnimated(0,ThisTabWidth/2 - I";
_xiv_icon.SetLayoutAnimated((int) (0),(int) (_thistabwidth/(double)2-(double)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_height)) : ((Object)(_g_imageheight)))))/(double)2),(int) (_height/(double)2-(double)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_height)) : ((Object)(_g_imageheight)))))/(double)2),(int)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_height)) : ((Object)(_g_imageheight))))),(int)(BA.ObjectToNumber(((_g_imageheight==0) ? ((Object)(_height)) : ((Object)(_g_imageheight))))));
 //BA.debugLineNum = 215;BA.debugLine="If mAutoDecreaseTextSize = True Then CheckTextS";
if (_mautodecreasetextsize==__c.True) { 
_checktextsize(_xlbl_text);};
 }
};
 //BA.debugLineNum = 218;BA.debugLine="xpnl_selector.SetLayoutAnimated(0,xpnl_backgroun";
_xpnl_selector.SetLayoutAnimated((int) (0),(int) (_xpnl_background.GetView(_g_index).getLeft()+_g_paddingselectionpanel),(int) (_g_paddingselectionpanel),(int) (_xpnl_background.GetView(_g_index).getWidth()-(_g_paddingselectionpanel*2)),(int) (_xpnl_background.GetView(_g_index).getHeight()-(_g_paddingselectionpanel*2)));
 };
 //BA.debugLineNum = 221;BA.debugLine="SetCircleClip(mBase,g_CornerRadiusBackground)";
_setcircleclip(_mbase,(int) (_g_cornerradiusbackground));
 //BA.debugLineNum = 222;BA.debugLine="SetCircleClip(xpnl_selector,g_CornerRadiusSelecti";
_setcircleclip(_xpnl_selector,(int) (_g_cornerradiusselectionpanel));
 //BA.debugLineNum = 223;BA.debugLine="UpdateSeperators";
_updateseperators();
 //BA.debugLineNum = 225;BA.debugLine="End Sub";
return "";
}
public String  _base_resize2() throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Public Sub Base_Resize2()";
 //BA.debugLineNum = 182;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 183;BA.debugLine="RefreshTabs";
_refreshtabs();
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return "";
}
public String  _checktextsize(anywheresoftware.b4a.objects.B4XViewWrapper _xview) throws Exception{
float _starttextsize = 0f;
boolean _found = false;
int _i = 0;
 //BA.debugLineNum = 227;BA.debugLine="Private Sub CheckTextSize(xview As B4XView)";
 //BA.debugLineNum = 228;BA.debugLine="If (MeasureTextWidth(xview.Text,g_ItemTextPropert";
if ((_measuretextwidth(_xview.getText(),_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ )+(double)(BA.ObjectToNumber(((_xui.getIsB4J()==__c.True) ? ((Object)(4)) : ((Object)(8))))))<=_xview.getWidth()) { 
if (true) return "";};
 //BA.debugLineNum = 229;BA.debugLine="Dim StartTextSize As Float = xview.TextSize";
_starttextsize = _xview.getTextSize();
 //BA.debugLineNum = 230;BA.debugLine="Dim Found As Boolean = False";
_found = __c.False;
 //BA.debugLineNum = 231;BA.debugLine="For i = StartTextSize To 0 Step -1";
{
final int step4 = -1;
final int limit4 = (int) (0);
_i = (int) (_starttextsize) ;
for (;_i >= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 232;BA.debugLine="If (MeasureTextWidth(xview.Text,xui.CreateFont(g";
if ((_measuretextwidth(_xview.getText(),_xui.CreateFont((android.graphics.Typeface)(_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ .ToNativeFont().getObject()),(float) (_i)))+(double)(BA.ObjectToNumber(((_xui.getIsB4J()==__c.True) ? ((Object)(4)) : ((Object)(8))))))<=_xview.getWidth()) { 
 //BA.debugLineNum = 233;BA.debugLine="xview.Font = xui.CreateFont(g_ItemTextPropertie";
_xview.setFont(_xui.CreateFont((android.graphics.Typeface)(_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ .ToNativeFont().getObject()),(float) (_i)));
 //BA.debugLineNum = 234;BA.debugLine="Found = True";
_found = __c.True;
 //BA.debugLineNum = 235;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 238;BA.debugLine="If Found = False Then xview.Font = xui.CreateFont";
if (_found==__c.False) { 
_xview.setFont(_xui.CreateFont((android.graphics.Typeface)(_g_itemtextproperties.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ .ToNativeFont().getObject()),(float) (1)));};
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 96;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 97;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 98;BA.debugLine="Public mBase As B4XView";
_mbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 99;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 100;BA.debugLine="Public Tag As Object";
_tag = new Object();
 //BA.debugLineNum = 102;BA.debugLine="Type ASSegmentedTab_ItemTextProperties(TextColor";
;
 //BA.debugLineNum = 103;BA.debugLine="Type ASSegmentedTab_SeperatorProperties(Color As";
;
 //BA.debugLineNum = 104;BA.debugLine="Type ASSegmentedTab_Tab(Text As String,Icon As B4";
;
 //BA.debugLineNum = 106;BA.debugLine="Private g_ItemTextProperties As ASSegmentedTab_It";
_g_itemtextproperties = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties();
 //BA.debugLineNum = 107;BA.debugLine="Private g_SeperatorProperties As ASSegmentedTab_S";
_g_seperatorproperties = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties();
 //BA.debugLineNum = 109;BA.debugLine="Private g_CornerRadiusBackground As Float";
_g_cornerradiusbackground = 0f;
 //BA.debugLineNum = 110;BA.debugLine="Private g_CornerRadiusSelectionPanel As Float";
_g_cornerradiusselectionpanel = 0f;
 //BA.debugLineNum = 111;BA.debugLine="Private g_PaddingSelectionPanel As Float";
_g_paddingselectionpanel = 0f;
 //BA.debugLineNum = 112;BA.debugLine="Private g_ShowSeperators As Boolean";
_g_showseperators = false;
 //BA.debugLineNum = 113;BA.debugLine="Private g_ImageHeight As Float = 0";
_g_imageheight = (float) (0);
 //BA.debugLineNum = 115;BA.debugLine="Private g_index As Int = 0";
_g_index = (int) (0);
 //BA.debugLineNum = 116;BA.debugLine="Public mAutoDecreaseTextSize As Boolean = False";
_mautodecreasetextsize = __c.False;
 //BA.debugLineNum = 119;BA.debugLine="Private xpnl_background As B4XView";
_xpnl_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 120;BA.debugLine="Private xpnl_seperators_background As B4XView";
_xpnl_seperators_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 121;BA.debugLine="Private xpnl_selector As B4XView";
_xpnl_selector = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public void  _clear() throws Exception{
ResumableSub_Clear rsub = new ResumableSub_Clear(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Clear extends BA.ResumableSub {
public ResumableSub_Clear(sadLogic.HomeCentral.assegmentedtab parent) {
this.parent = parent;
}
sadLogic.HomeCentral.assegmentedtab parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 126;BA.debugLine="xpnl_selector.RemoveAllViews";
parent._xpnl_selector.RemoveAllViews();
 //BA.debugLineNum = 127;BA.debugLine="xpnl_background.RemoveAllViews";
parent._xpnl_background.RemoveAllViews();
 //BA.debugLineNum = 128;BA.debugLine="xpnl_seperators_background.RemoveAllViews";
parent._xpnl_seperators_background.RemoveAllViews();
 //BA.debugLineNum = 129;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties  _createassegmentedtab_itemtextproperties(int _textcolor,int _selectedtextcolor,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _textfont,String _textalignment_vertical,String _textalignment_horizontal,int _backgroundcolor) throws Exception{
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties _t1 = null;
 //BA.debugLineNum = 704;BA.debugLine="Public Sub CreateASSegmentedTab_ItemTextProperties";
 //BA.debugLineNum = 705;BA.debugLine="Dim t1 As ASSegmentedTab_ItemTextProperties";
_t1 = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties();
 //BA.debugLineNum = 706;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 707;BA.debugLine="t1.TextColor = TextColor";
_t1.TextColor /*int*/  = _textcolor;
 //BA.debugLineNum = 708;BA.debugLine="t1.SelectedTextColor = SelectedTextColor";
_t1.SelectedTextColor /*int*/  = _selectedtextcolor;
 //BA.debugLineNum = 709;BA.debugLine="t1.TextFont = TextFont";
_t1.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/  = _textfont;
 //BA.debugLineNum = 710;BA.debugLine="t1.TextAlignment_Vertical = TextAlignment_Vertica";
_t1.TextAlignment_Vertical /*String*/  = _textalignment_vertical;
 //BA.debugLineNum = 711;BA.debugLine="t1.TextAlignment_Horizontal = TextAlignment_Horiz";
_t1.TextAlignment_Horizontal /*String*/  = _textalignment_horizontal;
 //BA.debugLineNum = 712;BA.debugLine="t1.BackgroundColor = BackgroundColor";
_t1.BackgroundColor /*int*/  = _backgroundcolor;
 //BA.debugLineNum = 713;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 714;BA.debugLine="End Sub";
return null;
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties  _createassegmentedtab_seperatorproperties(int _color,float _width,int _heightpercentage,float _cornerradius) throws Exception{
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties _t1 = null;
 //BA.debugLineNum = 684;BA.debugLine="Public Sub CreateASSegmentedTab_SeperatorPropertie";
 //BA.debugLineNum = 685;BA.debugLine="Dim t1 As ASSegmentedTab_SeperatorProperties";
_t1 = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties();
 //BA.debugLineNum = 686;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 687;BA.debugLine="t1.Color = Color";
_t1.Color /*int*/  = _color;
 //BA.debugLineNum = 688;BA.debugLine="t1.Width = Width";
_t1.Width /*float*/  = _width;
 //BA.debugLineNum = 689;BA.debugLine="t1.HeightPercentage = HeightPercentage";
_t1.HeightPercentage /*int*/  = _heightpercentage;
 //BA.debugLineNum = 690;BA.debugLine="t1.CornerRadius = CornerRadius";
_t1.CornerRadius /*float*/  = _cornerradius;
 //BA.debugLineNum = 691;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 692;BA.debugLine="End Sub";
return null;
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab  _createassegmentedtab_tab(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon,Object _value,sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties _itemtextproperties) throws Exception{
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _t1 = null;
 //BA.debugLineNum = 694;BA.debugLine="Public Sub CreateASSegmentedTab_Tab (Text As Strin";
 //BA.debugLineNum = 695;BA.debugLine="Dim t1 As ASSegmentedTab_Tab";
_t1 = new sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab();
 //BA.debugLineNum = 696;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 697;BA.debugLine="t1.Text = Text";
_t1.Text /*String*/  = _text;
 //BA.debugLineNum = 698;BA.debugLine="t1.Icon = Icon";
_t1.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/  = _icon;
 //BA.debugLineNum = 699;BA.debugLine="t1.Value = Value";
_t1.Value /*Object*/  = _value;
 //BA.debugLineNum = 700;BA.debugLine="t1.ItemTextProperties = ItemTextProperties";
_t1.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/  = _itemtextproperties;
 //BA.debugLineNum = 701;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 702;BA.debugLine="End Sub";
return null;
}
public String  _createseperator() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_seperator = null;
 //BA.debugLineNum = 241;BA.debugLine="Private Sub CreateSeperator";
 //BA.debugLineNum = 242;BA.debugLine="Dim xpnl_seperator As B4XView = xui.CreatePanel(\"";
_xpnl_seperator = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_seperator = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 243;BA.debugLine="xpnl_seperator.Visible = False";
_xpnl_seperator.setVisible(__c.False);
 //BA.debugLineNum = 244;BA.debugLine="xpnl_seperators_background.AddView(xpnl_seperator";
_xpnl_seperators_background.AddView((android.view.View)(_xpnl_seperator.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4a.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 141;BA.debugLine="mBase = Base";
_mbase = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 142;BA.debugLine="Tag = mBase.Tag";
_tag = _mbase.getTag();
 //BA.debugLineNum = 143;BA.debugLine="mBase.Tag = Me";
_mbase.setTag(this);
 //BA.debugLineNum = 145;BA.debugLine="xpnl_background = xui.CreatePanel(\"\")";
_xpnl_background = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 146;BA.debugLine="xpnl_seperators_background = xui.CreatePanel(\"\")";
_xpnl_seperators_background = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 147;BA.debugLine="xpnl_selector = xui.CreatePanel(\"\")";
_xpnl_selector = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 149;BA.debugLine="ini_props(Props)";
_ini_props(_props);
 //BA.debugLineNum = 151;BA.debugLine="mBase.AddView(xpnl_selector,0,0,0,0)";
_mbase.AddView((android.view.View)(_xpnl_selector.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 152;BA.debugLine="mBase.AddView(xpnl_background,0,0,0,0)";
_mbase.AddView((android.view.View)(_xpnl_background.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 153;BA.debugLine="mBase.AddView(xpnl_seperators_background,0,0,0,0)";
_mbase.AddView((android.view.View)(_xpnl_seperators_background.getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 164;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _fonttobitmap(String _text,boolean _ismaterialicons,float _fontsize,int _color) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.objects.B4XCanvas _cvs1 = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _fnt = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
int _baseline = 0;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
 //BA.debugLineNum = 527;BA.debugLine="Public Sub FontToBitmap (text As String, IsMateria";
 //BA.debugLineNum = 528;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 529;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 530;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 32dip, 32dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (32)));
 //BA.debugLineNum = 531;BA.debugLine="Dim cvs1 As B4XCanvas";
_cvs1 = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 532;BA.debugLine="cvs1.Initialize(p)";
_cvs1.Initialize(_p);
 //BA.debugLineNum = 533;BA.debugLine="Dim fnt As B4XFont";
_fnt = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
 //BA.debugLineNum = 534;BA.debugLine="If IsMaterialIcons Then fnt = xui.CreateMaterialI";
if (_ismaterialicons) { 
_fnt = _xui.CreateMaterialIcons(_fontsize);}
else {
_fnt = _xui.CreateFontAwesome(_fontsize);};
 //BA.debugLineNum = 535;BA.debugLine="Dim r As B4XRect = cvs1.MeasureText(text, fnt)";
_r = _cvs1.MeasureText(_text,_fnt);
 //BA.debugLineNum = 536;BA.debugLine="Dim BaseLine As Int = cvs1.TargetRect.CenterY - r";
_baseline = (int) (_cvs1.getTargetRect().getCenterY()-_r.getHeight()/(double)2-_r.getTop());
 //BA.debugLineNum = 537;BA.debugLine="cvs1.DrawText(text, cvs1.TargetRect.CenterX, Base";
_cvs1.DrawText(ba,_text,_cvs1.getTargetRect().getCenterX(),(float) (_baseline),_fnt,_color,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 //BA.debugLineNum = 538;BA.debugLine="Dim b As B4XBitmap = cvs1.CreateBitmap";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_b = _cvs1.CreateBitmap();
 //BA.debugLineNum = 539;BA.debugLine="cvs1.Release";
_cvs1.Release();
 //BA.debugLineNum = 540;BA.debugLine="Return b";
if (true) return _b;
 //BA.debugLineNum = 541;BA.debugLine="End Sub";
return null;
}
public int[]  _getargb(int _color) throws Exception{
int[] _res = null;
 //BA.debugLineNum = 655;BA.debugLine="Private Sub GetARGB(Color As Int) As Int()'ignore";
 //BA.debugLineNum = 656;BA.debugLine="Private res(4) As Int";
_res = new int[(int) (4)];
;
 //BA.debugLineNum = 657;BA.debugLine="res(0) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (0)] = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,((int)0xff000000)),(int) (24));
 //BA.debugLineNum = 658;BA.debugLine="res(1) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (1)] = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,((int)0xff0000)),(int) (16));
 //BA.debugLineNum = 659;BA.debugLine="res(2) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (2)] = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,((int)0xff00)),(int) (8));
 //BA.debugLineNum = 660;BA.debugLine="res(3) = Bit.And(Color, 0xff)";
_res[(int) (3)] = __c.Bit.And(_color,((int)0xff));
 //BA.debugLineNum = 661;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 662;BA.debugLine="End Sub";
return null;
}
public boolean  _getautodecreasetextsize() throws Exception{
 //BA.debugLineNum = 405;BA.debugLine="Public Sub getAutoDecreaseTextSize As Boolean";
 //BA.debugLineNum = 406;BA.debugLine="Return mAutoDecreaseTextSize";
if (true) return _mautodecreasetextsize;
 //BA.debugLineNum = 407;BA.debugLine="End Sub";
return false;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getbackgroundpanel() throws Exception{
 //BA.debugLineNum = 507;BA.debugLine="Public Sub getBackgroundPanel As B4XView";
 //BA.debugLineNum = 508;BA.debugLine="Return xpnl_background";
if (true) return _xpnl_background;
 //BA.debugLineNum = 509;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getbase() throws Exception{
 //BA.debugLineNum = 503;BA.debugLine="Public Sub getBase As B4XView";
 //BA.debugLineNum = 504;BA.debugLine="Return mBase";
if (true) return _mbase;
 //BA.debugLineNum = 505;BA.debugLine="End Sub";
return null;
}
public int  _getindex() throws Exception{
 //BA.debugLineNum = 380;BA.debugLine="Public Sub getIndex As Int";
 //BA.debugLineNum = 381;BA.debugLine="Return g_index";
if (true) return _g_index;
 //BA.debugLineNum = 382;BA.debugLine="End Sub";
return 0;
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties  _getitemtextproperties() throws Exception{
 //BA.debugLineNum = 377;BA.debugLine="Public Sub getItemTextProperties As ASSegmentedTab";
 //BA.debugLineNum = 378;BA.debugLine="Return g_ItemTextProperties";
if (true) return _g_itemtextproperties;
 //BA.debugLineNum = 379;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getselectionpanel() throws Exception{
 //BA.debugLineNum = 511;BA.debugLine="Public Sub getSelectionPanel As B4XView";
 //BA.debugLineNum = 512;BA.debugLine="Return xpnl_selector";
if (true) return _xpnl_selector;
 //BA.debugLineNum = 513;BA.debugLine="End Sub";
return null;
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_seperatorproperties  _getseperatorproperties() throws Exception{
 //BA.debugLineNum = 369;BA.debugLine="Public Sub getSeperatorProperties As ASSegmentedTa";
 //BA.debugLineNum = 370;BA.debugLine="Return g_SeperatorProperties";
if (true) return _g_seperatorproperties;
 //BA.debugLineNum = 371;BA.debugLine="End Sub";
return null;
}
public float  _getseperatorsheight() throws Exception{
 //BA.debugLineNum = 372;BA.debugLine="Public Sub getSeperatorsHeight As Float";
 //BA.debugLineNum = 373;BA.debugLine="Return mBase.Height*g_SeperatorProperties.HeightP";
if (true) return (float) (_mbase.getHeight()*_g_seperatorproperties.HeightPercentage /*int*/ /(double)100);
 //BA.debugLineNum = 374;BA.debugLine="End Sub";
return 0f;
}
public int  _getsize() throws Exception{
 //BA.debugLineNum = 515;BA.debugLine="Public Sub getSize As Int";
 //BA.debugLineNum = 516;BA.debugLine="Return xpnl_background.NumberOfViews";
if (true) return _xpnl_background.getNumberOfViews();
 //BA.debugLineNum = 517;BA.debugLine="End Sub";
return 0;
}
public sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab  _gettab(int _index) throws Exception{
 //BA.debugLineNum = 324;BA.debugLine="Public Sub GetTab(Index As Int) As ASSegmentedTab_";
 //BA.debugLineNum = 325;BA.debugLine="Return xpnl_background.GetView(Index).Tag";
if (true) return (sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_background.GetView(_index).getTag());
 //BA.debugLineNum = 326;BA.debugLine="End Sub";
return null;
}
public Object  _getvalue(int _index) throws Exception{
 //BA.debugLineNum = 328;BA.debugLine="Public Sub GetValue(Index As Int) As Object";
 //BA.debugLineNum = 329;BA.debugLine="Return xpnl_background.GetView(Index).Tag.As(ASSe";
if (true) return ((sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_background.GetView(_index).getTag())).Value /*Object*/ ;
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
return null;
}
public String  _ini_props(anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 168;BA.debugLine="Private Sub ini_props(Props As Map)";
 //BA.debugLineNum = 169;BA.debugLine="g_ItemTextProperties = CreateASSegmentedTab_ItemT";
_g_itemtextproperties = _createassegmentedtab_itemtextproperties(_xui.PaintOrColorToColor(_props.GetDefault((Object)("TextColor"),(Object)(((int)0xffffffff)))),_xui.PaintOrColorToColor(_props.GetDefault((Object)("SelectionTextColor"),(Object)(((int)0xffffffff)))),_xui.CreateDefaultFont((float) (15)),"CENTER","CENTER",_xui.Color_Transparent);
 //BA.debugLineNum = 170;BA.debugLine="g_SeperatorProperties = CreateASSegmentedTab_Sepe";
_g_seperatorproperties = _createassegmentedtab_seperatorproperties(_xui.PaintOrColorToColor(_props.GetDefault((Object)("SeperatorColor"),(Object)(((int)0x98ffffff)))),(float) (__c.DipToCurrent((int) (2))),(int) (50),(float) (0));
 //BA.debugLineNum = 172;BA.debugLine="g_CornerRadiusBackground = DipToCurrent(Props.Get";
_g_cornerradiusbackground = (float) (__c.DipToCurrent((int)(BA.ObjectToNumber(_props.GetDefault((Object)("CornerRadiusBackground"),(Object)(0))))));
 //BA.debugLineNum = 173;BA.debugLine="g_CornerRadiusSelectionPanel = DipToCurrent(Props";
_g_cornerradiusselectionpanel = (float) (__c.DipToCurrent((int)(BA.ObjectToNumber(_props.GetDefault((Object)("CornerRadiusSelectionPanel"),(Object)(0))))));
 //BA.debugLineNum = 174;BA.debugLine="g_PaddingSelectionPanel = DipToCurrent(Props.GetD";
_g_paddingselectionpanel = (float) (__c.DipToCurrent((int)(BA.ObjectToNumber(_props.GetDefault((Object)("PaddingSelectionPanel"),(Object)(0))))));
 //BA.debugLineNum = 175;BA.debugLine="g_ShowSeperators = Props.GetDefault(\"ShowSeperato";
_g_showseperators = BA.ObjectToBoolean(_props.GetDefault((Object)("ShowSeperators"),(Object)(__c.False)));
 //BA.debugLineNum = 177;BA.debugLine="mBase.Color = xui.PaintOrColorToColor(Props.GetDe";
_mbase.setColor(_xui.PaintOrColorToColor(_props.GetDefault((Object)("BackgroundColor"),(Object)(((int)0xff000000)))));
 //BA.debugLineNum = 178;BA.debugLine="xpnl_selector.Color = xui.PaintOrColorToColor(Pro";
_xpnl_selector.setColor(_xui.PaintOrColorToColor(_props.GetDefault((Object)("SelectionColor"),(Object)(((int)0xff2d8879)))));
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 134;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 135;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 136;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return "";
}
public int  _measuretextwidth(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _font1) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmp = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvs = null;
 //BA.debugLineNum = 664;BA.debugLine="Private Sub MeasureTextWidth(Text As String, Font1";
 //BA.debugLineNum = 666;BA.debugLine="Private bmp As Bitmap";
_bmp = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 667;BA.debugLine="bmp.InitializeMutable(2dip, 2dip)";
_bmp.InitializeMutable(__c.DipToCurrent((int) (2)),__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 668;BA.debugLine="Private cvs As Canvas";
_cvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 669;BA.debugLine="cvs.Initialize2(bmp)";
_cvs.Initialize2((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 670;BA.debugLine="Return cvs.MeasureStringWidth(Text, Font1.ToNa";
if (true) return (int) (_cvs.MeasureStringWidth(_text,(android.graphics.Typeface)(_font1.ToNativeFont().getObject()),_font1.getSize()));
 //BA.debugLineNum = 682;BA.debugLine="End Sub";
return 0;
}
public String  _refreshtabs() throws Exception{
int _i = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_tab_background = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xlbl_text = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xiv_icon = null;
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab = null;
 //BA.debugLineNum = 332;BA.debugLine="Public Sub RefreshTabs";
 //BA.debugLineNum = 333;BA.debugLine="For i = 0 To xpnl_background.NumberOfViews -1";
{
final int step1 = 1;
final int limit1 = (int) (_xpnl_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 334;BA.debugLine="Dim xpnl_tab_background As B4XView = xpnl_backgr";
_xpnl_tab_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_tab_background = _xpnl_background.GetView(_i);
 //BA.debugLineNum = 335;BA.debugLine="Dim xlbl_text As B4XView = xpnl_tab_background.G";
_xlbl_text = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xlbl_text = _xpnl_tab_background.GetView((int) (0));
 //BA.debugLineNum = 336;BA.debugLine="Dim xiv_icon As B4XView = xpnl_tab_background.Ge";
_xiv_icon = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xiv_icon = _xpnl_tab_background.GetView((int) (1));
 //BA.debugLineNum = 338;BA.debugLine="Dim xTab As ASSegmentedTab_Tab = xpnl_tab_backgr";
_xtab = (sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_tab_background.getTag());
 //BA.debugLineNum = 340;BA.debugLine="xlbl_text.Text = xTab.Text";
_xlbl_text.setText(BA.ObjectToCharSequence(_xtab.Text /*String*/ ));
 //BA.debugLineNum = 341;BA.debugLine="If i = g_index Then";
if (_i==_g_index) { 
 //BA.debugLineNum = 342;BA.debugLine="xlbl_text.TextColor = xTab.ItemTextProperties.S";
_xlbl_text.setTextColor(_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .SelectedTextColor /*int*/ );
 }else {
 //BA.debugLineNum = 344;BA.debugLine="xlbl_text.TextColor = xTab.ItemTextProperties.T";
_xlbl_text.setTextColor(_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .TextColor /*int*/ );
 };
 //BA.debugLineNum = 347;BA.debugLine="xlbl_text.SetColorAndBorder(xTab.ItemTextPropert";
_xlbl_text.SetColorAndBorder(_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .BackgroundColor /*int*/ ,(int) (0),(int) (0),__c.DipToCurrent((int) (5)));
 //BA.debugLineNum = 348;BA.debugLine="xlbl_text.Font = xTab.ItemTextProperties.TextFon";
_xlbl_text.setFont(_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ );
 //BA.debugLineNum = 349;BA.debugLine="xlbl_text.SetTextAlignment(xTab.ItemTextProperti";
_xlbl_text.SetTextAlignment(_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .TextAlignment_Vertical /*String*/ ,_xtab.ItemTextProperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ .TextAlignment_Horizontal /*String*/ );
 //BA.debugLineNum = 351;BA.debugLine="If xTab.Icon.IsInitialized = True And xTab.Icon";
if (_xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ .IsInitialized()==__c.True && _xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ != null) { 
 //BA.debugLineNum = 353;BA.debugLine="SetIconsWithColor(xiv_icon,xTab,i = g_index)";
_seticonswithcolor(_xiv_icon,_xtab,_i==_g_index);
 //BA.debugLineNum = 355;BA.debugLine="xiv_icon.Visible = True";
_xiv_icon.setVisible(__c.True);
 //BA.debugLineNum = 356;BA.debugLine="xlbl_text.Visible = False";
_xlbl_text.setVisible(__c.False);
 }else {
 //BA.debugLineNum = 358;BA.debugLine="xiv_icon.Visible = False";
_xiv_icon.setVisible(__c.False);
 //BA.debugLineNum = 359;BA.debugLine="xlbl_text.Visible = True";
_xlbl_text.setVisible(__c.True);
 };
 }
};
 //BA.debugLineNum = 363;BA.debugLine="End Sub";
return "";
}
public String  _selectedindex(int _index,int _duration) throws Exception{
 //BA.debugLineNum = 497;BA.debugLine="Public Sub SelectedIndex(index As Int,Duration As";
 //BA.debugLineNum = 498;BA.debugLine="g_index = index";
_g_index = _index;
 //BA.debugLineNum = 499;BA.debugLine="xpnl_selector.SetLayoutAnimated(Duration,mBase.Wi";
_xpnl_selector.SetLayoutAnimated(_duration,(int) (_mbase.getWidth()/(double)_xpnl_background.getNumberOfViews()*_index+_g_paddingselectionpanel),(int) (_g_paddingselectionpanel),_xpnl_selector.getWidth(),_xpnl_selector.getHeight());
 //BA.debugLineNum = 500;BA.debugLine="TabClick(xpnl_background.GetView(index),True)";
_tabclick(_xpnl_background.GetView(_index),__c.True);
 //BA.debugLineNum = 501;BA.debugLine="End Sub";
return "";
}
public String  _setautodecreasetextsize(boolean _decreasetextsize) throws Exception{
 //BA.debugLineNum = 409;BA.debugLine="Public Sub setAutoDecreaseTextSize(DecreaseTextSiz";
 //BA.debugLineNum = 410;BA.debugLine="mAutoDecreaseTextSize = DecreaseTextSize";
_mautodecreasetextsize = _decreasetextsize;
 //BA.debugLineNum = 411;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 412;BA.debugLine="End Sub";
return "";
}
public String  _setcircleclip(anywheresoftware.b4a.objects.B4XViewWrapper _pnl,int _radius) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 543;BA.debugLine="Private Sub SetCircleClip (pnl As B4XView,radius A";
 //BA.debugLineNum = 557;BA.debugLine="Dim jo As JavaObject = pnl";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pnl.getObject()));
 //BA.debugLineNum = 559;BA.debugLine="Try";
try { //BA.debugLineNum = 560;BA.debugLine="jo.RunMethod(\"setClipToOutline\", Array(True))";
_jo.RunMethod("setClipToOutline",new Object[]{(Object)(__c.True)});
 } 
       catch (Exception e5) {
			ba.setLastException(e5); };
 //BA.debugLineNum = 565;BA.debugLine="pnl.SetColorAndBorder(pnl.Color,0,0,radius)";
_pnl.SetColorAndBorder(_pnl.getColor(),(int) (0),(int) (0),_radius);
 //BA.debugLineNum = 574;BA.debugLine="End Sub";
return "";
}
public String  _setcornerradiusbackground(float _corner_radius) throws Exception{
 //BA.debugLineNum = 389;BA.debugLine="Public Sub setCornerRadiusBackground(corner_radius";
 //BA.debugLineNum = 390;BA.debugLine="g_CornerRadiusBackground = corner_radius";
_g_cornerradiusbackground = _corner_radius;
 //BA.debugLineNum = 391;BA.debugLine="SetCircleClip(mBase,corner_radius)";
_setcircleclip(_mbase,(int) (_corner_radius));
 //BA.debugLineNum = 392;BA.debugLine="End Sub";
return "";
}
public String  _setcornerradiusselectionpanel(float _corner_radius) throws Exception{
 //BA.debugLineNum = 394;BA.debugLine="Public Sub setCornerRadiusSelectionPanel(corner_ra";
 //BA.debugLineNum = 395;BA.debugLine="g_CornerRadiusSelectionPanel = corner_radius";
_g_cornerradiusselectionpanel = _corner_radius;
 //BA.debugLineNum = 396;BA.debugLine="SetCircleClip(xpnl_selector,corner_radius)";
_setcircleclip(_xpnl_selector,(int) (_corner_radius));
 //BA.debugLineNum = 397;BA.debugLine="End Sub";
return "";
}
public String  _seticonswithcolor(anywheresoftware.b4a.objects.B4XViewWrapper _xiv_icon,sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab,boolean _isselected) throws Exception{
float _scale = 0f;
 //BA.debugLineNum = 435;BA.debugLine="Private Sub SetIconsWithColor(xiv_icon As B4XView,";
 //BA.debugLineNum = 437;BA.debugLine="If xiv_icon.Visible Then";
if (_xiv_icon.getVisible()) { 
 //BA.debugLineNum = 439;BA.debugLine="Dim scale As Float = 1";
_scale = (float) (1);
 //BA.debugLineNum = 444;BA.debugLine="If isSelected Then";
if (_isselected) { 
 //BA.debugLineNum = 449;BA.debugLine="xiv_icon.SetBitmap(xTab.Icon.Resize(xiv_icon.Wi";
_xiv_icon.SetBitmap((android.graphics.Bitmap)(_xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ .Resize((int) (_xiv_icon.getWidth()*_scale),(int) (_xiv_icon.getHeight()*_scale),__c.True).getObject()));
 //BA.debugLineNum = 450;BA.debugLine="TintBmp(xiv_icon,g_ItemTextProperties.SelectedT";
_tintbmp((anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(_xiv_icon.getObject())),_g_itemtextproperties.SelectedTextColor /*int*/ );
 }else {
 //BA.debugLineNum = 458;BA.debugLine="xiv_icon.SetBitmap(xTab.Icon.Resize(xiv_icon.Wi";
_xiv_icon.SetBitmap((android.graphics.Bitmap)(_xtab.Icon /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ .Resize((int) (_xiv_icon.getWidth()*_scale),(int) (_xiv_icon.getHeight()*_scale),__c.True).getObject()));
 //BA.debugLineNum = 459;BA.debugLine="TintBmp(xiv_icon,g_ItemTextProperties.TextColor";
_tintbmp((anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(_xiv_icon.getObject())),_g_itemtextproperties.TextColor /*int*/ );
 };
 };
 //BA.debugLineNum = 466;BA.debugLine="End Sub";
return "";
}
public String  _setimageheight(float _height) throws Exception{
 //BA.debugLineNum = 365;BA.debugLine="Public Sub setImageHeight(height As Float)";
 //BA.debugLineNum = 366;BA.debugLine="g_ImageHeight = height";
_g_imageheight = _height;
 //BA.debugLineNum = 367;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 368;BA.debugLine="End Sub";
return "";
}
public String  _setindex(int _index) throws Exception{
 //BA.debugLineNum = 384;BA.debugLine="Public Sub setIndex(Index As Int)";
 //BA.debugLineNum = 385;BA.debugLine="g_index = Index";
_g_index = _index;
 //BA.debugLineNum = 386;BA.debugLine="SelectedIndex(Index,0)";
_selectedindex(_index,(int) (0));
 //BA.debugLineNum = 387;BA.debugLine="End Sub";
return "";
}
public String  _setpaddingselectionpanel(float _padding) throws Exception{
 //BA.debugLineNum = 399;BA.debugLine="Public Sub setPaddingSelectionPanel(padding As Flo";
 //BA.debugLineNum = 400;BA.debugLine="g_PaddingSelectionPanel = padding";
_g_paddingselectionpanel = _padding;
 //BA.debugLineNum = 401;BA.debugLine="Base_Resize(mBase.Width,mBase.Height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 402;BA.debugLine="End Sub";
return "";
}
public String  _setshowseperators(boolean _visible) throws Exception{
int _i = 0;
 //BA.debugLineNum = 414;BA.debugLine="Public Sub setShowSeperators(visible As Boolean)";
 //BA.debugLineNum = 415;BA.debugLine="g_ShowSeperators = visible";
_g_showseperators = _visible;
 //BA.debugLineNum = 416;BA.debugLine="If visible = False Then";
if (_visible==__c.False) { 
 //BA.debugLineNum = 417;BA.debugLine="xpnl_seperators_background.RemoveAllViews";
_xpnl_seperators_background.RemoveAllViews();
 }else {
 //BA.debugLineNum = 419;BA.debugLine="For i = 0 To xpnl_background.NumberOfViews -1";
{
final int step5 = 1;
final int limit5 = (int) (_xpnl_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
 //BA.debugLineNum = 420;BA.debugLine="CreateSeperator";
_createseperator();
 }
};
 //BA.debugLineNum = 422;BA.debugLine="UpdateSeperators";
_updateseperators();
 };
 //BA.debugLineNum = 424;BA.debugLine="End Sub";
return "";
}
public String  _tabchanged(int _index) throws Exception{
 //BA.debugLineNum = 519;BA.debugLine="Private Sub TabChanged(Index As Int)";
 //BA.debugLineNum = 520;BA.debugLine="If xui.SubExists(mCallBack,mEventName & \"_TabChan";
if (_xui.SubExists(ba,_mcallback,_meventname+"_TabChanged",(int) (1))) { 
 //BA.debugLineNum = 521;BA.debugLine="CallSub2(mCallBack,mEventName & \"_TabChanged\",In";
__c.CallSubNew2(ba,_mcallback,_meventname+"_TabChanged",(Object)(_index));
 };
 //BA.debugLineNum = 523;BA.debugLine="End Sub";
return "";
}
public String  _tabclick(anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_tab_background,boolean _isintern) throws Exception{
int _i = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _xiv_icon = null;
sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab _xtab = null;
 //BA.debugLineNum = 468;BA.debugLine="Private Sub TabClick(xpnl_tab_background As B4XVie";
 //BA.debugLineNum = 469;BA.debugLine="For i = 0 To xpnl_background.NumberOfViews -1";
{
final int step1 = 1;
final int limit1 = (int) (_xpnl_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 470;BA.debugLine="Dim xiv_icon As B4XView = xpnl_background.GetVie";
_xiv_icon = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xiv_icon = _xpnl_background.GetView(_i).GetView((int) (1));
 //BA.debugLineNum = 471;BA.debugLine="Dim xTab As ASSegmentedTab_Tab = xpnl_background";
_xtab = (sadLogic.HomeCentral.assegmentedtab._assegmentedtab_tab)(_xpnl_background.GetView(_i).getTag());
 //BA.debugLineNum = 473;BA.debugLine="If xpnl_background.GetView(i) = xpnl_tab_backgro";
if ((_xpnl_background.GetView(_i)).equals(_xpnl_tab_background)) { 
 //BA.debugLineNum = 474;BA.debugLine="If (xpnl_tab_background.Left <> xpnl_selector.L";
if ((_xpnl_tab_background.getLeft()!=_xpnl_selector.getLeft()) || _isintern) { 
 //BA.debugLineNum = 475;BA.debugLine="g_index = i";
_g_index = _i;
 //BA.debugLineNum = 476;BA.debugLine="xpnl_background.GetView(i).GetView(0).TextColo";
_xpnl_background.GetView(_i).GetView((int) (0)).setTextColor(_g_itemtextproperties.SelectedTextColor /*int*/ );
 //BA.debugLineNum = 478;BA.debugLine="SetIconsWithColor(xiv_icon,xTab,True)";
_seticonswithcolor(_xiv_icon,_xtab,__c.True);
 //BA.debugLineNum = 480;BA.debugLine="TabChanged(i)";
_tabchanged(_i);
 };
 }else {
 //BA.debugLineNum = 483;BA.debugLine="xpnl_background.GetView(i).GetView(0).TextColor";
_xpnl_background.GetView(_i).GetView((int) (0)).setTextColor(_g_itemtextproperties.TextColor /*int*/ );
 //BA.debugLineNum = 484;BA.debugLine="SetIconsWithColor(xiv_icon,xTab,False)";
_seticonswithcolor(_xiv_icon,_xtab,__c.False);
 };
 }
};
 //BA.debugLineNum = 488;BA.debugLine="xpnl_selector.SetLayoutAnimated(250,xpnl_tab_back";
_xpnl_selector.SetLayoutAnimated((int) (250),(int) (_xpnl_tab_background.getLeft()+_g_paddingselectionpanel),(int) (_g_paddingselectionpanel),(int) (_xpnl_tab_background.getWidth()-(_g_paddingselectionpanel*2)),(int) (_xpnl_tab_background.getHeight()-(_g_paddingselectionpanel*2)));
 //BA.debugLineNum = 489;BA.debugLine="UpdateSeperators";
_updateseperators();
 //BA.debugLineNum = 495;BA.debugLine="End Sub";
return "";
}
public String  _tintbmp(anywheresoftware.b4a.objects.ImageViewWrapper _img,int _color) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 577;BA.debugLine="Private Sub TintBmp(img As ImageView, color As Int";
 //BA.debugLineNum = 604;BA.debugLine="Dim jo As JavaObject=img";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_img.getObject()));
 //BA.debugLineNum = 605;BA.debugLine="jo.RunMethod(\"setImageBitmap\",Array(img.Bitmap))";
_jo.RunMethod("setImageBitmap",new Object[]{(Object)(_img.getBitmap())});
 //BA.debugLineNum = 607;BA.debugLine="jo.RunMethod(\"setColorFilter\",Array(Colors.rgb(G";
_jo.RunMethod("setColorFilter",new Object[]{(Object)(__c.Colors.RGB(_getargb(_color)[(int) (1)],_getargb(_color)[(int) (2)],_getargb(_color)[(int) (3)]))});
 //BA.debugLineNum = 612;BA.debugLine="End Sub";
return "";
}
public String  _updateseperators() throws Exception{
int _i = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_seperator = null;
anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_tmp_tab = null;
 //BA.debugLineNum = 247;BA.debugLine="Public Sub UpdateSeperators";
 //BA.debugLineNum = 248;BA.debugLine="For i = 0 To xpnl_seperators_background.NumberOfV";
{
final int step1 = 1;
final int limit1 = (int) (_xpnl_seperators_background.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 249;BA.debugLine="Dim xpnl_seperator As B4XView = xpnl_seperators_";
_xpnl_seperator = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_seperator = _xpnl_seperators_background.GetView(_i);
 //BA.debugLineNum = 251;BA.debugLine="Dim xpnl_tmp_tab As B4XView = xpnl_background.Ge";
_xpnl_tmp_tab = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xpnl_tmp_tab = _xpnl_background.GetView(_i);
 //BA.debugLineNum = 252;BA.debugLine="xpnl_seperator.SetLayoutAnimated(0,xpnl_tmp_tab.";
_xpnl_seperator.SetLayoutAnimated((int) (0),(int) (_xpnl_tmp_tab.getLeft()+_xpnl_tmp_tab.getWidth()-(_g_seperatorproperties.Width /*float*/ /(double)2)),(int) (_xpnl_tmp_tab.getHeight()/(double)2-(_xpnl_tmp_tab.getHeight()*_g_seperatorproperties.HeightPercentage /*int*/ /(double)100)/(double)2),(int) (_g_seperatorproperties.Width /*float*/ ),(int) (_xpnl_tmp_tab.getHeight()*_g_seperatorproperties.HeightPercentage /*int*/ /(double)100));
 //BA.debugLineNum = 253;BA.debugLine="xpnl_seperator.Visible = g_ShowSeperators And i";
_xpnl_seperator.setVisible(_g_showseperators && _i<(_xpnl_background.getNumberOfViews()-1) && _i!=_g_index && _i!=(_g_index-1));
 //BA.debugLineNum = 254;BA.debugLine="xpnl_seperator.SetColorAndBorder(g_SeperatorProp";
_xpnl_seperator.SetColorAndBorder(_g_seperatorproperties.Color /*int*/ ,(int) (0),(int) (0),(int) (_g_seperatorproperties.CornerRadius /*float*/ ));
 }
};
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _xpnl_tab_background_click() throws Exception{
 //BA.debugLineNum = 430;BA.debugLine="Private Sub xpnl_tab_background_Click";
 //BA.debugLineNum = 431;BA.debugLine="TabClick(Sender,False)";
_tabclick((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba))),__c.False);
 //BA.debugLineNum = 432;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
