package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadb4xdialoghelper extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.sadb4xdialoghelper");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.sadb4xdialoghelper.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.b4xdialog _dlg = null;
public float _scale = 0f;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _animatedialog(String _fromedge) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _base = null;
int _top = 0;
int _left = 0;
 //BA.debugLineNum = 96;BA.debugLine="Public Sub AnimateDialog (FromEdge As String)";
 //BA.debugLineNum = 97;BA.debugLine="Dim base As B4XView = dlg.Base";
_base = new anywheresoftware.b4a.objects.B4XViewWrapper();
_base = _dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ;
 //BA.debugLineNum = 98;BA.debugLine="Dim top As Int = base.Top";
_top = _base.getTop();
 //BA.debugLineNum = 99;BA.debugLine="Dim left As Int = base.Left";
_left = _base.getLeft();
 //BA.debugLineNum = 100;BA.debugLine="Select FromEdge.ToLowerCase";
switch (BA.switchObjectToInt(_fromedge.toLowerCase(),"bottom","top","left","right")) {
case 0: {
 //BA.debugLineNum = 102;BA.debugLine="base.Top = base.Parent.Height";
_base.setTop(_base.getParent().getHeight());
 break; }
case 1: {
 //BA.debugLineNum = 104;BA.debugLine="base.Top = -base.Height";
_base.setTop((int) (-_base.getHeight()));
 break; }
case 2: {
 //BA.debugLineNum = 106;BA.debugLine="base.Left = -base.Width";
_base.setLeft((int) (-_base.getWidth()));
 break; }
case 3: {
 //BA.debugLineNum = 108;BA.debugLine="base.Left = base.Parent.Width";
_base.setLeft(_base.getParent().getWidth());
 break; }
}
;
 //BA.debugLineNum = 110;BA.debugLine="base.SetLayoutAnimated(220, left, top, base.Width";
_base.SetLayoutAnimated((int) (220),_left,_top,_base.getWidth(),_base.getHeight());
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 10;BA.debugLine="Private Scale As Float";
_scale = 0f;
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.b4xdialog _odlg) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.objects.Accessibility _ac = null;
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize(oDlg As B4XDialog)";
 //BA.debugLineNum = 14;BA.debugLine="dlg = oDlg";
_dlg = _odlg;
 //BA.debugLineNum = 17;BA.debugLine="Dim ac As Accessibility";
_ac = new anywheresoftware.b4a.objects.Accessibility();
 //BA.debugLineNum = 18;BA.debugLine="Scale = ac.GetUserFontScale";
_scale = _ac.GetUserFontScale();
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _nocloseon2nddialog() throws Exception{
 //BA.debugLineNum = 114;BA.debugLine="Public Sub NoCloseOn2ndDialog";
 //BA.debugLineNum = 116;BA.debugLine="dlg.Base.Parent.Tag = \"\" 'this will prevent the d";
_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getParent().setTag((Object)(""));
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _themedialogform(Object _title) throws Exception{
float _size = 0f;
 //BA.debugLineNum = 62;BA.debugLine="Public Sub ThemeDialogForm(title As Object)";
 //BA.debugLineNum = 63;BA.debugLine="Dim size As Float = IIf(guiHelpers.gScreenSizeApr";
_size = (float)(BA.ObjectToNumber(((_guihelpers._gscreensizeaprox /*double*/ >6) ? ((Object)(25)) : ((Object)(22)))));
 //BA.debugLineNum = 64;BA.debugLine="ThemeDialogForm2(title,size)";
_themedialogform2(_title,(int) (_size));
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _themedialogform2(Object _title,int _txtsize) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Public Sub ThemeDialogForm2(title As Object,txtSiz";
 //BA.debugLineNum = 70;BA.debugLine="Try";
try { //BA.debugLineNum = 71;BA.debugLine="dlg.Title = title";
_dlg._title /*Object*/  = _title;
 //BA.debugLineNum = 72;BA.debugLine="If guiHelpers.gScreenSizeAprox > 5.5 Then";
if (_guihelpers._gscreensizeaprox /*double*/ >5.5) { 
 //BA.debugLineNum = 73;BA.debugLine="dlg.TitleBarHeight=6%y";
_dlg._titlebarheight /*int*/  = __c.PerYToCurrent((float) (6),ba);
 };
 } 
       catch (Exception e7) {
			ba.setLastException(e7); };
 //BA.debugLineNum = 81;BA.debugLine="dlg.TitleBarFont = xui.CreateDefaultFont(NumberFo";
_dlg._titlebarfont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/  = _xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_txtsize/(double)_scale,(int) (1),(int) (0),(int) (0),__c.False))));
 //BA.debugLineNum = 82;BA.debugLine="dlg.TitleBarColor = clrTheme.BackgroundHeader";
_dlg._titlebarcolor /*int*/  = _clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 83;BA.debugLine="dlg.TitleBarTextColor = clrTheme.txtNormal";
_dlg._titlebartextcolor /*int*/  = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 84;BA.debugLine="dlg.ButtonsTextColor = clrTheme.txtNormal";
_dlg._buttonstextcolor /*int*/  = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 85;BA.debugLine="dlg.BorderColor = clrTheme.txtNormal";
_dlg._bordercolor /*int*/  = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 86;BA.debugLine="dlg.BackgroundColor = clrTheme.Background2";
_dlg._backgroundcolor /*int*/  = _clrtheme._background2 /*int*/ ;
 //BA.debugLineNum = 87;BA.debugLine="dlg.ButtonsFont = xui.CreateDefaultFont(txtSize)";
_dlg._buttonsfont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/  = _xui.CreateDefaultFont((float) (_txtsize));
 //BA.debugLineNum = 88;BA.debugLine="dlg.ButtonsHeight = 60dip";
_dlg._buttonsheight /*int*/  = __c.DipToCurrent((int) (60));
 //BA.debugLineNum = 89;BA.debugLine="dlg.BorderCornersRadius = 4dip";
_dlg._bordercornersradius /*int*/  = __c.DipToCurrent((int) (4));
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public String  _themeinputdialogbtnsresize() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _btncancel = null;
anywheresoftware.b4a.objects.B4XViewWrapper _btnok = null;
 //BA.debugLineNum = 22;BA.debugLine="Public Sub ThemeInputDialogBtnsResize()";
 //BA.debugLineNum = 24;BA.debugLine="Try '--- reskin button, if it does not exist then";
try { //BA.debugLineNum = 25;BA.debugLine="Dim btnCancel As B4XView = dlg.GetButton(xui.Dia";
_btncancel = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btncancel = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 26;BA.debugLine="btnCancel.Font = xui.CreateDefaultFont(NumberFor";
_btncancel.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_btncancel.getFont().getSize()/(double)_scale,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 27;BA.debugLine="btnCancel.Width = btnCancel.Width + 20dip";
_btncancel.setWidth((int) (_btncancel.getWidth()+__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 28;BA.debugLine="btnCancel.Left = btnCancel.Left - 28dip";
_btncancel.setLeft((int) (_btncancel.getLeft()-__c.DipToCurrent((int) (28))));
 //BA.debugLineNum = 29;BA.debugLine="btnCancel.SetColorAndBorder(xui.Color_Transparen";
_btncancel.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 30;BA.debugLine="btnCancel.Height = btnCancel.Height - 4dip '---";
_btncancel.setHeight((int) (_btncancel.getHeight()-__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 31;BA.debugLine="btnCancel.Top = btnCancel.Top + 4dip";
_btncancel.setTop((int) (_btncancel.getTop()+__c.DipToCurrent((int) (4))));
 } 
       catch (Exception e10) {
			ba.setLastException(e10); };
 //BA.debugLineNum = 36;BA.debugLine="Try '--- reskin button, if it does not exist then";
try { //BA.debugLineNum = 37;BA.debugLine="Dim btnOk As B4XView = dlg.GetButton(xui.DialogR";
_btnok = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnok = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive);
 //BA.debugLineNum = 38;BA.debugLine="btnOk.Font = xui.CreateDefaultFont(NumberFormat2";
_btnok.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_btnok.getFont().getSize()/(double)_scale,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 39;BA.debugLine="btnOk.Width = btnOk.Width + 20dip";
_btnok.setWidth((int) (_btnok.getWidth()+__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 40;BA.debugLine="btnOk.Left = btnOk.Left - 48dip";
_btnok.setLeft((int) (_btnok.getLeft()-__c.DipToCurrent((int) (48))));
 //BA.debugLineNum = 41;BA.debugLine="btnOk.SetColorAndBorder(xui.Color_Transparent,2d";
_btnok.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 42;BA.debugLine="btnOk.Height = btnOk.Height - 4dip '--- resize h";
_btnok.setHeight((int) (_btnok.getHeight()-__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 43;BA.debugLine="btnOk.Top = btnOk.Top + 4dip";
_btnok.setTop((int) (_btnok.getTop()+__c.DipToCurrent((int) (4))));
 } 
       catch (Exception e20) {
			ba.setLastException(e20); };
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
