package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgiponoffsetup extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgiponoffsetup");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgiponoffsetup.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.foss.sadpreferencesdialog _mprefdlg = null;
public sadLogic.OctoTouchController.foss.sadpreferencesdialoghelper _mprefhelper = null;
public Object _mcallbackmodule = null;
public String _mcallbackmethod = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"dlgIpOnOffSetu";
_mmodule = "dlgIpOnOffSetup";
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private mPrefDlg As sadPreferencesDialog";
_mprefdlg = new sadLogic.OctoTouchController.foss.sadpreferencesdialog();
 //BA.debugLineNum = 11;BA.debugLine="Private mPrefHelper As sadPreferencesDialogHelper";
_mprefhelper = new sadLogic.OctoTouchController.foss.sadpreferencesdialoghelper();
 //BA.debugLineNum = 12;BA.debugLine="Private mCallBackModule As Object";
_mcallbackmodule = new Object();
 //BA.debugLineNum = 13;BA.debugLine="Private mCallBackMethod As String";
_mcallbackmethod = "";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 31;BA.debugLine="mPrefDlg.Dialog.Close(xui.DialogResponse_Cancel)";
_mprefdlg._dialog /*sadLogic.OctoTouchController.foss.b4xdialog*/ ._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _createdefaultdatafile(String _datafilename) throws Exception{
String _desctxt = "";
 //BA.debugLineNum = 35;BA.debugLine="Public Sub CreateDefaultDataFile(dataFileName As S";
 //BA.debugLineNum = 37;BA.debugLine="fileHelpers.SafeKill(dataFileName)";
_filehelpers._safekill /*String*/ (ba,_datafilename);
 //BA.debugLineNum = 38;BA.debugLine="Dim descTxt As String";
_desctxt = "";
 //BA.debugLineNum = 39;BA.debugLine="If IsNumber(dataFileName.SubString2(0,1)) Then";
if (__c.IsNumber(_datafilename.substring((int) (0),(int) (1)))) { 
 //BA.debugLineNum = 40;BA.debugLine="descTxt = \"Generic HTTP Control: \"	& dataFileNam";
_desctxt = "Generic HTTP Control: "+_datafilename.substring((int) (0),(int) (1));
 }else {
 //BA.debugLineNum = 42;BA.debugLine="descTxt = \"Printer Power SonOff\"";
_desctxt = "Printer Power SonOff";
 };
 //BA.debugLineNum = 44;BA.debugLine="File.WriteMap(xui.DefaultFolder,dataFileName, _";
__c.File.WriteMap(_xui.getDefaultFolder(),_datafilename,__c.createMap(new Object[] {(Object)("desc"),(Object)(_desctxt),(Object)("ipon"),(Object)("http://192.168.1.235/cm?cmnd=Power On"),(Object)("ipoff"),(Object)("http://192.168.1.235/cm?cmnd=Power Off"),(Object)("active"),(Object)("false"),(Object)("tgl"),(Object)("false")}));
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _dlgevent_beforedialogdisplayed(Object _template) throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub dlgEvent_BeforeDialogDisplayed (Templa";
 //BA.debugLineNum = 122;BA.debugLine="mPrefHelper.SkinDialog(Template)";
_mprefhelper._skindialog /*String*/ (_template);
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public boolean  _dlgevent_isvalid(anywheresoftware.b4a.objects.collections.Map _tempdata) throws Exception{
boolean _retval = false;
 //BA.debugLineNum = 113;BA.debugLine="Private Sub dlgEvent_IsValid (TempData As Map) As";
 //BA.debugLineNum = 115;BA.debugLine="Dim retval As Boolean = True";
_retval = __c.True;
 //BA.debugLineNum = 116;BA.debugLine="Return retval '--- all is good!";
if (true) return _retval;
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return false;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,Object _callbackmod,String _callbackmethod) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize(callbackMod As Object, callb";
 //BA.debugLineNum = 17;BA.debugLine="mCallBackModule = callbackMod";
_mcallbackmodule = _callbackmod;
 //BA.debugLineNum = 18;BA.debugLine="mCallBackMethod = callbackMethod";
_mcallbackmethod = _callbackmethod;
 //BA.debugLineNum = 19;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return null;
}
public void  _show(String _title,String _datafilename) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_title,_datafilename);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgiponoffsetup parent,String _title,String _datafilename) {
this.parent = parent;
this._title = _title;
this._datafilename = _datafilename;
}
sadLogic.OctoTouchController.foss.dlgiponoffsetup parent;
String _title;
String _datafilename;
anywheresoftware.b4a.objects.collections.Map _data = null;
boolean _totop = false;
float _h = 0f;
float _w = 0f;
String _s = "";
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 55;BA.debugLine="If File.Exists(xui.DefaultFolder,dataFileName) =";
if (true) break;

case 1:
//if
this.state = 4;
if (parent.__c.File.Exists(parent._xui.getDefaultFolder(),_datafilename)==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 56;BA.debugLine="CreateDefaultDataFile(dataFileName)";
parent._createdefaultdatafile(_datafilename);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 59;BA.debugLine="Dim data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = parent.__c.File.ReadMap(parent._xui.getDefaultFolder(),_datafilename);
 //BA.debugLineNum = 60;BA.debugLine="Dim ToTop As Boolean = False";
_totop = parent.__c.False;
 //BA.debugLineNum = 62;BA.debugLine="Dim h,w As Float";
_h = 0f;
_w = 0f;
 //BA.debugLineNum = 63;BA.debugLine="If guiHelpers.gScreenSizeAprox >= 6 And guiHelper";
if (true) break;

case 5:
//if
this.state = 12;
if (parent._guihelpers._gscreensizeaprox /*double*/ >=6 && parent._guihelpers._gscreensizeaprox /*double*/ <=8) { 
this.state = 7;
}else if(parent._guihelpers._gscreensizeaprox /*double*/ >=8) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 7:
//C
this.state = 12;
 //BA.debugLineNum = 64;BA.debugLine="h = 62%y";
_h = (float) (parent.__c.PerYToCurrent((float) (62),ba));
 if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 66;BA.debugLine="h = 52%y";
_h = (float) (parent.__c.PerYToCurrent((float) (52),ba));
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 68;BA.debugLine="h = 60%y";
_h = (float) (parent.__c.PerYToCurrent((float) (60),ba));
 if (true) break;
;
 //BA.debugLineNum = 71;BA.debugLine="If guiHelpers.gIsLandScape = False Then";

case 12:
//if
this.state = 17;
if (parent._guihelpers._gislandscape /*boolean*/ ==parent.__c.False) { 
this.state = 14;
}else {
this.state = 16;
}if (true) break;

case 14:
//C
this.state = 17;
 //BA.debugLineNum = 72;BA.debugLine="w = 92%x";
_w = (float) (parent.__c.PerXToCurrent((float) (92),ba));
 if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 74;BA.debugLine="w = 420dip";
_w = (float) (parent.__c.DipToCurrent((int) (420)));
 if (true) break;

case 17:
//C
this.state = 18;
;
 //BA.debugLineNum = 78;BA.debugLine="mPrefDlg.Initialize(B4XPages.MainPage.root, title";
parent._mprefdlg._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,(Object)(_title),(int) (_w),(int) (_h));
 //BA.debugLineNum = 79;BA.debugLine="Dim s As String = File.ReadString(File.DirAssets,";
_s = parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"dlgonoff.json");
 //BA.debugLineNum = 80;BA.debugLine="If guiHelpers.gIsPortrait Then s = s.Replace(\"1st";
if (true) break;

case 18:
//if
this.state = 23;
if (parent._guihelpers._gisportrait /*boolean*/ (ba)) { 
this.state = 20;
;}if (true) break;

case 20:
//C
this.state = 23;
_s = _s.replace("1st Command ","1st Cmd ");
if (true) break;

case 23:
//C
this.state = 24;
;
 //BA.debugLineNum = 81;BA.debugLine="mPrefDlg.LoadFromJson(s)";
parent._mprefdlg._loadfromjson /*String*/ (_s);
 //BA.debugLineNum = 82;BA.debugLine="mPrefDlg.SetEventsListener(Me,\"dlgEvent\")";
parent._mprefdlg._seteventslistener /*String*/ (parent,"dlgEvent");
 //BA.debugLineNum = 84;BA.debugLine="mPrefHelper.Initialize(mPrefDlg)";
parent._mprefhelper._initialize /*String*/ (ba,parent._mprefdlg);
 //BA.debugLineNum = 86;BA.debugLine="mPrefHelper.ThemePrefDialogForm";
parent._mprefhelper._themeprefdialogform /*String*/ ();
 //BA.debugLineNum = 87;BA.debugLine="mPrefDlg.PutAtTop = ToTop";
parent._mprefdlg._putattop /*Object*/  = (Object)(_totop);
 //BA.debugLineNum = 88;BA.debugLine="Dim RS As ResumableSub = mPrefDlg.ShowDialog(data";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mprefdlg._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_data,(Object)("SAVE"),(Object)("CLOSE"));
 //BA.debugLineNum = 89;BA.debugLine="mPrefHelper.dlgHelper.NoCloseOn2ndDialog";
parent._mprefhelper._dlghelper /*sadLogic.OctoTouchController.foss.sadb4xdialoghelper*/ ._nocloseon2nddialog /*String*/ ();
 //BA.debugLineNum = 90;BA.debugLine="mPrefHelper.dlgHelper.ThemeInputDialogBtnsResize";
parent._mprefhelper._dlghelper /*sadLogic.OctoTouchController.foss.sadb4xdialoghelper*/ ._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 93;BA.debugLine="Wait For (RS) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 32;
return;
case 32:
//C
this.state = 24;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 94;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 24:
//if
this.state = 31;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 26;
}if (true) break;

case 26:
//C
this.state = 27;
 //BA.debugLineNum = 95;BA.debugLine="guiHelpers.Show_toast(gblConst.DATA_SAVED,1500)";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._data_saved /*String*/ ,(int) (1500));
 //BA.debugLineNum = 96;BA.debugLine="File.WriteMap(xui.DefaultFolder,dataFileName,dat";
parent.__c.File.WriteMap(parent._xui.getDefaultFolder(),_datafilename,_data);
 //BA.debugLineNum = 98;BA.debugLine="If SubExists(mCallBackModule,mCallBackMethod) Th";
if (true) break;

case 27:
//if
this.state = 30;
if (parent.__c.SubExists(ba,parent._mcallbackmodule,parent._mcallbackmethod)) { 
this.state = 29;
}if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 99;BA.debugLine="CallSubDelayed2(mCallBackModule,mCallBackMethod";
parent.__c.CallSubDelayed2(ba,parent._mcallbackmodule,parent._mcallbackmethod,(Object)(_data));
 if (true) break;

case 30:
//C
this.state = 31;
;
 //BA.debugLineNum = 102;BA.debugLine="CallSubDelayed(B4XPages.MainPage.oPageCurrent,\"S";
parent.__c.CallSubDelayed(ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._opagecurrent /*Object*/ ,"Set_focus");
 if (true) break;

case 31:
//C
this.state = -1;
;
 //BA.debugLineNum = 105;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 106;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"PopupPluginOpti";
parent.__c.CallSubDelayed(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"PopupPluginOptionMenu");
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public boolean  _visible() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Visible() As Boolean";
 //BA.debugLineNum = 23;BA.debugLine="Try";
try { //BA.debugLineNum = 24;BA.debugLine="Return mPrefDlg.Dialog.Visible";
if (true) return _mprefdlg._dialog /*sadLogic.OctoTouchController.foss.b4xdialog*/ ._getvisible /*boolean*/ ();
 } 
       catch (Exception e4) {
			ba.setLastException(e4); //BA.debugLineNum = 26;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
