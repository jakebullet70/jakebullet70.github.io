package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgvolume extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgvolume");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgvolume.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.phone.Phone _ph = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public anywheresoftware.b4a.objects.LabelWrapper _label3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label1 = null;
public sadLogic.HomeCentral.b4xcombobox _cbosounds = null;
public sadLogic.HomeCentral.b4xseekbar _sbtimervol = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btntest = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltmrvol = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltimervol = null;
public int _mpvol = 0;
public int _maxvolumemusic = 0;
public int _maxvolumenotifaction = 0;
public int _maxvolumesys = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btntest_click() throws Exception{
 //BA.debugLineNum = 113;BA.debugLine="Private Sub btnTest_Click";
 //BA.debugLineNum = 114;BA.debugLine="vol_timers.PlaySound(sbTimerVol.Value,vol_timers.";
_vol_timers._playsound /*void*/ (ba,_sbtimervol._getvalue /*int*/ (),_vol_timers._buildalarmfile /*String*/ (ba,_cbosounds._getselecteditem /*String*/ ()));
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 10;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 13;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private Label3,Label1 As Label";
_label3 = new anywheresoftware.b4a.objects.LabelWrapper();
_label1 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private cboSounds As B4XComboBox";
_cbosounds = new sadLogic.HomeCentral.b4xcombobox();
 //BA.debugLineNum = 17;BA.debugLine="Private sbTimerVol As B4XSeekBar";
_sbtimervol = new sadLogic.HomeCentral.b4xseekbar();
 //BA.debugLineNum = 19;BA.debugLine="Private btnTest As Button";
_btntest = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private lblTmrVol As B4XView";
_lbltmrvol = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private pnlTimerVol As Panel";
_pnltimervol = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private mpVol As Int  'ignore";
_mpvol = 0;
 //BA.debugLineNum = 28;BA.debugLine="Private MaxVolumeMusic,MaxVolumeNotifaction,MaxVo";
_maxvolumemusic = 0;
_maxvolumenotifaction = 0;
_maxvolumesys = 0;
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Initialize(dlg As B4XDialog)";
 //BA.debugLineNum = 33;BA.debugLine="mDialog = dlg";
_mdialog = _dlg;
 //BA.debugLineNum = 41;BA.debugLine="MaxVolumeMusic = 		ph.GetMaxVolume(ph.VOLUME_MUSI";
_maxvolumemusic = _ph.GetMaxVolume(_ph.VOLUME_MUSIC);
 //BA.debugLineNum = 42;BA.debugLine="MaxVolumeNotifaction = 	ph.GetMaxVolume(ph.VOLUME";
_maxvolumenotifaction = _ph.GetMaxVolume(_ph.VOLUME_NOTIFICATION);
 //BA.debugLineNum = 43;BA.debugLine="MaxVolumeSys = 			ph.GetMaxVolume(ph.VOLUME_SYSTE";
_maxvolumesys = _ph.GetMaxVolume(_ph.VOLUME_SYSTEM);
 //BA.debugLineNum = 45;BA.debugLine="Log(\"VOLUME_SYSTEM\"&ph.GetVolume(ph.VOLUME_SYSTEM";
__c.LogImpl("25165837","VOLUME_SYSTEM"+BA.NumberToString(_ph.GetVolume(_ph.VOLUME_SYSTEM)),0);
 //BA.debugLineNum = 46;BA.debugLine="Log(\"VOLUME_MUSIC\"&ph.GetVolume(ph.VOLUME_MUSIC))";
__c.LogImpl("25165838","VOLUME_MUSIC"+BA.NumberToString(_ph.GetVolume(_ph.VOLUME_MUSIC)),0);
 //BA.debugLineNum = 47;BA.debugLine="Log(\"VOLUME_SYSTEM-------------------------------";
__c.LogImpl("25165839","VOLUME_SYSTEM-------------------------------",0);
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public String  _sbtimervol_valuechanged(int _value) throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Private Sub sbTimerVol_ValueChanged (Value As Int)";
 //BA.debugLineNum = 110;BA.debugLine="lblTmrVol.Text = Value & \"%\"";
_lbltmrvol.setText(BA.ObjectToCharSequence(BA.NumberToString(_value)+"%"));
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public void  _show(String _voltype) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_voltype);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgvolume parent,String _voltype) {
this.parent = parent;
this._voltype = _voltype;
}
sadLogic.HomeCentral.dlgvolume parent;
String _voltype;
sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _tmp = 0;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 56;BA.debugLine="mDialog.Initialize(mpage.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 57;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 58;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 60;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 61;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 640dip,290dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (640)),parent.__c.DipToCurrent((int) (290)));
 //BA.debugLineNum = 62;BA.debugLine="p.LoadLayout(\"dlgVolumeSettings\")";
_p.LoadLayout("dlgVolumeSettings",ba);
 //BA.debugLineNum = 64;BA.debugLine="pnlMain.Color = clrTheme.Background";
parent._pnlmain.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 65;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(Label3,L";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._label3.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._label1.getObject())),parent._lbltmrvol},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 66;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnTest))";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btntest});
 //BA.debugLineNum = 69;BA.debugLine="btnTest.Text = \"Test\"";
parent._btntest.setText(BA.ObjectToCharSequence("Test"));
 //BA.debugLineNum = 71;BA.debugLine="guiHelpers.ReSkinB4XComboBox(Array As B4XComboBox";
parent._guihelpers._reskinb4xcombobox /*String*/ (ba,new sadLogic.HomeCentral.b4xcombobox[]{parent._cbosounds});
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.SetPanelsBorder(Array As B4XView(pnlTi";
parent._guihelpers._setpanelsborder /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnltimervol.getObject()))},parent._clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 74;BA.debugLine="guiHelpers.ResizeText(\"100%\",lblTmrVol)";
parent._guihelpers._resizetext /*String*/ (ba,"100%",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lbltmrvol.getObject())));
 //BA.debugLineNum = 75;BA.debugLine="vol_timers.SelectItemInCBO(cboSounds,Main.kvs.Get";
parent._vol_timers._selectitemincbo /*String*/ (ba,parent._cbosounds,BA.ObjectToString(parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (parent._gblconst._ini_timers_alarm_file /*String*/ )));
 //BA.debugLineNum = 76;BA.debugLine="guiHelpers.ReSkinB4XSeekBar(Array As B4XSeekBar(s";
parent._guihelpers._reskinb4xseekbar /*String*/ (ba,new sadLogic.HomeCentral.b4xseekbar[]{parent._sbtimervol});
 //BA.debugLineNum = 78;BA.debugLine="If VolType = \"kt\" Then";
if (true) break;

case 1:
//if
this.state = 6;
if ((_voltype).equals("kt")) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 79;BA.debugLine="dlgHelper.ThemeDialogForm(\"Timer Volume\") '--- k";
_dlghelper._themedialogform /*String*/ ((Object)("Timer Volume"));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 81;BA.debugLine="dlgHelper.ThemeDialogForm(\"Volume ?\") '--- ONLY";
_dlghelper._themedialogform /*String*/ ((Object)("Volume ?"));
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 84;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"S";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("SAVE"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 85;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
_dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 87;BA.debugLine="Try";
if (true) break;

case 7:
//try
this.state = 12;
this.catchState = 11;
this.state = 9;
if (true) break;

case 9:
//C
this.state = 12;
this.catchState = 11;
 //BA.debugLineNum = 90;BA.debugLine="Log(\"current sys vol: \" & ph.GetVolume(ph.VOLUME";
parent.__c.LogImpl("25231397","current sys vol: "+BA.NumberToString(parent._ph.GetVolume(parent._ph.VOLUME_SYSTEM)),0);
 //BA.debugLineNum = 91;BA.debugLine="Dim tmp As Int = ph.GetVolume(ph.VOLUME_MUSIC)'i";
_tmp = parent._ph.GetVolume(parent._ph.VOLUME_MUSIC);
 if (true) break;

case 11:
//C
this.state = 12;
this.catchState = 0;
 //BA.debugLineNum = 93;BA.debugLine="guiHelpers.Show_toast2(gblConst.VOLUME_ERR,4500)";
parent._guihelpers._show_toast2 /*String*/ (ba,parent._gblconst._volume_err /*String*/ ,(int) (4500));
 //BA.debugLineNum = 94;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("25231401",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 12:
//C
this.state = 13;
this.catchState = 0;
;
 //BA.debugLineNum = 97;BA.debugLine="sbTimerVol.Value = Main.kvs.Get(gblConst.INI_TIME";
parent._sbtimervol._setvalue /*int*/ ((int)(BA.ObjectToNumber(parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (parent._gblconst._ini_timers_alarm_volume /*String*/ ))));
 //BA.debugLineNum = 98;BA.debugLine="sbTimerVol_ValueChanged(sbTimerVol.Value)";
parent._sbtimervol_valuechanged(parent._sbtimervol._getvalue /*int*/ ());
 //BA.debugLineNum = 101;BA.debugLine="Wait For (rs) Complete (i As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 17;
return;
case 17:
//C
this.state = 13;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 102;BA.debugLine="If i = xui.DialogResponse_Positive Then '--- save";
if (true) break;

case 13:
//if
this.state = 16;
if (_i==parent._xui.DialogResponse_Positive) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 103;BA.debugLine="vol_timers.SaveTimerVolume(cboSounds.SelectedIte";
parent._vol_timers._savetimervolume /*String*/ (ba,parent._cbosounds._getselecteditem /*String*/ (),parent._sbtimervol._getvalue /*int*/ ());
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
