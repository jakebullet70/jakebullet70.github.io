package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class octoklippymisc extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.octoklippymisc");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.octoklippymisc.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _key1stinit = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"OctoKlippyMisc";
_mmodule = "OctoKlippyMisc";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private Const key1stInit As String = \"1stRunCopyD";
_key1stinit = "1stRunCopyDefGCode";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _createdefgcodefiles() throws Exception{
sadLogic.OctoTouchController.foss.optionscfgseed _oseed = null;
 //BA.debugLineNum = 43;BA.debugLine="Public Sub CreateDefGCodeFiles";
 //BA.debugLineNum = 47;BA.debugLine="If Main.kvs.GetDefault(key1stInit,False) = False";
if ((_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ (_key1stinit,(Object)(__c.False))).equals((Object)(__c.False))) { 
 //BA.debugLineNum = 49;BA.debugLine="Dim oSeed As OptionsCfgSeed : oSeed.Initialize";
_oseed = new sadLogic.OctoTouchController.foss.optionscfgseed();
 //BA.debugLineNum = 49;BA.debugLine="Dim oSeed As OptionsCfgSeed : oSeed.Initialize";
_oseed._initialize /*String*/ (ba);
 //BA.debugLineNum = 52;BA.debugLine="fileHelpers.SafeKill(\"0\" & gblConst.GCODE_CUSTOM";
_filehelpers._safekill /*String*/ (getActivityBA(),"0"+_gblconst._gcode_custom_setup_file /*String*/ );
 //BA.debugLineNum = 54;BA.debugLine="File.WriteMap(XUI.DefaultFolder,\"0\" & gblConst.G";
__c.File.WriteMap(_xui.getDefaultFolder(),"0"+_gblconst._gcode_custom_setup_file /*String*/ ,_oseed._seedgcode1strun /*anywheresoftware.b4a.objects.collections.Map*/ ());
 //BA.debugLineNum = 57;BA.debugLine="Main.kvs.Put(key1stInit,True) '--- lets never do";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_key1stinit,(Object)(__c.True));
 };
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _createdefgcodefiles_force() throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Public Sub CreateDefGCodeFiles_Force";
 //BA.debugLineNum = 39;BA.debugLine="Main.kvs.Remove(key1stInit)";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._remove /*String*/ (_key1stinit);
 //BA.debugLineNum = 40;BA.debugLine="CreateDefGCodeFiles";
_createdefgcodefiles();
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _isoctoklipper() throws Exception{
ResumableSub_IsOctoKlipper rsub = new ResumableSub_IsOctoKlipper(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_IsOctoKlipper extends BA.ResumableSub {
public ResumableSub_IsOctoKlipper(sadLogic.OctoTouchController.foss.octoklippymisc parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.octoklippymisc parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
sadLogic.OctoTouchController.foss.jsonparsorplugins _o = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 18;BA.debugLine="Dim rs As ResumableSub =  B4XPages.MainPage.oMast";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (parent.getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._sendrequestgetinfo /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("/plugin/pluginmanager/plugins");
 //BA.debugLineNum = 19;BA.debugLine="Wait For(rs) Complete (Result As String)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 9;
return;
case 9:
//C
this.state = 1;
_result = (String) result[0];
;
 //BA.debugLineNum = 21;BA.debugLine="If Result.Length <> 0 Then";
if (true) break;

case 1:
//if
this.state = 8;
if (_result.length()!=0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 23;BA.debugLine="Dim o As JsonParsorPlugins  : o.Initialize";
_o = new sadLogic.OctoTouchController.foss.jsonparsorplugins();
 //BA.debugLineNum = 23;BA.debugLine="Dim o As JsonParsorPlugins  : o.Initialize";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 24;BA.debugLine="If o.IsOctoKlipperRunning(Result) = True Then";
if (true) break;

case 4:
//if
this.state = 7;
if (_o._isoctoklipperrunning /*boolean*/ (_result)==parent.__c.True) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 25;BA.debugLine="oc.Klippy = True";
parent._oc._klippy /*boolean*/  = parent.__c.True;
 if (true) break;

case 7:
//C
this.state = 8;
;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 31;BA.debugLine="Main.kvs.Put(gblConst.IS_OCTO_KLIPPY,oc.Klippy)";
parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (parent._gblconst._is_octo_klippy /*String*/ ,(Object)(parent._oc._klippy /*boolean*/ ));
 //BA.debugLineNum = 32;BA.debugLine="Return oc.Klippy";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._oc._klippy /*boolean*/ ));return;};
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
