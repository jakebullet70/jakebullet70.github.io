package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_dlgthemeselect{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbg").vw.setLeft((int)(0d));
views.get("pnlbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbg").vw.setTop((int)(0d));
views.get("pnlbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlthemebg").vw.setHeight((int)((views.get("pnlbg").vw.getHeight())-(80d * scale)));
if ((BA.ObjectToBoolean( String.valueOf(!anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("pnlbtns").vw.setLeft((int)(0d));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlbg").vw.getLeft() + views.get("pnlbg").vw.getWidth()) - (0d)));
views.get("pnlbtns").vw.setTop((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(60d * scale)));
views.get("pnlbtns").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight()) - ((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(60d * scale))));
views.get("spinner1").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("spinner1").vw.getHeight() / 2)));
views.get("spinner1").vw.setLeft((int)((10d * scale)));
views.get("btnclose").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btnsave").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
views.get("btnclose").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnclose").vw.getHeight() / 2)));
views.get("btnsave").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnsave").vw.getHeight() / 2)));
views.get("btnclose").vw.setLeft((int)((views.get("pnlbtns").vw.getLeft() + views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnclose").vw.getWidth())));
views.get("btnsave").vw.setLeft((int)((views.get("btnclose").vw.getLeft())-(4d * scale) - (views.get("btnsave").vw.getWidth())));
//BA.debugLineNum = 22;BA.debugLine="pnlThemeBG.Width = pnlBG.Width - 40dip"[dlgThemeSelect/General script]
views.get("pnlthemebg").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())-(40d * scale)));
//BA.debugLineNum = 23;BA.debugLine="pnlThemeMenu.Width = (pnlThemeBG.Width / 2) - 40dip"[dlgThemeSelect/General script]
views.get("pnlthememenu").vw.setWidth((int)(((views.get("pnlthemebg").vw.getWidth())/2d)-(40d * scale)));
//BA.debugLineNum = 24;BA.debugLine="pnlThemeHeader.SetLeftAndRight(10dip,pnlThemeBG.Width - 10dip)"[dlgThemeSelect/General script]
views.get("pnlthemeheader").vw.setLeft((int)((10d * scale)));
views.get("pnlthemeheader").vw.setWidth((int)((views.get("pnlthemebg").vw.getWidth())-(10d * scale) - ((10d * scale))));
//BA.debugLineNum = 25;BA.debugLine="pnlThemeBG.HorizontalCenter = pnlBG.Width /2"[dlgThemeSelect/General script]
views.get("pnlthemebg").vw.setLeft((int)((views.get("pnlbg").vw.getWidth())/2d - (views.get("pnlthemebg").vw.getWidth() / 2)));
//BA.debugLineNum = 26;BA.debugLine="pnlTexts.SetLeftAndRight(pnlThemeMenu.Right+10dip,pnlThemeBG.Right-30dip)"[dlgThemeSelect/General script]
views.get("pnltexts").vw.setLeft((int)((views.get("pnlthememenu").vw.getLeft() + views.get("pnlthememenu").vw.getWidth())+(10d * scale)));
views.get("pnltexts").vw.setWidth((int)((views.get("pnlthemebg").vw.getLeft() + views.get("pnlthemebg").vw.getWidth())-(30d * scale) - ((views.get("pnlthememenu").vw.getLeft() + views.get("pnlthememenu").vw.getWidth())+(10d * scale))));
//BA.debugLineNum = 27;BA.debugLine="lblText.HorizontalCenter = pnlTexts.Width / 2"[dlgThemeSelect/General script]
views.get("lbltext").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbltext").vw.getWidth() / 2)));
//BA.debugLineNum = 28;BA.debugLine="lblTextAcc.HorizontalCenter  = pnlTexts.Width / 2"[dlgThemeSelect/General script]
views.get("lbltextacc").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbltextacc").vw.getWidth() / 2)));
//BA.debugLineNum = 29;BA.debugLine="lblDisabled.HorizontalCenter = pnlTexts.Width / 2"[dlgThemeSelect/General script]
views.get("lbldisabled").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbldisabled").vw.getWidth() / 2)));
//BA.debugLineNum = 30;BA.debugLine="lblText1.HorizontalCenter    = pnlThemeHeader.Width /2"[dlgThemeSelect/General script]
views.get("lbltext1").vw.setLeft((int)((views.get("pnlthemeheader").vw.getWidth())/2d - (views.get("lbltext1").vw.getWidth() / 2)));
//BA.debugLineNum = 31;BA.debugLine="Else"[dlgThemeSelect/General script]
;}else{ 
;
//BA.debugLineNum = 33;BA.debugLine="pnlBtns.SetLeftAndRight(0,pnlBG.Width)"[dlgThemeSelect/General script]
views.get("pnlbtns").vw.setLeft((int)(0d));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlbg").vw.getWidth()) - (0d)));
//BA.debugLineNum = 34;BA.debugLine="pnlBtns.SetTopAndBottom(pnlBG.Bottom-60dip,pnlBG.Bottom)"[dlgThemeSelect/General script]
views.get("pnlbtns").vw.setTop((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(60d * scale)));
views.get("pnlbtns").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight()) - ((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(60d * scale))));
//BA.debugLineNum = 35;BA.debugLine="Spinner1.VerticalCenter = pnlBtns.Height/2"[dlgThemeSelect/General script]
views.get("spinner1").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("spinner1").vw.getHeight() / 2)));
//BA.debugLineNum = 36;BA.debugLine="Spinner1.Left = 8dip"[dlgThemeSelect/General script]
views.get("spinner1").vw.setLeft((int)((8d * scale)));
//BA.debugLineNum = 38;BA.debugLine="btnClose.Height = pnlBtns.Height - 10dip"[dlgThemeSelect/General script]
views.get("btnclose").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
//BA.debugLineNum = 39;BA.debugLine="btnSave.Height = pnlBtns.Height - 10dip"[dlgThemeSelect/General script]
views.get("btnsave").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(10d * scale)));
//BA.debugLineNum = 40;BA.debugLine="btnClose.VerticalCenter = pnlBtns.Height/2"[dlgThemeSelect/General script]
views.get("btnclose").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnclose").vw.getHeight() / 2)));
//BA.debugLineNum = 41;BA.debugLine="btnSave.VerticalCenter = pnlBtns.Height/2"[dlgThemeSelect/General script]
views.get("btnsave").vw.setTop((int)((views.get("pnlbtns").vw.getHeight())/2d - (views.get("btnsave").vw.getHeight() / 2)));
//BA.debugLineNum = 42;BA.debugLine="btnClose.Right = pnlBtns.Right - 8dip"[dlgThemeSelect/General script]
views.get("btnclose").vw.setLeft((int)((views.get("pnlbtns").vw.getLeft() + views.get("pnlbtns").vw.getWidth())-(8d * scale) - (views.get("btnclose").vw.getWidth())));
//BA.debugLineNum = 43;BA.debugLine="btnSave.Right = btnClose.Left - 4dip"[dlgThemeSelect/General script]
views.get("btnsave").vw.setLeft((int)((views.get("btnclose").vw.getLeft())-(4d * scale) - (views.get("btnsave").vw.getWidth())));
//BA.debugLineNum = 46;BA.debugLine="pnlThemeBG.SetLeftAndRight(10dip,pnlBG.Width - 10dip)"[dlgThemeSelect/General script]
views.get("pnlthemebg").vw.setLeft((int)((10d * scale)));
views.get("pnlthemebg").vw.setWidth((int)((views.get("pnlbg").vw.getWidth())-(10d * scale) - ((10d * scale))));
//BA.debugLineNum = 47;BA.debugLine="pnlThemeBG.SetTopAndBottom(pnlBG.Top+10dip,pnlBG.Bottom-100dip)"[dlgThemeSelect/General script]
views.get("pnlthemebg").vw.setTop((int)((views.get("pnlbg").vw.getTop())+(10d * scale)));
views.get("pnlthemebg").vw.setHeight((int)((views.get("pnlbg").vw.getTop() + views.get("pnlbg").vw.getHeight())-(100d * scale) - ((views.get("pnlbg").vw.getTop())+(10d * scale))));
//BA.debugLineNum = 48;BA.debugLine="pnlThemeHeader.SetLeftAndRight(10dip,pnlThemeBG.Right-20dip)"[dlgThemeSelect/General script]
views.get("pnlthemeheader").vw.setLeft((int)((10d * scale)));
views.get("pnlthemeheader").vw.setWidth((int)((views.get("pnlthemebg").vw.getLeft() + views.get("pnlthemebg").vw.getWidth())-(20d * scale) - ((10d * scale))));
//BA.debugLineNum = 49;BA.debugLine="pnlThemeHeader.Top = 18dip"[dlgThemeSelect/General script]
views.get("pnlthemeheader").vw.setTop((int)((18d * scale)));
//BA.debugLineNum = 50;BA.debugLine="pnlThemeMenu.SetLeftAndRight(20dip,pnlThemeBG.Width-20dip)"[dlgThemeSelect/General script]
views.get("pnlthememenu").vw.setLeft((int)((20d * scale)));
views.get("pnlthememenu").vw.setWidth((int)((views.get("pnlthemebg").vw.getWidth())-(20d * scale) - ((20d * scale))));
//BA.debugLineNum = 51;BA.debugLine="pnlThemeMenu.SetTopAndBottom(pnlThemeHeader.Bottom+8dip,pnlThemeBG.Height/2)"[dlgThemeSelect/General script]
views.get("pnlthememenu").vw.setTop((int)((views.get("pnlthemeheader").vw.getTop() + views.get("pnlthemeheader").vw.getHeight())+(8d * scale)));
views.get("pnlthememenu").vw.setHeight((int)((views.get("pnlthemebg").vw.getHeight())/2d - ((views.get("pnlthemeheader").vw.getTop() + views.get("pnlthemeheader").vw.getHeight())+(8d * scale))));
//BA.debugLineNum = 52;BA.debugLine="pnlTexts.SetLeftAndRight(pnlThemeBG.Left+10dip,pnlThemeBG.Width-20dip)"[dlgThemeSelect/General script]
views.get("pnltexts").vw.setLeft((int)((views.get("pnlthemebg").vw.getLeft())+(10d * scale)));
views.get("pnltexts").vw.setWidth((int)((views.get("pnlthemebg").vw.getWidth())-(20d * scale) - ((views.get("pnlthemebg").vw.getLeft())+(10d * scale))));
//BA.debugLineNum = 53;BA.debugLine="End If"[dlgThemeSelect/General script]
;};
//BA.debugLineNum = 55;BA.debugLine="lblText2.SetLeftAndRight(8dip,pnlThemeMenu.Width-8dip)"[dlgThemeSelect/General script]
views.get("lbltext2").vw.setLeft((int)((8d * scale)));
views.get("lbltext2").vw.setWidth((int)((views.get("pnlthememenu").vw.getWidth())-(8d * scale) - ((8d * scale))));
//BA.debugLineNum = 56;BA.debugLine="lblCustom.SetLeftAndRight(8dip,pnlThemeMenu.Width-8dip)"[dlgThemeSelect/General script]
views.get("lblcustom").vw.setLeft((int)((8d * scale)));
views.get("lblcustom").vw.setWidth((int)((views.get("pnlthememenu").vw.getWidth())-(8d * scale) - ((8d * scale))));
//BA.debugLineNum = 59;BA.debugLine="If Landscape Then"[dlgThemeSelect/General script]
if ((BA.ObjectToBoolean( String.valueOf(!anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
//BA.debugLineNum = 60;BA.debugLine="pnlThemeMenu.Height = pnlThemeBG.Height - 100dip"[dlgThemeSelect/General script]
views.get("pnlthememenu").vw.setHeight((int)((views.get("pnlthemebg").vw.getHeight())-(100d * scale)));
//BA.debugLineNum = 61;BA.debugLine="lblCustom.Bottom = pnlThemeMenu.Height - 4dip"[dlgThemeSelect/General script]
views.get("lblcustom").vw.setTop((int)((views.get("pnlthememenu").vw.getHeight())-(4d * scale) - (views.get("lblcustom").vw.getHeight())));
//BA.debugLineNum = 62;BA.debugLine="lblThemeBG.HorizontalCenter = pnlThemeBG.Width/2"[dlgThemeSelect/General script]
views.get("lblthemebg").vw.setLeft((int)((views.get("pnlthemebg").vw.getWidth())/2d - (views.get("lblthemebg").vw.getWidth() / 2)));
//BA.debugLineNum = 63;BA.debugLine="lblThemeBG.Bottom= pnlThemeBG.Height"[dlgThemeSelect/General script]
views.get("lblthemebg").vw.setTop((int)((views.get("pnlthemebg").vw.getHeight()) - (views.get("lblthemebg").vw.getHeight())));
//BA.debugLineNum = 64;BA.debugLine="Else"[dlgThemeSelect/General script]
;}else{ 
;
//BA.debugLineNum = 65;BA.debugLine="lblText.HorizontalCenter = pnlTexts.Width/2"[dlgThemeSelect/General script]
views.get("lbltext").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbltext").vw.getWidth() / 2)));
//BA.debugLineNum = 66;BA.debugLine="lblTextAcc.HorizontalCenter = pnlTexts.Width/2"[dlgThemeSelect/General script]
views.get("lbltextacc").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbltextacc").vw.getWidth() / 2)));
//BA.debugLineNum = 67;BA.debugLine="lblDisabled.HorizontalCenter = pnlTexts.Width/2"[dlgThemeSelect/General script]
views.get("lbldisabled").vw.setLeft((int)((views.get("pnltexts").vw.getWidth())/2d - (views.get("lbldisabled").vw.getWidth() / 2)));
//BA.debugLineNum = 68;BA.debugLine="lblThemeBG.HorizontalCenter = pnlThemeBG.Width/2"[dlgThemeSelect/General script]
views.get("lblthemebg").vw.setLeft((int)((views.get("pnlthemebg").vw.getWidth())/2d - (views.get("lblthemebg").vw.getWidth() / 2)));
//BA.debugLineNum = 69;BA.debugLine="lblThemeBG.Bottom= pnlThemeBG.Height"[dlgThemeSelect/General script]
views.get("lblthemebg").vw.setTop((int)((views.get("pnlthemebg").vw.getHeight()) - (views.get("lblthemebg").vw.getHeight())));
//BA.debugLineNum = 70;BA.debugLine="lblCustom.Bottom = pnlThemeMenu.Height - 4dip"[dlgThemeSelect/General script]
views.get("lblcustom").vw.setTop((int)((views.get("pnlthememenu").vw.getHeight())-(4d * scale) - (views.get("lblcustom").vw.getHeight())));
//BA.debugLineNum = 72;BA.debugLine="End If"[dlgThemeSelect/General script]
;};

}
}