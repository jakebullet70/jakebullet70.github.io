package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagecalculatorbase{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _tapesize="";
String _pad="";
String _btnht="";
String _btnvt="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
_tapesize = ".4";
views.get("scvpaperroll").vw.setLeft((int)((7d * scale)));
views.get("scvpaperroll").vw.setWidth((int)(((100d / 100 * width)*Double.parseDouble(_tapesize))-(7d * scale) - ((7d * scale))));
views.get("scvpaperroll").vw.setTop((int)((16d * scale)));
views.get("scvpaperroll").vw.setHeight((int)((100d / 100 * height)-(16d * scale) - ((16d * scale))));
views.get("imgpapertape").vw.setLeft((int)(0d));
views.get("imgpapertape").vw.setWidth((int)(((100d / 100 * width)*Double.parseDouble(_tapesize))-(6d * scale) - (0d)));
views.get("imgpapertape").vw.setTop((int)((0d * scale)));
views.get("imgpapertape").vw.setHeight((int)((100d / 100 * height) - ((0d * scale))));
views.get("pnlkeyboard").vw.setLeft((int)((views.get("scvpaperroll").vw.getWidth())+(4d / 100 * width)));
views.get("pnlkeyboard").vw.setWidth((int)((96d / 100 * width) - ((views.get("scvpaperroll").vw.getWidth())+(4d / 100 * width))));
views.get("pnlkeyboard").vw.setTop((int)((4d / 100 * height)));
views.get("pnlkeyboard").vw.setHeight((int)((96d / 100 * height) - ((4d / 100 * height))));
_pad = BA.NumberToString((6d * scale));
_btnht = BA.NumberToString((((views.get("pnlkeyboard").vw.getWidth())-Double.parseDouble(_pad))/5d));
_btnvt = BA.NumberToString((((views.get("pnlkeyboard").vw.getHeight())-Double.parseDouble(_pad))/4d));
views.get("btn7").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("btn7").vw.setWidth((int)(Double.parseDouble(_btnht) - (Double.parseDouble(_pad))));
views.get("btn7").vw.setTop((int)(Double.parseDouble(_pad)));
views.get("btn7").vw.setHeight((int)(Double.parseDouble(_btnvt) - (Double.parseDouble(_pad))));
views.get("btn8").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)));
views.get("btn8").vw.setWidth((int)(Double.parseDouble(_btnht)*2d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht))));
views.get("btn8").vw.setTop((int)(Double.parseDouble(_pad)));
views.get("btn8").vw.setHeight((int)(Double.parseDouble(_btnvt) - (Double.parseDouble(_pad))));
views.get("btn9").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d));
views.get("btn9").vw.setWidth((int)(Double.parseDouble(_btnht)*3d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d)));
views.get("btn9").vw.setTop((int)(Double.parseDouble(_pad)));
views.get("btn9").vw.setHeight((int)(Double.parseDouble(_btnvt) - (Double.parseDouble(_pad))));
views.get("btna").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d));
views.get("btna").vw.setWidth((int)(Double.parseDouble(_btnht)*4d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d)));
views.get("btna").vw.setTop((int)(Double.parseDouble(_pad)));
views.get("btna").vw.setHeight((int)(Double.parseDouble(_btnvt) - (Double.parseDouble(_pad))));
views.get("btncharsize").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d));
views.get("btncharsize").vw.setWidth((int)(Double.parseDouble(_btnht)*5d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d)));
views.get("btncharsize").vw.setTop((int)(Double.parseDouble(_pad)));
views.get("btncharsize").vw.setHeight((int)(Double.parseDouble(_btnvt) - (Double.parseDouble(_pad))));
views.get("btn4").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("btn4").vw.setWidth((int)(Double.parseDouble(_btnht) - (Double.parseDouble(_pad))));
views.get("btn4").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight())));
views.get("btn4").vw.setHeight((int)(Double.parseDouble(_btnvt)*2d - (Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight()))));
//BA.debugLineNum = 34;BA.debugLine="btn5.SetLeftAndRight(pad+btnHt,btnHt*2)"[pageCalculatorBase/General script]
views.get("btn5").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)));
views.get("btn5").vw.setWidth((int)(Double.parseDouble(_btnht)*2d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht))));
//BA.debugLineNum = 35;BA.debugLine="btn5.SetTopAndBottom(pad+btn7.Bottom,btnVt*2)"[pageCalculatorBase/General script]
views.get("btn5").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight())));
views.get("btn5").vw.setHeight((int)(Double.parseDouble(_btnvt)*2d - (Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight()))));
//BA.debugLineNum = 36;BA.debugLine="btn6.SetLeftAndRight(pad+btnHt*2,btnHt*3)"[pageCalculatorBase/General script]
views.get("btn6").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d));
views.get("btn6").vw.setWidth((int)(Double.parseDouble(_btnht)*3d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d)));
//BA.debugLineNum = 37;BA.debugLine="btn6.SetTopAndBottom(pad+btn7.Bottom,btnVt*2)"[pageCalculatorBase/General script]
views.get("btn6").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight())));
views.get("btn6").vw.setHeight((int)(Double.parseDouble(_btnvt)*2d - (Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight()))));
//BA.debugLineNum = 38;BA.debugLine="btnb.SetLeftAndRight(pad+btnHt*3,btnHt*4)"[pageCalculatorBase/General script]
views.get("btnb").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d));
views.get("btnb").vw.setWidth((int)(Double.parseDouble(_btnht)*4d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d)));
//BA.debugLineNum = 39;BA.debugLine="btnb.SetTopAndBottom(pad+btn7.Bottom,btnVt*2)"[pageCalculatorBase/General script]
views.get("btnb").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight())));
views.get("btnb").vw.setHeight((int)(Double.parseDouble(_btnvt)*2d - (Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight()))));
//BA.debugLineNum = 40;BA.debugLine="btnClr.SetLeftAndRight(pad+btnHt*4,btnHt*5)"[pageCalculatorBase/General script]
views.get("btnclr").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d));
views.get("btnclr").vw.setWidth((int)(Double.parseDouble(_btnht)*5d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d)));
//BA.debugLineNum = 41;BA.debugLine="btnClr.SetTopAndBottom(pad+btn7.Bottom,btnVt*2)"[pageCalculatorBase/General script]
views.get("btnclr").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight())));
views.get("btnclr").vw.setHeight((int)(Double.parseDouble(_btnvt)*2d - (Double.parseDouble(_pad)+(views.get("btn7").vw.getTop() + views.get("btn7").vw.getHeight()))));
//BA.debugLineNum = 43;BA.debugLine="btn1.SetLeftAndRight(pad,btnHt)"[pageCalculatorBase/General script]
views.get("btn1").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("btn1").vw.setWidth((int)(Double.parseDouble(_btnht) - (Double.parseDouble(_pad))));
//BA.debugLineNum = 44;BA.debugLine="btn1.SetTopAndBottom(pad+btn4.Bottom,btnVt*3)"[pageCalculatorBase/General script]
views.get("btn1").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight())));
views.get("btn1").vw.setHeight((int)(Double.parseDouble(_btnvt)*3d - (Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight()))));
//BA.debugLineNum = 45;BA.debugLine="btn2.SetLeftAndRight(pad+btnHt,btnHt*2)"[pageCalculatorBase/General script]
views.get("btn2").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)));
views.get("btn2").vw.setWidth((int)(Double.parseDouble(_btnht)*2d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht))));
//BA.debugLineNum = 46;BA.debugLine="btn2.SetTopAndBottom(pad+btn4.Bottom,btnVt*3)"[pageCalculatorBase/General script]
views.get("btn2").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight())));
views.get("btn2").vw.setHeight((int)(Double.parseDouble(_btnvt)*3d - (Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight()))));
//BA.debugLineNum = 47;BA.debugLine="btn3.SetLeftAndRight(pad+btnHt*2,btnHt*3)"[pageCalculatorBase/General script]
views.get("btn3").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d));
views.get("btn3").vw.setWidth((int)(Double.parseDouble(_btnht)*3d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d)));
//BA.debugLineNum = 48;BA.debugLine="btn3.SetTopAndBottom(pad+btn4.Bottom,btnVt*3)"[pageCalculatorBase/General script]
views.get("btn3").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight())));
views.get("btn3").vw.setHeight((int)(Double.parseDouble(_btnvt)*3d - (Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight()))));
//BA.debugLineNum = 49;BA.debugLine="btnc.SetLeftAndRight(pad+btnHt*3,btnHt*4)"[pageCalculatorBase/General script]
views.get("btnc").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d));
views.get("btnc").vw.setWidth((int)(Double.parseDouble(_btnht)*4d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d)));
//BA.debugLineNum = 50;BA.debugLine="btnc.SetTopAndBottom(pad+btn4.Bottom,btnVt*3)"[pageCalculatorBase/General script]
views.get("btnc").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight())));
views.get("btnc").vw.setHeight((int)(Double.parseDouble(_btnvt)*3d - (Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight()))));
//BA.debugLineNum = 51;BA.debugLine="btnBack.SetLeftAndRight(pad+btnHt*4,btnHt*5)"[pageCalculatorBase/General script]
views.get("btnback").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d));
views.get("btnback").vw.setWidth((int)(Double.parseDouble(_btnht)*5d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d)));
//BA.debugLineNum = 52;BA.debugLine="btnBack.SetTopAndBottom(pad+btn4.Bottom,btnVt*3)"[pageCalculatorBase/General script]
views.get("btnback").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight())));
views.get("btnback").vw.setHeight((int)(Double.parseDouble(_btnvt)*3d - (Double.parseDouble(_pad)+(views.get("btn4").vw.getTop() + views.get("btn4").vw.getHeight()))));
//BA.debugLineNum = 55;BA.debugLine="btn0.SetLeftAndRight(pad,btnHt)"[pageCalculatorBase/General script]
views.get("btn0").vw.setLeft((int)(Double.parseDouble(_pad)));
views.get("btn0").vw.setWidth((int)(Double.parseDouble(_btnht) - (Double.parseDouble(_pad))));
//BA.debugLineNum = 56;BA.debugLine="btn0.SetTopAndBottom(pad+btn1.Bottom,btnVt*4)"[pageCalculatorBase/General script]
views.get("btn0").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight())));
views.get("btn0").vw.setHeight((int)(Double.parseDouble(_btnvt)*4d - (Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight()))));
//BA.debugLineNum = 57;BA.debugLine="btnp.SetLeftAndRight(pad+btnHt,btnHt*2)"[pageCalculatorBase/General script]
views.get("btnp").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)));
views.get("btnp").vw.setWidth((int)(Double.parseDouble(_btnht)*2d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht))));
//BA.debugLineNum = 58;BA.debugLine="btnp.SetTopAndBottom(pad+btn1.Bottom,btnVt*4)"[pageCalculatorBase/General script]
views.get("btnp").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight())));
views.get("btnp").vw.setHeight((int)(Double.parseDouble(_btnvt)*4d - (Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight()))));
//BA.debugLineNum = 59;BA.debugLine="btne.SetLeftAndRight(pad+btnHt*2,btnHt*3)"[pageCalculatorBase/General script]
views.get("btne").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d));
views.get("btne").vw.setWidth((int)(Double.parseDouble(_btnht)*3d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*2d)));
//BA.debugLineNum = 60;BA.debugLine="btne.SetTopAndBottom(pad+btn1.Bottom,btnVt*4)"[pageCalculatorBase/General script]
views.get("btne").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight())));
views.get("btne").vw.setHeight((int)(Double.parseDouble(_btnvt)*4d - (Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight()))));
//BA.debugLineNum = 61;BA.debugLine="btnd.SetLeftAndRight(pad+btnHt*3,btnHt*4)"[pageCalculatorBase/General script]
views.get("btnd").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d));
views.get("btnd").vw.setWidth((int)(Double.parseDouble(_btnht)*4d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*3d)));
//BA.debugLineNum = 62;BA.debugLine="btnd.SetTopAndBottom(pad+btn1.Bottom,btnVt*4)"[pageCalculatorBase/General script]
views.get("btnd").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight())));
views.get("btnd").vw.setHeight((int)(Double.parseDouble(_btnvt)*4d - (Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight()))));
//BA.debugLineNum = 63;BA.debugLine="btnExit.SetLeftAndRight(pad+btnHt*4,btnHt*5)"[pageCalculatorBase/General script]
views.get("btnexit").vw.setLeft((int)(Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d));
views.get("btnexit").vw.setWidth((int)(Double.parseDouble(_btnht)*5d - (Double.parseDouble(_pad)+Double.parseDouble(_btnht)*4d)));
//BA.debugLineNum = 64;BA.debugLine="btnExit.SetTopAndBottom(pad+btn1.Bottom,btnVt*4)"[pageCalculatorBase/General script]
views.get("btnexit").vw.setTop((int)(Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight())));
views.get("btnexit").vw.setHeight((int)(Double.parseDouble(_btnvt)*4d - (Double.parseDouble(_pad)+(views.get("btn1").vw.getTop() + views.get("btn1").vw.getHeight()))));

}
}