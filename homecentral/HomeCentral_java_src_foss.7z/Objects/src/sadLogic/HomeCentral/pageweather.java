package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pageweather extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pageweather");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pageweather.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlcurrent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrenthigh = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrdesc = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrtxt = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbllocation = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncurrtemp = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgcurrent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblfeelslike = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgforecasticon1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblforecastday1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblforecastdesc1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblforecasthigh1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblforecastlow1 = null;
public b4a.example3.customlistview _lvforecast = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlforcastdivider = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btncurrtemp_click() throws Exception{
 //BA.debugLineNum = 165;BA.debugLine="Private Sub btnCurrTemp_Click";
 //BA.debugLineNum = 166;BA.debugLine="mpage.useCel = Not (mpage.useCel)";
_mpage._usecel /*boolean*/  = __c.Not(_mpage._usecel /*boolean*/ );
 //BA.debugLineNum = 167;BA.debugLine="WeatherData_RefreshScrn";
_weatherdata_refreshscrn();
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
String[] _ll = null;
String _defcity = "";
anywheresoftware.b4a.objects.collections.List _mnus = null;
int _x = 0;
 //BA.debugLineNum = 71;BA.debugLine="Private Sub Build_Side_Menu()";
 //BA.debugLineNum = 73;BA.debugLine="Dim ll() As String = Regex.Split(\";;\", Main.kvs.G";
_ll = __c.Regex.Split(";;",BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_city_list /*String*/ )));
 //BA.debugLineNum = 74;BA.debugLine="Dim DefCity As String  = Main.kvs.Get(gblConst.IN";
_defcity = BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_default_city /*String*/ ));
 //BA.debugLineNum = 76;BA.debugLine="Dim mnus As List : 	mnus.Initialize";
_mnus = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 76;BA.debugLine="Dim mnus As List : 	mnus.Initialize";
_mnus.Initialize();
 //BA.debugLineNum = 77;BA.debugLine="mnus.Add(\"Refresh\")";
_mnus.Add((Object)("Refresh"));
 //BA.debugLineNum = 78;BA.debugLine="mnus.Add(DefCity)";
_mnus.Add((Object)(_defcity));
 //BA.debugLineNum = 80;BA.debugLine="For x = 0 To ll.Length - 1";
{
final int step7 = 1;
final int limit7 = (int) (_ll.length-1);
_x = (int) (0) ;
for (;_x <= limit7 ;_x = _x + step7 ) {
 //BA.debugLineNum = 81;BA.debugLine="If ll(x) <> DefCity Then";
if ((_ll[_x]).equals(_defcity) == false) { 
 //BA.debugLineNum = 82;BA.debugLine="mnus.Add(ll(x))";
_mnus.Add((Object)(_ll[_x]));
 };
 }
};
 //BA.debugLineNum = 86;BA.debugLine="Menus.BuildSideMenu(mnus, objHelpers.CopyObject(m";
_menus._buildsidemenu /*String*/ (ba,_mnus,(anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_objhelpers._copyobject /*Object*/ (ba,(Object)(_mnus.getObject())))));
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 11;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private pnlCurrent As B4XView";
_pnlcurrent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private lblCurrentHigh As B4XView";
_lblcurrenthigh = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblCurrDesc As B4XView";
_lblcurrdesc = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lblCurrTXT As B4XView";
_lblcurrtxt = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private lblLocation As B4XView";
_lbllocation = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private btnCurrTemp As B4XView";
_btncurrtemp = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private imgCurrent As lmB4XImageViewX";
_imgcurrent = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 21;BA.debugLine="Private lblFeelsLike As B4XView";
_lblfeelslike = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private imgForecastIcon1 As lmB4XImageViewX";
_imgforecasticon1 = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 26;BA.debugLine="Private lblForecastDay1 As B4XView";
_lblforecastday1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private lblForecastDesc1 As B4XView";
_lblforecastdesc1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private lblForecastHigh1 As B4XView";
_lblforecasthigh1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private lblForecastLow1 As B4XView";
_lblforecastlow1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private lvForecast As CustomListView";
_lvforecast = new b4a.example3.customlistview();
 //BA.debugLineNum = 33;BA.debugLine="Private pnlForcastDivider As Panel";
_pnlforcastdivider = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createlistitemweather(int _arrid,int _width,int _height) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
String _lowtemp = "";
String _hightemp = "";
 //BA.debugLineNum = 170;BA.debugLine="Private Sub CreateListItemWeather(arrID As Int, Wi";
 //BA.debugLineNum = 172;BA.debugLine="Try";
try { //BA.debugLineNum = 174;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 175;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,Width, Height)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 176;BA.debugLine="p.LoadLayout(\"viewWeatherForcast\")";
_p.LoadLayout("viewWeatherForcast",ba);
 //BA.debugLineNum = 179;BA.debugLine="guiHelpers.SetPanelsDividers(Array As B4XView(pn";
_guihelpers._setpanelsdividers /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlforcastdivider.getObject()))},_clrtheme._dividercolor /*int*/ );
 //BA.debugLineNum = 181;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblFore";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblforecastday1,_lblforecastdesc1},_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 182;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblFore";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblforecasthigh1,_lblforecastlow1},_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 184;BA.debugLine="Dim lowTemp,highTemp As String";
_lowtemp = "";
_hightemp = "";
 //BA.debugLineNum = 185;BA.debugLine="highTemp  = \"High \" & IIf(mpage.useCel, mpage.We";
_hightemp = "High "+BA.ObjectToString(((_mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._high_c /*int*/ )+"°c")) : ((Object)(BA.NumberToString(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._high_f /*int*/ )+"°f"))));
 //BA.debugLineNum = 186;BA.debugLine="lowTemp   = \"Low \" & IIf(mpage.useCel, mpage.Wea";
_lowtemp = "Low "+BA.ObjectToString(((_mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._low_c /*int*/ )+"°c")) : ((Object)(BA.NumberToString(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._low_f /*int*/ )+"°f"))));
 //BA.debugLineNum = 188;BA.debugLine="mpage.WeatherData.LoadWeatherIcon(mpage.WeatherD";
_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._loadweathericon /*String*/ (_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._iconid /*int*/ ,_imgforecasticon1,__c.True);
 //BA.debugLineNum = 190;BA.debugLine="lblForecastDay1.Text   = mpage.WeatherData.Forca";
_lblforecastday1.setText(BA.ObjectToCharSequence(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._day /*String*/ ));
 //BA.debugLineNum = 191;BA.debugLine="lblForecastDesc1.Text = mpage.WeatherData.Forcas";
_lblforecastdesc1.setText(BA.ObjectToCharSequence(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [_arrid]._description /*String*/ ));
 //BA.debugLineNum = 192;BA.debugLine="lblForecastHigh1.Text  = highTemp";
_lblforecasthigh1.setText(BA.ObjectToCharSequence(_hightemp));
 //BA.debugLineNum = 193;BA.debugLine="lblForecastLow1.Text  = lowTemp";
_lblforecastlow1.setText(BA.ObjectToCharSequence(_lowtemp));
 } 
       catch (Exception e17) {
			ba.setLastException(e17); //BA.debugLineNum = 196;BA.debugLine="Log(LastException)";
__c.LogImpl("45482010",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 199;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 200;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 36;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 37;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 38;BA.debugLine="pnlMain.LoadLayout(\"pageWeatherBase\")";
_pnlmain.LoadLayout("pageWeatherBase",ba);
 //BA.debugLineNum = 39;BA.debugLine="pnlCurrent.LoadLayout(\"viewWeatherCurrent\")";
_pnlcurrent.LoadLayout("viewWeatherCurrent",ba);
 //BA.debugLineNum = 42;BA.debugLine="B4XPages.MainPage.EventGbl.Subscribe(gblConst.EVE";
_b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_weather_updated /*String*/ ,this,"WeatherData_RefreshScrn");
 //BA.debugLineNum = 43;BA.debugLine="B4XPages.MainPage.EventGbl.Subscribe(gblConst.EVE";
_b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_weather_update_failed /*String*/ ,this,"WeatherData_Fail");
 //BA.debugLineNum = 45;BA.debugLine="guiHelpers.SetPanelsTranparent(Array As B4XView(p";
_guihelpers._setpanelstranparent /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_pnlcurrent});
 //BA.debugLineNum = 46;BA.debugLine="guiHelpers.SkinButtonNoBorder(Array As Button(btn";
_guihelpers._skinbuttonnoborder /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btncurrtemp.getObject()))});
 //BA.debugLineNum = 49;BA.debugLine="imgCurrent.Bitmap = XUI.LoadBitmap(File.DirAssets";
_imgcurrent._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_xui.LoadBitmap(__c.File.getDirAssets(),"no weather.png"));
 //BA.debugLineNum = 51;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblCurre";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblcurrenthigh,_lblcurrtxt,_lbllocation,_lblfeelslike},_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 52;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblCurrD";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblcurrdesc,_btncurrtemp},_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 54;BA.debugLine="btnCurrTemp.TextSize = 54";
_btncurrtemp.setTextSize((float) (54));
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 68;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 61;BA.debugLine="Menus.SetHeader(\"Weather\",\"main_menu_weather.png\"";
_menus._setheader /*String*/ (ba,"Weather","main_menu_weather.png");
 //BA.debugLineNum = 62;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 63;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 64;BA.debugLine="WeatherData_RefreshScrn";
_weatherdata_refreshscrn();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _sidemenu_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 203;BA.debugLine="Private Sub SideMenu_ItemClick (Index As Int, Valu";
 //BA.debugLineNum = 204;BA.debugLine="Try";
try { //BA.debugLineNum = 205;BA.debugLine="Select Case  Value";
switch (BA.switchObjectToInt(_value,(Object)("Refresh"))) {
case 0: {
 //BA.debugLineNum = 207;BA.debugLine="guiHelpers.Show_toast(\"Refreshing Weather\")";
_guihelpers._show_toast /*String*/ (ba,"Refreshing Weather");
 //BA.debugLineNum = 208;BA.debugLine="CallSubDelayed(mpage.WeatherData,\"Try_Weather_";
__c.CallSubDelayed(ba,(Object)(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ),"Try_Weather_Update");
 break; }
default: {
 //BA.debugLineNum = 210;BA.debugLine="CallSubDelayed2(mpage.WeatherData,\"Update_Weat";
__c.CallSubDelayed2(ba,(Object)(_mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ),"Update_Weather",_value);
 break; }
}
;
 //BA.debugLineNum = 212;BA.debugLine="mpage.pnlSideMenu.SetVisibleAnimated(380, False)";
_mpage._pnlsidemenu /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .SetVisibleAnimated((int) (380),__c.False);
 } 
       catch (Exception e11) {
			ba.setLastException(e11); //BA.debugLineNum = 214;BA.debugLine="Log(LastException)";
__c.LogImpl("45547531",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 216;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public String  _weatherdata_beforeupdated() throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Private Sub WeatherData_BeforeUpdated";
 //BA.debugLineNum = 95;BA.debugLine="guiHelpers.ResizeText(\"Updating weather...\", lblC";
_guihelpers._resizetext /*String*/ (ba,"Updating weather...",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lblcurrdesc.getObject())));
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public String  _weatherdata_fail() throws Exception{
 //BA.debugLineNum = 98;BA.debugLine="Sub WeatherData_Fail";
 //BA.debugLineNum = 99;BA.debugLine="guiHelpers.ResizeText(\"Error, trying again in 1 m";
_guihelpers._resizetext /*String*/ (ba,"Error, trying again in 1 minute",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lbllocation.getObject())));
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public void  _weatherdata_refreshscrn() throws Exception{
ResumableSub_WeatherData_RefreshScrn rsub = new ResumableSub_WeatherData_RefreshScrn(this);
rsub.resume(ba, null);
}
public static class ResumableSub_WeatherData_RefreshScrn extends BA.ResumableSub {
public ResumableSub_WeatherData_RefreshScrn(sadLogic.HomeCentral.pageweather parent) {
this.parent = parent;
}
sadLogic.HomeCentral.pageweather parent;
String _details = "";
String _lowtemp = "";
String _hightemp = "";
String _tempcurr = "";
String _precipitation = "";
String _windspeed = "";
String _feelslike = "";
int _size = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 104;BA.debugLine="If pnlMain.Visible = False Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._pnlmain.getVisible()==parent.__c.False) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 105;BA.debugLine="If B4XPages.MainPage.DebugLog Then Log(\"WeatherDa";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._debuglog /*boolean*/ ) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
parent.__c.LogImpl("45350915","WeatherData_RefreshScrn",0);
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 107;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 19;
return;
case 19:
//C
this.state = 13;
;
 //BA.debugLineNum = 108;BA.debugLine="Dim details,lowTemp,highTemp,TempCurr,Precipitati";
_details = "";
_lowtemp = "";
_hightemp = "";
_tempcurr = "";
_precipitation = "";
_windspeed = "";
_feelslike = "";
 //BA.debugLineNum = 109;BA.debugLine="TempCurr     = IIf(mpage.useCel, mpage.WeatherDat";
_tempcurr = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qtemp_c /*int*/ )+"°c")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qtemp_f /*int*/ )+"°f"))));
 //BA.debugLineNum = 110;BA.debugLine="highTemp      = IIf(mpage.useCel, mpage.WeatherDa";
_hightemp = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._high_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._high_f /*int*/ )+"°"))));
 //BA.debugLineNum = 111;BA.debugLine="lowTemp       = IIf(mpage.useCel, mpage.WeatherDa";
_lowtemp = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._low_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._low_f /*int*/ )+"°"))));
 //BA.debugLineNum = 112;BA.debugLine="Precipitation = IIf(mpage.useMetric, mpage.Weathe";
_precipitation = BA.ObjectToString(((parent._mpage._usemetric /*boolean*/ ) ? ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qprecipitation_mm /*String*/ +"mm")) : ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qprecipitation_inches /*String*/ +"inches"))));
 //BA.debugLineNum = 113;BA.debugLine="WindSpeed   = IIf(mpage.useMetric, mpage.WeatherD";
_windspeed = BA.ObjectToString(((parent._mpage._usemetric /*boolean*/ ) ? ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwindspeed_kph /*String*/ +"km/h")) : ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwindspeed_mph /*String*/ +"mph"))));
 //BA.debugLineNum = 114;BA.debugLine="FeelsLike      = IIf(mpage.useCel, mpage.WeatherD";
_feelslike = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qfeelslike_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qfeelslike_f /*int*/ )+"°"))));
 //BA.debugLineNum = 116;BA.debugLine="If guiHelpers.gScreenSizeAprox > 8.5 Then";
if (true) break;

case 13:
//if
this.state = 18;
if (parent._guihelpers._gscreensizeaprox /*double*/ >8.5) { 
this.state = 15;
}else {
this.state = 17;
}if (true) break;

case 15:
//C
this.state = 18;
 //BA.debugLineNum = 117;BA.debugLine="details =   _ 			  \"Precipitation: \" & Precipita";
_details = "Precipitation: "+_precipitation+parent.__c.CRLF+"Humidity: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qhumidity /*String*/ +"%"+parent.__c.CRLF+"Pressure: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qpressure /*String*/ +parent.__c.CRLF+"Wind Speed: "+_windspeed+parent.__c.CRLF+"Wind Direction: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwinddirection /*String*/ +parent.__c.CRLF+"Cloud Cover: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qcloudcover /*String*/ +"%"+parent.__c.CRLF+"Sunrise: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunrise /*String*/ +" - Sunset: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunset /*String*/ +parent.__c.CRLF+"Last Updated At: "+parent._mpage._oclock /*sadLogic.HomeCentral.clock*/ ._formattime /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._lastupdatedat /*long*/ );
 //BA.debugLineNum = 126;BA.debugLine="guiHelpers.ResizeText(details.Trim, lblCurrTXT)";
parent._guihelpers._resizetext /*String*/ (ba,_details.trim(),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrtxt.getObject())));
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 128;BA.debugLine="details =   _ 			  \"Precipitation: \" & Precipita";
_details = "Precipitation: "+_precipitation+parent.__c.CRLF+"Humidity: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qhumidity /*String*/ +"%"+" - Pressure: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qpressure /*String*/ +parent.__c.CRLF+"Wind Speed: "+_windspeed+" - Direction: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwinddirection /*String*/ +parent.__c.CRLF+"Cloud Cover: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qcloudcover /*String*/ +"%"+parent.__c.CRLF+"Sunrise: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunrise /*String*/ +" - Sunset: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunset /*String*/ +parent.__c.CRLF+"Last Updated At: "+parent._mpage._oclock /*sadLogic.HomeCentral.clock*/ ._formattime /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._lastupdatedat /*long*/ );
 //BA.debugLineNum = 135;BA.debugLine="guiHelpers.ResizeText(details.Trim, lblCurrTXT)";
parent._guihelpers._resizetext /*String*/ (ba,_details.trim(),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrtxt.getObject())));
 if (true) break;

case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 138;BA.debugLine="guiHelpers.ResizeText(mpage.WeatherData.qDescript";
parent._guihelpers._resizetext /*String*/ (ba,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qdescription /*String*/ ,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrdesc.getObject())));
 //BA.debugLineNum = 139;BA.debugLine="guiHelpers.ResizeText(mpage.WeatherData.qLocation";
parent._guihelpers._resizetext /*String*/ (ba,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qlocation /*String*/ ,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lbllocation.getObject())));
 //BA.debugLineNum = 140;BA.debugLine="guiHelpers.ResizeText(details.Trim, lblCurrTXT)";
parent._guihelpers._resizetext /*String*/ (ba,_details.trim(),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrtxt.getObject())));
 //BA.debugLineNum = 141;BA.debugLine="guiHelpers.ResizeText(\"High \" & highTemp   & \"  /";
parent._guihelpers._resizetext /*String*/ (ba,"High "+_hightemp+"  /  Low "+_lowtemp,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrenthigh.getObject())));
 //BA.debugLineNum = 142;BA.debugLine="guiHelpers.ResizeText(TempCurr , btnCurrTemp)";
parent._guihelpers._resizetext /*String*/ (ba,_tempcurr,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._btncurrtemp.getObject())));
 //BA.debugLineNum = 143;BA.debugLine="guiHelpers.ResizeText(\"Feels like: \" & FeelsLike";
parent._guihelpers._resizetext /*String*/ (ba,"Feels like: "+_feelslike,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblfeelslike.getObject())));
 //BA.debugLineNum = 145;BA.debugLine="lblCurrTXT.TextSize = lblCurrTXT.TextSize - 4";
parent._lblcurrtxt.setTextSize((float) (parent._lblcurrtxt.getTextSize()-4));
 //BA.debugLineNum = 146;BA.debugLine="btnCurrTemp.TextSize = btnCurrTemp.TextSize - 9";
parent._btncurrtemp.setTextSize((float) (parent._btncurrtemp.getTextSize()-9));
 //BA.debugLineNum = 148;BA.debugLine="mpage.WeatherData.LoadWeatherIcon(mpage.WeatherDa";
parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._loadweathericon /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._iconid /*int*/ ,parent._imgcurrent,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qisday /*boolean*/ );
 //BA.debugLineNum = 156;BA.debugLine="lvForecast.Clear";
parent._lvforecast._clear();
 //BA.debugLineNum = 157;BA.debugLine="Dim size As Int = (lvForecast.AsView.Height / 3)";
_size = (int) ((parent._lvforecast._asview().getHeight()/(double)3)-parent.__c.DipToCurrent((int) (10)));
 //BA.debugLineNum = 158;BA.debugLine="lvForecast.Add(CreateListItemWeather(0,lvForecast";
parent._lvforecast._add(parent._createlistitemweather((int) (0),parent._lvforecast._asview().getWidth(),_size),(Object)("0"));
 //BA.debugLineNum = 159;BA.debugLine="lvForecast.Add(CreateListItemWeather(1,lvForecast";
parent._lvforecast._add(parent._createlistitemweather((int) (1),parent._lvforecast._asview().getWidth(),_size),(Object)("1"));
 //BA.debugLineNum = 160;BA.debugLine="lvForecast.Add(CreateListItemWeather(2,lvForecast";
parent._lvforecast._add(parent._createlistitemweather((int) (2),parent._lvforecast._asview().getWidth(),_size),(Object)("2"));
 //BA.debugLineNum = 161;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 20;
return;
case 20:
//C
this.state = -1;
;
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SIDEMENU_ITEMCLICK"))
	return _sidemenu_itemclick(((Number)args[0]).intValue(), (Object) args[1]);
return BA.SubDelegator.SubNotFound;
}
}
