package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class inmemdb extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.inmemdb");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.inmemdb.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.sql.SQL _sql = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _buildtable() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub BuildTable";
 //BA.debugLineNum = 20;BA.debugLine="sql.ExecNonQuery(\"DROP TABLE IF EXISTS files;\")";
_sql.ExecNonQuery("DROP TABLE IF EXISTS files;");
 //BA.debugLineNum = 21;BA.debugLine="sql.ExecNonQuery(\"CREATE TABLE files(file_name TE";
_sql.ExecNonQuery("CREATE TABLE files(file_name TEXT,hash TEXT,date_added TEXT);");
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"InMemDB\" 'igno";
_mmodule = "InMemDB";
 //BA.debugLineNum = 8;BA.debugLine="Public sql As SQL";
_sql = new anywheresoftware.b4a.sql.SQL();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _deletefilerec(String _fname) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Public Sub DeleteFileRec(fname As String)";
 //BA.debugLineNum = 44;BA.debugLine="sql.ExecNonQuery($\"DELETE FROM FILES WHERE file_n";
_sql.ExecNonQuery(("DELETE FROM FILES WHERE file_name = \""+__c.SmartStringFormatter("",(Object)(_fname))+"\";"));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public int  _gettotalrecs() throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Public Sub GetTotalRecs() As Int";
 //BA.debugLineNum = 40;BA.debugLine="Return sql.ExecQuerySingleResult(\"Select COUNT(*)";
if (true) return ((int)(Double.parseDouble(_sql.ExecQuerySingleResult("Select COUNT(*) FROM files;"))));
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 14;BA.debugLine="sql.Initialize(\"\", \":memory:\", True)";
_sql.Initialize("",":memory:",__c.True);
 //BA.debugLineNum = 15;BA.debugLine="BuildTable";
_buildtable();
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _insertfilerec(String _fname,String _hash,String _date_added) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Public Sub InsertFileRec(fname As String,hash As S";
 //BA.debugLineNum = 35;BA.debugLine="sql.ExecNonQuery($\"INSERT INTO FILES ('file_name'";
_sql.ExecNonQuery(("INSERT INTO FILES ('file_name','hash','date_added') \n"+"										  VALUES (\""+__c.SmartStringFormatter("",(Object)(_fname))+"\",\""+__c.SmartStringFormatter("",(Object)(_hash))+"\",\""+__c.SmartStringFormatter("",(Object)(_date_added))+"\");"));
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _seedtable(anywheresoftware.b4a.objects.collections.Map _fm) throws Exception{
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _f = null;
 //BA.debugLineNum = 24;BA.debugLine="Public Sub SeedTable(fm As Map)";
 //BA.debugLineNum = 25;BA.debugLine="sql.BeginTransaction";
_sql.BeginTransaction();
 //BA.debugLineNum = 26;BA.debugLine="For Each f As tOctoFileInfo In fm.Values";
{
final anywheresoftware.b4a.BA.IterableList group2 = _fm.Values();
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_f = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(group2.Get(index2));
 //BA.debugLineNum = 27;BA.debugLine="InsertFileRec(f.Name,f.hash,f.Date)";
_insertfilerec(_f.Name /*String*/ ,_f.hash /*String*/ ,_f.Date /*String*/ );
 }
};
 //BA.debugLineNum = 29;BA.debugLine="sql.TransactionSuccessful";
_sql.TransactionSuccessful();
 //BA.debugLineNum = 30;BA.debugLine="sql.EndTransaction";
_sql.EndTransaction();
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
