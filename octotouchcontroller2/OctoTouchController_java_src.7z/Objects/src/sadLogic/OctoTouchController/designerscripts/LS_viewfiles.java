package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewfiles{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlfileviewbg").vw.setLeft((int)(0d));
views.get("pnlfileviewbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlfileviewbg").vw.setTop((int)(0d));
views.get("pnlfileviewbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("lblpnlfileviewtop").vw.setLeft((int)((views.get("pnlfileviewbg").vw.getLeft())));
views.get("lblpnlfileviewtop").vw.setWidth((int)((views.get("pnlfileviewbg").vw.getLeft() + views.get("pnlfileviewbg").vw.getWidth()) - ((views.get("pnlfileviewbg").vw.getLeft()))));
views.get("lblpnlfileviewbottom").vw.setLeft((int)((views.get("pnlfileviewbg").vw.getLeft())));
views.get("lblpnlfileviewbottom").vw.setWidth((int)((views.get("pnlfileviewbg").vw.getLeft() + views.get("pnlfileviewbg").vw.getWidth()) - ((views.get("pnlfileviewbg").vw.getLeft()))));
views.get("lblpnlfileviewtop").vw.setTop((int)(0d));
views.get("lblpnlfileviewtop").vw.setHeight((int)((views.get("pnlfileviewbg").vw.getHeight())/2d - (0d)));
views.get("lblpnlfileviewbottom").vw.setTop((int)((views.get("pnlfileviewbg").vw.getHeight())/2d));
views.get("lblpnlfileviewbottom").vw.setHeight((int)((views.get("pnlfileviewbg").vw.getHeight()) - ((views.get("pnlfileviewbg").vw.getHeight())/2d)));

}
}