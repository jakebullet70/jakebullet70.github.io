package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgbedlevelmeshwiz2 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mobj = null;
public sadLogic.OctoTouchController.foss.octowebsocket _ows = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.PanelWrapper _parent = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlsteps = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbg = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnclose = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpreheat = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _alblheader = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _alblmenu = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblheaterbed = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblheatertool = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlspacer1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlspacer2 = null;
public anywheresoftware.b4a.objects.Timer _tmrheateronoff = null;
public double _mdistance = 0;
public boolean _minprobemode = false;
public anywheresoftware.b4a.objects.ButtonWrapper _btndn = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnup = null;
public String _pmode = "";
public String _ppmanual_mesh = "";
public sadLogic.OctoTouchController.foss.autotextsizelabel _alblzinfo = null;
public sadLogic.OctoTouchController.foss.soundsbeeps _obeepme = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btndst5 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btndst4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btndst3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btndst2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btndst1 = null;
public float _mcurrentmarlinz = 0f;
public float _moldmarlinz = 0f;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _btnclose_click() throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Private Sub btnClose_Click";
 //BA.debugLineNum = 102;BA.debugLine="Close_Me";
_close_me();
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _btndistance_highlight(anywheresoftware.b4a.objects.B4XViewWrapper _b) throws Exception{
 //BA.debugLineNum = 178;BA.debugLine="Private Sub btnDistance_Highlight(b As B4XView)";
 //BA.debugLineNum = 179;BA.debugLine="DistanceBtnsLookReset";
_distancebtnslookreset();
 //BA.debugLineNum = 180;BA.debugLine="b.SetColorAndBorder(xui.Color_Transparent, 6dip,c";
_b.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (6)),_clrtheme._txtaccent /*int*/ ,__c.DipToCurrent((int) (6)));
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return "";
}
public String  _btndst_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
 //BA.debugLineNum = 170;BA.debugLine="Private Sub btnDst_Click";
 //BA.debugLineNum = 171;BA.debugLine="Dim b As Button : b = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 171;BA.debugLine="Dim b As Button : b = Sender";
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 172;BA.debugLine="btnDistance_Highlight(b.As(B4XView))";
_btndistance_highlight(((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_b.getObject()))));
 //BA.debugLineNum = 173;BA.debugLine="mDIstance = b.Text";
_mdistance = (double)(Double.parseDouble(_b.getText()));
 //BA.debugLineNum = 174;BA.debugLine="CallSubDelayed(Main,\"Set_ScreenTmr\") '--- reset t";
__c.CallSubDelayed(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
return "";
}
public String  _btnpreheat_click() throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Private Sub btnPreHeat_Click";
 //BA.debugLineNum = 130;BA.debugLine="CallSub(B4XPages.MainPage,\"ShowPreHeatMenu_All\")";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"ShowPreHeatMenu_All");
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public void  _btnstart_click() throws Exception{
ResumableSub_btnStart_Click rsub = new ResumableSub_btnStart_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnStart_Click extends BA.ResumableSub {
public ResumableSub_btnStart_Click(sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent;
anywheresoftware.b4a.objects.ButtonWrapper _b = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 236;BA.debugLine="Dim b As Button : b = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 236;BA.debugLine="Dim b As Button : b = Sender";
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 237;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 239;BA.debugLine="mInProbeMode = True";
parent._minprobemode = parent.__c.True;
 //BA.debugLineNum = 241;BA.debugLine="btn1.RequestFocus";
parent._btn1.RequestFocus();
 //BA.debugLineNum = 246;BA.debugLine="If b.Text = \"START\" Then";
if (true) break;

case 1:
//if
this.state = 44;
if ((_b.getText()).equals("START")) { 
this.state = 3;
}else if((_b.getText()).equals(parent._oc._cklippy_accept /*String*/ ) || (_b.getText()).equals("DONE")) { 
this.state = 31;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 248;BA.debugLine="ShowZinfo(\"Preparing printer...\")";
parent._showzinfo("Preparing printer...");
 //BA.debugLineNum = 249;BA.debugLine="guiHelpers.Show_toast2(\"Homing printer\",2500)";
parent._guihelpers._show_toast2 /*String*/ (ba,"Homing printer",(int) (2500));
 //BA.debugLineNum = 253;BA.debugLine="If oc.Klippy Then '--------------------Klipper f";
if (true) break;

case 4:
//if
this.state = 29;
if (parent._oc._klippy /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 255;BA.debugLine="mOBJ.Send_Gcode(\"G28\")";
parent._mobj._send_gcode /*void*/ ("G28");
 //BA.debugLineNum = 256;BA.debugLine="Sleep(1000)";
parent.__c.Sleep(ba,this,(int) (1000));
this.state = 45;
return;
case 45:
//C
this.state = 7;
;
 //BA.debugLineNum = 259;BA.debugLine="If pMode = ppMANUAL_MESH Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((parent._pmode).equals(parent._ppmanual_mesh)) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 261;BA.debugLine="guiHelpers.Show_toast2(\"Starting manual mesh Z";
parent._guihelpers._show_toast2 /*String*/ (ba,"Starting manual mesh Z probe...",(int) (2500));
 //BA.debugLineNum = 262;BA.debugLine="mOBJ.Send_Gcode(\"BED_MESH_CALIBRATE  METHOD=ma";
parent._mobj._send_gcode /*void*/ ("BED_MESH_CALIBRATE  METHOD=manual");
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 266;BA.debugLine="guiHelpers.Show_toast2(\"Setting up for Z Offse";
parent._guihelpers._show_toast2 /*String*/ (ba,"Setting up for Z Offset...",(int) (2500));
 //BA.debugLineNum = 267;BA.debugLine="mOBJ.Send_Gcode($\"G1 Z5 X${oc.PrinterWidth / 2";
parent._mobj._send_gcode /*void*/ (("G1 Z5 X"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._printerwidth /*double*/ /(double)2))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._printerdepth /*double*/ /(double)2))+" F4000"));
 //BA.debugLineNum = 268;BA.debugLine="Sleep(500)";
parent.__c.Sleep(ba,this,(int) (500));
this.state = 46;
return;
case 46:
//C
this.state = 12;
;
 //BA.debugLineNum = 269;BA.debugLine="mOBJ.Send_Gcode(\"PROBE_CALIBRATE\")";
parent._mobj._send_gcode /*void*/ ("PROBE_CALIBRATE");
 if (true) break;

case 12:
//C
this.state = 29;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 277;BA.debugLine="If pMode = ppMANUAL_MESH Then";
if (true) break;

case 15:
//if
this.state = 28;
if ((parent._pmode).equals(parent._ppmanual_mesh)) { 
this.state = 17;
}else {
this.state = 19;
}if (true) break;

case 17:
//C
this.state = 28;
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 283;BA.debugLine="If oc.PrinterWidth = 0 Then";
if (true) break;

case 20:
//if
this.state = 23;
if (parent._oc._printerwidth /*double*/ ==0) { 
this.state = 22;
}if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 284;BA.debugLine="Log(\"oc.PrinterWidth = 0\")";
parent.__c.LogImpl("14942258","oc.PrinterWidth = 0",0);
 if (true) break;

case 23:
//C
this.state = 24;
;
 //BA.debugLineNum = 310;BA.debugLine="oWS.pParserWO.MsgsAdd(\"M851 \",Me,\"parse_z_offs";
parent._ows._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._msgsadd /*String*/ ("M851 ",parent,"parse_z_offset_msg");
 //BA.debugLineNum = 311;BA.debugLine="oWS.setThrottle(\"1\") : Sleep(1500)";
parent._ows._setthrottle /*String*/ ("1");
 //BA.debugLineNum = 311;BA.debugLine="oWS.setThrottle(\"1\") : Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 47;
return;
case 47:
//C
this.state = 24;
;
 //BA.debugLineNum = 313;BA.debugLine="mOldMarlinZ = -999";
parent._moldmarlinz = (float) (-999);
 //BA.debugLineNum = 314;BA.debugLine="mOBJ.Send_Gcode(\"M851\") : Sleep(1500)";
parent._mobj._send_gcode /*void*/ ("M851");
 //BA.debugLineNum = 314;BA.debugLine="mOBJ.Send_Gcode(\"M851\") : Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 48;
return;
case 48:
//C
this.state = 24;
;
 //BA.debugLineNum = 315;BA.debugLine="Do While mOldMarlinZ = -999";
if (true) break;

case 24:
//do while
this.state = 27;
while (parent._moldmarlinz==-999) {
this.state = 26;
if (true) break;
}
if (true) break;

case 26:
//C
this.state = 24;
 //BA.debugLineNum = 316;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 49;
return;
case 49:
//C
this.state = 24;
;
 if (true) break;

case 27:
//C
this.state = 28;
;
 //BA.debugLineNum = 319;BA.debugLine="oWS.setThrottle(\"90\")";
parent._ows._setthrottle /*String*/ ("90");
 //BA.debugLineNum = 322;BA.debugLine="oWS.bLastMessage = False";
parent._ows._blastmessage /*boolean*/  = parent.__c.False;
 //BA.debugLineNum = 326;BA.debugLine="oWS.pParserWO.EventAdd(\"ZChange\",Me,\"rec_text\"";
parent._ows._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._eventadd /*String*/ ("ZChange",parent,"rec_text");
 //BA.debugLineNum = 327;BA.debugLine="mCurrentMarlinZ = 8.00";
parent._mcurrentmarlinz = (float) (8.00);
 //BA.debugLineNum = 329;BA.debugLine="mOBJ.Send_Gcode(\"G90\") '--- absolute position";
parent._mobj._send_gcode /*void*/ ("G90");
 //BA.debugLineNum = 330;BA.debugLine="mOBJ.Send_Gcode(\"M851 Z0.0\") '--- reset Z";
parent._mobj._send_gcode /*void*/ ("M851 Z0.0");
 //BA.debugLineNum = 331;BA.debugLine="Sleep(1000)";
parent.__c.Sleep(ba,this,(int) (1000));
this.state = 50;
return;
case 50:
//C
this.state = 28;
;
 //BA.debugLineNum = 332;BA.debugLine="mOBJ.Send_Gcode(\"G28\")";
parent._mobj._send_gcode /*void*/ ("G28");
 //BA.debugLineNum = 333;BA.debugLine="Sleep(1000)";
parent.__c.Sleep(ba,this,(int) (1000));
this.state = 51;
return;
case 51:
//C
this.state = 28;
;
 //BA.debugLineNum = 335;BA.debugLine="guiHelpers.Show_toast2(\"Setting up for Z Offse";
parent._guihelpers._show_toast2 /*String*/ (ba,"Setting up for Z Offset...",(int) (2900));
 //BA.debugLineNum = 336;BA.debugLine="mOBJ.Send_Gcode(\"M211 S0\") '--- turn off softw";
parent._mobj._send_gcode /*void*/ ("M211 S0");
 //BA.debugLineNum = 337;BA.debugLine="mOBJ.Send_Gcode($\"G1 Z8 X${oc.PrinterWidth / 2";
parent._mobj._send_gcode /*void*/ (("G1 Z8 X"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._printerwidth /*double*/ /(double)2))+" Y"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._printerdepth /*double*/ /(double)2))+" F4000"));
 //BA.debugLineNum = 339;BA.debugLine="btn1.Text = \"DONE\"";
parent._btn1.setText(BA.ObjectToCharSequence("DONE"));
 //BA.debugLineNum = 340;BA.debugLine="btn2.Visible = True";
parent._btn2.setVisible(parent.__c.True);
 //BA.debugLineNum = 341;BA.debugLine="btnClose.Visible = False";
parent._btnclose.setVisible(parent.__c.False);
 //BA.debugLineNum = 342;BA.debugLine="btnPreheat.Visible = False";
parent._btnpreheat.setVisible(parent.__c.False);
 if (true) break;

case 28:
//C
this.state = 29;
;
 if (true) break;

case 29:
//C
this.state = 44;
;
 if (true) break;

case 31:
//C
this.state = 32;
 //BA.debugLineNum = 351;BA.debugLine="If oc.Klippy Then";
if (true) break;

case 32:
//if
this.state = 43;
if (parent._oc._klippy /*boolean*/ ) { 
this.state = 34;
}else {
this.state = 36;
}if (true) break;

case 34:
//C
this.state = 43;
 //BA.debugLineNum = 354;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_ACCEPT)";
parent._mobj._send_gcode /*void*/ (parent._oc._cklippy_accept /*String*/ );
 //BA.debugLineNum = 355;BA.debugLine="ProcessMeshComplete";
parent._processmeshcomplete();
 if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 359;BA.debugLine="If pMode = ppMANUAL_MESH Then";
if (true) break;

case 37:
//if
this.state = 42;
if ((parent._pmode).equals(parent._ppmanual_mesh)) { 
this.state = 39;
}else {
this.state = 41;
}if (true) break;

case 39:
//C
this.state = 42;
 if (true) break;

case 41:
//C
this.state = 42;
 //BA.debugLineNum = 366;BA.debugLine="mOBJ.Send_Gcode($\"M851 Z${mCurrentMarlinZ}\"$)";
parent._mobj._send_gcode /*void*/ (("M851 Z"+parent.__c.SmartStringFormatter("",(Object)(parent._mcurrentmarlinz))+""));
 //BA.debugLineNum = 367;BA.debugLine="mOBJ.Send_Gcode(\"G91\")  '--- absolute position";
parent._mobj._send_gcode /*void*/ ("G91");
 //BA.debugLineNum = 368;BA.debugLine="ProcessMeshComplete";
parent._processmeshcomplete();
 if (true) break;

case 42:
//C
this.state = 43;
;
 if (true) break;

case 43:
//C
this.state = 44;
;
 if (true) break;

case 44:
//C
this.state = -1;
;
 //BA.debugLineNum = 376;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _btnstop_click() throws Exception{
 //BA.debugLineNum = 205;BA.debugLine="Private Sub btnStop_Click";
 //BA.debugLineNum = 207;BA.debugLine="ProcessStop_GUI";
_processstop_gui();
 //BA.debugLineNum = 208;BA.debugLine="guiHelpers.Show_toast2(\"Canceling... Disabling St";
_guihelpers._show_toast2 /*String*/ (ba,"Canceling... Disabling Steppers...",(int) (3000));
 //BA.debugLineNum = 210;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 211;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_ABORT)";
_mobj._send_gcode /*void*/ (_oc._cklippy_abort /*String*/ );
 //BA.debugLineNum = 212;BA.debugLine="mOBJ.Send_Gcode(\"M18\") '--- disable steppers";
_mobj._send_gcode /*void*/ ("M18");
 }else {
 //BA.debugLineNum = 214;BA.debugLine="oWS.pParserWO.EventRemove(\"ZChange\")";
_ows._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._eventremove /*String*/ ("ZChange");
 //BA.debugLineNum = 215;BA.debugLine="oWS.pParserWO.MsgsRemove(\"M851 \") '--- just in c";
_ows._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._msgsremove /*String*/ ("M851 ");
 //BA.debugLineNum = 216;BA.debugLine="If mOldMarlinZ < -500 Then";
if (_moldmarlinz<-500) { 
 //BA.debugLineNum = 217;BA.debugLine="Log(\"invalid oldMarlinZ\")";
__c.LogImpl("14876684","invalid oldMarlinZ",0);
 //BA.debugLineNum = 218;BA.debugLine="mOBJ.Send_Gcode($\"M501\"$) '--- reset Z back to";
_mobj._send_gcode /*void*/ (("M501"));
 }else {
 //BA.debugLineNum = 220;BA.debugLine="Log(\"good oldMarlinZ\")";
__c.LogImpl("14876687","good oldMarlinZ",0);
 //BA.debugLineNum = 221;BA.debugLine="mOBJ.Send_Gcode($\"M851 Z${Round2(mOldMarlinZ,2)";
_mobj._send_gcode /*void*/ (("M851 Z"+__c.SmartStringFormatter("",(Object)(__c.Round2(_moldmarlinz,(int) (2))))+""));
 };
 //BA.debugLineNum = 223;BA.debugLine="mOBJ.Send_Gcode(\"M18\") '--- disable steppers";
_mobj._send_gcode /*void*/ ("M18");
 //BA.debugLineNum = 224;BA.debugLine="mOBJ.Send_Gcode(\"G90\") '--- absolute position";
_mobj._send_gcode /*void*/ ("G90");
 //BA.debugLineNum = 225;BA.debugLine="mOBJ.Send_Gcode(\"M211 S1\") '--- turn on software";
_mobj._send_gcode /*void*/ ("M211 S1");
 };
 //BA.debugLineNum = 227;BA.debugLine="ShowZinfo(\"Just hanging out and waiting...\")";
_showzinfo("Just hanging out and waiting...");
 //BA.debugLineNum = 228;BA.debugLine="mInProbeMode = False";
_minprobemode = __c.False;
 //BA.debugLineNum = 231;BA.debugLine="End Sub";
return "";
}
public String  _btnupdown_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _btn = null;
String _nval = "";
 //BA.debugLineNum = 397;BA.debugLine="Private Sub btnUpDown_Click";
 //BA.debugLineNum = 398;BA.debugLine="Dim btn As Button = Sender";
_btn = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 399;BA.debugLine="If btn1.Text = \"START\" Or mInProbeMode = False Th";
if ((_btn1.getText()).equals("START") || _minprobemode==__c.False) { 
 //BA.debugLineNum = 400;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 404;BA.debugLine="Dim nVal As String = Round2(mDIstance,3).As(Strin";
_nval = (BA.NumberToString(__c.Round2(_mdistance,(int) (3))));
 //BA.debugLineNum = 405;BA.debugLine="If btn.Text.ToUpperCase.Contains(\"LO\") Then";
if (_btn.getText().toUpperCase().contains("LO")) { 
 //BA.debugLineNum = 406;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 407;BA.debugLine="nVal = \"-\" & nVal";
_nval = "-"+_nval;
 }else {
 //BA.debugLineNum = 409;BA.debugLine="mCurrentMarlinZ = mCurrentMarlinZ - nVal";
_mcurrentmarlinz = (float) (_mcurrentmarlinz-(double)(Double.parseDouble(_nval)));
 };
 }else {
 //BA.debugLineNum = 412;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 }else {
 //BA.debugLineNum = 415;BA.debugLine="mCurrentMarlinZ = mCurrentMarlinZ + nVal";
_mcurrentmarlinz = (float) (_mcurrentmarlinz+(double)(Double.parseDouble(_nval)));
 };
 };
 //BA.debugLineNum = 420;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 421;BA.debugLine="mOBJ.Send_Gcode(\"TESTZ Z=\" & nVal)";
_mobj._send_gcode /*void*/ ("TESTZ Z="+_nval);
 }else {
 //BA.debugLineNum = 423;BA.debugLine="mCurrentMarlinZ = Round2(mCurrentMarlinZ,2)";
_mcurrentmarlinz = (float) (__c.Round2(_mcurrentmarlinz,(int) (2)));
 //BA.debugLineNum = 424;BA.debugLine="mOBJ.Send_Gcode(\"G1 Z\" & Round2(mCurrentMarlinZ,";
_mobj._send_gcode /*void*/ ("G1 Z"+BA.NumberToString(__c.Round2(_mcurrentmarlinz,(int) (2))));
 };
 //BA.debugLineNum = 428;BA.debugLine="End Sub";
return "";
}
public String  _buildgui(String _headertxt) throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Private Sub BuildGUI(headerTxt As String)";
 //BA.debugLineNum = 134;BA.debugLine="pnlBG.Color = clrTheme.Background";
_pnlbg.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 135;BA.debugLine="pnlSpacer1.SetColorAndBorder(clrTheme.txtNormal,2";
_pnlspacer1.SetColorAndBorder(_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 136;BA.debugLine="pnlSpacer2.SetColorAndBorder(clrTheme.txtNormal,2";
_pnlspacer2.SetColorAndBorder(_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 137;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(alblZinf";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_alblzinfo._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_alblheader._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_alblmenu._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheaterbed.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheatertool.getObject()))});
 //BA.debugLineNum = 138;BA.debugLine="If guiHelpers.gIsLandScape = False Then";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 139;BA.debugLine="alblMenu.BaseLabel.Visible = False";
_alblmenu._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setVisible(__c.False);
 };
 //BA.debugLineNum = 141;BA.debugLine="alblHeader.Text = headerTxt";
_alblheader._settext /*Object*/ ((Object)(_headertxt));
 //BA.debugLineNum = 142;BA.debugLine="pnlSteps.Color =clrTheme.Background";
_pnlsteps.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 143;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnClose,bt";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnclose,_btnpreheat,_btn1,_btn2,_btndn,_btnup});
 //BA.debugLineNum = 144;BA.debugLine="DistanceBtnsLookReset";
_distancebtnslookreset();
 //BA.debugLineNum = 145;BA.debugLine="guiHelpers.ResizeText(\"Tool: \" & CRLF & \"200\",lbl";
_guihelpers._resizetext /*String*/ (ba,(Object)("Tool: "+__c.CRLF+"200"),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheatertool.getObject())));
 //BA.debugLineNum = 146;BA.debugLine="guiHelpers.ResizeText(\"Bed: \" &CRLF & \"100\",	lblH";
_guihelpers._resizetext /*String*/ (ba,(Object)("Bed: "+__c.CRLF+"100"),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblheaterbed.getObject())));
 //BA.debugLineNum = 147;BA.debugLine="btn1.Text = \"START\" : btn2.Text = \"STOP\"";
_btn1.setText(BA.ObjectToCharSequence("START"));
 //BA.debugLineNum = 147;BA.debugLine="btn1.Text = \"START\" : btn2.Text = \"STOP\"";
_btn2.setText(BA.ObjectToCharSequence("STOP"));
 //BA.debugLineNum = 148;BA.debugLine="btn1.TextSize =  20   : btn2.TextSize = btn1.Text";
_btn1.setTextSize((float) (20));
 //BA.debugLineNum = 148;BA.debugLine="btn1.TextSize =  20   : btn2.TextSize = btn1.Text";
_btn2.setTextSize(_btn1.getTextSize());
 //BA.debugLineNum = 149;BA.debugLine="btnDistance_Highlight(btnDst1)";
_btndistance_highlight(_btndst1);
 //BA.debugLineNum = 150;BA.debugLine="ShowZinfo(\"Touch START to begin\")";
_showzinfo("Touch START to begin");
 //BA.debugLineNum = 151;BA.debugLine="parent.Visible = True";
_parent.setVisible(__c.True);
 //BA.debugLineNum = 152;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"dlgBedLevelMes";
_mmodule = "dlgBedLevelMeshWiz";
 //BA.debugLineNum = 8;BA.debugLine="Private mOBJ As B4XMainPage'ignore";
_mobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 9;BA.debugLine="Private oWS As OctoWebSocket";
_ows = new sadLogic.OctoTouchController.foss.octowebsocket();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 16;BA.debugLine="Private parent As Panel";
_parent = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private pnlSteps,pnlBG As Panel";
_pnlsteps = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlbg = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private btnClose,btn1,btn2,btnPreheat As Button";
_btnclose = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn2 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpreheat = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private alblHeader,alblMenu As AutoTextSizeLabel";
_alblheader = new sadLogic.OctoTouchController.foss.autotextsizelabel();
_alblmenu = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 21;BA.debugLine="Private lblHeaterBed,lblHeaterTool As Label";
_lblheaterbed = new anywheresoftware.b4a.objects.LabelWrapper();
_lblheatertool = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private pnlSpacer1,pnlSpacer2 As B4XView";
_pnlspacer1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlspacer2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private tmrHeaterOnOff As Timer";
_tmrheateronoff = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 25;BA.debugLine="Private mDIstance As Double = .01";
_mdistance = .01;
 //BA.debugLineNum = 26;BA.debugLine="Private mInProbeMode As Boolean = False";
_minprobemode = __c.False;
 //BA.debugLineNum = 28;BA.debugLine="Private btnDn,btnUp As Button";
_btndn = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnup = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Public pMode As String";
_pmode = "";
 //BA.debugLineNum = 31;BA.debugLine="Public Const ppMANUAL_MESH As String = \"mblw\"";
_ppmanual_mesh = "mblw";
 //BA.debugLineNum = 33;BA.debugLine="Private alblZinfo As AutoTextSizeLabel";
_alblzinfo = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 34;BA.debugLine="Private oBeepMe As SoundsBeeps";
_obeepme = new sadLogic.OctoTouchController.foss.soundsbeeps();
 //BA.debugLineNum = 36;BA.debugLine="Private btnDst5,btnDst4,btnDst3,btnDst2,btnDst1 A";
_btndst5 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btndst4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btndst3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btndst2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btndst1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private mCurrentMarlinZ As Float = 0";
_mcurrentmarlinz = (float) (0);
 //BA.debugLineNum = 40;BA.debugLine="Private mOldMarlinZ As Float = -999";
_moldmarlinz = (float) (-999);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Public Sub Close_Me  '--- class method, also calle";
 //BA.debugLineNum = 107;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 108;BA.debugLine="mOBJ.oMasterController.oWS.pParserWO.ResetRaiseE";
_mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._resetraiseevent /*String*/ ();
 //BA.debugLineNum = 109;BA.debugLine="If mInProbeMode Then";
if (_minprobemode) { 
 //BA.debugLineNum = 110;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_ABORT)";
_mobj._send_gcode /*void*/ (_oc._cklippy_abort /*String*/ );
 };
 }else {
 };
 //BA.debugLineNum = 115;BA.debugLine="parent.SetVisibleAnimated(500,False)";
_parent.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 116;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(_main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 117;BA.debugLine="Try '--- blowing up when app ends. Why?";
try { //BA.debugLineNum = 118;BA.debugLine="If tmrHeaterOnOff.IsInitialized Then";
if (_tmrheateronoff.IsInitialized()) { 
 //BA.debugLineNum = 119;BA.debugLine="tmrHeaterOnOff.Enabled = False";
_tmrheateronoff.setEnabled(__c.False);
 //BA.debugLineNum = 120;BA.debugLine="tmrHeaterOnOff = Null";
_tmrheateronoff = (anywheresoftware.b4a.objects.Timer)(__c.Null);
 };
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 123;BA.debugLine="Log(LastException)";
__c.LogImpl("14286866",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 125;BA.debugLine="parent.RemoveAllViews";
_parent.RemoveAllViews();
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public String  _distancebtnslookreset() throws Exception{
 //BA.debugLineNum = 165;BA.debugLine="Private Sub DistanceBtnsLookReset";
 //BA.debugLineNum = 166;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnDst1,btn";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btndst1.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btndst2.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btndst3.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btndst4.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btndst5.getObject()))});
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.PanelWrapper _p,String _mode) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 48;BA.debugLine="Public Sub Initialize(p As Panel,mode As String) A";
 //BA.debugLineNum = 50;BA.debugLine="mOBJ = B4XPages.MainPage";
_mobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 51;BA.debugLine="p.RemoveAllViews";
_p.RemoveAllViews();
 //BA.debugLineNum = 52;BA.debugLine="parent = p";
_parent = _p;
 //BA.debugLineNum = 53;BA.debugLine="pMode = mode";
_pmode = _mode;
 //BA.debugLineNum = 54;BA.debugLine="oBeepMe.Initialize";
_obeepme._initialize /*String*/ (ba);
 //BA.debugLineNum = 55;BA.debugLine="oWS = mOBJ.oMasterController.oWS";
_ows = _mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ;
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public String  _parse_z_offset_msg(String _txt) throws Exception{
int _z1 = 0;
int _z2 = 0;
String _ret = "";
 //BA.debugLineNum = 378;BA.debugLine="Private Sub parse_z_offset_msg(txt As String)";
 //BA.debugLineNum = 381;BA.debugLine="mOldMarlinZ = -998";
_moldmarlinz = (float) (-998);
 //BA.debugLineNum = 382;BA.debugLine="Try";
try { //BA.debugLineNum = 383;BA.debugLine="Dim z1 As Int = txt.IndexOf(\"Z\")";
_z1 = _txt.indexOf("Z");
 //BA.debugLineNum = 384;BA.debugLine="Dim z2 As Int = txt.IndexOf(\";\")";
_z2 = _txt.indexOf(";");
 //BA.debugLineNum = 385;BA.debugLine="Dim ret As String = txt.SubString2(z1 + 1,z2 - 1";
_ret = _txt.substring((int) (_z1+1),(int) (_z2-1)).trim();
 //BA.debugLineNum = 386;BA.debugLine="If IsNumber(ret) Then";
if (__c.IsNumber(_ret)) { 
 //BA.debugLineNum = 387;BA.debugLine="mOldMarlinZ = Round2(ret.As(Float),2)";
_moldmarlinz = (float) (__c.Round2(((float)(Double.parseDouble(_ret))),(int) (2)));
 };
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 390;BA.debugLine="Log(LastException)";
__c.LogImpl("15007756",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 392;BA.debugLine="oWS.pParserWO.MsgsRemove(\"M851 \")";
_ows._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._msgsremove /*String*/ ("M851 ");
 //BA.debugLineNum = 394;BA.debugLine="End Sub";
return "";
}
public String  _parsezinfo(String _s) throws Exception{
int _startndx = 0;
 //BA.debugLineNum = 191;BA.debugLine="Private Sub ParseZInfo(s As String)'ignore";
 //BA.debugLineNum = 192;BA.debugLine="If s.IndexOf(\"Z pos\") = -1 Then Return";
if (_s.indexOf("Z pos")==-1) { 
if (true) return "";};
 //BA.debugLineNum = 193;BA.debugLine="Try";
try { //BA.debugLineNum = 194;BA.debugLine="Dim StartNdx As Int = s.IndexOf(\"Z pos\")";
_startndx = _s.indexOf("Z pos");
 //BA.debugLineNum = 196;BA.debugLine="ShowZinfo(s.SubString2(StartNdx,s.Length))";
_showzinfo(_s.substring(_startndx,_s.length()));
 } 
       catch (Exception e6) {
			ba.setLastException(e6); //BA.debugLineNum = 198;BA.debugLine="Log(LastException)";
__c.LogImpl("14811143",BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 199;BA.debugLine="Log(\"ParseZInfo ERR2: \" & s)";
__c.LogImpl("14811144","ParseZInfo ERR2: "+_s,0);
 //BA.debugLineNum = 200;BA.debugLine="ShowZinfo(\"Parse Error:\")";
_showzinfo("Parse Error:");
 };
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public String  _pnlbg_click() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Private Sub pnlBG_Click";
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public String  _probe_failed_klippy() throws Exception{
 //BA.debugLineNum = 558;BA.debugLine="Private Sub Probe_failed_klippy";
 //BA.debugLineNum = 560;BA.debugLine="ShowZinfo(\"probe failed...\")";
_showzinfo("probe failed...");
 //BA.debugLineNum = 561;BA.debugLine="ProcessStop_GUI";
_processstop_gui();
 //BA.debugLineNum = 562;BA.debugLine="End Sub";
return "";
}
public String  _processmarlinmovemsg(String _msg) throws Exception{
int _sp = 0;
String _tmp = "";
 //BA.debugLineNum = 526;BA.debugLine="Private Sub ProcessMarlinMoveMsg(msg As String)";
 //BA.debugLineNum = 528;BA.debugLine="Try";
try { //BA.debugLineNum = 529;BA.debugLine="If msg.Contains(\"???\") Then Return";
if (_msg.contains("???")) { 
if (true) return "";};
 //BA.debugLineNum = 530;BA.debugLine="Dim sp As Int = msg.IndexOf(\"New Z=\")";
_sp = _msg.indexOf("New Z=");
 //BA.debugLineNum = 531;BA.debugLine="Dim tmp As String = msg.SubString(sp).Replace(\"N";
_tmp = _msg.substring(_sp).replace("New Z=","").replace("*","").trim();
 //BA.debugLineNum = 532;BA.debugLine="mCurrentMarlinZ = Round2(tmp,2)";
_mcurrentmarlinz = (float) (__c.Round2((double)(Double.parseDouble(_tmp)),(int) (2)));
 //BA.debugLineNum = 533;BA.debugLine="Log(\"G1 Z\" & tmp)";
__c.LogImpl("15269895","G1 Z"+_tmp,0);
 } 
       catch (Exception e8) {
			ba.setLastException(e8); //BA.debugLineNum = 535;BA.debugLine="Log(LastException)";
__c.LogImpl("15269897",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 539;BA.debugLine="End Sub";
return "";
}
public void  _processmeshcomplete() throws Exception{
ResumableSub_ProcessMeshComplete rsub = new ResumableSub_ProcessMeshComplete(this);
rsub.resume(ba, null);
}
public static class ResumableSub_ProcessMeshComplete extends BA.ResumableSub {
public ResumableSub_ProcessMeshComplete(sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent;
anywheresoftware.b4a.keywords.StringBuilderWrapper _m = null;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 567;BA.debugLine="Dim m As StringBuilder: m.Initialize";
_m = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 567;BA.debugLine="Dim m As StringBuilder: m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 569;BA.debugLine="Select Case True";
if (true) break;

case 1:
//select
this.state = 28;
switch (BA.switchObjectToInt(parent.__c.True,parent._oc._klippy /*boolean*/  && (parent._pmode).equals(parent._ppmanual_mesh),parent._oc._klippy /*boolean*/  && (parent._pmode).equals(parent._ppmanual_mesh) == false,parent._oc._klippy /*boolean*/ ==parent.__c.False && (parent._pmode).equals(parent._ppmanual_mesh),parent._oc._klippy /*boolean*/ ==parent.__c.False && (parent._pmode).equals(parent._ppmanual_mesh) == false)) {
case 0: {
this.state = 3;
if (true) break;
}
case 1: {
this.state = 11;
if (true) break;
}
case 2: {
this.state = 19;
if (true) break;
}
case 3: {
this.state = 21;
if (true) break;
}
}
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 571;BA.debugLine="m.Append(\"Bed Mesh state has been saved to prof";
_m.Append("Bed Mesh state has been saved to profile [default] for the ");
 //BA.debugLineNum = 572;BA.debugLine="m.Append(\"current session. Touch SAVE to update";
_m.Append("current session. Touch SAVE to update the printer config ");
 //BA.debugLineNum = 573;BA.debugLine="m.Append(\"File And restart the printer or CLOSE";
_m.Append("File And restart the printer or CLOSE to just use the current mesh");
 //BA.debugLineNum = 574;BA.debugLine="Wait For (SavePrompt(m.ToString)) Complete (res";
parent.__c.WaitFor("complete", ba, this, parent._saveprompt(_m.ToString()));
this.state = 29;
return;
case 29:
//C
this.state = 4;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 576;BA.debugLine="If res = xui.DialogResponse_Positive Then";
if (true) break;

case 4:
//if
this.state = 9;
if (_res==parent._xui.DialogResponse_Positive) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 577;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_SAVE)";
parent._mobj._send_gcode /*void*/ (parent._oc._cklippy_save /*String*/ );
 //BA.debugLineNum = 578;BA.debugLine="guiHelpers.Show_toast2(\"Saving CONFIG and rest";
parent._guihelpers._show_toast2 /*String*/ (ba,"Saving CONFIG and restarting printer",(int) (5200));
 //BA.debugLineNum = 579;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(mOBJ.o";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick",(int) (800));
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 581;BA.debugLine="guiHelpers.Show_toast2(\"Using Mesh for current";
parent._guihelpers._show_toast2 /*String*/ (ba,"Using Mesh for current session, homing printer",(int) (3000));
 //BA.debugLineNum = 582;BA.debugLine="mOBJ.Send_Gcode(\"G28\")";
parent._mobj._send_gcode /*void*/ ("G28");
 if (true) break;

case 9:
//C
this.state = 28;
;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 587;BA.debugLine="m.Append(\"New Z-Offset will be used for the cur";
_m.Append("New Z-Offset will be used for the current session.");
 //BA.debugLineNum = 588;BA.debugLine="m.Append(\"Touch SAVE to update the printer conf";
_m.Append("Touch SAVE to update the printer config file And ");
 //BA.debugLineNum = 589;BA.debugLine="m.Append(\"restart the printer or CLOSE to just";
_m.Append("restart the printer or CLOSE to just use the current offset");
 //BA.debugLineNum = 590;BA.debugLine="Wait For (SavePrompt(m.ToString)) Complete (res";
parent.__c.WaitFor("complete", ba, this, parent._saveprompt(_m.ToString()));
this.state = 30;
return;
case 30:
//C
this.state = 12;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 594;BA.debugLine="If res = xui.DialogResponse_Positive Then";
if (true) break;

case 12:
//if
this.state = 17;
if (_res==parent._xui.DialogResponse_Positive) { 
this.state = 14;
}else {
this.state = 16;
}if (true) break;

case 14:
//C
this.state = 17;
 //BA.debugLineNum = 595;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_SAVE)";
parent._mobj._send_gcode /*void*/ (parent._oc._cklippy_save /*String*/ );
 //BA.debugLineNum = 596;BA.debugLine="guiHelpers.Show_toast2(\"Saving new Z-Offset an";
parent._guihelpers._show_toast2 /*String*/ (ba,"Saving new Z-Offset and restarting printer",(int) (5200));
 //BA.debugLineNum = 597;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(mOBJ.o";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick",(int) (800));
 if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 599;BA.debugLine="guiHelpers.Show_toast2(\"Using Z-Offset for cur";
parent._guihelpers._show_toast2 /*String*/ (ba,"Using Z-Offset for current session, homing printer",(int) (4000));
 //BA.debugLineNum = 600;BA.debugLine="mOBJ.Send_Gcode(\"G28\")";
parent._mobj._send_gcode /*void*/ ("G28");
 if (true) break;

case 17:
//C
this.state = 28;
;
 if (true) break;

case 19:
//C
this.state = 28;
 if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 607;BA.debugLine="mOBJ.oMasterController.oWS.pParserWO.EventRemov";
parent._mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._eventremove /*String*/ ("ZChange");
 //BA.debugLineNum = 608;BA.debugLine="m.Append(\"New Z-Offset will be used for the cur";
_m.Append("New Z-Offset will be used for the current session.");
 //BA.debugLineNum = 609;BA.debugLine="m.Append(\"Touch SAVE to update your printers th";
_m.Append("Touch SAVE to update your printers the EEPROM ");
 //BA.debugLineNum = 610;BA.debugLine="m.Append(\"or CLOSE to just use the current offs";
_m.Append("or CLOSE to just use the current offset.");
 //BA.debugLineNum = 611;BA.debugLine="Wait For (SavePrompt(m.ToString)) Complete (res";
parent.__c.WaitFor("complete", ba, this, parent._saveprompt(_m.ToString()));
this.state = 31;
return;
case 31:
//C
this.state = 22;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 613;BA.debugLine="If res = xui.DialogResponse_Positive Then";
if (true) break;

case 22:
//if
this.state = 27;
if (_res==parent._xui.DialogResponse_Positive) { 
this.state = 24;
}else {
this.state = 26;
}if (true) break;

case 24:
//C
this.state = 27;
 //BA.debugLineNum = 614;BA.debugLine="mOBJ.Send_Gcode(\"M500\")";
parent._mobj._send_gcode /*void*/ ("M500");
 //BA.debugLineNum = 615;BA.debugLine="guiHelpers.Show_toast2(\"New Z-Offset saved to";
parent._guihelpers._show_toast2 /*String*/ (ba,"New Z-Offset saved to EEPROM",(int) (4000));
 if (true) break;

case 26:
//C
this.state = 27;
 //BA.debugLineNum = 617;BA.debugLine="guiHelpers.Show_toast2(\"Using Z-Offset for cur";
parent._guihelpers._show_toast2 /*String*/ (ba,"Using Z-Offset for current session",(int) (4000));
 if (true) break;

case 27:
//C
this.state = 28;
;
 //BA.debugLineNum = 619;BA.debugLine="mOBJ.Send_Gcode(\"M211 S1\") '--- turn on softwar";
parent._mobj._send_gcode /*void*/ ("M211 S1");
 //BA.debugLineNum = 620;BA.debugLine="mOBJ.Send_Gcode(\"G28\")";
parent._mobj._send_gcode /*void*/ ("G28");
 if (true) break;

case 28:
//C
this.state = -1;
;
 //BA.debugLineNum = 626;BA.debugLine="Close_Me '--- out of here, exit wizard";
parent._close_me();
 //BA.debugLineNum = 627;BA.debugLine="Return";
if (true) return ;
 //BA.debugLineNum = 629;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public String  _processstop_gui() throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Private Sub ProcessStop_GUI";
 //BA.debugLineNum = 155;BA.debugLine="mInProbeMode = False";
_minprobemode = __c.False;
 //BA.debugLineNum = 156;BA.debugLine="btn2.Visible = False";
_btn2.setVisible(__c.False);
 //BA.debugLineNum = 157;BA.debugLine="btnPreheat.Visible = True";
_btnpreheat.setVisible(__c.True);
 //BA.debugLineNum = 158;BA.debugLine="btn1.Text = \"START\"";
_btn1.setText(BA.ObjectToCharSequence("START"));
 //BA.debugLineNum = 159;BA.debugLine="btnClose.Visible = True";
_btnclose.setVisible(__c.True);
 //BA.debugLineNum = 160;BA.debugLine="btnClose.RequestFocus";
_btnclose.RequestFocus();
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public void  _rec_text(String _txt) throws Exception{
ResumableSub_Rec_Text rsub = new ResumableSub_Rec_Text(this,_txt);
rsub.resume(ba, null);
}
public static class ResumableSub_Rec_Text extends BA.ResumableSub {
public ResumableSub_Rec_Text(sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent,String _txt) {
this.parent = parent;
this._txt = _txt;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent;
String _txt;
String[] _cd = null;
String _s = "";
String[] group3;
int index3;
int groupLen3;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 434;BA.debugLine="If txt.Contains(CRLF) Then";
if (true) break;

case 1:
//if
this.state = 10;
if (_txt.contains(parent.__c.CRLF)) { 
this.state = 3;
}else {
this.state = 9;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 435;BA.debugLine="Dim cd() As String = Regex.Split(CRLF, txt)";
_cd = parent.__c.Regex.Split(parent.__c.CRLF,_txt);
 //BA.debugLineNum = 437;BA.debugLine="For Each s As String In cd";
if (true) break;

case 4:
//for
this.state = 7;
group3 = _cd;
index3 = 0;
groupLen3 = group3.length;
this.state = 11;
if (true) break;

case 11:
//C
this.state = 7;
if (index3 < groupLen3) {
this.state = 6;
_s = group3[index3];}
if (true) break;

case 12:
//C
this.state = 11;
index3++;
if (true) break;

case 6:
//C
this.state = 12;
 //BA.debugLineNum = 438;BA.debugLine="Rec_Text2(s)";
parent._rec_text2(_s);
 //BA.debugLineNum = 439;BA.debugLine="Sleep(250) '--- 1/4 second between";
parent.__c.Sleep(ba,this,(int) (250));
this.state = 13;
return;
case 13:
//C
this.state = 12;
;
 if (true) break;
if (true) break;

case 7:
//C
this.state = 10;
;
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 442;BA.debugLine="Rec_Text2(txt)";
parent._rec_text2(_txt);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 444;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _rec_text2(String _txt) throws Exception{
 //BA.debugLineNum = 447;BA.debugLine="Private Sub Rec_Text2(txt As String)";
 //BA.debugLineNum = 449;BA.debugLine="logMe.LogDebug2(\"rec txt:\" & txt,\"\")";
_logme._logdebug2 /*String*/ (ba,"rec txt:"+_txt,"");
 //BA.debugLineNum = 451;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 453;BA.debugLine="If pMode = ppMANUAL_MESH Then '--- manual bed le";
if ((_pmode).equals(_ppmanual_mesh)) { 
 //BA.debugLineNum = 455;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txt.contains("y in a manual Z probe"),_txt.contains("g manual Z probe"),_txt.contains("Z pos"),_txt.contains("Manual probe failed"),_txt.contains("has been saved"))) {
case 0: {
 //BA.debugLineNum = 459;BA.debugLine="RestartAlreadyIn_klippy";
_restartalreadyin_klippy();
 break; }
case 1: {
 //BA.debugLineNum = 463;BA.debugLine="If pMode = ppMANUAL_MESH Then '--- manual bed";
if ((_pmode).equals(_ppmanual_mesh)) { 
 //BA.debugLineNum = 464;BA.debugLine="btn1.Text = oc.cKLIPPY_ACCEPT";
_btn1.setText(BA.ObjectToCharSequence(_oc._cklippy_accept /*String*/ ));
 }else {
 //BA.debugLineNum = 466;BA.debugLine="btn1.Text = \"DONE\"";
_btn1.setText(BA.ObjectToCharSequence("DONE"));
 };
 //BA.debugLineNum = 468;BA.debugLine="btnClose.Visible = False";
_btnclose.setVisible(__c.False);
 //BA.debugLineNum = 469;BA.debugLine="btnPreheat.Visible = False";
_btnpreheat.setVisible(__c.False);
 //BA.debugLineNum = 470;BA.debugLine="btn2.Visible = True";
_btn2.setVisible(__c.True);
 break; }
case 2: {
 //BA.debugLineNum = 473;BA.debugLine="ParseZInfo(txt)";
_parsezinfo(_txt);
 break; }
case 3: {
 //BA.debugLineNum = 476;BA.debugLine="Probe_failed_klippy";
_probe_failed_klippy();
 break; }
case 4: {
 //BA.debugLineNum = 479;BA.debugLine="ShowZinfo(\"Process complete\")";
_showzinfo("Process complete");
 //BA.debugLineNum = 480;BA.debugLine="ProcessMeshComplete";
_processmeshcomplete();
 break; }
}
;
 }else {
 //BA.debugLineNum = 488;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txt.contains("Already in a manual Z p"),_txt.contains("g manual Z probe"),_txt.contains("Z position is"),_txt.contains("Z pos"))) {
case 0: {
 //BA.debugLineNum = 491;BA.debugLine="RestartAlreadyIn_klippy";
_restartalreadyin_klippy();
 break; }
case 1: {
 //BA.debugLineNum = 494;BA.debugLine="btn1.Text = \"DONE\"";
_btn1.setText(BA.ObjectToCharSequence("DONE"));
 //BA.debugLineNum = 495;BA.debugLine="btn2.Visible = True";
_btn2.setVisible(__c.True);
 //BA.debugLineNum = 496;BA.debugLine="btnClose.Visible = False";
_btnclose.setVisible(__c.False);
 //BA.debugLineNum = 497;BA.debugLine="btnPreheat.Visible = False";
_btnpreheat.setVisible(__c.False);
 break; }
case 2: {
 //BA.debugLineNum = 500;BA.debugLine="ProcessMeshComplete";
_processmeshcomplete();
 break; }
case 3: {
 //BA.debugLineNum = 503;BA.debugLine="ParseZInfo(txt)";
_parsezinfo(_txt);
 break; }
default: {
 //BA.debugLineNum = 505;BA.debugLine="Log(\"else:\" & txt)";
__c.LogImpl("15204410","else:"+_txt,0);
 break; }
}
;
 };
 }else {
 //BA.debugLineNum = 515;BA.debugLine="Log(txt)";
__c.LogImpl("15204420",_txt,0);
 //BA.debugLineNum = 516;BA.debugLine="ProcessMarlinMoveMsg(txt)";
_processmarlinmovemsg(_txt);
 //BA.debugLineNum = 517;BA.debugLine="ShowZinfo(txt)";
_showzinfo(_txt);
 };
 //BA.debugLineNum = 524;BA.debugLine="End Sub";
return "";
}
public void  _restartalreadyin_klippy() throws Exception{
ResumableSub_RestartAlreadyIn_klippy rsub = new ResumableSub_RestartAlreadyIn_klippy(this);
rsub.resume(ba, null);
}
public static class ResumableSub_RestartAlreadyIn_klippy extends BA.ResumableSub {
public ResumableSub_RestartAlreadyIn_klippy(sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 542;BA.debugLine="guiHelpers.Show_toast2(\"Manual Z probe already st";
parent._guihelpers._show_toast2 /*String*/ (ba,"Manual Z probe already started: Restarting...",(int) (6500));
 //BA.debugLineNum = 543;BA.debugLine="mOBJ.Send_Gcode(oc.cKLIPPY_ABORT)";
parent._mobj._send_gcode /*void*/ (parent._oc._cklippy_abort /*String*/ );
 //BA.debugLineNum = 544;BA.debugLine="Sleep(2000)";
parent.__c.Sleep(ba,this,(int) (2000));
this.state = 7;
return;
case 7:
//C
this.state = 1;
;
 //BA.debugLineNum = 545;BA.debugLine="If pMode = ppMANUAL_MESH Then";
if (true) break;

case 1:
//if
this.state = 6;
if ((parent._pmode).equals(parent._ppmanual_mesh)) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 546;BA.debugLine="mOBJ.Send_Gcode(\"BED_MESH_CALIBRATE  METHOD=manu";
parent._mobj._send_gcode /*void*/ ("BED_MESH_CALIBRATE  METHOD=manual");
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 548;BA.debugLine="mOBJ.Send_Gcode(\"MANUAL_PROBE\")";
parent._mobj._send_gcode /*void*/ ("MANUAL_PROBE");
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 550;BA.debugLine="Sleep(2000)";
parent.__c.Sleep(ba,this,(int) (2000));
this.state = 8;
return;
case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 551;BA.debugLine="Return";
if (true) return ;
 //BA.debugLineNum = 552;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _saveprompt(String _msg) throws Exception{
ResumableSub_SavePrompt rsub = new ResumableSub_SavePrompt(this,_msg);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SavePrompt extends BA.ResumableSub {
public ResumableSub_SavePrompt(sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent,String _msg) {
this.parent = parent;
this._msg = _msg;
}
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz2 parent;
String _msg;
float _w = 0f;
float _h = 0f;
sadLogic.OctoTouchController.foss.dlgmsgbox2 _mb2 = null;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 635;BA.debugLine="Dim w,h As Float";
_w = 0f;
_h = 0f;
 //BA.debugLineNum = 636;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 637;BA.debugLine="w = guiHelpers.gWidth * .7";
_w = (float) (parent._guihelpers._gwidth /*float*/ *.7);
 //BA.debugLineNum = 638;BA.debugLine="h = guiHelpers.MaxVerticalHeight_Landscape";
_h = parent._guihelpers._maxverticalheight_landscape /*float*/ (ba);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 640;BA.debugLine="w = guiHelpers.gWidth * .8 : h = 310dip";
_w = (float) (parent._guihelpers._gwidth /*float*/ *.8);
 //BA.debugLineNum = 640;BA.debugLine="w = guiHelpers.gWidth * .8 : h = 310dip";
_h = (float) (parent.__c.DipToCurrent((int) (310)));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 642;BA.debugLine="Dim mb2 As dlgMsgBox2 : mb2.Initialize(mOBJ.Root,";
_mb2 = new sadLogic.OctoTouchController.foss.dlgmsgbox2();
 //BA.debugLineNum = 642;BA.debugLine="Dim mb2 As dlgMsgBox2 : mb2.Initialize(mOBJ.Root,";
_mb2._initialize /*String*/ (ba,parent._mobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,_h,parent.__c.False);
 //BA.debugLineNum = 643;BA.debugLine="mb2.NewTextSize = 24";
_mb2._newtextsize /*float*/  = (float) (24);
 //BA.debugLineNum = 644;BA.debugLine="Wait For (mb2.Show(msg,gblConst.MB_ICON_QUESTION,";
parent.__c.WaitFor("complete", ba, this, _mb2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_msg,parent._gblconst._mb_icon_question /*String*/ ,"SAVE","","CLOSE"));
this.state = 7;
return;
case 7:
//C
this.state = -1;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 645;BA.debugLine="Return res";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_res));return;};
 //BA.debugLineNum = 648;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _show(String _headertxt) throws Exception{
 //BA.debugLineNum = 78;BA.debugLine="Public Sub Show(headerTxt As String)";
 //BA.debugLineNum = 83;BA.debugLine="parent.SetLayoutAnimated(0, 0, 0, parent.Width, p";
_parent.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_parent.getWidth(),_parent.getHeight());
 //BA.debugLineNum = 84;BA.debugLine="parent.LoadLayout(\"wizManualMeshBedLevel\")";
_parent.LoadLayout("wizManualMeshBedLevel",ba);
 //BA.debugLineNum = 85;BA.debugLine="BuildGUI(headerTxt)";
_buildgui(_headertxt);
 //BA.debugLineNum = 86;BA.debugLine="btn2.Visible = False";
_btn2.setVisible(__c.False);
 //BA.debugLineNum = 88;BA.debugLine="tmrHeaterOnOff.Initialize(\"tmrHeater\",1500)";
_tmrheateronoff.Initialize(ba,"tmrHeater",(long) (1500));
 //BA.debugLineNum = 89;BA.debugLine="tmrHeater_Tick";
_tmrheater_tick();
 //BA.debugLineNum = 90;BA.debugLine="tmrHeaterOnOff.Enabled = True";
_tmrheateronoff.setEnabled(__c.True);
 //BA.debugLineNum = 92;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 93;BA.debugLine="mOBJ.oMasterController.oWS.pParserWO.RaiseEventM";
_mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._raiseeventmod /*Object*/  = this;
 //BA.debugLineNum = 94;BA.debugLine="mOBJ.oMasterController.oWS.pParserWO.RaiseEventE";
_mobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pparserwo /*sadLogic.OctoTouchController.foss.websocketparse*/ ._raiseeventevent /*String*/  = "rec_text";
 };
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public String  _showzinfo(String _info) throws Exception{
 //BA.debugLineNum = 184;BA.debugLine="Private Sub ShowZinfo(info As String)";
 //BA.debugLineNum = 185;BA.debugLine="If info = \"\" Then info = \"Z Location ???\"";
if ((_info).equals("")) { 
_info = "Z Location ???";};
 //BA.debugLineNum = 186;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 187;BA.debugLine="info = info.Replace(\"Z position: \",\"Z pos: \")";
_info = _info.replace("Z position: ","Z pos: ");
 };
 //BA.debugLineNum = 189;BA.debugLine="alblZinfo.Text = info";
_alblzinfo._settext /*Object*/ ((Object)(_info));
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return "";
}
public String  _tmrheater_tick() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Private Sub tmrHeater_Tick";
 //BA.debugLineNum = 64;BA.debugLine="lblHeaterTool.Text =\"Tool: \" & CRLF & oc.Tool1Act";
_lblheatertool.setText(BA.ObjectToCharSequence("Tool: "+__c.CRLF+_oc._tool1actual /*String*/ .replace("C","")));
 //BA.debugLineNum = 65;BA.debugLine="lblHeaterBed.Text = \"Bed: \" & CRLF & oc.BedActual";
_lblheaterbed.setText(BA.ObjectToCharSequence("Bed: "+__c.CRLF+_oc._bedactual /*String*/ .replace("C","")));
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
if (BA.fastSubCompare(sub, "SHOW"))
	return _show((String) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
