package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagemenu2{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _w1="";
String _menulowerbtnlinetop="";
String _subbtntop="";
String _l0="";
String _p1="";
String _p2="";
String _padtop="";
String _h1="";
String _h2="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmainmenu").vw.setLeft((int)(0d));
views.get("pnlmainmenu").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmainmenu").vw.setTop((int)(0d));
views.get("pnlmainmenu").vw.setHeight((int)((100d / 100 * height) - (0d)));
if ((BA.ObjectToBoolean( String.valueOf(!anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
_w1 = BA.NumberToString((views.get("pnlmainmenu").vw.getWidth())*.6d);
_menulowerbtnlinetop = BA.NumberToString((4d * scale));
views.get("pnlinfo").vw.setLeft((int)(0d));
views.get("pnlinfo").vw.setWidth((int)(Double.parseDouble(_w1) - (0d)));
views.get("pnlmenulower").vw.setLeft((int)(0d));
views.get("pnlmenulower").vw.setWidth((int)(Double.parseDouble(_w1) - (0d)));
views.get("pnlmenulower").vw.setTop((int)((views.get("pnlmainmenu").vw.getHeight())-(72d * scale)));
views.get("pnlmenulower").vw.setHeight((int)((views.get("pnlmainmenu").vw.getHeight()) - ((views.get("pnlmainmenu").vw.getHeight())-(72d * scale))));
views.get("pnlinfo").vw.setTop((int)((views.get("pnlmainmenu").vw.getTop())));
views.get("pnlinfo").vw.setHeight((int)((views.get("pnlmenulower").vw.getTop()) - ((views.get("pnlmainmenu").vw.getTop()))));
_subbtntop = BA.NumberToString(((views.get("pnlmenulower").vw.getHeight())/2d)+(8d * scale));
views.get("btnsubplugin4").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin4").vw.getHeight() / 2)));
views.get("btnsubheater").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubheater").vw.getHeight() / 2)));
views.get("btnsubplugin1").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin1").vw.getHeight() / 2)));
views.get("btnsubplugin2").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin2").vw.getHeight() / 2)));
views.get("btnsubplugin3").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin3").vw.getHeight() / 2)));
views.get("btnsubplugin5").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin5").vw.getHeight() / 2)));
_l0 = BA.NumberToString((10d * scale));
views.get("pnlmenulowerbline").vw.setLeft((int)((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0)));
views.get("pnlmenulowerbline").vw.setWidth((int)((views.get("pnlmenulower").vw.getLeft() + views.get("pnlmenulower").vw.getWidth())-Double.parseDouble(_l0) - ((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0))));
views.get("pnlmenulowerbline").vw.setTop((int)((2d * scale)));
views.get("pnlmenulowerbline").vw.setHeight((int)(Double.parseDouble(_menulowerbtnlinetop)));
views.get("pnlmenulowerbline").vw.setVisible(BA.parseBoolean("false"));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlmenulower", BA.NumberToString((60d * scale)), BA.NumberToString((2d * scale)), "center"});
views.get("pnlmenubtns").vw.setLeft((int)((views.get("pnlinfo").vw.getLeft() + views.get("pnlinfo").vw.getWidth())));
views.get("pnlmenubtns").vw.setWidth((int)((views.get("pnlmainmenu").vw.getLeft() + views.get("pnlmainmenu").vw.getWidth()) - ((views.get("pnlinfo").vw.getLeft() + views.get("pnlinfo").vw.getWidth()))));
views.get("pnlmenubtns").vw.setTop((int)((views.get("pnlmainmenu").vw.getTop())));
views.get("pnlmenubtns").vw.setHeight((int)((views.get("pnlmainmenu").vw.getTop() + views.get("pnlmainmenu").vw.getHeight()) - ((views.get("pnlmainmenu").vw.getTop()))));
_p1 = BA.NumberToString((4d * scale));
_p2 = BA.NumberToString((10d * scale));
_padtop = BA.NumberToString((34d * scale));
views.get("pnltemptool").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnltemptool").vw.setWidth((int)(((views.get("pnlinfo").vw.getWidth())/2d)-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
views.get("pnltempbed").vw.setLeft((int)((views.get("pnltemptool").vw.getLeft() + views.get("pnltemptool").vw.getWidth())+Double.parseDouble(_p1)));
views.get("pnltempbed").vw.setWidth((int)((views.get("pnlinfo").vw.getWidth())-(Double.parseDouble(_p1)) - ((views.get("pnltemptool").vw.getLeft() + views.get("pnltemptool").vw.getWidth())+Double.parseDouble(_p1))));
views.get("pnltemptool").vw.setTop((int)(Double.parseDouble(_p2)+Double.parseDouble(_padtop)));
views.get("pnltemptool").vw.setHeight((int)((views.get("pnlinfo").vw.getHeight())-Double.parseDouble(_p2) - (Double.parseDouble(_p2)+Double.parseDouble(_padtop))));
views.get("pnltempbed").vw.setTop((int)(Double.parseDouble(_p2)+Double.parseDouble(_padtop)));
views.get("pnltempbed").vw.setHeight((int)((views.get("pnlinfo").vw.getHeight())-Double.parseDouble(_p2) - (Double.parseDouble(_p2)+Double.parseDouble(_padtop))));
_p1 = BA.NumberToString((4d * scale));
_p2 = BA.NumberToString((4d * scale));
views.get("pnlmnumovement").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlmnumovement").vw.setWidth((int)(((views.get("pnlmenubtns").vw.getWidth())/2d) - (Double.parseDouble(_p1))));
views.get("pnlmnumovement").vw.setTop((int)(Double.parseDouble(_p1)));
views.get("pnlmnumovement").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())/2d-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
views.get("pnlmnufiles").vw.setLeft((int)((views.get("pnlmnumovement").vw.getLeft() + views.get("pnlmnumovement").vw.getWidth())+Double.parseDouble(_p1)));
views.get("pnlmnufiles").vw.setWidth((int)((views.get("pnlmenubtns").vw.getWidth())-(Double.parseDouble(_p1)) - ((views.get("pnlmnumovement").vw.getLeft() + views.get("pnlmnumovement").vw.getWidth())+Double.parseDouble(_p1))));
views.get("pnlmnufiles").vw.setTop((int)(Double.parseDouble(_p1)));
views.get("pnlmnufiles").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())/2d-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
views.get("pnlmnuprinting").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlmnuprinting").vw.setWidth((int)((views.get("pnlmenubtns").vw.getWidth())-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
views.get("pnlmnuprinting").vw.setTop((int)((views.get("pnlmnufiles").vw.getTop() + views.get("pnlmnufiles").vw.getHeight())+Double.parseDouble(_p1)));
views.get("pnlmnuprinting").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())-Double.parseDouble(_p1) - ((views.get("pnlmnufiles").vw.getTop() + views.get("pnlmnufiles").vw.getHeight())+Double.parseDouble(_p1))));
views.get("pnlmenuupperbl").vw.setLeft((int)((views.get("pnlinfo").vw.getWidth())-(4d * scale)));
views.get("pnlmenuupperbl").vw.setWidth((int)((views.get("pnlinfo").vw.getWidth()) - ((views.get("pnlinfo").vw.getWidth())-(4d * scale))));
views.get("pnlmenuupperbl").vw.setTop((int)((views.get("pnltempbed").vw.getTop())+(15d * scale)));
views.get("pnlmenuupperbl").vw.setHeight((int)((views.get("pnlinfo").vw.getTop() + views.get("pnlinfo").vw.getHeight())-(15d * scale) - ((views.get("pnltempbed").vw.getTop())+(15d * scale))));
views.get("pnlmenuupperbl").vw.setVisible(BA.parseBoolean("false"));
;}else{ 
;
views.get("pnlinfo").vw.setLeft((int)(0d));
views.get("pnlinfo").vw.setWidth((int)((views.get("pnlmainmenu").vw.getWidth()) - (0d)));
views.get("pnlmenubtns").vw.setLeft((int)(0d));
views.get("pnlmenubtns").vw.setWidth((int)((views.get("pnlmainmenu").vw.getWidth()) - (0d)));
views.get("pnlmenulower").vw.setLeft((int)(0d));
views.get("pnlmenulower").vw.setWidth((int)((views.get("pnlmainmenu").vw.getWidth()) - (0d)));
_h1 = BA.NumberToString((views.get("pnlmainmenu").vw.getHeight())*.34d);
_h2 = BA.NumberToString((views.get("pnlmainmenu").vw.getHeight())*.56d);
views.get("pnlinfo").vw.setTop((int)((views.get("pnlmainmenu").vw.getTop())));
views.get("pnlinfo").vw.setHeight((int)(Double.parseDouble(_h1) - ((views.get("pnlmainmenu").vw.getTop()))));
views.get("pnlmenubtns").vw.setTop((int)((views.get("pnlinfo").vw.getTop() + views.get("pnlinfo").vw.getHeight())));
views.get("pnlmenubtns").vw.setHeight((int)(Double.parseDouble(_h2)+Double.parseDouble(_h1) - ((views.get("pnlinfo").vw.getTop() + views.get("pnlinfo").vw.getHeight()))));
views.get("pnlmenulower").vw.setTop((int)((views.get("pnlmenubtns").vw.getTop() + views.get("pnlmenubtns").vw.getHeight())));
views.get("pnlmenulower").vw.setHeight((int)((views.get("pnlmainmenu").vw.getTop() + views.get("pnlmainmenu").vw.getHeight()) - ((views.get("pnlmenubtns").vw.getTop() + views.get("pnlmenubtns").vw.getHeight()))));
_subbtntop = BA.NumberToString(((views.get("pnlmenulower").vw.getHeight())/2d)-(1d * scale));
views.get("btnsubplugin4").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin4").vw.getHeight() / 2)));
views.get("btnsubheater").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubheater").vw.getHeight() / 2)));
views.get("btnsubplugin1").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin1").vw.getHeight() / 2)));
views.get("btnsubplugin2").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin2").vw.getHeight() / 2)));
views.get("btnsubplugin3").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin3").vw.getHeight() / 2)));
//BA.debugLineNum = 75;BA.debugLine="btnSubPlugin5.VerticalCenter = subbtntop"[pageMenu2/General script]
views.get("btnsubplugin5").vw.setTop((int)(Double.parseDouble(_subbtntop) - (views.get("btnsubplugin5").vw.getHeight() / 2)));
//BA.debugLineNum = 77;BA.debugLine="L0 = 10dip"[pageMenu2/General script]
_l0 = BA.NumberToString((10d * scale));
//BA.debugLineNum = 78;BA.debugLine="MenuLowerBtnLineTop = 4dip"[pageMenu2/General script]
_menulowerbtnlinetop = BA.NumberToString((4d * scale));
//BA.debugLineNum = 79;BA.debugLine="pnlMenuLowerBLine.SetLeftAndRight(pnlMenuLower.Left+L0,pnlMenuLower.Right-L0)"[pageMenu2/General script]
views.get("pnlmenulowerbline").vw.setLeft((int)((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0)));
views.get("pnlmenulowerbline").vw.setWidth((int)((views.get("pnlmenulower").vw.getLeft() + views.get("pnlmenulower").vw.getWidth())-Double.parseDouble(_l0) - ((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0))));
//BA.debugLineNum = 80;BA.debugLine="pnlMenuLowerBLine.Top = 2dip"[pageMenu2/General script]
views.get("pnlmenulowerbline").vw.setTop((int)((2d * scale)));
//BA.debugLineNum = 81;BA.debugLine="pnlMenuLowerBLine.Height = MenuLowerBtnLineTop"[pageMenu2/General script]
views.get("pnlmenulowerbline").vw.setHeight((int)(Double.parseDouble(_menulowerbtnlinetop)));
//BA.debugLineNum = 82;BA.debugLine="pnlMenuLowerBLine.Visible = False '--- set to true in code"[pageMenu2/General script]
views.get("pnlmenulowerbline").vw.setVisible(BA.parseBoolean("false"));
//BA.debugLineNum = 83;BA.debugLine="DSE_Layout.SpreadHorizontally(pnlMenuLower,60dip,2dip,\"center\")"[pageMenu2/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlmenulower", BA.NumberToString((60d * scale)), BA.NumberToString((2d * scale)), "center"});
//BA.debugLineNum = 86;BA.debugLine="p1 = 4dip : p2 = 10dip : padtop = 6dip"[pageMenu2/General script]
_p1 = BA.NumberToString((4d * scale));
//BA.debugLineNum = 86;BA.debugLine="p1 = 4dip : p2 = 10dip : padtop = 6dip"[pageMenu2/General script]
_p2 = BA.NumberToString((10d * scale));
//BA.debugLineNum = 86;BA.debugLine="p1 = 4dip : p2 = 10dip : padtop = 6dip"[pageMenu2/General script]
_padtop = BA.NumberToString((6d * scale));
//BA.debugLineNum = 87;BA.debugLine="pnlTempTool.SetLeftAndRight(p1,(pnlInfo.Width / 2) - p1)"[pageMenu2/General script]
views.get("pnltemptool").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnltemptool").vw.setWidth((int)(((views.get("pnlinfo").vw.getWidth())/2d)-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 88;BA.debugLine="pnlTempBed.SetLeftAndRight(pnlTempTool.Right + p1,pnlInfo.Width - (p1))"[pageMenu2/General script]
views.get("pnltempbed").vw.setLeft((int)((views.get("pnltemptool").vw.getLeft() + views.get("pnltemptool").vw.getWidth())+Double.parseDouble(_p1)));
views.get("pnltempbed").vw.setWidth((int)((views.get("pnlinfo").vw.getWidth())-(Double.parseDouble(_p1)) - ((views.get("pnltemptool").vw.getLeft() + views.get("pnltemptool").vw.getWidth())+Double.parseDouble(_p1))));
//BA.debugLineNum = 89;BA.debugLine="pnlTempTool.SetTopAndBottom(p2+padtop,pnlInfo.Height - p2)"[pageMenu2/General script]
views.get("pnltemptool").vw.setTop((int)(Double.parseDouble(_p2)+Double.parseDouble(_padtop)));
views.get("pnltemptool").vw.setHeight((int)((views.get("pnlinfo").vw.getHeight())-Double.parseDouble(_p2) - (Double.parseDouble(_p2)+Double.parseDouble(_padtop))));
//BA.debugLineNum = 90;BA.debugLine="pnlTempBed.SetTopAndBottom(p2+padtop,pnlInfo.Height - p2)"[pageMenu2/General script]
views.get("pnltempbed").vw.setTop((int)(Double.parseDouble(_p2)+Double.parseDouble(_padtop)));
views.get("pnltempbed").vw.setHeight((int)((views.get("pnlinfo").vw.getHeight())-Double.parseDouble(_p2) - (Double.parseDouble(_p2)+Double.parseDouble(_padtop))));
//BA.debugLineNum = 91;BA.debugLine="pnlMenuUpperBL.SetLeftAndRight(pnlMenuLower.Left+L0,pnlMenuLower.Right-L0)"[pageMenu2/General script]
views.get("pnlmenuupperbl").vw.setLeft((int)((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0)));
views.get("pnlmenuupperbl").vw.setWidth((int)((views.get("pnlmenulower").vw.getLeft() + views.get("pnlmenulower").vw.getWidth())-Double.parseDouble(_l0) - ((views.get("pnlmenulower").vw.getLeft())+Double.parseDouble(_l0))));
//BA.debugLineNum = 92;BA.debugLine="pnlMenuUpperBL.Top = pnlInfo.Height - 5dip"[pageMenu2/General script]
views.get("pnlmenuupperbl").vw.setTop((int)((views.get("pnlinfo").vw.getHeight())-(5d * scale)));
//BA.debugLineNum = 93;BA.debugLine="pnlMenuUpperBL.Height = MenuLowerBtnLineTop"[pageMenu2/General script]
views.get("pnlmenuupperbl").vw.setHeight((int)(Double.parseDouble(_menulowerbtnlinetop)));
//BA.debugLineNum = 96;BA.debugLine="p1 = 4dip : p2 = 4dip"[pageMenu2/General script]
_p1 = BA.NumberToString((4d * scale));
//BA.debugLineNum = 96;BA.debugLine="p1 = 4dip : p2 = 4dip"[pageMenu2/General script]
_p2 = BA.NumberToString((4d * scale));
//BA.debugLineNum = 97;BA.debugLine="pnlMnuMovement.SetLeftAndRight(p1,(pnlMenuBtns.Width / 2))"[pageMenu2/General script]
views.get("pnlmnumovement").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlmnumovement").vw.setWidth((int)(((views.get("pnlmenubtns").vw.getWidth())/2d) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 98;BA.debugLine="pnlMnuMovement.SetTopAndBottom(p1,pnlMenuBtns.Height / 2 - (p1))"[pageMenu2/General script]
views.get("pnlmnumovement").vw.setTop((int)(Double.parseDouble(_p1)));
views.get("pnlmnumovement").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())/2d-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 99;BA.debugLine="pnlMnuFiles.SetLeftAndRight(pnlMnuMovement.Right + p1,pnlMenuBtns.Width - (p1))"[pageMenu2/General script]
views.get("pnlmnufiles").vw.setLeft((int)((views.get("pnlmnumovement").vw.getLeft() + views.get("pnlmnumovement").vw.getWidth())+Double.parseDouble(_p1)));
views.get("pnlmnufiles").vw.setWidth((int)((views.get("pnlmenubtns").vw.getWidth())-(Double.parseDouble(_p1)) - ((views.get("pnlmnumovement").vw.getLeft() + views.get("pnlmnumovement").vw.getWidth())+Double.parseDouble(_p1))));
//BA.debugLineNum = 100;BA.debugLine="pnlMnuFiles.SetTopAndBottom(p1,pnlMenuBtns.Height / 2 - (p1))"[pageMenu2/General script]
views.get("pnlmnufiles").vw.setTop((int)(Double.parseDouble(_p1)));
views.get("pnlmnufiles").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())/2d-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 101;BA.debugLine="pnlMnuPrinting.SetLeftAndRight(p1,pnlMenuBtns.Width - (p1))"[pageMenu2/General script]
views.get("pnlmnuprinting").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("pnlmnuprinting").vw.setWidth((int)((views.get("pnlmenubtns").vw.getWidth())-(Double.parseDouble(_p1)) - (Double.parseDouble(_p1))));
//BA.debugLineNum = 102;BA.debugLine="pnlMnuPrinting.SetTopAndBottom(pnlMnuFiles.Bottom + p1,pnlMenuBtns.Height - p1)"[pageMenu2/General script]
views.get("pnlmnuprinting").vw.setTop((int)((views.get("pnlmnufiles").vw.getTop() + views.get("pnlmnufiles").vw.getHeight())+Double.parseDouble(_p1)));
views.get("pnlmnuprinting").vw.setHeight((int)((views.get("pnlmenubtns").vw.getHeight())-Double.parseDouble(_p1) - ((views.get("pnlmnufiles").vw.getTop() + views.get("pnlmnufiles").vw.getHeight())+Double.parseDouble(_p1))));
//BA.debugLineNum = 104;BA.debugLine="End If"[pageMenu2/General script]
;};

}
}