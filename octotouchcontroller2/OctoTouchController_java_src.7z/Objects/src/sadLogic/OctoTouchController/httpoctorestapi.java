package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class httpoctorestapi extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.httpoctorestapi");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.httpoctorestapi.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"HttpOctoRestAP";
_mmodule = "HttpOctoRestAPI";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _deleterequest(String _deleteapicmd) throws Exception{
ResumableSub_DeleteRequest rsub = new ResumableSub_DeleteRequest(this,_deleteapicmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_DeleteRequest extends BA.ResumableSub {
public ResumableSub_DeleteRequest(sadLogic.OctoTouchController.httpoctorestapi parent,String _deleteapicmd) {
this.parent = parent;
this._deleteapicmd = _deleteapicmd;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _deleteapicmd;
String _insub = "";
String _sapi = "";
sadLogic.OctoTouchController.httpjob _job = null;
String _retstr = "";
String _uniquestr = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 256;BA.debugLine="Dim InSub As String = \"DeleteRequest\"";
_insub = "DeleteRequest";
 //BA.debugLineNum = 257;BA.debugLine="Dim sAPI As String = $\"http://${oc.OctoIp}:${oc.O";
_sapi = ("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+""+parent.__c.SmartStringFormatter("",(Object)(_deleteapicmd))+"?apikey="+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octokey /*String*/ ))+"");
 //BA.debugLineNum = 259;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 259;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 260;BA.debugLine="Dim retStr As String = \"\"";
_retstr = "";
 //BA.debugLineNum = 262;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 263;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As(";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 264;BA.debugLine="logMe.LogIt2($\"${UniqueStr}:-->${sAPI}<--:\"}\"$,m";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi))+"<--:\"}"),parent._mmodule,_insub);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 267;BA.debugLine="job.Delete(sAPI)";
_job._delete /*String*/ (_sapi);
 //BA.debugLineNum = 270;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 15;
return;
case 15:
//C
this.state = 5;
_job = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 271;BA.debugLine="If job.Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_job._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 272;BA.debugLine="retStr = job.GetString";
_retstr = _job._getstring /*String*/ ();
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 274;BA.debugLine="ProcessErrMsg(sAPI & CRLF &  job.ErrorMessage)";
parent._processerrmsg(_sapi+parent.__c.CRLF+_job._errormessage /*String*/ );
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 277;BA.debugLine="job.Release '--- free up resources";
_job._release /*String*/ ();
 //BA.debugLineNum = 279;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 11:
//if
this.state = 14;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 280;BA.debugLine="logMe.LogIt2( $\"${UniqueStr}:-->${sAPI}\"$,mModul";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi))+""),parent._mmodule,_insub);
 if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 283;BA.debugLine="Return retStr";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_retstr));return;};
 //BA.debugLineNum = 285;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(sadLogic.OctoTouchController.httpjob _job) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _download_andsavefile(String _link,String _filename) throws Exception{
ResumableSub_Download_AndSaveFile rsub = new ResumableSub_Download_AndSaveFile(this,_link,_filename);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Download_AndSaveFile extends BA.ResumableSub {
public ResumableSub_Download_AndSaveFile(sadLogic.OctoTouchController.httpoctorestapi parent,String _link,String _filename) {
this.parent = parent;
this._link = _link;
this._filename = _filename;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _link;
String _filename;
String _insub = "";
sadLogic.OctoTouchController.httpjob _j = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _oo = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 201;BA.debugLine="Dim InSub As String = \"Download_AndSaveFile\"";
_insub = "Download_AndSaveFile";
 //BA.debugLineNum = 203;BA.debugLine="If Link.Length = 0 Then";
if (true) break;

case 1:
//if
this.state = 10;
if (_link.length()==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 204;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"Thum";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Thumbnail path is empty",parent._mmodule,_insub);
if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 205;BA.debugLine="Return Null";
if (true) {
parent.__c.ReturnFromResumableSub(this,parent.__c.Null);return;};
 if (true) break;
;
 //BA.debugLineNum = 208;BA.debugLine="If fileName.Length <> 0 Then fileHelpers.SafeKill";

case 10:
//if
this.state = 15;
if (_filename.length()!=0) { 
this.state = 12;
;}if (true) break;

case 12:
//C
this.state = 15;
parent._filehelpers._safekill /*String*/ (parent.getActivityBA(),_filename);
if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 210;BA.debugLine="Dim j As HttpJob :	j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 210;BA.debugLine="Dim j As HttpJob :	j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 211;BA.debugLine="Try";
if (true) break;

case 16:
//try
this.state = 27;
this.catchState = 20;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 27;
this.catchState = 20;
 //BA.debugLineNum = 213;BA.debugLine="j.Download(Link)";
_j._download /*String*/ (_link);
 if (true) break;

case 20:
//C
this.state = 21;
this.catchState = 0;
 //BA.debugLineNum = 217;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(LastE";
if (true) break;

case 21:
//if
this.state = 26;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 23;
;}if (true) break;

case 23:
//C
this.state = 26;
parent._logme._logit2 /*String*/ (parent.getActivityBA(),BA.ObjectToString(parent.__c.LastException(parent.getActivityBA())),parent._mmodule,_insub);
if (true) break;

case 26:
//C
this.state = 27;
;
 if (true) break;
if (true) break;

case 27:
//C
this.state = 28;
this.catchState = 0;
;
 //BA.debugLineNum = 220;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 46;
return;
case 46:
//C
this.state = 28;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 222;BA.debugLine="Try";
if (true) break;

case 28:
//try
this.state = 45;
this.catchState = 38;
this.state = 30;
if (true) break;

case 30:
//C
this.state = 31;
this.catchState = 38;
 //BA.debugLineNum = 224;BA.debugLine="If j.Success Then";
if (true) break;

case 31:
//if
this.state = 36;
if (_j._success /*boolean*/ ) { 
this.state = 33;
}else {
this.state = 35;
}if (true) break;

case 33:
//C
this.state = 36;
 //BA.debugLineNum = 226;BA.debugLine="Dim oo As B4XBitmap = j.GetBitmap";
_oo = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_oo = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(_j._getbitmap /*anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper*/ ().getObject()));
 //BA.debugLineNum = 228;BA.debugLine="Dim Out As OutputStream '--- write it out";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 229;BA.debugLine="Out = File.OpenOutput(xui.DefaultFolder, fileNa";
_out = parent.__c.File.OpenOutput(parent._xui.getDefaultFolder(),_filename,parent.__c.False);
 //BA.debugLineNum = 230;BA.debugLine="oo.WriteToStream(Out, 100, \"PNG\")";
_oo.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"PNG"));
 //BA.debugLineNum = 231;BA.debugLine="Out.Close";
_out.Close();
 if (true) break;

case 35:
//C
this.state = 36;
 //BA.debugLineNum = 234;BA.debugLine="logMe.LogIt2(\"failed to dload thumbnail: \" & j.";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"failed to dload thumbnail: "+_j._errormessage /*String*/ ,parent._mmodule,_insub);
 if (true) break;

case 36:
//C
this.state = 45;
;
 if (true) break;

case 38:
//C
this.state = 39;
this.catchState = 0;
 //BA.debugLineNum = 238;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(LastE";
if (true) break;

case 39:
//if
this.state = 44;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 41;
;}if (true) break;

case 41:
//C
this.state = 44;
parent._logme._logit2 /*String*/ (parent.getActivityBA(),BA.ObjectToString(parent.__c.LastException(parent.getActivityBA())),parent._mmodule,_insub);
if (true) break;

case 44:
//C
this.state = 45;
;
 if (true) break;
if (true) break;

case 45:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 242;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 243;BA.debugLine="Return Null";
if (true) {
parent.__c.ReturnFromResumableSub(this,parent.__c.Null);return;};
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _downloadthumbnailandshow(String _link,sadLogic.OctoTouchController.b4ximageview _iv,String _filename) throws Exception{
ResumableSub_DownloadThumbnailAndShow rsub = new ResumableSub_DownloadThumbnailAndShow(this,_link,_iv,_filename);
rsub.resume(ba, null);
}
public static class ResumableSub_DownloadThumbnailAndShow extends BA.ResumableSub {
public ResumableSub_DownloadThumbnailAndShow(sadLogic.OctoTouchController.httpoctorestapi parent,String _link,sadLogic.OctoTouchController.b4ximageview _iv,String _filename) {
this.parent = parent;
this._link = _link;
this._iv = _iv;
this._filename = _filename;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _link;
sadLogic.OctoTouchController.b4ximageview _iv;
String _filename;
String _insub = "";
sadLogic.OctoTouchController.httpjob _j = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 155;BA.debugLine="Dim InSub As String = \"DownloadThumbnailAndShow\"";
_insub = "DownloadThumbnailAndShow";
 //BA.debugLineNum = 159;BA.debugLine="If Link.Length = 0 Then";
if (true) break;

case 1:
//if
this.state = 10;
if (_link.length()==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 160;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(\"Thum";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Thumbnail path is empty",parent._mmodule,_insub);
if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 161;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 164;BA.debugLine="If fileName.Length <> 0 Then fileHelpers.SafeKill";

case 10:
//if
this.state = 15;
if (_filename.length()!=0) { 
this.state = 12;
;}if (true) break;

case 12:
//C
this.state = 15;
parent._filehelpers._safekill /*String*/ (parent.getActivityBA(),_filename);
if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 166;BA.debugLine="Dim j As HttpJob :	j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 166;BA.debugLine="Dim j As HttpJob :	j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 167;BA.debugLine="j.Download(Link)";
_j._download /*String*/ (_link);
 //BA.debugLineNum = 170;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 36;
return;
case 36:
//C
this.state = 16;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 172;BA.debugLine="Try";
if (true) break;

case 16:
//try
this.state = 35;
this.catchState = 28;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 19;
this.catchState = 28;
 //BA.debugLineNum = 174;BA.debugLine="If j.Success Then";
if (true) break;

case 19:
//if
this.state = 26;
if (_j._success /*boolean*/ ) { 
this.state = 21;
}if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 176;BA.debugLine="iv.Bitmap =  j.GetBitmap";
_iv._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(_j._getbitmap /*anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper*/ ().getObject())));
 //BA.debugLineNum = 177;BA.debugLine="If fileName.Length <> 0 Then '--- write out fil";
if (true) break;

case 22:
//if
this.state = 25;
if (_filename.length()!=0) { 
this.state = 24;
}if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 179;BA.debugLine="Dim Out As OutputStream '--- write it out";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 180;BA.debugLine="Out = File.OpenOutput(xui.DefaultFolder, fileN";
_out = parent.__c.File.OpenOutput(parent._xui.getDefaultFolder(),_filename,parent.__c.False);
 //BA.debugLineNum = 181;BA.debugLine="iv.Bitmap.WriteToStream(Out, 100, \"PNG\")";
_iv._getbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ().WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"PNG"));
 //BA.debugLineNum = 182;BA.debugLine="Out.Close";
_out.Close();
 //BA.debugLineNum = 183;BA.debugLine="Log(\"DownloadThumbnailAndShow-dloading: \" & fi";
parent.__c.LogImpl("33226782","DownloadThumbnailAndShow-dloading: "+_filename,0);
 if (true) break;

case 25:
//C
this.state = 26;
;
 if (true) break;

case 26:
//C
this.state = 35;
;
 if (true) break;

case 28:
//C
this.state = 29;
this.catchState = 0;
 //BA.debugLineNum = 190;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt2(LastE";
if (true) break;

case 29:
//if
this.state = 34;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 31;
;}if (true) break;

case 31:
//C
this.state = 34;
parent._logme._logit2 /*String*/ (parent.getActivityBA(),BA.ObjectToString(parent.__c.LastException(parent.getActivityBA())),parent._mmodule,_insub);
if (true) break;

case 34:
//C
this.state = 35;
;
 if (true) break;
if (true) break;

case 35:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 194;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _postrequest(String _postapicmd) throws Exception{
ResumableSub_PostRequest rsub = new ResumableSub_PostRequest(this,_postapicmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_PostRequest extends BA.ResumableSub {
public ResumableSub_PostRequest(sadLogic.OctoTouchController.httpoctorestapi parent,String _postapicmd) {
this.parent = parent;
this._postapicmd = _postapicmd;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _postapicmd;
String _restapi = "";
String _jsondatamsg = "";
String _endpoint = "";
String _r = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 97;BA.debugLine="Dim restAPI, JsonDataMsg As String";
_restapi = "";
_jsondatamsg = "";
 //BA.debugLineNum = 98;BA.debugLine="restAPI = Regex.Split(\"!!\",PostApiCmd)(0)";
_restapi = parent.__c.Regex.Split("!!",_postapicmd)[(int) (0)];
 //BA.debugLineNum = 99;BA.debugLine="JsonDataMsg = Regex.Split(\"!!\",PostApiCmd)(1)";
_jsondatamsg = parent.__c.Regex.Split("!!",_postapicmd)[(int) (1)];
 //BA.debugLineNum = 100;BA.debugLine="Dim EndPoint As String = $\"http://${oc.OctoIp}:${";
_endpoint = ("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+""+parent.__c.SmartStringFormatter("",(Object)(_restapi))+"?apikey="+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octokey /*String*/ ))+"");
 //BA.debugLineNum = 101;BA.debugLine="Wait For (PostRequest2(EndPoint,JsonDataMsg)) Com";
parent.__c.WaitFor("complete", ba, this, parent._postrequest2(_endpoint,_jsondatamsg));
this.state = 1;
return;
case 1:
//C
this.state = -1;
_r = (String) result[0];
;
 //BA.debugLineNum = 102;BA.debugLine="Return r";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_r));return;};
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _r) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _postrequest2(String _endpoint,String _jsondatamsg) throws Exception{
ResumableSub_PostRequest2 rsub = new ResumableSub_PostRequest2(this,_endpoint,_jsondatamsg);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_PostRequest2 extends BA.ResumableSub {
public ResumableSub_PostRequest2(sadLogic.OctoTouchController.httpoctorestapi parent,String _endpoint,String _jsondatamsg) {
this.parent = parent;
this._endpoint = _endpoint;
this._jsondatamsg = _jsondatamsg;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _endpoint;
String _jsondatamsg;
sadLogic.OctoTouchController.httpjob _job = null;
String _retstr = "";
String _uniquestr = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 109;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 109;BA.debugLine="Dim job As HttpJob : job.Initialize(\"\", Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 110;BA.debugLine="Dim retStr As String = \"\"";
_retstr = "";
 //BA.debugLineNum = 112;BA.debugLine="If config.logREST_API  Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 113;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As(";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 114;BA.debugLine="logMe.LogIt($\"${UniqueStr}:-->${EndPoint & CRLF";
parent._logme._logit /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_endpoint+parent.__c.CRLF+_jsondatamsg+"<--:"))+""),parent._mmodule);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 117;BA.debugLine="job.PostString(EndPoint,JsonDataMsg)";
_job._poststring /*String*/ (_endpoint,_jsondatamsg);
 //BA.debugLineNum = 118;BA.debugLine="If JsonDataMsg = \"\" Then";
if (true) break;

case 5:
//if
this.state = 10;
if ((_jsondatamsg).equals("")) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 119;BA.debugLine="job.GetRequest.SetContentType(\"text/plain\")";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("text/plain");
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 121;BA.debugLine="job.GetRequest.SetContentType(\"application/json\"";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/json");
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 124;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 24;
return;
case 24:
//C
this.state = 11;
_job = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 125;BA.debugLine="If job.Success Then";
if (true) break;

case 11:
//if
this.state = 16;
if (_job._success /*boolean*/ ) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 126;BA.debugLine="retStr = job.GetString";
_retstr = _job._getstring /*String*/ ();
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 128;BA.debugLine="ProcessErrMsg( EndPoint & CRLF & JsonDataMsg & C";
parent._processerrmsg(_endpoint+parent.__c.CRLF+_jsondatamsg+parent.__c.CRLF+_job._errormessage /*String*/ );
 if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 131;BA.debugLine="job.Release '--- free up resources";
_job._release /*String*/ ();
 //BA.debugLineNum = 133;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 17:
//if
this.state = 20;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 19;
}if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 134;BA.debugLine="logMe.LogIt( $\"${UniqueStr}:-->${EndPoint}\"$,mMo";
parent._logme._logit /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_endpoint))+""),parent._mmodule);
 if (true) break;
;
 //BA.debugLineNum = 137;BA.debugLine="If EndPoint.Contains(oc.cCMD_PRINT) Or EndPoint.C";

case 20:
//if
this.state = 23;
if (_endpoint.contains(parent._oc._ccmd_print /*String*/ ) || _endpoint.contains(parent._oc._ccmd_cancel /*String*/ )) { 
this.state = 22;
}if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 139;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Se";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Set_ScreenTmr",(int) (10000));
 if (true) break;

case 23:
//C
this.state = -1;
;
 //BA.debugLineNum = 142;BA.debugLine="Return retStr";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_retstr));return;};
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _processerrmsg(String _msg) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Private Sub ProcessErrMsg(msg As String)";
 //BA.debugLineNum = 34;BA.debugLine="logMe.logit(\"(ProcessErrMsg)RestAPI ERR --> \" & m";
_logme._logit /*String*/ (getActivityBA(),"(ProcessErrMsg)RestAPI ERR --> "+_msg,_mmodule);
 //BA.debugLineNum = 35;BA.debugLine="msg = msg.ToLowerCase";
_msg = _msg.toLowerCase();
 //BA.debugLineNum = 37;BA.debugLine="If msg.Contains(\"ed to connect t\") Or msg.Contain";
if (_msg.contains("ed to connect t") || _msg.contains("ockettimeou") || _msg.contains("lid or inco")) { 
 //BA.debugLineNum = 42;BA.debugLine="oc.ResetAllOctoVars";
_oc._resetalloctovars /*String*/ (getActivityBA());
 //BA.debugLineNum = 43;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"CallSetupErro";
__c.CallSubDelayed2(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())),"CallSetupErrorConnecting",(Object)(__c.False));
 }else if(_msg.contains("is not oper")) { 
 //BA.debugLineNum = 46;BA.debugLine="oc.ResetAllOctoVars";
_oc._resetalloctovars /*String*/ (getActivityBA());
 //BA.debugLineNum = 47;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"CallSetupErro";
__c.CallSubDelayed2(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())),"CallSetupErrorConnecting",(Object)(__c.True));
 };
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendrequestgetinfo(String _octconst) throws Exception{
ResumableSub_SendRequestGetInfo rsub = new ResumableSub_SendRequestGetInfo(this,_octconst);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendRequestGetInfo extends BA.ResumableSub {
public ResumableSub_SendRequestGetInfo(sadLogic.OctoTouchController.httpoctorestapi parent,String _octconst) {
this.parent = parent;
this._octconst = _octconst;
}
sadLogic.OctoTouchController.httpoctorestapi parent;
String _octconst;
String _insub = "";
String _sapi = "";
sadLogic.OctoTouchController.httpjob _j = null;
String _retstr = "";
String _uniquestr = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 60;BA.debugLine="Dim inSub As String = \"SendRequestGetInfo\"";
_insub = "SendRequestGetInfo";
 //BA.debugLineNum = 61;BA.debugLine="Dim sAPI As String = $\"http://${oc.OctoIp}:${oc.O";
_sapi = ("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+""+parent.__c.SmartStringFormatter("",(Object)(_octconst))+"?apikey="+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octokey /*String*/ ))+"");
 //BA.debugLineNum = 63;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 63;BA.debugLine="Dim j As HttpJob: j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 64;BA.debugLine="Dim retStr As String = \"\"";
_retstr = "";
 //BA.debugLineNum = 66;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 67;BA.debugLine="Dim UniqueStr As String = Rnd(100000,999999).As(";
_uniquestr = (BA.NumberToString(parent.__c.Rnd((int) (100000),(int) (999999))));
 //BA.debugLineNum = 68;BA.debugLine="logMe.LogIt2($\"${UniqueStr}:-->${sAPI}\"$,mModule";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi))+""),parent._mmodule,_insub);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 71;BA.debugLine="j.Download(sAPI)";
_j._download /*String*/ (_sapi);
 //BA.debugLineNum = 72;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 15;
return;
case 15:
//C
this.state = 5;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 73;BA.debugLine="If j.Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_j._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 74;BA.debugLine="retStr = j.GetString";
_retstr = _j._getstring /*String*/ ();
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 76;BA.debugLine="ProcessErrMsg( sAPI &  CRLF &  j.ErrorMessage)";
parent._processerrmsg(_sapi+parent.__c.CRLF+_j._errormessage /*String*/ );
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 79;BA.debugLine="j.Release '--- free up resources";
_j._release /*String*/ ();
 //BA.debugLineNum = 81;BA.debugLine="If config.logREST_API Then";
if (true) break;

case 11:
//if
this.state = 14;
if (parent._config._logrest_api /*boolean*/ ) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 82;BA.debugLine="logMe.LogIt2($\"${UniqueStr}:-->${sAPI}\"$,mModule";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),(""+parent.__c.SmartStringFormatter("",(Object)(_uniquestr))+":-->"+parent.__c.SmartStringFormatter("",(Object)(_sapi))+""),parent._mmodule,_insub);
 if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 85;BA.debugLine="Return retStr";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_retstr));return;};
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
