package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class objhelpers {
private static objhelpers mostCurrent = new objhelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4a.objects.collections.Map  _concatmaps(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map[] _maps) throws Exception{
anywheresoftware.b4a.objects.collections.Map _retmap = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
Object _k = null;
 //BA.debugLineNum = 81;BA.debugLine="Public Sub ConcatMaps(maps() As Map) As Map 'ignor";
 //BA.debugLineNum = 82;BA.debugLine="Dim retMap As Map : retMap.Initialize";
_retmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 82;BA.debugLine="Dim retMap As Map : retMap.Initialize";
_retmap.Initialize();
 //BA.debugLineNum = 83;BA.debugLine="For Each m As Map In maps";
{
final anywheresoftware.b4a.objects.collections.Map[] group3 = _maps;
final int groupLen3 = group3.length
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_m = group3[index3];
 //BA.debugLineNum = 84;BA.debugLine="For Each k As Object In m.Keys";
{
final anywheresoftware.b4a.BA.IterableList group4 = _m.Keys();
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_k = group4.Get(index4);
 //BA.debugLineNum = 85;BA.debugLine="retMap.Put(k, m.Get(k))";
_retmap.Put(_k,_m.Get(_k));
 }
};
 }
};
 //BA.debugLineNum = 88;BA.debugLine="Return retMap";
if (true) return _retmap;
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.Map  _copymap(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _original) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Public Sub CopyMap(original As Map) As Map 'ignore";
 //BA.debugLineNum = 77;BA.debugLine="Return CopyObject(original)";
if (true) return (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_copyobject(_ba,(Object)(_original.getObject()))));
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return null;
}
public static Object  _copyobject(anywheresoftware.b4a.BA _ba,Object _sourceobject) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _s = null;
 //BA.debugLineNum = 68;BA.debugLine="Public Sub CopyObject(SourceObject As Object) As O";
 //BA.debugLineNum = 72;BA.debugLine="Dim s As B4XSerializator";
_s = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 73;BA.debugLine="Return s.ConvertBytesToObject(s.ConvertObjectToBy";
if (true) return _s.ConvertBytesToObject(_s.ConvertObjectToBytes(_sourceobject));
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public static String  _list2json(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _gen = null;
 //BA.debugLineNum = 43;BA.debugLine="public Sub List2Json(lst As List) As String";
 //BA.debugLineNum = 45;BA.debugLine="Dim gen As JSONGenerator";
_gen = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 46;BA.debugLine="gen.Initialize2(lst)";
_gen.Initialize2(_lst);
 //BA.debugLineNum = 47;BA.debugLine="Return gen.ToString";
if (true) return _gen.ToString();
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public static String[]  _list2strarray(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
String[] _ret = null;
int _index = 0;
 //BA.debugLineNum = 25;BA.debugLine="Public Sub List2StrArray(lst As List) As String()";
 //BA.debugLineNum = 27;BA.debugLine="Dim ret(lst.Size) As String";
_ret = new String[_lst.getSize()];
java.util.Arrays.fill(_ret,"");
 //BA.debugLineNum = 28;BA.debugLine="For index=0 To lst.Size - 1";
{
final int step2 = 1;
final int limit2 = (int) (_lst.getSize()-1);
_index = (int) (0) ;
for (;_index <= limit2 ;_index = _index + step2 ) {
 //BA.debugLineNum = 29;BA.debugLine="ret(index) = lst.Get(index)";
_ret[_index] = BA.ObjectToString(_lst.Get(_index));
 }
};
 //BA.debugLineNum = 31;BA.debugLine="Return ret";
if (true) return _ret;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public static String  _map2disk2(anywheresoftware.b4a.BA _ba,String _folder,String _filename,anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Map2Disk2(folder As String, filename As";
 //BA.debugLineNum = 15;BA.debugLine="Dim ser As B4XSerializator '--- in the RandomAcce";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 16;BA.debugLine="File.WriteBytes(folder, filename, ser.ConvertObje";
anywheresoftware.b4a.keywords.Common.File.WriteBytes(_folder,_filename,_ser.ConvertObjectToBytes((Object)(_m.getObject())));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public static String  _map2json(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _gen = null;
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Map2Json(m As Map) As String";
 //BA.debugLineNum = 37;BA.debugLine="Dim gen As JSONGenerator";
_gen = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 38;BA.debugLine="gen.Initialize(m)";
_gen.Initialize(_m);
 //BA.debugLineNum = 39;BA.debugLine="Return gen.ToString";
if (true) return _gen.ToString();
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.collections.List  _map2list(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.Map _mymap,boolean _keylist) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
Object _item = null;
 //BA.debugLineNum = 53;BA.debugLine="public Sub Map2List(myMap As Map, KeyList As Boole";
 //BA.debugLineNum = 54;BA.debugLine="Dim lst As List : lst.Initialize";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 54;BA.debugLine="Dim lst As List : lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 55;BA.debugLine="If KeyList Then";
if (_keylist) { 
 //BA.debugLineNum = 56;BA.debugLine="For Each item As Object In myMap.Keys";
{
final anywheresoftware.b4a.BA.IterableList group4 = _mymap.Keys();
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_item = group4.Get(index4);
 //BA.debugLineNum = 57;BA.debugLine="lst.Add(item)";
_lst.Add(_item);
 }
};
 }else {
 //BA.debugLineNum = 60;BA.debugLine="For Each item As Object In myMap.Values";
{
final anywheresoftware.b4a.BA.IterableList group8 = _mymap.Values();
final int groupLen8 = group8.getSize()
;int index8 = 0;
;
for (; index8 < groupLen8;index8++){
_item = group8.Get(index8);
 //BA.debugLineNum = 61;BA.debugLine="lst.Add(item)";
_lst.Add(_item);
 }
};
 };
 //BA.debugLineNum = 64;BA.debugLine="Return lst";
if (true) return _lst;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.Map  _mapfromdisk2(anywheresoftware.b4a.BA _ba,String _folder,String _filename) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub MapFromDisk2(folder As String, filename";
 //BA.debugLineNum = 20;BA.debugLine="Dim ser As B4XSerializator '--- in the RandomAcce";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 21;BA.debugLine="Return ser.ConvertBytesToObject(File.ReadBytes(fo";
if (true) return (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_ser.ConvertBytesToObject(anywheresoftware.b4a.keywords.Common.File.ReadBytes(_folder,_filename))));
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"objHelper\" 'ig";
_mmodule = "objHelper";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
}
