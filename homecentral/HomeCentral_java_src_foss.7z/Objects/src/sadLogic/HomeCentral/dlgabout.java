package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgabout extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgabout");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgabout.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblabouttop = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public sadLogic.HomeCentral.lmb4ximageviewx _iv = null;
public sadLogic.HomeCentral.madewithlove _madewithlove1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbleula = null;
public anywheresoftware.b4a.objects.Timer _tmr = null;
public anywheresoftware.b4a.objects.CSBuilder _cs = null;
public boolean _elua_mode = false;
public de.donmanfred.CreditsRollViewWrapper _credits = null;
public int _creditsmax = 0;
public int _creditspos = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _buildliclabel() throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Private Sub BuildLicLabel";
 //BA.debugLineNum = 84;BA.debugLine="lblEULA.Initialize(\"license\")";
_lbleula.Initialize(ba,"license");
 //BA.debugLineNum = 85;BA.debugLine="lblEULA.TextSize = 20";
_lbleula.setTextSize((float) (20));
 //BA.debugLineNum = 86;BA.debugLine="dlg.Base.AddView(lblEULA,14dip,dlg.Base.Height -";
_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .AddView((android.view.View)(_lbleula.getObject()),__c.DipToCurrent((int) (14)),(int) (_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()-__c.DipToCurrent((int) (47))),(int) ((_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-_dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel).getWidth()-__c.DipToCurrent((int) (20)))),__c.DipToCurrent((int) (36)));
 //BA.debugLineNum = 88;BA.debugLine="lblEULA.Text = cs.Initialize.Underline.Color(clrT";
_lbleula.setText(BA.ObjectToCharSequence(_cs.Initialize().Underline().Color(_clrtheme._txtnormal /*int*/ ).Append(BA.ObjectToCharSequence("License")).PopAll().getObject()));
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 10;BA.debugLine="Private lblAboutTop As Label";
_lblabouttop = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 12;BA.debugLine="Private iv As lmB4XImageViewX";
_iv = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 13;BA.debugLine="Private MadeWithLove1 As MadeWithLove";
_madewithlove1 = new sadLogic.HomeCentral.madewithlove();
 //BA.debugLineNum = 14;BA.debugLine="Private lblEULA As Label";
_lbleula = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private tmr As Timer";
_tmr = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 16;BA.debugLine="Private cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 17;BA.debugLine="Private ELUA_Mode As Boolean = False";
_elua_mode = __c.False;
 //BA.debugLineNum = 19;BA.debugLine="Private credits As CreditsRollView";
_credits = new de.donmanfred.CreditsRollViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private creditsMax As Int = 30000, creditsPos As";
_creditsmax = (int) (30000);
_creditspos = (int) (0);
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 28;BA.debugLine="dlg.Close(XUI.DialogResponse_Cancel)";
_dlg._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public String  _initcredits() throws Exception{
String _ver = "";
 //BA.debugLineNum = 114;BA.debugLine="Private Sub InitCredits";
 //BA.debugLineNum = 116;BA.debugLine="Dim ver As String = \"HomeCentral™ V\" & Applicatio";
_ver = "HomeCentral™ V"+__c.Application.getVersionName();
 //BA.debugLineNum = 118;BA.debugLine="If ELUA_Mode Then";
if (_elua_mode) { 
 //BA.debugLineNum = 120;BA.debugLine="credits.TextSize = 20";
_credits.setTextSize((float) (20));
 //BA.debugLineNum = 121;BA.debugLine="credits.EndScrollMult = 1";
_credits.setEndScrollMult((float) (1));
 //BA.debugLineNum = 122;BA.debugLine="credits.Text = CRLF & CRLF & $\" Released under t";
_credits.setText(BA.ObjectToCharSequence(__c.CRLF+__c.CRLF+("\n"+"Released under the GNU AFFERO GENERAL PUBLIC LICENSE\n"+"Version 3, 19 November 2007\n"+"\n"+"This is free software. In a nutshell...\n"+"\n"+"When we speak of free software, we are referring to freedom, not price.  \n"+"Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things.\n"+" \n"+"See the complete text on the license in the folder where this software is installed or search the internet for:\n"+"'GNU AFFERO GENERAL PUBLIC LICENSE V3'\n"+"")));
 //BA.debugLineNum = 135;BA.debugLine="tmr.Initialize(\"timer\",30)";
_tmr.Initialize(ba,"timer",(long) (30));
 }else {
 //BA.debugLineNum = 138;BA.debugLine="credits.TextSize = 24";
_credits.setTextSize((float) (24));
 //BA.debugLineNum = 139;BA.debugLine="credits.EndScrollMult = 1";
_credits.setEndScrollMult((float) (1));
 //BA.debugLineNum = 141;BA.debugLine="credits.Text = CRLF & CRLF & ver & $\" 		 -------";
_credits.setText(BA.ObjectToCharSequence(__c.CRLF+__c.CRLF+_ver+("\n"+"		\n"+"---------------------------\n"+"\n"+"- Legal Crap -\n"+"(©)sadLogic 2015 - 2025\n"+"(©)eHomeCreations 2002 - 2015\n"+"(©)Humankind - Forever\n"+"\n"+"\n"+"- About - \n"+"A dedicated tablet application for your kitchen / home using older Android devices. \n"+"HomeCentral was created by a family for other families. It has been a work of love for over 20 years. \n"+"At this point though the kids are grown and gone and its time to just release this into the wild as FOSS.\n"+"\n"+"We sincerely hope you enjoy using it and welcome any and all feedback you can share with us.\n"+"\n"+"Thanks!\n"+"\n"+"- Programmers - \n"+"---------------------------\n"+"Steven De George SR\n"+"Steven De George JR\n"+"Bogdan De George\n"+"\n"+"\n"+"- Art Work -\n"+"--------------------------\n"+"Stacey (De George) Hafner\n"+"openclipart.org\n"+"  \n"+"  \n"+"- Thanks to - \n"+"--------------------------\n"+"b4a Language: Erel\n"+"b4a forum: klaus (Switzerland)\n"+"b4a forum: agraham (UK)\n"+"b4a forum: Alexander Stolte (Germany)\n"+"b4a forum: Informatix (France)\n"+"b4a forum: DonManfred (Germany)\n"+"b4a forum: Magma (Greece)\n"+"b4a forum: CableGuy (France)\n"+"b4a forum: thedesolatesoul (UK)\n"+"The b4x BOSS consortium :)\n"+"And many many many others...\n"+"\n"+"And my poor wife who puts up with me.\n"+"")));
 //BA.debugLineNum = 190;BA.debugLine="tmr.Initialize(\"timer\",50)";
_tmr.Initialize(ba,"timer",(long) (50));
 };
 //BA.debugLineNum = 193;BA.debugLine="creditsPos = 0";
_creditspos = (int) (0);
 //BA.debugLineNum = 195;BA.debugLine="tmr.Enabled = True";
_tmr.setEnabled(__c.True);
 //BA.debugLineNum = 198;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dialog) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Initialize(Dialog As B4XDialog)";
 //BA.debugLineNum = 25;BA.debugLine="dlg = Dialog";
_dlg = _dialog;
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _license_click() throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Private Sub license_Click";
 //BA.debugLineNum = 70;BA.debugLine="If lblEULA.Text.ToLowerCase.Contains(\"license\") T";
if (_lbleula.getText().toLowerCase().contains("license")) { 
 //BA.debugLineNum = 71;BA.debugLine="lblEULA.Text = cs.Initialize.Underline.Color(clr";
_lbleula.setText(BA.ObjectToCharSequence(_cs.Initialize().Underline().Color(_clrtheme._txtnormal /*int*/ ).Append(BA.ObjectToCharSequence("About")).PopAll().getObject()));
 //BA.debugLineNum = 72;BA.debugLine="ELUA_Mode = True";
_elua_mode = __c.True;
 //BA.debugLineNum = 73;BA.debugLine="InitCredits";
_initcredits();
 }else {
 //BA.debugLineNum = 75;BA.debugLine="lblEULA.Text = cs.Initialize.Underline.Color(clr";
_lbleula.setText(BA.ObjectToCharSequence(_cs.Initialize().Underline().Color(_clrtheme._txtnormal /*int*/ ).Append(BA.ObjectToCharSequence("License")).PopAll().getObject()));
 //BA.debugLineNum = 76;BA.debugLine="ELUA_Mode = False";
_elua_mode = __c.False;
 //BA.debugLineNum = 77;BA.debugLine="InitCredits";
_initcredits();
 };
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgabout parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgabout parent;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
anywheresoftware.b4a.objects.LabelWrapper _lbl = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _msg = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 34;BA.debugLine="dlg.Initialize((B4XPages.MainPage.Root))";
parent._dlg._initialize /*String*/ (ba,(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ));
 //BA.debugLineNum = 35;BA.debugLine="dlgHelper.Initialize(dlg)";
parent._dlghelper._initialize /*String*/ (ba,parent._dlg);
 //BA.debugLineNum = 37;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 38;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,430dip,400dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (430)),parent.__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 39;BA.debugLine="p.LoadLayout(\"dlgAbout\")";
_p.LoadLayout("dlgAbout",ba);
 //BA.debugLineNum = 41;BA.debugLine="iv.Bitmap = XUI.LoadBitmap(File.DirAssets,\"logo.p";
parent._iv._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"logo.png"));
 //BA.debugLineNum = 44;BA.debugLine="dlgHelper.ThemeDialogForm(\"About\")";
parent._dlghelper._themedialogform /*String*/ ((Object)("About"));
 //BA.debugLineNum = 45;BA.debugLine="Dim rs As ResumableSub = dlg.ShowCustom(p, \"\", \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dlg._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("OK"));
 //BA.debugLineNum = 46;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
parent._dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 49;BA.debugLine="lblAboutTop.TextSize = 18";
parent._lblabouttop.setTextSize((float) (18));
 //BA.debugLineNum = 50;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblAbout";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblabouttop.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 51;BA.debugLine="credits.TextColor = clrTheme.txtNormal";
parent._credits.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 52;BA.debugLine="InitCredits";
parent._initcredits();
 //BA.debugLineNum = 53;BA.debugLine="Dim lbl As Label = MadeWithLove1.mBase.GetView(0)";
_lbl = new anywheresoftware.b4a.objects.LabelWrapper();
_lbl = (anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._madewithlove1._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .GetView((int) (0)).getObject()));
 //BA.debugLineNum = 53;BA.debugLine="Dim lbl As Label = MadeWithLove1.mBase.GetView(0)";
_lbl.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 54;BA.debugLine="BuildLicLabel";
parent._buildliclabel();
 //BA.debugLineNum = 56;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 56;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 57;BA.debugLine="msg.Append(\"(©)sadLogic 2015-25\").Append(CRLF)";
_msg.Append("(©)sadLogic 2015-25").Append(parent.__c.CRLF);
 //BA.debugLineNum = 58;BA.debugLine="msg.Append(\"Kherson Ukraine!\").Append(CRLF)";
_msg.Append("Kherson Ukraine!").Append(parent.__c.CRLF);
 //BA.debugLineNum = 59;BA.debugLine="msg.Append(\"AGPL-3.0 license\")";
_msg.Append("AGPL-3.0 license");
 //BA.debugLineNum = 60;BA.debugLine="lblAboutTop.Text = msg.ToString";
parent._lblabouttop.setText(BA.ObjectToCharSequence(_msg.ToString()));
 //BA.debugLineNum = 62;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 63;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"ResetScrn_Sleep";
parent.__c.CallSubDelayed(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 64;BA.debugLine="tmr.Enabled = False";
parent._tmr.setEnabled(parent.__c.False);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _timer_tick() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Sub timer_Tick";
 //BA.debugLineNum = 94;BA.debugLine="If creditsPos < creditsMax Then";
if (_creditspos<_creditsmax) { 
 //BA.debugLineNum = 95;BA.debugLine="creditsPos = creditsPos +1";
_creditspos = (int) (_creditspos+1);
 };
 //BA.debugLineNum = 98;BA.debugLine="If (creditsPos/1000) >= 1 Then";
if ((_creditspos/(double)1000)>=1) { 
 //BA.debugLineNum = 99;BA.debugLine="tmr.Enabled = False";
_tmr.setEnabled(__c.False);
 //BA.debugLineNum = 100;BA.debugLine="creditsPos = 0";
_creditspos = (int) (0);
 //BA.debugLineNum = 101;BA.debugLine="InitCredits";
_initcredits();
 };
 //BA.debugLineNum = 103;BA.debugLine="credits.ScrollPosition = (creditsPos/1000)";
_credits.setScrollPosition((float) ((_creditspos/(double)1000)));
 //BA.debugLineNum = 104;BA.debugLine="credits.DistanceFromText = 50dip";
_credits.setDistanceFromText((float) (__c.DipToCurrent((int) (50))));
 //BA.debugLineNum = 105;BA.debugLine="credits.Angle = 20";
_credits.setAngle((float) (20));
 //BA.debugLineNum = 108;BA.debugLine="credits.TextSize = 40";
_credits.setTextSize((float) (40));
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
