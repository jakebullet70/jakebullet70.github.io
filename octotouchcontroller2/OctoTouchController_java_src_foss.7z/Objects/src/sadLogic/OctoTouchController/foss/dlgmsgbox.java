package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgmsgbox extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgmsgbox");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgmsgbox.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public float _mheight = 0f;
public float _mwidth = 0f;
public boolean _mputnegativebtn2left = false;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lbltxt = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _basepnl = null;
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public sadLogic.OctoTouchController.foss.lmb4ximageviewx _lmb4ximageviewx1 = null;
public String _mkvstr = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbg = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Private const mModule As String = \"dlgMsgBox\"' 'i";
_mmodule = "dlgMsgBox";
 //BA.debugLineNum = 11;BA.debugLine="Private mMainObj As B4XView";
_mmainobj = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 14;BA.debugLine="Private mHeight As Float";
_mheight = 0f;
 //BA.debugLineNum = 15;BA.debugLine="Private mWidth As Float";
_mwidth = 0f;
 //BA.debugLineNum = 16;BA.debugLine="Private mPutNegativeBtn2Left As Boolean";
_mputnegativebtn2left = false;
 //BA.debugLineNum = 18;BA.debugLine="Public lblTxt As AutoTextSizeLabel";
_lbltxt = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 20;BA.debugLine="Private BasePnl As B4XView";
_basepnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 23;BA.debugLine="Private lmB4XImageViewX1 As lmB4XImageViewX";
_lmb4ximageviewx1 = new sadLogic.OctoTouchController.foss.lmb4ximageviewx();
 //BA.debugLineNum = 24;BA.debugLine="Private mKvStr As String";
_mkvstr = "";
 //BA.debugLineNum = 26;BA.debugLine="Private pnlBG As B4XView";
_pnlbg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 87;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _createdonotshowcheckbox() throws Exception{
anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chk = null;
 //BA.debugLineNum = 90;BA.debugLine="Private Sub CreateDoNotShowCheckbox";
 //BA.debugLineNum = 91;BA.debugLine="Dim chk As CheckBox : chk.Initialize(\"DoNotShow\")";
_chk = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
 //BA.debugLineNum = 91;BA.debugLine="Dim chk As CheckBox : chk.Initialize(\"DoNotShow\")";
_chk.Initialize(ba,"DoNotShow");
 //BA.debugLineNum = 92;BA.debugLine="chk.Text = \" Do not show again\"";
_chk.setText(BA.ObjectToCharSequence(" Do not show again"));
 //BA.debugLineNum = 93;BA.debugLine="chk.TextColor = clrTheme.txtNormal";
_chk.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 95;BA.debugLine="If guiHelpers.gScreenSizeAprox < 4.5 Then";
if (_guihelpers._gscreensizeaprox /*double*/ <4.5) { 
 //BA.debugLineNum = 96;BA.debugLine="chk.TextSize = 16";
_chk.setTextSize((float) (16));
 }else {
 //BA.debugLineNum = 98;BA.debugLine="chk.TextSize = 18";
_chk.setTextSize((float) (18));
 };
 //BA.debugLineNum = 101;BA.debugLine="guiHelpers.SetCBDrawable(chk, clrTheme.txtNormal,";
_guihelpers._setcbdrawable /*String*/ (ba,_chk,_clrtheme._txtnormal /*int*/ ,(int) (1),_clrtheme._txtnormal /*int*/ ,BA.ObjectToString(__c.Chr((int) (8730))),__c.Colors.LightGray,__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 102;BA.debugLine="mDialog.Base.AddView(chk,10dip,mDialog.Base.Heigh";
_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .AddView((android.view.View)(_chk.getObject()),__c.DipToCurrent((int) (10)),(int) (_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()-__c.DipToCurrent((int) (50))),(int) ((_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-_mdialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel).getWidth()-__c.DipToCurrent((int) (6)))),__c.DipToCurrent((int) (36)));
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public String  _donotshow_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Private Sub DoNotShow_CheckedChange(Checked As Boo";
 //BA.debugLineNum = 107;BA.debugLine="Main.kvs.Put(mKvStr,Checked.As(String))";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_mkvstr,(Object)((BA.ObjectToString(_checked))));
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _parentobj,String _title,float _width,float _height,boolean _putnegativebtn2left) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 31;BA.debugLine="Public Sub Initialize(parentObj As B4XView, title";
 //BA.debugLineNum = 33;BA.debugLine="mMainObj = parentObj";
_mmainobj = _parentobj;
 //BA.debugLineNum = 34;BA.debugLine="mTitle   = title";
_mtitle = _title;
 //BA.debugLineNum = 35;BA.debugLine="mHeight  = height";
_mheight = _height;
 //BA.debugLineNum = 36;BA.debugLine="mWidth   = width";
_mwidth = _width;
 //BA.debugLineNum = 37;BA.debugLine="mPutNegativeBtn2Left = PutNegativeBtn2Left";
_mputnegativebtn2left = _putnegativebtn2left;
 //BA.debugLineNum = 39;BA.debugLine="BasePnl = xui.CreatePanel(\"\")";
_basepnl = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 40;BA.debugLine="BasePnl.SetLayoutAnimated(0, 0, 0, mWidth, mHeigh";
_basepnl.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_mwidth),(int) (_mheight));
 //BA.debugLineNum = 41;BA.debugLine="BasePnl.LoadLayout(\"viewMsgBox\")";
_basepnl.LoadLayout("viewMsgBox",ba);
 //BA.debugLineNum = 43;BA.debugLine="lblTxt.TextColor = clrTheme.txtNormal";
_lbltxt._settextcolor /*int*/ (_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 44;BA.debugLine="pnlBG.Color = clrTheme.Background";
_pnlbg.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _setasoptionalmsgbox(String _kvkey) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Public Sub SetAsOptionalMsgBox(kvKey As String)";
 //BA.debugLineNum = 49;BA.debugLine="mKvStr = kvKey";
_mkvstr = _kvkey;
 //BA.debugLineNum = 50;BA.debugLine="Main.kvs.Put(mKvStr,False.As(String))";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_mkvstr,(Object)((BA.ObjectToString(__c.False))));
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _show(String _txt,String _icon_file,String _btn1,String _btn2,String _btn3) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_txt,_icon_file,_btn1,_btn2,_btn3);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgmsgbox parent,String _txt,String _icon_file,String _btn1,String _btn2,String _btn3) {
this.parent = parent;
this._txt = _txt;
this._icon_file = _icon_file;
this._btn1 = _btn1;
this._btn2 = _btn2;
this._btn3 = _btn3;
}
sadLogic.OctoTouchController.foss.dlgmsgbox parent;
String _txt;
String _icon_file;
String _btn1;
String _btn2;
String _btn3;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 66;BA.debugLine="mDialog.Initialize(mMainObj)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj);
 //BA.debugLineNum = 67;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 68;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 70;BA.debugLine="lblTxt.Text = txt";
parent._lbltxt._settext /*Object*/ ((Object)(_txt));
 //BA.debugLineNum = 71;BA.debugLine="lmB4XImageViewX1.Load(File.DirAssets, icon_file)";
parent._lmb4ximageviewx1._load /*String*/ (parent.__c.File.getDirAssets(),_icon_file);
 //BA.debugLineNum = 72;BA.debugLine="lmB4XImageViewX1.SetBitmap(guiHelpers.ChangeColor";
parent._lmb4ximageviewx1._setbitmap /*String*/ (parent._guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,parent._lmb4ximageviewx1._getbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (),parent._clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 74;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 75;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(BaseP";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._basepnl,(Object)(_btn1),(Object)(_btn2),(Object)(_btn3));
 //BA.debugLineNum = 76;BA.debugLine="ThemeInputDialogBtnsResize2(mDialog,mWidth)";
parent._themeinputdialogbtnsresize2(parent._mdialog,parent._mwidth);
 //BA.debugLineNum = 77;BA.debugLine="dlgHelper.AnimateDialog(\"top\")";
_dlghelper._animatedialog /*String*/ ("top");
 //BA.debugLineNum = 79;BA.debugLine="If mKvStr <> \"\" Then CreateDoNotShowCheckbox";
if (true) break;

case 1:
//if
this.state = 6;
if ((parent._mkvstr).equals("") == false) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._createdonotshowcheckbox();
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 81;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 7;
return;
case 7:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 82;BA.debugLine="Return Result";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _themeinputdialogbtnsresize2(sadLogic.OctoTouchController.foss.b4xdialog _dlg,float _w) throws Exception{
int _numofbtns = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _btncancel = null;
anywheresoftware.b4a.objects.B4XViewWrapper _btnyes = null;
anywheresoftware.b4a.objects.B4XViewWrapper _btnno = null;
 //BA.debugLineNum = 111;BA.debugLine="Private Sub ThemeInputDialogBtnsResize2(dlg As B4X";
 //BA.debugLineNum = 113;BA.debugLine="Dim numOfBtns As Int = 0";
_numofbtns = (int) (0);
 //BA.debugLineNum = 114;BA.debugLine="Try '--- reskin button, if it does not exist then";
try { //BA.debugLineNum = 115;BA.debugLine="Dim btnCancel As B4XView = dlg.GetButton(xui.Dia";
_btncancel = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btncancel = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 116;BA.debugLine="If btnCancel <> Null Then";
if (_btncancel!= null) { 
 //BA.debugLineNum = 117;BA.debugLine="numOfBtns = numOfBtns + 1";
_numofbtns = (int) (_numofbtns+1);
 //BA.debugLineNum = 118;BA.debugLine="btnCancel.Font = xui.CreateDefaultFont(NumberFo";
_btncancel.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_btncancel.getFont().getSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 119;BA.debugLine="btnCancel.Width = btnCancel.Width + 20dip";
_btncancel.setWidth((int) (_btncancel.getWidth()+__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 120;BA.debugLine="btnCancel.Left = w - btnCancel.Width - 5dip";
_btncancel.setLeft((int) (_w-_btncancel.getWidth()-__c.DipToCurrent((int) (5))));
 //BA.debugLineNum = 121;BA.debugLine="btnCancel.Height = btnCancel.Height - 4dip '---";
_btncancel.setHeight((int) (_btncancel.getHeight()-__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 122;BA.debugLine="btnCancel.Top = btnCancel.Top + 4dip";
_btncancel.setTop((int) (_btncancel.getTop()+__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 123;BA.debugLine="btnCancel.SetColorAndBorder(xui.Color_Transpare";
_btncancel.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 };
 } 
       catch (Exception e14) {
			ba.setLastException(e14); };
 //BA.debugLineNum = 131;BA.debugLine="Try '--- reskin button, if it does not exist then";
try { //BA.debugLineNum = 132;BA.debugLine="Dim btnYes As B4XView = dlg.GetButton(xui.Dialog";
_btnyes = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnyes = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive);
 //BA.debugLineNum = 134;BA.debugLine="If btnYes <> Null Then";
if (_btnyes!= null) { 
 //BA.debugLineNum = 135;BA.debugLine="numOfBtns = numOfBtns + 1";
_numofbtns = (int) (_numofbtns+1);
 //BA.debugLineNum = 136;BA.debugLine="btnYes.Font = xui.CreateDefaultFont(NumberForma";
_btnyes.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_btnyes.getFont().getSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 137;BA.debugLine="btnYes.Width = btnYes.Width + 20dip";
_btnyes.setWidth((int) (_btnyes.getWidth()+__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 138;BA.debugLine="btnYes.Left = w - (btnYes.width * numOfBtns) -";
_btnyes.setLeft((int) (_w-(_btnyes.getWidth()*_numofbtns)-(__c.DipToCurrent((int) (5))*_numofbtns)));
 //BA.debugLineNum = 139;BA.debugLine="btnYes.Height = btnYes.Height - 4dip '--- resiz";
_btnyes.setHeight((int) (_btnyes.getHeight()-__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 140;BA.debugLine="btnYes.Top = btnYes.Top + 4dip";
_btnyes.setTop((int) (_btnyes.getTop()+__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 141;BA.debugLine="btnYes.SetColorAndBorder(xui.Color_Transparent,";
_btnyes.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 };
 } 
       catch (Exception e27) {
			ba.setLastException(e27); };
 //BA.debugLineNum = 149;BA.debugLine="Try '--- reskin button, if it does not exist then";
try { //BA.debugLineNum = 150;BA.debugLine="Dim btnNo As B4XView = dlg.GetButton(xui.DialogR";
_btnno = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnno = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Negative);
 //BA.debugLineNum = 152;BA.debugLine="If btnNo <> Null Then";
if (_btnno!= null) { 
 //BA.debugLineNum = 153;BA.debugLine="numOfBtns = numOfBtns + 1";
_numofbtns = (int) (_numofbtns+1);
 //BA.debugLineNum = 154;BA.debugLine="btnNo.Font = xui.CreateDefaultFont(NumberFormat";
_btnno.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(_btnno.getFont().getSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 155;BA.debugLine="btnNo.Width = btnNo.Width + 20dip";
_btnno.setWidth((int) (_btnno.getWidth()+__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 156;BA.debugLine="btnNo.Height = btnNo.Height - 4dip '--- resize";
_btnno.setHeight((int) (_btnno.getHeight()-__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 157;BA.debugLine="btnNo.Top = btnNo.Top + 4dip";
_btnno.setTop((int) (_btnno.getTop()+__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 158;BA.debugLine="If mPutNegativeBtn2Left Then";
if (_mputnegativebtn2left) { 
 //BA.debugLineNum = 159;BA.debugLine="btnNo.Left = 10dip";
_btnno.setLeft(__c.DipToCurrent((int) (10)));
 }else {
 //BA.debugLineNum = 161;BA.debugLine="btnNo.Left = w - (btnNo.width * numOfBtns) - (";
_btnno.setLeft((int) (_w-(_btnno.getWidth()*_numofbtns)-(__c.DipToCurrent((int) (5))*_numofbtns)));
 };
 //BA.debugLineNum = 163;BA.debugLine="btnNo.SetColorAndBorder(xui.Color_Transparent,2";
_btnno.SetColorAndBorder(_xui.Color_Transparent,__c.DipToCurrent((int) (2)),_clrtheme._txtnormal /*int*/ ,__c.DipToCurrent((int) (8)));
 };
 } 
       catch (Exception e44) {
			ba.setLastException(e44); };
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
