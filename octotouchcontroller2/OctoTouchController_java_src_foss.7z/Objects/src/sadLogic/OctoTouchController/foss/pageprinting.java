package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pageprinting extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.pageprinting");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.pageprinting.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mpnlmain = null;
public String _mcallbackevent = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public String _mdisplayedfilename = "";
public int _mnumoftries4thumbnail = 0;
public anywheresoftware.b4a.objects.ButtonWrapper _btncancel = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpause = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnprint = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblfilename = null;
public sadLogic.OctoTouchController.foss.circularprogressbar _circularprogressbar1 = null;
public Object _mtext4printbtn = null;
public Object _mtext4resumebtn = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblprintstats1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblprintstats3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblprintstats2 = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblprintstatstmp = null;
public sadLogic.OctoTouchController.foss.lmb4ximageviewx _ivpreviewlg = null;
public String _mtmptemps = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlheating = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtns = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbgbed = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbgtool = null;
public sadLogic.OctoTouchController.foss.lmb4ximageviewx _ivbed = null;
public sadLogic.OctoTouchController.foss.lmb4ximageviewx _ivtool = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltooltemp1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblbedtemp1 = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public void  _btnaction_click() throws Exception{
ResumableSub_btnAction_Click rsub = new ResumableSub_btnAction_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnAction_Click extends BA.ResumableSub {
public ResumableSub_btnAction_Click(sadLogic.OctoTouchController.foss.pageprinting parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pageprinting parent;
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
sadLogic.OctoTouchController.foss.dlgmsgbox2 _mb2 = null;
int _res = 0;
float _w = 0f;
sadLogic.OctoTouchController.foss.dlgmsgbox _mb = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 270;BA.debugLine="Dim o As B4XView : o = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 270;BA.debugLine="Dim o As B4XView : o = Sender";
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 272;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 274;BA.debugLine="If oc.isConnected = False Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._oc._isconnected /*boolean*/ ==parent.__c.False) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 276;BA.debugLine="Update_Printer_Btns";
parent._update_printer_btns();
 //BA.debugLineNum = 279;BA.debugLine="Select Case o.tag";
if (true) break;

case 7:
//select
this.state = 40;
switch (BA.switchObjectToInt(_o.getTag(),(Object)("print"),(Object)("cancel"),(Object)("pause"),(Object)("resume"))) {
case 0: {
this.state = 9;
if (true) break;
}
case 1: {
this.state = 31;
if (true) break;
}
case 2: {
this.state = 37;
if (true) break;
}
case 3: {
this.state = 39;
if (true) break;
}
}
if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 282;BA.debugLine="If oc.isFileLoaded = False Then";
if (true) break;

case 10:
//if
this.state = 29;
if (parent._oc._isfileloaded /*boolean*/ ==parent.__c.False) { 
this.state = 12;
}else {
this.state = 14;
}if (true) break;

case 12:
//C
this.state = 29;
 //BA.debugLineNum = 284;BA.debugLine="guiHelpers.Show_toast(\"No file loaded\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"No file loaded",(int) (2000));
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 288;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"t";
parent.__c.CallSubNew(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 290;BA.debugLine="If oc.isCanceling = True Then";
if (true) break;

case 15:
//if
this.state = 18;
if (parent._oc._iscanceling /*boolean*/ ==parent.__c.True) { 
this.state = 17;
}if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 291;BA.debugLine="guiHelpers.Show_toast(\"Printer Is Canceling,";
parent._guihelpers._show_toast /*String*/ (ba,"Printer Is Canceling, Please Wait...",(int) (2000));
 //BA.debugLineNum = 292;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 18:
//C
this.state = 19;
;
 //BA.debugLineNum = 295;BA.debugLine="Dim mb2 As dlgMsgBox2 : mb2.Initialize(mMainOb";
_mb2 = new sadLogic.OctoTouchController.foss.dlgmsgbox2();
 //BA.debugLineNum = 295;BA.debugLine="Dim mb2 As dlgMsgBox2 : mb2.Initialize(mMainOb";
_mb2._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",(float) (parent.__c.DipToCurrent((int) (280))),(float) (parent.__c.DipToCurrent((int) (150))),parent.__c.False);
 //BA.debugLineNum = 296;BA.debugLine="mb2.NewTextSize = 32";
_mb2._newtextsize /*float*/  = (float) (32);
 //BA.debugLineNum = 297;BA.debugLine="Wait For (mb2.Show(\"Start print job?\",gblConst";
parent.__c.WaitFor("complete", ba, this, _mb2._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Start print job?",parent._gblconst._mb_icon_question /*String*/ ,"PRINT","","CANCEL"));
this.state = 41;
return;
case 41:
//C
this.state = 19;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 298;BA.debugLine="If res = xui.DialogResponse_Cancel Then Return";
if (true) break;

case 19:
//if
this.state = 24;
if (_res==parent._xui.DialogResponse_Cancel) { 
this.state = 21;
;}if (true) break;

case 21:
//C
this.state = 24;
if (true) return ;
if (true) break;

case 24:
//C
this.state = 25;
;
 //BA.debugLineNum = 300;BA.debugLine="guiHelpers.Show_toast(\"Starting Print...\",2000";
parent._guihelpers._show_toast /*String*/ (ba,"Starting Print...",(int) (2000));
 //BA.debugLineNum = 301;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.c";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_print /*String*/ );
 //BA.debugLineNum = 304;BA.debugLine="If ivPreviewLG.mBase.Visible = True Then";
if (true) break;

case 25:
//if
this.state = 28;
if (parent._ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getVisible()==parent.__c.True) { 
this.state = 27;
}if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 305;BA.debugLine="ivPreviewLG_Click '--- show tempeture panel";
parent._ivpreviewlg_click();
 if (true) break;

case 28:
//C
this.state = 29;
;
 if (true) break;

case 29:
//C
this.state = 40;
;
 if (true) break;

case 31:
//C
this.state = 32;
 //BA.debugLineNum = 311;BA.debugLine="Dim w As Float = IIf(guiHelpers.gIsLandScape,50";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (500)))) : ((Object)(parent._guihelpers._gwidth /*float*/ -parent.__c.DipToCurrent((int) (10)))))));
 //BA.debugLineNum = 312;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Ro";
_mb = new sadLogic.OctoTouchController.foss.dlgmsgbox();
 //BA.debugLineNum = 312;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Ro";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,(float) (parent.__c.DipToCurrent((int) (170))),parent.__c.False);
 //BA.debugLineNum = 313;BA.debugLine="Wait For (mb.Show(\"Do you want to cancel this p";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Do you want to cancel this print?",parent._gblconst._mb_icon_question /*String*/ ,"Yes - Cancel It","","No"));
this.state = 42;
return;
case 42:
//C
this.state = 32;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 316;BA.debugLine="If res = xui.DialogResponse_Positive Then";
if (true) break;

case 32:
//if
this.state = 35;
if (_res==parent._xui.DialogResponse_Positive) { 
this.state = 34;
}if (true) break;

case 34:
//C
this.state = 35;
 //BA.debugLineNum = 317;BA.debugLine="guiHelpers.Show_toast(\"Canceling...\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"Canceling...",(int) (2000));
 //BA.debugLineNum = 318;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.c";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_cancel /*String*/ );
 if (true) break;

case 35:
//C
this.state = 40;
;
 if (true) break;

case 37:
//C
this.state = 40;
 //BA.debugLineNum = 322;BA.debugLine="guiHelpers.Show_toast(\"Pausing...\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"Pausing...",(int) (2000));
 //BA.debugLineNum = 323;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cC";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_pause /*String*/ );
 if (true) break;

case 39:
//C
this.state = 40;
 //BA.debugLineNum = 326;BA.debugLine="guiHelpers.Show_toast(\"Resuming...\",2000)";
parent._guihelpers._show_toast /*String*/ (ba,"Resuming...",(int) (2000));
 //BA.debugLineNum = 327;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cC";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_resume /*String*/ );
 if (true) break;

case 40:
//C
this.state = -1;
;
 //BA.debugLineNum = 331;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public String  _buildgui() throws Exception{
anywheresoftware.b4a.phone.Phone _ph = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
 //BA.debugLineNum = 72;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 74;BA.debugLine="Dim ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 75;BA.debugLine="If ph.SdkVersion < gblConst.API_ANDROID_4_4 Then";
if (_ph.getSdkVersion()<_gblconst._api_android_4_4 /*int*/ ) { 
 //BA.debugLineNum = 76;BA.debugLine="pnlHeating.Height = pnlHeating.Height - 26dip";
_pnlheating.setHeight((int) (_pnlheating.getHeight()-__c.DipToCurrent((int) (26))));
 };
 //BA.debugLineNum = 80;BA.debugLine="guiHelpers.SetTextColor2(Array As B4XView(lblBedT";
_guihelpers._settextcolor2 /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblbedtemp1,_lbltooltemp1,_lblprintstats1._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_lblprintstats2,_lblprintstats3,_circularprogressbar1._getmainlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_lblfilename._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ()});
 //BA.debugLineNum = 84;BA.debugLine="ivPreviewLG.Load(File.DirAssets,gblConst.NO_THUMB";
_ivpreviewlg._load /*String*/ (__c.File.getDirAssets(),_gblconst._no_thumbnail /*String*/ );
 //BA.debugLineNum = 86;BA.debugLine="ivBed.Bitmap  = guiHelpers.ChangeColorBasedOnAlph";
_ivbed._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapSample(__c.File.getDirAssets(),"bed.png",_ivbed._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth(),_ivbed._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()).getObject())),_clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 88;BA.debugLine="ivTool.Bitmap = guiHelpers.ChangeColorBasedOnAlph";
_ivtool._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapSample(__c.File.getDirAssets(),"hotend.png",_ivbed._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth(),_ivbed._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()).getObject())),_clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 91;BA.debugLine="guiHelpers.SkinButton(Array As Button( btnCancel,";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel,_btnpause,_btnprint});
 //BA.debugLineNum = 93;BA.debugLine="guiHelpers.ResizeText(\"200  \",lblBedTemp1) '--- s";
_guihelpers._resizetext /*String*/ (ba,(Object)("200  "),_lblbedtemp1);
 //BA.debugLineNum = 94;BA.debugLine="guiHelpers.ResizeText(\"200  \",lblToolTemp1) '---";
_guihelpers._resizetext /*String*/ (ba,(Object)("200  "),_lbltooltemp1);
 //BA.debugLineNum = 96;BA.debugLine="CircularProgressBar1.ColorEmpty = clrTheme.txtNor";
_circularprogressbar1._setcolorempty /*int*/ (_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 97;BA.debugLine="CircularProgressBar1.ColorFull  = clrTheme.Backgr";
_circularprogressbar1._setcolorfull /*int*/ (_clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 98;BA.debugLine="CircularProgressBar1.Value      = 0";
_circularprogressbar1._setvalue /*float*/ ((float) (0));
 //BA.debugLineNum = 99;BA.debugLine="CircularProgressBar1.ValueUnit  = \"%\"";
_circularprogressbar1._setvalueunit("%");
 //BA.debugLineNum = 101;BA.debugLine="If guiHelpers.gScreenSizeAprox > 6 Then";
if (_guihelpers._gscreensizeaprox /*double*/ >6) { 
 //BA.debugLineNum = 102;BA.debugLine="CircularProgressBar1.MainLabel.Font = xui.Create";
_circularprogressbar1._getmainlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setFont(_xui.CreateDefaultFont((float) (62)));
 }else {
 //BA.debugLineNum = 104;BA.debugLine="CircularProgressBar1.MainLabel.Font = xui.Create";
_circularprogressbar1._getmainlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setFont(_xui.CreateDefaultFont((float) (42)));
 };
 //BA.debugLineNum = 108;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnCancel,";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel,_btnpause,_btnprint},(float)(Double.parseDouble(__c.NumberFormat2(_btncancel.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False))));
 //BA.debugLineNum = 112;BA.debugLine="lblPrintStatsTMP.Text   = $\"Total Time:0:00:00:00";
_lblprintstatstmp._settext /*Object*/ ((Object)(("Total Time:0:00:00:00")));
 //BA.debugLineNum = 113;BA.debugLine="lblPrintStats2.TextSize = lblPrintStatsTMP.BaseLa";
_lblprintstats2.setTextSize(_lblprintstatstmp._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getFont().getSize());
 //BA.debugLineNum = 114;BA.debugLine="lblPrintStats3.TextSize = lblPrintStats2.TextSize";
_lblprintstats3.setTextSize(_lblprintstats2.getTextSize());
 //BA.debugLineNum = 117;BA.debugLine="ivPreviewLG.mBase.Visible = False : 	ivPreviewLG_";
_ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 117;BA.debugLine="ivPreviewLG.mBase.Visible = False : 	ivPreviewLG_";
_ivpreviewlg_click();
 //BA.debugLineNum = 124;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 127;BA.debugLine="mText4PrintBtn  = cs.Initialize.Typeface(Typeface";
_mtext4printbtn = (Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf02f)))).Append(BA.ObjectToCharSequence(__c.CRLF)).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("Print")).PopAll().getObject());
 //BA.debugLineNum = 129;BA.debugLine="mText4ResumeBtn = cs.Initialize.Typeface(Typeface";
_mtext4resumebtn = (Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf04b)))).Append(BA.ObjectToCharSequence(__c.CRLF)).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("Resume")).PopAll().getObject());
 //BA.debugLineNum = 131;BA.debugLine="btnPause.Text = cs.Initialize.Typeface(Typeface.F";
_btnpause.setText(BA.ObjectToCharSequence(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf04c)))).Append(BA.ObjectToCharSequence(__c.CRLF)).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("Pause")).PopAll().getObject()));
 //BA.debugLineNum = 133;BA.debugLine="btnCancel.Text = cs.Initialize.Typeface(Typeface.";
_btncancel.setText(BA.ObjectToCharSequence(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (4))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf04d)))).Append(BA.ObjectToCharSequence(__c.CRLF)).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("Cancel")).PopAll().getObject()));
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"pagePrinting\"";
_mmodule = "pagePrinting";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private mPnlMain As B4XView";
_mpnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private mCallBackEvent As String 'ignore";
_mcallbackevent = "";
 //BA.debugLineNum = 11;BA.debugLine="Private mMainObj As B4XMainPage'ignore";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 13;BA.debugLine="Private mDisplayedFileName As String '--- curentl";
_mdisplayedfilename = "";
 //BA.debugLineNum = 14;BA.debugLine="Private mNumOfTries4Thumbnail As Int = 0";
_mnumoftries4thumbnail = (int) (0);
 //BA.debugLineNum = 16;BA.debugLine="Private btnCancel, btnPause, btnPrint As Button";
_btncancel = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpause = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnprint = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private lblFileName As AutoTextSizeLabel";
_lblfilename = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 19;BA.debugLine="Private CircularProgressBar1 As CircularProgressB";
_circularprogressbar1 = new sadLogic.OctoTouchController.foss.circularprogressbar();
 //BA.debugLineNum = 21;BA.debugLine="Private mText4PrintBtn,mText4ResumeBtn As Object";
_mtext4printbtn = new Object();
_mtext4resumebtn = new Object();
 //BA.debugLineNum = 22;BA.debugLine="Private lblPrintStats1 As AutoTextSizeLabel";
_lblprintstats1 = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 23;BA.debugLine="Private lblPrintStats3,lblPrintStats2 As B4XView";
_lblprintstats3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblprintstats2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private lblPrintStatsTMP As AutoTextSizeLabel";
_lblprintstatstmp = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 26;BA.debugLine="Private ivPreviewLG As lmB4XImageViewX";
_ivpreviewlg = new sadLogic.OctoTouchController.foss.lmb4ximageviewx();
 //BA.debugLineNum = 27;BA.debugLine="Private mTmpTemps As String";
_mtmptemps = "";
 //BA.debugLineNum = 29;BA.debugLine="Private pnlHeating,pnlBtns,pnlBGbed,pnlBGTool As";
_pnlheating = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbtns = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbgbed = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbgtool = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private ivBed,ivTool As lmB4XImageViewX";
_ivbed = new sadLogic.OctoTouchController.foss.lmb4ximageviewx();
_ivtool = new sadLogic.OctoTouchController.foss.lmb4ximageviewx();
 //BA.debugLineNum = 33;BA.debugLine="Private lblToolTemp1,lblBedTemp1 As B4XView";
_lbltooltemp1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblbedtemp1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _heaterview_click() throws Exception{
 //BA.debugLineNum = 423;BA.debugLine="Private Sub HeaterView_Click";
 //BA.debugLineNum = 424;BA.debugLine="ivPreviewLG_Click";
_ivpreviewlg_click();
 //BA.debugLineNum = 425;BA.debugLine="End Sub";
return "";
}
public String  _heaterviewlbl_click() throws Exception{
 //BA.debugLineNum = 426;BA.debugLine="Private Sub HeaterViewLbl_Click";
 //BA.debugLineNum = 427;BA.debugLine="ivPreviewLG_Click";
_ivpreviewlg_click();
 //BA.debugLineNum = 428;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _masterpanel,String _callbackevent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 38;BA.debugLine="Public Sub Initialize(masterPanel As B4XView,callB";
 //BA.debugLineNum = 40;BA.debugLine="mPnlMain = masterPanel";
_mpnlmain = _masterpanel;
 //BA.debugLineNum = 41;BA.debugLine="mCallBackEvent = callBackEvent";
_mcallbackevent = _callbackevent;
 //BA.debugLineNum = 42;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 44;BA.debugLine="mPnlMain.SetLayoutAnimated(0,0,masterPanel.top,ma";
_mpnlmain.SetLayoutAnimated((int) (0),(int) (0),_masterpanel.getTop(),_masterpanel.getWidth(),_masterpanel.getHeight());
 //BA.debugLineNum = 45;BA.debugLine="mPnlMain.LoadLayout(\"pagePrinting\")";
_mpnlmain.LoadLayout("pagePrinting",ba);
 //BA.debugLineNum = 47;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public String  _ivpreviewlg_click() throws Exception{
 //BA.debugLineNum = 408;BA.debugLine="Private Sub ivPreviewLG_Click";
 //BA.debugLineNum = 411;BA.debugLine="If ivPreviewLG.mBase.Visible = True Then";
if (_ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getVisible()==__c.True) { 
 //BA.debugLineNum = 412;BA.debugLine="ivPreviewLG.mBase.Visible = False";
_ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 413;BA.debugLine="pnlBGbed.Visible = True";
_pnlbgbed.setVisible(__c.True);
 //BA.debugLineNum = 414;BA.debugLine="pnlBGTool.Visible = True";
_pnlbgtool.setVisible(__c.True);
 //BA.debugLineNum = 415;BA.debugLine="Update_Printer_Temps";
_update_printer_temps();
 }else {
 //BA.debugLineNum = 417;BA.debugLine="ivPreviewLG.mBase.Visible = True";
_ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 418;BA.debugLine="pnlBGbed.Visible = False";
_pnlbgbed.setVisible(__c.False);
 //BA.debugLineNum = 419;BA.debugLine="pnlBGTool.Visible = False";
_pnlbgtool.setVisible(__c.False);
 };
 //BA.debugLineNum = 422;BA.debugLine="End Sub";
return "";
}
public void  _loadthumbnail() throws Exception{
ResumableSub_LoadThumbNail rsub = new ResumableSub_LoadThumbNail(this);
rsub.resume(ba, null);
}
public static class ResumableSub_LoadThumbNail extends BA.ResumableSub {
public ResumableSub_LoadThumbNail(sadLogic.OctoTouchController.foss.pageprinting parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pageprinting parent;
sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo _currentfileinfo = null;
Object _i = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 336;BA.debugLine="If oc.JobFileName = \"\" Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if ((parent._oc._jobfilename /*String*/ ).equals("")) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 342;BA.debugLine="If mMainObj.oMasterController.gMapOctoFilesList.I";
if (true) break;

case 7:
//if
this.state = 14;
if (parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .IsInitialized()==parent.__c.False) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 344;BA.debugLine="If mMainObj.oPageCurrent = mMainObj.oPagePrintin";
if (true) break;

case 10:
//if
this.state = 13;
if ((parent._mmainobj._opagecurrent /*Object*/ ).equals((Object)(parent._mmainobj._opageprinting /*sadLogic.OctoTouchController.foss.pageprinting*/ ))) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 345;BA.debugLine="guiHelpers.Show_toast(gblConst.THUMBNAIL_LOADIN";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._thumbnail_loading /*String*/ ,(int) (1500));
 if (true) break;

case 13:
//C
this.state = 14;
;
 //BA.debugLineNum = 347;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Load";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"LoadThumbNail",(int) (6200));
 //BA.debugLineNum = 348;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 14:
//C
this.state = 15;
;
 //BA.debugLineNum = 351;BA.debugLine="Dim currentFileInfo As tOctoFileInfo";
_currentfileinfo = new sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo();
 //BA.debugLineNum = 352;BA.debugLine="currentFileInfo =  mMainObj.oMasterController.gMa";
_currentfileinfo = (sadLogic.OctoTouchController.foss.jsonparserfiles._toctofileinfo)(parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._gmapoctofileslist /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent._oc._jobfilename /*String*/ )));
 //BA.debugLineNum = 354;BA.debugLine="mNumOfTries4Thumbnail = mNumOfTries4Thumbnail + 1";
parent._mnumoftries4thumbnail = (int) (parent._mnumoftries4thumbnail+1);
 //BA.debugLineNum = 355;BA.debugLine="If mNumOfTries4Thumbnail > 5 Then Return '--- I h";
if (true) break;

case 15:
//if
this.state = 20;
if (parent._mnumoftries4thumbnail>5) { 
this.state = 17;
;}if (true) break;

case 17:
//C
this.state = 20;
if (true) return ;
if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 357;BA.debugLine="If currentFileInfo = Null Or currentFileInfo.myTh";
if (true) break;

case 21:
//if
this.state = 32;
if (_currentfileinfo== null || (_currentfileinfo.myThumbnail_filename_disk /*String*/ ).equals("")) { 
this.state = 23;
}if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 358;BA.debugLine="If currentFileInfo = Null Then";
if (true) break;

case 24:
//if
this.state = 31;
if (_currentfileinfo== null) { 
this.state = 26;
}if (true) break;

case 26:
//C
this.state = 27;
 //BA.debugLineNum = 359;BA.debugLine="CallSubDelayed(mMainObj.oMasterController, \"Get";
parent.__c.CallSubDelayed(ba,(Object)(parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"GetAllOctoFilesInfo");
 //BA.debugLineNum = 360;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Loa";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"LoadThumbNail",(int) (3000));
 //BA.debugLineNum = 363;BA.debugLine="If mMainObj.oPageCurrent = mMainObj.oPagePrinti";
if (true) break;

case 27:
//if
this.state = 30;
if ((parent._mmainobj._opagecurrent /*Object*/ ).equals((Object)(parent._mmainobj._opageprinting /*sadLogic.OctoTouchController.foss.pageprinting*/ ))) { 
this.state = 29;
}if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 364;BA.debugLine="guiHelpers.Show_toast(gblConst.THUMBNAIL_LOADI";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._thumbnail_loading /*String*/ ,(int) (1500));
 if (true) break;

case 30:
//C
this.state = 31;
;
 if (true) break;

case 31:
//C
this.state = 32;
;
 //BA.debugLineNum = 368;BA.debugLine="ivPreviewLG.Load(File.DirAssets,gblConst.NO_THUM";
parent._ivpreviewlg._load /*String*/ (parent.__c.File.getDirAssets(),parent._gblconst._no_thumbnail /*String*/ );
 //BA.debugLineNum = 369;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 372;BA.debugLine="Try";

case 32:
//try
this.state = 58;
this.catchState = 57;
this.state = 34;
if (true) break;

case 34:
//C
this.state = 35;
this.catchState = 57;
 //BA.debugLineNum = 374;BA.debugLine="If File.Exists(xui.DefaultFolder,currentFileInfo";
if (true) break;

case 35:
//if
this.state = 55;
if (parent.__c.File.Exists(parent._xui.getDefaultFolder(),_currentfileinfo.myThumbnail_filename_disk /*String*/ )==parent.__c.False) { 
this.state = 37;
}else {
this.state = 54;
}if (true) break;

case 37:
//C
this.state = 38;
 //BA.debugLineNum = 376;BA.debugLine="If mMainObj.oPageCurrent = mMainObj.oPagePrinti";
if (true) break;

case 38:
//if
this.state = 41;
if ((parent._mmainobj._opagecurrent /*Object*/ ).equals((Object)(parent._mmainobj._opageprinting /*sadLogic.OctoTouchController.foss.pageprinting*/ ))) { 
this.state = 40;
}if (true) break;

case 40:
//C
this.state = 41;
 //BA.debugLineNum = 378;BA.debugLine="guiHelpers.Show_toast(gblConst.THUMBNAIL_LOADI";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._thumbnail_loading /*String*/ ,(int) (1000));
 if (true) break;
;
 //BA.debugLineNum = 382;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt(\"down";

case 41:
//if
this.state = 46;
if (parent._config._logfile_events /*boolean*/ ) { 
this.state = 43;
;}if (true) break;

case 43:
//C
this.state = 46;
parent._logme._logit /*String*/ (ba,"downloading missing thumbnail file; "+_currentfileinfo.myThumbnail_filename_disk /*String*/ ,parent._mmodule);
if (true) break;

case 46:
//C
this.state = 47;
;
 //BA.debugLineNum = 384;BA.debugLine="Wait For (mMainObj.oMasterController.cn.Downloa";
parent.__c.WaitFor("complete", ba, this, parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._download_andsavefile /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+"/")+_currentfileinfo.Thumbnail /*String*/ ,_currentfileinfo.myThumbnail_filename_disk /*String*/ ));
this.state = 59;
return;
case 59:
//C
this.state = 47;
_i = (Object) result[0];
;
 //BA.debugLineNum = 390;BA.debugLine="If File.Exists(xui.DefaultFolder,currentFileInf";
if (true) break;

case 47:
//if
this.state = 52;
if (parent.__c.File.Exists(parent._xui.getDefaultFolder(),_currentfileinfo.myThumbnail_filename_disk /*String*/ )==parent.__c.False) { 
this.state = 49;
}else {
this.state = 51;
}if (true) break;

case 49:
//C
this.state = 52;
 //BA.debugLineNum = 391;BA.debugLine="ivPreviewLG.Load(File.DirAssets,gblConst.NO_TH";
parent._ivpreviewlg._load /*String*/ (parent.__c.File.getDirAssets(),parent._gblconst._no_thumbnail /*String*/ );
 if (true) break;

case 51:
//C
this.state = 52;
 //BA.debugLineNum = 393;BA.debugLine="ivPreviewLG.Load(xui.DefaultFolder,currentFile";
parent._ivpreviewlg._load /*String*/ (parent._xui.getDefaultFolder(),_currentfileinfo.myThumbnail_filename_disk /*String*/ );
 if (true) break;

case 52:
//C
this.state = 55;
;
 if (true) break;

case 54:
//C
this.state = 55;
 //BA.debugLineNum = 396;BA.debugLine="ivPreviewLG.Load(xui.DefaultFolder,currentFileI";
parent._ivpreviewlg._load /*String*/ (parent._xui.getDefaultFolder(),_currentfileinfo.myThumbnail_filename_disk /*String*/ );
 if (true) break;

case 55:
//C
this.state = 58;
;
 if (true) break;

case 57:
//C
this.state = 58;
this.catchState = 0;
 //BA.debugLineNum = 400;BA.debugLine="guiHelpers.Show_toast(\"NULL Error loading thumbn";
parent._guihelpers._show_toast /*String*/ (ba,"NULL Error loading thumbnail",(int) (2000));
 //BA.debugLineNum = 401;BA.debugLine="logMe.LogIt2(LastException,mModule,\"LoadThumbNai";
parent._logme._logit2 /*String*/ (ba,BA.ObjectToString(parent.__c.LastException(ba)),parent._mmodule,"LoadThumbNail");
 if (true) break;
if (true) break;

case 58:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 405;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="public Sub Lost_focus()";
 //BA.debugLineNum = 68;BA.debugLine="mPnlMain.SetVisibleAnimated(500,False)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="public Sub Set_focus()";
 //BA.debugLineNum = 53;BA.debugLine="mPnlMain.SetVisibleAnimated(500,True)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 54;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
_mpnlmain.setEnabled(_oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 56;BA.debugLine="Update_Printer_Stats";
_update_printer_stats();
 //BA.debugLineNum = 57;BA.debugLine="Update_Printer_Temps";
_update_printer_temps();
 //BA.debugLineNum = 58;BA.debugLine="Update_Printer_Btns";
_update_printer_btns();
 //BA.debugLineNum = 60;BA.debugLine="UpdateFileName";
_updatefilename();
 //BA.debugLineNum = 61;BA.debugLine="mDisplayedFileName = oc.JobFileName";
_mdisplayedfilename = _oc._jobfilename /*String*/ ;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _show_temp_panel() throws Exception{
 //BA.debugLineNum = 429;BA.debugLine="Public Sub Show_Temp_Panel";
 //BA.debugLineNum = 431;BA.debugLine="Log(\"Printing_FromFilesPage\")";
__c.LogImpl("46989314","Printing_FromFilesPage",0);
 //BA.debugLineNum = 432;BA.debugLine="If ivPreviewLG.mBase.Visible = True Then";
if (_ivpreviewlg._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getVisible()==__c.True) { 
 //BA.debugLineNum = 433;BA.debugLine="ivPreviewLG_Click";
_ivpreviewlg_click();
 };
 //BA.debugLineNum = 435;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_btns() throws Exception{
 //BA.debugLineNum = 141;BA.debugLine="Public Sub Update_Printer_Btns";
 //BA.debugLineNum = 143;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
_mpnlmain.setEnabled(_oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 146;BA.debugLine="If oc.isPaused2 = True Then";
if (_oc._ispaused2 /*boolean*/ ==__c.True) { 
 //BA.debugLineNum = 147;BA.debugLine="btnPrint.Text = mText4ResumeBtn";
_btnprint.setText(BA.ObjectToCharSequence(_mtext4resumebtn));
 //BA.debugLineNum = 148;BA.debugLine="btnPrint.Tag = \"resume\"";
_btnprint.setTag((Object)("resume"));
 }else {
 //BA.debugLineNum = 150;BA.debugLine="btnPrint.Text = mText4PrintBtn";
_btnprint.setText(BA.ObjectToCharSequence(_mtext4printbtn));
 //BA.debugLineNum = 151;BA.debugLine="btnPrint.Tag = \"print\"";
_btnprint.setTag((Object)("print"));
 };
 //BA.debugLineNum = 156;BA.debugLine="If oc.isFileLoaded = False Then";
if (_oc._isfileloaded /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 158;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnprint,_btnpause,_btncancel},__c.False);
 //BA.debugLineNum = 159;BA.debugLine="Return";
if (true) return "";
 }else {
 };
 //BA.debugLineNum = 170;BA.debugLine="If oc.isPrinting Then";
if (_oc._isprinting /*boolean*/ ) { 
 //BA.debugLineNum = 173;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel,_btnpause},__c.True);
 //BA.debugLineNum = 174;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnprint},__c.False);
 }else if(_oc._isprinting /*boolean*/ ==__c.False && _oc._ispaused2 /*boolean*/ ==__c.True) { 
 //BA.debugLineNum = 179;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel,_btnprint},__c.True);
 //BA.debugLineNum = 180;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnpause},__c.False);
 }else if((_oc._jobprintstate /*String*/ ).equals("Resuming")) { 
 //BA.debugLineNum = 185;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel},__c.True);
 //BA.debugLineNum = 186;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnpause,_btnprint},__c.False);
 }else if(_oc._iscanceling /*boolean*/ ) { 
 //BA.debugLineNum = 190;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnpause,_btnprint,_btncancel},__c.False);
 }else {
 //BA.debugLineNum = 195;BA.debugLine="btnPrint.Enabled = oc.isFileLoaded";
_btnprint.setEnabled(_oc._isfileloaded /*boolean*/ );
 //BA.debugLineNum = 196;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnprint},_oc._isfileloaded /*boolean*/ );
 //BA.debugLineNum = 197;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button(bt";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncancel,_btnpause},__c.False);
 };
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_stats() throws Exception{
String _tmp = "";
 //BA.debugLineNum = 203;BA.debugLine="Public Sub Update_Printer_Stats";
 //BA.debugLineNum = 206;BA.debugLine="If IsNumber(oc.JobCompletion) Then";
if (__c.IsNumber(_oc._jobcompletion /*String*/ )) { 
 //BA.debugLineNum = 207;BA.debugLine="CircularProgressBar1.Value = oc.JobCompletion";
_circularprogressbar1._setvalue /*float*/ ((float)(Double.parseDouble(_oc._jobcompletion /*String*/ )));
 }else {
 //BA.debugLineNum = 209;BA.debugLine="CircularProgressBar1.Reset";
_circularprogressbar1._reset /*String*/ ();
 };
 //BA.debugLineNum = 212;BA.debugLine="Dim tmp As String = $\"File Size:${fileHelpers.Byt";
_tmp = ("File Size:"+__c.SmartStringFormatter("",(Object)(_filehelpers._bytestoreadablestring /*String*/ (ba,_oc._jobfilesize /*String*/ )))+"");
 //BA.debugLineNum = 213;BA.debugLine="If lblPrintStats1.Text <> tmp Then";
if ((_lblprintstats1._gettext /*Object*/ ()).equals((Object)(_tmp)) == false) { 
 //BA.debugLineNum = 214;BA.debugLine="lblPrintStats1.Text = tmp";
_lblprintstats1._settext /*Object*/ ((Object)(_tmp));
 };
 //BA.debugLineNum = 217;BA.debugLine="If oc.JobPrintTime <> \"-\" Then";
if ((_oc._jobprinttime /*String*/ ).equals("-") == false) { 
 //BA.debugLineNum = 218;BA.debugLine="lblPrintStats2.Text = $\"Total Time:${fnc.Convert";
_lblprintstats2.setText(BA.ObjectToCharSequence(("Total Time:"+__c.SmartStringFormatter("",(Object)(_fnc._convertsecondstostring /*String*/ (ba,_oc._jobprinttime /*String*/ )))+"")));
 //BA.debugLineNum = 219;BA.debugLine="lblPrintStats3.Text = $\"Time Left:${fnc.ConvertS";
_lblprintstats3.setText(BA.ObjectToCharSequence(("Time Left:"+__c.SmartStringFormatter("",(Object)(_fnc._convertsecondstostring /*String*/ (ba,_oc._jobprinttimeleft /*String*/ )))+"")));
 }else {
 //BA.debugLineNum = 221;BA.debugLine="lblPrintStats2.Text = \"\"";
_lblprintstats2.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 222;BA.debugLine="lblPrintStats3.Text = \"\"";
_lblprintstats3.setText(BA.ObjectToCharSequence(""));
 };
 //BA.debugLineNum = 225;BA.debugLine="If (oc.JobFileName.Length = 0 And lblFileName.Tex";
if ((_oc._jobfilename /*String*/ .length()==0 && (_lblfilename._gettext /*Object*/ ()).equals((Object)(_gblconst._no_file_loaded /*String*/ )) == false) || (_oc._jobfilename /*String*/ .length()!=0 && (_lblfilename._gettext /*Object*/ ()).equals((Object)(_gblconst._no_file_loaded /*String*/ ))) || ((_mdisplayedfilename).equals(_oc._jobfilename /*String*/ ) == false)) { 
 //BA.debugLineNum = 228;BA.debugLine="UpdateFileName";
_updatefilename();
 };
 //BA.debugLineNum = 231;BA.debugLine="mDisplayedFileName = oc.JobFileName";
_mdisplayedfilename = _oc._jobfilename /*String*/ ;
 //BA.debugLineNum = 233;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_temps() throws Exception{
 //BA.debugLineNum = 248;BA.debugLine="Public Sub Update_Printer_Temps";
 //BA.debugLineNum = 253;BA.debugLine="If lblBedTemp1.Visible = False Then Return";
if (_lblbedtemp1.getVisible()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 255;BA.debugLine="mTmpTemps = IIf(oc.Tool1Actual = $\"0${gblConst.DE";
_mtmptemps = BA.ObjectToString((((_oc._tool1actual /*String*/ ).equals(("0"+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off")) : ((Object)(_oc._tool1actual /*String*/ ))));
 //BA.debugLineNum = 256;BA.debugLine="If lblToolTemp1.Text <> mTmpTemps Then";
if ((_lbltooltemp1.getText()).equals(_mtmptemps) == false) { 
 //BA.debugLineNum = 257;BA.debugLine="lblToolTemp1.Text = mTmpTemps.Replace(\"C\",\"\") '-";
_lbltooltemp1.setText(BA.ObjectToCharSequence(_mtmptemps.replace("C","")));
 };
 //BA.debugLineNum = 260;BA.debugLine="mTmpTemps = IIf(oc.BedActual = $\"0${gblConst.DEGR";
_mtmptemps = BA.ObjectToString((((_oc._bedactual /*String*/ ).equals(("0"+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off")) : ((Object)(_oc._bedactual /*String*/ ))));
 //BA.debugLineNum = 261;BA.debugLine="If lblBedTemp1.Text <> mTmpTemps Then";
if ((_lblbedtemp1.getText()).equals(_mtmptemps) == false) { 
 //BA.debugLineNum = 262;BA.debugLine="lblBedTemp1.Text = mTmpTemps.Replace(\"C\",\"\") '--";
_lblbedtemp1.setText(BA.ObjectToCharSequence(_mtmptemps.replace("C","")));
 };
 //BA.debugLineNum = 265;BA.debugLine="End Sub";
return "";
}
public String  _updatefilename() throws Exception{
 //BA.debugLineNum = 235;BA.debugLine="Private Sub UpdateFileName";
 //BA.debugLineNum = 236;BA.debugLine="If oc.isFileLoaded Then";
if (_oc._isfileloaded /*boolean*/ ) { 
 //BA.debugLineNum = 237;BA.debugLine="lblFileName.Text = \" File: \" & fileHelpers.Remov";
_lblfilename._settext /*Object*/ ((Object)(" File: "+_filehelpers._removeextfromefilename /*String*/ (ba,_oc._jobfilename /*String*/ )));
 }else {
 //BA.debugLineNum = 239;BA.debugLine="lblFileName.Text = gblConst.NO_FILE_LOADED";
_lblfilename._settext /*Object*/ ((Object)(_gblconst._no_file_loaded /*String*/ ));
 };
 //BA.debugLineNum = 241;BA.debugLine="mNumOfTries4Thumbnail = 0";
_mnumoftries4thumbnail = (int) (0);
 //BA.debugLineNum = 242;BA.debugLine="LoadThumbNail";
_loadthumbnail();
 //BA.debugLineNum = 243;BA.debugLine="If (oc.isHeating Or oc.isPrinting) Then";
if ((_oc._isheating /*boolean*/  || _oc._isprinting /*boolean*/ )) { 
 //BA.debugLineNum = 244;BA.debugLine="Show_Temp_Panel";
_show_temp_panel();
 };
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SHOW_TEMP_PANEL"))
	return _show_temp_panel();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_BTNS"))
	return _update_printer_btns();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_STATS"))
	return _update_printer_stats();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_TEMPS"))
	return _update_printer_temps();
return BA.SubDelegator.SubNotFound;
}
}
