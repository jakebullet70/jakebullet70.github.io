package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlggeneraloptions extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlggeneraloptions");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlggeneraloptions.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.sadpreferencesdialog _mgeneraldlg = null;
public sadLogic.OctoTouchController.sadpreferencesdialoghelper _prefhelper = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgGeneralOpti";
_mmodule = "dlgGeneralOptions";
 //BA.debugLineNum = 9;BA.debugLine="Private mainObj As B4XMainPage";
_mainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mGeneralDlg As sadPreferencesDialog";
_mgeneraldlg = new sadLogic.OctoTouchController.sadpreferencesdialog();
 //BA.debugLineNum = 12;BA.debugLine="Private prefHelper As sadPreferencesDialogHelper";
_prefhelper = new sadLogic.OctoTouchController.sadpreferencesdialoghelper();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 24;BA.debugLine="mGeneralDlg.Dialog.Close(xui.DialogResponse_Cance";
_mgeneraldlg._dialog /*sadLogic.OctoTouchController.b4xdialog*/ ._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public String  _createdefaultfile() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="public Sub CreateDefaultFile";
 //BA.debugLineNum = 29;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.GENERAL";
if (__c.File.Exists(_xui.getDefaultFolder(),_gblconst._general_options_file /*String*/ )==__c.False) { 
 //BA.debugLineNum = 30;BA.debugLine="File.WriteMap(xui.DefaultFolder,gblConst.GENERAL";
__c.File.WriteMap(_xui.getDefaultFolder(),_gblconst._general_options_file /*String*/ ,__c.createMap(new Object[] {(Object)("logall"),(Object)("false"),(Object)("logpwr"),(Object)("false"),(Object)("logfiles"),(Object)("false"),(Object)("logoctokey"),(Object)("false"),(Object)("logrest"),(Object)("false"),(Object)("syscmds"),(Object)("false"),(Object)("axesx"),(Object)("false"),(Object)("axesy"),(Object)("false"),(Object)("axesz"),(Object)("false"),(Object)("sboot"),(Object)("false"),(Object)("syscmds"),(Object)("false"),(Object)("m600"),(Object)("false"),(Object)("prpwr"),(Object)("false"),(Object)("mpsd"),(Object)("true"),(Object)("ort"),(Object)("Autodetect")}));
 };
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _dlggeneral_beforedialogdisplayed(Object _template) throws Exception{
int _i = 0;
sadLogic.OctoTouchController.preferencesdialog._b4xprefitem _pi = null;
 //BA.debugLineNum = 109;BA.debugLine="Private Sub dlgGeneral_BeforeDialogDisplayed (Temp";
 //BA.debugLineNum = 110;BA.debugLine="prefHelper.SkinDialog(Template)";
_prefhelper._skindialog /*String*/ (_template);
 //BA.debugLineNum = 112;BA.debugLine="For i = 0 To mGeneralDlg.PrefItems.Size - 1";
{
final int step2 = 1;
final int limit2 = (int) (_mgeneraldlg._prefitems /*anywheresoftware.b4a.objects.collections.List*/ .getSize()-1);
_i = (int) (0) ;
for (;_i <= limit2 ;_i = _i + step2 ) {
 //BA.debugLineNum = 113;BA.debugLine="Dim pi As B4XPrefItem = mGeneralDlg.PrefItems.Ge";
_pi = (sadLogic.OctoTouchController.preferencesdialog._b4xprefitem)(_mgeneraldlg._prefitems /*anywheresoftware.b4a.objects.collections.List*/ .Get(_i));
 //BA.debugLineNum = 114;BA.debugLine="If pi.ItemType = mGeneralDlg.TYPE_BOOLEAN Then";
if (_pi.ItemType /*int*/ ==_mgeneraldlg._type_boolean /*int*/ ) { 
 };
 }
};
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public boolean  _dlggeneral_isvalid(anywheresoftware.b4a.objects.collections.Map _tempdata) throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Private Sub dlgGeneral_IsValid (TempData As Map) A";
 //BA.debugLineNum = 89;BA.debugLine="Return True '--- all is good!";
if (true) return __c.True;
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return false;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize() As Object";
 //BA.debugLineNum = 18;BA.debugLine="mainObj = B4XPages.MainPage";
_mainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 19;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public String  _processautobootflag(boolean _enabled) throws Exception{
String _fname = "";
 //BA.debugLineNum = 124;BA.debugLine="Private Sub ProcessAutoBootFlag(Enabled As Boolean";
 //BA.debugLineNum = 126;BA.debugLine="Dim fname As String = \"autostart.bin\"";
_fname = "autostart.bin";
 //BA.debugLineNum = 127;BA.debugLine="If Enabled Then";
if (_enabled) { 
 //BA.debugLineNum = 128;BA.debugLine="If File.Exists(xui.DefaultFolder,fname) Then Ret";
if (__c.File.Exists(_xui.getDefaultFolder(),_fname)) { 
if (true) return "";};
 //BA.debugLineNum = 129;BA.debugLine="File.WriteString(xui.DefaultFolder,fname,\"boot\")";
__c.File.WriteString(_xui.getDefaultFolder(),_fname,"boot");
 }else {
 //BA.debugLineNum = 131;BA.debugLine="fileHelpers.SafeKill(fname)";
_filehelpers._safekill /*String*/ (ba,_fname);
 };
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlggeneraloptions parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlggeneraloptions parent;
anywheresoftware.b4a.objects.collections.Map _data = null;
float _h = 0f;
float _w = 0f;
String _s = "";
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 40;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = parent.__c.File.ReadMap(parent._xui.getDefaultFolder(),parent._gblconst._general_options_file /*String*/ );
 //BA.debugLineNum = 42;BA.debugLine="Dim h,w As Float '--- TODO - needs refactor";
_h = 0f;
_w = 0f;
 //BA.debugLineNum = 43;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 14;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 13;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 44;BA.debugLine="If guiHelpers.gScreenSizeAprox >= 6 And guiHelpe";
if (true) break;

case 4:
//if
this.state = 11;
if (parent._guihelpers._gscreensizeaprox /*double*/ >=6 && parent._guihelpers._gscreensizeaprox /*double*/ <=8) { 
this.state = 6;
}else if(parent._guihelpers._gscreensizeaprox /*double*/ >=8) { 
this.state = 8;
}else {
this.state = 10;
}if (true) break;

case 6:
//C
this.state = 11;
 //BA.debugLineNum = 45;BA.debugLine="h = 62%y";
_h = (float) (parent.__c.PerYToCurrent((float) (62),ba));
 if (true) break;

case 8:
//C
this.state = 11;
 //BA.debugLineNum = 47;BA.debugLine="h = 55%y";
_h = (float) (parent.__c.PerYToCurrent((float) (55),ba));
 if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 49;BA.debugLine="h = 80%y";
_h = (float) (parent.__c.PerYToCurrent((float) (80),ba));
 if (true) break;

case 11:
//C
this.state = 14;
;
 //BA.debugLineNum = 51;BA.debugLine="w = 360dip";
_w = (float) (parent.__c.DipToCurrent((int) (360)));
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 53;BA.debugLine="h = 440dip";
_h = (float) (parent.__c.DipToCurrent((int) (440)));
 //BA.debugLineNum = 54;BA.debugLine="w = guiHelpers.gWidth * .92";
_w = (float) (parent._guihelpers._gwidth /*float*/ *.92);
 if (true) break;

case 14:
//C
this.state = 15;
;
 //BA.debugLineNum = 57;BA.debugLine="mGeneralDlg.Initialize(mainObj.root, \"General Set";
parent._mgeneraldlg._initialize /*String*/ (ba,parent._mainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,(Object)("General Settings"),(int) (_w),(int) (_h));
 //BA.debugLineNum = 59;BA.debugLine="Dim s As String = File.ReadString(File.DirAssets,";
_s = parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"dlggeneral.json");
 //BA.debugLineNum = 60;BA.debugLine="If guiHelpers.gIsPortrait Then s = s.Replace(\"Mov";
if (true) break;

case 15:
//if
this.state = 20;
if (parent._guihelpers._gisportrait /*boolean*/ (ba)) { 
this.state = 17;
;}if (true) break;

case 17:
//C
this.state = 20;
_s = _s.replace("Movement ","Move ");
if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 61;BA.debugLine="mGeneralDlg.LoadFromJson(s)";
parent._mgeneraldlg._loadfromjson /*String*/ (_s);
 //BA.debugLineNum = 62;BA.debugLine="mGeneralDlg.SetEventsListener(Me,\"dlgGeneral\")";
parent._mgeneraldlg._seteventslistener /*String*/ (parent,"dlgGeneral");
 //BA.debugLineNum = 65;BA.debugLine="prefHelper.Initialize(mGeneralDlg)";
parent._prefhelper._initialize /*String*/ (ba,parent._mgeneraldlg);
 //BA.debugLineNum = 66;BA.debugLine="If guiHelpers.gIsPortrait Then prefHelper.pDefaul";
if (true) break;

case 21:
//if
this.state = 26;
if (parent._guihelpers._gisportrait /*boolean*/ (ba)) { 
this.state = 23;
;}if (true) break;

case 23:
//C
this.state = 26;
parent._prefhelper._pdefaultfontsize /*float*/  = (float) (17);
if (true) break;

case 26:
//C
this.state = 27;
;
 //BA.debugLineNum = 67;BA.debugLine="prefHelper.ThemePrefDialogForm";
parent._prefhelper._themeprefdialogform /*String*/ ();
 //BA.debugLineNum = 68;BA.debugLine="mGeneralDlg.PutAtTop = False";
parent._mgeneraldlg._putattop /*Object*/  = (Object)(parent.__c.False);
 //BA.debugLineNum = 69;BA.debugLine="Dim RS As ResumableSub = mGeneralDlg.ShowDialog(D";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mgeneraldlg._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_data,(Object)("OK"),(Object)("CANCEL"));
 //BA.debugLineNum = 70;BA.debugLine="prefHelper.dlgHelper.ThemeInputDialogBtnsResize";
parent._prefhelper._dlghelper /*sadLogic.OctoTouchController.sadb4xdialoghelper*/ ._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 72;BA.debugLine="Wait For (RS) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 31;
return;
case 31:
//C
this.state = 27;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 73;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 27:
//if
this.state = 30;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 29;
}if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 74;BA.debugLine="guiHelpers.Show_toast(gblConst.DATA_SAVED,1500)";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._data_saved /*String*/ ,(int) (1500));
 //BA.debugLineNum = 75;BA.debugLine="File.WriteMap(xui.DefaultFolder,gblConst.GENERAL";
parent.__c.File.WriteMap(parent._xui.getDefaultFolder(),parent._gblconst._general_options_file /*String*/ ,_data);
 //BA.debugLineNum = 76;BA.debugLine="ProcessAutoBootFlag(Data.Get(\"sboot\").As(Boolean";
parent._processautobootflag((BA.ObjectToBoolean(_data.Get((Object)("sboot")))));
 //BA.debugLineNum = 77;BA.debugLine="config.ReadGeneralCFG";
parent._config._readgeneralcfg /*String*/ (ba);
 //BA.debugLineNum = 78;BA.debugLine="CallSub(mainObj.oPageCurrent,\"Set_focus\")";
parent.__c.CallSubNew(ba,parent._mainobj._opagecurrent /*Object*/ ,"Set_focus");
 //BA.debugLineNum = 79;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"Build_RightSid";
parent.__c.CallSubDelayed(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)),"Build_RightSideMenu");
 if (true) break;

case 30:
//C
this.state = -1;
;
 //BA.debugLineNum = 82;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 83;BA.debugLine="mainObj.pObjCurrentDlg1 = Null";
parent._mainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
