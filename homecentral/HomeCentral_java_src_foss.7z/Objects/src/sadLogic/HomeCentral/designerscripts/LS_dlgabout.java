package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_dlgabout{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("madewithlove1").vw.setTop((int)((100d / 100 * height) - (views.get("madewithlove1").vw.getHeight())));
views.get("lblabouttop").vw.setLeft((int)((views.get("iv").vw.getLeft() + views.get("iv").vw.getWidth())+(2d * scale)));
views.get("lblabouttop").vw.setWidth((int)((100d / 100 * width) - ((views.get("iv").vw.getLeft() + views.get("iv").vw.getWidth())+(2d * scale))));
views.get("credits").vw.setLeft((int)(0d));
views.get("credits").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("credits").vw.setTop((int)((views.get("iv").vw.getTop() + views.get("iv").vw.getHeight())));
views.get("credits").vw.setHeight((int)((views.get("madewithlove1").vw.getTop()) - ((views.get("iv").vw.getTop() + views.get("iv").vw.getHeight()))));

}
}