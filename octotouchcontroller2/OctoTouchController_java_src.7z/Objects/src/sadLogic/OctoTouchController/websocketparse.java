package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class websocketparse extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.websocketparse");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.websocketparse.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public Object _raiseeventmod = null;
public String _raiseeventevent = "";
public anywheresoftware.b4a.objects.collections.Map _pevents2monitor = null;
public anywheresoftware.b4a.objects.collections.Map _pmsgs2monitor = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static class _toctoevents{
public boolean IsInitialized;
public Object CallbackObj;
public String CallbackSub;
public void Initialize() {
IsInitialized = true;
CallbackObj = new Object();
CallbackSub = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private Const mModule As String = \"WebSocketParse";
_mmodule = "WebSocketParse";
 //BA.debugLineNum = 13;BA.debugLine="Public RaiseEventMod As Object = Null";
_raiseeventmod = __c.Null;
 //BA.debugLineNum = 14;BA.debugLine="Public RaiseEventEvent As String = \"\"";
_raiseeventevent = "";
 //BA.debugLineNum = 15;BA.debugLine="Public pEvents2Monitor As Map";
_pevents2monitor = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 16;BA.debugLine="Public pMsgs2Monitor As Map";
_pmsgs2monitor = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 17;BA.debugLine="Type tOctoEvents(CallbackObj As Object, CallbackS";
;
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _event_parse(String _msg) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _event = null;
anywheresoftware.b4a.objects.collections.Map _payload = null;
String _evtype = "";
sadLogic.OctoTouchController.websocketparse._toctoevents _o = null;
Object _outmsg = null;
double _new = 0;
String _old = "";
 //BA.debugLineNum = 45;BA.debugLine="Public Sub Event_Parse(msg As String)";
 //BA.debugLineNum = 48;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 48;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser.Initialize(_msg);
 //BA.debugLineNum = 50;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 51;BA.debugLine="Dim Event As Map = root.Get(\"event\")";
_event = new anywheresoftware.b4a.objects.collections.Map();
_event = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("event"))));
 //BA.debugLineNum = 52;BA.debugLine="Dim payload As Map = Event.Get(\"payload\")";
_payload = new anywheresoftware.b4a.objects.collections.Map();
_payload = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_event.Get((Object)("payload"))));
 //BA.debugLineNum = 53;BA.debugLine="Dim evType As String = Event.Get(\"type\")";
_evtype = BA.ObjectToString(_event.Get((Object)("type")));
 //BA.debugLineNum = 55;BA.debugLine="If pEvents2Monitor.ContainsKey(evType) = False Th";
if (_pevents2monitor.ContainsKey((Object)(_evtype))==__c.False) { 
 //BA.debugLineNum = 60;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 63;BA.debugLine="Dim o As tOctoEvents = pEvents2Monitor.Get(evType";
_o = (sadLogic.OctoTouchController.websocketparse._toctoevents)(_pevents2monitor.Get((Object)(_evtype)));
 //BA.debugLineNum = 66;BA.debugLine="Dim outMsg As Object = Null 'ignore";
_outmsg = __c.Null;
 //BA.debugLineNum = 67;BA.debugLine="Select Case evType";
switch (BA.switchObjectToInt(_evtype,"ZChange","MetadataAnalysisFinished","FilamentChange","PrintStarted","PrintFailed","FileRemoved")) {
case 0: {
 //BA.debugLineNum = 70;BA.debugLine="Dim new As Double = payload.Get(\"new\")";
_new = (double)(BA.ObjectToNumber(_payload.Get((Object)("new"))));
 //BA.debugLineNum = 71;BA.debugLine="Dim old As String = payload.Get(\"old\")";
_old = BA.ObjectToString(_payload.Get((Object)("old")));
 //BA.debugLineNum = 72;BA.debugLine="new = Round2(new,3)";
_new = __c.Round2(_new,(int) (3));
 //BA.debugLineNum = 73;BA.debugLine="If IsNumber(old) Then";
if (__c.IsNumber(_old)) { 
 //BA.debugLineNum = 74;BA.debugLine="old = Round2(old,3)";
_old = BA.NumberToString(__c.Round2((double)(Double.parseDouble(_old)),(int) (3)));
 }else {
 //BA.debugLineNum = 76;BA.debugLine="old = \"???\"";
_old = "???";
 };
 //BA.debugLineNum = 79;BA.debugLine="outMsg = $\"* Old Z=${old} / New Z=${new} *\"$";
_outmsg = (Object)(("* Old Z="+__c.SmartStringFormatter("",(Object)(_old))+" / New Z="+__c.SmartStringFormatter("",(Object)(_new))+" *"));
 break; }
case 1: {
 //BA.debugLineNum = 83;BA.debugLine="outMsg = msg";
_outmsg = (Object)(_msg);
 break; }
case 2: {
 //BA.debugLineNum = 86;BA.debugLine="outMsg = \"\" '{\"event\": {\"type\": \"FilamentChange";
_outmsg = (Object)("");
 break; }
case 3: 
case 4: 
case 5: {
 //BA.debugLineNum = 89;BA.debugLine="outMsg = msg";
_outmsg = (Object)(_msg);
 break; }
}
;
 //BA.debugLineNum = 93;BA.debugLine="If SubExists(o.CallbackObj,o.CallbackSub) Then";
if (__c.SubExists(ba,_o.CallbackObj /*Object*/ ,_o.CallbackSub /*String*/ )) { 
 //BA.debugLineNum = 94;BA.debugLine="CallSubDelayed2(o.CallbackObj,o.CallbackSub,outM";
__c.CallSubDelayed2(ba,_o.CallbackObj /*Object*/ ,_o.CallbackSub /*String*/ ,_outmsg);
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _eventadd(String _name,Object _callbackobj,String _callbacksub) throws Exception{
sadLogic.OctoTouchController.websocketparse._toctoevents _o = null;
 //BA.debugLineNum = 37;BA.debugLine="Public Sub EventAdd(name As String,CallbackObj As";
 //BA.debugLineNum = 38;BA.debugLine="Dim o As tOctoEvents : o.Initialize";
_o = new sadLogic.OctoTouchController.websocketparse._toctoevents();
 //BA.debugLineNum = 38;BA.debugLine="Dim o As tOctoEvents : o.Initialize";
_o.Initialize();
 //BA.debugLineNum = 39;BA.debugLine="o.CallbackObj = CallbackObj";
_o.CallbackObj /*Object*/  = _callbackobj;
 //BA.debugLineNum = 40;BA.debugLine="o.CallbackSub = CallbackSub";
_o.CallbackSub /*String*/  = _callbacksub;
 //BA.debugLineNum = 41;BA.debugLine="EventRemove(name)";
_eventremove(_name);
 //BA.debugLineNum = 42;BA.debugLine="pEvents2Monitor.Put(name,o)";
_pevents2monitor.Put((Object)(_name),(Object)(_o));
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _eventremove(String _name) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Public Sub EventRemove(name As String)";
 //BA.debugLineNum = 33;BA.debugLine="If pEvents2Monitor.ContainsKey(name) Then";
if (_pevents2monitor.ContainsKey((Object)(_name))) { 
 //BA.debugLineNum = 34;BA.debugLine="pEvents2Monitor.Remove(name)";
_pevents2monitor.Remove((Object)(_name));
 };
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 24;BA.debugLine="pEvents2Monitor.Initialize";
_pevents2monitor.Initialize();
 //BA.debugLineNum = 25;BA.debugLine="pMsgs2Monitor.Initialize";
_pmsgs2monitor.Initialize();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _klippy_parse(String _msg) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _plugin = null;
anywheresoftware.b4a.objects.collections.Map _data = null;
String _subtype = "";
String _payload = "";
String _msgtype = "";
String _payloadu = "";
 //BA.debugLineNum = 153;BA.debugLine="Public Sub Klippy_Parse(msg As String)";
 //BA.debugLineNum = 154;BA.debugLine="If config.logREST_API Then logMe.logit2(\"Klipper";
if (_config._logrest_api /*boolean*/ ) { 
_logme._logit2 /*String*/ (getActivityBA(),"Klipper msg",_mmodule,"Klippy_Parse");};
 //BA.debugLineNum = 157;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 157;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser.Initialize(_msg);
 //BA.debugLineNum = 158;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 159;BA.debugLine="Dim plugin As Map = root.Get(\"plugin\")";
_plugin = new anywheresoftware.b4a.objects.collections.Map();
_plugin = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("plugin"))));
 //BA.debugLineNum = 161;BA.debugLine="Dim data As Map = plugin.Get(\"data\")";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_plugin.Get((Object)("data"))));
 //BA.debugLineNum = 162;BA.debugLine="Dim subtype As String = data.Get(\"subtype\")";
_subtype = BA.ObjectToString(_data.Get((Object)("subtype")));
 //BA.debugLineNum = 163;BA.debugLine="Dim payload As String = data.Get(\"payload\").As(St";
_payload = (BA.ObjectToString(_data.Get((Object)("payload"))));
 //BA.debugLineNum = 165;BA.debugLine="Dim msgType As String = data.Get(\"type\") 'ignore";
_msgtype = BA.ObjectToString(_data.Get((Object)("type")));
 //BA.debugLineNum = 170;BA.debugLine="If RaiseEventMod <> Null Then";
if (_raiseeventmod!= null) { 
 //BA.debugLineNum = 171;BA.debugLine="If msgType = \"log\" Then";
if ((_msgtype).equals("log")) { 
 //BA.debugLineNum = 172;BA.debugLine="If SubExists(RaiseEventMod,RaiseEventEvent) The";
if (__c.SubExists(ba,_raiseeventmod,_raiseeventevent)) { 
 //BA.debugLineNum = 173;BA.debugLine="CallSubDelayed2(RaiseEventMod,RaiseEventEvent,";
__c.CallSubDelayed2(ba,_raiseeventmod,_raiseeventevent,(Object)(_payload));
 //BA.debugLineNum = 174;BA.debugLine="Return";
if (true) return "";
 };
 }else {
 //BA.debugLineNum = 177;BA.debugLine="Return";
if (true) return "";
 };
 };
 //BA.debugLineNum = 182;BA.debugLine="Dim payloadU As String = payload.ToUpperCase";
_payloadu = _payload.toUpperCase();
 //BA.debugLineNum = 183;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_payloadu.contains("SHUTDO"),_payloadu.contains("E: READY"))) {
case 0: {
 //BA.debugLineNum = 186;BA.debugLine="If B4XPages.MainPage.oPageCurrent <> B4XPages.M";
if ((_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())._opagecurrent /*Object*/ ).equals((Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())._opagemenu /*sadLogic.OctoTouchController.pagemenu*/ )) == false) { 
 //BA.debugLineNum = 188;BA.debugLine="CallSub(B4XPages.MainPage,\"btnPageAction_Click";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())),"btnPageAction_Click");
 //BA.debugLineNum = 189;BA.debugLine="guiHelpers.Show_toast2(\"Klipper disconnect...";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),"Klipper disconnect... Check printer",(int) (3500));
 };
 break; }
case 1: {
 //BA.debugLineNum = 193;BA.debugLine="guiHelpers.Show_toast2(\"Klipper ready\",3500)";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),"Klipper ready",(int) (3500));
 break; }
default: {
 //BA.debugLineNum = 196;BA.debugLine="Try";
try { //BA.debugLineNum = 197;BA.debugLine="If msgType = \"status\" Or subtype = \"error\" Th";
if ((_msgtype).equals("status") || (_subtype).equals("error")) { 
 //BA.debugLineNum = 200;BA.debugLine="guiHelpers.Show_toast2(payload.Replace(CRLF,";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),_payload.replace(__c.CRLF,"").replace("[","{").replace("]","}"),(int) (3500));
 };
 } 
       catch (Exception e35) {
			ba.setLastException(e35); //BA.debugLineNum = 203;BA.debugLine="Log(LastException)";
__c.LogImpl("63897650",BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 break; }
}
;
 //BA.debugLineNum = 208;BA.debugLine="End Sub";
return "";
}
public String  _msgs_parse(String _msg) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _current = null;
anywheresoftware.b4a.objects.collections.List _messages = null;
String _msgkey = "";
String _colmessages = "";
sadLogic.OctoTouchController.websocketparse._toctoevents _o = null;
 //BA.debugLineNum = 118;BA.debugLine="Public Sub Msgs_Parse(msg As String)";
 //BA.debugLineNum = 122;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 122;BA.debugLine="Dim parser As JSONParser : parser.Initialize(msg)";
_parser.Initialize(_msg);
 //BA.debugLineNum = 123;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 124;BA.debugLine="Dim current As Map = root.Get(\"current\")";
_current = new anywheresoftware.b4a.objects.collections.Map();
_current = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("current"))));
 //BA.debugLineNum = 125;BA.debugLine="Dim messages As List = current.Get(\"messages\")";
_messages = new anywheresoftware.b4a.objects.collections.List();
_messages = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_current.Get((Object)("messages"))));
 //BA.debugLineNum = 127;BA.debugLine="For Each msgkey As String In pMsgs2Monitor.keys";
{
final anywheresoftware.b4a.BA.IterableList group6 = _pmsgs2monitor.Keys();
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_msgkey = BA.ObjectToString(group6.Get(index6));
 //BA.debugLineNum = 128;BA.debugLine="For Each colmessages As String In messages";
{
final anywheresoftware.b4a.BA.IterableList group7 = _messages;
final int groupLen7 = group7.getSize()
;int index7 = 0;
;
for (; index7 < groupLen7;index7++){
_colmessages = BA.ObjectToString(group7.Get(index7));
 //BA.debugLineNum = 129;BA.debugLine="If colmessages.Contains(msgkey) Then";
if (_colmessages.contains(_msgkey)) { 
 //BA.debugLineNum = 130;BA.debugLine="Dim o As tOctoEvents = pMsgs2Monitor.Get(msgke";
_o = (sadLogic.OctoTouchController.websocketparse._toctoevents)(_pmsgs2monitor.Get((Object)(_msgkey)));
 //BA.debugLineNum = 131;BA.debugLine="If SubExists(o.CallbackObj,o.CallbackSub) Then";
if (__c.SubExists(ba,_o.CallbackObj /*Object*/ ,_o.CallbackSub /*String*/ )) { 
 //BA.debugLineNum = 132;BA.debugLine="CallSubDelayed2(o.CallbackObj,o.CallbackSub,c";
__c.CallSubDelayed2(ba,_o.CallbackObj /*Object*/ ,_o.CallbackSub /*String*/ ,(Object)(_colmessages));
 };
 };
 }
};
 }
};
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _msgsadd(String _name,Object _callbackobj,String _callbacksub) throws Exception{
sadLogic.OctoTouchController.websocketparse._toctoevents _o = null;
 //BA.debugLineNum = 110;BA.debugLine="Public Sub MsgsAdd(name As String,CallbackObj As O";
 //BA.debugLineNum = 111;BA.debugLine="Dim o As tOctoEvents : o.Initialize";
_o = new sadLogic.OctoTouchController.websocketparse._toctoevents();
 //BA.debugLineNum = 111;BA.debugLine="Dim o As tOctoEvents : o.Initialize";
_o.Initialize();
 //BA.debugLineNum = 112;BA.debugLine="o.CallbackObj = CallbackObj";
_o.CallbackObj /*Object*/  = _callbackobj;
 //BA.debugLineNum = 113;BA.debugLine="o.CallbackSub = CallbackSub";
_o.CallbackSub /*String*/  = _callbacksub;
 //BA.debugLineNum = 114;BA.debugLine="MsgsRemove(name)";
_msgsremove(_name);
 //BA.debugLineNum = 115;BA.debugLine="pMsgs2Monitor.Put(name,o)";
_pmsgs2monitor.Put((Object)(_name),(Object)(_o));
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
return "";
}
public String  _msgsremove(String _name) throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Public Sub MsgsRemove(name As String)";
 //BA.debugLineNum = 106;BA.debugLine="If pMsgs2Monitor.ContainsKey(name) Then";
if (_pmsgs2monitor.ContainsKey((Object)(_name))) { 
 //BA.debugLineNum = 107;BA.debugLine="pMsgs2Monitor.Remove(name)";
_pmsgs2monitor.Remove((Object)(_name));
 };
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public String  _resetraiseevent() throws Exception{
 //BA.debugLineNum = 146;BA.debugLine="Public Sub ResetRaiseEvent";
 //BA.debugLineNum = 147;BA.debugLine="RaiseEventEvent = \"\"";
_raiseeventevent = "";
 //BA.debugLineNum = 148;BA.debugLine="RaiseEventMod = Null";
_raiseeventmod = __c.Null;
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "EVENT_PARSE"))
	return _event_parse((String) args[0]);
if (BA.fastSubCompare(sub, "KLIPPY_PARSE"))
	return _klippy_parse((String) args[0]);
if (BA.fastSubCompare(sub, "MSGS_PARSE"))
	return _msgs_parse((String) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
