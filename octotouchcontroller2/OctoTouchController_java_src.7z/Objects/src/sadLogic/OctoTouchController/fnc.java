package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class fnc {
private static fnc mostCurrent = new fnc();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static String  _blankscreen(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Public Sub BlankScreen";
 //BA.debugLineNum = 27;BA.debugLine="B4XPages.MainPage.pnlScreenOff.Elevation = 5dip '";
mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (_ba)._pnlscreenoff /*anywheresoftware.b4a.objects.PanelWrapper*/ .setElevation((float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))));
 //BA.debugLineNum = 28;BA.debugLine="B4XPages.MainPage.pnlScreenOff.Visible = True";
mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (_ba)._pnlscreenoff /*anywheresoftware.b4a.objects.PanelWrapper*/ .setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 29;BA.debugLine="B4XPages.MainPage.pnlScreenOff.BringToFront";
mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (_ba)._pnlscreenoff /*anywheresoftware.b4a.objects.PanelWrapper*/ .BringToFront();
 //BA.debugLineNum = 30;BA.debugLine="powerHelpers.SetScreenBrightnessAndSave(0.1,False";
mostCurrent._powerhelpers._setscreenbrightnessandsave /*String*/ (_ba,(float) (0.1),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public static String  _buildthumbnailtempfilename(anywheresoftware.b4a.BA _ba,String _fname) throws Exception{
 //BA.debugLineNum = 149;BA.debugLine="public Sub BuildThumbnailTempFilename(fname As Str";
 //BA.debugLineNum = 152;BA.debugLine="Return \"sad__\" & fname";
if (true) return "sad__"+_fname;
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.drawable.GradientDrawable  _changegradient(anywheresoftware.b4a.BA _ba,int _color1,int _color2) throws Exception{
anywheresoftware.b4a.objects.drawable.GradientDrawable _gd = null;
int[] _c1 = null;
 //BA.debugLineNum = 280;BA.debugLine="Public Sub ChangeGradient(Color1 As Int,Color2 As";
 //BA.debugLineNum = 281;BA.debugLine="Dim gd As GradientDrawable, C1(2) As Int";
_gd = new anywheresoftware.b4a.objects.drawable.GradientDrawable();
_c1 = new int[(int) (2)];
;
 //BA.debugLineNum = 282;BA.debugLine="C1(0) = Color1";
_c1[(int) (0)] = _color1;
 //BA.debugLineNum = 283;BA.debugLine="C1(1) = Color2";
_c1[(int) (1)] = _color2;
 //BA.debugLineNum = 284;BA.debugLine="gd.Initialize(\"BOTTOM_TOP\", C1)";
_gd.Initialize(BA.getEnumFromString(android.graphics.drawable.GradientDrawable.Orientation.class,"BOTTOM_TOP"),_c1);
 //BA.debugLineNum = 286;BA.debugLine="Return gd";
if (true) return _gd;
 //BA.debugLineNum = 287;BA.debugLine="End Sub";
return null;
}
public static boolean  _checktemprange(anywheresoftware.b4a.BA _ba,String _what,int _value) throws Exception{
 //BA.debugLineNum = 263;BA.debugLine="Public Sub CheckTempRange(what As String, value As";
 //BA.debugLineNum = 265;BA.debugLine="If what = \"bed\" Then";
if ((_what).equals("bed")) { 
 //BA.debugLineNum = 266;BA.debugLine="If value > 130 Then";
if (_value>130) { 
 //BA.debugLineNum = 267;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 }else {
 //BA.debugLineNum = 270;BA.debugLine="If value > 350 Then";
if (_value>350) { 
 //BA.debugLineNum = 271;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 };
 //BA.debugLineNum = 275;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return false;
}
public static String  _cleanoldthumbnailfiles(anywheresoftware.b4a.BA _ba) throws Exception{
sadLogic.OctoTouchController.wildcardfileslist _o1 = null;
anywheresoftware.b4a.objects.collections.List _flist = null;
Object _fname = null;
 //BA.debugLineNum = 136;BA.debugLine="Public Sub CleanOldThumbnailFiles";
 //BA.debugLineNum = 138;BA.debugLine="If config.logFILE_EVENTS Then logMe.LogIt(\"CleanO";
if (mostCurrent._config._logfile_events /*boolean*/ ) { 
mostCurrent._logme._logit /*String*/ (_ba,"CleanOldThumbnailFiles!",_mmodule);};
 //BA.debugLineNum = 140;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1 = new sadLogic.OctoTouchController.wildcardfileslist();
 //BA.debugLineNum = 140;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 141;BA.debugLine="Dim flist As List = o1.GetFiles(xui.DefaultFolder";
_flist = new anywheresoftware.b4a.objects.collections.List();
_flist = _o1._getfiles /*anywheresoftware.b4a.objects.collections.List*/ (_xui.getDefaultFolder(),"sad__*",anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 142;BA.debugLine="For Each fname In flist";
{
final anywheresoftware.b4a.BA.IterableList group5 = _flist;
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_fname = group5.Get(index5);
 //BA.debugLineNum = 143;BA.debugLine="fileHelpers.SafeKill(fname)";
mostCurrent._filehelpers._safekill /*String*/ (_ba,BA.ObjectToString(_fname));
 }
};
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return "";
}
public static int[]  _convertsecondstocomponents(anywheresoftware.b4a.BA _ba,long _s) throws Exception{
int _numdays = 0;
int _numhours = 0;
int _numminutes = 0;
int _numseconds = 0;
 //BA.debugLineNum = 168;BA.debugLine="Private Sub ConvertSecondsToComponents(S As Long)";
 //BA.debugLineNum = 172;BA.debugLine="Dim NumDays As Int = S / 86400";
_numdays = (int) (_s/(double)86400);
 //BA.debugLineNum = 173;BA.debugLine="S = S - NumDays * 86400";
_s = (long) (_s-_numdays*86400);
 //BA.debugLineNum = 175;BA.debugLine="Dim NumHours As Int = S / 3600";
_numhours = (int) (_s/(double)3600);
 //BA.debugLineNum = 176;BA.debugLine="S = S - NumHours * 3600";
_s = (long) (_s-_numhours*3600);
 //BA.debugLineNum = 178;BA.debugLine="Dim NumMinutes As Int = S / 60";
_numminutes = (int) (_s/(double)60);
 //BA.debugLineNum = 179;BA.debugLine="S = S - NumMinutes * 60";
_s = (long) (_s-_numminutes*60);
 //BA.debugLineNum = 181;BA.debugLine="Dim NumSeconds As Int = S";
_numseconds = (int) (_s);
 //BA.debugLineNum = 182;BA.debugLine="Return Array As Int(NumDays, NumHours, NumMinutes";
if (true) return new int[]{_numdays,_numhours,_numminutes,_numseconds};
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return null;
}
public static String  _convertsecondstostring(anywheresoftware.b4a.BA _ba,String _str) throws Exception{
long _s = 0L;
int[] _tc = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 188;BA.debugLine="Public Sub ConvertSecondsToString(str As String) A";
 //BA.debugLineNum = 190;BA.debugLine="If IsNumber(str) = False Then";
if (anywheresoftware.b4a.keywords.Common.IsNumber(_str)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 191;BA.debugLine="If str = \"null\" Or str = \"-\" Then Return \"-\" '\"0";
if ((_str).equals("null") || (_str).equals("-")) { 
if (true) return "-";};
 //BA.debugLineNum = 192;BA.debugLine="Return str";
if (true) return _str;
 };
 //BA.debugLineNum = 195;BA.debugLine="Dim s As Long = str";
_s = (long)(Double.parseDouble(_str));
 //BA.debugLineNum = 197;BA.debugLine="Dim TC() As Int = ConvertSecondsToComponents(S)";
_tc = _convertsecondstocomponents(_ba,_s);
 //BA.debugLineNum = 198;BA.debugLine="Dim sb As StringBuilder : 	sb.Initialize";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 198;BA.debugLine="Dim sb As StringBuilder : 	sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 200;BA.debugLine="If TC(0) <> 0 Then 	'----  only add day if it is";
if (_tc[(int) (0)]!=0) { 
 //BA.debugLineNum = 201;BA.debugLine="sb.Append($\"${TC(0)}\"$)";
_sb.Append((""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_tc[(int) (0)]))+""));
 };
 //BA.debugLineNum = 203;BA.debugLine="If TC(1) <> 0 Then";
if (_tc[(int) (1)]!=0) { 
 //BA.debugLineNum = 204;BA.debugLine="sb.Append($\"${NumberFormat(TC(1),2,0)}:\"$)";
_sb.Append((""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(_tc[(int) (1)],(int) (2),(int) (0))))+":"));
 }else {
 //BA.debugLineNum = 206;BA.debugLine="sb.Append(\"00:\")";
_sb.Append("00:");
 };
 //BA.debugLineNum = 208;BA.debugLine="If TC(2) <> 0 Then";
if (_tc[(int) (2)]!=0) { 
 //BA.debugLineNum = 209;BA.debugLine="sb.Append($\"${NumberFormat(TC(2),2,0)}:\"$)";
_sb.Append((""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(_tc[(int) (2)],(int) (2),(int) (0))))+":"));
 }else {
 //BA.debugLineNum = 211;BA.debugLine="sb.Append(\"00:\")";
_sb.Append("00:");
 };
 //BA.debugLineNum = 213;BA.debugLine="If TC(3) <> 0 Then";
if (_tc[(int) (3)]!=0) { 
 //BA.debugLineNum = 214;BA.debugLine="sb.Append($\"${NumberFormat(TC(3),2,0)}\"$)";
_sb.Append((""+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.NumberFormat(_tc[(int) (3)],(int) (2),(int) (0))))+""));
 }else {
 //BA.debugLineNum = 216;BA.debugLine="sb.Append(\"00\")";
_sb.Append("00");
 };
 //BA.debugLineNum = 219;BA.debugLine="Return strHelpers.TrimLast(sb.ToString,\":\")";
if (true) return mostCurrent._strhelpers._trimlast /*String*/ (_ba,_sb.ToString(),":");
 //BA.debugLineNum = 221;BA.debugLine="End Sub";
return "";
}
public static String  _getfilenamefromhttp(anywheresoftware.b4a.BA _ba,String _url) throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="public Sub GetFilenameFromHTTP(URL As String) As S";
 //BA.debugLineNum = 159;BA.debugLine="Try";
try { //BA.debugLineNum = 160;BA.debugLine="Return URL.SubString2(URL.LastIndexOf(\"/\") + 1,U";
if (true) return _url.substring((int) (_url.lastIndexOf("/")+1),_url.length());
 } 
       catch (Exception e4) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e4); //BA.debugLineNum = 162;BA.debugLine="Return URL";
if (true) return _url;
 };
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static String  _gettxtlogfile(anywheresoftware.b4a.BA _ba) throws Exception{
sadLogic.OctoTouchController.wildcardfileslist _o1 = null;
anywheresoftware.b4a.objects.collections.List _lstfolder = null;
 //BA.debugLineNum = 15;BA.debugLine="Public Sub GetTxtLogFile() As String";
 //BA.debugLineNum = 17;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1 = new sadLogic.OctoTouchController.wildcardfileslist();
 //BA.debugLineNum = 17;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 18;BA.debugLine="Dim lstFolder As List = o1.GetFiles(xui.DefaultFo";
_lstfolder = new anywheresoftware.b4a.objects.collections.List();
_lstfolder = _o1._getfiles /*anywheresoftware.b4a.objects.collections.List*/ (_xui.getDefaultFolder(),"*.log",anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 19;BA.debugLine="If lstFolder.Size > 0 Then";
if (_lstfolder.getSize()>0) { 
 //BA.debugLineNum = 20;BA.debugLine="Return lstFolder.Get(0)";
if (true) return BA.ObjectToString(_lstfolder.Get((int) (0)));
 };
 //BA.debugLineNum = 22;BA.debugLine="Return \"\"";
if (true) return "";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static boolean  _isvalidipv4address(anywheresoftware.b4a.BA _ba,String _ipaddress) throws Exception{
 //BA.debugLineNum = 124;BA.debugLine="Public Sub IsValidIPv4Address(IPAddress As String)";
 //BA.debugLineNum = 126;BA.debugLine="Return Regex.IsMatch(\"^(([01]?\\d\\d?|2[0-4]\\d|25[0";
if (true) return anywheresoftware.b4a.keywords.Common.Regex.IsMatch("^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$",_ipaddress);
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return false;
}
public static boolean  _isvalidipv6address(anywheresoftware.b4a.BA _ba,String _ipaddress) throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Public Sub IsValidIPv6Address(IPAddress As String)";
 //BA.debugLineNum = 132;BA.debugLine="Return Regex.IsMatch(\"^([0-9a-f]{1,4}:){7}([0-9a-";
if (true) return anywheresoftware.b4a.keywords.Common.Regex.IsMatch("^([0-9a-f]{1,4}:){7}([0-9a-f]){1,4}$",_ipaddress);
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private mModule As String = \"fnc\"";
_mmodule = "fnc";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _processpowerflags(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Public Sub ProcessPowerFlags()";
 //BA.debugLineNum = 35;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"ProcessPowerF";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("28835842","ProcessPowerFlags()",0);};
 //BA.debugLineNum = 37;BA.debugLine="powerHelpers.ScreenON(config.AndroidTakeOverSleep";
mostCurrent._powerhelpers._screenon /*String*/ (_ba,mostCurrent._config._androidtakeoversleepflag /*boolean*/  && (mostCurrent._config._androidnotprintingscrnoffflag /*boolean*/  || mostCurrent._config._androidprintingscrnoffflag /*boolean*/ ));
 //BA.debugLineNum = 40;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
anywheresoftware.b4a.keywords.Common.CallSubNew((_ba.processBA == null ? _ba : _ba.processBA),(Object)(mostCurrent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 41;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
mostCurrent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(mostCurrent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public static boolean  _readconnectionfile(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.httpoctorestapi _cn) throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub ReadConnectionFile(cn As HttpOctoRestAP";
 //BA.debugLineNum = 48;BA.debugLine="oc.IsConnectionValid = False '--- assume bad";
mostCurrent._oc._isconnectionvalid /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 49;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.PRINTER";
if (anywheresoftware.b4a.keywords.Common.File.Exists(_xui.getDefaultFolder(),mostCurrent._gblconst._printer_setup_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 50;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 53;BA.debugLine="Dim m As Map = File.ReadMap(xui.DefaultFolder,gbl";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = anywheresoftware.b4a.keywords.Common.File.ReadMap(_xui.getDefaultFolder(),mostCurrent._gblconst._printer_setup_file /*String*/ );
 //BA.debugLineNum = 54;BA.debugLine="If m.IsInitialized = False Then Return False";
if (_m.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
if (true) return anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 55;BA.debugLine="oc.OctoIp     = m.Get( gblConst.PRINTER_IP)";
mostCurrent._oc._octoip /*String*/  = BA.ObjectToString(_m.Get((Object)(mostCurrent._gblconst._printer_ip /*String*/ )));
 //BA.debugLineNum = 56;BA.debugLine="oc.OctoKey = m.Get( gblConst.PRINTER_OCTO_KEY)";
mostCurrent._oc._octokey /*String*/  = BA.ObjectToString(_m.Get((Object)(mostCurrent._gblconst._printer_octo_key /*String*/ )));
 //BA.debugLineNum = 57;BA.debugLine="oc.OctoPort = m.Get( gblConst.PRINTER_PORT)";
mostCurrent._oc._octoport /*String*/  = BA.ObjectToString(_m.Get((Object)(mostCurrent._gblconst._printer_port /*String*/ )));
 //BA.debugLineNum = 59;BA.debugLine="If oc.OctoIp = \"\" Then";
if ((mostCurrent._oc._octoip /*String*/ ).equals("")) { 
 //BA.debugLineNum = 60;BA.debugLine="oc.IsConnectionValid = False";
mostCurrent._oc._isconnectionvalid /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 }else {
 //BA.debugLineNum = 62;BA.debugLine="cn.Initialize";
_cn._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 63;BA.debugLine="oc.IsConnectionValid = True";
mostCurrent._oc._isconnectionvalid /*boolean*/  = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 66;BA.debugLine="Return oc.IsConnectionValid";
if (true) return mostCurrent._oc._isconnectionvalid /*boolean*/ ;
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return false;
}
public static String  _roundjobpct(anywheresoftware.b4a.BA _ba,String _n) throws Exception{
 //BA.debugLineNum = 242;BA.debugLine="Public Sub RoundJobPct(n As String) As String";
 //BA.debugLineNum = 244;BA.debugLine="If IsNumber(n) Then";
if (anywheresoftware.b4a.keywords.Common.IsNumber(_n)) { 
 //BA.debugLineNum = 245;BA.debugLine="Return Round2(n,1).As(String) & \"%\"";
if (true) return (BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round2((double)(Double.parseDouble(_n)),(int) (1))))+"%";
 }else {
 //BA.debugLineNum = 247;BA.debugLine="Return \"-\"";
if (true) return "-";
 };
 //BA.debugLineNum = 250;BA.debugLine="End Sub";
return "";
}
public static String  _roundjobpctnodecimals(anywheresoftware.b4a.BA _ba,String _n) throws Exception{
 //BA.debugLineNum = 252;BA.debugLine="Public Sub RoundJobPctNoDecimals(n As String) As S";
 //BA.debugLineNum = 254;BA.debugLine="If IsNumber(n) Then";
if (anywheresoftware.b4a.keywords.Common.IsNumber(_n)) { 
 //BA.debugLineNum = 255;BA.debugLine="Return Round2(n,0).As(String) & \"%\"";
if (true) return (BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round2((double)(Double.parseDouble(_n)),(int) (0))))+"%";
 }else {
 //BA.debugLineNum = 257;BA.debugLine="Return \"-\"";
if (true) return "-";
 };
 //BA.debugLineNum = 260;BA.debugLine="End Sub";
return "";
}
}
