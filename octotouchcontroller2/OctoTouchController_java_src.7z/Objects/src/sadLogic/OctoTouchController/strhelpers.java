package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class strhelpers {
private static strhelpers mostCurrent = new strhelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4a.objects.collections.List  _cleanuppuncchar(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
int _x = 0;
String _ch = "";
String _a1 = "";
 //BA.debugLineNum = 105;BA.debugLine="Private Sub CleanupPuncChar(lst As List) As List";
 //BA.debugLineNum = 111;BA.debugLine="Try";
try { //BA.debugLineNum = 112;BA.debugLine="For x = 0 To lst.Size - 1";
{
final int step2 = 1;
final int limit2 = (int) (_lst.getSize()-1);
_x = (int) (0) ;
for (;_x <= limit2 ;_x = _x + step2 ) {
 //BA.debugLineNum = 113;BA.debugLine="For Each ch As String In Array As String(\".\",\",";
{
final String[] group3 = new String[]{".",",",":",";","?","!"};
final int groupLen3 = group3.length
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_ch = group3[index3];
 //BA.debugLineNum = 114;BA.debugLine="If lst.Get(x) = ch Then";
if ((_lst.Get(_x)).equals((Object)(_ch))) { 
 //BA.debugLineNum = 115;BA.debugLine="Dim a1 As String = lst.Get(x-1)";
_a1 = BA.ObjectToString(_lst.Get((int) (_x-1)));
 //BA.debugLineNum = 116;BA.debugLine="lst.Set(x-1,a1 & ch)";
_lst.Set((int) (_x-1),(Object)(_a1+_ch));
 //BA.debugLineNum = 117;BA.debugLine="lst.Set(x,\"\")";
_lst.Set(_x,(Object)(""));
 };
 }
};
 }
};
 } 
       catch (Exception e12) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e12); //BA.debugLineNum = 122;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("62783505",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 //BA.debugLineNum = 124;BA.debugLine="Return lst";
if (true) return _lst;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return null;
}
public static String  _convertlinuxlineendings2windows(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="public Sub ConvertLinuxLineEndings2Windows(s As St";
 //BA.debugLineNum = 12;BA.debugLine="Return s.Replace(Chr(10),Chr(13) & Chr(10))";
if (true) return _s.replace(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10))));
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public static boolean  _isnullorempty(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Public Sub IsNullOrEmpty(s As String) As Boolean";
 //BA.debugLineNum = 145;BA.debugLine="Return s = Null Or s.CompareTo(Null) = 0 Or s = \"";
if (true) return _s== null || _s.compareTo(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Null))==0 || (_s).equals("");
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return false;
}
public static String  _join(anywheresoftware.b4a.BA _ba,String _sepchar,anywheresoftware.b4a.objects.collections.List _strings) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _s = "";
 //BA.debugLineNum = 26;BA.debugLine="public Sub Join(sepChar As String, Strings As List";
 //BA.debugLineNum = 28;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 29;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 31;BA.debugLine="For Each s As String In Strings";
{
final anywheresoftware.b4a.BA.IterableList group3 = _strings;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_s = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 32;BA.debugLine="sb.Append(s).Append(sepChar)";
_sb.Append(_s).Append(_sepchar);
 }
};
 //BA.debugLineNum = 35;BA.debugLine="If sb.Length > 0 Then";
if (_sb.getLength()>0) { 
 //BA.debugLineNum = 36;BA.debugLine="sb.Remove(sb.Length - sepChar.Length, sb.Length)";
_sb.Remove((int) (_sb.getLength()-_sepchar.length()),_sb.getLength());
 };
 //BA.debugLineNum = 39;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"strHelper\" 'ig";
_mmodule = "strHelper";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _propercase(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
int _i = 0;
 //BA.debugLineNum = 15;BA.debugLine="Public Sub ProperCase(s As String) As String";
 //BA.debugLineNum = 16;BA.debugLine="s = s.ToLowerCase";
_s = _s.toLowerCase();
 //BA.debugLineNum = 17;BA.debugLine="Dim m As Matcher = Regex.Matcher(\"\\b(\\w)\", s)";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = anywheresoftware.b4a.keywords.Common.Regex.Matcher("\\b(\\w)",_s);
 //BA.debugLineNum = 18;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 19;BA.debugLine="Dim i As Int = m.GetStart(1)";
_i = _m.GetStart((int) (1));
 //BA.debugLineNum = 20;BA.debugLine="s = s.SubString2(0, i) & s.SubString2(i, i + 1).";
_s = _s.substring((int) (0),_i)+_s.substring(_i,(int) (_i+1)).toUpperCase()+_s.substring((int) (_i+1));
 }
;
 //BA.debugLineNum = 22;BA.debugLine="Return s";
if (true) return _s;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public static boolean  _str2bool(anywheresoftware.b4a.BA _ba,String _txt) throws Exception{
String _tmp = "";
 //BA.debugLineNum = 55;BA.debugLine="public Sub Str2Bool(txt As String) As Boolean";
 //BA.debugLineNum = 57;BA.debugLine="Try";
try { //BA.debugLineNum = 58;BA.debugLine="Dim tmp As String = txt.ToLowerCase.Trim";
_tmp = _txt.toLowerCase().trim();
 //BA.debugLineNum = 59;BA.debugLine="If tmp = \"false\" Then Return False";
if ((_tmp).equals("false")) { 
if (true) return anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 60;BA.debugLine="If tmp = \"true\"  Then Return True";
if ((_tmp).equals("true")) { 
if (true) return anywheresoftware.b4a.keywords.Common.True;};
 //BA.debugLineNum = 61;BA.debugLine="If (IsNumber(tmp)) And tmp <> \"0\" Then Return Tr";
if ((anywheresoftware.b4a.keywords.Common.IsNumber(_tmp)) && (_tmp).equals("0") == false) { 
if (true) return anywheresoftware.b4a.keywords.Common.True;};
 } 
       catch (Exception e7) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e7); };
 //BA.debugLineNum = 66;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return false;
}
public static String  _striphtml(anywheresoftware.b4a.BA _ba,String _txt) throws Exception{
String[] _parts = null;
int _x = 0;
 //BA.debugLineNum = 129;BA.debugLine="Public Sub StripHTML(txt As String) As String";
 //BA.debugLineNum = 130;BA.debugLine="Dim parts() As String = Regex.Split(\">\",txt)";
_parts = anywheresoftware.b4a.keywords.Common.Regex.Split(">",_txt);
 //BA.debugLineNum = 131;BA.debugLine="txt = \"\"";
_txt = "";
 //BA.debugLineNum = 132;BA.debugLine="For x = 0 To parts.Length -1";
{
final int step3 = 1;
final int limit3 = (int) (_parts.length-1);
_x = (int) (0) ;
for (;_x <= limit3 ;_x = _x + step3 ) {
 //BA.debugLineNum = 133;BA.debugLine="If parts(x).IndexOf(\"<\")>-1 Then";
if (_parts[_x].indexOf("<")>-1) { 
 //BA.debugLineNum = 134;BA.debugLine="txt = txt & parts(x).SubString2(0,parts(x).Inde";
_txt = _txt+_parts[_x].substring((int) (0),_parts[_x].indexOf("<"));
 }else {
 //BA.debugLineNum = 136;BA.debugLine="txt = txt & parts(x)";
_txt = _txt+_parts[_x];
 };
 }
};
 //BA.debugLineNum = 139;BA.debugLine="Return txt";
if (true) return _txt;
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public static String  _trimlast(anywheresoftware.b4a.BA _ba,String _s,String _trimchar) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="public Sub TrimLast(s As String, trimchar As Strin";
 //BA.debugLineNum = 46;BA.debugLine="If s.EndsWith(trimchar) Then";
if (_s.endsWith(_trimchar)) { 
 //BA.debugLineNum = 47;BA.debugLine="Return s.SubString2(0,s.Length - 1)";
if (true) return _s.substring((int) (0),(int) (_s.length()-1));
 }else {
 //BA.debugLineNum = 49;BA.debugLine="Return s";
if (true) return _s;
 };
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public static String  _wordwrap(anywheresoftware.b4a.BA _ba,String _txt,int _linelen) throws Exception{
anywheresoftware.b4a.objects.collections.List _wordlist = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _word = "";
int _currlinesize = 0;
int _wordlistlen = 0;
int _wordptr = 0;
 //BA.debugLineNum = 72;BA.debugLine="Public Sub WordWrap(txt As String, lineLen As Int)";
 //BA.debugLineNum = 73;BA.debugLine="Dim wordList As List : wordList.Initialize";
_wordlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 73;BA.debugLine="Dim wordList As List : wordList.Initialize";
_wordlist.Initialize();
 //BA.debugLineNum = 74;BA.debugLine="wordList = CleanupPuncChar(Regex.Split(\"\\b\", txt)";
_wordlist = _cleanuppuncchar(_ba,anywheresoftware.b4a.keywords.Common.ArrayToList(anywheresoftware.b4a.keywords.Common.Regex.Split("\\b",_txt)));
 //BA.debugLineNum = 76;BA.debugLine="Dim sb As StringBuilder :  sb.Initialize";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 76;BA.debugLine="Dim sb As StringBuilder :  sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 77;BA.debugLine="Dim word As String, CurrLineSize = 0 As Int";
_word = "";
_currlinesize = (int) (0);
 //BA.debugLineNum = 78;BA.debugLine="Dim wordListLen As Int = wordList.size - 1";
_wordlistlen = (int) (_wordlist.getSize()-1);
 //BA.debugLineNum = 80;BA.debugLine="For wordPtr = 0 To wordListLen";
{
final int step8 = 1;
final int limit8 = _wordlistlen;
_wordptr = (int) (0) ;
for (;_wordptr <= limit8 ;_wordptr = _wordptr + step8 ) {
 //BA.debugLineNum = 82;BA.debugLine="word = wordList.Get(wordPtr).As(String).Trim";
_word = (BA.ObjectToString(_wordlist.Get(_wordptr))).trim();
 //BA.debugLineNum = 83;BA.debugLine="If word.Length = 0 Then Continue";
if (_word.length()==0) { 
if (true) continue;};
 //BA.debugLineNum = 84;BA.debugLine="If sb.Length = 0 Then";
if (_sb.getLength()==0) { 
 //BA.debugLineNum = 85;BA.debugLine="sb.Append(word).Append(\" \")";
_sb.Append(_word).Append(" ");
 //BA.debugLineNum = 86;BA.debugLine="Continue";
if (true) continue;
 };
 //BA.debugLineNum = 89;BA.debugLine="If wordPtr < wordListLen  Then";
if (_wordptr<_wordlistlen) { 
 //BA.debugLineNum = 90;BA.debugLine="If CurrLineSize + wordList.Get(wordPtr + 1).As(";
if (_currlinesize+(BA.ObjectToString(_wordlist.Get((int) (_wordptr+1)))).length()<_linelen) { 
 //BA.debugLineNum = 91;BA.debugLine="sb.Append(word).Append(\" \")";
_sb.Append(_word).Append(" ");
 //BA.debugLineNum = 92;BA.debugLine="CurrLineSize = CurrLineSize + word.Length + 1";
_currlinesize = (int) (_currlinesize+_word.length()+1);
 }else {
 //BA.debugLineNum = 94;BA.debugLine="sb.Append(word).Append(CRLF)";
_sb.Append(_word).Append(anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 95;BA.debugLine="CurrLineSize = 0";
_currlinesize = (int) (0);
 };
 }else {
 //BA.debugLineNum = 98;BA.debugLine="sb.Append(word)";
_sb.Append(_word);
 };
 }
};
 //BA.debugLineNum = 102;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
}
