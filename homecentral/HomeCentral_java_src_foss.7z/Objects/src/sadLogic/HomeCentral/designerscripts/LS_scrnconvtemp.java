package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_scrnconvtemp{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padtb="";
String _padlr="";
String _txth="";
String _lblh="";
String _buffer="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
_padtb = BA.NumberToString((30d * scale));
_padlr = BA.NumberToString((60d * scale));
_txth = BA.NumberToString((58d * scale));
_lblh = BA.NumberToString((46d * scale));
_buffer = BA.NumberToString((100d / 100 * width)/4d);
views.get("pnltemp").vw.setLeft((int)(0d));
views.get("pnltemp").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnltemp").vw.setTop((int)(0d));
views.get("pnltemp").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("lblf").vw.setTop((int)(Double.parseDouble(_padtb)+Double.parseDouble(_buffer)));
views.get("lblf").vw.setHeight((int)(Double.parseDouble(_lblh)+Double.parseDouble(_padtb)+Double.parseDouble(_buffer) - (Double.parseDouble(_padtb)+Double.parseDouble(_buffer))));
views.get("lblf").vw.setLeft((int)(Double.parseDouble(_padlr)));
views.get("lblf").vw.setWidth((int)((views.get("pnltemp").vw.getWidth())-Double.parseDouble(_padlr) - (Double.parseDouble(_padlr))));
views.get("txtf").vw.setTop((int)((views.get("lblf").vw.getTop() + views.get("lblf").vw.getHeight())));
views.get("txtf").vw.setHeight((int)((views.get("lblf").vw.getTop() + views.get("lblf").vw.getHeight())+Double.parseDouble(_txth) - ((views.get("lblf").vw.getTop() + views.get("lblf").vw.getHeight()))));
views.get("txtf").vw.setLeft((int)(Double.parseDouble(_padlr)));
views.get("txtf").vw.setWidth((int)((views.get("pnltemp").vw.getWidth())-Double.parseDouble(_padlr) - (Double.parseDouble(_padlr))));
views.get("lblc").vw.setTop((int)((views.get("txtf").vw.getTop() + views.get("txtf").vw.getHeight())+Double.parseDouble(_padtb)));
views.get("lblc").vw.setHeight((int)((views.get("txtf").vw.getTop() + views.get("txtf").vw.getHeight())+Double.parseDouble(_lblh)+Double.parseDouble(_padtb) - ((views.get("txtf").vw.getTop() + views.get("txtf").vw.getHeight())+Double.parseDouble(_padtb))));
views.get("lblc").vw.setLeft((int)(Double.parseDouble(_padlr)));
views.get("lblc").vw.setWidth((int)((views.get("pnltemp").vw.getWidth())-Double.parseDouble(_padlr) - (Double.parseDouble(_padlr))));
views.get("txtc").vw.setTop((int)((views.get("lblc").vw.getTop() + views.get("lblc").vw.getHeight())));
views.get("txtc").vw.setHeight((int)((views.get("lblc").vw.getTop() + views.get("lblc").vw.getHeight())+Double.parseDouble(_txth) - ((views.get("lblc").vw.getTop() + views.get("lblc").vw.getHeight()))));
views.get("txtc").vw.setLeft((int)(Double.parseDouble(_padlr)));
views.get("txtc").vw.setWidth((int)((views.get("pnltemp").vw.getWidth())-Double.parseDouble(_padlr) - (Double.parseDouble(_padlr))));

}
}