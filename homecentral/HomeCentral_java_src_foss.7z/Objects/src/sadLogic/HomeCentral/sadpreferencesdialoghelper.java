package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadpreferencesdialoghelper extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.sadpreferencesdialoghelper");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.sadpreferencesdialoghelper.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.sadpreferencesdialog _prefdlg = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public float _pdefaultfontsize = 0f;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private prefdlg As sadPreferencesDialog";
_prefdlg = new sadLogic.HomeCentral.sadpreferencesdialog();
 //BA.debugLineNum = 13;BA.debugLine="Public dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 14;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 15;BA.debugLine="Public pDefaultFontSize As Float = 19";
_pdefaultfontsize = (float) (19);
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.sadpreferencesdialog _oprefdlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(oPrefDlg As sadPreferencesDi";
 //BA.debugLineNum = 19;BA.debugLine="prefdlg = oPrefDlg";
_prefdlg = _oprefdlg;
 //BA.debugLineNum = 20;BA.debugLine="dlg = prefdlg.Dialog";
_dlg = _prefdlg._dialog /*sadLogic.HomeCentral.b4xdialog*/ ;
 //BA.debugLineNum = 21;BA.debugLine="dlgHelper.Initialize(dlg)";
_dlghelper._initialize /*String*/ (ba,_dlg);
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _map2disk2(String _folder,String _filename,anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Map2Disk2(folder As String, filename As";
 //BA.debugLineNum = 26;BA.debugLine="Dim ser As B4XSerializator '--- in the RandomAcce";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 27;BA.debugLine="File.WriteBytes(folder, filename, ser.ConvertObje";
__c.File.WriteBytes(_folder,_filename,_ser.ConvertObjectToBytes((Object)(_m.getObject())));
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _mapfromdisk2(String _folder,String _filename) throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
 //BA.debugLineNum = 30;BA.debugLine="Public Sub MapFromDisk2(folder As String, filename";
 //BA.debugLineNum = 31;BA.debugLine="Dim ser As B4XSerializator '--- in the RandomAcce";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 32;BA.debugLine="Return ser.ConvertBytesToObject(File.ReadBytes(fo";
if (true) return (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_ser.ConvertBytesToObject(__c.File.ReadBytes(_folder,_filename))));
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _skindialog(Object _template) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _fnt0 = null;
int _i = 0;
sadLogic.HomeCentral.preferencesdialog._b4xprefitem _pit = null;
sadLogic.HomeCentral.b4xfloattextfield _ft = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
sadLogic.HomeCentral.b4xplusminus _plmi = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p1 = null;
 //BA.debugLineNum = 81;BA.debugLine="Public Sub SkinDialog(Template As Object)";
 //BA.debugLineNum = 83;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
_dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 85;BA.debugLine="Dim fnt0 As B4XFont = xui.CreateDefaultFont(pDefa";
_fnt0 = _xui.CreateDefaultFont(_pdefaultfontsize);
 //BA.debugLineNum = 87;BA.debugLine="Try";
try { //BA.debugLineNum = 89;BA.debugLine="For i = 0 To prefdlg.PrefItems.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_prefdlg._prefitems /*anywheresoftware.b4a.objects.collections.List*/ .getSize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 90;BA.debugLine="Dim pit As B4XPrefItem = prefdlg.PrefItems.Get(";
_pit = (sadLogic.HomeCentral.preferencesdialog._b4xprefitem)(_prefdlg._prefitems /*anywheresoftware.b4a.objects.collections.List*/ .Get(_i));
 //BA.debugLineNum = 92;BA.debugLine="Select Case pit.ItemType";
switch (BA.switchObjectToInt(_pit.ItemType /*int*/ ,_prefdlg._type_text /*int*/ ,_prefdlg._type_password /*int*/ ,_prefdlg._type_number /*int*/ ,_prefdlg._type_decimalnumber /*int*/ ,_prefdlg._type_multilinetext /*int*/ ,_prefdlg._type_boolean /*int*/ ,_prefdlg._type_numericrange /*int*/ ,_prefdlg._type_time /*int*/ )) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: {
 //BA.debugLineNum = 94;BA.debugLine="Dim ft As B4XFloatTextField = prefdlg.CustomL";
_ft = (sadLogic.HomeCentral.b4xfloattextfield)(_prefdlg._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).GetView((int) (0)).getTag());
 //BA.debugLineNum = 95;BA.debugLine="ft.TextField.Font = fnt0";
_ft._gettextfield /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setFont(_fnt0);
 //BA.debugLineNum = 96;BA.debugLine="guiHelpers.SetTextColorB4XFloatTextField(Arra";
_guihelpers._settextcolorb4xfloattextfield /*String*/ (ba,new sadLogic.HomeCentral.b4xfloattextfield[]{_ft});
 break; }
case 5: {
 //BA.debugLineNum = 99;BA.debugLine="Dim p As B4XView = prefdlg.CustomListView1.Ge";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _prefdlg._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).GetView((int) (0));
 //BA.debugLineNum = 100;BA.debugLine="p.Font = fnt0";
_p.setFont(_fnt0);
 break; }
case 6: {
 //BA.debugLineNum = 103;BA.debugLine="Dim plmi As B4XPlusMinus = prefdlg.CustomList";
_plmi = (sadLogic.HomeCentral.b4xplusminus)(_prefdlg._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).GetView((int) (0)).getTag());
 //BA.debugLineNum = 104;BA.debugLine="plmi.MainLabel.Font = xui.CreateDefaultFont(2";
_plmi._mainlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setFont(_xui.CreateDefaultFont((float) (22)));
 //BA.debugLineNum = 105;BA.debugLine="Dim p1 As B4XView = prefdlg.CustomListView1.G";
_p1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p1 = _prefdlg._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).GetView((int) (1));
 //BA.debugLineNum = 106;BA.debugLine="p1.Font = fnt0";
_p1.setFont(_fnt0);
 break; }
case 7: {
 //BA.debugLineNum = 116;BA.debugLine="prefdlg.CustomListView1.GetPanel(i).GetView(3";
_prefdlg._customlistview1 /*b4a.example3.customlistview*/ ._getpanel(_i).GetView((int) (3)).setFont(_fnt0);
 break; }
}
;
 }
};
 } 
       catch (Exception e24) {
			ba.setLastException(e24); //BA.debugLineNum = 133;BA.debugLine="Log(LastException)";
__c.LogImpl("59637812",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public String  _themeprefdialogform() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Public Sub ThemePrefDialogForm";
 //BA.debugLineNum = 39;BA.debugLine="Try";
try { //BA.debugLineNum = 41;BA.debugLine="prefdlg.ItemsBackgroundColor = clrTheme.Backgrou";
_prefdlg._itemsbackgroundcolor /*int*/  = _clrtheme._background /*int*/ ;
 //BA.debugLineNum = 42;BA.debugLine="prefdlg.SeparatorBackgroundColor = clrTheme.Back";
_prefdlg._separatorbackgroundcolor /*int*/  = _clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 43;BA.debugLine="prefdlg.SeparatorTextColor = clrTheme.txtAccent";
_prefdlg._separatortextcolor /*int*/  = _clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 44;BA.debugLine="prefdlg.TextColor = clrTheme.txtNormal";
_prefdlg._textcolor /*int*/  = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 57;BA.debugLine="dlgHelper.ThemeDialogForm(prefdlg.Title.As(Strin";
_dlghelper._themedialogform /*String*/ ((Object)((BA.ObjectToString(_prefdlg._gettitle /*Object*/ ()))));
 } 
       catch (Exception e8) {
			ba.setLastException(e8); //BA.debugLineNum = 60;BA.debugLine="Log(LastException)";
__c.LogImpl("59572247",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
