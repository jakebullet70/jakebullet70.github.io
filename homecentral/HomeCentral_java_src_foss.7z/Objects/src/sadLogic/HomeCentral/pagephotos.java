package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagephotos extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pagephotos");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pagephotos.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.HomeCentral.lmb4ximageviewx _img = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbtns = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnstart = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnfullscrn = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnnext = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnprev = null;
public b4a.example3.customlistview _lvpics = null;
public sadLogic.HomeCentral.preoptimizedclv _pclv = null;
public anywheresoftware.b4a.objects.Timer _tmrpicshow = null;
public anywheresoftware.b4a.objects.collections.List _lstpics = null;
public String _picpath = "";
public int _picpointer = 0;
public int _lvpointerhigh = 0;
public int _lvpointerlow = 0;
public sadLogic.HomeCentral.lmb4ximageviewx _lmb4ximageviewx1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public void  _btnpressed_click() throws Exception{
ResumableSub_btnPressed_Click rsub = new ResumableSub_btnPressed_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnPressed_Click extends BA.ResumableSub {
public ResumableSub_btnPressed_Click(sadLogic.HomeCentral.pagephotos parent) {
this.parent = parent;
}
sadLogic.HomeCentral.pagephotos parent;
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
sadLogic.HomeCentral.prompt4folder _oo = null;
String _f = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 190;BA.debugLine="Dim b As Button = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 191;BA.debugLine="Log(\"btn tag --> \" & b.Tag)";
parent.__c.LogImpl("45023236","btn tag --> "+BA.ObjectToString(_b.getTag()),0);
 //BA.debugLineNum = 192;BA.debugLine="Return";
if (true) return ;
 //BA.debugLineNum = 196;BA.debugLine="Select Case b.Tag 'IGNORE";
if (true) break;

case 1:
//select
this.state = 14;
switch (BA.switchObjectToInt(_b.getTag(),(Object)("n"),(Object)("p"),(Object)("ss"),(Object)("f"))) {
case 0: {
this.state = 3;
if (true) break;
}
case 1: {
this.state = 5;
if (true) break;
}
case 2: {
this.state = 11;
if (true) break;
}
case 3: {
this.state = 13;
if (true) break;
}
}
if (true) break;

case 3:
//C
this.state = 14;
 //BA.debugLineNum = 198;BA.debugLine="NextPic";
parent._nextpic();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 201;BA.debugLine="picPointer = picPointer - 1";
parent._picpointer = (int) (parent._picpointer-1);
 //BA.debugLineNum = 202;BA.debugLine="If picPointer < 0 Then";
if (true) break;

case 6:
//if
this.state = 9;
if (parent._picpointer<0) { 
this.state = 8;
}if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 203;BA.debugLine="picPointer = (lstPics.Size -1)";
parent._picpointer = (int) ((parent._lstpics.getSize()-1));
 if (true) break;

case 9:
//C
this.state = 14;
;
 //BA.debugLineNum = 205;BA.debugLine="ShowPic(picPointer,lstPics.Get(picPointer))";
parent._showpic(parent._picpointer,BA.ObjectToString(parent._lstpics.Get(parent._picpointer)));
 if (true) break;

case 11:
//C
this.state = 14;
 //BA.debugLineNum = 208;BA.debugLine="lvPics.AsView.Visible = False";
parent._lvpics._asview().setVisible(parent.__c.False);
 //BA.debugLineNum = 209;BA.debugLine="img.mBase.Visible = True";
parent._img._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(parent.__c.True);
 //BA.debugLineNum = 210;BA.debugLine="tmrPicShow.Enabled = True";
parent._tmrpicshow.setEnabled(parent.__c.True);
 //BA.debugLineNum = 211;BA.debugLine="ShowPic(picPointer,lstPics.Get(picPointer))";
parent._showpic(parent._picpointer,BA.ObjectToString(parent._lstpics.Get(parent._picpointer)));
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 215;BA.debugLine="guiHelpers.Show_toast(\"TODO\")";
parent._guihelpers._show_toast /*String*/ (ba,"TODO");
 //BA.debugLineNum = 216;BA.debugLine="Return";
if (true) return ;
 //BA.debugLineNum = 218;BA.debugLine="Dim oo As Prompt4Folder'ignore";
_oo = new sadLogic.HomeCentral.prompt4folder();
 //BA.debugLineNum = 219;BA.debugLine="oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 220;BA.debugLine="oo.SelectExtFolder(Me)";
_oo._selectextfolder /*void*/ (parent);
 //BA.debugLineNum = 221;BA.debugLine="Wait For Selected_Folder(f As String)";
parent.__c.WaitFor("selected_folder", ba, this, null);
this.state = 15;
return;
case 15:
//C
this.state = 14;
_f = (String) result[0];
;
 //BA.debugLineNum = 222;BA.debugLine="Log(\"OK --> \" & oo.pSelectedFolder)";
parent.__c.LogImpl("45023267","OK --> "+_oo._pselectedfolder /*String*/ ,0);
 if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 225;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _selected_folder(String _f) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 10;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private img As lmB4XImageViewX";
_img = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 14;BA.debugLine="Private pnlBtns As Panel";
_pnlbtns = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private btnStart,btnFullScrn,btnNext,btnPrev As B";
_btnstart = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnfullscrn = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnnext = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnprev = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lvPics As CustomListView";
_lvpics = new b4a.example3.customlistview();
 //BA.debugLineNum = 18;BA.debugLine="Private PCLV As PreoptimizedCLV";
_pclv = new sadLogic.HomeCentral.preoptimizedclv();
 //BA.debugLineNum = 19;BA.debugLine="Public tmrPicShow As Timer";
_tmrpicshow = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 21;BA.debugLine="Private lstPics As List";
_lstpics = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 22;BA.debugLine="Private picPath As String = \"/Removable/MicroSD/p";
_picpath = "/Removable/MicroSD/pics";
 //BA.debugLineNum = 24;BA.debugLine="Private picPointer As Int = 1";
_picpointer = (int) (1);
 //BA.debugLineNum = 25;BA.debugLine="Private lvPointerHigh,lvPointerLow As Int 'ignore";
_lvpointerhigh = 0;
_lvpointerlow = 0;
 //BA.debugLineNum = 27;BA.debugLine="Private img As lmB4XImageViewX";
_img = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 28;BA.debugLine="Private lmB4XImageViewX1 As lmB4XImageViewX";
_lmb4ximageviewx1 = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 29;BA.debugLine="Private pnlSplitter As B4XView";
_pnlsplitter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _img_click() throws Exception{
 //BA.debugLineNum = 171;BA.debugLine="Private Sub img_Click";
 //BA.debugLineNum = 172;BA.debugLine="Log(\"img_Click\")";
__c.LogImpl("44892161","img_Click",0);
 //BA.debugLineNum = 173;BA.debugLine="lvPics.AsView.Visible = True";
_lvpics._asview().setVisible(__c.True);
 //BA.debugLineNum = 174;BA.debugLine="img.mBase.Visible = False";
_img._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 175;BA.debugLine="lvPics.JumpToItem(picPointer) '--- keep the ListV";
_lvpics._jumptoitem(_picpointer);
 //BA.debugLineNum = 176;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
float _size = 0f;
int _x = 0;
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 35;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 36;BA.debugLine="pnlMain.LoadLayout(\"pagePhotosBase\")";
_pnlmain.LoadLayout("pagePhotosBase",ba);
 //BA.debugLineNum = 38;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnStart,bt";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnstart,_btnfullscrn,_btnnext,_btnprev});
 //BA.debugLineNum = 39;BA.debugLine="guiHelpers.SetPanelsDividers(Array As B4XView(pnl";
_guihelpers._setpanelsdividers /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_pnlsplitter},_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 41;BA.debugLine="tmrPicShow.Initialize(\"tmrShow\",8000)";
_tmrpicshow.Initialize(ba,"tmrShow",(long) (8000));
 //BA.debugLineNum = 42;BA.debugLine="tmrPicShow.Enabled = False";
_tmrpicshow.setEnabled(__c.False);
 //BA.debugLineNum = 44;BA.debugLine="pnlBtns.Visible = True";
_pnlbtns.setVisible(__c.True);
 //BA.debugLineNum = 46;BA.debugLine="ScanPics";
_scanpics();
 //BA.debugLineNum = 48;BA.debugLine="lvPics.AsView.Color = XUI.Color_Transparent";
_lvpics._asview().setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 49;BA.debugLine="img.Bitmap = LoadBitmapResize(File.DirAssets,\"pfr";
_img._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapResize(__c.File.getDirAssets(),"pframe.png",(int) (_img._getwidth /*double*/ ()),(int) (_img._getheight /*double*/ ()),__c.False).getObject())));
 //BA.debugLineNum = 50;BA.debugLine="PCLV.Initialize(Me, \"PCLV\", lvPics)";
_pclv._initialize /*String*/ (ba,this,"PCLV",_lvpics);
 //BA.debugLineNum = 51;BA.debugLine="PCLV.ShowScrollBar = False";
_pclv._showscrollbar /*boolean*/  = __c.False;
 //BA.debugLineNum = 52;BA.debugLine="Dim size As Float = lvPics.AsView.Height";
_size = (float) (_lvpics._asview().getHeight());
 //BA.debugLineNum = 53;BA.debugLine="For x = 0 To lstPics.Size - 1";
{
final int step14 = 1;
final int limit14 = (int) (_lstpics.getSize()-1);
_x = (int) (0) ;
for (;_x <= limit14 ;_x = _x + step14 ) {
 //BA.debugLineNum = 54;BA.debugLine="PCLV.AddItem(size, XUI.Color_Transparent, x & \":";
_pclv._additem /*String*/ ((int) (_size),_xui.Color_Transparent,(Object)(BA.NumberToString(_x)+"::"+BA.ObjectToString(_lstpics.Get(_x))));
 }
};
 //BA.debugLineNum = 56;BA.debugLine="PCLV.Commit";
_pclv._commit /*String*/ ();
 //BA.debugLineNum = 57;BA.debugLine="img.mBase.Visible = False";
_img._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _lmb4ximageviewx1_click() throws Exception{
sadLogic.HomeCentral.lmb4ximageviewx _o = null;
 //BA.debugLineNum = 141;BA.debugLine="Private Sub lmB4XImageViewX1_Click";
 //BA.debugLineNum = 142;BA.debugLine="Dim o As lmB4XImageViewX = Sender";
_o = (sadLogic.HomeCentral.lmb4ximageviewx)(__c.Sender(ba));
 //BA.debugLineNum = 143;BA.debugLine="lvPics.AsView.Visible = False";
_lvpics._asview().setVisible(__c.False);
 //BA.debugLineNum = 144;BA.debugLine="img.mBase.Visible = True";
_img._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 145;BA.debugLine="tmrPicShow.Enabled = False";
_tmrpicshow.setEnabled(__c.False);
 //BA.debugLineNum = 146;BA.debugLine="ShowPic(Regex.Split(\"::\",o.Tag)(0),Regex.Split(\":";
_showpic((int)(Double.parseDouble(__c.Regex.Split("::",BA.ObjectToString(_o._tag /*Object*/ ))[(int) (0)])),__c.Regex.Split("::",BA.ObjectToString(_o._tag /*Object*/ ))[(int) (1)]);
 //BA.debugLineNum = 147;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 69;BA.debugLine="tmrPicShow.Enabled = False";
_tmrpicshow.setEnabled(__c.False);
 //BA.debugLineNum = 70;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public String  _lvpics_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Private Sub lvPics_ItemClick (Index As Int, Value";
 //BA.debugLineNum = 134;BA.debugLine="lvPics.AsView.Visible = False";
_lvpics._asview().setVisible(__c.False);
 //BA.debugLineNum = 135;BA.debugLine="img.mBase.Visible = True";
_img._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 137;BA.debugLine="ShowPic(Index,Regex.Split(\"::\",Value)(1))";
_showpic(_index,__c.Regex.Split("::",BA.ObjectToString(_value))[(int) (1)]);
 //BA.debugLineNum = 138;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return "";
}
public String  _lvpics_visiblerangechanged(int _firstindex,int _lastindex) throws Exception{
int _i = 0;
b4a.example3.customlistview._clvitem _item = null;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
 //BA.debugLineNum = 87;BA.debugLine="Sub  lvPics_VisibleRangeChanged (FirstIndex As Int";
 //BA.debugLineNum = 88;BA.debugLine="For Each i As Int In PCLV.VisibleRangeChanged(Fir";
{
final anywheresoftware.b4a.BA.IterableList group1 = _pclv._visiblerangechanged /*anywheresoftware.b4a.objects.collections.List*/ (_firstindex,_lastindex);
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_i = (int)(BA.ObjectToNumber(group1.Get(index1)));
 //BA.debugLineNum = 89;BA.debugLine="Dim item As CLVItem = lvPics.GetRawListItem(i)";
_item = _lvpics._getrawlistitem(_i);
 //BA.debugLineNum = 90;BA.debugLine="Dim pnl As B4XView = XUI.CreatePanel(\"\")";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 91;BA.debugLine="item.Panel.AddView(pnl, 0, 0, item.Panel.Width,";
_item.Panel.AddView((android.view.View)(_pnl.getObject()),(int) (0),(int) (0),_item.Panel.getWidth(),_item.Panel.getHeight());
 //BA.debugLineNum = 92;BA.debugLine="pnl.LoadLayout(\"viewPhotoItem\")";
_pnl.LoadLayout("viewPhotoItem",ba);
 //BA.debugLineNum = 93;BA.debugLine="lmB4XImageViewX1.Load(picPath, lstPics.Get(i))";
_lmb4ximageviewx1._load /*String*/ (_picpath,BA.ObjectToString(_lstpics.Get(_i)));
 //BA.debugLineNum = 94;BA.debugLine="lmB4XImageViewX1.Tag = i & \"::\" & lstPics.Get(i)";
_lmb4ximageviewx1._tag /*Object*/  = (Object)(BA.NumberToString(_i)+"::"+BA.ObjectToString(_lstpics.Get(_i)));
 }
};
 //BA.debugLineNum = 97;BA.debugLine="lvPointerLow  = FirstIndex";
_lvpointerlow = _firstindex;
 //BA.debugLineNum = 98;BA.debugLine="lvPointerHigh = LastIndex";
_lvpointerhigh = _lastindex;
 //BA.debugLineNum = 99;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public String  _nextpic() throws Exception{
 //BA.debugLineNum = 179;BA.debugLine="Private Sub NextPic";
 //BA.debugLineNum = 180;BA.debugLine="picPointer = picPointer + 1";
_picpointer = (int) (_picpointer+1);
 //BA.debugLineNum = 181;BA.debugLine="If picPointer > (lstPics.Size -1) Then";
if (_picpointer>(_lstpics.getSize()-1)) { 
 //BA.debugLineNum = 182;BA.debugLine="picPointer = 0";
_picpointer = (int) (0);
 };
 //BA.debugLineNum = 184;BA.debugLine="ShowPic(picPointer,lstPics.Get(picPointer))";
_showpic(_picpointer,BA.ObjectToString(_lstpics.Get(_picpointer)));
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return "";
}
public Object  _pclv_hintrequested(int _index) throws Exception{
String _word = "";
 //BA.debugLineNum = 82;BA.debugLine="Sub PCLV_HintRequested (Index As Int) As Object";
 //BA.debugLineNum = 83;BA.debugLine="Dim word As String = lvPics.GetValue(Index)";
_word = BA.ObjectToString(_lvpics._getvalue(_index));
 //BA.debugLineNum = 84;BA.debugLine="Return word";
if (true) return (Object)(_word);
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return null;
}
public String  _scanpics() throws Exception{
String _f = "";
 //BA.debugLineNum = 150;BA.debugLine="Private Sub ScanPics";
 //BA.debugLineNum = 151;BA.debugLine="lstPics.Initialize";
_lstpics.Initialize();
 //BA.debugLineNum = 152;BA.debugLine="Try";
try { //BA.debugLineNum = 153;BA.debugLine="For Each f As String In File.ListFiles(picPath)";
{
final anywheresoftware.b4a.BA.IterableList group3 = __c.File.ListFiles(_picpath);
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_f = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 154;BA.debugLine="If picPath = File.DirAssets Then";
if ((_picpath).equals(__c.File.getDirAssets())) { 
 //BA.debugLineNum = 155;BA.debugLine="If f.EndsWith(\"jpg\") Then";
if (_f.endsWith("jpg")) { 
 //BA.debugLineNum = 156;BA.debugLine="lstPics.Add(f)";
_lstpics.Add((Object)(_f));
 };
 }else {
 //BA.debugLineNum = 159;BA.debugLine="lstPics.Add(f)";
_lstpics.Add((Object)(_f));
 };
 }
};
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 163;BA.debugLine="Log(LastException)";
__c.LogImpl("44826637",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 166;BA.debugLine="Log(\"ttl pics ---> \" & lstPics.Size)";
__c.LogImpl("44826640","ttl pics ---> "+BA.NumberToString(_lstpics.getSize()),0);
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 65;BA.debugLine="Menus.SetHeader(\"Photo Album\",\"main_menu_pics.png";
_menus._setheader /*String*/ (ba,"Photo Album","main_menu_pics.png");
 //BA.debugLineNum = 66;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public String  _setrotationx(anywheresoftware.b4a.objects.B4XViewWrapper _v,float _angle) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 107;BA.debugLine="Sub setRotationX(v As B4XView, Angle As Float)'ign";
 //BA.debugLineNum = 108;BA.debugLine="Dim jo = v As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_v.getObject()));
 //BA.debugLineNum = 109;BA.debugLine="jo.RunMethod(\"setRotationX\", Array As Object(Angl";
_jo.RunMethod("setRotationX",new Object[]{(Object)(_angle)});
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public String  _setrotationy(anywheresoftware.b4a.objects.B4XViewWrapper _v,float _angle) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 103;BA.debugLine="Sub setRotationY(v As B4XView, Angle As Float)'ign";
 //BA.debugLineNum = 104;BA.debugLine="Dim jo = v As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_v.getObject()));
 //BA.debugLineNum = 105;BA.debugLine="jo.RunMethod(\"setRotationY\", Array As Object(Angl";
_jo.RunMethod("setRotationY",new Object[]{(Object)(_angle)});
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public String  _showpic(int _index,String _fname) throws Exception{
anywheresoftware.b4a.agraham.reflection.Reflection _r = null;
 //BA.debugLineNum = 118;BA.debugLine="Private Sub ShowPic(index As Int,fname As String)'";
 //BA.debugLineNum = 119;BA.debugLine="Try";
try { //BA.debugLineNum = 122;BA.debugLine="Dim r As Reflector";
_r = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 123;BA.debugLine="r.Target = r.RunStaticMethod(\"java.lang.Runtime\"";
_r.Target = _r.RunStaticMethod("java.lang.Runtime","getRuntime",(Object[])(__c.Null),(String[])(__c.Null));
 //BA.debugLineNum = 124;BA.debugLine="Log(\"available Memory = \" & ((r.RunMethod(\"maxMe";
__c.LogImpl("44630022","available Memory = "+BA.NumberToString((((double)(BA.ObjectToNumber(_r.RunMethod("maxMemory")))-(double)(BA.ObjectToNumber(_r.RunMethod("totalMemory"))))/(double)(1024*1024)))+" MB",0);
 //BA.debugLineNum = 126;BA.debugLine="img.Load(picPath,fname)";
_img._load /*String*/ (_picpath,_fname);
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 129;BA.debugLine="Log(LastException)";
__c.LogImpl("44630027",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public String  _tmrshow_tick() throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Private Sub tmrShow_Tick";
 //BA.debugLineNum = 113;BA.debugLine="tmrPicShow.Enabled = False";
_tmrpicshow.setEnabled(__c.False);
 //BA.debugLineNum = 114;BA.debugLine="NextPic";
_nextpic();
 //BA.debugLineNum = 115;BA.debugLine="tmrPicShow.Enabled = True";
_tmrpicshow.setEnabled(__c.True);
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
return BA.SubDelegator.SubNotFound;
}
}
