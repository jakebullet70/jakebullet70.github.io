package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagemenu extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.pagemenu");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.pagemenu.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mpnlmain = null;
public String _mcallbackevent = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubheater = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubplugin1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubplugin2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubplugin3 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubplugin4 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsubplugin5 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlinfo = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmainmenu = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmenubtns = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmenulower = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmenulowerbline = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmnufiles = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmnumovement = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmnuprinting = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltempbed = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltemptool = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblactualtemp = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltexttop = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltextbottom = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblbedactualv = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblbedtargetv = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltoolactualv = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltooltargetv = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblactualtempbedv = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblactualtemptoolv = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmenuupperbl = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _btnsubbtnaction_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 227;BA.debugLine="Private Sub btnSubBtnAction_Click";
 //BA.debugLineNum = 229;BA.debugLine="Dim o As B4XView : o = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 229;BA.debugLine="Dim o As B4XView : o = Sender";
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 230;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 232;BA.debugLine="Select Case o.Tag";
switch (BA.switchObjectToInt(_o.getTag(),(Object)("br"),(Object)("soff"),(Object)("heat"))) {
case 0: {
 //BA.debugLineNum = 235;BA.debugLine="B4XPages.MainPage.SideMenu.DoBrightnessDlg";
_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._sidemenu /*sadLogic.OctoTouchController.sadb4xdraweradvancedhelper*/ ._dobrightnessdlg /*String*/ ();
 break; }
case 1: {
 //BA.debugLineNum = 238;BA.debugLine="CallSub2(Main,\"TurnOnOff_ScreenTmr\",False)";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"TurnOnOff_ScreenTmr",(Object)(__c.False));
 //BA.debugLineNum = 239;BA.debugLine="fnc.BlankScreen";
_fnc._blankscreen /*String*/ (ba);
 break; }
case 2: {
 //BA.debugLineNum = 242;BA.debugLine="If oc.isConnected = False Then";
if (_oc._isconnected /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 243;BA.debugLine="guiHelpers.Show_toast(gblConst.NOT_CONNECTED,1";
_guihelpers._show_toast /*String*/ (ba,_gblconst._not_connected /*String*/ ,(int) (1000));
 //BA.debugLineNum = 244;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 246;BA.debugLine="If oc.isPrinting Then";
if (_oc._isprinting /*boolean*/ ) { 
 //BA.debugLineNum = 247;BA.debugLine="guiHelpers.Show_toast(\"Printer is busy\",2000)";
_guihelpers._show_toast /*String*/ (ba,"Printer is busy",(int) (2000));
 }else {
 //BA.debugLineNum = 249;BA.debugLine="CallSub(B4XPages.MainPage,\"ShowPreHeatMenu_All";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)),"ShowPreHeatMenu_All");
 };
 break; }
}
;
 //BA.debugLineNum = 254;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 55;BA.debugLine="BuildMenuCard(pnlMnuMovement,\"menuMovement.png\",\"";
_buildmenucard(_pnlmnumovement,"menuMovement.png","Movement",_gblconst._page_movement /*String*/ );
 //BA.debugLineNum = 56;BA.debugLine="BuildMenuCard(pnlMnuFiles,\"menuFiles.png\",\"Files\"";
_buildmenucard(_pnlmnufiles,"menuFiles.png","Files",_gblconst._page_files /*String*/ );
 //BA.debugLineNum = 57;BA.debugLine="BuildMenuCard(pnlMnuPrinting,\"menuPrint.png\",\"Pri";
_buildmenucard(_pnlmnuprinting,"menuPrint.png","Printing",_gblconst._page_printing /*String*/ );
 //BA.debugLineNum = 59;BA.debugLine="BuildStatCard(pnlTempTool,\"hotend.png\",\"tool\")";
_buildstatcard(_pnltemptool,"hotend.png","tool");
 //BA.debugLineNum = 60;BA.debugLine="BuildStatCard(pnlTempBed,\"bed.png\",\"bed\")";
_buildstatcard(_pnltempbed,"bed.png","bed");
 //BA.debugLineNum = 62;BA.debugLine="lblToolActualV.Text = \"Actual\" : lblBedActualV.Te";
_lbltoolactualv.setText(BA.ObjectToCharSequence("Actual"));
 //BA.debugLineNum = 62;BA.debugLine="lblToolActualV.Text = \"Actual\" : lblBedActualV.Te";
_lblbedactualv.setText(BA.ObjectToCharSequence(_lbltoolactualv.getText()));
 //BA.debugLineNum = 63;BA.debugLine="lblActualTempBedV.TextColor = clrTheme.txtNormal";
_lblactualtempbedv.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 64;BA.debugLine="lblActualTempToolV.TextColor = clrTheme.txtNormal";
_lblactualtemptoolv.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 66;BA.debugLine="If guiHelpers.gIsLandScape = False Then";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 67;BA.debugLine="lblToolTargetV.TextSize = 20";
_lbltooltargetv.setTextSize((float) (20));
 //BA.debugLineNum = 68;BA.debugLine="lblBedTargetV.TextSize = 20";
_lblbedtargetv.setTextSize((float) (20));
 };
 //BA.debugLineNum = 71;BA.debugLine="guiHelpers.SetVisible(Array As B4XView(btnSubPlug";
_guihelpers._setvisible /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnsubplugin1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnsubplugin2.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnsubplugin3.getObject()))},__c.False);
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.SkinButton_Pugin(Array As Button(btnSu";
_guihelpers._skinbutton_pugin /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnsubplugin1,_btnsubplugin2,_btnsubplugin3,_btnsubplugin4,_btnsubplugin5,_btnsubheater});
 //BA.debugLineNum = 73;BA.debugLine="pnlMenuLowerBLine.Color = clrTheme.txtAccent";
_pnlmenulowerbline.setColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 74;BA.debugLine="pnlMenuUpperBL.Color = clrTheme.txtAccent";
_pnlmenuupperbl.setColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 75;BA.debugLine="pnlMenuLowerBLine.Visible = True '--- turned off";
_pnlmenulowerbline.setVisible(__c.True);
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public String  _buildmenucard(anywheresoftware.b4a.objects.PanelWrapper _mnupanel,String _imgfile,String _text,String _mnuaction) throws Exception{
anywheresoftware.b4a.objects.ConcreteViewWrapper _v = null;
sadLogic.OctoTouchController.lmb4ximageviewx _o1 = null;
sadLogic.OctoTouchController.autotextsizelabel _o6 = null;
 //BA.debugLineNum = 147;BA.debugLine="Private Sub BuildMenuCard(mnuPanel As Panel,imgFil";
 //BA.debugLineNum = 149;BA.debugLine="mnuPanel.LoadLayout(\"menuCard2\")";
_mnupanel.LoadLayout("menuCard2",ba);
 //BA.debugLineNum = 150;BA.debugLine="For Each v As View In mnuPanel.GetAllViewsRecursi";
_v = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
{
final anywheresoftware.b4a.BA.IterableList group2 = _mnupanel.GetAllViewsRecursive();
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_v = (anywheresoftware.b4a.objects.ConcreteViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ConcreteViewWrapper(), (android.view.View)(group2.Get(index2)));
 //BA.debugLineNum = 152;BA.debugLine="If v.Tag <> Null Then";
if (_v.getTag()!= null) { 
 //BA.debugLineNum = 153;BA.debugLine="If v.Tag Is lmB4XImageViewX Then";
if (_v.getTag() instanceof sadLogic.OctoTouchController.lmb4ximageviewx) { 
 //BA.debugLineNum = 154;BA.debugLine="Dim o1 As lmB4XImageViewX = v.Tag";
_o1 = (sadLogic.OctoTouchController.lmb4ximageviewx)(_v.getTag());
 //BA.debugLineNum = 155;BA.debugLine="o1.mClickAnimationColor = clrTheme.txtAccent";
_o1._mclickanimationcolor /*int*/  = _clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 156;BA.debugLine="o1.Load(File.DirAssets,imgFile)";
_o1._load /*String*/ (__c.File.getDirAssets(),_imgfile);
 //BA.debugLineNum = 157;BA.debugLine="o1.SetBitmap(guiHelpers.ChangeColorBasedOnAlph";
_o1._setbitmap /*String*/ (_guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,_o1._getbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (),_clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 158;BA.debugLine="o1.Tag2 = mnuAction '--- set menu action";
_o1._settag2 /*String*/ (_mnuaction);
 }else if(_v.getTag() instanceof sadLogic.OctoTouchController.autotextsizelabel) { 
 //BA.debugLineNum = 161;BA.debugLine="Dim o6 As AutoTextSizeLabel = v.Tag";
_o6 = (sadLogic.OctoTouchController.autotextsizelabel)(_v.getTag());
 //BA.debugLineNum = 162;BA.debugLine="o6.Text = Text";
_o6._settext /*Object*/ ((Object)(_text));
 //BA.debugLineNum = 163;BA.debugLine="o6.TextColor = clrTheme.txtAccent";
_o6._settextcolor /*int*/ (_clrtheme._txtaccent /*int*/ );
 };
 };
 }
};
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return "";
}
public String  _buildstatcard(anywheresoftware.b4a.objects.PanelWrapper _viewpanel,String _imgfile,String _text) throws Exception{
anywheresoftware.b4a.objects.ConcreteViewWrapper _v = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b = null;
anywheresoftware.b4a.objects.LabelWrapper _o6 = null;
 //BA.debugLineNum = 99;BA.debugLine="Private Sub BuildStatCard(viewPanel As Panel,imgFi";
 //BA.debugLineNum = 101;BA.debugLine="viewPanel.LoadLayout(\"mainstatcard.bal\")";
_viewpanel.LoadLayout("mainstatcard.bal",ba);
 //BA.debugLineNum = 103;BA.debugLine="For Each v As View In viewPanel.GetAllViewsRecurs";
_v = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
{
final anywheresoftware.b4a.BA.IterableList group2 = _viewpanel.GetAllViewsRecursive();
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_v = (anywheresoftware.b4a.objects.ConcreteViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ConcreteViewWrapper(), (android.view.View)(group2.Get(index2)));
 //BA.debugLineNum = 105;BA.debugLine="If v.Tag <> Null Then";
if (_v.getTag()!= null) { 
 //BA.debugLineNum = 107;BA.debugLine="If v Is ImageView Then";
if (_v.getObjectOrNull() instanceof android.widget.ImageView) { 
 //BA.debugLineNum = 108;BA.debugLine="Dim b As Bitmap = LoadBitmapResize(File.DirAss";
_b = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
_b = __c.LoadBitmapResize(__c.File.getDirAssets(),_imgfile,_v.getWidth(),_v.getHeight(),__c.True);
 //BA.debugLineNum = 109;BA.debugLine="v.As(ImageView).Bitmap = guiHelpers.ChangeColo";
((anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(_v.getObject()))).setBitmap((android.graphics.Bitmap)(_guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(_b.getObject())),_clrtheme._txtnormal /*int*/ ).getObject()));
 //BA.debugLineNum = 110;BA.debugLine="v.As(ImageView).Tag = IIf(Text.ToLowerCase = \"";
((anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(_v.getObject()))).setTag((((_text.toLowerCase()).equals("bed")) ? ((Object)("b")) : ((Object)("t"))));
 }else if(_v.getObjectOrNull() instanceof android.widget.TextView) { 
 //BA.debugLineNum = 113;BA.debugLine="Dim o6 As Label = v";
_o6 = new anywheresoftware.b4a.objects.LabelWrapper();
_o6 = (anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_v.getObject()));
 //BA.debugLineNum = 114;BA.debugLine="If o6.Text = \"t\" Then '--- top label - actual";
if ((_o6.getText()).equals("t")) { 
 //BA.debugLineNum = 115;BA.debugLine="guiHelpers.ResizeText(\"Actual ..\" & gblConst.";
_guihelpers._resizetext /*String*/ (ba,(Object)("Actual .."+_gblconst._degree_symbol /*String*/ ),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_o6.getObject())));
 //BA.debugLineNum = 116;BA.debugLine="If Text = \"bed\" Then";
if ((_text).equals("bed")) { 
 //BA.debugLineNum = 117;BA.debugLine="lblBedActualV = o6";
_lblbedactualv = _o6;
 }else {
 //BA.debugLineNum = 119;BA.debugLine="lblToolActualV = o6";
_lbltoolactualv = _o6;
 };
 }else if((_o6.getText()).equals("b")) { 
 //BA.debugLineNum = 122;BA.debugLine="guiHelpers.ResizeText(\"Target .......\" & gblC";
_guihelpers._resizetext /*String*/ (ba,(Object)("Target ......."+_gblconst._degree_symbol /*String*/ ),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_o6.getObject())));
 //BA.debugLineNum = 123;BA.debugLine="If Text = \"bed\" Then";
if ((_text).equals("bed")) { 
 //BA.debugLineNum = 124;BA.debugLine="lblBedTargetV = o6";
_lblbedtargetv = _o6;
 }else {
 //BA.debugLineNum = 126;BA.debugLine="lblToolTargetV = o6";
_lbltooltargetv = _o6;
 };
 }else {
 //BA.debugLineNum = 129;BA.debugLine="guiHelpers.ResizeText(\"100\" & gblConst.DEGREE";
_guihelpers._resizetext /*String*/ (ba,(Object)("100"+_gblconst._degree_symbol /*String*/ ),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_o6.getObject())));
 //BA.debugLineNum = 130;BA.debugLine="o6.Text = \"0\" & gblConst.DEGREE_SYMBOL";
_o6.setText(BA.ObjectToCharSequence("0"+_gblconst._degree_symbol /*String*/ ));
 //BA.debugLineNum = 131;BA.debugLine="If Text = \"bed\" Then";
if ((_text).equals("bed")) { 
 //BA.debugLineNum = 132;BA.debugLine="lblActualTempBedV = o6";
_lblactualtempbedv = _o6;
 }else {
 //BA.debugLineNum = 134;BA.debugLine="lblActualTempToolV = o6";
_lblactualtemptoolv = _o6;
 };
 };
 //BA.debugLineNum = 138;BA.debugLine="o6.TextColor = clrTheme.txtAccent";
_o6.setTextColor(_clrtheme._txtaccent /*int*/ );
 };
 };
 }
};
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"pageMenu\" 'ign";
_mmodule = "pageMenu";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private mPnlMain As B4XView";
_mpnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private mCallBackEvent As String";
_mcallbackevent = "";
 //BA.debugLineNum = 11;BA.debugLine="Private mMainObj As B4XMainPage 'ignore";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 14;BA.debugLine="Private btnSubHeater As Button";
_btnsubheater = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private btnSubPlugin1 As Button";
_btnsubplugin1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private btnSubPlugin2 As Button";
_btnsubplugin2 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private btnSubPlugin3 As Button";
_btnsubplugin3 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private btnSubPlugin4 As Button";
_btnsubplugin4 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private btnSubPlugin5 As Button";
_btnsubplugin5 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private pnlInfo As Panel";
_pnlinfo = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private pnlMainMenu As Panel";
_pnlmainmenu = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private pnlMenuBtns As Panel";
_pnlmenubtns = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private pnlMenuLower As Panel";
_pnlmenulower = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private pnlMenuLowerBLine As Panel";
_pnlmenulowerbline = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private pnlMnuFiles As Panel";
_pnlmnufiles = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private pnlMnuMovement As Panel";
_pnlmnumovement = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private pnlMnuPrinting As Panel";
_pnlmnuprinting = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private pnlTempBed,pnlTempTool As Panel";
_pnltempbed = new anywheresoftware.b4a.objects.PanelWrapper();
_pnltemptool = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private lblActualTemp,lblTextTop,lblTextBottom As";
_lblactualtemp = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltexttop = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltextbottom = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private lblBedActualV,lblBedTargetV,lblToolActual";
_lblbedactualv = new anywheresoftware.b4a.objects.LabelWrapper();
_lblbedtargetv = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltoolactualv = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltooltargetv = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private lblActualTempBedV, lblActualTempToolV As";
_lblactualtempbedv = new anywheresoftware.b4a.objects.LabelWrapper();
_lblactualtemptoolv = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private pnlMenuUpperBL As Panel";
_pnlmenuupperbl = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _masterpanel,String _callbackevent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 39;BA.debugLine="Public Sub Initialize(masterPanel As B4XView,callB";
 //BA.debugLineNum = 41;BA.debugLine="mPnlMain = masterPanel";
_mpnlmain = _masterpanel;
 //BA.debugLineNum = 42;BA.debugLine="mCallBackEvent = callBackEvent";
_mcallbackevent = _callbackevent;
 //BA.debugLineNum = 43;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 45;BA.debugLine="mPnlMain.SetLayoutAnimated(0,0,masterPanel.top,ma";
_mpnlmain.SetLayoutAnimated((int) (0),(int) (0),_masterpanel.getTop(),_masterpanel.getWidth(),_masterpanel.getHeight());
 //BA.debugLineNum = 46;BA.debugLine="mPnlMain.LoadLayout(\"pageMenu2\")";
_mpnlmain.LoadLayout("pageMenu2",ba);
 //BA.debugLineNum = 47;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 48;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"ShowV";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"ShowVer",(int) (2300));
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 94;BA.debugLine="mPnlMain.SetVisibleAnimated(500,False)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 95;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public void  _mnucardimg_click() throws Exception{
ResumableSub_mnuCardImg_Click rsub = new ResumableSub_mnuCardImg_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_mnuCardImg_Click extends BA.ResumableSub {
public ResumableSub_mnuCardImg_Click(sadLogic.OctoTouchController.pagemenu parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.pagemenu parent;
sadLogic.OctoTouchController.lmb4ximageviewx _oo1 = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 206;BA.debugLine="If oc.isconnected = False Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._oc._isconnected /*boolean*/ ==parent.__c.False) { 
this.state = 3;
}else if(parent.__c.Not(parent._oc._isklippyconnected2 /*boolean*/ (ba))) { 
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 207;BA.debugLine="guiHelpers.show_toast(gblConst.not_connected,130";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._not_connected /*String*/ ,(int) (1300));
 //BA.debugLineNum = 208;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 210;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 214;BA.debugLine="Try";

case 6:
//try
this.state = 11;
this.catchState = 10;
this.state = 8;
if (true) break;

case 8:
//C
this.state = 11;
this.catchState = 10;
 //BA.debugLineNum = 215;BA.debugLine="Dim oo1 As lmB4XImageViewX : oo1 = Sender";
_oo1 = new sadLogic.OctoTouchController.lmb4ximageviewx();
 //BA.debugLineNum = 215;BA.debugLine="Dim oo1 As lmB4XImageViewX : oo1 = Sender";
_oo1 = (sadLogic.OctoTouchController.lmb4ximageviewx)(parent.__c.Sender(ba));
 //BA.debugLineNum = 216;BA.debugLine="Sleep(50)";
parent.__c.Sleep(ba,this,(int) (50));
this.state = 12;
return;
case 12:
//C
this.state = 11;
;
 //BA.debugLineNum = 217;BA.debugLine="CallSub2(mMainObj,mCallBackEvent,oo1.tag2)";
parent.__c.CallSubNew2(ba,(Object)(parent._mmainobj),parent._mcallbackevent,(Object)(_oo1._gettag2 /*String*/ ()));
 if (true) break;

case 10:
//C
this.state = 11;
this.catchState = 0;
 //BA.debugLineNum = 219;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("44761106",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 11:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _mnucardimg1_click() throws Exception{
anywheresoftware.b4a.objects.ImageViewWrapper _oo1 = null;
sadLogic.OctoTouchController.heaterroutines _oo2 = null;
 //BA.debugLineNum = 172;BA.debugLine="Private Sub mnuCardImg1_Click";
 //BA.debugLineNum = 174;BA.debugLine="If oc.IsKlippyConnected2 = False Then";
if (_oc._isklippyconnected2 /*boolean*/ (ba)==__c.False) { 
 //BA.debugLineNum = 175;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 178;BA.debugLine="If oc.isconnected = False Then";
if (_oc._isconnected /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 179;BA.debugLine="guiHelpers.show_toast(gblConst.not_connected,100";
_guihelpers._show_toast /*String*/ (ba,_gblconst._not_connected /*String*/ ,(int) (1000));
 //BA.debugLineNum = 180;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 183;BA.debugLine="Dim oo1 As ImageView : oo1 = Sender";
_oo1 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 183;BA.debugLine="Dim oo1 As ImageView : oo1 = Sender";
_oo1 = (anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(__c.Sender(ba)));
 //BA.debugLineNum = 184;BA.debugLine="Dim oo2 As HeaterRoutines : oo2.Initialize";
_oo2 = new sadLogic.OctoTouchController.heaterroutines();
 //BA.debugLineNum = 184;BA.debugLine="Dim oo2 As HeaterRoutines : oo2.Initialize";
_oo2._initialize /*String*/ (ba);
 //BA.debugLineNum = 185;BA.debugLine="If oo1.Tag = \"b\" Then";
if ((_oo1.getTag()).equals((Object)("b"))) { 
 //BA.debugLineNum = 186;BA.debugLine="If oc.isPrinting Or oc.IsPaused2 Then";
if (_oc._isprinting /*boolean*/  || _oc._ispaused2 /*boolean*/ ) { 
 //BA.debugLineNum = 187;BA.debugLine="oo2.ChangeTempBed";
_oo2._changetempbed /*String*/ ();
 }else {
 //BA.debugLineNum = 189;BA.debugLine="oo2.PopupBedHeaterMenu";
_oo2._popupbedheatermenu /*String*/ ();
 };
 }else {
 //BA.debugLineNum = 192;BA.debugLine="If oc.isPrinting Or oc.IsPaused2 Then";
if (_oc._isprinting /*boolean*/  || _oc._ispaused2 /*boolean*/ ) { 
 //BA.debugLineNum = 193;BA.debugLine="oo2.ChangeTempTool";
_oo2._changetemptool /*String*/ ();
 }else {
 //BA.debugLineNum = 195;BA.debugLine="oo2.PopupToolHeaterMenu";
_oo2._popuptoolheatermenu /*String*/ ();
 };
 };
 //BA.debugLineNum = 199;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 87;BA.debugLine="mPnlMain.SetVisibleAnimated(500,True)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 88;BA.debugLine="CallSubDelayed(B4XPages.MainPage ,\"Build_RightSid";
__c.CallSubDelayed(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)),"Build_RightSideMenu");
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _showver() throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Public Sub ShowVer";
 //BA.debugLineNum = 81;BA.debugLine="guiHelpers.Show_toast(\"Version: V\" & Application.";
_guihelpers._show_toast /*String*/ (ba,"Version: V"+__c.Application.getVersionName(),(int) (2200));
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_temps() throws Exception{
 //BA.debugLineNum = 257;BA.debugLine="Public Sub Update_Printer_Temps";
 //BA.debugLineNum = 259;BA.debugLine="lblActualTempToolV.Text = oc.Tool1Actual.Replace(";
_lblactualtemptoolv.setText(BA.ObjectToCharSequence(_oc._tool1actual /*String*/ .replace("C","")));
 //BA.debugLineNum = 260;BA.debugLine="lblToolTargetV.Text = (\"Target: \"& $\"${IIf(oc.too";
_lbltooltargetv.setText(BA.ObjectToCharSequence((("Target: "+(""+__c.SmartStringFormatter("",(((_oc._tool1target /*String*/ ).equals(("0"+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off")) : ((Object)(_oc._tool1target /*String*/ ))))+""))).replace("C","")));
 //BA.debugLineNum = 262;BA.debugLine="lblActualTempBedV.Text = oc.BedActual.Replace(\"C\"";
_lblactualtempbedv.setText(BA.ObjectToCharSequence(_oc._bedactual /*String*/ .replace("C","")));
 //BA.debugLineNum = 263;BA.debugLine="lblBedTargetV.Text = (\"Target: \"& $\"${IIf(oc.BedT";
_lblbedtargetv.setText(BA.ObjectToCharSequence((("Target: "+(""+__c.SmartStringFormatter("",(((_oc._bedtarget /*String*/ ).equals(("0"+__c.SmartStringFormatter("",(Object)(_gblconst._degree_symbol /*String*/ ))+"C"))) ? ((Object)("off")) : ((Object)(_oc._bedtarget /*String*/ ))))+""))).replace("C","")));
 //BA.debugLineNum = 269;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SHOWVER"))
	return _showver();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_TEMPS"))
	return _update_printer_temps();
return BA.SubDelegator.SubNotFound;
}
}
