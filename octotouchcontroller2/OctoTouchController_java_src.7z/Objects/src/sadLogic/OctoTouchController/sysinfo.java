package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sysinfo extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.sysinfo");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.sysinfo.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public String  _convertmap2str(anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _s = null;
Object _thekey = null;
 //BA.debugLineNum = 69;BA.debugLine="Public Sub ConvertMap2Str(m As Map) As String";
 //BA.debugLineNum = 71;BA.debugLine="Dim s As StringBuilder : s.Initialize";
_s = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 71;BA.debugLine="Dim s As StringBuilder : s.Initialize";
_s.Initialize();
 //BA.debugLineNum = 72;BA.debugLine="For Each theKey As Object In m.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _m.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_thekey = group3.Get(index3);
 //BA.debugLineNum = 73;BA.debugLine="s.Append(theKey).Append(\":\").Append(m.Get(theKey";
_s.Append(BA.ObjectToString(_thekey)).Append(":").Append(BA.ObjectToString(_m.Get(_thekey))).Append(__c.CRLF);
 }
};
 //BA.debugLineNum = 76;BA.debugLine="Return s.ToString";
if (true) return _s.ToString();
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _getinfo() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.phone.Phone _p = null;
com.rootsoft.oslibrary.OSLibrary _os = null;
String[] _cpu = null;
 //BA.debugLineNum = 13;BA.debugLine="Public Sub GetInfo() As Map";
 //BA.debugLineNum = 15;BA.debugLine="Dim m As Map, p As Phone, os As OperatingSystem";
_m = new anywheresoftware.b4a.objects.collections.Map();
_p = new anywheresoftware.b4a.phone.Phone();
_os = new com.rootsoft.oslibrary.OSLibrary();
 //BA.debugLineNum = 16;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 17;BA.debugLine="os.Initialize(\"\")";
_os.Initialize(ba,"");
 //BA.debugLineNum = 19;BA.debugLine="Try";
try { //BA.debugLineNum = 21;BA.debugLine="m.Put(\"Manufacturer\",p.Manufacturer)";
_m.Put((Object)("Manufacturer"),(Object)(_p.getManufacturer()));
 //BA.debugLineNum = 22;BA.debugLine="m.Put(\"Model\",p.Model)";
_m.Put((Object)("Model"),(Object)(_p.getModel()));
 //BA.debugLineNum = 23;BA.debugLine="m.Put(\"Product\",p.Product)";
_m.Put((Object)("Product"),(Object)(_p.getProduct()));
 //BA.debugLineNum = 24;BA.debugLine="m.Put(\"SDK\",p.SdkVersion)";
_m.Put((Object)("SDK"),(Object)(_p.getSdkVersion()));
 //BA.debugLineNum = 26;BA.debugLine="m.Put(\"Total internal memory size (MB)\", Round2(";
_m.Put((Object)("Total internal memory size (MB)"),(Object)(__c.Round2(_os.getTotalInternalMemorySize()/(double)(1024*1024),(int) (0))));
 //BA.debugLineNum = 27;BA.debugLine="m.Put(\"Available internal memory (MB)\", Round2(o";
_m.Put((Object)("Available internal memory (MB)"),(Object)(__c.Round2(_os.getAvailableInternalMemorySize()/(double)(1024*1024),(int) (0))));
 //BA.debugLineNum = 28;BA.debugLine="m.Put(\"Total external memory size (MB)\", Round2(";
_m.Put((Object)("Total external memory size (MB)"),(Object)(__c.Round2(_os.getTotalExternalMemorySize()/(double)(1024*1024),(int) (0))));
 //BA.debugLineNum = 29;BA.debugLine="m.Put(\"External memory available\", os.externalMe";
_m.Put((Object)("External memory available"),(Object)(_os.externalMemoryAvailable()));
 //BA.debugLineNum = 31;BA.debugLine="m.Put(\"Display logical density (DPI)\", os.densit";
_m.Put((Object)("Display logical density (DPI)"),(Object)(_os.densityDpi()));
 //BA.debugLineNum = 32;BA.debugLine="m.Put(\"Font scaled density\", os.scaledDensity)";
_m.Put((Object)("Font scaled density"),(Object)(_os.scaledDensity()));
 //BA.debugLineNum = 33;BA.debugLine="m.Put(\"Screen width (pixels)\", os.widthPixels)";
_m.Put((Object)("Screen width (pixels)"),(Object)(_os.widthPixels()));
 //BA.debugLineNum = 34;BA.debugLine="m.Put(\"Screen height (pixels)\", os.heightPixels)";
_m.Put((Object)("Screen height (pixels)"),(Object)(_os.heightPixels()));
 //BA.debugLineNum = 35;BA.debugLine="m.Put(\"Pixels per inch (x-direction)\", Round2(os";
_m.Put((Object)("Pixels per inch (x-direction)"),(Object)(__c.Round2(_os.xdpi(),(int) (0))));
 //BA.debugLineNum = 36;BA.debugLine="m.Put(\"Pixels per inch (y-direction)\", Round2(os";
_m.Put((Object)("Pixels per inch (y-direction)"),(Object)(__c.Round2(_os.ydpi(),(int) (0))));
 //BA.debugLineNum = 37;BA.debugLine="m.Put(\"Physical screen width (DPI*Pixels)\", Roun";
_m.Put((Object)("Physical screen width (DPI*Pixels)"),(Object)(__c.Round2(_os.physicalScreenWidth(),(int) (0))));
 //BA.debugLineNum = 38;BA.debugLine="m.Put(\"Physical screen height (DPI*Pixels)\", Rou";
_m.Put((Object)("Physical screen height (DPI*Pixels)"),(Object)(__c.Round2(_os.physicalScreenHeight(),(int) (0))));
 //BA.debugLineNum = 40;BA.debugLine="Dim CPU() As String : CPU = Regex.Split( CRLF,os";
_cpu = new String[(int) (0)];
java.util.Arrays.fill(_cpu,"");
 //BA.debugLineNum = 40;BA.debugLine="Dim CPU() As String : CPU = Regex.Split( CRLF,os";
_cpu = __c.Regex.Split(__c.CRLF,_os.ReadCPUinfo());
 //BA.debugLineNum = 41;BA.debugLine="If CPU.Length > 2 Then";
if (_cpu.length>2) { 
 //BA.debugLineNum = 42;BA.debugLine="m.Put(\"CPU Information1\", CPU(0))";
_m.Put((Object)("CPU Information1"),(Object)(_cpu[(int) (0)]));
 //BA.debugLineNum = 43;BA.debugLine="m.Put(\"CPU Information2\", CPU(1))";
_m.Put((Object)("CPU Information2"),(Object)(_cpu[(int) (1)]));
 };
 } 
       catch (Exception e28) {
			ba.setLastException(e28); //BA.debugLineNum = 47;BA.debugLine="Log(LastException)";
__c.LogImpl("63111202",BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 //BA.debugLineNum = 50;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public sadLogic.OctoTouchController.b4xorderedmap  _getinfo2() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
sadLogic.OctoTouchController.b4xorderedmap _out = null;
Object _thekey = null;
 //BA.debugLineNum = 55;BA.debugLine="Public Sub GetInfo2() As B4XOrderedMap";
 //BA.debugLineNum = 57;BA.debugLine="Dim m As Map = GetInfo";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _getinfo();
 //BA.debugLineNum = 58;BA.debugLine="Dim out As B4XOrderedMap : out.Initialize";
_out = new sadLogic.OctoTouchController.b4xorderedmap();
 //BA.debugLineNum = 58;BA.debugLine="Dim out As B4XOrderedMap : out.Initialize";
_out._initialize /*String*/ (ba);
 //BA.debugLineNum = 60;BA.debugLine="For Each theKey As Object In m.Keys";
{
final anywheresoftware.b4a.BA.IterableList group4 = _m.Keys();
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_thekey = group4.Get(index4);
 //BA.debugLineNum = 61;BA.debugLine="out.Put(theKey,m.Get(theKey))";
_out._put /*String*/ (_thekey,_m.Get(_thekey));
 }
};
 //BA.debugLineNum = 64;BA.debugLine="Return out";
if (true) return _out;
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
