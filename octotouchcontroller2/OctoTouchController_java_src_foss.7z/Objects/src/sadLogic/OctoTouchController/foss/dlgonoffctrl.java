package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgonoffctrl extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgonoffctrl");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgonoffctrl.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnoff = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnon = null;
public anywheresoftware.b4a.objects.collections.Map _data = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public void  _btnctrl_click() throws Exception{
ResumableSub_btnCtrl_Click rsub = new ResumableSub_btnCtrl_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnCtrl_Click extends BA.ResumableSub {
public ResumableSub_btnCtrl_Click(sadLogic.OctoTouchController.foss.dlgonoffctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgonoffctrl parent;
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
String _cmd = "";
String _s = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 83;BA.debugLine="Dim o As B4XView : o = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 83;BA.debugLine="Dim o As B4XView : o = Sender";
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 85;BA.debugLine="Dim cmd As String";
_cmd = "";
 //BA.debugLineNum = 86;BA.debugLine="If o.Tag =\"on\" Then";
if (true) break;

case 1:
//if
this.state = 6;
if ((_o.getTag()).equals((Object)("on"))) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 87;BA.debugLine="cmd = Data.Get(\"ipon\")";
_cmd = BA.ObjectToString(parent._data.Get((Object)("ipon")));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 89;BA.debugLine="cmd = Data.Get(\"ipoff\")";
_cmd = BA.ObjectToString(parent._data.Get((Object)("ipoff")));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 92;BA.debugLine="Wait For (SendCmd2(cmd)) Complete(s As String)";
parent.__c.WaitFor("complete", ba, this, parent._sendcmd2(_cmd));
this.state = 7;
return;
case 7:
//C
this.state = -1;
_s = (String) result[0];
;
 //BA.debugLineNum = 93;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel) '--- clo";
parent._mdialog._close /*boolean*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _s) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgOnOffCtrl\"'";
_mmodule = "dlgOnOffCtrl";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 13;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 16;BA.debugLine="Private btnOff,btnOn As B4XView";
_btnoff = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnon = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Public Data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 32;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,String _title) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize( title As String) As Object";
 //BA.debugLineNum = 25;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 26;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 27;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendcmd2(String _cmd) throws Exception{
ResumableSub_SendCmd2 rsub = new ResumableSub_SendCmd2(this,_cmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendCmd2 extends BA.ResumableSub {
public ResumableSub_SendCmd2(sadLogic.OctoTouchController.foss.dlgonoffctrl parent,String _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
sadLogic.OctoTouchController.foss.dlgonoffctrl parent;
String _cmd;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 98;BA.debugLine="mMainObj.oMasterController.cn.PostRequest2(cmd,\"\"";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmd,"");
 //BA.debugLineNum = 99;BA.debugLine="guiHelpers.Show_toast2(\"Sending Command\",1500)";
parent._guihelpers._show_toast2 /*String*/ (ba,"Sending Command",(int) (1500));
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgonoffctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgonoffctrl parent;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _h = 0f;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 39;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 40;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 41;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 43;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 44;BA.debugLine="Dim h As Float";
_h = 0f;
 //BA.debugLineNum = 45;BA.debugLine="If guiHelpers.gScreenSizeAprox > 7 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gscreensizeaprox /*double*/ >7) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 46;BA.debugLine="h = 280dip";
_h = (float) (parent.__c.DipToCurrent((int) (280)));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 48;BA.debugLine="h = 240dip";
_h = (float) (parent.__c.DipToCurrent((int) (240)));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 50;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 260dip,h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (260)),(int) (_h));
 //BA.debugLineNum = 51;BA.debugLine="p.LoadLayout(\"viewPsuCtrl\") '--- use this one";
_p.LoadLayout("viewPsuCtrl",ba);
 //BA.debugLineNum = 53;BA.debugLine="pnlMain.Color = clrTheme.Background";
parent._pnlmain.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 54;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnOff,btnO";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnoff.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnon.getObject()))});
 //BA.debugLineNum = 56;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 57;BA.debugLine="btnOff.Text = cs.Initialize.Typeface(Typeface.MAT";
parent._btnoff.setText(BA.ObjectToCharSequence(_cs.Initialize().Typeface(parent.__c.Typeface.getMATERIALICONS()).VerticalAlign(parent.__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(parent.__c.Chr(((int)0xe3a4)))).Typeface(parent.__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("    Off")).PopAll().getObject()));
 //BA.debugLineNum = 59;BA.debugLine="btnOn.Text  = cs.Initialize.Typeface(Typeface.MAT";
parent._btnon.setText(BA.ObjectToCharSequence(_cs.Initialize().Typeface(parent.__c.Typeface.getMATERIALICONS()).VerticalAlign(parent.__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(parent.__c.Chr(((int)0xe3a5)))).Typeface(parent.__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("    On")).PopAll().getObject()));
 //BA.debugLineNum = 61;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnOff,btn";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnoff.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnon.getObject()))},(float) ((double)(Double.parseDouble(parent.__c.NumberFormat2(parent._btnoff.getTextSize()/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))-(double)(BA.ObjectToNumber(((parent._guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 65;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 66;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 67;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 69;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 7;
return;
case 7:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 70;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 74;BA.debugLine="mMainObj.pObjCurrentDlg1 = Null";
parent._mmainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
