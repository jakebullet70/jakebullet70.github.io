package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class logme {
private static logme mostCurrent = new logme();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static int _pdaysofoldlogsbeforedelete = 0;
public static String _mlogfilepath = "";
public static String _mlogfilenamebase = "";
public static String _mlogfilename = "";
public static String _mlogfileext = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public static String  _buildlogfilename(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="private Sub BuildLogFileName()";
 //BA.debugLineNum = 132;BA.debugLine="mLogFileName = GetDay & mLogFileNameBase  & \".\" &";
_mlogfilename = _getday(_ba)+_mlogfilenamebase+"."+_mlogfileext;
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return "";
}
public static String  _checkifneednewlogfile(anywheresoftware.b4a.BA _ba) throws Exception{
String _tt = "";
 //BA.debugLineNum = 118;BA.debugLine="Private Sub CheckIfNeedNewLogFile";
 //BA.debugLineNum = 121;BA.debugLine="Dim tt As String = GetDay";
_tt = _getday(_ba);
 //BA.debugLineNum = 122;BA.debugLine="If mLogFileName.StartsWith(tt) = False Then";
if (_mlogfilename.startsWith(_tt)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 123;BA.debugLine="BuildLogFileName";
_buildlogfilename(_ba);
 };
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return "";
}
public static int  _daysbetweendated(anywheresoftware.b4a.BA _ba,long _date1,long _date2) throws Exception{
b4a.example.dateutils._period _p = null;
 //BA.debugLineNum = 112;BA.debugLine="Private Sub DaysBetweenDated(date1 As Long, date2";
 //BA.debugLineNum = 113;BA.debugLine="Dim p As Period = DateUtils.PeriodBetweenInDays(d";
_p = mostCurrent._dateutils._periodbetweenindays(_ba,_date1,_date2);
 //BA.debugLineNum = 114;BA.debugLine="Return p.Days";
if (true) return _p.Days;
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return 0;
}
public static String  _deleteoldfiles(anywheresoftware.b4a.BA _ba,String _fspec) throws Exception{
sadLogic.OctoTouchController.wildcardfileslist _o1 = null;
anywheresoftware.b4a.objects.collections.List _flist = null;
Object _fname = null;
long _fdate = 0L;
int _numdays = 0;
String _s = "";
 //BA.debugLineNum = 93;BA.debugLine="Public Sub DeleteOldFiles(fspec As String)";
 //BA.debugLineNum = 95;BA.debugLine="LogColor(\"Start: Deleting Old Files\",xui.Color_Gr";
anywheresoftware.b4a.keywords.Common.LogImpl("38469634","Start: Deleting Old Files",_xui.Color_Green);
 //BA.debugLineNum = 96;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1 = new sadLogic.OctoTouchController.wildcardfileslist();
 //BA.debugLineNum = 96;BA.debugLine="Dim o1 As WildCardFilesList : o1.Initialize";
_o1._initialize /*String*/ ((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 97;BA.debugLine="Dim flist As List = o1.GetFiles(xui.DefaultFolder";
_flist = new anywheresoftware.b4a.objects.collections.List();
_flist = _o1._getfiles /*anywheresoftware.b4a.objects.collections.List*/ (_xui.getDefaultFolder(),_fspec,anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 98;BA.debugLine="For Each fname In flist";
{
final anywheresoftware.b4a.BA.IterableList group5 = _flist;
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_fname = group5.Get(index5);
 //BA.debugLineNum = 100;BA.debugLine="Dim fDate As Long = File.LastModified(xui.Defaul";
_fdate = anywheresoftware.b4a.keywords.Common.File.LastModified(_xui.getDefaultFolder(),BA.ObjectToString(_fname));
 //BA.debugLineNum = 101;BA.debugLine="Dim numDays As Int = DaysBetweenDated(fDate,Date";
_numdays = _daysbetweendated(_ba,_fdate,anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 102;BA.debugLine="If  numDays > pDaysOfOldLogsBeforeDelete Then";
if (_numdays>_pdaysofoldlogsbeforedelete) { 
 //BA.debugLineNum = 103;BA.debugLine="fileHelpers.SafeKill(fname)";
mostCurrent._filehelpers._safekill /*String*/ (_ba,BA.ObjectToString(_fname));
 //BA.debugLineNum = 104;BA.debugLine="Dim s As String = \"deleting old log/crash file:";
_s = "deleting old log/crash file: "+BA.ObjectToString(_fname);
 //BA.debugLineNum = 105;BA.debugLine="Log(s)";
anywheresoftware.b4a.keywords.Common.LogImpl("38469644",_s,0);
 //BA.debugLineNum = 106;BA.debugLine="Write2Disk(s)";
_write2disk(_ba,_s);
 };
 }
};
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public static String  _getdatetime4logmsg(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="private Sub GetDateTime4LogMsg() As String";
 //BA.debugLineNum = 69;BA.debugLine="DateTime.DateFormat= \"yyyy-MM-dd\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("yyyy-MM-dd");
 //BA.debugLineNum = 70;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss.SS\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss.SS");
 //BA.debugLineNum = 71;BA.debugLine="Return DateTime.Date(DateTime.Now) & \" \" & DateTi";
if (true) return anywheresoftware.b4a.keywords.Common.DateTime.Date(anywheresoftware.b4a.keywords.Common.DateTime.getNow())+" "+anywheresoftware.b4a.keywords.Common.DateTime.Time(anywheresoftware.b4a.keywords.Common.DateTime.TicksPerDay);
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public static String  _getday(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Private Sub GetDay() As String";
 //BA.debugLineNum = 138;BA.debugLine="DateTime.DateFormat = \"yyyy-MM-dd_\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("yyyy-MM-dd_");
 //BA.debugLineNum = 139;BA.debugLine="Return DateTime.Date(DateTime.Now)";
if (true) return anywheresoftware.b4a.keywords.Common.DateTime.Date(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public static String  _init(anywheresoftware.b4a.BA _ba,String _folder,String _fname,String _ext) throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Init(folder As String, fname As String,";
 //BA.debugLineNum = 21;BA.debugLine="mLogFileNameBase = fname";
_mlogfilenamebase = _fname;
 //BA.debugLineNum = 22;BA.debugLine="mLogFilePath = folder";
_mlogfilepath = _folder;
 //BA.debugLineNum = 23;BA.debugLine="mLogFileExt = ext";
_mlogfileext = _ext;
 //BA.debugLineNum = 24;BA.debugLine="BuildLogFileName";
_buildlogfilename(_ba);
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _logdebug2(anywheresoftware.b4a.BA _ba,String _txt,String _callingmodule) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Public Sub LogDebug2(txt As String, callingModule";
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public static String  _logit(anywheresoftware.b4a.BA _ba,String _txt,String _callingmodule) throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Public Sub LogIt(txt As String, callingModule As S";
 //BA.debugLineNum = 40;BA.debugLine="CheckIfNeedNewLogFile";
_checkifneednewlogfile(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Write2Disk2(\"** \" & GetDateTime4LogMsg &  \" :-->";
_write2disk2(_ba,"** "+_getdatetime4logmsg(_ba)+" :--> "+_callingmodule+" <--> "+_txt,_mlogfilename);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public static String  _logit2(anywheresoftware.b4a.BA _ba,String _txt,String _callingmodule,String _callingsub) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Public Sub LogIt2(txt As String, callingModule As";
 //BA.debugLineNum = 51;BA.debugLine="CheckIfNeedNewLogFile";
_checkifneednewlogfile(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Write2Disk2(\"** \" & GetDateTime4LogMsg &  \" :-->";
_write2disk2(_ba,"** "+_getdatetime4logmsg(_ba)+" :--> "+_callingmodule+":"+_callingsub+" <--> "+_txt,_mlogfilename);
 //BA.debugLineNum = 55;BA.debugLine="Log(txt)";
anywheresoftware.b4a.keywords.Common.LogImpl("38207494",_txt,0);
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Public pDaysOfOldLogsBeforeDelete As Int = 2";
_pdaysofoldlogsbeforedelete = (int) (2);
 //BA.debugLineNum = 10;BA.debugLine="Private mLogFilePath As String";
_mlogfilepath = "";
 //BA.debugLineNum = 11;BA.debugLine="Private mLogFileNameBase As String";
_mlogfilenamebase = "";
 //BA.debugLineNum = 12;BA.debugLine="Private mLogFileName As String";
_mlogfilename = "";
 //BA.debugLineNum = 13;BA.debugLine="Private mLogFileExt As String";
_mlogfileext = "";
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public static String  _write2disk(anywheresoftware.b4a.BA _ba,String _strtolog) throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="public Sub Write2Disk(strToLog As String)";
 //BA.debugLineNum = 88;BA.debugLine="If strToLog.Length = 0 Then strToLog = \"empty\"";
if (_strtolog.length()==0) { 
_strtolog = "empty";};
 //BA.debugLineNum = 89;BA.debugLine="Write2Disk2(strToLog,mLogFileName)";
_write2disk2(_ba,_strtolog,_mlogfilename);
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _write2disk2(anywheresoftware.b4a.BA _ba,String _strtolog,String _filename) throws Exception{
boolean _file_append = false;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _textwriter1 = null;
 //BA.debugLineNum = 76;BA.debugLine="private Sub Write2Disk2(strToLog As String,filenam";
 //BA.debugLineNum = 77;BA.debugLine="Dim Const FILE_APPEND As Boolean = True";
_file_append = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 78;BA.debugLine="Dim TextWriter1 As TextWriter";
_textwriter1 = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 79;BA.debugLine="strToLog = \"********  \" & GetDateTime4LogMsg &  \"";
_strtolog = "********  "+_getdatetime4logmsg(_ba)+"  ********"+anywheresoftware.b4a.keywords.Common.CRLF+_strtolog;
 //BA.debugLineNum = 80;BA.debugLine="TextWriter1.Initialize(File.OpenOutput(mLogFilePa";
_textwriter1.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(_mlogfilepath,_filename,_file_append).getObject()));
 //BA.debugLineNum = 81;BA.debugLine="TextWriter1.WriteLine(strToLog)";
_textwriter1.WriteLine(_strtolog);
 //BA.debugLineNum = 82;BA.debugLine="TextWriter1.Flush";
_textwriter1.Flush();
 //BA.debugLineNum = 83;BA.debugLine="TextWriter1.Close";
_textwriter1.Close();
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
}
