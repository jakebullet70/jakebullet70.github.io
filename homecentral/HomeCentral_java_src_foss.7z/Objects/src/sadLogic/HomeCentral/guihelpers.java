package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class guihelpers {
private static guihelpers mostCurrent = new guihelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.StringUtils _su = null;
public static double _gscreensizeaprox = 0;
public static int _gscreensizedpi = 0;
public static boolean _gislandscape = false;
public static float _gfscale = 0f;
public static float _gwidth = 0f;
public static float _gheight = 0f;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _animateb4xview(anywheresoftware.b4a.BA _ba,String _fromedge,anywheresoftware.b4a.objects.B4XViewWrapper _base) throws Exception{
int _top = 0;
int _left = 0;
 //BA.debugLineNum = 475;BA.debugLine="Public Sub AnimateB4xView (FromEdge As String,base";
 //BA.debugLineNum = 476;BA.debugLine="Dim top As Int = base.Top";
_top = _base.getTop();
 //BA.debugLineNum = 477;BA.debugLine="Dim left As Int = base.Left";
_left = _base.getLeft();
 //BA.debugLineNum = 478;BA.debugLine="Select FromEdge.ToLowerCase";
switch (BA.switchObjectToInt(_fromedge.toLowerCase(),"bottom","top","left","right")) {
case 0: {
 //BA.debugLineNum = 480;BA.debugLine="base.Top = base.Parent.Height";
_base.setTop(_base.getParent().getHeight());
 break; }
case 1: {
 //BA.debugLineNum = 482;BA.debugLine="base.Top = -base.Height";
_base.setTop((int) (-_base.getHeight()));
 break; }
case 2: {
 //BA.debugLineNum = 484;BA.debugLine="base.Left = -base.Width";
_base.setLeft((int) (-_base.getWidth()));
 break; }
case 3: {
 //BA.debugLineNum = 486;BA.debugLine="base.Left = base.Parent.Width";
_base.setLeft(_base.getParent().getWidth());
 break; }
}
;
 //BA.debugLineNum = 488;BA.debugLine="base.Visible = True";
_base.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 489;BA.debugLine="base.SetLayoutAnimated(220, left, top, base.Width";
_base.SetLayoutAnimated((int) (220),_left,_top,_base.getWidth(),_base.getHeight());
 //BA.debugLineNum = 490;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _changecolorbasedonalphalevel(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp,int _newcolor) throws Exception{
b4a.example.bitmapcreator _bc = null;
b4a.example.bitmapcreator._argbcolor _a1 = null;
b4a.example.bitmapcreator._argbcolor _a2 = null;
int _y = 0;
int _x = 0;
 //BA.debugLineNum = 60;BA.debugLine="Public Sub ChangeColorBasedOnAlphaLevel(bmp As B4X";
 //BA.debugLineNum = 61;BA.debugLine="Dim bc As BitmapCreator";
_bc = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 62;BA.debugLine="bc.Initialize(bmp.Width, bmp.Height)";
_bc._initialize((_ba.processBA == null ? _ba : _ba.processBA),(int) (_bmp.getWidth()),(int) (_bmp.getHeight()));
 //BA.debugLineNum = 63;BA.debugLine="bc.CopyPixelsFromBitmap(bmp)";
_bc._copypixelsfrombitmap(_bmp);
 //BA.debugLineNum = 64;BA.debugLine="Dim a1, a2 As ARGBColor";
_a1 = new b4a.example.bitmapcreator._argbcolor();
_a2 = new b4a.example.bitmapcreator._argbcolor();
 //BA.debugLineNum = 65;BA.debugLine="bc.ColorToARGB(NewColor, a1)";
_bc._colortoargb(_newcolor,_a1);
 //BA.debugLineNum = 66;BA.debugLine="For y = 0 To bc.mHeight - 1";
{
final int step6 = 1;
final int limit6 = (int) (_bc._mheight-1);
_y = (int) (0) ;
for (;_y <= limit6 ;_y = _y + step6 ) {
 //BA.debugLineNum = 67;BA.debugLine="For x = 0 To bc.mWidth - 1";
{
final int step7 = 1;
final int limit7 = (int) (_bc._mwidth-1);
_x = (int) (0) ;
for (;_x <= limit7 ;_x = _x + step7 ) {
 //BA.debugLineNum = 68;BA.debugLine="bc.GetARGB(x, y, a2)";
_bc._getargb(_x,_y,_a2);
 //BA.debugLineNum = 69;BA.debugLine="If a2.a > 0 Then";
if (_a2.a>0) { 
 //BA.debugLineNum = 70;BA.debugLine="a2.r = a1.r";
_a2.r = _a1.r;
 //BA.debugLineNum = 71;BA.debugLine="a2.g = a1.g";
_a2.g = _a1.g;
 //BA.debugLineNum = 72;BA.debugLine="a2.b = a1.b";
_a2.b = _a1.b;
 //BA.debugLineNum = 73;BA.debugLine="bc.SetARGB(x, y, a2)";
_bc._setargb(_x,_y,_a2);
 };
 }
};
 }
};
 //BA.debugLineNum = 77;BA.debugLine="Return bc.Bitmap";
if (true) return _bc._getbitmap();
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return null;
}
public static int  _changecolorvisible(anywheresoftware.b4a.BA _ba,int _clr) throws Exception{
int[] _argb = null;
 //BA.debugLineNum = 285;BA.debugLine="Private Sub ChangeColorVisible(clr As Int) As Int";
 //BA.debugLineNum = 286;BA.debugLine="Dim argb() As Int = clrTheme.Int2ARGB(clr)";
_argb = mostCurrent._clrtheme._int2argb /*int[]*/ (_ba,_clr);
 //BA.debugLineNum = 287;BA.debugLine="Return xui.Color_ARGB(90,argb(1),argb(2),argb(3))";
if (true) return _xui.Color_ARGB((int) (90),_argb[(int) (1)],_argb[(int) (2)],_argb[(int) (3)]);
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
return 0;
}
public static boolean  _checksize(anywheresoftware.b4a.BA _ba,float _size,boolean _multiplelines,anywheresoftware.b4a.objects.LabelWrapper _mlbl) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvs = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmp = null;
 //BA.debugLineNum = 304;BA.debugLine="public Sub CheckSize(size As Float, MultipleLines";
 //BA.debugLineNum = 306;BA.debugLine="Try";
try { //BA.debugLineNum = 309;BA.debugLine="Dim cvs As Canvas ,  bmp As Bitmap";
_cvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
_bmp = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 310;BA.debugLine="bmp.InitializeMutable(1%x,1%y)";
_bmp.InitializeMutable(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (1),_ba),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (1),_ba));
 //BA.debugLineNum = 311;BA.debugLine="cvs.Initialize2(bmp)";
_cvs.Initialize2((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 312;BA.debugLine="mLbl.TextSize = size";
_mlbl.setTextSize(_size);
 //BA.debugLineNum = 313;BA.debugLine="If MultipleLines Then";
if (_multiplelines) { 
 //BA.debugLineNum = 314;BA.debugLine="Return su.MeasureMultilineTextHeight(mLbl, mLbl.";
if (true) return _su.MeasureMultilineTextHeight((android.widget.TextView)(_mlbl.getObject()),BA.ObjectToCharSequence(_mlbl.getText()))>_mlbl.getHeight();
 }else {
 //BA.debugLineNum = 316;BA.debugLine="Return cvs.MeasureStringWidth(mLbl.Text, mLbl.Ty";
if (true) return _cvs.MeasureStringWidth(_mlbl.getText(),_mlbl.getTypeface(),_size)>_mlbl.getWidth() || _su.MeasureMultilineTextHeight((android.widget.TextView)(_mlbl.getObject()),BA.ObjectToCharSequence(_mlbl.getText()))>_mlbl.getHeight();
 };
 } 
       catch (Exception e12) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e12); //BA.debugLineNum = 321;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("29884433",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 //BA.debugLineNum = 324;BA.debugLine="Return True '--- just return true if error";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 326;BA.debugLine="End Sub";
return false;
}
public static String  _enabledisableviews(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _arr,boolean _enabledisable) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 112;BA.debugLine="Public Sub EnableDisableViews(Arr() As B4XView,Ena";
 //BA.debugLineNum = 113;BA.debugLine="For Each o As B4XView In Arr";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 114;BA.debugLine="o.enabled = EnableDisable";
_o.setEnabled(_enabledisable);
 }
};
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 10;BA.debugLine="Public gScreenSizeAprox As Double = 7 '--- asume";
_gscreensizeaprox = 7;
 //BA.debugLineNum = 11;BA.debugLine="Public gScreenSizeDPI As Int = 0";
_gscreensizedpi = (int) (0);
 //BA.debugLineNum = 12;BA.debugLine="Public gIsLandScape As Boolean";
_gislandscape = false;
 //BA.debugLineNum = 13;BA.debugLine="Public gFscale As Float";
_gfscale = 0f;
 //BA.debugLineNum = 14;BA.debugLine="Public gWidth As Float";
_gwidth = 0f;
 //BA.debugLineNum = 15;BA.debugLine="Public gHeight As Float";
_gheight = 0f;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public static String  _resizetext(anywheresoftware.b4a.BA _ba,String _value,anywheresoftware.b4a.objects.LabelWrapper _mlbl) throws Exception{
float _highvalue = 0f;
float _lowvalue = 0f;
float _currentvalue = 0f;
boolean _multiplelines = false;
float _tolerancevalue = 0f;
boolean _currentresult = false;
int _offset = 0;
 //BA.debugLineNum = 328;BA.debugLine="Public Sub ResizeText(value As String, mLbl As Lab";
 //BA.debugLineNum = 329;BA.debugLine="Dim HighValue As Float  = 2";
_highvalue = (float) (2);
 //BA.debugLineNum = 330;BA.debugLine="Dim LowValue As Float = 1";
_lowvalue = (float) (1);
 //BA.debugLineNum = 331;BA.debugLine="Dim CurrentValue As Float";
_currentvalue = 0f;
 //BA.debugLineNum = 333;BA.debugLine="mLbl.Text = value";
_mlbl.setText(BA.ObjectToCharSequence(_value));
 //BA.debugLineNum = 334;BA.debugLine="Dim multipleLines As Boolean = mLbl.Text.Contains";
_multiplelines = _mlbl.getText().contains(anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 339;BA.debugLine="Do While Not(CheckSize(HighValue, multipleLines,m";
while (anywheresoftware.b4a.keywords.Common.Not(_checksize(_ba,_highvalue,_multiplelines,_mlbl))) {
 //BA.debugLineNum = 340;BA.debugLine="LowValue = HighValue";
_lowvalue = _highvalue;
 //BA.debugLineNum = 341;BA.debugLine="HighValue = HighValue + 30";
_highvalue = (float) (_highvalue+30);
 }
;
 //BA.debugLineNum = 344;BA.debugLine="CurrentValue = (HighValue + LowValue)/2";
_currentvalue = (float) ((_highvalue+_lowvalue)/(double)2);
 //BA.debugLineNum = 352;BA.debugLine="Dim ToleranceValue As Float = 2";
_tolerancevalue = (float) (2);
 //BA.debugLineNum = 354;BA.debugLine="Dim currentResult As Boolean";
_currentresult = false;
 //BA.debugLineNum = 355;BA.debugLine="Do While (CurrentValue - LowValue) > ToleranceVal";
while ((_currentvalue-_lowvalue)>_tolerancevalue || (_highvalue-_currentvalue)>_tolerancevalue) {
 //BA.debugLineNum = 357;BA.debugLine="currentResult = CheckSize(CurrentValue, multiple";
_currentresult = _checksize(_ba,_currentvalue,_multiplelines,_mlbl);
 //BA.debugLineNum = 359;BA.debugLine="If currentResult Then 'this means currentvalue i";
if (_currentresult) { 
 //BA.debugLineNum = 360;BA.debugLine="HighValue = CurrentValue";
_highvalue = _currentvalue;
 }else {
 //BA.debugLineNum = 362;BA.debugLine="LowValue = CurrentValue";
_lowvalue = _currentvalue;
 };
 //BA.debugLineNum = 364;BA.debugLine="CurrentValue = (HighValue + LowValue) / 2";
_currentvalue = (float) ((_highvalue+_lowvalue)/(double)2);
 }
;
 //BA.debugLineNum = 367;BA.debugLine="Dim offset As Int = 0";
_offset = (int) (0);
 //BA.debugLineNum = 368;BA.debugLine="mLbl.TextSize = ((CurrentValue - ToleranceValue)";
_mlbl.setTextSize((float) (((_currentvalue-_tolerancevalue)+_offset)));
 //BA.debugLineNum = 370;BA.debugLine="End Sub";
return "";
}
public static String  _reskinb4xcombobox(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xcombobox[] _cbo) throws Exception{
sadLogic.HomeCentral.b4xcombobox _cb = null;
anywheresoftware.b4j.object.JavaObject _jo1 = null;
anywheresoftware.b4a.phone.Phone _p = null;
anywheresoftware.b4j.object.JavaObject _jo2 = null;
 //BA.debugLineNum = 188;BA.debugLine="Public Sub ReSkinB4XComboBox(cbo() As B4XComboBox)";
 //BA.debugLineNum = 190;BA.debugLine="For Each cb As B4XComboBox In cbo";
{
final sadLogic.HomeCentral.b4xcombobox[] group1 = _cbo;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_cb = group1[index1];
 //BA.debugLineNum = 191;BA.debugLine="Try";
try { //BA.debugLineNum = 194;BA.debugLine="Dim jo1 As JavaObject = cb.cmbBox.Background";
_jo1 = new anywheresoftware.b4j.object.JavaObject();
_jo1 = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_cb._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .getBackground()));
 //BA.debugLineNum = 195;BA.debugLine="Dim p As Phone";
_p = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 196;BA.debugLine="If p.SdkVersion < 29 Then";
if (_p.getSdkVersion()<29) { 
 //BA.debugLineNum = 197;BA.debugLine="jo1.RunMethod(\"setColorFilter\", Array(clrTheme";
_jo1.RunMethod("setColorFilter",new Object[]{(Object)(mostCurrent._clrtheme._txtnormal /*int*/ ),(Object)("SRC_ATOP")});
 }else {
 //BA.debugLineNum = 199;BA.debugLine="Dim jo2 As JavaObject";
_jo2 = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 200;BA.debugLine="jo2 = jo2.InitializeNewInstance(\"android.graph";
_jo2 = _jo2.InitializeNewInstance("android.graphics.BlendModeColorFilter",new Object[]{(Object)(mostCurrent._clrtheme._txtnormal /*int*/ ),(Object)("SRC_ATOP")});
 //BA.debugLineNum = 201;BA.debugLine="jo1.RunMethod(\"setColorFilter\", Array(jo2))";
_jo1.RunMethod("setColorFilter",new Object[]{(Object)(_jo2.getObject())});
 };
 //BA.debugLineNum = 205;BA.debugLine="cb.cmbBox.TextColor = clrTheme.txtNormal";
_cb._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setTextColor(mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 206;BA.debugLine="cb.cmbBox.Color = clrTheme.BackgroundHeader";
_cb._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setColor(mostCurrent._clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 207;BA.debugLine="cb.cmbBox.DropdownBackgroundColor = clrTheme.Ba";
_cb._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setDropdownBackgroundColor(mostCurrent._clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 208;BA.debugLine="cb.cmbBox.DropdownTextColor = clrTheme.txtNorma";
_cb._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setDropdownTextColor(mostCurrent._clrtheme._txtnormal /*int*/ );
 } 
       catch (Exception e17) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e17); //BA.debugLineNum = 211;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("29360151",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 }
};
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public static String  _reskinb4xseekbar(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xseekbar[] _sb) throws Exception{
sadLogic.HomeCentral.b4xseekbar _b = null;
 //BA.debugLineNum = 180;BA.debugLine="Public Sub ReSkinB4XSeekBar(sb() As B4XSeekBar)";
 //BA.debugLineNum = 181;BA.debugLine="For Each b As B4XSeekBar In sb";
{
final sadLogic.HomeCentral.b4xseekbar[] group1 = _sb;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_b = group1[index1];
 //BA.debugLineNum = 182;BA.debugLine="b.ThumbColor = clrTheme.txtNormal";
_b._thumbcolor /*int*/  = mostCurrent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 183;BA.debugLine="b.Color1 = clrTheme.txtAccent";
_b._color1 /*int*/  = mostCurrent._clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 184;BA.debugLine="b.Color2 = clrTheme.txtNormal";
_b._color2 /*int*/  = mostCurrent._clrtheme._txtnormal /*int*/ ;
 }
};
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return "";
}
public static String  _setcbdrawable(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _cb,int _boxcolor,int _boxwidth,int _tickcolor,String _tickchar,int _disabledcolor,int _size,int _padding) throws Exception{
anywheresoftware.b4a.objects.drawable.StateListDrawable _sld = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmenabled = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmchecked = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmdisabled = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _rect1 = null;
anywheresoftware.b4a.objects.drawable.BitmapDrawable _enabled = null;
anywheresoftware.b4a.objects.drawable.BitmapDrawable _checked = null;
anywheresoftware.b4a.objects.drawable.BitmapDrawable _disabled = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv1 = null;
int _fontsize = 0;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv2 = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 420;BA.debugLine="Public Sub SetCBDrawable(CB As CheckBox,BoxColor A";
 //BA.debugLineNum = 423;BA.debugLine="Dim SLD As StateListDrawable";
_sld = new anywheresoftware.b4a.objects.drawable.StateListDrawable();
 //BA.debugLineNum = 424;BA.debugLine="SLD.Initialize";
_sld.Initialize();
 //BA.debugLineNum = 426;BA.debugLine="Dim BMEnabled,BMChecked,BMDisabled As Bitmap";
_bmenabled = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
_bmchecked = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
_bmdisabled = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 427;BA.debugLine="BMEnabled.InitializeMutable(Size,Size)";
_bmenabled.InitializeMutable(_size,_size);
 //BA.debugLineNum = 428;BA.debugLine="BMChecked.InitializeMutable(Size,Size)";
_bmchecked.InitializeMutable(_size,_size);
 //BA.debugLineNum = 429;BA.debugLine="BMDisabled.InitializeMutable(Size,Size)";
_bmdisabled.InitializeMutable(_size,_size);
 //BA.debugLineNum = 431;BA.debugLine="Dim CNV As Canvas";
_cnv = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 432;BA.debugLine="CNV.Initialize2(BMEnabled)";
_cnv.Initialize2((android.graphics.Bitmap)(_bmenabled.getObject()));
 //BA.debugLineNum = 433;BA.debugLine="Dim Rect1 As Rect";
_rect1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 434;BA.debugLine="Rect1.Initialize(Padding ,Padding ,Size - Padding";
_rect1.Initialize(_padding,_padding,(int) (_size-_padding),(int) (_size-_padding));
 //BA.debugLineNum = 435;BA.debugLine="CNV.DrawRect(Rect1,BoxColor,False,BoxWidth)";
_cnv.DrawRect((android.graphics.Rect)(_rect1.getObject()),_boxcolor,anywheresoftware.b4a.keywords.Common.False,(float) (_boxwidth));
 //BA.debugLineNum = 436;BA.debugLine="Dim Enabled,Checked,Disabled As BitmapDrawable";
_enabled = new anywheresoftware.b4a.objects.drawable.BitmapDrawable();
_checked = new anywheresoftware.b4a.objects.drawable.BitmapDrawable();
_disabled = new anywheresoftware.b4a.objects.drawable.BitmapDrawable();
 //BA.debugLineNum = 437;BA.debugLine="Enabled.Initialize(BMEnabled)";
_enabled.Initialize((android.graphics.Bitmap)(_bmenabled.getObject()));
 //BA.debugLineNum = 439;BA.debugLine="Dim CNV1 As Canvas";
_cnv1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 440;BA.debugLine="CNV1.Initialize2(BMChecked)";
_cnv1.Initialize2((android.graphics.Bitmap)(_bmchecked.getObject()));
 //BA.debugLineNum = 441;BA.debugLine="If TickChar = \"Fill\" Then";
if ((_tickchar).equals("Fill")) { 
 //BA.debugLineNum = 442;BA.debugLine="CNV1.DrawRect(Rect1,TickColor,True,BoxWidth)";
_cnv1.DrawRect((android.graphics.Rect)(_rect1.getObject()),_tickcolor,anywheresoftware.b4a.keywords.Common.True,(float) (_boxwidth));
 //BA.debugLineNum = 443;BA.debugLine="CNV1.DrawRect(Rect1,BoxColor,False,BoxWidth)";
_cnv1.DrawRect((android.graphics.Rect)(_rect1.getObject()),_boxcolor,anywheresoftware.b4a.keywords.Common.False,(float) (_boxwidth));
 }else {
 //BA.debugLineNum = 445;BA.debugLine="CNV1.DrawRect(Rect1,BoxColor,False,BoxWidth)";
_cnv1.DrawRect((android.graphics.Rect)(_rect1.getObject()),_boxcolor,anywheresoftware.b4a.keywords.Common.False,(float) (_boxwidth));
 //BA.debugLineNum = 447;BA.debugLine="Dim FontSize As Int = 6";
_fontsize = (int) (6);
 //BA.debugLineNum = 448;BA.debugLine="Do While CNV.MeasureStringHeight(TickChar,Typefa";
while (_cnv.MeasureStringHeight(_tickchar,anywheresoftware.b4a.keywords.Common.Typeface.DEFAULT,(float) (_fontsize))<_size-(_boxwidth*2)-(_padding*2)) {
 //BA.debugLineNum = 449;BA.debugLine="FontSize = FontSize + 1";
_fontsize = (int) (_fontsize+1);
 }
;
 //BA.debugLineNum = 451;BA.debugLine="FontSize = FontSize - 1";
_fontsize = (int) (_fontsize-1);
 //BA.debugLineNum = 453;BA.debugLine="CNV1.DrawText(TickChar,Size/2,(Size + CNV.Measur";
_cnv1.DrawText(_ba,_tickchar,(float) (_size/(double)2),(float) ((_size+_cnv.MeasureStringHeight(_tickchar,anywheresoftware.b4a.keywords.Common.Typeface.DEFAULT,(float) (_fontsize)))/(double)2),anywheresoftware.b4a.keywords.Common.Typeface.DEFAULT,(float) (_fontsize),_tickcolor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 //BA.debugLineNum = 455;BA.debugLine="Checked.Initialize(BMChecked)";
_checked.Initialize((android.graphics.Bitmap)(_bmchecked.getObject()));
 //BA.debugLineNum = 457;BA.debugLine="Dim CNV2 As Canvas";
_cnv2 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 458;BA.debugLine="CNV2.Initialize2(BMDisabled)";
_cnv2.Initialize2((android.graphics.Bitmap)(_bmdisabled.getObject()));
 //BA.debugLineNum = 459;BA.debugLine="CNV2.DrawRect(Rect1,DisabledColor,True,BoxWidth)";
_cnv2.DrawRect((android.graphics.Rect)(_rect1.getObject()),_disabledcolor,anywheresoftware.b4a.keywords.Common.True,(float) (_boxwidth));
 //BA.debugLineNum = 460;BA.debugLine="CNV2.DrawRect(Rect1,BoxColor,False,BoxWidth)";
_cnv2.DrawRect((android.graphics.Rect)(_rect1.getObject()),_boxcolor,anywheresoftware.b4a.keywords.Common.False,(float) (_boxwidth));
 //BA.debugLineNum = 461;BA.debugLine="Disabled.Initialize(BMDisabled)";
_disabled.Initialize((android.graphics.Bitmap)(_bmdisabled.getObject()));
 //BA.debugLineNum = 464;BA.debugLine="SLD.AddState(SLD.State_Disabled,Disabled)";
_sld.AddState(_sld.State_Disabled,(android.graphics.drawable.Drawable)(_disabled.getObject()));
 //BA.debugLineNum = 465;BA.debugLine="SLD.AddState(SLD.State_Checked,Checked)";
_sld.AddState(_sld.State_Checked,(android.graphics.drawable.Drawable)(_checked.getObject()));
 //BA.debugLineNum = 466;BA.debugLine="SLD.AddState(SLD.State_Enabled,Enabled)";
_sld.AddState(_sld.State_Enabled,(android.graphics.drawable.Drawable)(_enabled.getObject()));
 //BA.debugLineNum = 467;BA.debugLine="SLD.AddCatchAllState(Enabled)";
_sld.AddCatchAllState((android.graphics.drawable.Drawable)(_enabled.getObject()));
 //BA.debugLineNum = 469;BA.debugLine="Dim JO As JavaObject = CB";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_cb.getObject()));
 //BA.debugLineNum = 470;BA.debugLine="JO.RunMethod(\"setButtonDrawable\",Array As Object(";
_jo.RunMethod("setButtonDrawable",new Object[]{(Object)(_sld.getObject())});
 //BA.debugLineNum = 471;BA.debugLine="End Sub";
return "";
}
public static String  _setcolortextstatelist(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.ButtonWrapper _btn,int _pressed,int _enabled,int _disabled) throws Exception{
int[][] _states = null;
int[] _color = null;
anywheresoftware.b4j.object.JavaObject _csl = null;
anywheresoftware.b4j.object.JavaObject _b1 = null;
 //BA.debugLineNum = 271;BA.debugLine="Private Sub SetColorTextStateList(Btn As Button,Pr";
 //BA.debugLineNum = 273;BA.debugLine="Dim States(3,1) As Int";
_states = new int[(int) (3)][];
{
int d0 = _states.length;
int d1 = (int) (1);
for (int i0 = 0;i0 < d0;i0++) {
_states[i0] = new int[d1];
}
}
;
 //BA.debugLineNum = 274;BA.debugLine="States(0,0) = 16842919    'Pressed";
_states[(int) (0)][(int) (0)] = (int) (16842919);
 //BA.debugLineNum = 275;BA.debugLine="States(1,0) = 16842910    'Enabled";
_states[(int) (1)][(int) (0)] = (int) (16842910);
 //BA.debugLineNum = 276;BA.debugLine="States(2,0) = -16842910 'Disabled";
_states[(int) (2)][(int) (0)] = (int) (-16842910);
 //BA.debugLineNum = 278;BA.debugLine="Dim Color(3) As Int = Array As Int(Pressed,Enable";
_color = new int[]{_pressed,_enabled,_disabled};
 //BA.debugLineNum = 280;BA.debugLine="Dim CSL As JavaObject";
_csl = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 281;BA.debugLine="CSL.InitializeNewInstance(\"android.content.res.Co";
_csl.InitializeNewInstance("android.content.res.ColorStateList",new Object[]{(Object)(_states),(Object)(_color)});
 //BA.debugLineNum = 282;BA.debugLine="Dim B1 As JavaObject = Btn";
_b1 = new anywheresoftware.b4j.object.JavaObject();
_b1 = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_btn.getObject()));
 //BA.debugLineNum = 283;BA.debugLine="B1.RunMethod(\"setTextColor\",Array As Object(CSL))";
_b1.RunMethod("setTextColor",new Object[]{(Object)(_csl.getObject())});
 //BA.debugLineNum = 284;BA.debugLine="End Sub";
return "";
}
public static String  _setpanelsborder(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _arr,int _clr) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 145;BA.debugLine="Public Sub SetPanelsBorder(Arr() As B4XView,clr As";
 //BA.debugLineNum = 146;BA.debugLine="For Each o As B4XView In Arr";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 147;BA.debugLine="o.SetColorAndBorder(xui.Color_Transparent,1dip,c";
_o.SetColorAndBorder(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1)),_clr,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (3)));
 }
};
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public static String  _setpanelsdividers(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _arr,int _clr) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 138;BA.debugLine="Public Sub SetPanelsDividers(Arr() As B4XView,clr";
 //BA.debugLineNum = 139;BA.debugLine="For Each o As B4XView In Arr";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 140;BA.debugLine="o.SetColorAndBorder(clr,1dip,clr,3dip)";
_o.SetColorAndBorder(_clr,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1)),_clr,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (3)));
 //BA.debugLineNum = 141;BA.debugLine="o.Color = clr";
_o.setColor(_clr);
 }
};
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return "";
}
public static String  _setpanelstranparent(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _arr) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 151;BA.debugLine="Public Sub SetPanelsTranparent(Arr() As B4XView)";
 //BA.debugLineNum = 152;BA.debugLine="For Each o As B4XView In Arr";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 153;BA.debugLine="o.SetColorAndBorder(xui.Color_Transparent,0dip,x";
_o.SetColorAndBorder(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)),_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 }
};
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
return "";
}
public static String  _settextcolor(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _obj,int _clr) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 118;BA.debugLine="Public Sub SetTextColor(obj() As B4XView,clr As In";
 //BA.debugLineNum = 119;BA.debugLine="For Each o As B4XView In obj";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _obj;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 120;BA.debugLine="o.TextColor = clr";
_o.setTextColor(_clr);
 }
};
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public static String  _settextcolorb4xfloattextfield(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xfloattextfield[] _views) throws Exception{
sadLogic.HomeCentral.b4xfloattextfield _o = null;
 //BA.debugLineNum = 218;BA.debugLine="Public Sub SetTextColorB4XFloatTextField(views() A";
 //BA.debugLineNum = 220;BA.debugLine="For Each o As B4XFloatTextField In views";
{
final sadLogic.HomeCentral.b4xfloattextfield[] group1 = _views;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 221;BA.debugLine="o.TextField.TextColor = clrTheme.txtNormal";
_o._gettextfield /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setTextColor(mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 222;BA.debugLine="o.NonFocusedHintColor = clrTheme.txtAccent";
_o._nonfocusedhintcolor /*int*/  = mostCurrent._clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 223;BA.debugLine="o.HintColor = clrTheme.txtAccent";
_o._hintcolor /*int*/  = mostCurrent._clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 224;BA.debugLine="o.Update";
_o._update /*String*/ ();
 }
};
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return "";
}
public static String  _settextshadow(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _pview,float _pradius,float _pdx,float _pdy,int _pcolor) throws Exception{
anywheresoftware.b4a.agraham.reflection.Reflection _ref = null;
 //BA.debugLineNum = 391;BA.debugLine="Public Sub SetTextShadow(pView As B4XView, pRadius";
 //BA.debugLineNum = 392;BA.debugLine="Dim ref As Reflector";
_ref = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 393;BA.debugLine="ref.Target = pView";
_ref.Target = (Object)(_pview.getObject());
 //BA.debugLineNum = 394;BA.debugLine="ref.RunMethod4(\"setShadowLayer\", Array As Object(";
_ref.RunMethod4("setShadowLayer",new Object[]{(Object)(_pradius),(Object)(_pdx),(Object)(_pdy),(Object)(_pcolor)},new String[]{"java.lang.float","java.lang.float","java.lang.float","java.lang.int"});
 //BA.debugLineNum = 395;BA.debugLine="End Sub";
return "";
}
public static String  _settextsize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _obj,float _size) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 100;BA.debugLine="Public Sub SetTextSize(obj() As B4XView,size As Fl";
 //BA.debugLineNum = 101;BA.debugLine="For Each o As B4XView In obj";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _obj;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 //BA.debugLineNum = 102;BA.debugLine="o.TextSize = size";
_o.setTextSize(_size);
 }
};
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public static String  _setviewshadow(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _view,double _offset,int _color) throws Exception{
 //BA.debugLineNum = 397;BA.debugLine="Public Sub SetViewShadow (View As B4XView, Offset";
 //BA.debugLineNum = 410;BA.debugLine="Offset = Offset * 2";
_offset = _offset*2;
 //BA.debugLineNum = 411;BA.debugLine="View.As(JavaObject).RunMethod(\"setElevation\", Arr";
((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_view.getObject()))).RunMethod("setElevation",new Object[]{(Object)(((float) (_offset)))});
 //BA.debugLineNum = 415;BA.debugLine="End Sub";
return "";
}
public static String  _setvisible(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper[] _arr,boolean _visible) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _v = null;
 //BA.debugLineNum = 81;BA.debugLine="Public Sub SetVisible(Arr() As B4XView,Visible As";
 //BA.debugLineNum = 82;BA.debugLine="For Each v As B4XView In Arr";
{
final anywheresoftware.b4a.objects.B4XViewWrapper[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_v = group1[index1];
 //BA.debugLineNum = 83;BA.debugLine="v.Visible = Visible";
_v.setVisible(_visible);
 }
};
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public static String  _show_toast(anywheresoftware.b4a.BA _ba,String _msg) throws Exception{
 //BA.debugLineNum = 293;BA.debugLine="Public Sub Show_toast(msg As String)";
 //BA.debugLineNum = 294;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"Show_Toast\", m";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2((_ba.processBA == null ? _ba : _ba.processBA),(Object)(mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)),"Show_Toast",(Object)(_msg));
 //BA.debugLineNum = 295;BA.debugLine="End Sub";
return "";
}
public static String  _show_toast2(anywheresoftware.b4a.BA _ba,String _msg,int _ms) throws Exception{
 //BA.debugLineNum = 296;BA.debugLine="Public Sub Show_toast2(msg As String, ms As Int)";
 //BA.debugLineNum = 297;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast2\",";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3((_ba.processBA == null ? _ba : _ba.processBA),(Object)(mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)),"Show_Toast2",(Object)(_msg),(Object)(_ms));
 //BA.debugLineNum = 298;BA.debugLine="End Sub";
return "";
}
public static float  _sizefontadjust(anywheresoftware.b4a.BA _ba) throws Exception{
int _i = 0;
 //BA.debugLineNum = 374;BA.debugLine="Public Sub SizeFontAdjust() As Float";
 //BA.debugLineNum = 375;BA.debugLine="Dim I As Int =  gWidth";
_i = (int) (_gwidth);
 //BA.debugLineNum = 376;BA.debugLine="If I > 760 And I < 900 Then";
if (_i>760 && _i<900) { 
 //BA.debugLineNum = 377;BA.debugLine="Return 1";
if (true) return (float) (1);
 }else if(_i>901 && _i<1099) { 
 //BA.debugLineNum = 379;BA.debugLine="Return 1.20";
if (true) return (float) (1.20);
 }else if(_i>1200) { 
 //BA.debugLineNum = 381;BA.debugLine="Return 1.45";
if (true) return (float) (1.45);
 }else {
 //BA.debugLineNum = 384;BA.debugLine="Return 1";
if (true) return (float) (1);
 };
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return 0f;
}
public static String  _skinbutton(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.ButtonWrapper[] _obj) throws Exception{
int _clraccent = 0;
int _clrnormal = 0;
int _clrpressed = 0;
anywheresoftware.b4a.objects.ButtonWrapper _btn = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _defaultdrawable = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _presseddrawable = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _disableddrawable = null;
anywheresoftware.b4a.objects.drawable.StateListDrawable _sld1 = null;
 //BA.debugLineNum = 248;BA.debugLine="Public Sub SkinButton(obj() As Button)";
 //BA.debugLineNum = 250;BA.debugLine="Dim clrAccent, clrNormal ,clrPressed As Int";
_clraccent = 0;
_clrnormal = 0;
_clrpressed = 0;
 //BA.debugLineNum = 251;BA.debugLine="clrNormal = clrTheme.txtNormal";
_clrnormal = mostCurrent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 252;BA.debugLine="clrAccent = clrTheme.txtAccent";
_clraccent = mostCurrent._clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 254;BA.debugLine="clrPressed = ChangeColorVisible(clrTheme.txtNorma";
_clrpressed = _changecolorvisible(_ba,mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 255;BA.debugLine="For Each btn As Button In obj";
{
final anywheresoftware.b4a.objects.ButtonWrapper[] group5 = _obj;
final int groupLen5 = group5.length
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_btn = group5[index5];
 //BA.debugLineNum = 256;BA.debugLine="SetColorTextStateList(btn,clrPressed,clrNormal,c";
_setcolortextstatelist(_ba,_btn,_clrpressed,_clrnormal,mostCurrent._clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 258;BA.debugLine="Dim DefaultDrawable, PressedDrawable,DisabledDra";
_defaultdrawable = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
_presseddrawable = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
_disableddrawable = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 259;BA.debugLine="DefaultDrawable.Initialize2(xui.Color_Transparen";
_defaultdrawable.Initialize2(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),_clraccent);
 //BA.debugLineNum = 260;BA.debugLine="PressedDrawable.Initialize2(clrPressed,8dip,2dip";
_presseddrawable.Initialize2(_clrpressed,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),_clrnormal);
 //BA.debugLineNum = 261;BA.debugLine="DisabledDrawable.Initialize2(xui.Color_Transpare";
_disableddrawable.Initialize2(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 263;BA.debugLine="Dim sld1 As StateListDrawable : sld1.Initialize";
_sld1 = new anywheresoftware.b4a.objects.drawable.StateListDrawable();
 //BA.debugLineNum = 263;BA.debugLine="Dim sld1 As StateListDrawable : sld1.Initialize";
_sld1.Initialize();
 //BA.debugLineNum = 264;BA.debugLine="sld1.AddState(sld1.State_Pressed, PressedDrawabl";
_sld1.AddState(_sld1.State_Pressed,(android.graphics.drawable.Drawable)(_presseddrawable.getObject()));
 //BA.debugLineNum = 265;BA.debugLine="sld1.AddState(sld1.State_Disabled, DisabledDrawa";
_sld1.AddState(_sld1.State_Disabled,(android.graphics.drawable.Drawable)(_disableddrawable.getObject()));
 //BA.debugLineNum = 266;BA.debugLine="sld1.AddCatchAllState(DefaultDrawable)";
_sld1.AddCatchAllState((android.graphics.drawable.Drawable)(_defaultdrawable.getObject()));
 //BA.debugLineNum = 267;BA.debugLine="btn.Background = sld1";
_btn.setBackground((android.graphics.drawable.Drawable)(_sld1.getObject()));
 }
};
 //BA.debugLineNum = 269;BA.debugLine="End Sub";
return "";
}
public static String  _skinbuttonnoborder(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.ButtonWrapper[] _obj) throws Exception{
int _clrnormal = 0;
int _clrpressed = 0;
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _defaultdrawable = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _presseddrawable = null;
anywheresoftware.b4a.objects.drawable.StateListDrawable _sld1 = null;
 //BA.debugLineNum = 232;BA.debugLine="Public Sub SkinButtonNoBorder(obj() As Button)";
 //BA.debugLineNum = 233;BA.debugLine="Dim clrNormal ,clrPressed As Int";
_clrnormal = 0;
_clrpressed = 0;
 //BA.debugLineNum = 234;BA.debugLine="clrNormal = clrTheme.txtNormal";
_clrnormal = mostCurrent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 235;BA.debugLine="clrPressed = ChangeColorVisible(clrTheme.txtNorma";
_clrpressed = _changecolorvisible(_ba,mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 236;BA.debugLine="For Each b As Button In obj";
{
final anywheresoftware.b4a.objects.ButtonWrapper[] group4 = _obj;
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_b = group4[index4];
 //BA.debugLineNum = 237;BA.debugLine="SetColorTextStateList(b,clrPressed,clrNormal,clr";
_setcolortextstatelist(_ba,_b,_clrpressed,_clrnormal,mostCurrent._clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 239;BA.debugLine="Dim DefaultDrawable, PressedDrawable As ColorDra";
_defaultdrawable = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
_presseddrawable = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 240;BA.debugLine="DefaultDrawable.Initialize(xui.Color_Transparent";
_defaultdrawable.Initialize(_xui.Color_Transparent,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8)));
 //BA.debugLineNum = 241;BA.debugLine="PressedDrawable.Initialize2(clrPressed,8dip,2dip";
_presseddrawable.Initialize2(_clrpressed,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),_clrnormal);
 //BA.debugLineNum = 242;BA.debugLine="Dim sld1 As StateListDrawable :sld1.Initialize";
_sld1 = new anywheresoftware.b4a.objects.drawable.StateListDrawable();
 //BA.debugLineNum = 242;BA.debugLine="Dim sld1 As StateListDrawable :sld1.Initialize";
_sld1.Initialize();
 //BA.debugLineNum = 243;BA.debugLine="sld1.AddState(sld1.State_Pressed, PressedDrawabl";
_sld1.AddState(_sld1.State_Pressed,(android.graphics.drawable.Drawable)(_presseddrawable.getObject()));
 //BA.debugLineNum = 244;BA.debugLine="sld1.AddCatchAllState(DefaultDrawable)";
_sld1.AddCatchAllState((android.graphics.drawable.Drawable)(_defaultdrawable.getObject()));
 //BA.debugLineNum = 245;BA.debugLine="b.Background = sld1";
_b.setBackground((android.graphics.drawable.Drawable)(_sld1.getObject()));
 }
};
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public static String  _skintextedit(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.EditTextWrapper[] _et,int _brd_r,boolean _nopopupkb) throws Exception{
anywheresoftware.b4a.objects.drawable.ColorDrawable _cd = null;
anywheresoftware.b4a.objects.drawable.StateListDrawable _sd = null;
anywheresoftware.b4a.objects.EditTextWrapper _v = null;
 //BA.debugLineNum = 517;BA.debugLine="Public Sub SkinTextEdit(et() As EditText ,brd_r As";
 //BA.debugLineNum = 519;BA.debugLine="Dim cd As ColorDrawable";
_cd = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 520;BA.debugLine="Dim sd As StateListDrawable";
_sd = new anywheresoftware.b4a.objects.drawable.StateListDrawable();
 //BA.debugLineNum = 521;BA.debugLine="sd.Initialize";
_sd.Initialize();
 //BA.debugLineNum = 523;BA.debugLine="For Each v As EditText In et";
{
final anywheresoftware.b4a.objects.EditTextWrapper[] group4 = _et;
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_v = group4[index4];
 //BA.debugLineNum = 525;BA.debugLine="cd.Initialize2(clrTheme.btnDisableText,brd_r,2di";
_cd.Initialize2(mostCurrent._clrtheme._btndisabletext /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 526;BA.debugLine="sd.AddState(sd.State_Disabled, cd)";
_sd.AddState(_sd.State_Disabled,(android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 528;BA.debugLine="cd.Initialize2(clrTheme.txtAccent,brd_r,2dip,clr";
_cd.Initialize2(mostCurrent._clrtheme._txtaccent /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 529;BA.debugLine="sd.AddState(sd.State_Focused, cd)";
_sd.AddState(_sd.State_Focused,(android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 532;BA.debugLine="cd.Initialize2(clrTheme.txtNormal,brd_r,2dip,clr";
_cd.Initialize2(mostCurrent._clrtheme._txtnormal /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 533;BA.debugLine="sd.AddCatchAllState(cd)";
_sd.AddCatchAllState((android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 535;BA.debugLine="v.Background = sd";
_v.setBackground((android.graphics.drawable.Drawable)(_sd.getObject()));
 //BA.debugLineNum = 537;BA.debugLine="If NoPopupKB Then";
if (_nopopupkb) { 
 //BA.debugLineNum = 538;BA.debugLine="v.InputType = v.INPUT_TYPE_NONE";
_v.setInputType(_v.INPUT_TYPE_NONE);
 };
 }
};
 //BA.debugLineNum = 543;BA.debugLine="End Sub";
return "";
}
public static String  _skintextedit2(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.EditTextWrapper[] _et,int _brd_r) throws Exception{
anywheresoftware.b4a.objects.drawable.ColorDrawable _cd = null;
anywheresoftware.b4a.objects.drawable.StateListDrawable _sd = null;
anywheresoftware.b4a.objects.EditTextWrapper _v = null;
 //BA.debugLineNum = 495;BA.debugLine="Public Sub SkinTextEdit2(et() As EditText ,brd_r A";
 //BA.debugLineNum = 497;BA.debugLine="Dim cd As ColorDrawable";
_cd = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 498;BA.debugLine="Dim sd As StateListDrawable";
_sd = new anywheresoftware.b4a.objects.drawable.StateListDrawable();
 //BA.debugLineNum = 499;BA.debugLine="sd.Initialize";
_sd.Initialize();
 //BA.debugLineNum = 501;BA.debugLine="For Each v As EditText In et";
{
final anywheresoftware.b4a.objects.EditTextWrapper[] group4 = _et;
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_v = group4[index4];
 //BA.debugLineNum = 503;BA.debugLine="cd.Initialize2(clrTheme.btnDisableText,brd_r,2di";
_cd.Initialize2(mostCurrent._clrtheme._btndisabletext /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 504;BA.debugLine="sd.AddState(sd.State_Disabled, cd)";
_sd.AddState(_sd.State_Disabled,(android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 506;BA.debugLine="cd.Initialize2(clrTheme.txtAccent,brd_r,2dip,clr";
_cd.Initialize2(mostCurrent._clrtheme._txtaccent /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 507;BA.debugLine="sd.AddState(sd.State_Focused, cd)";
_sd.AddState(_sd.State_Focused,(android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 510;BA.debugLine="cd.Initialize2(clrTheme.txtNormal,brd_r,2dip,clr";
_cd.Initialize2(mostCurrent._clrtheme._txtnormal /*int*/ ,_brd_r,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2)),mostCurrent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 511;BA.debugLine="sd.AddCatchAllState(cd)";
_sd.AddCatchAllState((android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 513;BA.debugLine="v.Background = sd";
_v.setBackground((android.graphics.drawable.Drawable)(_sd.getObject()));
 }
};
 //BA.debugLineNum = 516;BA.debugLine="End Sub";
return "";
}
public static String  _themefloattextfield(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xfloattextfield[] _arr) throws Exception{
sadLogic.HomeCentral.b4xfloattextfield _o = null;
 //BA.debugLineNum = 126;BA.debugLine="Public Sub ThemeFloatTextField(Arr() As B4XFloatTe";
 //BA.debugLineNum = 127;BA.debugLine="For Each o As B4XFloatTextField In Arr";
{
final sadLogic.HomeCentral.b4xfloattextfield[] group1 = _arr;
final int groupLen1 = group1.length
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_o = group1[index1];
 }
};
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
return "";
}
}
