package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagemovement extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.pagemovement");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.pagemovement.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mpnlmain = null;
public String _mcallbackevent = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public sadLogic.OctoTouchController.foss.sadas_floatingpanel _fp = null;
public String _movejogsize = "";
public int _extruderlengthsize = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnljogmovement = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlgeneral = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnretract = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmoff = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnheat = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnfn = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnextrude = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnlength = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnxyright = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnxyleft = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnxyhome = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnxyforward = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnxyback = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnzup = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnzhome = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnzdown = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblgeneral = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblheaderz = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblheaderxy = null;
public boolean _mpageenabledisable = false;
public anywheresoftware.b4a.objects.PanelWrapper _pnlgeneral2 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlgeneral1 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnljogmovement1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmovemm0 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmovemm1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmovemm2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmovemm3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblmovepopup = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmovemm = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _blcr_touchmenu() throws Exception{
sadLogic.OctoTouchController.foss.dlgbltouchactions _o2 = null;
 //BA.debugLineNum = 377;BA.debugLine="Private Sub BLCR_TouchMenu";
 //BA.debugLineNum = 379;BA.debugLine="Dim o2 As dlgBLTouchActions";
_o2 = new sadLogic.OctoTouchController.foss.dlgbltouchactions();
 //BA.debugLineNum = 380;BA.debugLine="mMainObj.pObjCurrentDlg1 = o2.Initialize";
_mmainobj._pobjcurrentdlg1 /*Object*/  = _o2._initialize /*Object*/ (ba);
 //BA.debugLineNum = 381;BA.debugLine="o2.Show";
_o2._show /*void*/ ();
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return "";
}
public String  _btngeneral_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 136;BA.debugLine="Private Sub btnGeneral_Click";
 //BA.debugLineNum = 138;BA.debugLine="Dim o As B4XView : o = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 138;BA.debugLine="Dim o As B4XView : o = Sender";
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 140;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 142;BA.debugLine="If oc.isConnected = False Then Return";
if (_oc._isconnected /*boolean*/ ==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 150;BA.debugLine="Select Case o.Tag";
switch (BA.switchObjectToInt(_o.getTag(),(Object)("heat"),(Object)("elength"),(Object)("ext"),(Object)("ret"),(Object)("fmnu"),(Object)("moff"))) {
case 0: {
 //BA.debugLineNum = 151;BA.debugLine="Case \"heat\" 	: ToolHeatChangeRequest";
_toolheatchangerequest();
 break; }
case 1: {
 //BA.debugLineNum = 152;BA.debugLine="Case \"elength\" 	: SetExtruderLength";
_setextruderlength();
 break; }
case 2: {
 //BA.debugLineNum = 153;BA.debugLine="Case \"ext\"		: ExtrudeRetract(True)";
_extruderetract(__c.True);
 break; }
case 3: {
 //BA.debugLineNum = 154;BA.debugLine="Case \"ret\"		: ExtrudeRetract(False)";
_extruderetract(__c.False);
 break; }
case 4: {
 //BA.debugLineNum = 155;BA.debugLine="Case \"fmnu\"		: FunctionMenu";
_functionmenu();
 break; }
case 5: {
 //BA.debugLineNum = 156;BA.debugLine="Case \"moff\"		: MotorsOff";
_motorsoff();
 break; }
}
;
 //BA.debugLineNum = 159;BA.debugLine="End Sub";
return "";
}
public String  _btnjogmovemm_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _o = null;
 //BA.debugLineNum = 366;BA.debugLine="Private Sub btnJogMoveMM_Click";
 //BA.debugLineNum = 367;BA.debugLine="Dim o As Button = Sender";
_o = new anywheresoftware.b4a.objects.ButtonWrapper();
_o = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 368;BA.debugLine="MoveJogSize = o.Text.Replace(\"mm\",\"\")";
_movejogsize = _o.getText().replace("mm","");
 //BA.debugLineNum = 369;BA.debugLine="lblMovePopup.Text = o.Text";
_lblmovepopup.setText(BA.ObjectToCharSequence(_o.getText()));
 //BA.debugLineNum = 370;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
__c.CallSubDelayed2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 371;BA.debugLine="fp.Close '--- close floating panel";
_fp._close /*void*/ ();
 //BA.debugLineNum = 372;BA.debugLine="End Sub";
return "";
}
public String  _btnxyz_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _btn = null;
 //BA.debugLineNum = 161;BA.debugLine="Private Sub btnXYZ_Click";
 //BA.debugLineNum = 163;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 163;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 165;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 177;BA.debugLine="Select Case btn.Tag";
switch (BA.switchObjectToInt(_btn.getTag(),(Object)("Zhome"),(Object)("XYhome"),(Object)("Zup"),(Object)("Zdown"),(Object)("XYleft"),(Object)("XYright"),(Object)("XYforward"),(Object)("XYback"))) {
case 0: {
 //BA.debugLineNum = 180;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_z_home /*String*/ );
 break; }
case 1: {
 //BA.debugLineNum = 182;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xy_home /*String*/ );
 break; }
case 2: {
 //BA.debugLineNum = 184;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedz /*boolean*/ ) ? ((Object)("-")) : ((Object)(""))))+"")+_movejogsize).replace("!DIR!","z"));
 break; }
case 3: {
 //BA.debugLineNum = 186;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedz /*boolean*/ ) ? ((Object)("")) : ((Object)("-"))))+"")+_movejogsize).replace("!DIR!","z"));
 break; }
case 4: {
 //BA.debugLineNum = 188;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedx /*boolean*/ ) ? ((Object)("")) : ((Object)("-"))))+"")+_movejogsize).replace("!DIR!","x"));
 break; }
case 5: {
 //BA.debugLineNum = 190;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedx /*boolean*/ ) ? ((Object)("-")) : ((Object)(""))))+"")+_movejogsize).replace("!DIR!","x"));
 break; }
case 6: {
 //BA.debugLineNum = 192;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedy /*boolean*/ ) ? ((Object)("")) : ((Object)("-"))))+"")+_movejogsize).replace("!DIR!","y"));
 break; }
case 7: {
 //BA.debugLineNum = 194;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cJ";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cjog_xyz_move /*String*/ .replace("!SIZE!",(""+__c.SmartStringFormatter("",((_oc._printerprofileinvertedy /*boolean*/ ) ? ((Object)("-")) : ((Object)(""))))+"")+_movejogsize).replace("!DIR!","y"));
 break; }
}
;
 //BA.debugLineNum = 197;BA.debugLine="guiHelpers.Show_toast(\"Command Sent\",1200)";
_guihelpers._show_toast /*String*/ (ba,"Command Sent",(int) (1200));
 //BA.debugLineNum = 199;BA.debugLine="End Sub";
return "";
}
public void  _build_gui() throws Exception{
ResumableSub_Build_GUI rsub = new ResumableSub_Build_GUI(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Build_GUI extends BA.ResumableSub {
public ResumableSub_Build_GUI(sadLogic.OctoTouchController.foss.pagemovement parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.pagemovement parent;
float _bs = 0f;
anywheresoftware.b4a.objects.ButtonWrapper _btn = null;
anywheresoftware.b4a.objects.B4XViewWrapper[] group15;
int index15;
int groupLen15;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 65;BA.debugLine="fp.Initialize(Me,\"fp\",B4XPages.MainPage.Root)";
parent._fp._initialize /*String*/ (ba,parent,"fp",parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 66;BA.debugLine="fp.PreSize(260dip, 210dip)";
parent._fp._presize /*String*/ ((float) (parent.__c.DipToCurrent((int) (260))),(float) (parent.__c.DipToCurrent((int) (210))));
 //BA.debugLineNum = 67;BA.debugLine="fp.Panel.LoadLayout(\"viewMovementMM\")";
parent._fp._getpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().LoadLayout("viewMovementMM",ba);
 //BA.debugLineNum = 68;BA.debugLine="fp.ArrowVisible = False";
parent._fp._setarrowvisible /*boolean*/ (parent.__c.False);
 //BA.debugLineNum = 73;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnRetract,";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnretract,parent._btnmoff,parent._btnheat,parent._btnfn,parent._btnextrude,parent._btnlength,parent._btnxyright,parent._btnxyleft,parent._btnxyhome,parent._btnxyforward,parent._btnxyback,parent._btnzup,parent._btnzhome,parent._btnzdown,parent._btnmovemm0,parent._btnmovemm1,parent._btnmovemm2,parent._btnmovemm3});
 //BA.debugLineNum = 78;BA.debugLine="If guiHelpers.gScreenSizeAprox < 5.1 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._guihelpers._gscreensizeaprox /*double*/ <5.1) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 79;BA.debugLine="Dim bs As Float = btnExtrude.TextSize - 2";
_bs = (float) (parent._btnextrude.getTextSize()-2);
 //BA.debugLineNum = 80;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnRetrac";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnretract,parent._btnmoff,parent._btnextrude},_bs);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 82;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblGener";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{parent._lblgeneral,parent._lblheaderz,parent._lblheaderxy,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblmovepopup.getObject()))});
 //BA.debugLineNum = 83;BA.debugLine="guiHelpers.ResizeText(\"General\",lblGeneral)";
parent._guihelpers._resizetext /*String*/ (ba,(Object)("General"),parent._lblgeneral);
 //BA.debugLineNum = 84;BA.debugLine="guiHelpers.ResizeText(\"Z\",lblHeaderZ)";
parent._guihelpers._resizetext /*String*/ (ba,(Object)("Z"),parent._lblheaderz);
 //BA.debugLineNum = 85;BA.debugLine="guiHelpers.ResizeText(\"X/Y\",lblHeaderXY)";
parent._guihelpers._resizetext /*String*/ (ba,(Object)("X/Y"),parent._lblheaderxy);
 //BA.debugLineNum = 86;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 9;
return;
case 9:
//C
this.state = 5;
;
 //BA.debugLineNum = 89;BA.debugLine="For Each btn As Button In Array As B4XView(btnXYl";
if (true) break;

case 5:
//for
this.state = 8;
_btn = new anywheresoftware.b4a.objects.ButtonWrapper();
group15 = new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnxyleft.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnxyright.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnzhome.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnzup.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnzdown.getObject()))};
index15 = 0;
groupLen15 = group15.length;
this.state = 10;
if (true) break;

case 10:
//C
this.state = 8;
if (index15 < groupLen15) {
this.state = 7;
_btn = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(group15[index15].getObject()));}
if (true) break;

case 11:
//C
this.state = 10;
index15++;
if (true) break;

case 7:
//C
this.state = 11;
 //BA.debugLineNum = 90;BA.debugLine="btn.Height = btnXYhome.Height";
_btn.setHeight(parent._btnxyhome.getHeight());
 if (true) break;
if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 92;BA.debugLine="btnXYleft.Top = btnXYhome.Top : btnXYright.Top =";
parent._btnxyleft.setTop(parent._btnxyhome.getTop());
 //BA.debugLineNum = 92;BA.debugLine="btnXYleft.Top = btnXYhome.Top : btnXYright.Top =";
parent._btnxyright.setTop(parent._btnxyhome.getTop());
 //BA.debugLineNum = 92;BA.debugLine="btnXYleft.Top = btnXYhome.Top : btnXYright.Top =";
parent._btnzhome.setTop(parent._btnxyhome.getTop());
 //BA.debugLineNum = 93;BA.debugLine="btnZdown.Top = btnXYforward.Top : btnZup.Top = bt";
parent._btnzdown.setTop(parent._btnxyforward.getTop());
 //BA.debugLineNum = 93;BA.debugLine="btnZdown.Top = btnXYforward.Top : btnZup.Top = bt";
parent._btnzup.setTop(parent._btnxyback.getTop());
 //BA.debugLineNum = 94;BA.debugLine="btnZdown.Top = btnXYforward.Top : btnZup.Top = bt";
parent._btnzdown.setTop(parent._btnxyforward.getTop());
 //BA.debugLineNum = 94;BA.debugLine="btnZdown.Top = btnXYforward.Top : btnZup.Top = bt";
parent._btnzup.setTop(parent._btnxyback.getTop());
 //BA.debugLineNum = 97;BA.debugLine="lblMovePopup.Top = btnXYforward.Top +btnXYforward";
parent._lblmovepopup.setTop((int) (parent._btnxyforward.getTop()+parent._btnxyforward.getHeight()/(double)2));
 //BA.debugLineNum = 98;BA.debugLine="pnlMoveMM.SetColorAndBorder(clrTheme.BackgroundHe";
parent._pnlmovemm.SetColorAndBorder(parent._clrtheme._backgroundheader /*int*/ ,parent.__c.DipToCurrent((int) (1)),parent._clrtheme._txtnormal /*int*/ ,parent.__c.DipToCurrent((int) (8)));
 //BA.debugLineNum = 100;BA.debugLine="MoveJogSize = \"10\"";
parent._movejogsize = "10";
 //BA.debugLineNum = 101;BA.debugLine="lblMovePopup.Text = \"10mm\"";
parent._lblmovepopup.setText(BA.ObjectToCharSequence("10mm"));
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.objects.collections.Map  _buildfunctionmnu() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
int _jj = 0;
String _f = "";
anywheresoftware.b4a.objects.collections.Map _da = null;
 //BA.debugLineNum = 247;BA.debugLine="Private Sub BuildFunctionMnu() As Map";
 //BA.debugLineNum = 248;BA.debugLine="Dim m As Map : m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 248;BA.debugLine="Dim m As Map : m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 249;BA.debugLine="m.Put(\"Pre-Heat Menu\",\"prh\")";
_m.Put((Object)("Pre-Heat Menu"),(Object)("prh"));
 //BA.debugLineNum = 250;BA.debugLine="m.Put(\"Cooling Fan Menu\",\"clf\")";
_m.Put((Object)("Cooling Fan Menu"),(Object)("clf"));
 //BA.debugLineNum = 252;BA.debugLine="If config.ReadManualBedScrewLevelFLAG 	Then m.Put";
if (_config._readmanualbedscrewlevelflag /*boolean*/ (ba)) { 
_m.Put((Object)("Manual Bed Leveling Wizard"),(Object)("blw"));};
 //BA.debugLineNum = 253;BA.debugLine="If config.ReadWizardFilamentChangeFLAG  Then m.Pu";
if (_config._readwizardfilamentchangeflag /*boolean*/ (ba)) { 
_m.Put((Object)("Change Filament Wizard"),(Object)("cf"));};
 //BA.debugLineNum = 254;BA.debugLine="If config.ReadBLCRtouchFLAG     		Then m.Put(\"BL/";
if (_config._readblcrtouchflag /*boolean*/ (ba)) { 
_m.Put((Object)("BL/CR Touch Probe Testing"),(Object)("blcr"));};
 //BA.debugLineNum = 255;BA.debugLine="If config.ReadZOffsetFLAG 				Then m.Put(\"Set Z O";
if (_config._readzoffsetflag /*boolean*/ (ba)) { 
_m.Put((Object)("Set Z Offset For Auto Bed Leveling)"),(Object)("zo"));};
 //BA.debugLineNum = 256;BA.debugLine="If config.ReadManualBedMeshLevelFLAG	Then m.Put(\"";
if (_config._readmanualbedmeshlevelflag /*boolean*/ (ba)) { 
_m.Put((Object)("Manual Mesh Bed Leveling Wizard"),(Object)("mblw"));};
 //BA.debugLineNum = 258;BA.debugLine="For jj =0 To 7";
{
final int step10 = 1;
final int limit10 = (int) (7);
_jj = (int) (0) ;
for (;_jj <= limit10 ;_jj = _jj + step10 ) {
 //BA.debugLineNum = 259;BA.debugLine="Dim f As String = jj & gblConst.GCODE_CUSTOM_SET";
_f = BA.NumberToString(_jj)+_gblconst._gcode_custom_setup_file /*String*/ ;
 //BA.debugLineNum = 260;BA.debugLine="Dim da As Map = File.ReadMap(xui.DefaultFolder,f";
_da = new anywheresoftware.b4a.objects.collections.Map();
_da = __c.File.ReadMap(_xui.getDefaultFolder(),_f);
 //BA.debugLineNum = 261;BA.debugLine="If da.Get(\"wmenu\").As(Boolean) = True Then";
if ((BA.ObjectToBoolean(_da.Get((Object)("wmenu"))))==__c.True) { 
 //BA.debugLineNum = 262;BA.debugLine="m.Put(da.Get(\"desc\"),\"f\" & jj)";
_m.Put(_da.Get((Object)("desc")),(Object)("f"+BA.NumberToString(_jj)));
 };
 }
};
 //BA.debugLineNum = 265;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"pageMovement\"";
_mmodule = "pageMovement";
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mPnlMain As B4XView";
_mpnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private mCallBackEvent As String 'ignore";
_mcallbackevent = "";
 //BA.debugLineNum = 13;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 14;BA.debugLine="Private fp As sadAS_FloatingPanel";
_fp = new sadLogic.OctoTouchController.foss.sadas_floatingpanel();
 //BA.debugLineNum = 16;BA.debugLine="Private MoveJogSize As String";
_movejogsize = "";
 //BA.debugLineNum = 17;BA.debugLine="Private ExtruderLengthSize As Int = 10";
_extruderlengthsize = (int) (10);
 //BA.debugLineNum = 19;BA.debugLine="Private pnlJogMovement As B4XView";
_pnljogmovement = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private pnlGeneral As B4XView";
_pnlgeneral = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private btnRetract,btnMOff,btnHeat,btnFN,btnExtru";
_btnretract = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnmoff = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnheat = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnfn = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnextrude = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnlength = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private btnXYright,btnXYleft,btnXYhome,btnXYforwa";
_btnxyright = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnxyleft = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnxyhome = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnxyforward = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnxyback = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private btnZup,btnZhome,btnZdown As Button";
_btnzup = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnzhome = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnzdown = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private lblGeneral,lblHeaderZ,lblHeaderXY As B4XV";
_lblgeneral = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblheaderz = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblheaderxy = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private mPageEnableDisable As Boolean";
_mpageenabledisable = false;
 //BA.debugLineNum = 29;BA.debugLine="Private pnlGeneral2,pnlGeneral1 As Panel";
_pnlgeneral2 = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlgeneral1 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private pnlJogMovement1 As Panel";
_pnljogmovement1 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private btnMoveMM0 As Button";
_btnmovemm0 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private btnMoveMM1 As Button";
_btnmovemm1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private btnMoveMM2 As Button";
_btnmovemm2 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private btnMoveMM3 As Button";
_btnmovemm3 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private lblMovePopup As Label";
_lblmovepopup = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private pnlMoveMM As B4XView";
_pnlmovemm = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _extruderetract(boolean _extrude) throws Exception{
 //BA.debugLineNum = 323;BA.debugLine="Private Sub ExtrudeRetract(Extrude As Boolean)";
 //BA.debugLineNum = 325;BA.debugLine="If oc.Tool1ActualReal < 150 Then";
if (_oc._tool1actualreal /*float*/ <150) { 
 //BA.debugLineNum = 326;BA.debugLine="guiHelpers.Show_toast(\"Tool is not hot enough\",1";
_guihelpers._show_toast /*String*/ (ba,"Tool is not hot enough",(int) (1800));
 //BA.debugLineNum = 327;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 336;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cCMD";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_tool_extrude_retract /*String*/ .replace("!LEN!",BA.ObjectToString(((_extrude) ? ((Object)("")) : ((Object)("-"))))+BA.NumberToString(_extruderlengthsize)));
 //BA.debugLineNum = 337;BA.debugLine="guiHelpers.Show_toast(IIf(Extrude,\"Extrusion\",\"Re";
_guihelpers._show_toast /*String*/ (ba,BA.ObjectToString(((_extrude) ? ((Object)("Extrusion")) : ((Object)("Retraction"))))+": "+BA.NumberToString(_extruderlengthsize)+"mm",(int) (1200));
 //BA.debugLineNum = 340;BA.debugLine="End Sub";
return "";
}
public String  _extruderlength_set(String _value) throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Private Sub ExtruderLength_Set(value As String)";
 //BA.debugLineNum = 225;BA.debugLine="If value.Length = 0 Then Return";
if (_value.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 227;BA.debugLine="ExtruderLengthSize = value";
_extruderlengthsize = (int)(Double.parseDouble(_value));
 //BA.debugLineNum = 228;BA.debugLine="btnLength.Text = ExtruderLengthSize.As(String) &";
_btnlength.setText(BA.ObjectToCharSequence((BA.NumberToString(_extruderlengthsize))+"mm"));
 //BA.debugLineNum = 230;BA.debugLine="End Sub";
return "";
}
public String  _functionmenu() throws Exception{
sadLogic.OctoTouchController.foss.dlglistbox _o1 = null;
float _w = 0f;
 //BA.debugLineNum = 235;BA.debugLine="Private Sub FunctionMenu";
 //BA.debugLineNum = 237;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.foss.dlglistbox();
 //BA.debugLineNum = 238;BA.debugLine="mMainObj.pObjCurrentDlg1 = o1.Initialize(\"Functio";
_mmainobj._pobjcurrentdlg1 /*Object*/  = _o1._initialize /*Object*/ (ba,(Object)("Function Menu"),this,"FunctionMenu_Event",_mmainobj._pobjcurrentdlg1 /*Object*/ );
 //BA.debugLineNum = 239;BA.debugLine="Dim w As Float = 320dip";
_w = (float) (__c.DipToCurrent((int) (320)));
 //BA.debugLineNum = 240;BA.debugLine="If guiHelpers.gIsLandScape = False And guiHelpers";
if (_guihelpers._gislandscape /*boolean*/ ==__c.False && _guihelpers._gscreensizeaprox /*double*/ <4.5) { 
_w = (float) (_guihelpers._gwidth /*float*/ *.9);};
 //BA.debugLineNum = 241;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 242;BA.debugLine="o1.Show(250dip,w,BuildFunctionMnu)";
_o1._show /*void*/ ((float) (__c.DipToCurrent((int) (250))),_w,_buildfunctionmnu());
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _functionmenu_event(String _value,Object _tag) throws Exception{
String _msg = "";
sadLogic.OctoTouchController.foss.dlgmsgbox _mb = null;
String _ask = "";
sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz_z_offset _bm = null;
sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz _uu = null;
sadLogic.OctoTouchController.foss.dlgfilamentctrl _o1 = null;
boolean _areweinthemiddleofprint = false;
 //BA.debugLineNum = 268;BA.debugLine="Private Sub FunctionMenu_Event(value As String, ta";
 //BA.debugLineNum = 271;BA.debugLine="B4XPages.MainPage.pObjCurrentDlg1 = Null";
_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._pobjcurrentdlg1 /*Object*/  = __c.Null;
 //BA.debugLineNum = 272;BA.debugLine="If value.Length = 0 Then Return";
if (_value.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 273;BA.debugLine="Dim msg As String = \"Command sent: \" 'ignore";
_msg = "Command sent: ";
 //BA.debugLineNum = 274;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.foss.dlgmsgbox();
 //BA.debugLineNum = 275;BA.debugLine="mb.Initialize(mMainObj.root,\"Continue\",IIf(guiHel";
_mb._initialize /*String*/ (ba,_mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Continue",(float)(BA.ObjectToNumber(((_guihelpers._gislandscape /*boolean*/ ) ? ((Object)(__c.DipToCurrent((int) (500)))) : ((Object)(_guihelpers._gwidth /*float*/ -__c.DipToCurrent((int) (40))))))),(float) (__c.DipToCurrent((int) (200))),__c.False);
 //BA.debugLineNum = 276;BA.debugLine="Dim Ask As String = \"Touch OK to continue\" 'ignor";
_ask = "Touch OK to continue";
 //BA.debugLineNum = 278;BA.debugLine="Select Case value";
switch (BA.switchObjectToInt(_value,"clf","f0","f1","f2","f3","f4","f5","f6","f7","zo","mblw","blw","cf","prh","blcr")) {
case 0: {
 //BA.debugLineNum = 280;BA.debugLine="CallSub(B4XPages.MainPage,\"Cooling_Fan\")";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Cooling_Fan");
 break; }
case 1: 
case 2: 
case 3: 
case 4: 
case 5: 
case 6: 
case 7: 
case 8: {
 //BA.debugLineNum = 283;BA.debugLine="CallSubDelayed2(mMainObj,\"RunGCodeOnOff_Menu\",v";
__c.CallSubDelayed2(ba,(Object)(_mmainobj),"RunGCodeOnOff_Menu",(Object)((_value).replace("f","")+_gblconst._gcode_custom_setup_file /*String*/ ));
 break; }
case 9: {
 //BA.debugLineNum = 286;BA.debugLine="Dim bm As dlgBedLevelMeshWiz_Z_OffSet";
_bm = new sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz_z_offset();
 //BA.debugLineNum = 287;BA.debugLine="mMainObj.pobjWizards = bm.Initialize(mMainObj.p";
_mmainobj._pobjwizards /*Object*/  = _bm._initialize /*Object*/ (ba,_mmainobj._pnlwizards /*anywheresoftware.b4a.objects.PanelWrapper*/ ,_value);
 //BA.debugLineNum = 288;BA.debugLine="bm.Show(\"Set Z Offset Wizard\")";
_bm._show /*String*/ ("Set Z Offset Wizard");
 break; }
case 10: {
 //BA.debugLineNum = 291;BA.debugLine="Dim bm As dlgBedLevelMeshWiz_Z_OffSet";
_bm = new sadLogic.OctoTouchController.foss.dlgbedlevelmeshwiz_z_offset();
 //BA.debugLineNum = 292;BA.debugLine="mMainObj.pobjWizards = bm.Initialize(mMainObj.p";
_mmainobj._pobjwizards /*Object*/  = _bm._initialize /*Object*/ (ba,_mmainobj._pnlwizards /*anywheresoftware.b4a.objects.PanelWrapper*/ ,_value);
 //BA.debugLineNum = 293;BA.debugLine="bm.Show(\"Mesh Bed Leveling Wizard\")";
_bm._show /*String*/ ("Mesh Bed Leveling Wizard");
 break; }
case 11: {
 //BA.debugLineNum = 296;BA.debugLine="Dim uu As dlgBedLevelManualWiz";
_uu = new sadLogic.OctoTouchController.foss.dlgbedlevelmanualwiz();
 //BA.debugLineNum = 297;BA.debugLine="mMainObj.pobjWizards = uu.Initialize(mMainObj.p";
_mmainobj._pobjwizards /*Object*/  = _uu._initialize /*Object*/ (ba,_mmainobj._pnlwizards /*anywheresoftware.b4a.objects.PanelWrapper*/ );
 //BA.debugLineNum = 298;BA.debugLine="uu.Show";
_uu._show /*void*/ ();
 break; }
case 12: {
 //BA.debugLineNum = 301;BA.debugLine="Dim o1 As dlgFilamentCtrl";
_o1 = new sadLogic.OctoTouchController.foss.dlgfilamentctrl();
 //BA.debugLineNum = 302;BA.debugLine="Dim AreWeInTheMiddleOfPrint As Boolean = True";
_areweinthemiddleofprint = __c.True;
 //BA.debugLineNum = 303;BA.debugLine="If oc.JobPrintState.EqualsIgnoreCase(\"Operation";
if (_oc._jobprintstate /*String*/ .equalsIgnoreCase("Operational")) { 
_areweinthemiddleofprint = __c.False;};
 //BA.debugLineNum = 304;BA.debugLine="mMainObj.pObjCurrentDlg2 = o1.Initialize(AreWeI";
_mmainobj._pobjcurrentdlg2 /*Object*/  = _o1._initialize /*Object*/ (ba,_areweinthemiddleofprint);
 //BA.debugLineNum = 305;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 break; }
case 13: {
 //BA.debugLineNum = 308;BA.debugLine="CallSub(B4XPages.MainPage,\"ShowPreHeatMenu_All\"";
__c.CallSubNew(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"ShowPreHeatMenu_All");
 break; }
case 14: {
 //BA.debugLineNum = 311;BA.debugLine="BLCR_TouchMenu";
_blcr_touchmenu();
 break; }
default: {
 //BA.debugLineNum = 314;BA.debugLine="msg = \" ...TODO... \"";
_msg = " ...TODO... ";
 break; }
}
;
 //BA.debugLineNum = 318;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _masterpanel,String _callbackevent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 39;BA.debugLine="Public Sub Initialize(masterPanel As B4XView,callB";
 //BA.debugLineNum = 41;BA.debugLine="mPnlMain = masterPanel";
_mpnlmain = _masterpanel;
 //BA.debugLineNum = 42;BA.debugLine="mCallBackEvent = callBackEvent";
_mcallbackevent = _callbackevent;
 //BA.debugLineNum = 43;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 45;BA.debugLine="mPnlMain.SetLayoutAnimated(0,0,masterPanel.top,ma";
_mpnlmain.SetLayoutAnimated((int) (0),(int) (0),_masterpanel.getTop(),_masterpanel.getWidth(),_masterpanel.getHeight());
 //BA.debugLineNum = 46;BA.debugLine="mPnlMain.LoadLayout(\"pageMovement\")";
_mpnlmain.LoadLayout("pageMovement",ba);
 //BA.debugLineNum = 48;BA.debugLine="Build_GUI";
_build_gui();
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _lblmovepopup_click() throws Exception{
float _top = 0f;
 //BA.debugLineNum = 354;BA.debugLine="Private Sub lblMovePopup_Click";
 //BA.debugLineNum = 355;BA.debugLine="Dim Top As Float";
_top = 0f;
 //BA.debugLineNum = 356;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (_guihelpers._gislandscape /*boolean*/ ) { 
 //BA.debugLineNum = 357;BA.debugLine="Top = lblMovePopup.Top - (pnlMoveMM.Height/2)";
_top = (float) (_lblmovepopup.getTop()-(_pnlmovemm.getHeight()/(double)2));
 //BA.debugLineNum = 358;BA.debugLine="fp.OpenOrientation = fp.OpenOrientation_BottomTo";
_fp._setopenorientation(_fp._getopenorientation_bottomtop /*String*/ ());
 }else {
 //BA.debugLineNum = 360;BA.debugLine="Top = lblMovePopup.Top + lblMovePopup.Height + 1";
_top = (float) (_lblmovepopup.getTop()+_lblmovepopup.getHeight()+__c.DipToCurrent((int) (10)));
 //BA.debugLineNum = 361;BA.debugLine="fp.OpenOrientation = fp.OpenOrientation_LeftTop";
_fp._setopenorientation(_fp._getopenorientation_lefttop /*String*/ ());
 };
 //BA.debugLineNum = 363;BA.debugLine="fp.Show(lblMovePopup.Left,Top, pnlMoveMM.Width,pn";
_fp._show /*void*/ ((float) (_lblmovepopup.getLeft()),_top,(float) (_pnlmovemm.getWidth()),(float) (_pnlmovemm.getHeight()));
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="public Sub Lost_focus()";
 //BA.debugLineNum = 59;BA.debugLine="mPnlMain.SetVisibleAnimated(500,False)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 60;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public String  _motorsoff() throws Exception{
 //BA.debugLineNum = 342;BA.debugLine="Private Sub MotorsOff";
 //BA.debugLineNum = 347;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cPOS";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cpost_gcode_command /*String*/ .replace("!CMD!","M18"));
 //BA.debugLineNum = 350;BA.debugLine="guiHelpers.Show_toast(\"Command sent: Motors Off\",";
_guihelpers._show_toast /*String*/ (ba,"Command sent: Motors Off",(int) (1800));
 //BA.debugLineNum = 351;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="public Sub Set_focus()";
 //BA.debugLineNum = 53;BA.debugLine="mPnlMain.SetVisibleAnimated(500,True)";
_mpnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 54;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
_mpnlmain.setEnabled(_oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 55;BA.debugLine="Update_Printer_Btns";
_update_printer_btns();
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _setextruderlength() throws Exception{
sadLogic.OctoTouchController.foss.dlgnumericinput _o1 = null;
 //BA.debugLineNum = 215;BA.debugLine="Private Sub SetExtruderLength";
 //BA.debugLineNum = 217;BA.debugLine="Dim o1 As dlgNumericInput";
_o1 = new sadLogic.OctoTouchController.foss.dlgnumericinput();
 //BA.debugLineNum = 218;BA.debugLine="o1.Initialize(\"Extruder Length\",\"Enter Length\",Me";
_o1._initialize /*String*/ (ba,"Extruder Length","Enter Length",this,"ExtruderLength_Set");
 //BA.debugLineNum = 219;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 //BA.debugLineNum = 221;BA.debugLine="End Sub";
return "";
}
public String  _toolheatchangerequest() throws Exception{
sadLogic.OctoTouchController.foss.heaterroutines _oo = null;
 //BA.debugLineNum = 207;BA.debugLine="Private Sub ToolHeatChangeRequest";
 //BA.debugLineNum = 209;BA.debugLine="Dim oo As HeaterRoutines : oo.Initialize";
_oo = new sadLogic.OctoTouchController.foss.heaterroutines();
 //BA.debugLineNum = 209;BA.debugLine="Dim oo As HeaterRoutines : oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 210;BA.debugLine="oo.PopupToolHeaterMenu";
_oo._popuptoolheatermenu /*String*/ ();
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public String  _update_printer_btns() throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="public Sub Update_Printer_Btns";
 //BA.debugLineNum = 109;BA.debugLine="mPageEnableDisable = IIf(oc.isPrinting,False,True";
_mpageenabledisable = BA.ObjectToBoolean(((_oc._isprinting /*boolean*/ ) ? ((Object)(__c.False)) : ((Object)(__c.True))));
 //BA.debugLineNum = 110;BA.debugLine="If oc.IsPaused2 And File.ReadMap(xui.DefaultFolde";
if (_oc._ispaused2 /*boolean*/  && (BA.ObjectToBoolean(__c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._general_options_file /*String*/ ).GetDefault((Object)("mpsd"),(Object)(__c.False))))) { 
 //BA.debugLineNum = 111;BA.debugLine="mPageEnableDisable = True";
_mpageenabledisable = __c.True;
 //BA.debugLineNum = 112;BA.debugLine="If oc.JobPrintState = \"Resuming\" Then mPageEnabl";
if ((_oc._jobprintstate /*String*/ ).equals("Resuming")) { 
_mpageenabledisable = __c.False;};
 };
 //BA.debugLineNum = 115;BA.debugLine="guiHelpers.EnableDisableBtns2(Array As Button( _";
_guihelpers._enabledisablebtns2 /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnretract,_btnmoff,_btnheat,_btnfn,_btnextrude,_btnlength,_btnxyright,_btnxyleft,_btnxyhome,_btnxyforward,_btnxyback,_btnzup,_btnzhome,_btnzdown},_mpageenabledisable);
 //BA.debugLineNum = 121;BA.debugLine="mPnlMain.Enabled = oc.isConnected";
_mpnlmain.setEnabled(_oc._isconnected /*boolean*/ );
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "UPDATE_PRINTER_BTNS"))
	return _update_printer_btns();
return BA.SubDelegator.SubNotFound;
}
}
