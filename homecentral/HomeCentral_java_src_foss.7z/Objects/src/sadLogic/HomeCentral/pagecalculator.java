package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagecalculator extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pagecalculator");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pagecalculator.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public anywheresoftware.b4a.objects.StringUtils _stu = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblpaperroll = null;
public double _scaleauto = 0;
public String _sval = "";
public double _val = 0;
public String _op0 = "";
public double _result = 0;
public String _txt = "";
public int _new = 0;
public boolean _charsizelarge = false;
public anywheresoftware.b4a.objects.ButtonWrapper _btn0 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn3 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn4 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn6 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn7 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn8 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn9 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btna = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnb = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnc = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnd = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btne = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnp = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnback = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnclr = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnexit = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncharsize = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlkeyboard = null;
public anywheresoftware.b4a.objects.ScrollViewWrapper _scvpaperroll = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgpapertape = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btnback_click() throws Exception{
 //BA.debugLineNum = 302;BA.debugLine="Private Sub btnBack_Click";
 //BA.debugLineNum = 303;BA.debugLine="If sVal.Length > 0 Then";
if (_sval.length()>0) { 
 //BA.debugLineNum = 304;BA.debugLine="Txt = sVal.SubString2(0, sVal.Length - 1)";
_txt = _sval.substring((int) (0),(int) (_sval.length()-1));
 //BA.debugLineNum = 305;BA.debugLine="sVal = sVal.SubString2(0, sVal.Length - 1)";
_sval = _sval.substring((int) (0),(int) (_sval.length()-1));
 //BA.debugLineNum = 306;BA.debugLine="UpdateTape";
_updatetape();
 };
 //BA.debugLineNum = 308;BA.debugLine="End Sub";
return "";
}
public String  _btncharsize_click() throws Exception{
 //BA.debugLineNum = 310;BA.debugLine="Private Sub btnCharSize_Click";
 //BA.debugLineNum = 311;BA.debugLine="If CharSizeLarge = False Then";
if (_charsizelarge==__c.False) { 
 //BA.debugLineNum = 312;BA.debugLine="lblPaperRoll.TextSize = 19 * ScaleAuto";
_lblpaperroll.setTextSize((float) (19*_scaleauto));
 }else {
 //BA.debugLineNum = 314;BA.debugLine="lblPaperRoll.TextSize = 26 * ScaleAuto";
_lblpaperroll.setTextSize((float) (26*_scaleauto));
 };
 //BA.debugLineNum = 316;BA.debugLine="CharSizeLarge = Not (CharSizeLarge)";
_charsizelarge = __c.Not(_charsizelarge);
 //BA.debugLineNum = 317;BA.debugLine="End Sub";
return "";
}
public void  _btnclr_click() throws Exception{
ResumableSub_btnClr_Click rsub = new ResumableSub_btnClr_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnClr_Click extends BA.ResumableSub {
public ResumableSub_btnClr_Click(sadLogic.HomeCentral.pagecalculator parent) {
this.parent = parent;
}
sadLogic.HomeCentral.pagecalculator parent;
sadLogic.HomeCentral.dlgthemedmsgbox _o = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 287;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o = new sadLogic.HomeCentral.dlgthemedmsgbox();
 //BA.debugLineNum = 287;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 288;BA.debugLine="Wait For (o.Show(\"Do you really want To clear the";
parent.__c.WaitFor("complete", ba, this, _o._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Do you really want To clear the calculator?","A T T E N T I O N","YES","","CANCEL"));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 289;BA.debugLine="If i = XUI.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_i==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 290;BA.debugLine="Val = 0";
parent._val = 0;
 //BA.debugLineNum = 291;BA.debugLine="sVal = \"\"";
parent._sval = "";
 //BA.debugLineNum = 292;BA.debugLine="Result = 0";
parent._result = 0;
 //BA.debugLineNum = 293;BA.debugLine="New = 0";
parent._new = (int) (0);
 //BA.debugLineNum = 294;BA.debugLine="Txt = \"\"";
parent._txt = "";
 //BA.debugLineNum = 295;BA.debugLine="Op0 = \"\"";
parent._op0 = "";
 //BA.debugLineNum = 296;BA.debugLine="lblPaperRoll.Text = \"\"";
parent._lblpaperroll.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 297;BA.debugLine="lblPaperRoll.Height = scvPaperRoll.Height";
parent._lblpaperroll.setHeight(parent._scvpaperroll.getHeight());
 //BA.debugLineNum = 298;BA.debugLine="scvPaperRoll.Panel.Height = scvPaperRoll.Height";
parent._scvpaperroll.getPanel().setHeight(parent._scvpaperroll.getHeight());
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 300;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public String  _btndigit_click() throws Exception{
String _b = "";
 //BA.debugLineNum = 93;BA.debugLine="Private Sub btnDigit_Click";
 //BA.debugLineNum = 94;BA.debugLine="Dim b As String = Sender.As(B4XView).Tag";
_b = BA.ObjectToString(((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)))).getTag());
 //BA.debugLineNum = 95;BA.debugLine="If New = 0 Then New = 1";
if (_new==0) { 
_new = (int) (1);};
 //BA.debugLineNum = 97;BA.debugLine="Select b";
switch (BA.switchObjectToInt(_b,"0","1","2","3","4","5","6","7","8","9","3.1415926535897932",".","a","b","c","d","e","y","g","s","x","f")) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: 
case 5: 
case 6: 
case 7: 
case 8: 
case 9: 
case 10: 
case 11: {
 //BA.debugLineNum = 99;BA.debugLine="Select Op0";
switch (BA.switchObjectToInt(_op0,"g","s","m","x")) {
case 0: 
case 1: 
case 2: 
case 3: {
 //BA.debugLineNum = 101;BA.debugLine="Return";
if (true) return "";
 break; }
}
;
 //BA.debugLineNum = 104;BA.debugLine="If Op0 = \"e\" Then";
if ((_op0).equals("e")) { 
 //BA.debugLineNum = 105;BA.debugLine="Txt = Txt & CRLF & CRLF";
_txt = _txt+__c.CRLF+__c.CRLF;
 //BA.debugLineNum = 106;BA.debugLine="sVal = \"\"";
_sval = "";
 //BA.debugLineNum = 107;BA.debugLine="Op0 = \"\"";
_op0 = "";
 //BA.debugLineNum = 108;BA.debugLine="Result = 0";
_result = 0;
 //BA.debugLineNum = 109;BA.debugLine="New = 0";
_new = (int) (0);
 };
 //BA.debugLineNum = 112;BA.debugLine="If b = \"3.1415926535897932\" Then";
if ((_b).equals("3.1415926535897932")) { 
 //BA.debugLineNum = 113;BA.debugLine="If sVal <> \"\" Then";
if ((_sval).equals("") == false) { 
 //BA.debugLineNum = 114;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 116;BA.debugLine="Txt = Txt & cPI";
_txt = _txt+BA.NumberToString(__c.cPI);
 //BA.debugLineNum = 117;BA.debugLine="sVal = cPI";
_sval = BA.NumberToString(__c.cPI);
 }else if((_b).equals(".")) { 
 //BA.debugLineNum = 119;BA.debugLine="If sVal.IndexOf(\".\") < 0 Then";
if (_sval.indexOf(".")<0) { 
 //BA.debugLineNum = 120;BA.debugLine="Txt = Txt & b";
_txt = _txt+_b;
 //BA.debugLineNum = 121;BA.debugLine="sVal = sVal & b";
_sval = _sval+_b;
 };
 }else {
 //BA.debugLineNum = 124;BA.debugLine="Txt = Txt & b";
_txt = _txt+_b;
 //BA.debugLineNum = 125;BA.debugLine="sVal = sVal & b";
_sval = _sval+_b;
 };
 break; }
case 12: 
case 13: 
case 14: 
case 15: 
case 16: 
case 17: {
 //BA.debugLineNum = 128;BA.debugLine="If sVal =\"\" Then";
if ((_sval).equals("")) { 
 //BA.debugLineNum = 129;BA.debugLine="Select Op0";
switch (BA.switchObjectToInt(_op0,"a","b","c","d","y","")) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: 
case 5: {
 //BA.debugLineNum = 131;BA.debugLine="Return";
if (true) return "";
 break; }
}
;
 //BA.debugLineNum = 133;BA.debugLine="sVal = Result";
_sval = BA.NumberToString(_result);
 };
 //BA.debugLineNum = 135;BA.debugLine="GetValue(b)";
_getvalue(_b);
 break; }
case 18: 
case 19: 
case 20: {
 //BA.debugLineNum = 137;BA.debugLine="If sVal = \"\" Then";
if ((_sval).equals("")) { 
 //BA.debugLineNum = 138;BA.debugLine="Select Op0";
switch (BA.switchObjectToInt(_op0,"a","b","c","d","y","")) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: 
case 5: {
 //BA.debugLineNum = 140;BA.debugLine="Return";
if (true) return "";
 break; }
}
;
 //BA.debugLineNum = 142;BA.debugLine="sVal = Result";
_sval = BA.NumberToString(_result);
 };
 //BA.debugLineNum = 144;BA.debugLine="If Op0 = \"\" Then";
if ((_op0).equals("")) { 
 //BA.debugLineNum = 145;BA.debugLine="Result = sVal";
_result = (double)(Double.parseDouble(_sval));
 };
 //BA.debugLineNum = 147;BA.debugLine="GetValue(b)";
_getvalue(_b);
 break; }
case 21: {
 //BA.debugLineNum = 149;BA.debugLine="If Op0 = \"e\" Then";
if ((_op0).equals("e")) { 
 //BA.debugLineNum = 150;BA.debugLine="Txt = Txt & CRLF & CRLF";
_txt = _txt+__c.CRLF+__c.CRLF;
 //BA.debugLineNum = 151;BA.debugLine="New = 0";
_new = (int) (0);
 //BA.debugLineNum = 152;BA.debugLine="sVal = \"\"";
_sval = "";
 //BA.debugLineNum = 153;BA.debugLine="Op0 = \"\"";
_op0 = "";
 };
 break; }
}
;
 //BA.debugLineNum = 157;BA.debugLine="UpdateTape";
_updatetape();
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Private Sub Build_Side_Menu";
 //BA.debugLineNum = 84;BA.debugLine="Menus.BuildSideMenu(Array As String(\"\"),Array As";
_menus._buildsidemenu /*String*/ (ba,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}));
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public String  _calcresult(String _op) throws Exception{
 //BA.debugLineNum = 246;BA.debugLine="Private Sub CalcResult(Op As String)";
 //BA.debugLineNum = 247;BA.debugLine="Select Op";
switch (BA.switchObjectToInt(_op,"a","b","c","d","g","s","x","y")) {
case 0: {
 //BA.debugLineNum = 249;BA.debugLine="Result = Result + Val";
_result = _result+_val;
 break; }
case 1: {
 //BA.debugLineNum = 251;BA.debugLine="Result = Result - Val";
_result = _result-_val;
 break; }
case 2: {
 //BA.debugLineNum = 253;BA.debugLine="Result = Result * Val";
_result = _result*_val;
 break; }
case 3: {
 //BA.debugLineNum = 255;BA.debugLine="Result = Result / Val";
_result = _result/(double)_val;
 break; }
case 4: {
 //BA.debugLineNum = 257;BA.debugLine="Result = Result * Result";
_result = _result*_result;
 break; }
case 5: {
 //BA.debugLineNum = 259;BA.debugLine="Result = Sqrt(Result)";
_result = __c.Sqrt(_result);
 break; }
case 6: {
 //BA.debugLineNum = 261;BA.debugLine="If Result <> 0 Then";
if (_result!=0) { 
 //BA.debugLineNum = 262;BA.debugLine="Result = 1 / Result";
_result = 1/(double)_result;
 };
 break; }
case 7: {
 //BA.debugLineNum = 265;BA.debugLine="Result = Result * Val / 100";
_result = _result*_val/(double)100;
 break; }
}
;
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 14;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 17;BA.debugLine="Private stu As StringUtils";
_stu = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 19;BA.debugLine="Private lblPaperRoll As Label";
_lblpaperroll = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private ScaleAuto As Double";
_scaleauto = 0;
 //BA.debugLineNum = 22;BA.debugLine="Private sVal = \"\" As String";
_sval = "";
 //BA.debugLineNum = 23;BA.debugLine="Private Val = 0 As Double";
_val = 0;
 //BA.debugLineNum = 24;BA.debugLine="Private Op0 = \"\" As String";
_op0 = "";
 //BA.debugLineNum = 25;BA.debugLine="Private Result = 0 As Double";
_result = 0;
 //BA.debugLineNum = 26;BA.debugLine="Private Txt = \"\" As String";
_txt = "";
 //BA.debugLineNum = 27;BA.debugLine="Private New = 0 As Int";
_new = (int) (0);
 //BA.debugLineNum = 28;BA.debugLine="Private CharSizeLarge As Boolean = False";
_charsizelarge = __c.False;
 //BA.debugLineNum = 30;BA.debugLine="Private btn0, btn1, btn2, btn3, btn4, btn5, btn6,";
_btn0 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn2 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn3 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn4 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn6 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn7 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn8 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btn9 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private btna, btnb, btnc, btnd, btne, btnp As But";
_btna = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnb = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnc = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnd = new anywheresoftware.b4a.objects.ButtonWrapper();
_btne = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnp = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private btnBack, btnClr, btnExit,btnCharSize As B";
_btnback = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnclr = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnexit = new anywheresoftware.b4a.objects.ButtonWrapper();
_btncharsize = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private pnlKeyboard As Panel";
_pnlkeyboard = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private scvPaperRoll As ScrollView";
_scvpaperroll = new anywheresoftware.b4a.objects.ScrollViewWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private imgPaperTape As lmB4XImageViewX";
_imgpapertape = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public String  _getvalue(String _op) throws Exception{
 //BA.debugLineNum = 160;BA.debugLine="Private Sub GetValue(Op As String)";
 //BA.debugLineNum = 161;BA.debugLine="If Op0 = \"e\" And (Op = \"s\" Or Op = \"g\" Or Op = \"x";
if ((_op0).equals("e") && ((_op).equals("s") || (_op).equals("g") || (_op).equals("x"))) { 
 //BA.debugLineNum = 162;BA.debugLine="Val = Result";
_val = _result;
 }else {
 //BA.debugLineNum = 164;BA.debugLine="Val = sVal";
_val = (double)(Double.parseDouble(_sval));
 };
 //BA.debugLineNum = 167;BA.debugLine="sVal = \"\"";
_sval = "";
 //BA.debugLineNum = 169;BA.debugLine="If Op = \"g\" Or Op = \"s\" Or Op = \"x\" Then";
if ((_op).equals("g") || (_op).equals("s") || (_op).equals("x")) { 
 //BA.debugLineNum = 170;BA.debugLine="If Op0 = \"a\" Or Op0 = \"b\" Or Op0 = \"c\" Or Op0 =";
if ((_op0).equals("a") || (_op0).equals("b") || (_op0).equals("c") || (_op0).equals("d") || (_op0).equals("y")) { 
 //BA.debugLineNum = 171;BA.debugLine="CalcResult(Op0)";
_calcresult(_op0);
 //BA.debugLineNum = 172;BA.debugLine="Txt = Txt & \"  = \" & Result";
_txt = _txt+"  = "+BA.NumberToString(_result);
 };
 //BA.debugLineNum = 174;BA.debugLine="Operation(Op)";
_operation(_op);
 //BA.debugLineNum = 175;BA.debugLine="CalcResult(Op)";
_calcresult(_op);
 //BA.debugLineNum = 176;BA.debugLine="Txt = Txt & \"  = \" & Result";
_txt = _txt+"  = "+BA.NumberToString(_result);
 //BA.debugLineNum = 177;BA.debugLine="Op0 = Op";
_op0 = _op;
 //BA.debugLineNum = 178;BA.debugLine="Op0 = \"e\"";
_op0 = "e";
 //BA.debugLineNum = 179;BA.debugLine="Op = \"e\"";
_op = "e";
 //BA.debugLineNum = 180;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 183;BA.debugLine="If New = 1 Then";
if (_new==1) { 
 //BA.debugLineNum = 184;BA.debugLine="Result = Val";
_result = _val;
 //BA.debugLineNum = 185;BA.debugLine="Operation(Op)";
_operation(_op);
 //BA.debugLineNum = 186;BA.debugLine="If Op = \"g\" Or Op = \"s\" Or Op = \"x\" Then";
if ((_op).equals("g") || (_op).equals("s") || (_op).equals("x")) { 
 //BA.debugLineNum = 187;BA.debugLine="CalcResult(Op)";
_calcresult(_op);
 //BA.debugLineNum = 188;BA.debugLine="Txt = Txt & \"  = \" & Result";
_txt = _txt+"  = "+BA.NumberToString(_result);
 //BA.debugLineNum = 189;BA.debugLine="Op = \"e\"";
_op = "e";
 };
 //BA.debugLineNum = 191;BA.debugLine="UpdateTape";
_updatetape();
 //BA.debugLineNum = 192;BA.debugLine="New = 2";
_new = (int) (2);
 //BA.debugLineNum = 193;BA.debugLine="Op0 = Op";
_op0 = _op;
 //BA.debugLineNum = 194;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 197;BA.debugLine="If Op = \"e\" Then";
if ((_op).equals("e")) { 
 //BA.debugLineNum = 198;BA.debugLine="If Op0 = \"e\" Then";
if ((_op0).equals("e")) { 
 //BA.debugLineNum = 199;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 201;BA.debugLine="Txt = Txt & CRLF & \" =  \"";
_txt = _txt+__c.CRLF+" =  ";
 //BA.debugLineNum = 202;BA.debugLine="CalcResult(Op0)";
_calcresult(_op0);
 //BA.debugLineNum = 203;BA.debugLine="Txt = Txt & Result";
_txt = _txt+BA.NumberToString(_result);
 }else {
 //BA.debugLineNum = 205;BA.debugLine="If Op0 = \"g\" Or Op0 = \"s\" Or Op0 = \"x\" Then";
if ((_op0).equals("g") || (_op0).equals("s") || (_op0).equals("x")) { 
 //BA.debugLineNum = 206;BA.debugLine="Operation(Op)";
_operation(_op);
 //BA.debugLineNum = 207;BA.debugLine="Op0 = Op";
_op0 = _op;
 //BA.debugLineNum = 208;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 211;BA.debugLine="CalcResult(Op0)";
_calcresult(_op0);
 //BA.debugLineNum = 212;BA.debugLine="If Op0<>\"e\" Then";
if ((_op0).equals("e") == false) { 
 //BA.debugLineNum = 213;BA.debugLine="Txt = Txt & \"  = \" & Result";
_txt = _txt+"  = "+BA.NumberToString(_result);
 };
 //BA.debugLineNum = 215;BA.debugLine="Operation(Op)";
_operation(_op);
 //BA.debugLineNum = 216;BA.debugLine="If Op = \"g\" Or Op = \"s\" Or Op = \"x\" Then";
if ((_op).equals("g") || (_op).equals("s") || (_op).equals("x")) { 
 //BA.debugLineNum = 217;BA.debugLine="CalcResult(Op)";
_calcresult(_op);
 //BA.debugLineNum = 218;BA.debugLine="Txt = Txt & \"  = \" & Result";
_txt = _txt+"  = "+BA.NumberToString(_result);
 //BA.debugLineNum = 219;BA.debugLine="Op = \"e\"";
_op = "e";
 };
 };
 //BA.debugLineNum = 222;BA.debugLine="Op0 = Op";
_op0 = _op;
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 40;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 41;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 42;BA.debugLine="pnlMain.LoadLayout(\"pageCalculatorBase\")";
_pnlmain.LoadLayout("pageCalculatorBase",ba);
 //BA.debugLineNum = 44;BA.debugLine="ScaleAuto = 1 + 0.5 * ((100%x + 100%y) / (320dip";
_scaleauto = 1+0.5*((__c.PerXToCurrent((float) (100),ba)+__c.PerYToCurrent((float) (100),ba))/(double)(__c.DipToCurrent((int) (320))+__c.DipToCurrent((int) (430)))-1);
 //BA.debugLineNum = 46;BA.debugLine="lblPaperRoll.Initialize(\"lblPaperRoll\")";
_lblpaperroll.Initialize(ba,"lblPaperRoll");
 //BA.debugLineNum = 47;BA.debugLine="scvPaperRoll.Panel.AddView(lblPaperRoll, 0, 0, im";
_scvpaperroll.getPanel().AddView((android.view.View)(_lblpaperroll.getObject()),(int) (0),(int) (0),(int) (_imgpapertape._getwidth /*double*/ ()),_scvpaperroll.getHeight());
 //BA.debugLineNum = 49;BA.debugLine="scvPaperRoll.Panel.Height = scvPaperRoll.Height";
_scvpaperroll.getPanel().setHeight(_scvpaperroll.getHeight());
 //BA.debugLineNum = 50;BA.debugLine="lblPaperRoll.TextSize = 24 * ScaleAuto";
_lblpaperroll.setTextSize((float) (24*_scaleauto));
 //BA.debugLineNum = 51;BA.debugLine="lblPaperRoll.Color = XUI.Color_Transparent'Colors";
_lblpaperroll.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 52;BA.debugLine="lblPaperRoll.TextColor = XUI.Color_Black";
_lblpaperroll.setTextColor(_xui.Color_Black);
 //BA.debugLineNum = 54;BA.debugLine="imgPaperTape.Bitmap = XUI.LoadBitmap(File.DirAsse";
_imgpapertape._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_xui.LoadBitmap(__c.File.getDirAssets(),"paper-tape.png"));
 //BA.debugLineNum = 57;BA.debugLine="scvPaperRoll.BringToFront";
_scvpaperroll.BringToFront();
 //BA.debugLineNum = 59;BA.debugLine="guiHelpers.SkinButton(Array As Button(btn0, btn1,";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btn0,_btn1,_btn2,_btn3,_btn4,_btn5,_btn6,_btn7,_btn8,_btn9,_btna,_btnb,_btnc,_btnd,_btne,_btnp,_btnback,_btnclr,_btnexit,_btncharsize});
 //BA.debugLineNum = 62;BA.debugLine="guiHelpers.ResizeText(\"0\",btn0)";
_guihelpers._resizetext /*String*/ (ba,"0",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_btn0.getObject())));
 //BA.debugLineNum = 63;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(btn0, btn";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn0.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn2.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn3.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn4.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn6.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn7.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn8.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btn9.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btna.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnc.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnd.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btne.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnexit.getObject()))},(float) ((_btn0.getTextSize()-10)));
 //BA.debugLineNum = 65;BA.debugLine="btnClr.Text = \"Clear Tape\" : btnCharSize.Text = \"";
_btnclr.setText(BA.ObjectToCharSequence("Clear Tape"));
 //BA.debugLineNum = 65;BA.debugLine="btnClr.Text = \"Clear Tape\" : btnCharSize.Text = \"";
_btncharsize.setText(BA.ObjectToCharSequence("Char Size"));
 //BA.debugLineNum = 66;BA.debugLine="btnBack.TextSize = btna.TextSize - 16";
_btnback.setTextSize((float) (_btna.getTextSize()-16));
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 77;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _operation(String _op) throws Exception{
 //BA.debugLineNum = 225;BA.debugLine="Private Sub Operation(Op As String)";
 //BA.debugLineNum = 226;BA.debugLine="Select Op";
switch (BA.switchObjectToInt(_op,"a","b","c","d")) {
case 0: {
 //BA.debugLineNum = 228;BA.debugLine="Txt = Txt & CRLF & \"+ \"";
_txt = _txt+__c.CRLF+"+ ";
 break; }
case 1: {
 //BA.debugLineNum = 230;BA.debugLine="Txt = Txt & CRLF & \"- \"";
_txt = _txt+__c.CRLF+"- ";
 break; }
case 2: {
 //BA.debugLineNum = 232;BA.debugLine="Txt = Txt & CRLF & \"* \"";
_txt = _txt+__c.CRLF+"* ";
 break; }
case 3: {
 //BA.debugLineNum = 234;BA.debugLine="Txt = Txt & CRLF & \"/ \"";
_txt = _txt+__c.CRLF+"/ ";
 break; }
}
;
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _page_setup() throws Exception{
 //BA.debugLineNum = 79;BA.debugLine="Private Sub Page_Setup";
 //BA.debugLineNum = 80;BA.debugLine="guiHelpers.Show_toast2(\"No setup for this page\",3";
_guihelpers._show_toast2 /*String*/ (ba,"No setup for this page",(int) (3500));
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 72;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 73;BA.debugLine="Menus.SetHeader(\"Calculator\",\"main_menu_calc.png\"";
_menus._setheader /*String*/ (ba,"Calculator","main_menu_calc.png");
 //BA.debugLineNum = 74;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public void  _updatetape() throws Exception{
ResumableSub_UpdateTape rsub = new ResumableSub_UpdateTape(this);
rsub.resume(ba, null);
}
public static class ResumableSub_UpdateTape extends BA.ResumableSub {
public ResumableSub_UpdateTape(sadLogic.HomeCentral.pagecalculator parent) {
this.parent = parent;
}
sadLogic.HomeCentral.pagecalculator parent;
float _h = 0f;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 270;BA.debugLine="Dim h As Float";
_h = 0f;
 //BA.debugLineNum = 274;BA.debugLine="lblPaperRoll.Text = Txt";
parent._lblpaperroll.setText(BA.ObjectToCharSequence(parent._txt));
 //BA.debugLineNum = 276;BA.debugLine="h = stu.MeasureMultilineTextHeight(lblPaperRoll,";
_h = (float) (parent._stu.MeasureMultilineTextHeight((android.widget.TextView)(parent._lblpaperroll.getObject()),BA.ObjectToCharSequence(parent._txt)));
 //BA.debugLineNum = 277;BA.debugLine="If h > scvPaperRoll.Height Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_h>parent._scvpaperroll.getHeight()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 278;BA.debugLine="lblPaperRoll.Height = h";
parent._lblpaperroll.setHeight((int) (_h));
 //BA.debugLineNum = 279;BA.debugLine="scvPaperRoll.Panel.Height = h";
parent._scvpaperroll.getPanel().setHeight((int) (_h));
 //BA.debugLineNum = 280;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 4;
;
 //BA.debugLineNum = 281;BA.debugLine="scvPaperRoll.ScrollPosition = h";
parent._scvpaperroll.setScrollPosition((int) (_h));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 283;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 284;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
return BA.SubDelegator.SubNotFound;
}
}
