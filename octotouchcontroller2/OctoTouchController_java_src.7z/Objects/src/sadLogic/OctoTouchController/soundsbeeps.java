package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class soundsbeeps extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.soundsbeeps");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.soundsbeeps.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.Timer _tid = null;
public anywheresoftware.b4a.objects.Timer _tii = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _alarm(long _durationmilliseconds) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Public Sub Alarm(DurationMilliseconds As Long)";
 //BA.debugLineNum = 58;BA.debugLine="tiD.Initialize(\"tiD\",DurationMilliseconds)";
_tid.Initialize(ba,"tiD",_durationmilliseconds);
 //BA.debugLineNum = 59;BA.debugLine="tiI.Initialize(\"tiI\",250)";
_tii.Initialize(ba,"tiI",(long) (250));
 //BA.debugLineNum = 60;BA.debugLine="tiD.Enabled=True";
_tid.setEnabled(__c.True);
 //BA.debugLineNum = 61;BA.debugLine="tiI.Enabled=True";
_tii.setEnabled(__c.True);
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
public String  _beep(long _durationms,long _freqhz) throws Exception{
anywheresoftware.b4a.audio.Beeper _b = null;
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Beep(DurationMS As Long,FreqHz As Long)";
 //BA.debugLineNum = 33;BA.debugLine="Dim b As Beeper";
_b = new anywheresoftware.b4a.audio.Beeper();
 //BA.debugLineNum = 34;BA.debugLine="b.Initialize(DurationMS, FreqHz) '--- sample -";
_b.Initialize((int) (_durationms),(int) (_freqhz));
 //BA.debugLineNum = 35;BA.debugLine="b.Beep";
_b.Beep();
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public void  _beeps(long _durationms,long _freqhz,int _times) throws Exception{
ResumableSub_Beeps rsub = new ResumableSub_Beeps(this,_durationms,_freqhz,_times);
rsub.resume(ba, null);
}
public static class ResumableSub_Beeps extends BA.ResumableSub {
public ResumableSub_Beeps(sadLogic.OctoTouchController.soundsbeeps parent,long _durationms,long _freqhz,int _times) {
this.parent = parent;
this._durationms = _durationms;
this._freqhz = _freqhz;
this._times = _times;
}
sadLogic.OctoTouchController.soundsbeeps parent;
long _durationms;
long _freqhz;
int _times;
anywheresoftware.b4a.audio.Beeper _b = null;
int _x = 0;
int step3;
int limit3;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 22;BA.debugLine="Dim b As Beeper";
_b = new anywheresoftware.b4a.audio.Beeper();
 //BA.debugLineNum = 23;BA.debugLine="b.Initialize(DurationMS, FreqHZ) '--- sample - 30";
_b.Initialize((int) (_durationms),(int) (_freqhz));
 //BA.debugLineNum = 24;BA.debugLine="For x = 1 To Times";
if (true) break;

case 1:
//for
this.state = 4;
step3 = 1;
limit3 = _times;
_x = (int) (1) ;
this.state = 5;
if (true) break;

case 5:
//C
this.state = 4;
if ((step3 > 0 && _x <= limit3) || (step3 < 0 && _x >= limit3)) this.state = 3;
if (true) break;

case 6:
//C
this.state = 5;
_x = ((int)(0 + _x + step3)) ;
if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 25;BA.debugLine="b.Beep";
_b.Beep();
 //BA.debugLineNum = 26;BA.debugLine="Beep(DurationMS,FreqHZ)";
parent._beep(_durationms,_freqhz);
 //BA.debugLineNum = 27;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 7;
return;
case 7:
//C
this.state = 6;
;
 if (true) break;
if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 14;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 15;BA.debugLine="Dim tiD,tiI As Timer";
_tid = new anywheresoftware.b4a.objects.Timer();
_tii = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _tid_tick() throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Private Sub tiD_tick";
 //BA.debugLineNum = 65;BA.debugLine="tiI.enabled=False";
_tii.setEnabled(__c.False);
 //BA.debugLineNum = 66;BA.debugLine="tiD.Enabled=False";
_tid.setEnabled(__c.False);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public String  _tii_tick() throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Private Sub tiI_tick";
 //BA.debugLineNum = 70;BA.debugLine="Beep(250,500)";
_beep((long) (250),(long) (500));
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
