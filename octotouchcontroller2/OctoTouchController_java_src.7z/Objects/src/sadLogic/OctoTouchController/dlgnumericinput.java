package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgnumericinput extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgnumericinput");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgnumericinput.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mprompt = "";
public String _mtitle = "";
public Object _mcallback = null;
public String _meventname = "";
public sadLogic.OctoTouchController.b4xdialog _mdialog = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgNumericInpu";
_mmodule = "dlgNumericInput";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mPrompt As String";
_mprompt = "";
 //BA.debugLineNum = 12;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 13;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 14;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 16;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _title,String _prompt,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Initialize( title As String, prompt As";
 //BA.debugLineNum = 24;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 25;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 26;BA.debugLine="mPrompt = prompt";
_mprompt = _prompt;
 //BA.debugLineNum = 27;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 28;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgnumericinput parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgnumericinput parent;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
sadLogic.OctoTouchController.sadb4xinputtemplate _inputtemplate = null;
anywheresoftware.b4a.objects.EditTextWrapper _et = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _intresult = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 36;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 37;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 38;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 40;BA.debugLine="Dim inputTemplate As sadB4XInputTemplate";
_inputtemplate = new sadLogic.OctoTouchController.sadb4xinputtemplate();
 //BA.debugLineNum = 41;BA.debugLine="inputTemplate.Initialize";
_inputtemplate._initialize /*String*/ (ba);
 //BA.debugLineNum = 44;BA.debugLine="Dim et As EditText = inputTemplate.TextField1";
_et = new anywheresoftware.b4a.objects.EditTextWrapper();
_et = (anywheresoftware.b4a.objects.EditTextWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.EditTextWrapper(), (android.widget.EditText)(_inputtemplate._textfield1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject()));
 //BA.debugLineNum = 45;BA.debugLine="et.InputType = et.INPUT_TYPE_NUMBERS";
_et.setInputType(_et.INPUT_TYPE_NUMBERS);
 //BA.debugLineNum = 46;BA.debugLine="inputTemplate.ConfigureForNumbers(False, False) '";
_inputtemplate._configurefornumbers /*String*/ (parent.__c.False,parent.__c.False);
 //BA.debugLineNum = 49;BA.debugLine="inputTemplate.mBase.Color = clrTheme.Background";
_inputtemplate._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 50;BA.debugLine="inputTemplate.lblTitle.Text = mPrompt";
_inputtemplate._lbltitle /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setText(BA.ObjectToCharSequence(parent._mprompt));
 //BA.debugLineNum = 51;BA.debugLine="inputTemplate.lblTitle.TextColor = clrTheme.txtNo";
_inputtemplate._lbltitle /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 53;BA.debugLine="dlgHelper.ThemeDialogForm( mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 54;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowTemplate(inp";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_inputtemplate),(Object)("SET"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 55;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 56;BA.debugLine="SizeInputDialog(mDialog,inputTemplate)";
parent._sizeinputdialog(parent._mdialog,_inputtemplate);
 //BA.debugLineNum = 59;BA.debugLine="Wait For(rs)complete(intResult As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_intresult = (Integer) result[0];
;
 //BA.debugLineNum = 60;BA.debugLine="CallSub2(mCallback,mEventName,IIf( intResult = xu";
parent.__c.CallSubNew2(ba,parent._mcallback,parent._meventname,((_intresult==parent._xui.DialogResponse_Positive) ? ((Object)(_inputtemplate._text /*String*/ )) : ((Object)(""))));
 //BA.debugLineNum = 62;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _intresult) throws Exception{
}
public String  _sizeinputdialog(sadLogic.OctoTouchController.b4xdialog _dlg,sadLogic.OctoTouchController.sadb4xinputtemplate _input) throws Exception{
anywheresoftware.b4a.objects.EditTextWrapper _et = null;
anywheresoftware.b4a.objects.PanelWrapper _p = null;
anywheresoftware.b4a.objects.B4XViewWrapper _lb = null;
anywheresoftware.b4a.objects.B4XViewWrapper _cncl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _ok = null;
 //BA.debugLineNum = 68;BA.debugLine="Private Sub SizeInputDialog(dlg As B4XDialog, inpu";
 //BA.debugLineNum = 70;BA.debugLine="Dim ET As EditText = input.TextField1";
_et = new anywheresoftware.b4a.objects.EditTextWrapper();
_et = (anywheresoftware.b4a.objects.EditTextWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.EditTextWrapper(), (android.widget.EditText)(_input._textfield1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject()));
 //BA.debugLineNum = 71;BA.debugLine="Dim p As Panel = input.GetPanel(dlg)";
_p = new anywheresoftware.b4a.objects.PanelWrapper();
_p = (anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(_input._getpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_dlg).getObject()));
 //BA.debugLineNum = 72;BA.debugLine="Dim LB As B4XView = p.GetView(0)";
_lb = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lb = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_p.GetView((int) (0)).getObject()));
 //BA.debugLineNum = 74;BA.debugLine="LB.Font = xui.CreateDefaultFont(NumberFormat2(22";
_lb.setFont(_xui.CreateDefaultFont((float)(Double.parseDouble(__c.NumberFormat2(22/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))));
 //BA.debugLineNum = 75;BA.debugLine="input.mBase.Height = input.mBase.Height + 22dip '";
_input._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setHeight((int) (_input._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()+__c.DipToCurrent((int) (22))));
 //BA.debugLineNum = 76;BA.debugLine="LB.Height = Round((input.mBase.Height / 2.7)).As(";
_lb.setHeight((int) (((float) (__c.Round((_input._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()/(double)2.7))))));
 //BA.debugLineNum = 78;BA.debugLine="ET.Gravity = Gravity.CENTER";
_et.setGravity(__c.Gravity.CENTER);
 //BA.debugLineNum = 79;BA.debugLine="ET.Height = Round(input.mBase.Height / 2).As(Floa";
_et.setHeight((int) (((float) (__c.Round(_input._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()/(double)2)))));
 //BA.debugLineNum = 80;BA.debugLine="ET.top = LB.Top + LB.Height + 8dip  '(input.mBase";
_et.setTop((int) (_lb.getTop()+_lb.getHeight()+__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 81;BA.debugLine="ET.Width = input.mBase.Width - (ET.Left * 2)";
_et.setWidth((int) (_input._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-(_et.getLeft()*2)));
 //BA.debugLineNum = 82;BA.debugLine="ET.TextSize = NumberFormat2(28 / guiHelpers.gFsca";
_et.setTextSize((float)(Double.parseDouble(__c.NumberFormat2(28/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False))));
 //BA.debugLineNum = 83;BA.debugLine="ET.TextColor = clrTheme.txtNormal";
_et.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 85;BA.debugLine="Dim Cncl As B4XView = dlg.GetButton(xui.DialogRes";
_cncl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_cncl = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 86;BA.debugLine="Dim ok   As B4XView = dlg.GetButton(xui.DialogRes";
_ok = new anywheresoftware.b4a.objects.B4XViewWrapper();
_ok = _dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive);
 //BA.debugLineNum = 88;BA.debugLine="Cncl.Top = ET.Top + ET.Height + dlg.TitleBarHeigh";
_cncl.setTop((int) (_et.getTop()+_et.getHeight()+_dlg._titlebarheight /*int*/ +__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 89;BA.debugLine="ok.Top = Cncl.Top";
_ok.setTop(_cncl.getTop());
 //BA.debugLineNum = 91;BA.debugLine="dlg.Base.Height = ok.Height + ok.Top + 8dip'LB.He";
_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setHeight((int) (_ok.getHeight()+_ok.getTop()+__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
