package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadcallsubutils extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.sadcallsubutils");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.sadcallsubutils.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.Map _rundelayed = null;
public boolean _goingdown = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static class _rundelayeddata{
public boolean IsInitialized;
public Object Module;
public String SubName;
public Object[] Arg;
public boolean Delayed;
public void Initialize() {
IsInitialized = true;
Module = new Object();
SubName = "";
Arg = new Object[0];
{
int d0 = Arg.length;
for (int i0 = 0;i0 < d0;i0++) {
Arg[i0] = new Object();
}
}
;
Delayed = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _callsubdelayedplus(Object _module,String _subname,int _delay) throws Exception{
 //BA.debugLineNum = 78;BA.debugLine="Public Sub CallSubDelayedPlus(Module As Object, Su";
 //BA.debugLineNum = 79;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 80;BA.debugLine="CallSubDelayedPlus2(Module, SubName, Delay, Null)";
_callsubdelayedplus2(_module,_subname,_delay,(Object[])(__c.Null));
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public String  _callsubdelayedplus2(Object _module,String _subname,int _delay,Object[] _arg) throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Public Sub CallSubDelayedPlus2(Module As Object, S";
 //BA.debugLineNum = 87;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 88;BA.debugLine="PlusImpl(Module, SubName, Delay, Arg, True)";
_plusimpl(_module,_subname,_delay,_arg,__c.True);
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _callsubplus(Object _module,String _subname,int _delay) throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Public Sub CallSubPlus(Module As Object, SubName A";
 //BA.debugLineNum = 94;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 95;BA.debugLine="CallSubPlus2(Module, SubName, Delay, Null)";
_callsubplus2(_module,_subname,_delay,(Object[])(__c.Null));
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public String  _callsubplus2(Object _module,String _subname,int _delay,Object[] _arg) throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Public Sub CallSubPlus2(Module As Object, SubName";
 //BA.debugLineNum = 102;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 103;BA.debugLine="PlusImpl(Module, SubName, Delay, Arg, False)";
_plusimpl(_module,_subname,_delay,_arg,__c.False);
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 16;BA.debugLine="Private RunDelayed As Map, GoingDown As Boolean =";
_rundelayed = new anywheresoftware.b4a.objects.collections.Map();
_goingdown = __c.False;
 //BA.debugLineNum = 17;BA.debugLine="Type RunDelayedData (Module As Object, SubName As";
;
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _destroy() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Destroy";
 //BA.debugLineNum = 26;BA.debugLine="GoingDown = True";
_goingdown = __c.True;
 //BA.debugLineNum = 27;BA.debugLine="RunDelayed.Clear";
_rundelayed.Clear();
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.Timer  _exists(Object _module,String _subname) throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
sadLogic.HomeCentral.sadcallsubutils._rundelayeddata _dt = null;
 //BA.debugLineNum = 58;BA.debugLine="Public Sub Exists(Module As Object, SubName As Str";
 //BA.debugLineNum = 60;BA.debugLine="If GoingDown Then Return Null";
if (_goingdown) { 
if (true) return (anywheresoftware.b4a.objects.Timer)(__c.Null);};
 //BA.debugLineNum = 61;BA.debugLine="If RunDelayed.IsInitialized <> False Then";
if (_rundelayed.IsInitialized()!=__c.False) { 
 //BA.debugLineNum = 62;BA.debugLine="For Each t As Timer In RunDelayed.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _rundelayed.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_t = (anywheresoftware.b4a.objects.Timer)(group3.Get(index3));
 //BA.debugLineNum = 63;BA.debugLine="Dim dt As RunDelayedData = RunDelayed.Get(t)";
_dt = (sadLogic.HomeCentral.sadcallsubutils._rundelayeddata)(_rundelayed.Get((Object)(_t)));
 //BA.debugLineNum = 64;BA.debugLine="If dt.SubName = SubName And dt.Module = Module";
if ((_dt.SubName /*String*/ ).equals(_subname) && (_dt.Module /*Object*/ ).equals(_module)) { 
 //BA.debugLineNum = 66;BA.debugLine="Return t";
if (true) return _t;
 };
 }
};
 };
 //BA.debugLineNum = 70;BA.debugLine="Return Null";
if (true) return (anywheresoftware.b4a.objects.Timer)(__c.Null);
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return null;
}
public String  _existsremove(Object _module,String _subname) throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
 //BA.debugLineNum = 48;BA.debugLine="Public Sub ExistsRemove(Module As Object, SubName";
 //BA.debugLineNum = 50;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 51;BA.debugLine="Dim t As Timer = Exists(Module,SubName)";
_t = _exists(_module,_subname);
 //BA.debugLineNum = 52;BA.debugLine="If t <> Null Then";
if (_t!= null) { 
 //BA.debugLineNum = 53;BA.debugLine="t.Enabled = False";
_t.setEnabled(__c.False);
 //BA.debugLineNum = 54;BA.debugLine="RunDelayed.Remove(t)";
_rundelayed.Remove((Object)(_t));
 };
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _existsremoveadd_delayedplus(Object _module,String _subname,int _delay) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Public Sub ExistsRemoveAdd_DelayedPlus(Module As O";
 //BA.debugLineNum = 34;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 35;BA.debugLine="ExistsRemove(Module, SubName)";
_existsremove(_module,_subname);
 //BA.debugLineNum = 36;BA.debugLine="CallSubDelayedPlus(Module,SubName,Delay)";
_callsubdelayedplus(_module,_subname,_delay);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public String  _existsremoveadd_delayedplus2(Object _module,String _subname,int _delay,Object[] _arg) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Public Sub ExistsRemoveAdd_DelayedPlus2(Module As";
 //BA.debugLineNum = 42;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 43;BA.debugLine="ExistsRemove(Module, SubName)";
_existsremove(_module,_subname);
 //BA.debugLineNum = 44;BA.debugLine="CallSubDelayedPlus2(Module,SubName,Delay,Arg)";
_callsubdelayedplus2(_module,_subname,_delay,_arg);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 21;BA.debugLine="RunDelayed.Initialize";
_rundelayed.Initialize();
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _plusimpl(Object _module,String _subname,int _delay,Object[] _arg,boolean _delayed) throws Exception{
anywheresoftware.b4a.objects.Timer _tmr = null;
sadLogic.HomeCentral.sadcallsubutils._rundelayeddata _rdd = null;
 //BA.debugLineNum = 106;BA.debugLine="Private Sub PlusImpl(Module As Object, SubName As";
 //BA.debugLineNum = 108;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 109;BA.debugLine="Dim tmr As Timer";
_tmr = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 110;BA.debugLine="tmr.Initialize(\"tmr\", Delay)";
_tmr.Initialize(ba,"tmr",(long) (_delay));
 //BA.debugLineNum = 111;BA.debugLine="Dim rdd As RunDelayedData";
_rdd = new sadLogic.HomeCentral.sadcallsubutils._rundelayeddata();
 //BA.debugLineNum = 112;BA.debugLine="rdd.Module = Module";
_rdd.Module /*Object*/  = _module;
 //BA.debugLineNum = 113;BA.debugLine="rdd.SubName = SubName";
_rdd.SubName /*String*/  = _subname;
 //BA.debugLineNum = 114;BA.debugLine="rdd.Arg = Arg";
_rdd.Arg /*Object[]*/  = _arg;
 //BA.debugLineNum = 115;BA.debugLine="rdd.delayed = delayed";
_rdd.Delayed /*boolean*/  = _delayed;
 //BA.debugLineNum = 116;BA.debugLine="RunDelayed.Put(tmr, rdd)";
_rundelayed.Put((Object)(_tmr),(Object)(_rdd));
 //BA.debugLineNum = 117;BA.debugLine="tmr.Enabled = True";
_tmr.setEnabled(__c.True);
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public String  _tmr_tick() throws Exception{
anywheresoftware.b4a.objects.Timer _t = null;
sadLogic.HomeCentral.sadcallsubutils._rundelayeddata _rdd = null;
 //BA.debugLineNum = 125;BA.debugLine="Private Sub tmr_Tick";
 //BA.debugLineNum = 126;BA.debugLine="If GoingDown Then Return";
if (_goingdown) { 
if (true) return "";};
 //BA.debugLineNum = 127;BA.debugLine="Dim t As Timer = Sender";
_t = (anywheresoftware.b4a.objects.Timer)(__c.Sender(getActivityBA()));
 //BA.debugLineNum = 128;BA.debugLine="t.Enabled = False";
_t.setEnabled(__c.False);
 //BA.debugLineNum = 129;BA.debugLine="Dim rdd As RunDelayedData = RunDelayed.Get(t)";
_rdd = (sadLogic.HomeCentral.sadcallsubutils._rundelayeddata)(_rundelayed.Get((Object)(_t)));
 //BA.debugLineNum = 130;BA.debugLine="RunDelayed.Remove(t)";
_rundelayed.Remove((Object)(_t));
 //BA.debugLineNum = 136;BA.debugLine="If rdd.Delayed Then";
if (_rdd.Delayed /*boolean*/ ) { 
 //BA.debugLineNum = 137;BA.debugLine="If rdd.Arg = Null Then";
if (_rdd.Arg /*Object[]*/ == null) { 
 //BA.debugLineNum = 138;BA.debugLine="CallSubDelayed(rdd.Module, rdd.SubName)";
__c.CallSubDelayed(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ );
 }else {
 //BA.debugLineNum = 140;BA.debugLine="CallSubDelayed2(rdd.Module, rdd.SubName, rdd.Ar";
__c.CallSubDelayed2(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ ,(Object)(_rdd.Arg /*Object[]*/ ));
 };
 }else {
 //BA.debugLineNum = 143;BA.debugLine="If rdd.Arg = Null Then";
if (_rdd.Arg /*Object[]*/ == null) { 
 //BA.debugLineNum = 144;BA.debugLine="CallSub(rdd.Module, rdd.SubName)";
__c.CallSubNew(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ );
 }else {
 //BA.debugLineNum = 146;BA.debugLine="CallSub2(rdd.Module, rdd.SubName, rdd.Arg)";
__c.CallSubNew2(ba,_rdd.Module /*Object*/ ,_rdd.SubName /*String*/ ,(Object)(_rdd.Arg /*Object[]*/ ));
 };
 };
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
