package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlg1strun extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlg1strun");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlg1strun.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblabouttop = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public sadLogic.HomeCentral.lmb4ximageviewx _iv = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chkbox = null;
public sadLogic.HomeCentral.autotextsizelabel _txt1strun = null;
public sadLogic.HomeCentral.autotextsizelabel _txtnever = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _buildchkbox() throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Private Sub BuildChkbox";
 //BA.debugLineNum = 65;BA.debugLine="chkBox.Initialize(\"chkCheckUpdate\")";
_chkbox.Initialize(ba,"chkCheckUpdate");
 //BA.debugLineNum = 66;BA.debugLine="chkBox.Text = \" Check for updates\"";
_chkbox.setText(BA.ObjectToCharSequence(" Check for updates"));
 //BA.debugLineNum = 67;BA.debugLine="chkBox.TextColor = clrTheme.txtNormal";
_chkbox.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 68;BA.debugLine="chkBox.TextSize = 18";
_chkbox.setTextSize((float) (18));
 //BA.debugLineNum = 69;BA.debugLine="guiHelpers.SetCBDrawable(chkBox, clrTheme.txtNorm";
_guihelpers._setcbdrawable /*String*/ (ba,_chkbox,_clrtheme._txtnormal /*int*/ ,(int) (1),_clrtheme._txtnormal /*int*/ ,BA.ObjectToString(__c.Chr((int) (8730))),__c.Colors.LightGray,__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 70;BA.debugLine="dlg.Base.AddView(chkBox,10dip,dlg.Base.Height - 5";
_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .AddView((android.view.View)(_chkbox.getObject()),__c.DipToCurrent((int) (10)),(int) (_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()-__c.DipToCurrent((int) (50))),(int) ((_dlg._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-_dlg._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel).getWidth()-__c.DipToCurrent((int) (16)))),__c.DipToCurrent((int) (36)));
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public String  _chkcheckupdate_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Private Sub chkCheckUpdate_CheckedChange(Checked A";
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 10;BA.debugLine="Private lblAboutTop As Label";
_lblabouttop = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 12;BA.debugLine="Private iv As lmB4XImageViewX";
_iv = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 13;BA.debugLine="Private chkBox As CheckBox";
_chkbox = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private txt1stRun,txtNever As AutoTextSizeLabel";
_txt1strun = new sadLogic.HomeCentral.autotextsizelabel();
_txtnever = new sadLogic.HomeCentral.autotextsizelabel();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 22;BA.debugLine="dlg.Close(XUI.DialogResponse_Cancel)";
_dlg._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dialog) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(Dialog As B4XDialog)";
 //BA.debugLineNum = 19;BA.debugLine="dlg = Dialog";
_dlg = _dialog;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlg1strun parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlg1strun parent;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _msg = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 28;BA.debugLine="dlg.Initialize((B4XPages.MainPage.Root))";
parent._dlg._initialize /*String*/ (ba,(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ));
 //BA.debugLineNum = 29;BA.debugLine="dlgHelper.Initialize(dlg)";
parent._dlghelper._initialize /*String*/ (ba,parent._dlg);
 //BA.debugLineNum = 31;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 32;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,540dip,420dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (540)),parent.__c.DipToCurrent((int) (420)));
 //BA.debugLineNum = 33;BA.debugLine="p.LoadLayout(\"dlg1stRun\")";
_p.LoadLayout("dlg1stRun",ba);
 //BA.debugLineNum = 35;BA.debugLine="iv.Bitmap = XUI.LoadBitmap(File.DirAssets,\"logo02";
parent._iv._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"logo02.png"));
 //BA.debugLineNum = 38;BA.debugLine="dlgHelper.ThemeDialogForm( \"App Update Checking\")";
parent._dlghelper._themedialogform /*String*/ ((Object)("App Update Checking"));
 //BA.debugLineNum = 39;BA.debugLine="Dim rs As ResumableSub = dlg.ShowCustom(p, \"\", \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dlg._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("OK"));
 //BA.debugLineNum = 40;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
parent._dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 43;BA.debugLine="lblAboutTop.TextSize = 18";
parent._lblabouttop.setTextSize((float) (18));
 //BA.debugLineNum = 45;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblAbout";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblabouttop.getObject())),parent._txt1strun._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),parent._txtnever._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ()},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 46;BA.debugLine="txtNever.Text = \"Remember, updates will *NEVER* b";
parent._txtnever._settext /*Object*/ ((Object)("Remember, updates will *NEVER* be downloaded automaticly"));
 //BA.debugLineNum = 47;BA.debugLine="txt1stRun.Text = File.GetText(File.DirAssets,\"1st";
parent._txt1strun._settext /*Object*/ ((Object)(parent.__c.File.GetText(parent.__c.File.getDirAssets(),"1stRun.txt")));
 //BA.debugLineNum = 48;BA.debugLine="BuildChkbox";
parent._buildchkbox();
 //BA.debugLineNum = 50;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 51;BA.debugLine="msg.Append(\"(©)sadLogic 2015-25\").Append(CRLF)";
_msg.Append("(©)sadLogic 2015-25").Append(parent.__c.CRLF);
 //BA.debugLineNum = 52;BA.debugLine="msg.Append(\"Kherson Ukraine!\").Append(CRLF)";
_msg.Append("Kherson Ukraine!").Append(parent.__c.CRLF);
 //BA.debugLineNum = 53;BA.debugLine="msg.Append(\"AGPL-3.0 license\")";
_msg.Append("AGPL-3.0 license");
 //BA.debugLineNum = 54;BA.debugLine="lblAboutTop.Text = msg.ToString";
parent._lblabouttop.setText(BA.ObjectToCharSequence(_msg.ToString()));
 //BA.debugLineNum = 56;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 57;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"ResetScrn_Sleep";
parent.__c.CallSubDelayed(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 58;BA.debugLine="config.Change_AppUpdateCheck(chkBox.Checked)";
parent._config._change_appupdatecheck /*String*/ (ba,parent._chkbox.getChecked());
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
