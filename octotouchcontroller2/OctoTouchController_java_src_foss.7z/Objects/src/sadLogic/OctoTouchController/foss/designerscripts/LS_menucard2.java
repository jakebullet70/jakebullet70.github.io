package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_menucard2{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padtb="";
String _padlr="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
_padtb = BA.NumberToString((6d * scale));
_padlr = BA.NumberToString((1d * scale));
;}else{ 
;
_padtb = BA.NumberToString((6d * scale));
_padlr = BA.NumberToString((6d * scale));
;};
views.get("mnucard2").vw.setLeft((int)(0d));
views.get("mnucard2").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("mnucard2").vw.setTop((int)(0d));
views.get("mnucard2").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("mnucardimg").vw.setTop((int)(Double.parseDouble(_padtb)));
views.get("mnucardimg").vw.setHeight((int)((80d / 100 * height)-Double.parseDouble(_padtb) - (Double.parseDouble(_padtb))));
views.get("mnucardimg").vw.setLeft((int)(Double.parseDouble(_padlr)));
views.get("mnucardimg").vw.setWidth((int)((100d / 100 * width)-Double.parseDouble(_padlr) - (Double.parseDouble(_padlr))));
views.get("lbltext").vw.setTop((int)((views.get("mnucardimg").vw.getTop() + views.get("mnucardimg").vw.getHeight())));
views.get("lbltext").vw.setHeight((int)((100d / 100 * height) - ((views.get("mnucardimg").vw.getTop() + views.get("mnucardimg").vw.getHeight()))));

}
}