package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class heaterroutines extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.heaterroutines");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.heaterroutines.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _changetempbed() throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Public Sub ChangeTempBed";
 //BA.debugLineNum = 102;BA.debugLine="TempChangePrompt(\"bed\")";
_tempchangeprompt("bed");
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _changetemptool() throws Exception{
 //BA.debugLineNum = 98;BA.debugLine="Public Sub ChangeTempTool";
 //BA.debugLineNum = 99;BA.debugLine="TempChangePrompt(\"tool\")";
_tempchangeprompt("tool");
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private mMainObj As B4XMainPage'ignore";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _heattempchange_bed(String _value,String _tag) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Private Sub HeatTempChange_Bed(value As String, ta";
 //BA.debugLineNum = 67;BA.debugLine="If value.Length = 0 Then Return";
if (_value.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 69;BA.debugLine="If value = \"ev\" Then";
if ((_value).equals("ev")) { 
 //BA.debugLineNum = 71;BA.debugLine="ChangeTempBed";
_changetempbed();
 //BA.debugLineNum = 72;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 75;BA.debugLine="If value.EndsWith(\"off\") Then value = 0 '--- bed";
if (_value.endsWith("off")) { 
_value = BA.NumberToString(0);};
 //BA.debugLineNum = 77;BA.debugLine="If fnc.CheckTempRange(\"bed\", value) = False Then";
if (_fnc._checktemprange /*boolean*/ (ba,"bed",(int)(Double.parseDouble(_value)))==__c.False) { 
 //BA.debugLineNum = 78;BA.debugLine="guiHelpers.Show_toast(\"Invalid Temperature\",1800";
_guihelpers._show_toast /*String*/ (ba,"Invalid Temperature",(int) (1800));
 //BA.debugLineNum = 79;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 85;BA.debugLine="mMainObj.oMasterController.CN.PostRequest(oc.cCMD";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",BA.NumberToString(((int)(Double.parseDouble(_value))))));
 //BA.debugLineNum = 88;BA.debugLine="guiHelpers.Show_toast(\"Bed Temperature Change\",14";
_guihelpers._show_toast /*String*/ (ba,"Bed Temperature Change",(int) (1400));
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _heattempchange_tool(String _value,String _tag) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Private Sub HeatTempChange_Tool(value As String, t";
 //BA.debugLineNum = 25;BA.debugLine="If value.Length = 0 Then Return";
if (_value.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 27;BA.debugLine="If value = \"ev\" Then";
if ((_value).equals("ev")) { 
 //BA.debugLineNum = 31;BA.debugLine="ChangeTempTool";
_changetemptool();
 //BA.debugLineNum = 32;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 35;BA.debugLine="If value.EndsWith(\"off\") Then value = 0 '--- tool";
if (_value.endsWith("off")) { 
_value = BA.NumberToString(0);};
 //BA.debugLineNum = 37;BA.debugLine="If fnc.CheckTempRange(\"tool\", value) = False Then";
if (_fnc._checktemprange /*boolean*/ (ba,"tool",(int)(Double.parseDouble(_value)))==__c.False) { 
 //BA.debugLineNum = 38;BA.debugLine="guiHelpers.Show_toast(\"Invalid Temperature\",1800";
_guihelpers._show_toast /*String*/ (ba,"Invalid Temperature",(int) (1800));
 //BA.debugLineNum = 39;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 45;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cCMD";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",_value).replace("!VAL1!",BA.NumberToString(0)));
 //BA.debugLineNum = 49;BA.debugLine="guiHelpers.Show_toast(\"Tool Temperature Change\",1";
_guihelpers._show_toast /*String*/ (ba,"Tool Temperature Change",(int) (1400));
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _popupbedheatermenu() throws Exception{
sadLogic.OctoTouchController.foss.dlglistbox _o1 = null;
 //BA.debugLineNum = 57;BA.debugLine="Public Sub PopupBedHeaterMenu";
 //BA.debugLineNum = 59;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.foss.dlglistbox();
 //BA.debugLineNum = 60;BA.debugLine="mMainObj.pObjCurrentDlg1 = o1.Initialize(\"Bed Pre";
_mmainobj._pobjcurrentdlg1 /*Object*/  = _o1._initialize /*Object*/ (ba,(Object)("Bed Presets"),this,"HeatTempChange_Bed",_mmainobj._pobjcurrentdlg1 /*Object*/ );
 //BA.debugLineNum = 61;BA.debugLine="o1.Show(250dip,220dip,mMainObj.oMasterController.";
_o1._show /*void*/ ((float) (__c.DipToCurrent((int) (250))),(float) (__c.DipToCurrent((int) (220))),_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._mapbedheatvaluesonly /*anywheresoftware.b4a.objects.collections.Map*/ );
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _popuptoolheatermenu() throws Exception{
sadLogic.OctoTouchController.foss.dlglistbox _o1 = null;
 //BA.debugLineNum = 15;BA.debugLine="Public Sub PopupToolHeaterMenu";
 //BA.debugLineNum = 17;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.foss.dlglistbox();
 //BA.debugLineNum = 18;BA.debugLine="mMainObj.pObjCurrentDlg1 = o1.Initialize(\"Tool Pr";
_mmainobj._pobjcurrentdlg1 /*Object*/  = _o1._initialize /*Object*/ (ba,(Object)("Tool Presets"),this,"HeatTempChange_Tool",_mmainobj._pobjcurrentdlg1 /*Object*/ );
 //BA.debugLineNum = 19;BA.debugLine="o1.Show(250dip,220dip,mMainObj.oMasterController.";
_o1._show /*void*/ ((float) (__c.DipToCurrent((int) (250))),(float) (__c.DipToCurrent((int) (220))),_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._maptoolheatvaluesonly /*anywheresoftware.b4a.objects.collections.Map*/ );
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _tempchange_bed(String _value) throws Exception{
 //BA.debugLineNum = 143;BA.debugLine="Private Sub TempChange_Bed(value As String)";
 //BA.debugLineNum = 147;BA.debugLine="If value = \"\" Then Return";
if ((_value).equals("")) { 
if (true) return "";};
 //BA.debugLineNum = 148;BA.debugLine="If fnc.CheckTempRange(\"bed\", value) = False Then";
if (_fnc._checktemprange /*boolean*/ (ba,"bed",(int)(Double.parseDouble(_value)))==__c.False) { 
 //BA.debugLineNum = 149;BA.debugLine="guiHelpers.Show_toast(\"Invalid Temperature\",1800";
_guihelpers._show_toast /*String*/ (ba,"Invalid Temperature",(int) (1800));
 //BA.debugLineNum = 150;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 156;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cCMD";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_bed_temp /*String*/ .replace("!VAL!",_value));
 //BA.debugLineNum = 159;BA.debugLine="guiHelpers.Show_toast(\"Bed Temperature Change\",14";
_guihelpers._show_toast /*String*/ (ba,"Bed Temperature Change",(int) (1400));
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public String  _tempchange_tool1(String _value) throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub TempChange_Tool1(value As String)";
 //BA.debugLineNum = 125;BA.debugLine="If value.Length = 0 Then Return";
if (_value.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 126;BA.debugLine="If fnc.CheckTempRange(\"tool\", value) = False Then";
if (_fnc._checktemprange /*boolean*/ (ba,"tool",(int)(Double.parseDouble(_value)))==__c.False) { 
 //BA.debugLineNum = 127;BA.debugLine="guiHelpers.Show_toast(\"Invalid Temperature\",1800";
_guihelpers._show_toast /*String*/ (ba,"Invalid Temperature",(int) (1800));
 //BA.debugLineNum = 128;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 134;BA.debugLine="mMainObj.oMasterController.cn.PostRequest( _";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",_value).replace("!VAL1!",BA.NumberToString(0)));
 //BA.debugLineNum = 138;BA.debugLine="guiHelpers.Show_toast(\"Tool Temperature Change\",1";
_guihelpers._show_toast /*String*/ (ba,"Tool Temperature Change",(int) (1400));
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public String  _tempchangeprompt(String _what) throws Exception{
sadLogic.OctoTouchController.foss.dlgnumericinput _o1 = null;
 //BA.debugLineNum = 105;BA.debugLine="Private Sub TempChangePrompt(what As String)";
 //BA.debugLineNum = 107;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
__c.CallSubNew(ba,(Object)(_main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 110;BA.debugLine="If oc.isConnected = False Then Return";
if (_oc._isconnected /*boolean*/ ==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 112;BA.debugLine="Dim o1 As dlgNumericInput";
_o1 = new sadLogic.OctoTouchController.foss.dlgnumericinput();
 //BA.debugLineNum = 113;BA.debugLine="o1.Initialize( _ 		IIf(what = \"bed\",\"Bed Temperat";
_o1._initialize /*String*/ (ba,BA.ObjectToString((((_what).equals("bed")) ? ((Object)("Bed Temperature")) : ((Object)("Tool Temperature")))),"Enter Temperature",this,BA.ObjectToString((((_what).equals("bed")) ? ((Object)("TempChange_Bed")) : ((Object)("TempChange_Tool1")))));
 //BA.debugLineNum = 117;BA.debugLine="o1.Show";
_o1._show /*void*/ ();
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
