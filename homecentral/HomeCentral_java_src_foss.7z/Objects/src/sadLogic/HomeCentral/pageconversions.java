package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pageconversions extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pageconversions");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pageconversions.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbg = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlnumpad = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlinput = null;
public sadLogic.HomeCentral.conversionmod _oconversion = null;
public anywheresoftware.b4a.objects.EditTextWrapper _curtxt = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button3 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button4 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button6 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button7 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button8 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button9 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button10 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button11 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button12 = null;
public int _currscrn = 0;
public anywheresoftware.b4a.objects.LabelWrapper _lblwhat = null;
public int _scrnweight = 0;
public int _scrnvolume = 0;
public int _scrntemp = 0;
public int _scrnlength = 0;
public int _scrnbutter = 0;
public anywheresoftware.b4a.objects.PanelWrapper _pnlweight = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlweightf = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtoz = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtpounds = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtkg = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtgrams = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblkg = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblgrams = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblpounds = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbloz = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltemp = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblf = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblc = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtc = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtf = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnllength = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnllenframe = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtinches = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtcm = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtmm = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblmm = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcm = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblinches = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbutter = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtgramsb = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txttbsp = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtstick = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtcup = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtozb = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblgramsb = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltbsp = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblstick = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcup = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblozb = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel5 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel0 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblml = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltsp = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltbspb = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblfloz = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcupsb = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblgal = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblliters = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblquarts = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblpints = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlvolume0 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlvolume1 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlvolume2 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtpints = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtml = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txttsp = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txttbspb = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtfloz = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtcupsb = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtquarts = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtliters = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtgal = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public void  _activescrnload(int _scrn) throws Exception{
ResumableSub_ActiveScrnLoad rsub = new ResumableSub_ActiveScrnLoad(this,_scrn);
rsub.resume(ba, null);
}
public static class ResumableSub_ActiveScrnLoad extends BA.ResumableSub {
public ResumableSub_ActiveScrnLoad(sadLogic.HomeCentral.pageconversions parent,int _scrn) {
this.parent = parent;
this._scrn = _scrn;
}
sadLogic.HomeCentral.pageconversions parent;
int _scrn;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 102;BA.debugLine="If currScrn = scrn Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._currscrn==_scrn) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 103;BA.debugLine="currScrn = scrn";
parent._currscrn = _scrn;
 //BA.debugLineNum = 104;BA.debugLine="pnlInput.RemoveAllViews";
parent._pnlinput.RemoveAllViews();
 //BA.debugLineNum = 109;BA.debugLine="pnlInput.Visible = False";
parent._pnlinput.setVisible(parent.__c.False);
 //BA.debugLineNum = 110;BA.debugLine="pnlInput.Top = lblWhat.Height";
parent._pnlinput.setTop(parent._lblwhat.getHeight());
 //BA.debugLineNum = 111;BA.debugLine="Select Case scrn";
if (true) break;

case 7:
//select
this.state = 18;
switch (BA.switchObjectToInt(_scrn,parent._scrnbutter,parent._scrnlength,parent._scrntemp,parent._scrnvolume,parent._scrnweight)) {
case 0: {
this.state = 9;
if (true) break;
}
case 1: {
this.state = 11;
if (true) break;
}
case 2: {
this.state = 13;
if (true) break;
}
case 3: {
this.state = 15;
if (true) break;
}
case 4: {
this.state = 17;
if (true) break;
}
}
if (true) break;

case 9:
//C
this.state = 18;
 //BA.debugLineNum = 114;BA.debugLine="guiHelpers.ResizeText(\"Butter\",lblWhat)";
parent._guihelpers._resizetext /*String*/ (ba,"Butter",parent._lblwhat);
 //BA.debugLineNum = 115;BA.debugLine="pnlInput.LoadLayout(\"scrnConvButter\")";
parent._pnlinput.LoadLayout("scrnConvButter",ba);
 //BA.debugLineNum = 117;BA.debugLine="guiHelpers.SetPanelsTranparent(Array As B4XView";
parent._guihelpers._setpanelstranparent /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnlbutter.getObject())),parent._panel1,parent._panel2,parent._panel3,parent._panel4,parent._panel5,parent._panel0});
 //BA.debugLineNum = 119;BA.debugLine="txtGramsB_FocusChanged(True)";
parent._txtgramsb_focuschanged(parent.__c.True);
 //BA.debugLineNum = 121;BA.debugLine="guiHelpers.SkinTextEdit(Array As EditText(txtGr";
parent._guihelpers._skintextedit /*String*/ (ba,new anywheresoftware.b4a.objects.EditTextWrapper[]{parent._txtgramsb,parent._txttbsp,parent._txtstick,parent._txtcup,parent._txtozb},(int) (0),parent.__c.True);
 //BA.debugLineNum = 123;BA.debugLine="guiHelpers.ResizeText(lblGramsB.Text,lblGramsB)";
parent._guihelpers._resizetext /*String*/ (ba,parent._lblgramsb.getText(),parent._lblgramsb);
 //BA.debugLineNum = 124;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(lblCUP,";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcup.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltbsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblstick.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblozb.getObject()))},parent._lblgramsb.getTextSize());
 //BA.debugLineNum = 126;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(txtCUP,";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtcup.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txttbsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtgramsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtstick.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtozb.getObject()))},(float) (24));
 //BA.debugLineNum = 127;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(txtCUP";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtcup.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txttbsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtgramsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtstick.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtozb.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 128;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblCUP";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcup.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltbsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblgramsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblstick.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblozb.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 if (true) break;

case 11:
//C
this.state = 18;
 //BA.debugLineNum = 132;BA.debugLine="guiHelpers.ResizeText(\"Length\",lblWhat)";
parent._guihelpers._resizetext /*String*/ (ba,"Length",parent._lblwhat);
 //BA.debugLineNum = 133;BA.debugLine="pnlInput.LoadLayout(\"scrnConvLength\")";
parent._pnlinput.LoadLayout("scrnConvLength",ba);
 //BA.debugLineNum = 134;BA.debugLine="pnlLength.Color= Colors.Transparent	: pnlLenFra";
parent._pnllength.setColor(parent.__c.Colors.Transparent);
 //BA.debugLineNum = 134;BA.debugLine="pnlLength.Color= Colors.Transparent	: pnlLenFra";
parent._pnllenframe.setColor(parent.__c.Colors.Transparent);
 //BA.debugLineNum = 135;BA.debugLine="txtMM_FocusChanged(True)";
parent._txtmm_focuschanged(parent.__c.True);
 //BA.debugLineNum = 137;BA.debugLine="guiHelpers.SkinTextEdit(Array As EditText(txtMM";
parent._guihelpers._skintextedit /*String*/ (ba,new anywheresoftware.b4a.objects.EditTextWrapper[]{parent._txtmm,parent._txtinches,parent._txtcm},(int) (0),parent.__c.True);
 //BA.debugLineNum = 139;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(txtInc";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtinches.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtcm.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtmm.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 140;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(txtInch";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtinches.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtcm.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtmm.getObject()))},(float) (24));
 //BA.debugLineNum = 141;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblInc";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblinches.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcm.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblmm.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 143;BA.debugLine="guiHelpers.ResizeText(lblMM.Text,lblMM)";
parent._guihelpers._resizetext /*String*/ (ba,parent._lblmm.getText(),parent._lblmm);
 //BA.debugLineNum = 144;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(lblCM,l";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcm.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblinches.getObject()))},parent._lblmm.getTextSize());
 if (true) break;

case 13:
//C
this.state = 18;
 //BA.debugLineNum = 147;BA.debugLine="guiHelpers.ResizeText(\"Temperature\",lblWhat)";
parent._guihelpers._resizetext /*String*/ (ba,"Temperature",parent._lblwhat);
 //BA.debugLineNum = 148;BA.debugLine="pnlInput.LoadLayout(\"scrnConvTemp\")";
parent._pnlinput.LoadLayout("scrnConvTemp",ba);
 //BA.debugLineNum = 149;BA.debugLine="pnlInput.Top = pnlInput.Top - 60dip";
parent._pnlinput.setTop((int) (parent._pnlinput.getTop()-parent.__c.DipToCurrent((int) (60))));
 //BA.debugLineNum = 150;BA.debugLine="pnlTemp.Color = Colors.Transparent";
parent._pnltemp.setColor(parent.__c.Colors.Transparent);
 //BA.debugLineNum = 151;BA.debugLine="txtF_FocusChanged(True)";
parent._txtf_focuschanged(parent.__c.True);
 //BA.debugLineNum = 153;BA.debugLine="guiHelpers.SkinTextEdit(Array As EditText(txtF,";
parent._guihelpers._skintextedit /*String*/ (ba,new anywheresoftware.b4a.objects.EditTextWrapper[]{parent._txtf,parent._txtc},(int) (0),parent.__c.True);
 //BA.debugLineNum = 155;BA.debugLine="txtF.TextColor = clrTheme.txtNormal : txtC.Text";
parent._txtf.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 155;BA.debugLine="txtF.TextColor = clrTheme.txtNormal : txtC.Text";
parent._txtc.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 156;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(txtC,tx";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtc.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtf.getObject()))},(float) (24));
 //BA.debugLineNum = 157;BA.debugLine="lblF.TextColor = clrTheme.txtNormal : lblC.Text";
parent._lblf.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 157;BA.debugLine="lblF.TextColor = clrTheme.txtNormal : lblC.Text";
parent._lblc.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 159;BA.debugLine="guiHelpers.ResizeText(lblF.Text,lblF) : lblC.Te";
parent._guihelpers._resizetext /*String*/ (ba,parent._lblf.getText(),parent._lblf);
 //BA.debugLineNum = 159;BA.debugLine="guiHelpers.ResizeText(lblF.Text,lblF) : lblC.Te";
parent._lblc.setTextSize(parent._lblf.getTextSize());
 if (true) break;

case 15:
//C
this.state = 18;
 //BA.debugLineNum = 162;BA.debugLine="guiHelpers.ResizeText(\"Volume\",lblWhat)";
parent._guihelpers._resizetext /*String*/ (ba,"Volume",parent._lblwhat);
 //BA.debugLineNum = 163;BA.debugLine="pnlInput.LoadLayout(\"scrnConvVolume\")";
parent._pnlinput.LoadLayout("scrnConvVolume",ba);
 //BA.debugLineNum = 164;BA.debugLine="guiHelpers.SetPanelsTranparent(Array As B4XView";
parent._guihelpers._setpanelstranparent /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnlvolume0.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnlvolume1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnlvolume2.getObject()))});
 //BA.debugLineNum = 165;BA.debugLine="txtML_FocusChanged(True)";
parent._txtml_focuschanged(parent.__c.True);
 //BA.debugLineNum = 167;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(txtPINT";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtpints.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtml.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txttsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txttbspb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtfloz.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtcupsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtquarts.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtliters.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtgal.getObject()))},(float) (24));
 //BA.debugLineNum = 168;BA.debugLine="guiHelpers.SkinTextEdit(Array As EditText(txtPI";
parent._guihelpers._skintextedit /*String*/ (ba,new anywheresoftware.b4a.objects.EditTextWrapper[]{parent._txtpints,parent._txtml,parent._txttsp,parent._txttbspb,parent._txtfloz,parent._txtcupsb,parent._txtquarts,parent._txtliters,parent._txtgal},(int) (0),parent.__c.True);
 //BA.debugLineNum = 169;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblPIN";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblpints.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblml.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltbspb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblfloz.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcupsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblquarts.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblliters.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblgal.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 181;BA.debugLine="guiHelpers.ResizeText(lblML.Text,lblML)";
parent._guihelpers._resizetext /*String*/ (ba,parent._lblml.getText(),parent._lblml);
 //BA.debugLineNum = 182;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(lblPINT";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblpints.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltsp.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltbspb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblfloz.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblcupsb.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblquarts.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblliters.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblgal.getObject()))},parent._lblml.getTextSize());
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 186;BA.debugLine="guiHelpers.ResizeText(\"Weight\",lblWhat)";
parent._guihelpers._resizetext /*String*/ (ba,"Weight",parent._lblwhat);
 //BA.debugLineNum = 187;BA.debugLine="pnlInput.LoadLayout(\"scrnConvWeight\")";
parent._pnlinput.LoadLayout("scrnConvWeight",ba);
 //BA.debugLineNum = 188;BA.debugLine="pnlWeight.Color  = Colors.Transparent : pnlWeig";
parent._pnlweight.setColor(parent.__c.Colors.Transparent);
 //BA.debugLineNum = 188;BA.debugLine="pnlWeight.Color  = Colors.Transparent : pnlWeig";
parent._pnlweightf.setColor(parent.__c.Colors.Transparent);
 //BA.debugLineNum = 190;BA.debugLine="txtOZ_FocusChanged(True)";
parent._txtoz_focuschanged(parent.__c.True);
 //BA.debugLineNum = 192;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(txtOZ,t";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtoz.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtpounds.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtkg.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._txtgrams.getObject()))},(float) (24));
 //BA.debugLineNum = 193;BA.debugLine="guiHelpers.SkinTextEdit(Array As EditText(txtOZ";
parent._guihelpers._skintextedit /*String*/ (ba,new anywheresoftware.b4a.objects.EditTextWrapper[]{parent._txtoz,parent._txtpounds,parent._txtkg,parent._txtgrams},(int) (0),parent.__c.True);
 //BA.debugLineNum = 194;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblKG,";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblkg.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblgrams.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblpounds.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbloz.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 196;BA.debugLine="guiHelpers.ResizeText(lblOZ.Text,lblOZ)";
parent._guihelpers._resizetext /*String*/ (ba,parent._lbloz.getText(),parent._lbloz);
 //BA.debugLineNum = 197;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(lblKG,l";
parent._guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblkg.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblgrams.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lblpounds.getObject()))},parent._lbloz.getTextSize());
 if (true) break;

case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 201;BA.debugLine="pnlInput.SetVisibleAnimated(500,True)";
parent._pnlinput.SetVisibleAnimated((int) (500),parent.__c.True);
 //BA.debugLineNum = 202;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 19;
return;
case 19:
//C
this.state = -1;
;
 //BA.debugLineNum = 204;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _btnnums_click() throws Exception{
String _txt = "";
 //BA.debugLineNum = 231;BA.debugLine="Private Sub btnNums_Click";
 //BA.debugLineNum = 232;BA.debugLine="Dim txt As String = Sender.As(Button).Text";
_txt = ((anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)))).getText();
 //BA.debugLineNum = 233;BA.debugLine="curTxt.Text = curTxt.Text & txt";
_curtxt.setText(BA.ObjectToCharSequence(_curtxt.getText()+_txt));
 //BA.debugLineNum = 234;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Public Sub Build_Side_Menu";
 //BA.debugLineNum = 224;BA.debugLine="Menus.BuildSideMenu(Array As String(\"Weight\",\"Vol";
_menus._buildsidemenu /*String*/ (ba,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Weight","Volume","Temp","Butter","Length"}),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"we","vo","te","bu","le"}));
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return "";
}
public String  _button12_click() throws Exception{
 //BA.debugLineNum = 238;BA.debugLine="Sub Button12_Click";
 //BA.debugLineNum = 239;BA.debugLine="doCalc : '--- do the conversion";
_docalc();
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 11;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private pnlBG,pnlNumPad,pnlInput As Panel";
_pnlbg = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlnumpad = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlinput = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private oConversion As ConversionMod";
_oconversion = new sadLogic.HomeCentral.conversionmod();
 //BA.debugLineNum = 14;BA.debugLine="Private curTxt As EditText";
_curtxt = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private Button1,Button2,Button3,Button4,Button5,B";
_button1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button2 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button3 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button4 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button6 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button7 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private Button8,Button9,Button10,Button11,Button1";
_button8 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button9 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button10 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button11 = new anywheresoftware.b4a.objects.ButtonWrapper();
_button12 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private currScrn As Int";
_currscrn = 0;
 //BA.debugLineNum = 22;BA.debugLine="Private lblWhat As Label";
_lblwhat = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private scrnWeight, scrnVolume, scrnTemp, scrnLen";
_scrnweight = 0;
_scrnvolume = 0;
_scrntemp = 0;
_scrnlength = 0;
_scrnbutter = 0;
 //BA.debugLineNum = 25;BA.debugLine="scrnButter = 0: scrnLength = 1: scrnTemp = 2: scr";
_scrnbutter = (int) (0);
 //BA.debugLineNum = 25;BA.debugLine="scrnButter = 0: scrnLength = 1: scrnTemp = 2: scr";
_scrnlength = (int) (1);
 //BA.debugLineNum = 25;BA.debugLine="scrnButter = 0: scrnLength = 1: scrnTemp = 2: scr";
_scrntemp = (int) (2);
 //BA.debugLineNum = 25;BA.debugLine="scrnButter = 0: scrnLength = 1: scrnTemp = 2: scr";
_scrnvolume = (int) (3);
 //BA.debugLineNum = 25;BA.debugLine="scrnButter = 0: scrnLength = 1: scrnTemp = 2: scr";
_scrnweight = (int) (4);
 //BA.debugLineNum = 28;BA.debugLine="Private pnlWeight,pnlWeightF As Panel";
_pnlweight = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlweightf = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private txtOZ,txtPounds,txtKG,txtGrams As EditTex";
_txtoz = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtpounds = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtkg = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtgrams = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private lblKG,lblGrams,lblPounds,lblOZ As Label";
_lblkg = new anywheresoftware.b4a.objects.LabelWrapper();
_lblgrams = new anywheresoftware.b4a.objects.LabelWrapper();
_lblpounds = new anywheresoftware.b4a.objects.LabelWrapper();
_lbloz = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private pnlTemp As Panel";
_pnltemp = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private lblF,lblC As Label";
_lblf = new anywheresoftware.b4a.objects.LabelWrapper();
_lblc = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private txtC,txtF As EditText";
_txtc = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtf = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private pnlLength,pnlLenFrame As Panel";
_pnllength = new anywheresoftware.b4a.objects.PanelWrapper();
_pnllenframe = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private txtInches,txtCM,txtMM As  EditText";
_txtinches = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtcm = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtmm = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private lblMM,lblCM,lblInches As Label";
_lblmm = new anywheresoftware.b4a.objects.LabelWrapper();
_lblcm = new anywheresoftware.b4a.objects.LabelWrapper();
_lblinches = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private pnlButter As Panel";
_pnlbutter = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private txtGramsB,txtTBSP,txtStick,txtCUP,txtOZb";
_txtgramsb = new anywheresoftware.b4a.objects.EditTextWrapper();
_txttbsp = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtstick = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtcup = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtozb = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private lblGramsB,lblTBSP,lblStick,lblCUP,lblOZb";
_lblgramsb = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltbsp = new anywheresoftware.b4a.objects.LabelWrapper();
_lblstick = new anywheresoftware.b4a.objects.LabelWrapper();
_lblcup = new anywheresoftware.b4a.objects.LabelWrapper();
_lblozb = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private Panel1,Panel2,Panel3,Panel4,Panel5,Panel0";
_panel1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_panel2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_panel3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_panel4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_panel5 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_panel0 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Private lblML,lblTSP,lblTBSPb,lblFLOZ,lblCUPSb As";
_lblml = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltsp = new anywheresoftware.b4a.objects.LabelWrapper();
_lbltbspb = new anywheresoftware.b4a.objects.LabelWrapper();
_lblfloz = new anywheresoftware.b4a.objects.LabelWrapper();
_lblcupsb = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Private lblGAL,lblLiters,lblQuarts,lblPINTS As La";
_lblgal = new anywheresoftware.b4a.objects.LabelWrapper();
_lblliters = new anywheresoftware.b4a.objects.LabelWrapper();
_lblquarts = new anywheresoftware.b4a.objects.LabelWrapper();
_lblpints = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 52;BA.debugLine="Private pnlVolume0,pnlVolume1,pnlVolume2 As Panel";
_pnlvolume0 = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlvolume1 = new anywheresoftware.b4a.objects.PanelWrapper();
_pnlvolume2 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 53;BA.debugLine="Private txtPINTS,txtML,txtTSP,txtTBSPb,txtFlOZ,tx";
_txtpints = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtml = new anywheresoftware.b4a.objects.EditTextWrapper();
_txttsp = new anywheresoftware.b4a.objects.EditTextWrapper();
_txttbspb = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtfloz = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtcupsb = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtquarts = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtliters = new anywheresoftware.b4a.objects.EditTextWrapper();
_txtgal = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _clearbutter() throws Exception{
 //BA.debugLineNum = 404;BA.debugLine="Sub ClearButter";
 //BA.debugLineNum = 405;BA.debugLine="txtCUP.Text = \"\"";
_txtcup.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 406;BA.debugLine="txtTBSP.Text = \"\"";
_txttbsp.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 407;BA.debugLine="txtGramsB.Text = \"\"";
_txtgramsb.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 408;BA.debugLine="txtOZb.Text = \"\"";
_txtozb.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 409;BA.debugLine="txtStick.Text = \"\"";
_txtstick.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 410;BA.debugLine="End Sub";
return "";
}
public String  _clearlength() throws Exception{
 //BA.debugLineNum = 350;BA.debugLine="Sub ClearLength";
 //BA.debugLineNum = 351;BA.debugLine="txtMM.Text = \"\"";
_txtmm.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 352;BA.debugLine="txtCM.Text = \"\"";
_txtcm.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 353;BA.debugLine="txtInches.Text = \"\"";
_txtinches.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 354;BA.debugLine="End Sub";
return "";
}
public String  _cleartemp() throws Exception{
 //BA.debugLineNum = 314;BA.debugLine="Private Sub ClearTemp()";
 //BA.debugLineNum = 315;BA.debugLine="txtC.Text = \"\"";
_txtc.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 316;BA.debugLine="txtF.Text = \"\"";
_txtf.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 317;BA.debugLine="End Sub";
return "";
}
public String  _clearvolume() throws Exception{
 //BA.debugLineNum = 707;BA.debugLine="Sub ClearVolume";
 //BA.debugLineNum = 708;BA.debugLine="txtPINTS.Text = \"\"";
_txtpints.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 709;BA.debugLine="txtML.Text = \"\"";
_txtml.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 710;BA.debugLine="txtTSP.Text = \"\"";
_txttsp.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 711;BA.debugLine="txtTBSPb.Text = \"\"";
_txttbspb.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 712;BA.debugLine="txtFlOZ.Text = \"\"";
_txtfloz.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 713;BA.debugLine="txtCUPSb.Text = \"\"";
_txtcupsb.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 714;BA.debugLine="txtQuarts.Text = \"\"";
_txtquarts.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 715;BA.debugLine="txtLiters.Text = \"\"";
_txtliters.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 716;BA.debugLine="txtGAL.Text = \"\"";
_txtgal.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 717;BA.debugLine="End Sub";
return "";
}
public String  _clearweight() throws Exception{
 //BA.debugLineNum = 284;BA.debugLine="Private Sub ClearWeight()";
 //BA.debugLineNum = 285;BA.debugLine="txtOZ.Text = \"\"";
_txtoz.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 286;BA.debugLine="txtPounds.Text = \"\"";
_txtpounds.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 287;BA.debugLine="txtGrams.Text = \"\"";
_txtgrams.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 288;BA.debugLine="txtKG.Text = \"\"";
_txtkg.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return "";
}
public String  _docalc() throws Exception{
float _value = 0f;
 //BA.debugLineNum = 414;BA.debugLine="Private Sub doCalc";
 //BA.debugLineNum = 417;BA.debugLine="Dim value As Float";
_value = 0f;
 //BA.debugLineNum = 418;BA.debugLine="Select Case currScrn";
switch (BA.switchObjectToInt(_currscrn,_scrnvolume,_scrnbutter,_scrnweight,_scrntemp,_scrnlength)) {
case 0: {
 //BA.debugLineNum = 420;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txtgal.getText().length()!=0 && (_txtgal.getText().trim()).equals(".") == false,_txtfloz.getText().length()!=0 && (_txtfloz.getText().trim()).equals(".") == false,_txtcupsb.getText().length()!=0 && (_txtcupsb.getText().trim()).equals(".") == false,_txtpints.getText().length()!=0 && (_txtpints.getText().trim()).equals(".") == false,_txttsp.getText().length()!=0 && (_txttsp.getText().trim()).equals(".") == false,_txttbspb.getText().length()!=0 && (_txttbspb.getText().trim()).equals(".") == false,_txtquarts.getText().length()!=0 && (_txtquarts.getText().trim()).equals(".") == false,_txtml.getText().length()!=0 && (_txtml.getText().trim()).equals(".") == false,_txtliters.getText().length()!=0 && (_txtliters.getText().trim()).equals(".") == false)) {
case 0: {
 //BA.debugLineNum = 422;BA.debugLine="value = txtGAL.Text";
_value = (float)(Double.parseDouble(_txtgal.getText()));
 //BA.debugLineNum = 423;BA.debugLine="txtPINTS.Text = oConversion.volume_gal2pints(";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2pints /*float*/ (_value)));
 //BA.debugLineNum = 424;BA.debugLine="txtQuarts.Text = oConversion.volume_gal2quart";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2quarts /*float*/ (_value)));
 //BA.debugLineNum = 425;BA.debugLine="txtML.Text = oConversion.volume_gal2ml(value)";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2ml /*float*/ (_value)));
 //BA.debugLineNum = 426;BA.debugLine="txtCUPSb.Text = oConversion.volume_gal2cups(v";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2cups /*float*/ (_value)));
 //BA.debugLineNum = 427;BA.debugLine="txtFlOZ.Text = oConversion.volume_gal2floz(va";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2floz /*float*/ (_value)));
 //BA.debugLineNum = 428;BA.debugLine="txtLiters.Text = oConversion.volume_gal2liter";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2liters /*float*/ (_value)));
 //BA.debugLineNum = 429;BA.debugLine="txtTSP.Text = oConversion.volume_gal2tsp(valu";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2tsp /*float*/ (_value)));
 //BA.debugLineNum = 430;BA.debugLine="txtTBSPb.Text = oConversion.volume_gal2tbsp(v";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_gal2tbsp /*float*/ (_value)));
 break; }
case 1: {
 //BA.debugLineNum = 433;BA.debugLine="value = txtFlOZ.Text";
_value = (float)(Double.parseDouble(_txtfloz.getText()));
 //BA.debugLineNum = 434;BA.debugLine="txtPINTS.Text = oConversion.volume_floz2pints";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2pints /*float*/ (_value)));
 //BA.debugLineNum = 435;BA.debugLine="txtQuarts.Text = oConversion.volume_floz2quar";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2quarts /*float*/ (_value)));
 //BA.debugLineNum = 436;BA.debugLine="txtML.Text = oConversion.volume_floz2ml(value";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2ml /*float*/ (_value)));
 //BA.debugLineNum = 437;BA.debugLine="txtCUPSb.Text = oConversion.volume_floz2cups(";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2cups /*float*/ (_value)));
 //BA.debugLineNum = 438;BA.debugLine="txtGAL.Text = oConversion.volume_floz2gal(val";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2gal /*float*/ (_value)));
 //BA.debugLineNum = 439;BA.debugLine="txtLiters.Text = oConversion.volume_floz2lite";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2liters /*float*/ (_value)));
 //BA.debugLineNum = 440;BA.debugLine="txtTSP.Text = oConversion.volume_floz2tsp(val";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2tsp /*float*/ (_value)));
 //BA.debugLineNum = 441;BA.debugLine="txtTBSPb.Text = oConversion.volume_floz2tbsp(";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_floz2tbsp /*float*/ (_value)));
 break; }
case 2: {
 //BA.debugLineNum = 444;BA.debugLine="value = txtCUPSb.Text";
_value = (float)(Double.parseDouble(_txtcupsb.getText()));
 //BA.debugLineNum = 445;BA.debugLine="txtPINTS.Text = oConversion.volume_cups2pints";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2pints /*float*/ (_value)));
 //BA.debugLineNum = 446;BA.debugLine="txtQuarts.Text = oConversion.volume_cups2quar";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2quarts /*float*/ (_value)));
 //BA.debugLineNum = 447;BA.debugLine="txtML.Text = oConversion.volume_cups2ml(value";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2ml /*float*/ (_value)));
 //BA.debugLineNum = 448;BA.debugLine="txtFlOZ.Text = oConversion.volume_cups2floz(v";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2floz /*float*/ (_value)));
 //BA.debugLineNum = 449;BA.debugLine="txtGAL.Text = oConversion.volume_cups2gal(val";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2gal /*float*/ (_value)));
 //BA.debugLineNum = 450;BA.debugLine="txtLiters.Text = oConversion.volume_cups2lite";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2liters /*float*/ (_value)));
 //BA.debugLineNum = 451;BA.debugLine="txtTSP.Text = oConversion.volume_cups2tsp(val";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2tsp /*float*/ (_value)));
 //BA.debugLineNum = 452;BA.debugLine="txtTBSPb.Text = oConversion.volume_cups2tbsp(";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_cups2tbsp /*float*/ (_value)));
 break; }
case 3: {
 //BA.debugLineNum = 455;BA.debugLine="value = txtPINTS.Text";
_value = (float)(Double.parseDouble(_txtpints.getText()));
 //BA.debugLineNum = 456;BA.debugLine="txtCUPSb.Text = oConversion.volume_pints2cups";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2cups /*float*/ (_value)));
 //BA.debugLineNum = 457;BA.debugLine="txtQuarts.Text = oConversion.volume_pints2qua";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2quarts /*float*/ (_value)));
 //BA.debugLineNum = 458;BA.debugLine="txtML.Text = oConversion.volume_pints2ml(valu";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2ml /*float*/ (_value)));
 //BA.debugLineNum = 459;BA.debugLine="txtFlOZ.Text = oConversion.volume_pints2floz(";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2floz /*float*/ (_value)));
 //BA.debugLineNum = 460;BA.debugLine="txtGAL.Text = oConversion.volume_pints2gal(va";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2gal /*float*/ (_value)));
 //BA.debugLineNum = 461;BA.debugLine="txtLiters.Text = oConversion.volume_pints2lit";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2liters /*float*/ (_value)));
 //BA.debugLineNum = 462;BA.debugLine="txtTSP.Text = oConversion.volume_pints2tsp(va";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2tsp /*float*/ (_value)));
 //BA.debugLineNum = 463;BA.debugLine="txtTBSPb.Text = oConversion.volume_pints2tbsp";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_pints2tbsp /*float*/ (_value)));
 break; }
case 4: {
 //BA.debugLineNum = 466;BA.debugLine="value = txtTSP.Text";
_value = (float)(Double.parseDouble(_txttsp.getText()));
 //BA.debugLineNum = 467;BA.debugLine="txtCUPSb.Text = oConversion.volume_tsp2cups(v";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2cups /*float*/ (_value)));
 //BA.debugLineNum = 468;BA.debugLine="txtQuarts.Text = oConversion.volume_tsp2quart";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2quarts /*float*/ (_value)));
 //BA.debugLineNum = 469;BA.debugLine="txtML.Text = oConversion.volume_tsp2ml(value)";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2ml /*float*/ (_value)));
 //BA.debugLineNum = 470;BA.debugLine="txtFlOZ.Text = oConversion.volume_tsp2floz(va";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2floz /*float*/ (_value)));
 //BA.debugLineNum = 471;BA.debugLine="txtGAL.Text = oConversion.volume_tsp2gal(valu";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2gal /*float*/ (_value)));
 //BA.debugLineNum = 472;BA.debugLine="txtLiters.Text = oConversion.volume_tsp2liter";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2liters /*float*/ (_value)));
 //BA.debugLineNum = 473;BA.debugLine="txtPINTS.Text = oConversion.volume_tsp2pints(";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2pints /*float*/ (_value)));
 //BA.debugLineNum = 474;BA.debugLine="txtTBSPb.Text = oConversion.volume_tsp2tbsp(v";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_tsp2tbsp /*float*/ (_value)));
 break; }
case 5: {
 //BA.debugLineNum = 477;BA.debugLine="value = txtTBSPb.Text";
_value = (float)(Double.parseDouble(_txttbspb.getText()));
 //BA.debugLineNum = 478;BA.debugLine="txtCUPSb.Text = oConversion.volume_tbsp2cups(";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2cups /*float*/ (_value)));
 //BA.debugLineNum = 479;BA.debugLine="txtQuarts.Text = oConversion.volume_tbsp2quar";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2quarts /*float*/ (_value)));
 //BA.debugLineNum = 480;BA.debugLine="txtML.Text = oConversion.volume_tbsp2ml(value";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2ml /*float*/ (_value)));
 //BA.debugLineNum = 481;BA.debugLine="txtFlOZ.Text = oConversion.volume_tbsp2floz(v";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2floz /*float*/ (_value)));
 //BA.debugLineNum = 482;BA.debugLine="txtGAL.Text = oConversion.volume_tbsp2gal(val";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2gal /*float*/ (_value)));
 //BA.debugLineNum = 483;BA.debugLine="txtLiters.Text = oConversion.volume_tbsp2lite";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2liters /*float*/ (_value)));
 //BA.debugLineNum = 484;BA.debugLine="txtPINTS.Text = oConversion.volume_tbsp2pints";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2pints /*float*/ (_value)));
 //BA.debugLineNum = 485;BA.debugLine="txtTSP.Text = oConversion.volume_tbsp2tsp(val";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_tbsp2tsp /*float*/ (_value)));
 break; }
case 6: {
 //BA.debugLineNum = 488;BA.debugLine="value = txtQuarts.Text";
_value = (float)(Double.parseDouble(_txtquarts.getText()));
 //BA.debugLineNum = 489;BA.debugLine="txtCUPSb.Text = oConversion.volume_quart2cups";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2cups /*float*/ (_value)));
 //BA.debugLineNum = 490;BA.debugLine="txtTBSPb.Text = oConversion.volume_quart2tbsp";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2tbsp /*float*/ (_value)));
 //BA.debugLineNum = 491;BA.debugLine="txtML.Text = oConversion.volume_quart2ml(valu";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2ml /*float*/ (_value)));
 //BA.debugLineNum = 492;BA.debugLine="txtFlOZ.Text = oConversion.volume_quart2floz(";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2floz /*float*/ (_value)));
 //BA.debugLineNum = 493;BA.debugLine="txtGAL.Text = oConversion.volume_quart2gal(va";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2gal /*float*/ (_value)));
 //BA.debugLineNum = 494;BA.debugLine="txtLiters.Text = oConversion.volume_quart2lit";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2liters /*float*/ (_value)));
 //BA.debugLineNum = 495;BA.debugLine="txtPINTS.Text = oConversion.volume_quart2pint";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2pints /*float*/ (_value)));
 //BA.debugLineNum = 496;BA.debugLine="txtTSP.Text = oConversion.volume_quart2tsp(va";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_quart2tsp /*float*/ (_value)));
 break; }
case 7: {
 //BA.debugLineNum = 499;BA.debugLine="value = txtML.Text";
_value = (float)(Double.parseDouble(_txtml.getText()));
 //BA.debugLineNum = 500;BA.debugLine="txtCUPSb.Text = oConversion.volume_ml2cups(va";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2cups /*float*/ (_value)));
 //BA.debugLineNum = 501;BA.debugLine="txtTBSPb.Text = oConversion.volume_ml2tbsp(va";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2tbsp /*float*/ (_value)));
 //BA.debugLineNum = 502;BA.debugLine="txtQuarts.Text = oConversion.volume_ml2quart(";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2quart /*float*/ (_value)));
 //BA.debugLineNum = 503;BA.debugLine="txtFlOZ.Text = oConversion.volume_ml2floz(val";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2floz /*float*/ (_value)));
 //BA.debugLineNum = 504;BA.debugLine="txtGAL.Text = oConversion.volume_ml2gal(value";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2gal /*float*/ (_value)));
 //BA.debugLineNum = 505;BA.debugLine="txtLiters.Text = oConversion.volume_ml2liters";
_txtliters.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2liters /*float*/ (_value)));
 //BA.debugLineNum = 506;BA.debugLine="txtPINTS.Text = oConversion.volume_ml2pints(v";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2pints /*float*/ (_value)));
 //BA.debugLineNum = 507;BA.debugLine="txtTSP.Text = oConversion.volume_ml2tsp(value";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_ml2tsp /*float*/ (_value)));
 break; }
case 8: {
 //BA.debugLineNum = 510;BA.debugLine="value = txtLiters.Text";
_value = (float)(Double.parseDouble(_txtliters.getText()));
 //BA.debugLineNum = 511;BA.debugLine="txtCUPSb.Text = oConversion.volume_liter2cups";
_txtcupsb.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2cups /*float*/ (_value)));
 //BA.debugLineNum = 512;BA.debugLine="txtTBSPb.Text = oConversion.volume_liter2tbsp";
_txttbspb.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2tbsp /*float*/ (_value)));
 //BA.debugLineNum = 513;BA.debugLine="txtQuarts.Text = oConversion.volume_liter2qua";
_txtquarts.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2quart /*float*/ (_value)));
 //BA.debugLineNum = 514;BA.debugLine="txtFlOZ.Text = oConversion.volume_liter2floz(";
_txtfloz.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2floz /*float*/ (_value)));
 //BA.debugLineNum = 515;BA.debugLine="txtGAL.Text = oConversion.volume_liter2gal(va";
_txtgal.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2gal /*float*/ (_value)));
 //BA.debugLineNum = 516;BA.debugLine="txtML.Text = oConversion.volume_liter2ml(valu";
_txtml.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2ml /*float*/ (_value)));
 //BA.debugLineNum = 517;BA.debugLine="txtPINTS.Text = oConversion.volume_liter2pint";
_txtpints.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2pints /*float*/ (_value)));
 //BA.debugLineNum = 518;BA.debugLine="txtTSP.Text = oConversion.volume_liter2tsp(va";
_txttsp.setText(BA.ObjectToCharSequence(_oconversion._volume_liter2tsp /*float*/ (_value)));
 break; }
}
;
 break; }
case 1: {
 //BA.debugLineNum = 523;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txtozb.getText().length()!=0 && (_txtozb.getText().trim()).equals(".") == false,_txtgramsb.getText().length()!=0 && (_txtgramsb.getText().trim()).equals(".") == false,_txtstick.getText().length()!=0 && (_txtstick.getText().trim()).equals(".") == false,_txtcup.getText().length()!=0 && (_txtcup.getText().trim()).equals(".") == false,_txttbsp.getText().length()!=0 && (_txttbsp.getText().trim()).equals(".") == false)) {
case 0: {
 //BA.debugLineNum = 525;BA.debugLine="value = txtOZb.Text";
_value = (float)(Double.parseDouble(_txtozb.getText()));
 //BA.debugLineNum = 526;BA.debugLine="txtGramsB.Text = oConversion.butter_oz2grams(";
_txtgramsb.setText(BA.ObjectToCharSequence(_oconversion._butter_oz2grams /*float*/ (_value)));
 //BA.debugLineNum = 527;BA.debugLine="txtStick.Text  = oConversion.butter_oz2stick(";
_txtstick.setText(BA.ObjectToCharSequence(_oconversion._butter_oz2stick /*float*/ (_value)));
 //BA.debugLineNum = 528;BA.debugLine="txtCUP.Text    = oConversion.butter_oz2cup(va";
_txtcup.setText(BA.ObjectToCharSequence(_oconversion._butter_oz2cup /*float*/ (_value)));
 //BA.debugLineNum = 529;BA.debugLine="txtTBSP.Text   = oConversion.butter_oz2tbsp(v";
_txttbsp.setText(BA.ObjectToCharSequence(_oconversion._butter_oz2tbsp /*float*/ (_value)));
 break; }
case 1: {
 //BA.debugLineNum = 532;BA.debugLine="value = txtGramsB.Text";
_value = (float)(Double.parseDouble(_txtgramsb.getText()));
 //BA.debugLineNum = 533;BA.debugLine="txtOZb.Text    = oConversion.butter_grams2oz(";
_txtozb.setText(BA.ObjectToCharSequence(_oconversion._butter_grams2oz /*float*/ (_value)));
 //BA.debugLineNum = 534;BA.debugLine="txtStick.Text  = oConversion.butter_grams2sti";
_txtstick.setText(BA.ObjectToCharSequence(_oconversion._butter_grams2stick /*float*/ (_value)));
 //BA.debugLineNum = 535;BA.debugLine="txtCUP.Text    = oConversion.butter_grams2cup";
_txtcup.setText(BA.ObjectToCharSequence(_oconversion._butter_grams2cup /*float*/ (_value)));
 //BA.debugLineNum = 536;BA.debugLine="txtTBSP.Text   = oConversion.butter_grams2tbs";
_txttbsp.setText(BA.ObjectToCharSequence(_oconversion._butter_grams2tbsp /*float*/ (_value)));
 break; }
case 2: {
 //BA.debugLineNum = 539;BA.debugLine="value = txtStick.Text";
_value = (float)(Double.parseDouble(_txtstick.getText()));
 //BA.debugLineNum = 540;BA.debugLine="txtOZb.Text    = oConversion.butter_stick2oz(";
_txtozb.setText(BA.ObjectToCharSequence(_oconversion._butter_stick2oz /*float*/ (_value)));
 //BA.debugLineNum = 541;BA.debugLine="txtCUP.Text    = oConversion.butter_stick2cup";
_txtcup.setText(BA.ObjectToCharSequence(_oconversion._butter_stick2cups /*float*/ (_value)));
 //BA.debugLineNum = 542;BA.debugLine="txtGramsB.Text = oConversion.butter_stick2gra";
_txtgramsb.setText(BA.ObjectToCharSequence(_oconversion._butter_stick2gram /*float*/ (_value)));
 //BA.debugLineNum = 543;BA.debugLine="txtTBSP.Text   = oConversion.butter_stick2tbs";
_txttbsp.setText(BA.ObjectToCharSequence(_oconversion._butter_stick2tbsp /*float*/ (_value)));
 break; }
case 3: {
 //BA.debugLineNum = 546;BA.debugLine="value = txtCUP.Text";
_value = (float)(Double.parseDouble(_txtcup.getText()));
 //BA.debugLineNum = 547;BA.debugLine="txtOZb.Text    = oConversion.butter_cup2oz(va";
_txtozb.setText(BA.ObjectToCharSequence(_oconversion._butter_cup2oz /*float*/ (_value)));
 //BA.debugLineNum = 548;BA.debugLine="txtStick.Text  = oConversion.butter_cup2stick";
_txtstick.setText(BA.ObjectToCharSequence(_oconversion._butter_cup2stick /*float*/ (_value)));
 //BA.debugLineNum = 549;BA.debugLine="txtGramsB.Text = oConversion.butter_cup2gram(";
_txtgramsb.setText(BA.ObjectToCharSequence(_oconversion._butter_cup2gram /*float*/ (_value)));
 //BA.debugLineNum = 550;BA.debugLine="txtTBSP.Text   = oConversion.butter_cup2tbsp(";
_txttbsp.setText(BA.ObjectToCharSequence(_oconversion._butter_cup2tbsp /*float*/ (_value)));
 break; }
case 4: {
 //BA.debugLineNum = 553;BA.debugLine="value = txtTBSP.Text";
_value = (float)(Double.parseDouble(_txttbsp.getText()));
 //BA.debugLineNum = 554;BA.debugLine="txtCUP.Text    = oConversion.butter_tbsp2cups";
_txtcup.setText(BA.ObjectToCharSequence(_oconversion._butter_tbsp2cups /*float*/ (_value)));
 //BA.debugLineNum = 555;BA.debugLine="txtStick.Text  = oConversion.butter_tbsp2stic";
_txtstick.setText(BA.ObjectToCharSequence(_oconversion._butter_tbsp2stick /*float*/ (_value)));
 //BA.debugLineNum = 556;BA.debugLine="txtGramsB.Text = oConversion.butter_tbsp2gram";
_txtgramsb.setText(BA.ObjectToCharSequence(_oconversion._butter_tbsp2gram /*float*/ (_value)));
 //BA.debugLineNum = 557;BA.debugLine="txtOZb.Text    = oConversion.butter_tbsp2oz(v";
_txtozb.setText(BA.ObjectToCharSequence(_oconversion._butter_tbsp2oz /*float*/ (_value)));
 break; }
}
;
 break; }
case 2: {
 //BA.debugLineNum = 562;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txtoz.getText().length()!=0 && (_txtoz.getText().trim()).equals(".") == false,_txtpounds.getText().length()!=0 && (_txtpounds.getText().trim()).equals(".") == false,_txtgrams.getText().length()!=0 && (_txtgrams.getText().trim()).equals(".") == false,_txtkg.getText().length()!=0 && (_txtkg.getText().trim()).equals(".") == false)) {
case 0: {
 //BA.debugLineNum = 564;BA.debugLine="value = txtOZ.Text";
_value = (float)(Double.parseDouble(_txtoz.getText()));
 //BA.debugLineNum = 565;BA.debugLine="txtPounds.Text = oConversion.weight_oz2pounds";
_txtpounds.setText(BA.ObjectToCharSequence(_oconversion._weight_oz2pounds /*float*/ (_value)));
 //BA.debugLineNum = 566;BA.debugLine="txtGrams.Text  = oConversion.weight_oz2grams(";
_txtgrams.setText(BA.ObjectToCharSequence(_oconversion._weight_oz2grams /*float*/ (_value)));
 //BA.debugLineNum = 567;BA.debugLine="txtKG.Text     = oConversion.weight_oz2kg(val";
_txtkg.setText(BA.ObjectToCharSequence(_oconversion._weight_oz2kg /*float*/ (_value)));
 break; }
case 1: {
 //BA.debugLineNum = 570;BA.debugLine="value = txtPounds.Text";
_value = (float)(Double.parseDouble(_txtpounds.getText()));
 //BA.debugLineNum = 571;BA.debugLine="txtOZ.Text    = oConversion.weight_pounds2oz(";
_txtoz.setText(BA.ObjectToCharSequence(_oconversion._weight_pounds2oz /*float*/ (_value)));
 //BA.debugLineNum = 572;BA.debugLine="txtGrams.Text = oConversion.weight_pounds2gra";
_txtgrams.setText(BA.ObjectToCharSequence(_oconversion._weight_pounds2grams /*float*/ (_value)));
 //BA.debugLineNum = 573;BA.debugLine="txtKG.Text    = oConversion.weight_pounds2kg(";
_txtkg.setText(BA.ObjectToCharSequence(_oconversion._weight_pounds2kg /*float*/ (_value)));
 break; }
case 2: {
 //BA.debugLineNum = 576;BA.debugLine="value = txtGrams.Text";
_value = (float)(Double.parseDouble(_txtgrams.getText()));
 //BA.debugLineNum = 577;BA.debugLine="txtPounds.Text = oConversion.weight_grams2pou";
_txtpounds.setText(BA.ObjectToCharSequence(_oconversion._weight_grams2pounds /*float*/ (_value)));
 //BA.debugLineNum = 578;BA.debugLine="txtOZ.Text     = oConversion.weight_grams2oz(";
_txtoz.setText(BA.ObjectToCharSequence(_oconversion._weight_grams2oz /*float*/ (_value)));
 //BA.debugLineNum = 579;BA.debugLine="txtKG.Text     = oConversion.weight_grams2kg(";
_txtkg.setText(BA.ObjectToCharSequence(_oconversion._weight_grams2kg /*float*/ (_value)));
 break; }
case 3: {
 //BA.debugLineNum = 582;BA.debugLine="value = txtKG.Text";
_value = (float)(Double.parseDouble(_txtkg.getText()));
 //BA.debugLineNum = 583;BA.debugLine="txtPounds.Text = oConversion.weight_kg2pounds";
_txtpounds.setText(BA.ObjectToCharSequence(_oconversion._weight_kg2pounds /*float*/ (_value)));
 //BA.debugLineNum = 584;BA.debugLine="txtOZ.Text     = oConversion.weight_kg2oz(val";
_txtoz.setText(BA.ObjectToCharSequence(_oconversion._weight_kg2oz /*float*/ (_value)));
 //BA.debugLineNum = 585;BA.debugLine="txtGrams.Text  = oConversion.weight_kg2grams(";
_txtgrams.setText(BA.ObjectToCharSequence(_oconversion._weight_kg2grams /*float*/ (_value)));
 break; }
}
;
 break; }
case 3: {
 //BA.debugLineNum = 590;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txtc.getText().length()!=0 && (_txtc.getText().trim()).equals(".") == false,_txtf.getText().length()!=0 && (_txtf.getText().trim()).equals(".") == false)) {
case 0: {
 //BA.debugLineNum = 592;BA.debugLine="value = txtC.Text";
_value = (float)(Double.parseDouble(_txtc.getText()));
 //BA.debugLineNum = 593;BA.debugLine="txtF.Text = oConversion.temp_c2f(value)";
_txtf.setText(BA.ObjectToCharSequence(_oconversion._temp_c2f /*float*/ (_value)));
 break; }
case 1: {
 //BA.debugLineNum = 596;BA.debugLine="value = txtF.Text";
_value = (float)(Double.parseDouble(_txtf.getText()));
 //BA.debugLineNum = 597;BA.debugLine="txtC.Text = oConversion.temp_f2c(value)";
_txtc.setText(BA.ObjectToCharSequence(_oconversion._temp_f2c /*float*/ (_value)));
 break; }
}
;
 break; }
case 4: {
 //BA.debugLineNum = 602;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(__c.True,_txtmm.getText().length()!=0 && (_txtmm.getText().trim()).equals(".") == false,_txtcm.getText().length()!=0 && (_txtcm.getText().trim()).equals(".") == false,_txtinches.getText().length()!=0 && (_txtinches.getText().trim()).equals(".") == false)) {
case 0: {
 //BA.debugLineNum = 604;BA.debugLine="value = txtMM.Text";
_value = (float)(Double.parseDouble(_txtmm.getText()));
 //BA.debugLineNum = 605;BA.debugLine="txtCM.Text     = oConversion.length_mm2cm(val";
_txtcm.setText(BA.ObjectToCharSequence(_oconversion._length_mm2cm /*float*/ (_value)));
 //BA.debugLineNum = 606;BA.debugLine="txtInches.Text = oConversion.length_mm2inches";
_txtinches.setText(BA.ObjectToCharSequence(_oconversion._length_mm2inches /*float*/ (_value)));
 break; }
case 1: {
 //BA.debugLineNum = 609;BA.debugLine="value = txtCM.Text";
_value = (float)(Double.parseDouble(_txtcm.getText()));
 //BA.debugLineNum = 610;BA.debugLine="txtMM.Text     = oConversion.length_cm2mm(val";
_txtmm.setText(BA.ObjectToCharSequence(_oconversion._length_cm2mm /*float*/ (_value)));
 //BA.debugLineNum = 611;BA.debugLine="txtInches.Text = oConversion.length_cm2inches";
_txtinches.setText(BA.ObjectToCharSequence(_oconversion._length_cm2inches /*float*/ (_value)));
 break; }
case 2: {
 //BA.debugLineNum = 614;BA.debugLine="value = txtInches.Text";
_value = (float)(Double.parseDouble(_txtinches.getText()));
 //BA.debugLineNum = 615;BA.debugLine="txtMM.Text = oConversion.length_inches2mm(val";
_txtmm.setText(BA.ObjectToCharSequence(_oconversion._length_inches2mm /*float*/ (_value)));
 //BA.debugLineNum = 616;BA.debugLine="txtCM.Text = oConversion.length_inches2cm(val";
_txtcm.setText(BA.ObjectToCharSequence(_oconversion._length_inches2cm /*float*/ (_value)));
 break; }
}
;
 break; }
}
;
 //BA.debugLineNum = 623;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 59;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 60;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 61;BA.debugLine="p.LoadLayout(\"pageConversionsBase\")";
_p.LoadLayout("pageConversionsBase",ba);
 //BA.debugLineNum = 63;BA.debugLine="guiHelpers.SetPanelsTranparent(Array As B4XView(p";
_guihelpers._setpanelstranparent /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlbg.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlnumpad.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlinput.getObject()))});
 //BA.debugLineNum = 64;BA.debugLine="lblWhat.TextColor =clrTheme.txtNormal";
_lblwhat.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 66;BA.debugLine="guiHelpers.SkinButton(Array As Button(Button1,But";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_button1,_button2,_button3,_button4,_button5,_button6,_button7,_button8,_button9,_button10,_button11,_button12});
 //BA.debugLineNum = 69;BA.debugLine="guiHelpers.ResizeText(\"1\",Button1)";
_guihelpers._resizetext /*String*/ (ba,"1",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_button1.getObject())));
 //BA.debugLineNum = 70;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(Button1,B";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button2.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button3.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button4.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button6.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button7.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button8.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button9.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button10.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_button11.getObject()))},(float) ((_button1.getTextSize()-10)));
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.ResizeText(\"Calc\",Button12) : Button12";
_guihelpers._resizetext /*String*/ (ba,"Calc",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_button12.getObject())));
 //BA.debugLineNum = 72;BA.debugLine="guiHelpers.ResizeText(\"Calc\",Button12) : Button12";
_button12.setTextSize((float) (_button12.getTextSize()-6));
 //BA.debugLineNum = 73;BA.debugLine="oConversion.Initialize";
_oconversion._initialize /*String*/ (ba);
 //BA.debugLineNum = 74;BA.debugLine="Build_Side_Menu";
_build_side_menu();
 //BA.debugLineNum = 75;BA.debugLine="ActiveScrnLoad(scrnWeight) : txtOZ.RequestFocus";
_activescrnload(_scrnweight);
 //BA.debugLineNum = 75;BA.debugLine="ActiveScrnLoad(scrnWeight) : txtOZ.RequestFocus";
_txtoz.RequestFocus();
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public String  _lblc_click() throws Exception{
 //BA.debugLineNum = 295;BA.debugLine="Sub lblC_Click";
 //BA.debugLineNum = 296;BA.debugLine="txtC.RequestFocus";
_txtc.RequestFocus();
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return "";
}
public String  _lblcm_click() throws Exception{
 //BA.debugLineNum = 325;BA.debugLine="Sub lblCM_Click";
 //BA.debugLineNum = 326;BA.debugLine="txtCM.RequestFocus";
_txtcm.RequestFocus();
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return "";
}
public String  _lblcup_click() throws Exception{
 //BA.debugLineNum = 362;BA.debugLine="Sub lblCup_Click";
 //BA.debugLineNum = 363;BA.debugLine="txtCUP.RequestFocus";
_txtcup.RequestFocus();
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return "";
}
public String  _lblcupsb_click() throws Exception{
 //BA.debugLineNum = 638;BA.debugLine="Sub lblCUPSb_Click";
 //BA.debugLineNum = 639;BA.debugLine="txtCUPSb.RequestFocus";
_txtcupsb.RequestFocus();
 //BA.debugLineNum = 640;BA.debugLine="End Sub";
return "";
}
public String  _lblf_click() throws Exception{
 //BA.debugLineNum = 298;BA.debugLine="Sub lblF_Click";
 //BA.debugLineNum = 299;BA.debugLine="txtF.RequestFocus";
_txtf.RequestFocus();
 //BA.debugLineNum = 300;BA.debugLine="End Sub";
return "";
}
public String  _lblfloz_click() throws Exception{
 //BA.debugLineNum = 635;BA.debugLine="Sub lblFLOZ_Click";
 //BA.debugLineNum = 636;BA.debugLine="txtFlOZ.RequestFocus";
_txtfloz.RequestFocus();
 //BA.debugLineNum = 637;BA.debugLine="End Sub";
return "";
}
public String  _lblgal_click() throws Exception{
 //BA.debugLineNum = 650;BA.debugLine="Sub lblGAL_Click";
 //BA.debugLineNum = 651;BA.debugLine="txtGAL.RequestFocus";
_txtgal.RequestFocus();
 //BA.debugLineNum = 652;BA.debugLine="End Sub";
return "";
}
public String  _lblgrams_click() throws Exception{
 //BA.debugLineNum = 250;BA.debugLine="Sub lblGrams_Click";
 //BA.debugLineNum = 251;BA.debugLine="txtGrams.RequestFocus";
_txtgrams.RequestFocus();
 //BA.debugLineNum = 252;BA.debugLine="End Sub";
return "";
}
public String  _lblgramsb_click() throws Exception{
 //BA.debugLineNum = 365;BA.debugLine="Sub lblGramsB_Click";
 //BA.debugLineNum = 366;BA.debugLine="txtGramsB.RequestFocus";
_txtgramsb.RequestFocus();
 //BA.debugLineNum = 367;BA.debugLine="End Sub";
return "";
}
public String  _lblinches_click() throws Exception{
 //BA.debugLineNum = 322;BA.debugLine="Sub lblInches_Click";
 //BA.debugLineNum = 323;BA.debugLine="txtInches.RequestFocus";
_txtinches.RequestFocus();
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return "";
}
public String  _lblkg_click() throws Exception{
 //BA.debugLineNum = 247;BA.debugLine="Sub lblKG_Click";
 //BA.debugLineNum = 248;BA.debugLine="txtKG.RequestFocus";
_txtkg.RequestFocus();
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return "";
}
public String  _lblliters_click() throws Exception{
 //BA.debugLineNum = 647;BA.debugLine="Sub lblLiters_Click";
 //BA.debugLineNum = 648;BA.debugLine="txtLiters.RequestFocus";
_txtliters.RequestFocus();
 //BA.debugLineNum = 649;BA.debugLine="End Sub";
return "";
}
public String  _lblml_click() throws Exception{
 //BA.debugLineNum = 626;BA.debugLine="Sub lblML_Click";
 //BA.debugLineNum = 627;BA.debugLine="txtML.RequestFocus";
_txtml.RequestFocus();
 //BA.debugLineNum = 628;BA.debugLine="End Sub";
return "";
}
public String  _lblmm_click() throws Exception{
 //BA.debugLineNum = 328;BA.debugLine="Sub lblMM_Click";
 //BA.debugLineNum = 329;BA.debugLine="txtMM.RequestFocus";
_txtmm.RequestFocus();
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
return "";
}
public String  _lbloz_click() throws Exception{
 //BA.debugLineNum = 256;BA.debugLine="Sub lblOZ_Click";
 //BA.debugLineNum = 257;BA.debugLine="txtOZ.RequestFocus";
_txtoz.RequestFocus();
 //BA.debugLineNum = 258;BA.debugLine="End Sub";
return "";
}
public String  _lblozb_click() throws Exception{
 //BA.debugLineNum = 371;BA.debugLine="Sub lblOZb_Click";
 //BA.debugLineNum = 372;BA.debugLine="txtOZb.RequestFocus";
_txtozb.RequestFocus();
 //BA.debugLineNum = 373;BA.debugLine="End Sub";
return "";
}
public String  _lblpints_click() throws Exception{
 //BA.debugLineNum = 641;BA.debugLine="Sub lblPINTS_Click";
 //BA.debugLineNum = 642;BA.debugLine="txtPINTS.RequestFocus";
_txtpints.RequestFocus();
 //BA.debugLineNum = 643;BA.debugLine="End Sub";
return "";
}
public String  _lblpounds_click() throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Sub lblPounds_Click";
 //BA.debugLineNum = 254;BA.debugLine="txtPounds.RequestFocus";
_txtpounds.RequestFocus();
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return "";
}
public String  _lblquarts_click() throws Exception{
 //BA.debugLineNum = 644;BA.debugLine="Sub lblQuarts_Click";
 //BA.debugLineNum = 645;BA.debugLine="txtQuarts.RequestFocus";
_txtquarts.RequestFocus();
 //BA.debugLineNum = 646;BA.debugLine="End Sub";
return "";
}
public String  _lblstick_click() throws Exception{
 //BA.debugLineNum = 359;BA.debugLine="Sub lblStick_Click";
 //BA.debugLineNum = 360;BA.debugLine="txtStick.RequestFocus";
_txtstick.RequestFocus();
 //BA.debugLineNum = 361;BA.debugLine="End Sub";
return "";
}
public String  _lbltbsp_click() throws Exception{
 //BA.debugLineNum = 368;BA.debugLine="Sub lblTBSP_Click";
 //BA.debugLineNum = 369;BA.debugLine="txtTBSP.RequestFocus";
_txttbsp.RequestFocus();
 //BA.debugLineNum = 370;BA.debugLine="End Sub";
return "";
}
public String  _lbltbspb_click() throws Exception{
 //BA.debugLineNum = 632;BA.debugLine="Sub lblTBSPb_Click";
 //BA.debugLineNum = 633;BA.debugLine="txtTBSPb.RequestFocus";
_txttbspb.RequestFocus();
 //BA.debugLineNum = 634;BA.debugLine="End Sub";
return "";
}
public String  _lbltsp_click() throws Exception{
 //BA.debugLineNum = 629;BA.debugLine="Sub lblTSP_Click";
 //BA.debugLineNum = 630;BA.debugLine="txtTSP.RequestFocus";
_txttsp.RequestFocus();
 //BA.debugLineNum = 631;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 88;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _page_setup() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Private Sub Page_Setup";
 //BA.debugLineNum = 91;BA.debugLine="guiHelpers.Show_toast2(\"No setup for this page\",3";
_guihelpers._show_toast2 /*String*/ (ba,"No setup for this page",(int) (3500));
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 83;BA.debugLine="Menus.SetHeader(\"Conversions\",\"main_menu_conversi";
_menus._setheader /*String*/ (ba,"Conversions","main_menu_conversions.png");
 //BA.debugLineNum = 84;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 85;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public String  _sidemenu_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 210;BA.debugLine="Private Sub SideMenu_ItemClick (Index As Int, Valu";
 //BA.debugLineNum = 211;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 212;BA.debugLine="Select Case Value";
switch (BA.switchObjectToInt(_value,(Object)("we"),(Object)("vo"),(Object)("te"),(Object)("bu"),(Object)("le"))) {
case 0: {
 //BA.debugLineNum = 213;BA.debugLine="Case \"we\" : ActiveScrnLoad(scrnWeight)";
_activescrnload(_scrnweight);
 break; }
case 1: {
 //BA.debugLineNum = 214;BA.debugLine="Case \"vo\" : ActiveScrnLoad(scrnVolume	)";
_activescrnload(_scrnvolume);
 break; }
case 2: {
 //BA.debugLineNum = 215;BA.debugLine="Case \"te\" : ActiveScrnLoad(scrnTemp)";
_activescrnload(_scrntemp);
 break; }
case 3: {
 //BA.debugLineNum = 216;BA.debugLine="Case \"bu\" : ActiveScrnLoad(scrnButter)";
_activescrnload(_scrnbutter);
 break; }
case 4: {
 //BA.debugLineNum = 217;BA.debugLine="Case \"le\" : ActiveScrnLoad(scrnLength)";
_activescrnload(_scrnlength);
 break; }
}
;
 //BA.debugLineNum = 219;BA.debugLine="mpage.pnlSideMenu.SetVisibleAnimated(380, False)";
_mpage._pnlsidemenu /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public String  _txtc_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 301;BA.debugLine="Sub txtC_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 302;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 303;BA.debugLine="ClearTemp";
_cleartemp();
 //BA.debugLineNum = 304;BA.debugLine="curTxt = txtC";
_curtxt = _txtc;
 };
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return "";
}
public String  _txtcm_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 338;BA.debugLine="Sub txtCM_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 339;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 340;BA.debugLine="ClearLength";
_clearlength();
 //BA.debugLineNum = 341;BA.debugLine="curTxt = txtCM";
_curtxt = _txtcm;
 };
 //BA.debugLineNum = 343;BA.debugLine="End Sub";
return "";
}
public String  _txtcup_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 392;BA.debugLine="Sub txtCUP_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 393;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 394;BA.debugLine="ClearButter";
_clearbutter();
 //BA.debugLineNum = 395;BA.debugLine="curTxt = txtCUP";
_curtxt = _txtcup;
 };
 //BA.debugLineNum = 397;BA.debugLine="End Sub";
return "";
}
public String  _txtcupsb_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 683;BA.debugLine="Sub txtCUPSb_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 684;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 685;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 686;BA.debugLine="curTxt = txtCUPSb";
_curtxt = _txtcupsb;
 };
 //BA.debugLineNum = 688;BA.debugLine="End Sub";
return "";
}
public String  _txtf_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 307;BA.debugLine="Sub txtF_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 308;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 309;BA.debugLine="ClearTemp";
_cleartemp();
 //BA.debugLineNum = 310;BA.debugLine="curTxt = txtF";
_curtxt = _txtf;
 };
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
return "";
}
public String  _txtfloz_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 677;BA.debugLine="Sub txtFlOZ_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 678;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 679;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 680;BA.debugLine="curTxt = txtFlOZ";
_curtxt = _txtfloz;
 };
 //BA.debugLineNum = 682;BA.debugLine="End Sub";
return "";
}
public String  _txtgal_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 701;BA.debugLine="Sub txtGAL_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 702;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 703;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 704;BA.debugLine="curTxt = txtGAL";
_curtxt = _txtgal;
 };
 //BA.debugLineNum = 706;BA.debugLine="End Sub";
return "";
}
public String  _txtgrams_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 271;BA.debugLine="Sub txtGrams_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 272;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 273;BA.debugLine="ClearWeight";
_clearweight();
 //BA.debugLineNum = 274;BA.debugLine="curTxt = txtGrams";
_curtxt = _txtgrams;
 };
 //BA.debugLineNum = 276;BA.debugLine="End Sub";
return "";
}
public String  _txtgramsb_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 374;BA.debugLine="Sub txtGramsB_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 375;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 376;BA.debugLine="ClearButter";
_clearbutter();
 //BA.debugLineNum = 377;BA.debugLine="curTxt = txtGramsB";
_curtxt = _txtgramsb;
 };
 //BA.debugLineNum = 379;BA.debugLine="End Sub";
return "";
}
public String  _txtinches_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 332;BA.debugLine="Sub txtInches_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 333;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 334;BA.debugLine="ClearLength";
_clearlength();
 //BA.debugLineNum = 335;BA.debugLine="curTxt = txtInches";
_curtxt = _txtinches;
 };
 //BA.debugLineNum = 337;BA.debugLine="End Sub";
return "";
}
public String  _txtkg_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 277;BA.debugLine="Sub txtKG_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 278;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 279;BA.debugLine="ClearWeight";
_clearweight();
 //BA.debugLineNum = 280;BA.debugLine="curTxt = txtKG";
_curtxt = _txtkg;
 };
 //BA.debugLineNum = 282;BA.debugLine="End Sub";
return "";
}
public String  _txtliters_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 695;BA.debugLine="Sub txtLiters_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 696;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 697;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 698;BA.debugLine="curTxt = txtLiters";
_curtxt = _txtliters;
 };
 //BA.debugLineNum = 700;BA.debugLine="End Sub";
return "";
}
public String  _txtml_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 659;BA.debugLine="Sub txtML_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 660;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 661;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 662;BA.debugLine="curTxt = txtML";
_curtxt = _txtml;
 };
 //BA.debugLineNum = 664;BA.debugLine="End Sub";
return "";
}
public String  _txtmm_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 344;BA.debugLine="Sub txtMM_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 345;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 346;BA.debugLine="ClearLength";
_clearlength();
 //BA.debugLineNum = 347;BA.debugLine="curTxt = txtMM";
_curtxt = _txtmm;
 };
 //BA.debugLineNum = 349;BA.debugLine="End Sub";
return "";
}
public String  _txtoz_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 259;BA.debugLine="Sub txtOZ_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 260;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 261;BA.debugLine="ClearWeight";
_clearweight();
 //BA.debugLineNum = 262;BA.debugLine="curTxt = txtOZ";
_curtxt = _txtoz;
 };
 //BA.debugLineNum = 264;BA.debugLine="End Sub";
return "";
}
public String  _txtozb_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 386;BA.debugLine="Sub txtOZb_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 387;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 388;BA.debugLine="ClearButter";
_clearbutter();
 //BA.debugLineNum = 389;BA.debugLine="curTxt = txtOZb";
_curtxt = _txtozb;
 };
 //BA.debugLineNum = 391;BA.debugLine="End Sub";
return "";
}
public String  _txtpints_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 653;BA.debugLine="Sub txtPINTS_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 654;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 655;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 656;BA.debugLine="curTxt = txtPINTS";
_curtxt = _txtpints;
 };
 //BA.debugLineNum = 658;BA.debugLine="End Sub";
return "";
}
public String  _txtpounds_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 265;BA.debugLine="Sub txtPounds_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 266;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 267;BA.debugLine="ClearWeight";
_clearweight();
 //BA.debugLineNum = 268;BA.debugLine="curTxt = txtPounds";
_curtxt = _txtpounds;
 };
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return "";
}
public String  _txtquarts_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 689;BA.debugLine="Sub txtQuarts_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 690;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 691;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 692;BA.debugLine="curTxt = txtQuarts";
_curtxt = _txtquarts;
 };
 //BA.debugLineNum = 694;BA.debugLine="End Sub";
return "";
}
public String  _txtstick_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 398;BA.debugLine="Sub txtStick_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 399;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 400;BA.debugLine="ClearButter";
_clearbutter();
 //BA.debugLineNum = 401;BA.debugLine="curTxt = txtStick";
_curtxt = _txtstick;
 };
 //BA.debugLineNum = 403;BA.debugLine="End Sub";
return "";
}
public String  _txttbsp_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 380;BA.debugLine="Sub txtTBSP_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 381;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 382;BA.debugLine="ClearButter";
_clearbutter();
 //BA.debugLineNum = 383;BA.debugLine="curTxt = txtTBSP";
_curtxt = _txttbsp;
 };
 //BA.debugLineNum = 385;BA.debugLine="End Sub";
return "";
}
public String  _txttbspb_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 671;BA.debugLine="Sub txtTBSPb_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 672;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 673;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 674;BA.debugLine="curTxt = txtTBSPb";
_curtxt = _txttbspb;
 };
 //BA.debugLineNum = 676;BA.debugLine="End Sub";
return "";
}
public String  _txttsp_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 665;BA.debugLine="Sub txtTSP_FocusChanged (HasFocus As Boolean)";
 //BA.debugLineNum = 666;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 667;BA.debugLine="ClearVolume";
_clearvolume();
 //BA.debugLineNum = 668;BA.debugLine="curTxt = txtTSP";
_curtxt = _txttsp;
 };
 //BA.debugLineNum = 670;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SIDEMENU_ITEMCLICK"))
	return _sidemenu_itemclick(((Number)args[0]).intValue(), (Object) args[1]);
return BA.SubDelegator.SubNotFound;
}
}
