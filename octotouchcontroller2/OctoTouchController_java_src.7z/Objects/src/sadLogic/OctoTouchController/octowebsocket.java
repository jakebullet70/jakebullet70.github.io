package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class octowebsocket extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.octowebsocket");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.octowebsocket.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.WebSocketWrapper _wsocket = null;
public boolean _merrorsecprovider = false;
public String _pclosedreason = "";
public boolean _pconnected = false;
public boolean _isinit = false;
public boolean _mignoremasteroctoevent = false;
public sadLogic.OctoTouchController.websocketparse _pparserwo = null;
public String _psubscriptionmain = "";
public String _msesionname = "";
public String _msessionkey = "";
public boolean _mpassiveloginisbusy = false;
public int _msockettries = 0;
public boolean _isconnecting = false;
public String _mlastmsg = "";
public boolean _blastmessage = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Const mModule As String = \"OctoWebSocket\"";
_mmodule = "OctoWebSocket";
 //BA.debugLineNum = 8;BA.debugLine="Public wSocket As WebSocket";
_wsocket = new anywheresoftware.b4a.objects.WebSocketWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Public mErrorSecProvider As Boolean = False";
_merrorsecprovider = __c.False;
 //BA.debugLineNum = 10;BA.debugLine="Public pClosedReason As String";
_pclosedreason = "";
 //BA.debugLineNum = 11;BA.debugLine="Public pConnected As Boolean = False";
_pconnected = __c.False;
 //BA.debugLineNum = 13;BA.debugLine="Public IsInit As Boolean = False";
_isinit = __c.False;
 //BA.debugLineNum = 14;BA.debugLine="Public mIgnoreMasterOctoEvent As Boolean = True";
_mignoremasteroctoevent = __c.True;
 //BA.debugLineNum = 15;BA.debugLine="Public pParserWO As WebSocketParse";
_pparserwo = new sadLogic.OctoTouchController.websocketparse();
 //BA.debugLineNum = 16;BA.debugLine="Public pSubscriptionMain As String";
_psubscriptionmain = "";
 //BA.debugLineNum = 18;BA.debugLine="Private mSesionName As String = \"\"";
_msesionname = "";
 //BA.debugLineNum = 19;BA.debugLine="Private mSessionKey As String = \"\"";
_msessionkey = "";
 //BA.debugLineNum = 20;BA.debugLine="Private mPassiveLoginIsBusy As Boolean = False";
_mpassiveloginisbusy = __c.False;
 //BA.debugLineNum = 21;BA.debugLine="Private mSocketTries As Int = 0";
_msockettries = (int) (0);
 //BA.debugLineNum = 23;BA.debugLine="Private isConnecting As Boolean = False";
_isconnecting = __c.False;
 //BA.debugLineNum = 24;BA.debugLine="Public mlastMsg As String";
_mlastmsg = "";
 //BA.debugLineNum = 25;BA.debugLine="Public bLastMessage As Boolean = False";
_blastmessage = __c.False;
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _connect_socket() throws Exception{
ResumableSub_Connect_Socket rsub = new ResumableSub_Connect_Socket(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Connect_Socket extends BA.ResumableSub {
public ResumableSub_Connect_Socket(sadLogic.OctoTouchController.octowebsocket parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.octowebsocket parent;
String _insub = "";
String _txt = "";
String _message = "";
boolean _allgood = false;
int _ct = 0;
boolean _i = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 104;BA.debugLine="Dim Const inSub As String	= \"Connect\"";
_insub = "Connect";
 //BA.debugLineNum = 105;BA.debugLine="Dim txt As String";
_txt = "";
 //BA.debugLineNum = 107;BA.debugLine="Log(\"WS start: \" & mSocketTries)";
parent.__c.LogImpl("41943045","WS start: "+BA.NumberToString(parent._msockettries),0);
 //BA.debugLineNum = 108;BA.debugLine="mSocketTries = mSocketTries + 1";
parent._msockettries = (int) (parent._msockettries+1);
 //BA.debugLineNum = 110;BA.debugLine="If isConnecting = True Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._isconnecting==parent.__c.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 111;BA.debugLine="txt = \"WS already trying to connect\"";
_txt = "WS already trying to connect";
 //BA.debugLineNum = 112;BA.debugLine="logMe.logit2(txt,mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),_txt,parent._mmodule,_insub);
 //BA.debugLineNum = 113;BA.debugLine="Return txt";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_txt));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 115;BA.debugLine="isConnecting = True";
parent._isconnecting = parent.__c.True;
 //BA.debugLineNum = 117;BA.debugLine="Try";
if (true) break;

case 5:
//try
this.state = 14;
this.catchState = 13;
this.state = 7;
if (true) break;

case 7:
//C
this.state = 8;
this.catchState = 13;
 //BA.debugLineNum = 118;BA.debugLine="If wSocket.Connected Then";
if (true) break;

case 8:
//if
this.state = 11;
if (parent._wsocket.getConnected()) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 119;BA.debugLine="isConnecting = False";
parent._isconnecting = parent.__c.False;
 //BA.debugLineNum = 120;BA.debugLine="txt = \"WS is already connected\"";
_txt = "WS is already connected";
 //BA.debugLineNum = 121;BA.debugLine="logMe.logit2(txt,mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),_txt,parent._mmodule,_insub);
 //BA.debugLineNum = 122;BA.debugLine="Return txt";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_txt));return;};
 if (true) break;

case 11:
//C
this.state = 14;
;
 if (true) break;

case 13:
//C
this.state = 14;
this.catchState = 0;
 if (true) break;
if (true) break;

case 14:
//C
this.state = 15;
this.catchState = 0;
;
 //BA.debugLineNum = 128;BA.debugLine="logMe.LogIt2(\"WS connecting...\",mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"WS connecting...",parent._mmodule,_insub);
 //BA.debugLineNum = 129;BA.debugLine="pConnected = False '--- assume bad";
parent._pconnected = parent.__c.False;
 //BA.debugLineNum = 132;BA.debugLine="wSocket.Initialize(\"ws\")";
parent._wsocket.Initialize(ba,"ws");
 //BA.debugLineNum = 133;BA.debugLine="wSocket.Connect($\"ws://${oc.OctoIp}:${oc.OctoPort";
parent._wsocket.Connect(("ws://"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoip /*String*/ ))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octoport /*String*/ ))+"/sockjs/websocket?apikey="+parent.__c.SmartStringFormatter("",(Object)(parent._oc._octokey /*String*/ ))+""));
 //BA.debugLineNum = 134;BA.debugLine="Wait For ws_Connected";
parent.__c.WaitFor("ws_connected", ba, this, null);
this.state = 26;
return;
case 26:
//C
this.state = 15;
;
 //BA.debugLineNum = 135;BA.debugLine="logMe.LogIt2(\"WS connected...\",mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"WS connected...",parent._mmodule,_insub);
 //BA.debugLineNum = 136;BA.debugLine="pConnected = True";
parent._pconnected = parent.__c.True;
 //BA.debugLineNum = 137;BA.debugLine="Wait For ws_TextMessage (Message As String)";
parent.__c.WaitFor("ws_textmessage", ba, this, null);
this.state = 27;
return;
case 27:
//C
this.state = 15;
_message = (String) result[0];
;
 //BA.debugLineNum = 139;BA.debugLine="SetSubscription(pSubscriptionMain)";
parent._setsubscription(parent._psubscriptionmain);
 //BA.debugLineNum = 142;BA.debugLine="Dim allGood As Boolean = False, ct As Int = 0";
_allgood = parent.__c.False;
_ct = (int) (0);
 //BA.debugLineNum = 143;BA.debugLine="Do While ct < 4";
if (true) break;

case 15:
//do while
this.state = 25;
while (_ct<4) {
this.state = 17;
if (true) break;
}
if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 145;BA.debugLine="ct = ct + 1";
_ct = (int) (_ct+1);
 //BA.debugLineNum = 146;BA.debugLine="Log(\"calling passive login: \" & ct)";
parent.__c.LogImpl("41943084","calling passive login: "+BA.NumberToString(_ct),0);
 //BA.debugLineNum = 147;BA.debugLine="Wait For (Passive_Login) Complete(i As Boolean)";
parent.__c.WaitFor("complete", ba, this, parent._passive_login());
this.state = 28;
return;
case 28:
//C
this.state = 18;
_i = (Boolean) result[0];
;
 //BA.debugLineNum = 148;BA.debugLine="allGood = i";
_allgood = _i;
 //BA.debugLineNum = 149;BA.debugLine="Log(\"Passive login OK=\" & i.As(String))";
parent.__c.LogImpl("41943087","Passive login OK="+(BA.ObjectToString(_i)),0);
 //BA.debugLineNum = 150;BA.debugLine="If i Then";
if (true) break;

case 18:
//if
this.state = 21;
if (_i) { 
this.state = 20;
}if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 151;BA.debugLine="Message = \"WS socket passive login: OK\"";
_message = "WS socket passive login: OK";
 //BA.debugLineNum = 152;BA.debugLine="Exit";
this.state = 25;
if (true) break;
 if (true) break;
;
 //BA.debugLineNum = 154;BA.debugLine="If mSocketTries > 3 Then";

case 21:
//if
this.state = 24;
if (parent._msockettries>3) { 
this.state = 23;
}if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 155;BA.debugLine="Message = \"WS socket failed with passive login\"";
_message = "WS socket failed with passive login";
 //BA.debugLineNum = 156;BA.debugLine="Exit '--- failure";
this.state = 25;
if (true) break;
 if (true) break;

case 24:
//C
this.state = 15;
;
 //BA.debugLineNum = 158;BA.debugLine="Sleep(1200)";
parent.__c.Sleep(ba,this,(int) (1200));
this.state = 29;
return;
case 29:
//C
this.state = 15;
;
 if (true) break;

case 25:
//C
this.state = -1;
;
 //BA.debugLineNum = 164;BA.debugLine="setThrottle(\"90\") '--- this is very inacurate";
parent._setthrottle("90");
 //BA.debugLineNum = 165;BA.debugLine="isConnecting = False";
parent._isconnecting = parent.__c.False;
 //BA.debugLineNum = 166;BA.debugLine="pConnected = allGood";
parent._pconnected = _allgood;
 //BA.debugLineNum = 167;BA.debugLine="Log(\"wb init end: \" & Message)";
parent.__c.LogImpl("41943105","wb init end: "+_message,0);
 //BA.debugLineNum = 168;BA.debugLine="Return Message '--- this is the connected message";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_message));return;};
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _ws_connected() throws Exception{
}
public void  _complete(boolean _i) throws Exception{
}
public String  _disablestrictmode() throws Exception{
String _insub = "";
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _policy = null;
anywheresoftware.b4j.object.JavaObject _sm = null;
 //BA.debugLineNum = 49;BA.debugLine="Private Sub DisableStrictMode";
 //BA.debugLineNum = 50;BA.debugLine="Dim InSub As String = \"DisableStrictMode\"";
_insub = "DisableStrictMode";
 //BA.debugLineNum = 51;BA.debugLine="logMe.LogIt2(\"Start\",mModule,InSub)";
_logme._logit2 /*String*/ (getActivityBA(),"Start",_mmodule,_insub);
 //BA.debugLineNum = 52;BA.debugLine="Dim jo As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 53;BA.debugLine="jo.InitializeStatic(\"android.os.Build.VERSION\")";
_jo.InitializeStatic("android.os.Build.VERSION");
 //BA.debugLineNum = 54;BA.debugLine="If jo.GetField(\"SDK_INT\") > 9 Then";
if ((double)(BA.ObjectToNumber(_jo.GetField("SDK_INT")))>9) { 
 //BA.debugLineNum = 55;BA.debugLine="Dim policy As JavaObject";
_policy = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 56;BA.debugLine="policy = policy.InitializeNewInstance(\"android.o";
_policy = _policy.InitializeNewInstance("android.os.StrictMode.ThreadPolicy.Builder",(Object[])(__c.Null));
 //BA.debugLineNum = 57;BA.debugLine="policy = policy.RunMethodJO(\"permitAll\", Null).R";
_policy = _policy.RunMethodJO("permitAll",(Object[])(__c.Null)).RunMethodJO("build",(Object[])(__c.Null));
 //BA.debugLineNum = 58;BA.debugLine="Dim sm As JavaObject";
_sm = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 59;BA.debugLine="sm.InitializeStatic(\"android.os.StrictMode\").Run";
_sm.InitializeStatic("android.os.StrictMode").RunMethod("setThreadPolicy",new Object[]{(Object)(_policy.getObject())});
 //BA.debugLineNum = 60;BA.debugLine="logMe.LogIt2(\"Done\",mModule,InSub)";
_logme._logit2 /*String*/ (getActivityBA(),"Done",_mmodule,_insub);
 }else {
 //BA.debugLineNum = 62;BA.debugLine="logMe.LogIt2(\"Skipped < Android 9\",mModule,InSub";
_logme._logit2 /*String*/ (getActivityBA(),"Skipped < Android 9",_mmodule,_insub);
 };
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public sadLogic.OctoTouchController.octowebsocket  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Initialize() As OctoWebSocket";
 //BA.debugLineNum = 35;BA.debugLine="pParserWO.Initialize";
_pparserwo._initialize /*String*/ (ba);
 //BA.debugLineNum = 37;BA.debugLine="pSubscriptionMain  = $\"{\"subscribe\": { 				  \"sta";
_psubscriptionmain = ("{\"subscribe\": {\n"+"				  \"state\": {\n"+"			      \"logs\": false,\n"+"			      \"messages\": true},\n"+"			      \"events\": true,\n"+"				  \"plugins\": [\"OctoKlipper\",\"klipper\"]\n"+"				  }}");
 //BA.debugLineNum = 45;BA.debugLine="IsInit = True";
_isinit = __c.True;
 //BA.debugLineNum = 46;BA.debugLine="Return Me";
if (true) return (sadLogic.OctoTouchController.octowebsocket)(this);
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _passive_login() throws Exception{
ResumableSub_Passive_Login rsub = new ResumableSub_Passive_Login(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Passive_Login extends BA.ResumableSub {
public ResumableSub_Passive_Login(sadLogic.OctoTouchController.octowebsocket parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.octowebsocket parent;
String _insub = "";
String _sendme = "";
String _r = "";
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 174;BA.debugLine="Dim Const inSub As String = \"Passive_Login\"";
_insub = "Passive_Login";
 //BA.debugLineNum = 175;BA.debugLine="Dim sendMe As String";
_sendme = "";
 //BA.debugLineNum = 177;BA.debugLine="If mPassiveLoginIsBusy Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._mpassiveloginisbusy) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 178;BA.debugLine="logMe.LogIt2(\"mPassiveLoginIsBusy=true\",mModule,";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"mPassiveLoginIsBusy=true",parent._mmodule,_insub);
 //BA.debugLineNum = 179;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 181;BA.debugLine="mPassiveLoginIsBusy = True";
parent._mpassiveloginisbusy = parent.__c.True;
 //BA.debugLineNum = 185;BA.debugLine="logMe.logit2(\"Passive_Login start\",mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Passive_Login start",parent._mmodule,_insub);
 //BA.debugLineNum = 188;BA.debugLine="If mSessionKey.Length <> 0 Then";
if (true) break;

case 5:
//if
this.state = 20;
if (parent._msessionkey.length()!=0) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 189;BA.debugLine="Log(\"**********RE-USE************\")";
parent.__c.LogImpl("42008592","**********RE-USE************",0);
 //BA.debugLineNum = 190;BA.debugLine="Log(\"name:\" & mSesionName)";
parent.__c.LogImpl("42008593","name:"+parent._msesionname,0);
 //BA.debugLineNum = 191;BA.debugLine="Log(\"session:\" & mSessionKey)";
parent.__c.LogImpl("42008594","session:"+parent._msessionkey,0);
 //BA.debugLineNum = 192;BA.debugLine="Log(\"****************************\")";
parent.__c.LogImpl("42008595","****************************",0);
 //BA.debugLineNum = 193;BA.debugLine="sendMe = $\"{\"auth\": \"${mSesionName}:${mSessionKe";
_sendme = ("{\"auth\": \""+parent.__c.SmartStringFormatter("",(Object)(parent._msesionname))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._msessionkey))+"\"}");
 //BA.debugLineNum = 194;BA.debugLine="Wait For (SendAndWait(sendMe)) Complete (r As St";
parent.__c.WaitFor("complete", ba, this, parent._sendandwait(_sendme));
this.state = 29;
return;
case 29:
//C
this.state = 8;
_r = (String) result[0];
;
 //BA.debugLineNum = 195;BA.debugLine="Log(\"Passive_Login ret val1: \" & r)";
parent.__c.LogImpl("42008598","Passive_Login ret val1: "+_r,0);
 //BA.debugLineNum = 196;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 197;BA.debugLine="If r.Contains(\"reauthReq\") Then '--- this has ha";
if (true) break;

case 8:
//if
this.state = 11;
if (_r.contains("reauthReq")) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 198;BA.debugLine="guiHelpers.Show_toast2(\"Auth Err! Restatrt App\"";
parent._guihelpers._show_toast2 /*String*/ (parent.getActivityBA(),"Auth Err! Restatrt App",(int) (15000));
 //BA.debugLineNum = 199;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 200;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 202;BA.debugLine="If r.Contains(\"no connection\") Then";

case 11:
//if
this.state = 14;
if (_r.contains("no connection")) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 203;BA.debugLine="mSesionName = \"\" : mSessionKey = \"\"";
parent._msesionname = "";
 //BA.debugLineNum = 203;BA.debugLine="mSesionName = \"\" : mSessionKey = \"\"";
parent._msessionkey = "";
 //BA.debugLineNum = 204;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 205;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 207;BA.debugLine="If oc.Klippy And r.StartsWith($\"{\"plugin\"$) Then";

case 14:
//if
this.state = 19;
if (parent._oc._klippy /*boolean*/  && _r.startsWith(("{\"plugin"))) { 
this.state = 16;
;}if (true) break;

case 16:
//C
this.state = 19;
parent._ws_textmessage(_r);
if (true) break;

case 19:
//C
this.state = 20;
;
 //BA.debugLineNum = 208;BA.debugLine="mSocketTries = 0";
parent._msockettries = (int) (0);
 //BA.debugLineNum = 209;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 210;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 214;BA.debugLine="Wait For (B4XPages.MainPage.oMasterController.CN.";
parent.__c.WaitFor("complete", ba, this, parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (parent.getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (("/api/login!!{ \"passive\": \"true\" }")));
this.state = 30;
return;
case 30:
//C
this.state = 21;
_r = (String) result[0];
;
 //BA.debugLineNum = 215;BA.debugLine="If strHelpers.IsNullOrEmpty(r) Then";
if (true) break;

case 21:
//if
this.state = 24;
if (parent._strhelpers._isnullorempty /*boolean*/ (parent.getActivityBA(),_r)) { 
this.state = 23;
}if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 216;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 217;BA.debugLine="logMe.logit2(\"/api/login is empty\",mModule,inSub";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"/api/login is empty",parent._mmodule,_insub);
 //BA.debugLineNum = 218;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 24:
//C
this.state = 25;
;
 //BA.debugLineNum = 221;BA.debugLine="Dim parser As JSONParser : parser.Initialize(r) :";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 221;BA.debugLine="Dim parser As JSONParser : parser.Initialize(r) :";
_parser.Initialize(_r);
 //BA.debugLineNum = 221;BA.debugLine="Dim parser As JSONParser : parser.Initialize(r) :";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 222;BA.debugLine="mSesionName = root.Get(\"name\")";
parent._msesionname = BA.ObjectToString(_root.Get((Object)("name")));
 //BA.debugLineNum = 223;BA.debugLine="mSessionKey = root.Get(\"session\")";
parent._msessionkey = BA.ObjectToString(_root.Get((Object)("session")));
 //BA.debugLineNum = 224;BA.debugLine="sendMe = $\"{\"auth\": \"${mSessionKey}:${mSessionKey";
_sendme = ("{\"auth\": \""+parent.__c.SmartStringFormatter("",(Object)(parent._msessionkey))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._msessionkey))+"\"}");
 //BA.debugLineNum = 225;BA.debugLine="Log(\"*************NEW************\")";
parent.__c.LogImpl("42008628","*************NEW************",0);
 //BA.debugLineNum = 226;BA.debugLine="Log(\"name:\" & mSesionName)";
parent.__c.LogImpl("42008629","name:"+parent._msesionname,0);
 //BA.debugLineNum = 227;BA.debugLine="Log(\"session:\" & mSessionKey)";
parent.__c.LogImpl("42008630","session:"+parent._msessionkey,0);
 //BA.debugLineNum = 228;BA.debugLine="Log(\"****************************\")";
parent.__c.LogImpl("42008631","****************************",0);
 //BA.debugLineNum = 229;BA.debugLine="Wait For (SendAndWait(sendMe)) Complete (r As Str";
parent.__c.WaitFor("complete", ba, this, parent._sendandwait(_sendme));
this.state = 31;
return;
case 31:
//C
this.state = 25;
_r = (String) result[0];
;
 //BA.debugLineNum = 230;BA.debugLine="logMe.logit2(\"Passive_Login ret val2: \" & r,mModu";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Passive_Login ret val2: "+_r,parent._mmodule,_insub);
 //BA.debugLineNum = 232;BA.debugLine="logMe.logit2(\"Passive_Login Auth end\",mModule,inS";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Passive_Login Auth end",parent._mmodule,_insub);
 //BA.debugLineNum = 233;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 234;BA.debugLine="If r.Contains(\"reauthReq\") Then";
if (true) break;

case 25:
//if
this.state = 28;
if (_r.contains("reauthReq")) { 
this.state = 27;
}if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 235;BA.debugLine="logMe.logit2(\"reauthReq=true\",mModule,inSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"reauthReq=true",parent._mmodule,_insub);
 //BA.debugLineNum = 237;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 238;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 28:
//C
this.state = -1;
;
 //BA.debugLineNum = 240;BA.debugLine="mSocketTries = 0";
parent._msockettries = (int) (0);
 //BA.debugLineNum = 241;BA.debugLine="mPassiveLoginIsBusy = False";
parent._mpassiveloginisbusy = parent.__c.False;
 //BA.debugLineNum = 242;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _providerinstall() throws Exception{
ResumableSub_ProviderInstall rsub = new ResumableSub_ProviderInstall(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ProviderInstall extends BA.ResumableSub {
public ResumableSub_ProviderInstall(sadLogic.OctoTouchController.octowebsocket parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.octowebsocket parent;
String _insub = "";
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _context = null;
Object _listener = null;
String _methodname = "";
Object[] _args = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 67;BA.debugLine="Dim InSub As String = \"ProviderInstall\"";
_insub = "ProviderInstall";
 //BA.debugLineNum = 68;BA.debugLine="logMe.LogIt2(\"Start\",mModule,InSub)";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Start",parent._mmodule,_insub);
 //BA.debugLineNum = 72;BA.debugLine="Dim jo As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 73;BA.debugLine="jo.InitializeStatic(\"com.google.android.gms.secur";
_jo.InitializeStatic("com.google.android.gms.security.ProviderInstaller");
 //BA.debugLineNum = 74;BA.debugLine="Dim context As JavaObject";
_context = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 75;BA.debugLine="context.InitializeContext";
_context.InitializeContext(ba);
 //BA.debugLineNum = 76;BA.debugLine="DisableStrictMode";
parent._disablestrictmode();
 //BA.debugLineNum = 77;BA.debugLine="Dim listener As Object = _ 		jo.CreateEventFromUI";
_listener = _jo.CreateEventFromUI(ba,"com.google.android.gms.security.ProviderInstaller.ProviderInstallListener","listener",parent.__c.Null);
 //BA.debugLineNum = 79;BA.debugLine="Log(\"Installing security provider if needed...\")";
parent.__c.LogImpl("41811981","Installing security provider if needed...",0);
 //BA.debugLineNum = 80;BA.debugLine="jo.RunMethod(\"installIfNeededAsync\", Array(contex";
_jo.RunMethod("installIfNeededAsync",new Object[]{(Object)(_context.getObject()),_listener});
 //BA.debugLineNum = 81;BA.debugLine="Wait For listener_Event (MethodName As String, Ar";
parent.__c.WaitFor("listener_event", ba, this, null);
this.state = 7;
return;
case 7:
//C
this.state = 1;
_methodname = (String) result[0];
_args = (Object[]) result[1];
;
 //BA.debugLineNum = 82;BA.debugLine="If MethodName = \"onProviderInstalled\" Then";
if (true) break;

case 1:
//if
this.state = 6;
if ((_methodname).equals("onProviderInstalled")) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 83;BA.debugLine="logMe.LogIt2(\"Provider installed successfully\",m";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Provider installed successfully",parent._mmodule,_insub);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 85;BA.debugLine="logMe.LogIt2(\"Error installing provider: \" & Arg";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"Error installing provider: "+BA.ObjectToString(_args[(int) (0)]),parent._mmodule,_insub);
 //BA.debugLineNum = 86;BA.debugLine="mErrorSecProvider = True";
parent._merrorsecprovider = parent.__c.True;
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 88;BA.debugLine="Return mErrorSecProvider";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent._merrorsecprovider));return;};
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _listener_event(String _methodname,Object[] _args) throws Exception{
}
public void  _send(String _cmd) throws Exception{
ResumableSub_Send rsub = new ResumableSub_Send(this,_cmd);
rsub.resume(ba, null);
}
public static class ResumableSub_Send extends BA.ResumableSub {
public ResumableSub_Send(sadLogic.OctoTouchController.octowebsocket parent,String _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
sadLogic.OctoTouchController.octowebsocket parent;
String _cmd;
String _msg = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 332;BA.debugLine="If pConnected = False Then";
if (true) break;

case 1:
//if
this.state = 10;
if (parent._pconnected==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 333;BA.debugLine="logMe.LogIt2(\"no web socket connection - reconne";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"no web socket connection - reconnecting",parent._mmodule,"Send");
 //BA.debugLineNum = 334;BA.debugLine="Wait For (Connect_Socket) Complete (msg As Strin";
parent.__c.WaitFor("complete", ba, this, parent._connect_socket());
this.state = 11;
return;
case 11:
//C
this.state = 4;
_msg = (String) result[0];
;
 //BA.debugLineNum = 335;BA.debugLine="If pConnected = False Then Return";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._pconnected==parent.__c.False) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
if (true) return ;
if (true) break;

case 9:
//C
this.state = 10;
;
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 337;BA.debugLine="wSocket.SendText(cmd)";
parent._wsocket.SendText(_cmd);
 //BA.debugLineNum = 338;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendandwait(String _cmd) throws Exception{
ResumableSub_SendAndWait rsub = new ResumableSub_SendAndWait(this,_cmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendAndWait extends BA.ResumableSub {
public ResumableSub_SendAndWait(sadLogic.OctoTouchController.octowebsocket parent,String _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
sadLogic.OctoTouchController.octowebsocket parent;
String _cmd;
String _msg = "";
String _message = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 342;BA.debugLine="If pConnected = False Then";
if (true) break;

case 1:
//if
this.state = 10;
if (parent._pconnected==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 343;BA.debugLine="logMe.LogIt2(\"no web socket connection - reconne";
parent._logme._logit2 /*String*/ (parent.getActivityBA(),"no web socket connection - reconnecting",parent._mmodule,"SendAndWait");
 //BA.debugLineNum = 344;BA.debugLine="Wait For (Connect_Socket) Complete (msg As Strin";
parent.__c.WaitFor("complete", ba, this, parent._connect_socket());
this.state = 11;
return;
case 11:
//C
this.state = 4;
_msg = (String) result[0];
;
 //BA.debugLineNum = 345;BA.debugLine="If pConnected = False Then Return \"no connection";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._pconnected==parent.__c.False) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)("no connection"));return;};
if (true) break;

case 9:
//C
this.state = 10;
;
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 348;BA.debugLine="wSocket.SendText(cmd)";
parent._wsocket.SendText(_cmd);
 //BA.debugLineNum = 349;BA.debugLine="Wait For ws_TextMessage (Message As String)";
parent.__c.WaitFor("ws_textmessage", ba, this, null);
this.state = 12;
return;
case 12:
//C
this.state = -1;
_message = (String) result[0];
;
 //BA.debugLineNum = 350;BA.debugLine="Return Message";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_message));return;};
 //BA.debugLineNum = 351;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _setsubscription(String _s) throws Exception{
 //BA.debugLineNum = 98;BA.debugLine="Public Sub SetSubscription(s As String)";
 //BA.debugLineNum = 99;BA.debugLine="Send(s)";
_send(_s);
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public String  _setthrottle(String _num) throws Exception{
 //BA.debugLineNum = 246;BA.debugLine="Public Sub setThrottle(num As String)";
 //BA.debugLineNum = 247;BA.debugLine="Send($\"{\"throttle\": ${num}}\"$)";
_send(("{\"throttle\": "+__c.SmartStringFormatter("",(Object)(_num))+"}"));
 //BA.debugLineNum = 248;BA.debugLine="If config.logREST_API Then logMe.logit2(\"WebSocke";
if (_config._logrest_api /*boolean*/ ) { 
_logme._logit2 /*String*/ (getActivityBA(),"WebSocket throttle: "+_num,_mmodule,"setThrottle");};
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return "";
}
public String  _ws_closed(String _reason) throws Exception{
String _insub = "";
String _msg = "";
 //BA.debugLineNum = 290;BA.debugLine="Private Sub ws_Closed (Reason As String)";
 //BA.debugLineNum = 292;BA.debugLine="Dim InSub As String = \"ws_Closed\"";
_insub = "ws_Closed";
 //BA.debugLineNum = 293;BA.debugLine="Dim msg As String = \"\"";
_msg = "";
 //BA.debugLineNum = 294;BA.debugLine="pConnected = False";
_pconnected = __c.False;
 //BA.debugLineNum = 295;BA.debugLine="pClosedReason = \"\"";
_pclosedreason = "";
 //BA.debugLineNum = 296;BA.debugLine="If strHelpers.IsNullOrEmpty(Reason) Then";
if (_strhelpers._isnullorempty /*boolean*/ (getActivityBA(),_reason)) { 
 //BA.debugLineNum = 297;BA.debugLine="Reason = \"Sys closed\"";
_reason = "Sys closed";
 }else {
 //BA.debugLineNum = 299;BA.debugLine="logMe.LogIt2(\"ws close reason: \" & Reason,mModul";
_logme._logit2 /*String*/ (getActivityBA(),"ws close reason: "+_reason,_mmodule,_insub);
 };
 //BA.debugLineNum = 301;BA.debugLine="pClosedReason = Reason";
_pclosedreason = _reason;
 //BA.debugLineNum = 304;BA.debugLine="If Reason = \"WebSockets connection lost\" Then";
if ((_reason).equals("WebSockets connection lost")) { 
 //BA.debugLineNum = 305;BA.debugLine="logMe.LogIt2(\"reconnecting - WS lost: \"  & Reaso";
_logme._logit2 /*String*/ (getActivityBA(),"reconnecting - WS lost: "+_reason,_mmodule,_insub);
 //BA.debugLineNum = 306;BA.debugLine="guiHelpers.Show_toast2(\"(Re)Connecting WebSocket";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),"(Re)Connecting WebSocket...",(int) (2000));
 //BA.debugLineNum = 307;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Conn";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"Connect_socket",(int) (800));
 }else if((_reason).equals("WebSockets protocol violation")) { 
 //BA.debugLineNum = 311;BA.debugLine="wSocket.Close";
_wsocket.Close();
 //BA.debugLineNum = 312;BA.debugLine="If mSocketTries > 3 Then";
if (_msockettries>3) { 
 //BA.debugLineNum = 313;BA.debugLine="msg = \"WebSockets protocol violation. Restart O";
_msg = "WebSockets protocol violation. Restart Octoprint and App";
 //BA.debugLineNum = 314;BA.debugLine="logMe.LogIt2(msg,mModule,InSub)";
_logme._logit2 /*String*/ (getActivityBA(),_msg,_mmodule,_insub);
 //BA.debugLineNum = 315;BA.debugLine="guiHelpers.Show_toast2(msg,15000)";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),_msg,(int) (15000));
 }else {
 //BA.debugLineNum = 317;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Con";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"Connect_socket",(int) (800));
 };
 }else {
 //BA.debugLineNum = 321;BA.debugLine="If Main.isAppClosing Or Reason = \"Sys closed\" Th";
if (_main._isappclosing /*boolean*/  || (_reason).equals("Sys closed")) { 
if (true) return "";};
 //BA.debugLineNum = 322;BA.debugLine="msg =\"Restart Octoprint: Error: \" & pClosedReaso";
_msg = "Restart Octoprint: Error: "+_pclosedreason;
 //BA.debugLineNum = 323;BA.debugLine="guiHelpers.Show_toast2(msg ,15000)";
_guihelpers._show_toast2 /*String*/ (getActivityBA(),_msg,(int) (15000));
 //BA.debugLineNum = 324;BA.debugLine="Log(\"WS error: \" & msg)";
__c.LogImpl("42205218","WS error: "+_msg,0);
 //BA.debugLineNum = 325;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"CallSetupErro";
__c.CallSubDelayed2(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())),"CallSetupErrorConnecting",(Object)(__c.False));
 };
 //BA.debugLineNum = 328;BA.debugLine="End Sub";
return "";
}
public String  _ws_textmessage(String _message) throws Exception{
 //BA.debugLineNum = 252;BA.debugLine="Private Sub ws_TextMessage(Message As String)";
 //BA.debugLineNum = 261;BA.debugLine="If Message.StartsWith($\"{\"event\": {\"\"$) Then";
if (_message.startsWith(("{\"event\": {\""))) { 
 //BA.debugLineNum = 262;BA.debugLine="CallSub2(pParserWO,\"Event_Parse\",Message)";
__c.CallSubNew2(ba,(Object)(_pparserwo),"Event_Parse",(Object)(_message));
 //BA.debugLineNum = 263;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 266;BA.debugLine="If oc.Klippy And Message.StartsWith($\"{\"plugin\":";
if (_oc._klippy /*boolean*/  && _message.startsWith(("{\"plugin\": {\"plugin\": \"klipper\""))) { 
 //BA.debugLineNum = 267;BA.debugLine="CallSub2(pParserWO,\"Klippy_Parse\",Message)";
__c.CallSubNew2(ba,(Object)(_pparserwo),"Klippy_Parse",(Object)(_message));
 //BA.debugLineNum = 268;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 271;BA.debugLine="If Message.StartsWith($\"{\"plugin\": {\"\"$) Then";
if (_message.startsWith(("{\"plugin\": {\""))) { 
 //BA.debugLineNum = 273;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 276;BA.debugLine="If pParserWO.pMsgs2Monitor.Size <> 0 Then '--- ms";
if (_pparserwo._pmsgs2monitor /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()!=0) { 
 //BA.debugLineNum = 277;BA.debugLine="CallSub2(pParserWO,\"Msgs_Parse\",Message)";
__c.CallSubNew2(ba,(Object)(_pparserwo),"Msgs_Parse",(Object)(_message));
 //BA.debugLineNum = 278;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 281;BA.debugLine="If Message.StartsWith($\"{\"reauthRequired\"\"$) Then";
if (_message.startsWith(("{\"reauthRequired\""))) { 
 //BA.debugLineNum = 282;BA.debugLine="logMe.LogIt(\"reauthRequired type: \" & Message,mM";
_logme._logit /*String*/ (getActivityBA(),"reauthRequired type: "+_message,_mmodule);
 //BA.debugLineNum = 283;BA.debugLine="Passive_Login";
_passive_login();
 //BA.debugLineNum = 284;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 287;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
