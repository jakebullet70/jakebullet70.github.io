package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class powerhelpers {
private static powerhelpers mostCurrent = new powerhelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _mmodule = "";
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.phone.Phone.PhoneWakeState _pws = null;
public static anywheresoftware.b4a.phone.Phone _ph = null;
public static float _pscreenbrightness = 0f;
public static float _auto_brightness = 0f;
public static String _screen_brightness_file = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static float  _getscreenbrightness(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.agraham.reflection.Reflection _ref = null;
float _brightness = 0f;
 //BA.debugLineNum = 135;BA.debugLine="Public Sub GetScreenBrightness() As Float";
 //BA.debugLineNum = 139;BA.debugLine="Dim ref As Reflector";
_ref = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 140;BA.debugLine="ref.Target = ref.GetActivity";
_ref.Target = (Object)(_ref.GetActivity((_ba.processBA == null ? _ba : _ba.processBA)));
 //BA.debugLineNum = 141;BA.debugLine="ref.Target = ref.RunMethod(\"getWindow\")";
_ref.Target = _ref.RunMethod("getWindow");
 //BA.debugLineNum = 142;BA.debugLine="ref.Target = ref.RunMethod(\"getAttributes\")";
_ref.Target = _ref.RunMethod("getAttributes");
 //BA.debugLineNum = 143;BA.debugLine="Dim brightness As Float = ref.GetField(\"screen";
_brightness = (float)(BA.ObjectToNumber(_ref.GetField("screenBrightness")));
 //BA.debugLineNum = 144;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"screen bright";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("47579145","screen brightness is: "+BA.NumberToString(_brightness),0);};
 //BA.debugLineNum = 145;BA.debugLine="Return brightness";
if (true) return _brightness;
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return 0f;
}
public static String  _init(anywheresoftware.b4a.BA _ba,boolean _takeoverpower) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Init(takeOverPower As Boolean)";
 //BA.debugLineNum = 30;BA.debugLine="If takeOverPower = False Then Return";
if (_takeoverpower==anywheresoftware.b4a.keywords.Common.False) { 
if (true) return "";};
 //BA.debugLineNum = 32;BA.debugLine="If LoadBrightnesFromfile = False Then";
if (_loadbrightnesfromfile(_ba)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 33;BA.debugLine="pScreenBrightness = GetScreenBrightness";
_pscreenbrightness = _getscreenbrightness(_ba);
 //BA.debugLineNum = 34;BA.debugLine="If pScreenBrightness = AUTO_BRIGHTNESS Then";
if (_pscreenbrightness==_auto_brightness) { 
 //BA.debugLineNum = 35;BA.debugLine="pScreenBrightness = 0.5";
_pscreenbrightness = (float) (0.5);
 //BA.debugLineNum = 36;BA.debugLine="SetScreenBrightnessAndSave(pScreenBrightness,Tr";
_setscreenbrightnessandsave(_ba,_pscreenbrightness,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 37;BA.debugLine="Return";
if (true) return "";
 };
 };
 //BA.debugLineNum = 40;BA.debugLine="SetScreenBrightnessAndSave(pScreenBrightness,Fals";
_setscreenbrightnessandsave(_ba,_pscreenbrightness,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public static boolean  _loadbrightnesfromfile(anywheresoftware.b4a.BA _ba) throws Exception{
String _v = "";
 //BA.debugLineNum = 124;BA.debugLine="Private Sub LoadBrightnesFromfile() As Boolean";
 //BA.debugLineNum = 126;BA.debugLine="Dim v As String = fileHelpers.Read_ReturnSingleVa";
_v = mostCurrent._filehelpers._read_returnsinglevalue /*String*/ (_ba,_screen_brightness_file);
 //BA.debugLineNum = 127;BA.debugLine="If v = \"\" Then Return False";
if ((_v).equals("")) { 
if (true) return anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 128;BA.debugLine="pScreenBrightness = v.As(Float)";
_pscreenbrightness = ((float)(Double.parseDouble(_v)));
 //BA.debugLineNum = 129;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private Const mModule As String = \"powerHelpers\"";
_mmodule = "powerHelpers";
 //BA.debugLineNum = 13;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 15;BA.debugLine="Private pws As PhoneWakeState";
_pws = new anywheresoftware.b4a.phone.Phone.PhoneWakeState();
 //BA.debugLineNum = 16;BA.debugLine="Private ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 18;BA.debugLine="Public pScreenBrightness As Float = -1";
_pscreenbrightness = (float) (-1);
 //BA.debugLineNum = 19;BA.debugLine="Private Const AUTO_BRIGHTNESS As Float = -1";
_auto_brightness = (float) (-1);
 //BA.debugLineNum = 20;BA.debugLine="Private Const SCREEN_BRIGHTNESS_FILE As String =";
_screen_brightness_file = "scrn_brightness.lst";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public static String  _releaselocks(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Public Sub ReleaseLocks";
 //BA.debugLineNum = 71;BA.debugLine="pws.ReleaseKeepAlive";
_pws.ReleaseKeepAlive();
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public static String  _screenoff(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Public Sub ScreenOff";
 //BA.debugLineNum = 63;BA.debugLine="pws.ReleaseKeepAlive";
_pws.ReleaseKeepAlive();
 //BA.debugLineNum = 64;BA.debugLine="pws.PartialLock";
_pws.PartialLock((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 65;BA.debugLine="ph.SetScreenBrightness(0)";
_ph.SetScreenBrightness((_ba.processBA == null ? _ba : _ba.processBA),(float) (0));
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public static String  _screenon(anywheresoftware.b4a.BA _ba,boolean _takeoverpower) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Public Sub ScreenON(takeOverPower As Boolean)";
 //BA.debugLineNum = 47;BA.debugLine="ReleaseLocks";
_releaselocks(_ba);
 //BA.debugLineNum = 49;BA.debugLine="If takeOverPower Then";
if (_takeoverpower) { 
 //BA.debugLineNum = 50;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"KeepAlive -";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("47185925","KeepAlive - ON",0);};
 //BA.debugLineNum = 51;BA.debugLine="pws.KeepAlive(True)";
_pws.KeepAlive((_ba.processBA == null ? _ba : _ba.processBA),anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 53;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"KeepAlive -";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("47185928","KeepAlive - OFF",0);};
 };
 //BA.debugLineNum = 56;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2((_ba.processBA == null ? _ba : _ba.processBA),(Object)(mostCurrent._main.getObject()),"Dim_ActionBar",(Object)(mostCurrent._gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public static String  _setscreenbrightness2(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Public Sub SetScreenBrightness2";
 //BA.debugLineNum = 119;BA.debugLine="SetScreenBrightnessAndSave(pScreenBrightness,Fals";
_setscreenbrightnessandsave(_ba,_pscreenbrightness,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public static String  _setscreenbrightnessandsave(anywheresoftware.b4a.BA _ba,float _value,boolean _save2file) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Public Sub SetScreenBrightnessAndSave(value As Flo";
 //BA.debugLineNum = 99;BA.debugLine="Try";
try { //BA.debugLineNum = 100;BA.debugLine="If pScreenBrightness = AUTO_BRIGHTNESS Then";
if (_pscreenbrightness==_auto_brightness) { 
 //BA.debugLineNum = 101;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"cannot set";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("47382534","cannot set brightness, brightness is in automode",0);};
 //BA.debugLineNum = 102;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 104;BA.debugLine="If config.logPOWER_EVENTS Then Log(\"setting brig";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
anywheresoftware.b4a.keywords.Common.LogImpl("47382537","setting brightness to: "+BA.NumberToString(_value),0);};
 //BA.debugLineNum = 105;BA.debugLine="ph.SetScreenBrightness(value)";
_ph.SetScreenBrightness((_ba.processBA == null ? _ba : _ba.processBA),_value);
 //BA.debugLineNum = 106;BA.debugLine="If Save2File Then";
if (_save2file) { 
 //BA.debugLineNum = 107;BA.debugLine="fileHelpers.Write_SingleValue(SCREEN_BRIGHTNESS";
mostCurrent._filehelpers._write_singlevalue /*String*/ (_ba,_screen_brightness_file,(BA.NumberToString(_value)));
 };
 } 
       catch (Exception e12) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e12); //BA.debugLineNum = 111;BA.debugLine="logMe.LogIt2(LastException,mModule,\"SetScreenBri";
mostCurrent._logme._logit2 /*String*/ (_ba,BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),_mmodule,"SetScreenBrightnessAndSave");
 };
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
}
