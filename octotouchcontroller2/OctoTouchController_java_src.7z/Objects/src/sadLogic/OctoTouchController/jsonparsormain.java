package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jsonparsormain extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.jsonparsormain");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.jsonparsormain.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _checknull(String _v) throws Exception{
 //BA.debugLineNum = 250;BA.debugLine="Private Sub CheckNull(v As String) As String";
 //BA.debugLineNum = 251;BA.debugLine="Try";
try { //BA.debugLineNum = 252;BA.debugLine="Return IIf(v = Null Or v = \"null\" Or v = \"\",\"\",v";
if (true) return BA.ObjectToString(((_v== null || (_v).equals("null") || (_v).equals("")) ? ((Object)("")) : ((Object)(_v))));
 } 
       catch (Exception e4) {
			ba.setLastException(e4); //BA.debugLineNum = 254;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _checknull0(String _v) throws Exception{
 //BA.debugLineNum = 260;BA.debugLine="Private Sub CheckNull0(v As String) As String";
 //BA.debugLineNum = 261;BA.debugLine="Try";
try { //BA.debugLineNum = 262;BA.debugLine="Return IIf(v = Null Or v = \"null\" Or v = \"\" Or v";
if (true) return BA.ObjectToString(((_v== null || (_v).equals("null") || (_v).equals("") || (_v).equals("0.0")) ? ((Object)("0")) : ((Object)(_v))));
 } 
       catch (Exception e4) {
			ba.setLastException(e4); //BA.debugLineNum = 264;BA.debugLine="Return \"0\"";
if (true) return "0";
 };
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public String  _checknulldash(String _v) throws Exception{
 //BA.debugLineNum = 269;BA.debugLine="Private Sub CheckNullDash(v As String) As String";
 //BA.debugLineNum = 270;BA.debugLine="Try";
try { //BA.debugLineNum = 271;BA.debugLine="Return IIf(v = Null Or v = \"null\" Or v = \"\",\"-\",";
if (true) return BA.ObjectToString(((_v== null || (_v).equals("null") || (_v).equals("")) ? ((Object)("-")) : ((Object)(_v))));
 } 
       catch (Exception e4) {
			ba.setLastException(e4); //BA.debugLineNum = 273;BA.debugLine="Return \"-\"";
if (true) return "-";
 };
 //BA.debugLineNum = 275;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"jsonParserMain";
_mmodule = "jsonParserMain";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _jobstatus(String _s) throws Exception{
String _callingsub = "";
anywheresoftware.b4a.objects.collections.JSONParser _jp = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.collections.Map _mprogress = null;
anywheresoftware.b4a.objects.collections.Map _mjob = null;
anywheresoftware.b4a.objects.collections.Map _mfile = null;
 //BA.debugLineNum = 99;BA.debugLine="Public Sub  JobStatus(s As String)";
 //BA.debugLineNum = 100;BA.debugLine="Dim CallingSub As String = \"JobStatus\"";
_callingsub = "JobStatus";
 //BA.debugLineNum = 102;BA.debugLine="Dim jp As JSONParser";
_jp = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 104;BA.debugLine="Try";
try { //BA.debugLineNum = 106;BA.debugLine="jp.Initialize(s)";
_jp.Initialize(_s);
 //BA.debugLineNum = 110;BA.debugLine="oc.isCanceling = False";
_oc._iscanceling /*boolean*/  = __c.False;
 //BA.debugLineNum = 111;BA.debugLine="oc.isPrinting = False";
_oc._isprinting /*boolean*/  = __c.False;
 //BA.debugLineNum = 112;BA.debugLine="oc.isPaused2 = False";
_oc._ispaused2 /*boolean*/  = __c.False;
 //BA.debugLineNum = 186;BA.debugLine="Dim m, mProgress As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
_mprogress = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 187;BA.debugLine="Dim mJob, mFile As Map";
_mjob = new anywheresoftware.b4a.objects.collections.Map();
_mfile = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 188;BA.debugLine="m = jp.NextObject";
_m = _jp.NextObject();
 //BA.debugLineNum = 191;BA.debugLine="oc.JobPrintState = m.Get(\"state\")";
_oc._jobprintstate /*String*/  = BA.ObjectToString(_m.Get((Object)("state")));
 //BA.debugLineNum = 192;BA.debugLine="Select Case oc.JobPrintState";
switch (BA.switchObjectToInt(_oc._jobprintstate /*String*/ ,"Printing","Canceling","Cancelling","Paused")) {
case 0: {
 //BA.debugLineNum = 193;BA.debugLine="Case \"Printing\"     			: oc.isPrinting = True";
_oc._isprinting /*boolean*/  = __c.True;
 break; }
case 1: 
case 2: {
 //BA.debugLineNum = 194;BA.debugLine="Case \"Canceling\",\"Cancelling\"	: oc.isCanceling";
_oc._iscanceling /*boolean*/  = __c.True;
 break; }
case 3: {
 //BA.debugLineNum = 195;BA.debugLine="Case \"Paused\"      				: oc.isPaused2 = True";
_oc._ispaused2 /*boolean*/  = __c.True;
 break; }
}
;
 //BA.debugLineNum = 199;BA.debugLine="mJob = m.Get(\"job\").As(Map)";
_mjob = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_m.Get((Object)("job")))));
 //BA.debugLineNum = 200;BA.debugLine="mFile = mJob.Get(\"file\").As(Map)";
_mfile = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_mjob.Get((Object)("file")))));
 //BA.debugLineNum = 201;BA.debugLine="mProgress = m.Get(\"progress\").As(Map)";
_mprogress = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_m.Get((Object)("progress")))));
 //BA.debugLineNum = 203;BA.debugLine="oc.JobFileName = CheckNull(mFile.Get(\"name\"))";
_oc._jobfilename /*String*/  = _checknull(BA.ObjectToString(_mfile.Get((Object)("name"))));
 //BA.debugLineNum = 205;BA.debugLine="oc.isFileLoaded = (oc.JobFileName.Length <> 0)";
_oc._isfileloaded /*boolean*/  = (_oc._jobfilename /*String*/ .length()!=0);
 //BA.debugLineNum = 206;BA.debugLine="oc.JobFileOrigin = CheckNull(mFile.Get(\"origin\")";
_oc._jobfileorigin /*String*/  = _checknull(BA.ObjectToString(_mfile.Get((Object)("origin"))));
 //BA.debugLineNum = 207;BA.debugLine="oc.JobFileSize = CheckNull(mFile.Get(\"size\"))";
_oc._jobfilesize /*String*/  = _checknull(BA.ObjectToString(_mfile.Get((Object)("size"))));
 //BA.debugLineNum = 209;BA.debugLine="oc.JobEstPrintTime = IIf(CheckNull(mJob.Get(\"est";
_oc._jobestprinttime /*String*/  = BA.ObjectToString((((_checknull(BA.ObjectToString(_mjob.Get((Object)("estimatedPrintTime"))))).equals("") == false) ? (_mjob.Get((Object)("estimatedPrintTime"))) : ((Object)("N/A"))));
 //BA.debugLineNum = 212;BA.debugLine="oc.JobCompletion = CheckNull0(mProgress.Get(\"com";
_oc._jobcompletion /*String*/  = _checknull0(BA.ObjectToString(_mprogress.Get((Object)("completion"))));
 //BA.debugLineNum = 213;BA.debugLine="oc.JobFilePos = CheckNull0(mProgress.Get(\"filepo";
_oc._jobfilepos /*String*/  = _checknull0(BA.ObjectToString(_mprogress.Get((Object)("filepos"))));
 //BA.debugLineNum = 214;BA.debugLine="oc.JobPrintTime = CheckNullDash(mProgress.Get(\"p";
_oc._jobprinttime /*String*/  = _checknulldash(BA.ObjectToString(_mprogress.Get((Object)("printTime"))));
 //BA.debugLineNum = 215;BA.debugLine="oc.JobPrintTimeLeft = CheckNullDash(mProgress.Ge";
_oc._jobprinttimeleft /*String*/  = _checknulldash(BA.ObjectToString(_mprogress.Get((Object)("printTimeLeft"))));
 //BA.debugLineNum = 217;BA.debugLine="If oc.isHeating = True And oc.isPrinting = True";
if (_oc._isheating /*boolean*/ ==__c.True && _oc._isprinting /*boolean*/ ==__c.True) { 
 //BA.debugLineNum = 218;BA.debugLine="oc.JobPrintState = \"Heating/Printing\"";
_oc._jobprintstate /*String*/  = "Heating/Printing";
 };
 //BA.debugLineNum = 221;BA.debugLine="If oc.lastJobPrintState <> oc.JobPrintState Then";
if ((_oc._lastjobprintstate /*String*/ ).equals(_oc._jobprintstate /*String*/ ) == false) { 
 //BA.debugLineNum = 223;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"Update_Printe";
__c.CallSubDelayed(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (getActivityBA())),"Update_Printer_Btns");
 };
 //BA.debugLineNum = 229;BA.debugLine="oc.lastJobPrintState = oc.JobPrintState";
_oc._lastjobprintstate /*String*/  = _oc._jobprintstate /*String*/ ;
 } 
       catch (Exception e40) {
			ba.setLastException(e40); //BA.debugLineNum = 235;BA.debugLine="logMe.LogIt2(LastException,mModule,CallingSub)";
_logme._logit2 /*String*/ (getActivityBA(),BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 //BA.debugLineNum = 236;BA.debugLine="oc.ResetJobVars";
_oc._resetjobvars /*String*/ (getActivityBA());
 };
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public String  _tempstatus(String _s) throws Exception{
String _callingsub = "";
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.collections.Map _mtemp = null;
anywheresoftware.b4a.objects.collections.Map _mbed = null;
anywheresoftware.b4a.objects.collections.Map _mtool1 = null;
anywheresoftware.b4a.objects.collections.JSONParser _jp = null;
int _tmptool = 0;
int _tmpbed = 0;
int _targetbedcheck = 0;
int _targettoolcheck = 0;
int _bedcheckoffset = 0;
int _toolcheckoffset = 0;
int _bedactual = 0;
int _toolactual = 0;
 //BA.debugLineNum = 15;BA.debugLine="Public Sub TempStatus(s As String)";
 //BA.debugLineNum = 16;BA.debugLine="Dim CallingSub As String = \"TempStatus\"";
_callingsub = "TempStatus";
 //BA.debugLineNum = 17;BA.debugLine="Dim m, mTemp, mBed, mTool1 As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
_mtemp = new anywheresoftware.b4a.objects.collections.Map();
_mbed = new anywheresoftware.b4a.objects.collections.Map();
_mtool1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 18;BA.debugLine="Dim jp As JSONParser";
_jp = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 19;BA.debugLine="Dim tmpTool, tmpBed As Int '--- tmp vars to stip";
_tmptool = 0;
_tmpbed = 0;
 //BA.debugLineNum = 22;BA.debugLine="Try";
try { //BA.debugLineNum = 24;BA.debugLine="oc.isHeating = False";
_oc._isheating /*boolean*/  = __c.False;
 //BA.debugLineNum = 25;BA.debugLine="Dim TargetBedCheck,TargetToolCheck As Int";
_targetbedcheck = 0;
_targettoolcheck = 0;
 //BA.debugLineNum = 33;BA.debugLine="Try";
try { //BA.debugLineNum = 34;BA.debugLine="jp.Initialize(s)";
_jp.Initialize(_s);
 //BA.debugLineNum = 35;BA.debugLine="m = jp.NextObject";
_m = _jp.NextObject();
 //BA.debugLineNum = 36;BA.debugLine="mTemp = m.Get(\"temperature\").As(Map)";
_mtemp = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_m.Get((Object)("temperature")))));
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 38;BA.debugLine="logMe.LogIt2(\"temp 0:\"$ & LastException,mModule";
_logme._logit2 /*String*/ (getActivityBA(),"temp 0:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 //BA.debugLineNum = 42;BA.debugLine="Try";
try { //BA.debugLineNum = 43;BA.debugLine="mBed = mTemp.Get(\"bed\").As(Map)";
_mbed = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_mtemp.Get((Object)("bed")))));
 } 
       catch (Exception e18) {
			ba.setLastException(e18); //BA.debugLineNum = 45;BA.debugLine="logMe.LogIt2(\"temp 1:\"$ & LastException,mModule";
_logme._logit2 /*String*/ (getActivityBA(),"temp 1:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 //BA.debugLineNum = 47;BA.debugLine="Try";
try { //BA.debugLineNum = 48;BA.debugLine="TargetBedCheck = CheckNull0(mBed.Get(\"target\"))";
_targetbedcheck = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mbed.Get((Object)("target"))))));
 //BA.debugLineNum = 49;BA.debugLine="tmpBed = CheckNull0(mBed.Get(\"actual\"))";
_tmpbed = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mbed.Get((Object)("actual"))))));
 //BA.debugLineNum = 50;BA.debugLine="oc.BedActual   = tmpBed & gblConst.DEGREE_SYMBO";
_oc._bedactual /*String*/  = BA.NumberToString(_tmpbed)+_gblconst._degree_symbol /*String*/ +"C";
 //BA.debugLineNum = 51;BA.debugLine="oc.BedTarget   = TargetBedCheck.As(String)  & g";
_oc._bedtarget /*String*/  = (BA.NumberToString(_targetbedcheck))+_gblconst._degree_symbol /*String*/ +"C";
 } 
       catch (Exception e26) {
			ba.setLastException(e26); //BA.debugLineNum = 53;BA.debugLine="logMe.LogIt2(\"temp 11:\"$ & LastException,mModul";
_logme._logit2 /*String*/ (getActivityBA(),"temp 11:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 //BA.debugLineNum = 57;BA.debugLine="Try";
try { //BA.debugLineNum = 58;BA.debugLine="mTool1 = mTemp.Get(\"tool0\").As(Map)";
_mtool1 = ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_mtemp.Get((Object)("tool0")))));
 } 
       catch (Exception e31) {
			ba.setLastException(e31); //BA.debugLineNum = 60;BA.debugLine="logMe.LogIt2(\"temp 2:\"$ & LastException,mModule";
_logme._logit2 /*String*/ (getActivityBA(),"temp 2:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 //BA.debugLineNum = 62;BA.debugLine="Try";
try { //BA.debugLineNum = 63;BA.debugLine="TargetToolCheck = CheckNull0(mTool1.Get(\"target";
_targettoolcheck = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mtool1.Get((Object)("target"))))));
 //BA.debugLineNum = 64;BA.debugLine="oc.Tool1TargetReal = CheckNull0(mTool1.Get(\"tar";
_oc._tool1targetreal /*float*/  = (float)(Double.parseDouble(_checknull0(BA.ObjectToString(_mtool1.Get((Object)("target"))))));
 //BA.debugLineNum = 65;BA.debugLine="oc.Tool1ActualReal = CheckNull0(mTool1.Get(\"act";
_oc._tool1actualreal /*float*/  = (float)(Double.parseDouble(_checknull0(BA.ObjectToString(_mtool1.Get((Object)("actual"))))));
 //BA.debugLineNum = 66;BA.debugLine="tmpTool = CheckNull0(mTool1.Get(\"actual\"))";
_tmptool = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mtool1.Get((Object)("actual"))))));
 //BA.debugLineNum = 67;BA.debugLine="oc.Tool1Actual = tmpTool & gblConst.DEGREE_SYMB";
_oc._tool1actual /*String*/  = BA.NumberToString(_tmptool)+_gblconst._degree_symbol /*String*/ +"C";
 //BA.debugLineNum = 68;BA.debugLine="oc.Tool1Target = TargetToolCheck.As(String) & g";
_oc._tool1target /*String*/  = (BA.NumberToString(_targettoolcheck))+_gblconst._degree_symbol /*String*/ +"C";
 } 
       catch (Exception e41) {
			ba.setLastException(e41); //BA.debugLineNum = 70;BA.debugLine="logMe.LogIt2(\"temp 22:\"$ & LastException,mModul";
_logme._logit2 /*String*/ (getActivityBA(),"temp 22:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 //BA.debugLineNum = 74;BA.debugLine="Try";
try { //BA.debugLineNum = 76;BA.debugLine="If TargetBedCheck <> 0 Or TargetToolCheck <> 0";
if (_targetbedcheck!=0 || _targettoolcheck!=0) { 
 //BA.debugLineNum = 77;BA.debugLine="Dim bedCheckOffset As Int = 2";
_bedcheckoffset = (int) (2);
 //BA.debugLineNum = 78;BA.debugLine="Dim toolCheckOffset As Int = 5";
_toolcheckoffset = (int) (5);
 //BA.debugLineNum = 79;BA.debugLine="Dim bedActual As Int = CheckNull0(mBed.Get(\"ac";
_bedactual = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mbed.Get((Object)("actual"))))));
 //BA.debugLineNum = 80;BA.debugLine="Dim toolActual As Int = CheckNull0(mTool1.Get(";
_toolactual = (int)(Double.parseDouble(_checknull0(BA.ObjectToString(_mtool1.Get((Object)("actual"))))));
 //BA.debugLineNum = 81;BA.debugLine="If (bedActual + bedCheckOffset <= TargetBedChe";
if ((_bedactual+_bedcheckoffset<=_targetbedcheck) || (_toolactual+_toolcheckoffset<=_targettoolcheck)) { 
 //BA.debugLineNum = 82;BA.debugLine="oc.isHeating = True";
_oc._isheating /*boolean*/  = __c.True;
 }else {
 //BA.debugLineNum = 84;BA.debugLine="oc.isHeating = False";
_oc._isheating /*boolean*/  = __c.False;
 };
 };
 } 
       catch (Exception e56) {
			ba.setLastException(e56); //BA.debugLineNum = 88;BA.debugLine="logMe.LogIt2(\"temp 33:\"$ & LastException,mModul";
_logme._logit2 /*String*/ (getActivityBA(),"temp 33:"+BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 };
 } 
       catch (Exception e59) {
			ba.setLastException(e59); //BA.debugLineNum = 92;BA.debugLine="logMe.LogIt2(LastException,mModule,CallingSub)";
_logme._logit2 /*String*/ (getActivityBA(),BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_callingsub);
 //BA.debugLineNum = 93;BA.debugLine="oc.ResetTempVars";
_oc._resettempvars /*String*/ (getActivityBA());
 };
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
