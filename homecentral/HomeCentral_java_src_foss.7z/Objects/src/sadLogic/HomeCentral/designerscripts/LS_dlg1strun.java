package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_dlg1strun{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[dlg1stRun/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="txtNever.Bottom = 100%y"[dlg1stRun/General script]
views.get("txtnever").vw.setTop((int)((100d / 100 * height) - (views.get("txtnever").vw.getHeight())));
//BA.debugLineNum = 5;BA.debugLine="txtNever.SetLeftAndRight(2dip,100%x-2dip)"[dlg1stRun/General script]
views.get("txtnever").vw.setLeft((int)((2d * scale)));
views.get("txtnever").vw.setWidth((int)((100d / 100 * width)-(2d * scale) - ((2d * scale))));
//BA.debugLineNum = 6;BA.debugLine="lblAboutTop.SetLeftAndRight(iv.Right+2dip,100%x)"[dlg1stRun/General script]
views.get("lblabouttop").vw.setLeft((int)((views.get("iv").vw.getLeft() + views.get("iv").vw.getWidth())+(2d * scale)));
views.get("lblabouttop").vw.setWidth((int)((100d / 100 * width) - ((views.get("iv").vw.getLeft() + views.get("iv").vw.getWidth())+(2d * scale))));
//BA.debugLineNum = 8;BA.debugLine="txt1stRun.SetLeftAndRight(2dip,100%x-2dip)"[dlg1stRun/General script]
views.get("txt1strun").vw.setLeft((int)((2d * scale)));
views.get("txt1strun").vw.setWidth((int)((100d / 100 * width)-(2d * scale) - ((2d * scale))));
//BA.debugLineNum = 9;BA.debugLine="txt1stRun.SetTopAndBottom(iv.Bottom,txtNever.Top)"[dlg1stRun/General script]
views.get("txt1strun").vw.setTop((int)((views.get("iv").vw.getTop() + views.get("iv").vw.getHeight())));
views.get("txt1strun").vw.setHeight((int)((views.get("txtnever").vw.getTop()) - ((views.get("iv").vw.getTop() + views.get("iv").vw.getHeight()))));

}
}