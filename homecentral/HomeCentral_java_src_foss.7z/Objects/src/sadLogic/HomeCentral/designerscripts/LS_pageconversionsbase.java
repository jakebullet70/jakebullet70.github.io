package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pageconversionsbase{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _padb="";
String _sizeh="";
String _sizev="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbg").vw.setLeft((int)(0d));
views.get("pnlbg").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlbg").vw.setTop((int)(0d));
views.get("pnlbg").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlnumpad").vw.setLeft((int)((45d / 100 * width)));
views.get("pnlnumpad").vw.setWidth((int)((95d / 100 * width) - ((45d / 100 * width))));
views.get("pnlnumpad").vw.setTop((int)((4d / 100 * height)));
views.get("pnlnumpad").vw.setHeight((int)((94d / 100 * height) - ((4d / 100 * height))));
views.get("lblwhat").vw.setLeft((int)((40d * scale)));
views.get("lblwhat").vw.setWidth((int)((45d / 100 * width) - ((40d * scale))));
views.get("lblwhat").vw.setTop((int)((4d / 100 * height)));
views.get("lblwhat").vw.setHeight((int)((14d / 100 * height) - ((4d / 100 * height))));
views.get("pnlinput").vw.setLeft((int)((40d * scale)));
views.get("pnlinput").vw.setWidth((int)((45d / 100 * width) - ((40d * scale))));
views.get("pnlinput").vw.setTop((int)((13d / 100 * height)));
views.get("pnlinput").vw.setHeight((int)((93d / 100 * height) - ((13d / 100 * height))));
_padb = BA.NumberToString((4d * scale));
_sizeh = BA.NumberToString(((views.get("pnlnumpad").vw.getWidth())-(Double.parseDouble(_padb)))/3d);
_sizev = BA.NumberToString(((views.get("pnlnumpad").vw.getHeight())-(Double.parseDouble(_padb)))/4d);
views.get("button1").vw.setLeft((int)(Double.parseDouble(_padb)));
views.get("button1").vw.setWidth((int)(Double.parseDouble(_sizeh) - (Double.parseDouble(_padb))));
views.get("button1").vw.setTop((int)(Double.parseDouble(_padb)));
views.get("button1").vw.setHeight((int)(Double.parseDouble(_sizev) - (Double.parseDouble(_padb))));
views.get("button2").vw.setLeft((int)((views.get("button1").vw.getLeft() + views.get("button1").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button2").vw.setWidth((int)(Double.parseDouble(_sizeh)*2d - ((views.get("button1").vw.getLeft() + views.get("button1").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button2").vw.setTop((int)(Double.parseDouble(_padb)));
views.get("button2").vw.setHeight((int)(Double.parseDouble(_sizev) - (Double.parseDouble(_padb))));
views.get("button3").vw.setLeft((int)((views.get("button2").vw.getLeft() + views.get("button2").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button3").vw.setWidth((int)(Double.parseDouble(_sizeh)*3d - ((views.get("button2").vw.getLeft() + views.get("button2").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button3").vw.setTop((int)(Double.parseDouble(_padb)));
views.get("button3").vw.setHeight((int)(Double.parseDouble(_sizev) - (Double.parseDouble(_padb))));
views.get("button4").vw.setLeft((int)(Double.parseDouble(_padb)));
views.get("button4").vw.setWidth((int)(Double.parseDouble(_sizeh) - (Double.parseDouble(_padb))));
views.get("button4").vw.setTop((int)((views.get("button1").vw.getTop() + views.get("button1").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button4").vw.setHeight((int)(Double.parseDouble(_sizev)*2d - ((views.get("button1").vw.getTop() + views.get("button1").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button5").vw.setLeft((int)((views.get("button1").vw.getLeft() + views.get("button1").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button5").vw.setWidth((int)(Double.parseDouble(_sizeh)*2d - ((views.get("button1").vw.getLeft() + views.get("button1").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button5").vw.setTop((int)((views.get("button1").vw.getTop() + views.get("button1").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button5").vw.setHeight((int)(Double.parseDouble(_sizev)*2d - ((views.get("button1").vw.getTop() + views.get("button1").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button6").vw.setLeft((int)((views.get("button2").vw.getLeft() + views.get("button2").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button6").vw.setWidth((int)(Double.parseDouble(_sizeh)*3d - ((views.get("button2").vw.getLeft() + views.get("button2").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button6").vw.setTop((int)((views.get("button2").vw.getTop() + views.get("button2").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button6").vw.setHeight((int)(Double.parseDouble(_sizev)*2d - ((views.get("button2").vw.getTop() + views.get("button2").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button7").vw.setLeft((int)(Double.parseDouble(_padb)));
views.get("button7").vw.setWidth((int)(Double.parseDouble(_sizeh) - (Double.parseDouble(_padb))));
views.get("button7").vw.setTop((int)((views.get("button4").vw.getTop() + views.get("button4").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button7").vw.setHeight((int)(Double.parseDouble(_sizev)*3d - ((views.get("button4").vw.getTop() + views.get("button4").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button8").vw.setLeft((int)((views.get("button4").vw.getLeft() + views.get("button4").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button8").vw.setWidth((int)(Double.parseDouble(_sizeh)*2d - ((views.get("button4").vw.getLeft() + views.get("button4").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button8").vw.setTop((int)((views.get("button4").vw.getTop() + views.get("button4").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button8").vw.setHeight((int)(Double.parseDouble(_sizev)*3d - ((views.get("button4").vw.getTop() + views.get("button4").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button9").vw.setLeft((int)((views.get("button5").vw.getLeft() + views.get("button5").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button9").vw.setWidth((int)(Double.parseDouble(_sizeh)*3d - ((views.get("button5").vw.getLeft() + views.get("button5").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button9").vw.setTop((int)((views.get("button5").vw.getTop() + views.get("button5").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button9").vw.setHeight((int)(Double.parseDouble(_sizev)*3d - ((views.get("button5").vw.getTop() + views.get("button5").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button10").vw.setLeft((int)(Double.parseDouble(_padb)));
views.get("button10").vw.setWidth((int)(Double.parseDouble(_sizeh) - (Double.parseDouble(_padb))));
views.get("button10").vw.setTop((int)((views.get("button7").vw.getTop() + views.get("button7").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button10").vw.setHeight((int)(Double.parseDouble(_sizev)*4d - ((views.get("button7").vw.getTop() + views.get("button7").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button11").vw.setLeft((int)((views.get("button7").vw.getLeft() + views.get("button7").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button11").vw.setWidth((int)(Double.parseDouble(_sizeh)*2d - ((views.get("button7").vw.getLeft() + views.get("button7").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button11").vw.setTop((int)((views.get("button7").vw.getTop() + views.get("button7").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button11").vw.setHeight((int)(Double.parseDouble(_sizev)*4d - ((views.get("button7").vw.getTop() + views.get("button7").vw.getHeight())+Double.parseDouble(_padb))));
views.get("button12").vw.setLeft((int)((views.get("button8").vw.getLeft() + views.get("button8").vw.getWidth())+Double.parseDouble(_padb)));
views.get("button12").vw.setWidth((int)(Double.parseDouble(_sizeh)*3d - ((views.get("button8").vw.getLeft() + views.get("button8").vw.getWidth())+Double.parseDouble(_padb))));
views.get("button12").vw.setTop((int)((views.get("button8").vw.getTop() + views.get("button8").vw.getHeight())+Double.parseDouble(_padb)));
views.get("button12").vw.setHeight((int)(Double.parseDouble(_sizev)*4d - ((views.get("button8").vw.getTop() + views.get("button8").vw.getHeight())+Double.parseDouble(_padb))));

}
}