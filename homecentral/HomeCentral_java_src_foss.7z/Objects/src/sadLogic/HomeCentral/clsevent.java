package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clsevent extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.clsevent");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.clsevent.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.List _subscriptions = null;
public anywheresoftware.b4a.objects.collections.List _callbacks = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private subscriptions As List";
_subscriptions = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 4;BA.debugLine="Private callbacks As List";
_callbacks = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 5;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 9;BA.debugLine="subscriptions.Initialize";
_subscriptions.Initialize();
 //BA.debugLineNum = 10;BA.debugLine="callbacks.Initialize";
_callbacks.Initialize();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _raise() throws Exception{
Object _deleg = null;
int _callbackindex = 0;
 //BA.debugLineNum = 50;BA.debugLine="Public Sub Raise()";
 //BA.debugLineNum = 51;BA.debugLine="For Each deleg As Object In subscriptions";
{
final anywheresoftware.b4a.BA.IterableList group1 = _subscriptions;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_deleg = group1.Get(index1);
 //BA.debugLineNum = 52;BA.debugLine="Dim callbackIndex As Int = subscriptions.IndexOf";
_callbackindex = _subscriptions.IndexOf(_deleg);
 //BA.debugLineNum = 53;BA.debugLine="If SubExists(deleg, callbacks.Get(callbackIndex)";
if (__c.SubExists(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)))) { 
 //BA.debugLineNum = 54;BA.debugLine="CallSubDelayed(deleg, callbacks.Get(callbackInd";
__c.CallSubDelayed(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)));
 };
 }
};
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _raise2(Object _arg1) throws Exception{
Object _deleg = null;
int _callbackindex = 0;
 //BA.debugLineNum = 62;BA.debugLine="Public Sub Raise2(arg1 As Object)";
 //BA.debugLineNum = 63;BA.debugLine="For Each deleg As Object In subscriptions";
{
final anywheresoftware.b4a.BA.IterableList group1 = _subscriptions;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_deleg = group1.Get(index1);
 //BA.debugLineNum = 64;BA.debugLine="Dim callbackIndex As Int = subscriptions.IndexOf";
_callbackindex = _subscriptions.IndexOf(_deleg);
 //BA.debugLineNum = 65;BA.debugLine="If SubExists(deleg, callbacks.Get(callbackIndex)";
if (__c.SubExists(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)))) { 
 //BA.debugLineNum = 66;BA.debugLine="CallSubDelayed2(deleg, callbacks.Get(callbackIn";
__c.CallSubDelayed2(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)),_arg1);
 };
 }
};
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public String  _raise3(Object _arg1,Object _arg2) throws Exception{
Object _deleg = null;
int _callbackindex = 0;
 //BA.debugLineNum = 75;BA.debugLine="Public Sub Raise3(arg1 As Object, arg2 As Object)";
 //BA.debugLineNum = 76;BA.debugLine="For Each deleg As Object In subscriptions";
{
final anywheresoftware.b4a.BA.IterableList group1 = _subscriptions;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_deleg = group1.Get(index1);
 //BA.debugLineNum = 77;BA.debugLine="Dim callbackIndex As Int = subscriptions.IndexOf";
_callbackindex = _subscriptions.IndexOf(_deleg);
 //BA.debugLineNum = 78;BA.debugLine="If SubExists(deleg, callbacks.Get(callbackIndex)";
if (__c.SubExists(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)))) { 
 //BA.debugLineNum = 79;BA.debugLine="CallSubDelayed3(deleg, callbacks.Get(callbackIn";
__c.CallSubDelayed3(ba,_deleg,BA.ObjectToString(_callbacks.Get(_callbackindex)),_arg1,_arg2);
 };
 }
};
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _subscribe(Object _target,String _callback) throws Exception{
int _index = 0;
boolean _additem = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Subscribe(target As Object, callback As";
 //BA.debugLineNum = 19;BA.debugLine="Dim index As Int = subscriptions.IndexOf(target)";
_index = _subscriptions.IndexOf(_target);
 //BA.debugLineNum = 20;BA.debugLine="Dim addItem As Boolean";
_additem = false;
 //BA.debugLineNum = 22;BA.debugLine="addItem = index = -1";
_additem = _index==-1;
 //BA.debugLineNum = 24;BA.debugLine="If (addItem = False) Then";
if ((_additem==__c.False)) { 
 //BA.debugLineNum = 25;BA.debugLine="If (callbacks.Get(index) <> callback) Then";
if (((_callbacks.Get(_index)).equals((Object)(_callback)) == false)) { 
 //BA.debugLineNum = 26;BA.debugLine="subscriptions.RemoveAt(index)";
_subscriptions.RemoveAt(_index);
 //BA.debugLineNum = 27;BA.debugLine="callbacks.RemoveAt(index)";
_callbacks.RemoveAt(_index);
 //BA.debugLineNum = 28;BA.debugLine="addItem = True";
_additem = __c.True;
 };
 };
 //BA.debugLineNum = 32;BA.debugLine="If (addItem) Then";
if ((_additem)) { 
 //BA.debugLineNum = 33;BA.debugLine="subscriptions.add(target)";
_subscriptions.Add(_target);
 //BA.debugLineNum = 34;BA.debugLine="callbacks.add(callback)";
_callbacks.Add((Object)(_callback));
 };
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _unsubscribe(Object _target) throws Exception{
int _index = 0;
 //BA.debugLineNum = 41;BA.debugLine="Public Sub Unsubscribe(target As Object)";
 //BA.debugLineNum = 42;BA.debugLine="Dim index As Int = subscriptions.IndexOf(target)";
_index = _subscriptions.IndexOf(_target);
 //BA.debugLineNum = 43;BA.debugLine="If (index <> -1) Then";
if ((_index!=-1)) { 
 //BA.debugLineNum = 44;BA.debugLine="subscriptions.RemoveAt(index)";
_subscriptions.RemoveAt(_index);
 //BA.debugLineNum = 45;BA.debugLine="callbacks.RemoveAt(index)";
_callbacks.RemoveAt(_index);
 };
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
