package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_dlgblcrtouch{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _w="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)(0d));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 5;BA.debugLine="pnlMain.SetTopAndBottom(0,100%y)"[dlgBLCRtouch/General script]
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
//BA.debugLineNum = 7;BA.debugLine="pnlL.SetLeftAndRight(0,pnlMain.Width * .5)"[dlgBLCRtouch/General script]
views.get("pnll").vw.setLeft((int)(0d));
views.get("pnll").vw.setWidth((int)((views.get("pnlmain").vw.getWidth())*.5d - (0d)));
//BA.debugLineNum = 8;BA.debugLine="pnlL.SetTopAndBottom(0,pnlMain.Bottom)"[dlgBLCRtouch/General script]
views.get("pnll").vw.setTop((int)(0d));
views.get("pnll").vw.setHeight((int)((views.get("pnlmain").vw.getTop() + views.get("pnlmain").vw.getHeight()) - (0d)));
//BA.debugLineNum = 9;BA.debugLine="pnlR.SetLeftAndRight(pnlMain.Width * .5,pnlMain.Width)"[dlgBLCRtouch/General script]
views.get("pnlr").vw.setLeft((int)((views.get("pnlmain").vw.getWidth())*.5d));
views.get("pnlr").vw.setWidth((int)((views.get("pnlmain").vw.getWidth()) - ((views.get("pnlmain").vw.getWidth())*.5d)));
//BA.debugLineNum = 10;BA.debugLine="pnlR.SetTopAndBottom(0,pnlMain.Bottom)"[dlgBLCRtouch/General script]
views.get("pnlr").vw.setTop((int)(0d));
views.get("pnlr").vw.setHeight((int)((views.get("pnlmain").vw.getTop() + views.get("pnlmain").vw.getHeight()) - (0d)));
//BA.debugLineNum = 12;BA.debugLine="w = pnlR.Width * .88"[dlgBLCRtouch/General script]
_w = BA.NumberToString((views.get("pnlr").vw.getWidth())*.88d);
//BA.debugLineNum = 13;BA.debugLine="btnDn.Width = w"[dlgBLCRtouch/General script]
views.get("btndn").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 14;BA.debugLine="btnPBed.Width = w"[dlgBLCRtouch/General script]
views.get("btnpbed").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 15;BA.debugLine="btnrAlarm.Width = w"[dlgBLCRtouch/General script]
views.get("btnralarm").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 16;BA.debugLine="btnSave.Width = w"[dlgBLCRtouch/General script]
views.get("btnsave").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 17;BA.debugLine="btnSelftTest.Width = w"[dlgBLCRtouch/General script]
views.get("btnselfttest").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 18;BA.debugLine="btnUp.Width = w"[dlgBLCRtouch/General script]
views.get("btnup").vw.setWidth((int)(Double.parseDouble(_w)));
//BA.debugLineNum = 20;BA.debugLine="DSE_Layout.SpreadVertically(pnlR,0,6dip,\"center\")"[dlgBLCRtouch/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnlr", "0", BA.NumberToString((6d * scale)), "center"});
//BA.debugLineNum = 21;BA.debugLine="DSE_Layout.SpreadVertically(pnlL,0,6dip,\"center\")"[dlgBLCRtouch/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnll", "0", BA.NumberToString((6d * scale)), "center"});

}
}