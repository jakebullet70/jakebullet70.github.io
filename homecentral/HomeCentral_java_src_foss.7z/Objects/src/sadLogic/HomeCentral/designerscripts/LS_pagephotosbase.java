package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagephotosbase{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _pad="";
String _p1="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlbtns").vw.setLeft((int)((86d / 100 * width)));
views.get("pnlbtns").vw.setWidth((int)((100d / 100 * width) - ((86d / 100 * width))));
views.get("pnlshow").vw.setLeft((int)(0d));
views.get("pnlshow").vw.setWidth((int)((86d / 100 * width) - (0d)));
views.get("pnlbtns").vw.setTop((int)(0d));
views.get("pnlbtns").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("btnfullscrn").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnfullscrn").vw.getWidth())));
views.get("btnnext").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnnext").vw.getWidth())));
views.get("btnprev").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnprev").vw.getWidth())));
views.get("btnstart").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())-(10d * scale) - (views.get("btnstart").vw.getWidth())));
views.get("pnlsplitter").vw.setLeft((int)((7d * scale)));
views.get("pnlsplitter").vw.setWidth((int)((10d * scale) - ((7d * scale))));
views.get("pnlsplitter").vw.setTop((int)((16d * scale)));
views.get("pnlsplitter").vw.setHeight((int)((views.get("pnlbtns").vw.getHeight())-(16d * scale) - ((16d * scale))));
_pad = BA.NumberToString((30d * scale));
views.get("lvpics").vw.setLeft((int)((views.get("pnlshow").vw.getLeft())+Double.parseDouble(_pad)));
views.get("lvpics").vw.setWidth((int)((views.get("pnlshow").vw.getLeft() + views.get("pnlshow").vw.getWidth())-Double.parseDouble(_pad) - ((views.get("pnlshow").vw.getLeft())+Double.parseDouble(_pad))));
views.get("lvpics").vw.setHeight((int)((views.get("pnlshow").vw.getHeight())/2d));
views.get("lvpics").vw.setTop((int)((views.get("pnlshow").vw.getHeight())/2d - (views.get("lvpics").vw.getHeight() / 2)));
_p1 = BA.NumberToString((20d * scale));
views.get("img").vw.setTop((int)(Double.parseDouble(_p1)));
views.get("img").vw.setHeight((int)((views.get("pnlshow").vw.getHeight())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));
views.get("img").vw.setLeft((int)(Double.parseDouble(_p1)));
views.get("img").vw.setWidth((int)((views.get("pnlshow").vw.getWidth())-Double.parseDouble(_p1) - (Double.parseDouble(_p1))));

}
}