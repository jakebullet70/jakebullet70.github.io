package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clrtheme {
private static clrtheme mostCurrent = new clrtheme();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static String _mmodule = "";
public static sadLogic.OctoTouchController.foss.clrtheme._tthemecolors _customcolors = null;
public static int _background = 0;
public static int _backgroundheader = 0;
public static int _background2 = 0;
public static int _txtaccent = 0;
public static int _txtnormal = 0;
public static int _btndisabletext = 0;
public static int _dividercolor = 0;
public static int _itemsbackgroundcolor = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static class _tthemecolors{
public boolean IsInitialized;
public int bg;
public int bgheader;
public int bgmenu;
public int txtNormal;
public int txtacc;
public int disabled;
public int divider;
public void Initialize() {
IsInitialized = true;
bg = 0;
bgheader = 0;
bgmenu = 0;
txtNormal = 0;
txtacc = 0;
disabled = 0;
divider = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _colortohex(anywheresoftware.b4a.BA _ba,int _clr) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
 //BA.debugLineNum = 153;BA.debugLine="Public Sub ColorToHex(clr As Int) As String";
 //BA.debugLineNum = 154;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 155;BA.debugLine="Return bc.HexFromBytes(bc.IntsToBytes(Array As In";
if (true) return _bc.HexFromBytes(_bc.IntsToBytes(new int[]{_clr}));
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public static String  _colortohex4bblabel(anywheresoftware.b4a.BA _ba,int _clr) throws Exception{
 //BA.debugLineNum = 149;BA.debugLine="Public Sub ColorToHex4BBLabel(clr As Int) As Strin";
 //BA.debugLineNum = 150;BA.debugLine="Return \"0x\" & ColorToHex(clr)";
if (true) return "0x"+_colortohex(_ba,_clr);
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
return "";
}
public static int  _hextocolor(anywheresoftware.b4a.BA _ba,String _hex) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
int[] _ints = null;
 //BA.debugLineNum = 158;BA.debugLine="Public Sub HexToColor(Hex As String) As Int 'ignor";
 //BA.debugLineNum = 159;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 160;BA.debugLine="If Hex.StartsWith(\"#\") Then";
if (_hex.startsWith("#")) { 
 //BA.debugLineNum = 161;BA.debugLine="Hex = Hex.SubString(1)";
_hex = _hex.substring((int) (1));
 }else if(_hex.startsWith("0x")) { 
 //BA.debugLineNum = 163;BA.debugLine="Hex = Hex.SubString(2)";
_hex = _hex.substring((int) (2));
 };
 //BA.debugLineNum = 165;BA.debugLine="Dim ints() As Int = bc.IntsFromBytes(bc.HexToByte";
_ints = _bc.IntsFromBytes(_bc.HexToBytes(_hex));
 //BA.debugLineNum = 166;BA.debugLine="Return ints(0)";
if (true) return _ints[(int) (0)];
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return 0;
}
public static String  _init(anywheresoftware.b4a.BA _ba,String _theme) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Init(theme As String)";
 //BA.debugLineNum = 26;BA.debugLine="If Main.kvs.ContainsKey(gblConst.CUSTOM_THEME_COL";
if (mostCurrent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._containskey /*boolean*/ (mostCurrent._gblconst._custom_theme_colors /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
_seedcustomclrs(_ba);};
 //BA.debugLineNum = 27;BA.debugLine="customcolors = Main.kvs.Get(gblConst.CUSTOM_THEME";
_customcolors = (sadLogic.OctoTouchController.foss.clrtheme._tthemecolors)(mostCurrent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._get /*Object*/ (mostCurrent._gblconst._custom_theme_colors /*String*/ ));
 //BA.debugLineNum = 28;BA.debugLine="InitTheme(theme)";
_inittheme(_ba,_theme);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public static String  _inittheme(anywheresoftware.b4a.BA _ba,String _theme) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Public Sub InitTheme(theme As String)";
 //BA.debugLineNum = 34;BA.debugLine="txtNormal = xui.Color_white";
_txtnormal = _xui.Color_White;
 //BA.debugLineNum = 35;BA.debugLine="txtAccent = xui.Color_LightGray";
_txtaccent = _xui.Color_LightGray;
 //BA.debugLineNum = 36;BA.debugLine="btnDisableText = xui.Color_ARGB(50,192,192,192)";
_btndisabletext = _xui.Color_ARGB((int) (50),(int) (192),(int) (192),(int) (192));
 //BA.debugLineNum = 37;BA.debugLine="DividerColor = xui.Color_LightGray";
_dividercolor = _xui.Color_LightGray;
 //BA.debugLineNum = 39;BA.debugLine="theme = theme.ToLowerCase";
_theme = _theme.toLowerCase();
 //BA.debugLineNum = 40;BA.debugLine="Log(\"Init Theme: \" & theme)";
anywheresoftware.b4a.keywords.Common.LogImpl("10027016","Init Theme: "+_theme,0);
 //BA.debugLineNum = 42;BA.debugLine="Select Case theme";
switch (BA.switchObjectToInt(_theme,"rose","custom","red","green","gray","dark","dark-blue","dark-green","prusa")) {
case 0: {
 //BA.debugLineNum = 45;BA.debugLine="Background = -7177863";
_background = (int) (-7177863);
 //BA.debugLineNum = 46;BA.debugLine="BackgroundHeader = -3054235";
_backgroundheader = (int) (-3054235);
 //BA.debugLineNum = 47;BA.debugLine="Background2 = -7576990";
_background2 = (int) (-7576990);
 //BA.debugLineNum = 48;BA.debugLine="txtNormal = -15461870";
_txtnormal = (int) (-15461870);
 //BA.debugLineNum = 49;BA.debugLine="txtAccent = -395787";
_txtaccent = (int) (-395787);
 //BA.debugLineNum = 50;BA.debugLine="btnDisableText = 1715811894";
_btndisabletext = (int) (1715811894);
 //BA.debugLineNum = 51;BA.debugLine="DividerColor = -3355444";
_dividercolor = (int) (-3355444);
 break; }
case 1: {
 //BA.debugLineNum = 54;BA.debugLine="Background = CustomColors.bg";
_background = _customcolors.bg /*int*/ ;
 //BA.debugLineNum = 55;BA.debugLine="BackgroundHeader = CustomColors.bgHeader";
_backgroundheader = _customcolors.bgheader /*int*/ ;
 //BA.debugLineNum = 56;BA.debugLine="Background2 = CustomColors.bgMenu";
_background2 = _customcolors.bgmenu /*int*/ ;
 //BA.debugLineNum = 57;BA.debugLine="txtNormal = CustomColors.txtNormal";
_txtnormal = _customcolors.txtNormal /*int*/ ;
 //BA.debugLineNum = 58;BA.debugLine="txtAccent = CustomColors.txtAcc";
_txtaccent = _customcolors.txtacc /*int*/ ;
 //BA.debugLineNum = 59;BA.debugLine="btnDisableText = CustomColors.Disabled";
_btndisabletext = _customcolors.disabled /*int*/ ;
 //BA.debugLineNum = 60;BA.debugLine="DividerColor = CustomColors.Divider";
_dividercolor = _customcolors.divider /*int*/ ;
 break; }
case 2: {
 //BA.debugLineNum = 63;BA.debugLine="Background = xui.Color_ARGB(255,131, 21, 25)";
_background = _xui.Color_ARGB((int) (255),(int) (131),(int) (21),(int) (25));
 //BA.debugLineNum = 64;BA.debugLine="BackgroundHeader = -5239520";
_backgroundheader = (int) (-5239520);
 //BA.debugLineNum = 65;BA.debugLine="Background2 = xui.Color_ARGB(255,162, 30, 25)";
_background2 = _xui.Color_ARGB((int) (255),(int) (162),(int) (30),(int) (25));
 //BA.debugLineNum = 66;BA.debugLine="btnDisableText = 1006303994";
_btndisabletext = (int) (1006303994);
 //BA.debugLineNum = 67;BA.debugLine="txtAccent = -1803140";
_txtaccent = (int) (-1803140);
 break; }
case 3: {
 //BA.debugLineNum = 70;BA.debugLine="Background = xui.Color_ARGB(255,19, 62, 11)";
_background = _xui.Color_ARGB((int) (255),(int) (19),(int) (62),(int) (11));
 //BA.debugLineNum = 71;BA.debugLine="BackgroundHeader = -16310780";
_backgroundheader = (int) (-16310780);
 //BA.debugLineNum = 72;BA.debugLine="Background2 = xui.Color_ARGB(255,10, 53, 2)";
_background2 = _xui.Color_ARGB((int) (255),(int) (10),(int) (53),(int) (2));
 //BA.debugLineNum = 73;BA.debugLine="btnDisableText = 720959736";
_btndisabletext = (int) (720959736);
 break; }
case 4: {
 //BA.debugLineNum = 76;BA.debugLine="Background = xui.Color_ARGB(255,90, 90, 90)";
_background = _xui.Color_ARGB((int) (255),(int) (90),(int) (90),(int) (90));
 //BA.debugLineNum = 77;BA.debugLine="BackgroundHeader =-13487823";
_backgroundheader = (int) (-13487823);
 //BA.debugLineNum = 78;BA.debugLine="Background2 = xui.Color_ARGB(255,60, 60, 60)";
_background2 = _xui.Color_ARGB((int) (255),(int) (60),(int) (60),(int) (60));
 break; }
case 5: {
 //BA.debugLineNum = 81;BA.debugLine="Background = xui.Color_ARGB(255,2, 2, 2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 82;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 83;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 84;BA.debugLine="btnDisableText = 1404812219";
_btndisabletext = (int) (1404812219);
 break; }
case 6: {
 //BA.debugLineNum = 87;BA.debugLine="Background = xui.Color_ARGB(255,2,2,2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 88;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 89;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 90;BA.debugLine="txtNormal = -16739073";
_txtnormal = (int) (-16739073);
 //BA.debugLineNum = 91;BA.debugLine="txtAccent = -8472605";
_txtaccent = (int) (-8472605);
 //BA.debugLineNum = 92;BA.debugLine="btnDisableText = -12104360";
_btndisabletext = (int) (-12104360);
 break; }
case 7: {
 //BA.debugLineNum = 95;BA.debugLine="Background = xui.Color_ARGB(255,2,2,2)";
_background = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 96;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,30, 30, 3";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 97;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 98;BA.debugLine="txtNormal = -11276022";
_txtnormal = (int) (-11276022);
 //BA.debugLineNum = 99;BA.debugLine="txtAccent = 0xFFB1E89A";
_txtaccent = ((int)0xffb1e89a);
 //BA.debugLineNum = 100;BA.debugLine="btnDisableText = -12366785";
_btndisabletext = (int) (-12366785);
 break; }
case 8: {
 //BA.debugLineNum = 103;BA.debugLine="Background = -14672868";
_background = (int) (-14672868);
 //BA.debugLineNum = 104;BA.debugLine="BackgroundHeader = xui.Color_ARGB(255,11, 11, 1";
_backgroundheader = _xui.Color_ARGB((int) (255),(int) (11),(int) (11),(int) (11));
 //BA.debugLineNum = 105;BA.debugLine="Background2 = xui.Color_ARGB(255,43, 43, 43)";
_background2 = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 106;BA.debugLine="txtNormal = -1551583";
_txtnormal = (int) (-1551583);
 //BA.debugLineNum = 107;BA.debugLine="txtAccent = 0xFFD77762";
_txtaccent = ((int)0xffd77762);
 //BA.debugLineNum = 108;BA.debugLine="btnDisableText = xui.Color_ARGB(50,192,192,192)";
_btndisabletext = _xui.Color_ARGB((int) (50),(int) (192),(int) (192),(int) (192));
 //BA.debugLineNum = 109;BA.debugLine="DividerColor = xui.Color_Black";
_dividercolor = _xui.Color_Black;
 break; }
default: {
 //BA.debugLineNum = 112;BA.debugLine="Log(\"Theme Else: \" & theme)";
anywheresoftware.b4a.keywords.Common.LogImpl("10027088","Theme Else: "+_theme,0);
 //BA.debugLineNum = 113;BA.debugLine="Background = xui.Color_ARGB(255,53, 69, 85)";
_background = _xui.Color_ARGB((int) (255),(int) (53),(int) (69),(int) (85));
 //BA.debugLineNum = 114;BA.debugLine="BackgroundHeader = -14932432";
_backgroundheader = (int) (-14932432);
 //BA.debugLineNum = 115;BA.debugLine="Background2 = xui.Color_ARGB(255,45, 62, 78)";
_background2 = _xui.Color_ARGB((int) (255),(int) (45),(int) (62),(int) (78));
 break; }
}
;
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public static int[]  _int2argb(anywheresoftware.b4a.BA _ba,int _color) throws Exception{
int[] _res = null;
 //BA.debugLineNum = 169;BA.debugLine="Public Sub Int2ARGB(Color As Int) As Int()";
 //BA.debugLineNum = 170;BA.debugLine="Dim res(4) As Int";
_res = new int[(int) (4)];
;
 //BA.debugLineNum = 171;BA.debugLine="res(0) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (0)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff000000)),(int) (24));
 //BA.debugLineNum = 172;BA.debugLine="res(1) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (1)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff0000)),(int) (16));
 //BA.debugLineNum = 173;BA.debugLine="res(2) = Bit.UnsignedShiftRight(Bit.And(Color, 0x";
_res[(int) (2)] = anywheresoftware.b4a.keywords.Common.Bit.UnsignedShiftRight(anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff00)),(int) (8));
 //BA.debugLineNum = 174;BA.debugLine="res(3) = Bit.And(Color, 0xff)";
_res[(int) (3)] = anywheresoftware.b4a.keywords.Common.Bit.And(_color,((int)0xff));
 //BA.debugLineNum = 175;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private Const mModule As String = \"clrTheme\" 'ign";
_mmodule = "clrTheme";
 //BA.debugLineNum = 10;BA.debugLine="Type tthemecolors (bg, bgheader, bgmenu, txtNorma";
;
 //BA.debugLineNum = 11;BA.debugLine="Public customcolors As tthemecolors";
_customcolors = new sadLogic.OctoTouchController.foss.clrtheme._tthemecolors();
 //BA.debugLineNum = 13;BA.debugLine="Public Background,BackgroundHeader,Background2 As";
_background = 0;
_backgroundheader = 0;
_background2 = 0;
 //BA.debugLineNum = 15;BA.debugLine="Public txtAccent,txtNormal As Int";
_txtaccent = 0;
_txtnormal = 0;
 //BA.debugLineNum = 16;BA.debugLine="Public btnDisableText As Int";
_btndisabletext = 0;
 //BA.debugLineNum = 17;BA.debugLine="Public DividerColor As Int";
_dividercolor = 0;
 //BA.debugLineNum = 19;BA.debugLine="Public ItemsBackgroundColor As Int '--- used in s";
_itemsbackgroundcolor = 0;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _seedcustomclrs(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 131;BA.debugLine="Private Sub SeedCustomClrs";
 //BA.debugLineNum = 133;BA.debugLine="Log(\"Seed clrs\")";
anywheresoftware.b4a.keywords.Common.LogImpl("10092546","Seed clrs",0);
 //BA.debugLineNum = 134;BA.debugLine="CustomColors.Initialize";
_customcolors.Initialize();
 //BA.debugLineNum = 136;BA.debugLine="CustomColors.bg = xui.Color_ARGB(255,2, 2, 2)";
_customcolors.bg /*int*/  = _xui.Color_ARGB((int) (255),(int) (2),(int) (2),(int) (2));
 //BA.debugLineNum = 137;BA.debugLine="CustomColors.bgHeader = xui.Color_ARGB(255,30, 30";
_customcolors.bgheader /*int*/  = _xui.Color_ARGB((int) (255),(int) (30),(int) (30),(int) (30));
 //BA.debugLineNum = 138;BA.debugLine="CustomColors.bgMenu = xui.Color_ARGB(255,43, 43,";
_customcolors.bgmenu /*int*/  = _xui.Color_ARGB((int) (255),(int) (43),(int) (43),(int) (43));
 //BA.debugLineNum = 139;BA.debugLine="CustomColors.txtNormal = xui.Color_white";
_customcolors.txtNormal /*int*/  = _xui.Color_White;
 //BA.debugLineNum = 140;BA.debugLine="CustomColors.txtAcc = xui.Color_LightGray";
_customcolors.txtacc /*int*/  = _xui.Color_LightGray;
 //BA.debugLineNum = 141;BA.debugLine="CustomColors.Disabled = xui.Color_ARGB(50,192,192";
_customcolors.disabled /*int*/  = _xui.Color_ARGB((int) (50),(int) (192),(int) (192),(int) (192));
 //BA.debugLineNum = 142;BA.debugLine="CustomColors.Divider = xui.Color_LightGray";
_customcolors.divider /*int*/  = _xui.Color_LightGray;
 //BA.debugLineNum = 143;BA.debugLine="Main.kvs.Put(gblConst.CUSTOM_THEME_COLORS,CustomC";
mostCurrent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._custom_theme_colors /*String*/ ,(Object)(_customcolors));
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return "";
}
}
