package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class optionscfgseed extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.optionscfgseed");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.optionscfgseed.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.Map _m = null;
public anywheresoftware.b4a.keywords.StringBuilderWrapper _s = null;
public String _txt = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 9;BA.debugLine="Private s As StringBuilder";
_s = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _seedgcode1strun() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Public Sub SeedGCode1StRun() As Map";
 //BA.debugLineNum = 18;BA.debugLine="s.Initialize";
_s.Initialize();
 //BA.debugLineNum = 19;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 21;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 22;BA.debugLine="s.Append(\"# Klipper - Calls a G29 Macro\").Append";
_s.Append("# Klipper - Calls a G29 Macro").Append(__c.CRLF);
 //BA.debugLineNum = 23;BA.debugLine="s.Append(\"M117 Starting...\").Append(CRLF).Append";
_s.Append("M117 Starting...").Append(__c.CRLF).Append("G29").Append(__c.CRLF);
 //BA.debugLineNum = 24;BA.debugLine="txt = \"Auto Level Bed (Call G29 Macro)\"";
_txt = "Auto Level Bed (Call G29 Macro)";
 }else {
 //BA.debugLineNum = 26;BA.debugLine="s.Append(\"# Marlin ONLY\")";
_s.Append("# Marlin ONLY");
 //BA.debugLineNum = 27;BA.debugLine="s.Append(\"M140 S60\").Append(CRLF).Append(\"M117 H";
_s.Append("M140 S60").Append(__c.CRLF).Append("M117 Homing all").Append(__c.CRLF);
 //BA.debugLineNum = 28;BA.debugLine="s.Append(\"G28\").Append(CRLF)";
_s.Append("G28").Append(__c.CRLF);
 //BA.debugLineNum = 29;BA.debugLine="s.Append(\"M420 S0\").Append(CRLF)";
_s.Append("M420 S0").Append(__c.CRLF);
 //BA.debugLineNum = 30;BA.debugLine="s.Append(\"M117 Heating the bed\").Append(CRLF)";
_s.Append("M117 Heating the bed").Append(__c.CRLF);
 //BA.debugLineNum = 31;BA.debugLine="s.Append(\"M190 S60\").Append(CRLF)";
_s.Append("M190 S60").Append(__c.CRLF);
 //BA.debugLineNum = 32;BA.debugLine="s.Append(\"M300 S1000 P500\").Append(CRLF)";
_s.Append("M300 S1000 P500").Append(__c.CRLF);
 //BA.debugLineNum = 33;BA.debugLine="s.Append(\"G29 T\").Append(CRLF)";
_s.Append("G29 T").Append(__c.CRLF);
 //BA.debugLineNum = 34;BA.debugLine="s.Append(\"M140 S0\").Append(CRLF)";
_s.Append("M140 S0").Append(__c.CRLF);
 //BA.debugLineNum = 35;BA.debugLine="s.Append(\"M500\").Append(CRLF)";
_s.Append("M500").Append(__c.CRLF);
 //BA.debugLineNum = 36;BA.debugLine="s.Append(\"M300 S440 P200\").Append(CRLF).Append(\"";
_s.Append("M300 S440 P200").Append(__c.CRLF).Append("M300 S660 P250").Append(__c.CRLF).Append("M300 S880 P300").Append(__c.CRLF);
 //BA.debugLineNum = 37;BA.debugLine="s.Append(\"G28\").Append(CRLF)";
_s.Append("G28").Append(__c.CRLF);
 //BA.debugLineNum = 38;BA.debugLine="txt = \"Auto Level Bed (G29 - Heated 60c)\"";
_txt = "Auto Level Bed (G29 - Heated 60c)";
 };
 //BA.debugLineNum = 41;BA.debugLine="s.Append(\"M117 Bed leveling done!\").Append(CRLF)";
_s.Append("M117 Bed leveling done!").Append(__c.CRLF);
 //BA.debugLineNum = 43;BA.debugLine="m = CreateMap(\"desc\": txt, \"prompt\":\"true\", _";
_m = __c.createMap(new Object[] {(Object)("desc"),(Object)(_txt),(Object)("prompt"),(Object)("true"),(Object)("gcode"),(Object)(_s.ToString()),(Object)("wmenu"),(Object)("false"),(Object)("rmenu"),(Object)("false")});
 //BA.debugLineNum = 45;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
