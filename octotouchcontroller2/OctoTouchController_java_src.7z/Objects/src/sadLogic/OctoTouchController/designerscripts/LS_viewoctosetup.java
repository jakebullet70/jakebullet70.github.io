package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewoctosetup{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _allwidth="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)(0d));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("btngetoctokey"));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("btncheckconnection"));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("pnltext").vw.setLeft((int)(0d));
views.get("pnltext").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnltext").vw.setTop((int)(0d));
views.get("pnltext").vw.setHeight((int)((70d / 100 * height) - (0d)));
views.get("pnlbtns").vw.setLeft((int)((0d * scale)));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - ((0d * scale))));
views.get("pnlbtns").vw.setHeight((int)((30d / 100 * height)));
views.get("pnlbtns").vw.setTop((int)((views.get("pnltext").vw.getTop() + views.get("pnltext").vw.getHeight())));
_allwidth = BA.NumberToString((views.get("pnlbtns").vw.getWidth())-(4d * scale));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlbtns", BA.NumberToString((120d * scale)), BA.NumberToString((6d * scale)), "center"});
;}else{ 
;
views.get("pnltext").vw.setLeft((int)(0d));
views.get("pnltext").vw.setWidth((int)((67d / 100 * width) - (0d)));
views.get("pnltext").vw.setTop((int)(0d));
views.get("pnltext").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlbtns").vw.setLeft((int)((views.get("pnltext").vw.getLeft() + views.get("pnltext").vw.getWidth())));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - ((views.get("pnltext").vw.getLeft() + views.get("pnltext").vw.getWidth()))));
views.get("pnlbtns").vw.setTop((int)(0d));
views.get("pnlbtns").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("btncheckconnection").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btncheckconnection").vw.getWidth() / 2)));
views.get("btngetoctokey").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btngetoctokey").vw.getWidth() / 2)));
;};
views.get("b4xloadingindicator1").vw.setTop((int)((50d / 100 * height) - (views.get("b4xloadingindicator1").vw.getHeight() / 2)));
views.get("b4xloadingindicator1").vw.setLeft((int)((50d / 100 * width) - (views.get("b4xloadingindicator1").vw.getWidth() / 2)));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("txtoctokey"));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("txtprinterdesc"));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("txtprinterip"));
anywheresoftware.b4a.keywords.LayoutBuilder.scaleView(views.get("txtprinterport"));

}
}