package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jsonparsorplugins extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.jsonparsorplugins");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.jsonparsorplugins.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private Const mModule As String = \"JsonParsorPlug";
_mmodule = "JsonParsorPlugins";
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public boolean  _isoctoklipperrunning(String _s) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.List _plugins = null;
anywheresoftware.b4a.objects.collections.Map _colplugins = null;
String _b = "";
 //BA.debugLineNum = 18;BA.debugLine="Public Sub IsOctoKlipperRunning(s As String) As Bo";
 //BA.debugLineNum = 20;BA.debugLine="If s.Contains(\"OctoKlipper\") Then";
if (_s.contains("OctoKlipper")) { 
 //BA.debugLineNum = 23;BA.debugLine="Dim parser As JSONParser : 	parser.Initialize(s)";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 23;BA.debugLine="Dim parser As JSONParser : 	parser.Initialize(s)";
_parser.Initialize(_s);
 //BA.debugLineNum = 24;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 25;BA.debugLine="Dim plugins As List = root.Get(\"plugins\")";
_plugins = new anywheresoftware.b4a.objects.collections.List();
_plugins = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_root.Get((Object)("plugins"))));
 //BA.debugLineNum = 27;BA.debugLine="For Each colplugins As Map In plugins";
_colplugins = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group6 = _plugins;
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_colplugins = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group6.Get(index6)));
 //BA.debugLineNum = 28;BA.debugLine="If colplugins.Get(\"name\") = \"OctoKlipper\" Then";
if ((_colplugins.Get((Object)("name"))).equals((Object)("OctoKlipper"))) { 
 //BA.debugLineNum = 29;BA.debugLine="Dim b As String = colplugins.Get(\"enabled\")";
_b = BA.ObjectToString(_colplugins.Get((Object)("enabled")));
 //BA.debugLineNum = 30;BA.debugLine="If b.ToLowerCase = \"true\" Then";
if ((_b.toLowerCase()).equals("true")) { 
 //BA.debugLineNum = 31;BA.debugLine="Return True";
if (true) return __c.True;
 };
 };
 }
};
 };
 //BA.debugLineNum = 37;BA.debugLine="Return False '--- not installed";
if (true) return __c.False;
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
