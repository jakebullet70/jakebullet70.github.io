package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgsetupweather extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgsetupweather");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgsetupweather.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnsetdefaultcity = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnremove = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnadd = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chkmetric = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chkcelsius = null;
public b4a.example3.customlistview _lstlocations = null;
public String _defcity = "";
public String _selectediconsset = "";
public sadLogic.HomeCentral.b4xcombobox _cboiconsets = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlcont = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtns = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public sadLogic.HomeCentral.sadclvselections _lvs = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public void  _btnadd_click() throws Exception{
ResumableSub_btnAdd_Click rsub = new ResumableSub_btnAdd_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnAdd_Click extends BA.ResumableSub {
public ResumableSub_btnAdd_Click(sadLogic.HomeCentral.dlgsetupweather parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetupweather parent;
sadLogic.HomeCentral.sadb4xinputtemplate _t = null;
sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper2 = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 123;BA.debugLine="Dim t As sadB4XInputTemplate : t.Initialize";
_t = new sadLogic.HomeCentral.sadb4xinputtemplate();
 //BA.debugLineNum = 123;BA.debugLine="Dim t As sadB4XInputTemplate : t.Initialize";
_t._initialize /*String*/ (ba);
 //BA.debugLineNum = 124;BA.debugLine="mpage.Dialog2.Initialize(mpage.Root)";
parent._mpage._dialog2 /*sadLogic.HomeCentral.b4xdialog*/ ._initialize /*String*/ (ba,parent._mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 126;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 10;
this.catchState = 9;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 9;
 //BA.debugLineNum = 127;BA.debugLine="Dim dlgHelper2 As sadB4XDialogHelper";
_dlghelper2 = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 128;BA.debugLine="dlgHelper2.Initialize(mpage.Dialog2)";
_dlghelper2._initialize /*String*/ (ba,parent._mpage._dialog2 /*sadLogic.HomeCentral.b4xdialog*/ );
 //BA.debugLineNum = 130;BA.debugLine="dlgHelper2.ThemeDialogForm(\"Enter city\")";
_dlghelper2._themedialogform /*String*/ ((Object)("Enter city"));
 //BA.debugLineNum = 135;BA.debugLine="Dim rs As ResumableSub = mpage.Dialog2.ShowTempl";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mpage._dialog2 /*sadLogic.HomeCentral.b4xdialog*/ ._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_t),(Object)("OK"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 136;BA.debugLine="dlgHelper2.ThemeDialogBtnsResize";
_dlghelper2._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 137;BA.debugLine="clrTheme.SetThemesadB4xInputTemplate(t,\"City nam";
parent._clrtheme._setthemesadb4xinputtemplate /*String*/ (ba,_t,"City name");
 //BA.debugLineNum = 139;BA.debugLine="Wait For (rs) Complete (i As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 11;
return;
case 11:
//C
this.state = 4;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 140;BA.debugLine="If i = XUI.DialogResponse_Cancel Then";
if (true) break;

case 4:
//if
this.state = 7;
if (_i==parent._xui.DialogResponse_Cancel) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 141;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 7:
//C
this.state = 10;
;
 //BA.debugLineNum = 144;BA.debugLine="lstLocations.AddTextItem(t.Text,t.Text)";
parent._lstlocations._addtextitem((Object)(_t._text /*String*/ ),(Object)(_t._text /*String*/ ));
 if (true) break;

case 9:
//C
this.state = 10;
this.catchState = 0;
 //BA.debugLineNum = 147;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("24051738",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 10:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public void  _btnremove_click() throws Exception{
ResumableSub_btnRemove_Click rsub = new ResumableSub_btnRemove_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnRemove_Click extends BA.ResumableSub {
public ResumableSub_btnRemove_Click(sadLogic.HomeCentral.dlgsetupweather parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetupweather parent;
sadLogic.HomeCentral.dlgthemedmsgbox _o = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 155;BA.debugLine="If lstLocations.Size = 1 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._lstlocations._getsize()==1) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 156;BA.debugLine="guiHelpers.Show_toast(\"Cannot delete last city\")";
parent._guihelpers._show_toast /*String*/ (ba,"Cannot delete last city");
 //BA.debugLineNum = 157;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 160;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o = new sadLogic.HomeCentral.dlgthemedmsgbox();
 //BA.debugLineNum = 160;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 161;BA.debugLine="Wait For (o.Show(\"Are you sure you want to delete";
parent.__c.WaitFor("complete", ba, this, _o._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Are you sure you want to delete this city?","Question?","YES","","CANCEL"));
this.state = 9;
return;
case 9:
//C
this.state = 5;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 162;BA.debugLine="If i = XUI.DialogResponse_Cancel Then";
if (true) break;

case 5:
//if
this.state = 8;
if (_i==parent._xui.DialogResponse_Cancel) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 163;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 166;BA.debugLine="lstLocations.RemoveAt(lvs.SelectedItems.AsList.Ge";
parent._lstlocations._removeat((int)(BA.ObjectToNumber(parent._lvs._selecteditems /*sadLogic.HomeCentral.b4xset*/ ._aslist /*anywheresoftware.b4a.objects.collections.List*/ ().Get((int) (0)))));
 //BA.debugLineNum = 167;BA.debugLine="guiHelpers.Show_toast(\"City deleted\")";
parent._guihelpers._show_toast /*String*/ (ba,"City deleted");
 //BA.debugLineNum = 169;BA.debugLine="lvs.SelectedItems.Clear";
parent._lvs._selecteditems /*sadLogic.HomeCentral.b4xset*/ ._clear /*String*/ ();
 //BA.debugLineNum = 170;BA.debugLine="lvs.ItemClicked(0)";
parent._lvs._itemclicked /*String*/ ((int) (0));
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _btnsetdefaultcity_click() throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Private Sub btnSetDefaultCity_Click";
 //BA.debugLineNum = 176;BA.debugLine="DefCity = lstLocations.GetValue( lvs.SelectedItem";
_defcity = BA.ObjectToString(_lstlocations._getvalue((int)(BA.ObjectToNumber(_lvs._selecteditems /*sadLogic.HomeCentral.b4xset*/ ._aslist /*anywheresoftware.b4a.objects.collections.List*/ ().Get((int) (0))))));
 //BA.debugLineNum = 177;BA.debugLine="guiHelpers.Show_toast(DefCity & \" - set as defaul";
_guihelpers._show_toast /*String*/ (ba,_defcity+" - set as default city");
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _cboiconsets_selectedindexchanged(int _index) throws Exception{
 //BA.debugLineNum = 199;BA.debugLine="Private Sub cboIconSets_SelectedIndexChanged (Inde";
 //BA.debugLineNum = 200;BA.debugLine="SetIconSet(Index)";
_seticonset(_index);
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 13;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 14;BA.debugLine="Private btnSetDefaultCity,btnRemove,btnAdd As B4X";
_btnsetdefaultcity = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnremove = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnadd = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private chkMetric,chkCelsius As CheckBox";
_chkmetric = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
_chkcelsius = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lstLocations As CustomListView";
_lstlocations = new b4a.example3.customlistview();
 //BA.debugLineNum = 18;BA.debugLine="Private DefCity, SelectedIconsSet As String = \"\"";
_defcity = "";
_selectediconsset = "";
 //BA.debugLineNum = 20;BA.debugLine="Private cboIconSets As B4XComboBox";
_cboiconsets = new sadLogic.HomeCentral.b4xcombobox();
 //BA.debugLineNum = 21;BA.debugLine="Private pnlCont,pnlBtns As B4XView";
_pnlcont = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbtns = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 23;BA.debugLine="Private lvs As sadClvSelections";
_lvs = new sadLogic.HomeCentral.sadclvselections();
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dialog) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 29;BA.debugLine="Public Sub Initialize(Dialog As B4XDialog)";
 //BA.debugLineNum = 30;BA.debugLine="dlg = Dialog";
_dlg = _dialog;
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public String  _initiconsets() throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Private Sub InitIconSets";
 //BA.debugLineNum = 183;BA.debugLine="cboIconSets.cmbBox.AddAll(Array As String(\"Icons";
_cboiconsets._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Icons - Bright and shiny 1","Icons - Bright and shiny 2","Icons - Material design","Icons - Material design (Color)","Icons - API (Color)"}));
 //BA.debugLineNum = 186;BA.debugLine="Select Case gblConst.WEATHERicons";
switch (BA.switchObjectToInt(_gblconst._weathericons /*String*/ ,"cc01","ww01","ms01","tv03","api")) {
case 0: {
 //BA.debugLineNum = 187;BA.debugLine="Case \"cc01\"    : cboIconSets.SelectedIndex = 0";
_cboiconsets._setselectedindex /*int*/ ((int) (0));
 break; }
case 1: {
 //BA.debugLineNum = 188;BA.debugLine="Case \"ww01\"   : cboIconSets.SelectedIndex = 1";
_cboiconsets._setselectedindex /*int*/ ((int) (1));
 break; }
case 2: {
 //BA.debugLineNum = 189;BA.debugLine="Case \"ms01\"   : cboIconSets.SelectedIndex = 2";
_cboiconsets._setselectedindex /*int*/ ((int) (2));
 break; }
case 3: {
 //BA.debugLineNum = 190;BA.debugLine="Case \"tv03\"	   : cboIconSets.SelectedIndex = 3";
_cboiconsets._setselectedindex /*int*/ ((int) (3));
 break; }
case 4: {
 //BA.debugLineNum = 191;BA.debugLine="Case \"api\"	   : cboIconSets.SelectedIndex = 4";
_cboiconsets._setselectedindex /*int*/ ((int) (4));
 break; }
}
;
 //BA.debugLineNum = 194;BA.debugLine="SetIconSet(cboIconSets.SelectedIndex)";
_seticonset(_cboiconsets._getselectedindex /*int*/ ());
 //BA.debugLineNum = 195;BA.debugLine="SelectedIconsSet = gblConst.WEATHERicons";
_selectediconsset = _gblconst._weathericons /*String*/ ;
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public String  _loaddata() throws Exception{
String[] _ll = null;
String _city = "";
 //BA.debugLineNum = 82;BA.debugLine="Private Sub LoadData()";
 //BA.debugLineNum = 84;BA.debugLine="Dim ll() As String = Regex.Split(\";;\", Main.kvs.G";
_ll = __c.Regex.Split(";;",BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_city_list /*String*/ )));
 //BA.debugLineNum = 86;BA.debugLine="lstLocations.Clear";
_lstlocations._clear();
 //BA.debugLineNum = 87;BA.debugLine="lstLocations.DefaultTextColor = clrTheme.txtNorma";
_lstlocations._defaulttextcolor = _clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 90;BA.debugLine="For Each city As String In ll";
{
final String[] group4 = _ll;
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_city = group4[index4];
 //BA.debugLineNum = 91;BA.debugLine="lstLocations.AddTextItem(city,city)";
_lstlocations._addtextitem((Object)(_city),(Object)(_city));
 }
};
 //BA.debugLineNum = 94;BA.debugLine="DefCity = Main.kvs.Get(gblConst.INI_WEATHER_DEFAU";
_defcity = BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_default_city /*String*/ ));
 //BA.debugLineNum = 95;BA.debugLine="chkCelsius.Checked = Main.kvs.Get(gblConst.INI_WE";
_chkcelsius.setChecked(BA.ObjectToBoolean(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_use_celsius /*String*/ )));
 //BA.debugLineNum = 96;BA.debugLine="chkMetric.Checked = Main.kvs.Get(gblConst.INI_WEA";
_chkmetric.setChecked(BA.ObjectToBoolean(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_weather_use_metric /*String*/ )));
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _lstlocations_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 77;BA.debugLine="Private Sub lstLocations_ItemClick (Index As Int,";
 //BA.debugLineNum = 78;BA.debugLine="lvs.ItemClicked(Index)";
_lvs._itemclicked /*String*/ (_index);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public String  _savedata() throws Exception{
String _dd = "";
int _x = 0;
 //BA.debugLineNum = 100;BA.debugLine="Private Sub SaveData()";
 //BA.debugLineNum = 102;BA.debugLine="Dim dd As String";
_dd = "";
 //BA.debugLineNum = 103;BA.debugLine="For x = 0 To lstLocations.Size - 1";
{
final int step2 = 1;
final int limit2 = (int) (_lstlocations._getsize()-1);
_x = (int) (0) ;
for (;_x <= limit2 ;_x = _x + step2 ) {
 //BA.debugLineNum = 104;BA.debugLine="dd = dd & lstLocations.GetValue(x)& \";;\"";
_dd = _dd+BA.ObjectToString(_lstlocations._getvalue(_x))+";;";
 }
};
 //BA.debugLineNum = 106;BA.debugLine="dd = strHelpers.TrimLast(dd,\";;\")";
_dd = _strhelpers._trimlast /*String*/ (ba,_dd,";;");
 //BA.debugLineNum = 107;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_CITY_LIST,dd)";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_weather_city_list /*String*/ ,(Object)(_dd));
 //BA.debugLineNum = 110;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_DEFAULT_CITY,De";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_weather_default_city /*String*/ ,(Object)(_defcity));
 //BA.debugLineNum = 111;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_USE_CELSIUS,chk";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_weather_use_celsius /*String*/ ,(Object)(_chkcelsius.getChecked()));
 //BA.debugLineNum = 112;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_USE_METRIC,chkM";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_weather_use_metric /*String*/ ,(Object)(_chkmetric.getChecked()));
 //BA.debugLineNum = 114;BA.debugLine="gblConst.WEATHERicons = SelectedIconsSet";
_gblconst._weathericons /*String*/  = _selectediconsset;
 //BA.debugLineNum = 115;BA.debugLine="Main.kvs.Put(gblConst.INI_WEATHER_ICONS_PATH,Sele";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_weather_icons_path /*String*/ ,(Object)(_selectediconsset));
 //BA.debugLineNum = 117;BA.debugLine="CallSubDelayed(mpage.oPageCurrent,\"Build_Side_Men";
__c.CallSubDelayed(ba,_mpage._opagecurrent /*Object*/ ,"Build_Side_Menu");
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _seticonset(int _i) throws Exception{
 //BA.debugLineNum = 203;BA.debugLine="Private Sub SetIconSet(i As Int)";
 //BA.debugLineNum = 204;BA.debugLine="Select Case i";
switch (_i) {
case 0: {
 //BA.debugLineNum = 205;BA.debugLine="Case 0 : SelectedIconsSet = \"cc01\"";
_selectediconsset = "cc01";
 break; }
case 1: {
 //BA.debugLineNum = 206;BA.debugLine="Case 1 : SelectedIconsSet = \"ww01\"";
_selectediconsset = "ww01";
 break; }
case 2: {
 //BA.debugLineNum = 207;BA.debugLine="Case 2 : SelectedIconsSet = \"ms01\"";
_selectediconsset = "ms01";
 break; }
case 3: {
 //BA.debugLineNum = 208;BA.debugLine="Case 3 : SelectedIconsSet = \"tv03\"";
_selectediconsset = "tv03";
 break; }
case 4: {
 //BA.debugLineNum = 209;BA.debugLine="Case 4 : SelectedIconsSet = \"api\"";
_selectediconsset = "api";
 break; }
}
;
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgsetupweather parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetupweather parent;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 36;BA.debugLine="dlg.Initialize((B4XPages.MainPage.Root))";
parent._dlg._initialize /*String*/ (ba,(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ));
 //BA.debugLineNum = 37;BA.debugLine="dlgHelper.Initialize(dlg)";
parent._dlghelper._initialize /*String*/ (ba,parent._dlg);
 //BA.debugLineNum = 39;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 40;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,  430dip,  450dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (430)),parent.__c.DipToCurrent((int) (450)));
 //BA.debugLineNum = 41;BA.debugLine="p.LoadLayout(\"viewSetupWeather\")";
_p.LoadLayout("viewSetupWeather",ba);
 //BA.debugLineNum = 45;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnAdd,btnR";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnadd.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnremove.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnsetdefaultcity.getObject()))});
 //BA.debugLineNum = 46;BA.debugLine="guiHelpers.ReSkinB4XComboBox(Array As B4XComboBox";
parent._guihelpers._reskinb4xcombobox /*String*/ (ba,new sadLogic.HomeCentral.b4xcombobox[]{parent._cboiconsets});
 //BA.debugLineNum = 47;BA.debugLine="guiHelpers.SetCBDrawable(chkCelsius, clrTheme.txt";
parent._guihelpers._setcbdrawable /*String*/ (ba,parent._chkcelsius,parent._clrtheme._txtnormal /*int*/ ,(int) (1),parent._clrtheme._txtnormal /*int*/ ,BA.ObjectToString(parent.__c.Chr((int) (8730))),parent.__c.Colors.LightGray,parent.__c.DipToCurrent((int) (32)),parent.__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 48;BA.debugLine="guiHelpers.SetCBDrawable(chkMetric, clrTheme.txtN";
parent._guihelpers._setcbdrawable /*String*/ (ba,parent._chkmetric,parent._clrtheme._txtnormal /*int*/ ,(int) (1),parent._clrtheme._txtnormal /*int*/ ,BA.ObjectToString(parent.__c.Chr((int) (8730))),parent.__c.Colors.LightGray,parent.__c.DipToCurrent((int) (32)),parent.__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 50;BA.debugLine="LoadData";
parent._loaddata();
 //BA.debugLineNum = 51;BA.debugLine="InitIconSets";
parent._initiconsets();
 //BA.debugLineNum = 53;BA.debugLine="lvs.Initialize(lstLocations)";
parent._lvs._initialize /*String*/ (ba,parent._lstlocations);
 //BA.debugLineNum = 54;BA.debugLine="lvs.Mode = lvs.MODE_SINGLE_ITEM_PERMANENT";
parent._lvs._setmode /*int*/ (parent._lvs._mode_single_item_permanent /*int*/ );
 //BA.debugLineNum = 55;BA.debugLine="clrTheme.SetThemeCustomListView(lstLocations)";
parent._clrtheme._setthemecustomlistview /*String*/ (ba,parent._lstlocations);
 //BA.debugLineNum = 56;BA.debugLine="lvs.SelectionColor = lstLocations.PressedColor";
parent._lvs._selectioncolor /*int*/  = parent._lstlocations._pressedcolor;
 //BA.debugLineNum = 57;BA.debugLine="lvs.ItemClicked(0)";
parent._lvs._itemclicked /*String*/ ((int) (0));
 //BA.debugLineNum = 59;BA.debugLine="chkCelsius.TextColor = clrTheme.txtNormal";
parent._chkcelsius.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 60;BA.debugLine="chkMetric.TextColor = clrTheme.txtNormal";
parent._chkmetric.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 61;BA.debugLine="guiHelpers.SetCBDrawable(chkCelsius, clrTheme.txt";
parent._guihelpers._setcbdrawable /*String*/ (ba,parent._chkcelsius,parent._clrtheme._txtnormal /*int*/ ,(int) (1),parent._clrtheme._txtaccent /*int*/ ,BA.ObjectToString(parent.__c.Chr((int) (8730))),parent.__c.Colors.LightGray,parent.__c.DipToCurrent((int) (32)),parent.__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 62;BA.debugLine="guiHelpers.SetCBDrawable(chkMetric, clrTheme.txtN";
parent._guihelpers._setcbdrawable /*String*/ (ba,parent._chkmetric,parent._clrtheme._txtnormal /*int*/ ,(int) (1),parent._clrtheme._txtaccent /*int*/ ,BA.ObjectToString(parent.__c.Chr((int) (8730))),parent.__c.Colors.LightGray,parent.__c.DipToCurrent((int) (32)),parent.__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 64;BA.debugLine="dlgHelper.ThemeDialogForm(\"Weather Setup\")";
parent._dlghelper._themedialogform /*String*/ ((Object)("Weather Setup"));
 //BA.debugLineNum = 65;BA.debugLine="Dim rs As ResumableSub = dlg.ShowCustom(p, \"SAVE\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dlg._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("SAVE"),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 66;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
parent._dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 67;BA.debugLine="dlgHelper.NoCloseOn2ndDialog";
parent._dlghelper._nocloseon2nddialog /*String*/ ();
 //BA.debugLineNum = 69;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 70;BA.debugLine="If Result = XUI.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 71;BA.debugLine="SaveData";
parent._savedata();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
