package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgoctopsusetup extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgoctopsusetup");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgoctopsusetup.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _lblswitch = null;
public sadLogic.OctoTouchController.foss.b4xfloattextfield _txtprinterip = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public sadLogic.OctoTouchController.foss.b4xswitch _swpsuocto = null;
public sadLogic.OctoTouchController.foss.b4xswitch _swpsuctrlonoff = null;
public sadLogic.OctoTouchController.foss.b4xswitch _swsonoff = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblpsuinfo2 = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblsonoffinfo2 = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _buildgui() throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 97;BA.debugLine="pnlMain.Color = clrTheme.Background";
_pnlmain.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 98;BA.debugLine="guiHelpers.SetTextColorB4XFloatTextField(Array As";
_guihelpers._settextcolorb4xfloattextfield /*String*/ (ba,new sadLogic.OctoTouchController.foss.b4xfloattextfield[]{_txtprinterip});
 //BA.debugLineNum = 99;BA.debugLine="Try";
try { //BA.debugLineNum = 100;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblSono";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblsonoffinfo2._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_lblpsuinfo2._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (),_lblswitch});
 } 
       catch (Exception e6) {
			ba.setLastException(e6); //BA.debugLineNum = 102;BA.debugLine="Log(LastException)";
__c.LogImpl("23330823",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 105;BA.debugLine="txtPrinterIP.HintText = \"Tasmota IP\"";
_txtprinterip._hinttext /*String*/  = "Tasmota IP";
 //BA.debugLineNum = 106;BA.debugLine="swPSUocto.Value = True";
_swpsuocto._setvalue /*boolean*/ (__c.True);
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private const mModule As String = \"dlgOctoPsuSetu";
_mmodule = "dlgOctoPsuSetup";
 //BA.debugLineNum = 12;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 13;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 14;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 16;BA.debugLine="Private lblSwitch As B4XView";
_lblswitch = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private txtPrinterIP As B4XFloatTextField";
_txtprinterip = new sadLogic.OctoTouchController.foss.b4xfloattextfield();
 //BA.debugLineNum = 19;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 23;BA.debugLine="Private swPSUocto,swPsuCtrlOnOff,swSonoff As B4XS";
_swpsuocto = new sadLogic.OctoTouchController.foss.b4xswitch();
_swpsuctrlonoff = new sadLogic.OctoTouchController.foss.b4xswitch();
_swsonoff = new sadLogic.OctoTouchController.foss.b4xswitch();
 //BA.debugLineNum = 25;BA.debugLine="Private lblPSUinfo2 As AutoTextSizeLabel";
_lblpsuinfo2 = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 26;BA.debugLine="Private lblSonoffInfo2 As AutoTextSizeLabel";
_lblsonoffinfo2 = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _createdefaultoctopowercfg() throws Exception{
 //BA.debugLineNum = 110;BA.debugLine="Public Sub CreateDefaultOctoPowerCfg";
 //BA.debugLineNum = 112;BA.debugLine="Main.kvs.Put(gblConst.PWR_CTRL_ON,False)";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_ctrl_on /*String*/ ,(Object)(__c.False));
 //BA.debugLineNum = 113;BA.debugLine="Main.kvs.Put(gblConst.PWR_PSU_PLUGIN,True)";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_psu_plugin /*String*/ ,(Object)(__c.True));
 //BA.debugLineNum = 114;BA.debugLine="Main.kvs.Put(gblConst.PWR_SONOFF_PLUGIN,False)";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_sonoff_plugin /*String*/ ,(Object)(__c.False));
 //BA.debugLineNum = 115;BA.debugLine="Main.kvs.Put(gblConst.PWR_SONOFF_IP,\"\")";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_sonoff_ip /*String*/ ,(Object)(""));
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,String _title) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 31;BA.debugLine="Public Sub Initialize( title As String) As Object";
 //BA.debugLineNum = 33;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 34;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public String  _invalidateconnection() throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="Private Sub InvalidateConnection";
 //BA.debugLineNum = 157;BA.debugLine="txtPrinterIP.mBase.Visible = Not (swPSUocto.Value";
_txtprinterip._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.Not(_swpsuocto._getvalue /*boolean*/ ()));
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public String  _readsettingsfile() throws Exception{
 //BA.debugLineNum = 147;BA.debugLine="Private Sub ReadSettingsFile";
 //BA.debugLineNum = 149;BA.debugLine="txtPrinterIP.Text = Main.kvs.GetDefault(gblConst.";
_txtprinterip._settext /*String*/ (BA.ObjectToString(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ (_gblconst._pwr_sonoff_ip /*String*/ ,(Object)(""))));
 //BA.debugLineNum = 150;BA.debugLine="swSonoff.Value = Main.kvs.Get(gblConst.PWR_SONOFF";
_swsonoff._setvalue /*boolean*/ ((BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._get /*Object*/ (_gblconst._pwr_sonoff_plugin /*String*/ ))));
 //BA.debugLineNum = 151;BA.debugLine="swPSUocto.Value = Main.kvs.Get(gblConst.PWR_PSU_P";
_swpsuocto._setvalue /*boolean*/ ((BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._get /*Object*/ (_gblconst._pwr_psu_plugin /*String*/ ))));
 //BA.debugLineNum = 152;BA.debugLine="swPsuCtrlOnOff.Value = Main.kvs.Get(gblConst.PWR_";
_swpsuctrlonoff._setvalue /*boolean*/ ((BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._get /*Object*/ (_gblconst._pwr_ctrl_on /*String*/ ))));
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
public String  _save_settings() throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Private Sub Save_settings";
 //BA.debugLineNum = 122;BA.debugLine="guiHelpers.Show_toast(gblConst.DATA_SAVED,2500)";
_guihelpers._show_toast /*String*/ (ba,_gblconst._data_saved /*String*/ ,(int) (2500));
 //BA.debugLineNum = 123;BA.debugLine="Main.kvs.Put(gblConst.PWR_CTRL_ON,swPsuCtrlOnOff.";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_ctrl_on /*String*/ ,(Object)(_swpsuctrlonoff._getvalue /*boolean*/ ()));
 //BA.debugLineNum = 124;BA.debugLine="Main.kvs.Put(gblConst.PWR_PSU_PLUGIN,swPSUocto.Va";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_psu_plugin /*String*/ ,(Object)(_swpsuocto._getvalue /*boolean*/ ()));
 //BA.debugLineNum = 125;BA.debugLine="Main.kvs.Put(gblConst.PWR_SONOFF_PLUGIN,swSonoff.";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_sonoff_plugin /*String*/ ,(Object)(_swsonoff._getvalue /*boolean*/ ()));
 //BA.debugLineNum = 126;BA.debugLine="Main.kvs.Put(gblConst.PWR_SONOFF_IP,txtPrinterIP.";
_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._put /*String*/ (_gblconst._pwr_sonoff_ip /*String*/ ,(Object)(_txtprinterip._gettext /*String*/ ()+""));
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgoctopsusetup parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgoctopsusetup parent;
sadLogic.OctoTouchController.foss.dlgmsgbox _mb = null;
sadLogic.OctoTouchController.foss.guimsgs _gui = null;
int _result = 0;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
float _w = 0f;
float _h = 0f;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 42;BA.debugLine="If Main.kvs.GetDefault(\"psuWarning\",False).As(Boo";
if (true) break;

case 1:
//if
this.state = 4;
if ((BA.ObjectToBoolean(parent._main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ ("psuWarning",(Object)(parent.__c.False))))==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 43;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.foss.dlgmsgbox();
 //BA.debugLineNum = 44;BA.debugLine="mb.Initialize(mMainObj.root,\"Information\",IIf(gu";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Information",(float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (500)))) : ((Object)(parent._guihelpers._gwidth /*float*/ -parent.__c.DipToCurrent((int) (20))))))),(float) (parent.__c.DipToCurrent((int) (240))),parent.__c.False);
 //BA.debugLineNum = 45;BA.debugLine="mb.SetAsOptionalMsgBox(\"psuWarning\")";
_mb._setasoptionalmsgbox /*String*/ ("psuWarning");
 //BA.debugLineNum = 46;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.OctoTouchController.foss.guimsgs();
 //BA.debugLineNum = 46;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 47;BA.debugLine="Wait For (mb.Show(gui.GetOctoPluginWarningTxt, _";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_gui._getoctopluginwarningtxt /*String*/ (),parent._gblconst._mb_icon_info /*String*/ ,"","","OK"));
this.state = 21;
return;
case 21:
//C
this.state = 4;
_result = (Integer) result[0];
;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 52;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 53;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 54;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 56;BA.debugLine="Dim w,h As Float";
_w = 0f;
_h = 0f;
 //BA.debugLineNum = 57;BA.debugLine="If guiHelpers.gScreenSizeAprox > 6.5 Then";
if (true) break;

case 5:
//if
this.state = 16;
if (parent._guihelpers._gscreensizeaprox /*double*/ >6.5) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 16;
 //BA.debugLineNum = 58;BA.debugLine="w = 540dip : h = 310dip";
_w = (float) (parent.__c.DipToCurrent((int) (540)));
 //BA.debugLineNum = 58;BA.debugLine="w = 540dip : h = 310dip";
_h = (float) (parent.__c.DipToCurrent((int) (310)));
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 60;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 10:
//if
this.state = 15;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 12;
}else {
this.state = 14;
}if (true) break;

case 12:
//C
this.state = 15;
 //BA.debugLineNum = 61;BA.debugLine="w = 420dip";
_w = (float) (parent.__c.DipToCurrent((int) (420)));
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 63;BA.debugLine="w = guiHelpers.gWidth *.95";
_w = (float) (parent._guihelpers._gwidth /*float*/ *.95);
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 65;BA.debugLine="h = 240dip";
_h = (float) (parent.__c.DipToCurrent((int) (240)));
 if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 68;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 69;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, w, h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_w),(int) (_h));
 //BA.debugLineNum = 70;BA.debugLine="p.LoadLayout(\"viewPsuSetup\")";
_p.LoadLayout("viewPsuSetup",ba);
 //BA.debugLineNum = 72;BA.debugLine="BuildGUI";
parent._buildgui();
 //BA.debugLineNum = 74;BA.debugLine="dlgHelper.ThemeDialogForm( mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 75;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"S";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("SAVE"),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 76;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 77;BA.debugLine="ReadSettingsFile";
parent._readsettingsfile();
 //BA.debugLineNum = 78;BA.debugLine="InvalidateConnection";
parent._invalidateconnection();
 //BA.debugLineNum = 80;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 82;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 22;
return;
case 22:
//C
this.state = 17;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 84;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 17:
//if
this.state = 20;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 19;
}if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 85;BA.debugLine="Save_settings";
parent._save_settings();
 //BA.debugLineNum = 86;BA.debugLine="CallSub(mMainObj.oPageCurrent,\"Set_focus\")";
parent.__c.CallSubNew(ba,parent._mmainobj._opagecurrent /*Object*/ ,"Set_focus");
 if (true) break;

case 20:
//C
this.state = -1;
;
 //BA.debugLineNum = 89;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 90;BA.debugLine="CallSubDelayed(mMainObj,\"PopupPluginOptionMenu\")";
parent.__c.CallSubDelayed(ba,(Object)(parent._mmainobj),"PopupPluginOptionMenu");
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _swpsuocto_valuechanged(boolean _value) throws Exception{
 //BA.debugLineNum = 165;BA.debugLine="Private Sub swPSUocto_ValueChanged (Value As Boole";
 //BA.debugLineNum = 166;BA.debugLine="swSonoff.Value = Not (Value)";
_swsonoff._setvalue /*boolean*/ (__c.Not(_value));
 //BA.debugLineNum = 167;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _swsonoff_valuechanged(boolean _value) throws Exception{
 //BA.debugLineNum = 161;BA.debugLine="Private Sub swSonoff_ValueChanged (Value As Boolea";
 //BA.debugLineNum = 162;BA.debugLine="swPSUocto.Value = Not (Value)";
_swpsuocto._setvalue /*boolean*/ (__c.Not(_value));
 //BA.debugLineNum = 163;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public String  _txtprinterip_focuschanged(boolean _hasfocus) throws Exception{
 //BA.debugLineNum = 137;BA.debugLine="Private Sub txtPrinterIP_FocusChanged (HasFocus As";
 //BA.debugLineNum = 138;BA.debugLine="If HasFocus Then";
if (_hasfocus) { 
 //BA.debugLineNum = 139;BA.debugLine="txtPrinterIP.RequestFocusAndShowKeyboard";
_txtprinterip._requestfocusandshowkeyboard /*String*/ ();
 }else {
 };
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return "";
}
public String  _txtprinterip_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Private Sub txtPrinterIP_TextChanged (Old As Strin";
 //BA.debugLineNum = 133;BA.debugLine="If swPSUocto.Value = True Then";
if (_swpsuocto._getvalue /*boolean*/ ()==__c.True) { 
 //BA.debugLineNum = 134;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 };
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
