package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class listviewselector extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.listviewselector");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.listviewselector.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _selectedindex = 0;
public anywheresoftware.b4a.objects.ListViewWrapper _lv = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 13;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 14;BA.debugLine="Public selectedIndex As Int = -1";
_selectedindex = (int) (-1);
 //BA.debugLineNum = 15;BA.debugLine="Private lv As ListView";
_lv = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _clicklistviewitem(int _index) throws Exception{
anywheresoftware.b4j.object.JavaObject _jolv = null;
int _firstvisible = 0;
int _relativeindex = 0;
anywheresoftware.b4j.object.JavaObject _itemview = null;
long _itemid = 0L;
 //BA.debugLineNum = 34;BA.debugLine="Sub ClickListViewItem(index As Int)";
 //BA.debugLineNum = 35;BA.debugLine="Dim joLV As JavaObject = lv";
_jolv = new anywheresoftware.b4j.object.JavaObject();
_jolv = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_lv.getObject()));
 //BA.debugLineNum = 36;BA.debugLine="Dim firstVisible As Int = joLV.RunMethod(\"getFirs";
_firstvisible = (int)(BA.ObjectToNumber(_jolv.RunMethod("getFirstVisiblePosition",(Object[])(__c.Null))));
 //BA.debugLineNum = 37;BA.debugLine="Dim relativeIndex As Int = index - firstVisible";
_relativeindex = (int) (_index-_firstvisible);
 //BA.debugLineNum = 39;BA.debugLine="If relativeIndex < 0 Or relativeIndex >= joLV.Run";
if (_relativeindex<0 || _relativeindex>=(double)(BA.ObjectToNumber(_jolv.RunMethod("getChildCount",(Object[])(__c.Null))))) { 
 //BA.debugLineNum = 41;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 44;BA.debugLine="Dim itemView As JavaObject = joLV.RunMethod(\"getC";
_itemview = new anywheresoftware.b4j.object.JavaObject();
_itemview = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jolv.RunMethod("getChildAt",new Object[]{(Object)(_relativeindex)})));
 //BA.debugLineNum = 45;BA.debugLine="If itemView.IsInitialized Then";
if (_itemview.IsInitialized()) { 
 //BA.debugLineNum = 47;BA.debugLine="Dim itemId As Long = index";
_itemid = (long) (_index);
 //BA.debugLineNum = 49;BA.debugLine="joLV.RunMethod(\"performItemClick\", Array(itemVie";
_jolv.RunMethod("performItemClick",new Object[]{(Object)(_itemview.getObject()),(Object)(_index),(Object)(_itemid)});
 };
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.ListViewWrapper _lst) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4a.objects.drawable.ColorDrawable _cdw = null;
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(lst As ListView)";
 //BA.debugLineNum = 19;BA.debugLine="lv = lst";
_lv = _lst;
 //BA.debugLineNum = 20;BA.debugLine="Private jo = lst As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_lst.getObject()));
 //BA.debugLineNum = 21;BA.debugLine="Private cdw As ColorDrawable";
_cdw = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 22;BA.debugLine="cdw.Initialize(clrTheme.Background, clrTheme.txtN";
_cdw.Initialize(_clrtheme._background /*int*/ ,_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 23;BA.debugLine="jo.RunMethod(\"setSelector\", Array(cdw))";
_jo.RunMethod("setSelector",new Object[]{(Object)(_cdw.getObject())});
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _itemclick(int _position,Object _value) throws Exception{
anywheresoftware.b4j.object.JavaObject _jolv = null;
int _firstvisible = 0;
int _oldrelativeindex = 0;
anywheresoftware.b4j.object.JavaObject _oldview = null;
int _relativeindex = 0;
anywheresoftware.b4j.object.JavaObject _newview = null;
 //BA.debugLineNum = 54;BA.debugLine="Public Sub ItemClick (Position As Int, Value As Ob";
 //BA.debugLineNum = 57;BA.debugLine="If selectedIndex <> -1 Then";
if (_selectedindex!=-1) { 
 //BA.debugLineNum = 58;BA.debugLine="Dim joLV As JavaObject = lv";
_jolv = new anywheresoftware.b4j.object.JavaObject();
_jolv = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_lv.getObject()));
 //BA.debugLineNum = 59;BA.debugLine="Dim firstVisible As Int = joLV.RunMethod(\"getFir";
_firstvisible = (int)(BA.ObjectToNumber(_jolv.RunMethod("getFirstVisiblePosition",(Object[])(__c.Null))));
 //BA.debugLineNum = 60;BA.debugLine="Dim oldRelativeIndex As Int = selectedIndex - fi";
_oldrelativeindex = (int) (_selectedindex-_firstvisible);
 //BA.debugLineNum = 61;BA.debugLine="If oldRelativeIndex >= 0 And oldRelativeIndex <";
if (_oldrelativeindex>=0 && _oldrelativeindex<(double)(BA.ObjectToNumber(_jolv.RunMethod("getChildCount",(Object[])(__c.Null))))) { 
 //BA.debugLineNum = 62;BA.debugLine="Dim oldView As JavaObject = joLV.RunMethod(\"get";
_oldview = new anywheresoftware.b4j.object.JavaObject();
_oldview = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jolv.RunMethod("getChildAt",new Object[]{(Object)(_oldrelativeindex)})));
 //BA.debugLineNum = 63;BA.debugLine="oldView.RunMethod(\"setBackgroundColor\", Array(C";
_oldview.RunMethod("setBackgroundColor",new Object[]{(Object)(__c.Colors.Transparent)});
 };
 };
 //BA.debugLineNum = 68;BA.debugLine="Dim joLV As JavaObject = lv";
_jolv = new anywheresoftware.b4j.object.JavaObject();
_jolv = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_lv.getObject()));
 //BA.debugLineNum = 69;BA.debugLine="Dim firstVisible As Int = joLV.RunMethod(\"getFirs";
_firstvisible = (int)(BA.ObjectToNumber(_jolv.RunMethod("getFirstVisiblePosition",(Object[])(__c.Null))));
 //BA.debugLineNum = 70;BA.debugLine="Dim relativeIndex As Int = Position - firstVisibl";
_relativeindex = (int) (_position-_firstvisible);
 //BA.debugLineNum = 71;BA.debugLine="If relativeIndex >= 0 And relativeIndex < joLV.Ru";
if (_relativeindex>=0 && _relativeindex<(double)(BA.ObjectToNumber(_jolv.RunMethod("getChildCount",(Object[])(__c.Null))))) { 
 //BA.debugLineNum = 72;BA.debugLine="Dim newView As JavaObject = joLV.RunMethod(\"getC";
_newview = new anywheresoftware.b4j.object.JavaObject();
_newview = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jolv.RunMethod("getChildAt",new Object[]{(Object)(_relativeindex)})));
 //BA.debugLineNum = 73;BA.debugLine="newView.RunMethod(\"setBackgroundColor\", Array(cl";
_newview.RunMethod("setBackgroundColor",new Object[]{(Object)(_clrtheme._background /*int*/ )});
 };
 //BA.debugLineNum = 76;BA.debugLine="selectedIndex = Position";
_selectedindex = _position;
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public void  _programmaticallyclickandhighlight(int _index) throws Exception{
ResumableSub_ProgrammaticallyClickAndHighlight rsub = new ResumableSub_ProgrammaticallyClickAndHighlight(this,_index);
rsub.resume(ba, null);
}
public static class ResumableSub_ProgrammaticallyClickAndHighlight extends BA.ResumableSub {
public ResumableSub_ProgrammaticallyClickAndHighlight(sadLogic.HomeCentral.listviewselector parent,int _index) {
this.parent = parent;
this._index = _index;
}
sadLogic.HomeCentral.listviewselector parent;
int _index;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 29;BA.debugLine="lv.SetSelection(index)";
parent._lv.SetSelection(_index);
 //BA.debugLineNum = 30;BA.debugLine="Sleep(200) ' Wait for scroll to complete";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 31;BA.debugLine="ClickListViewItem(index)";
parent._clicklistviewitem(_index);
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
