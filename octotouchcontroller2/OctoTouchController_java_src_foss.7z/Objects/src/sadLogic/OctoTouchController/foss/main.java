package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = true;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "sadLogic.OctoTouchController.foss", "sadLogic.OctoTouchController.foss.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "sadLogic.OctoTouchController.foss", "sadLogic.OctoTouchController.foss.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "sadLogic.OctoTouchController.foss.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create " + (isFirst ? "(first time)" : "") + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static boolean _actionbarhomeclicked = false;
public static sadLogic.OctoTouchController.foss.callsubutils _tmrtimercallsub = null;
public static sadLogic.OctoTouchController.foss.keyvaluestore _kvs = null;
public static sadLogic.OctoTouchController.foss.inmemdb _db = null;
public static sadLogic.OctoTouchController.foss.fileprovider _provider = null;
public static boolean _isappclosing = false;
public static anywheresoftware.b4a.objects.Timer _tmrmain = null;
public static anywheresoftware.b4a.objects.Timer _tmrscreen = null;
public static String _mmodule = "";
public anywheresoftware.b4a.phone.Phone _ph = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _activity_actionbarhomeclick() throws Exception{
 //BA.debugLineNum = 317;BA.debugLine="Sub Activity_ActionBarHomeClick";
 //BA.debugLineNum = 318;BA.debugLine="ActionBarHomeClicked = True";
_actionbarhomeclicked = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 319;BA.debugLine="B4XPages.Delegate.Activity_ActionBarHomeClick";
mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._activity_actionbarhomeclick /*String*/ ();
 //BA.debugLineNum = 320;BA.debugLine="ActionBarHomeClicked = False";
_actionbarhomeclicked = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 321;BA.debugLine="End Sub";
return "";
}
public static String  _activity_create(boolean _firsttime) throws Exception{
sadLogic.OctoTouchController.foss.b4xpagesmanager _pm = null;
 //BA.debugLineNum = 79;BA.debugLine="Sub Activity_Create(FirstTime As Boolean) 'ignore";
 //BA.debugLineNum = 81;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 83;BA.debugLine="Log(\"Activity_Create - FirstTime = True\")";
anywheresoftware.b4a.keywords.Common.LogImpl("131076","Activity_Create - FirstTime = True",0);
 //BA.debugLineNum = 84;BA.debugLine="SetUserOrientPref";
_setuserorientpref();
 //BA.debugLineNum = 85;BA.debugLine="tmrTimerCallSub.Initialize";
_tmrtimercallsub._initialize /*String*/ (processBA);
 //BA.debugLineNum = 86;BA.debugLine="kvs.Initialize(xui.DefaultFolder, \"kvs.db3\")";
_kvs._initialize /*String*/ (processBA,mostCurrent._xui.getDefaultFolder(),"kvs.db3");
 //BA.debugLineNum = 87;BA.debugLine="InitApp";
_initapp();
 //BA.debugLineNum = 91;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"tmrSplash";
_tmrtimercallsub._callsubdelayedplus /*String*/ (main.getObject(),"tmrSplash_Tick",(int) (3500));
 }else {
 //BA.debugLineNum = 95;BA.debugLine="Log(\"Activity_Create - FirstTime = False\")";
anywheresoftware.b4a.keywords.Common.LogImpl("131088","Activity_Create - FirstTime = False",0);
 };
 //BA.debugLineNum = 99;BA.debugLine="If tmrScreen.IsInitialized = False Then";
if (_tmrscreen.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 100;BA.debugLine="tmrScreen.Initialize(\"tmrScreenPower\",15000)	'--";
_tmrscreen.Initialize(processBA,"tmrScreenPower",(long) (15000));
 };
 //BA.debugLineNum = 103;BA.debugLine="If tmrMain.IsInitialized = False Then";
if (_tmrmain.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 104;BA.debugLine="tmrMain.Initialize(\"tmrMain\",2100) 	'--- main lo";
_tmrmain.Initialize(processBA,"tmrMain",(long) (2100));
 };
 //BA.debugLineNum = 107;BA.debugLine="SetupFullScrn";
_setupfullscrn();
 //BA.debugLineNum = 109;BA.debugLine="Dim pm As B4XPagesManager";
_pm = new sadLogic.OctoTouchController.foss.b4xpagesmanager();
 //BA.debugLineNum = 110;BA.debugLine="pm.Initialize(Activity)";
_pm._initialize /*String*/ (mostCurrent.activityBA,mostCurrent._activity);
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return "";
}
public static boolean  _activity_keypress(int _keycode) throws Exception{
 //BA.debugLineNum = 323;BA.debugLine="Sub Activity_KeyPress (KeyCode As Int) As Boolean";
 //BA.debugLineNum = 324;BA.debugLine="Return B4XPages.Delegate.Activity_KeyPress(KeyCod";
if (true) return mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._activity_keypress /*boolean*/ (_keycode);
 //BA.debugLineNum = 325;BA.debugLine="End Sub";
return false;
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 335;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 336;BA.debugLine="B4XPages.Delegate.Activity_Pause";
mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._activity_pause /*String*/ ();
 //BA.debugLineNum = 337;BA.debugLine="Log(\"UserClosed:\" & UserClosed)";
anywheresoftware.b4a.keywords.Common.LogImpl("1114114","UserClosed:"+BA.ObjectToString(_userclosed),0);
 //BA.debugLineNum = 338;BA.debugLine="If UserClosed Then ExitApplication";
if (_userclosed) { 
anywheresoftware.b4a.keywords.Common.ExitApplication();};
 //BA.debugLineNum = 339;BA.debugLine="End Sub";
return "";
}
public static String  _activity_permissionresult(String _permission,boolean _result) throws Exception{
 //BA.debugLineNum = 341;BA.debugLine="Sub Activity_PermissionResult (Permission As Strin";
 //BA.debugLineNum = 342;BA.debugLine="B4XPages.Delegate.Activity_PermissionResult(Permi";
mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._activity_permissionresult /*String*/ (_permission,_result);
 //BA.debugLineNum = 343;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 327;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 328;BA.debugLine="B4XPages.Delegate.Activity_Resume";
mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._activity_resume /*String*/ ();
 //BA.debugLineNum = 329;BA.debugLine="If config.IsInit Then";
if (mostCurrent._config._isinit /*boolean*/ ) { 
 //BA.debugLineNum = 331;BA.debugLine="fnc.ProcessPowerFlags";
mostCurrent._fnc._processpowerflags /*String*/ (mostCurrent.activityBA);
 };
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
return "";
}
public static void  _activity_windowfocuschanged(boolean _hasfocus) throws Exception{
ResumableSub_Activity_WindowFocusChanged rsub = new ResumableSub_Activity_WindowFocusChanged(null,_hasfocus);
rsub.resume(processBA, null);
}
public static class ResumableSub_Activity_WindowFocusChanged extends BA.ResumableSub {
public ResumableSub_Activity_WindowFocusChanged(sadLogic.OctoTouchController.foss.main parent,boolean _hasfocus) {
this.parent = parent;
this._hasfocus = _hasfocus;
}
sadLogic.OctoTouchController.foss.main parent;
boolean _hasfocus;
anywheresoftware.b4j.object.JavaObject _jo = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 298;BA.debugLine="If ph.SdkVersion < gblConst.API_ANDROID_4_4 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent.mostCurrent._ph.getSdkVersion()<parent.mostCurrent._gblconst._api_android_4_4 /*int*/ ) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 301;BA.debugLine="If HasFocus Then";
if (true) break;

case 7:
//if
this.state = 16;
if (_hasfocus) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 302;BA.debugLine="Try";
if (true) break;

case 10:
//try
this.state = 15;
this.catchState = 14;
this.state = 12;
if (true) break;

case 12:
//C
this.state = 15;
this.catchState = 14;
 //BA.debugLineNum = 303;BA.debugLine="Dim jo As JavaObject = Activity";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(parent.mostCurrent._activity.getObject()));
 //BA.debugLineNum = 304;BA.debugLine="Sleep(300)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (300));
this.state = 17;
return;
case 17:
//C
this.state = 15;
;
 //BA.debugLineNum = 305;BA.debugLine="jo.RunMethod(\"setSystemUiVisibility\", Array As";
_jo.RunMethod("setSystemUiVisibility",new Object[]{(Object)(5894)});
 if (true) break;

case 14:
//C
this.state = 15;
this.catchState = 0;
 //BA.debugLineNum = 307;BA.debugLine="Log(\"error\")";
anywheresoftware.b4a.keywords.Common.LogImpl("851979","error",0);
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 0;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
processBA.setLastException(e0);}
            }
        }
    }
}
public static boolean  _canrequestpackageinstalls() throws Exception{
anywheresoftware.b4j.object.JavaObject _ctxt = null;
anywheresoftware.b4j.object.JavaObject _packagemanager = null;
 //BA.debugLineNum = 431;BA.debugLine="Private Sub CanRequestPackageInstalls As Boolean";
 //BA.debugLineNum = 432;BA.debugLine="Dim ctxt As JavaObject";
_ctxt = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 433;BA.debugLine="ctxt.InitializeContext";
_ctxt.InitializeContext(processBA);
 //BA.debugLineNum = 434;BA.debugLine="Dim PackageManager As JavaObject = ctxt.RunMethod";
_packagemanager = new anywheresoftware.b4j.object.JavaObject();
_packagemanager = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_ctxt.RunMethod("getPackageManager",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 435;BA.debugLine="Return PackageManager.RunMethod(\"canRequestPackag";
if (true) return BA.ObjectToBoolean(_packagemanager.RunMethod("canRequestPackageInstalls",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 436;BA.debugLine="End Sub";
return false;
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _checkinstallationrequirements() throws Exception{
ResumableSub_CheckInstallationRequirements rsub = new ResumableSub_CheckInstallationRequirements(null);
rsub.resume(processBA, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_CheckInstallationRequirements extends BA.ResumableSub {
public ResumableSub_CheckInstallationRequirements(sadLogic.OctoTouchController.foss.main parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.main parent;
int _result = 0;
anywheresoftware.b4a.objects.IntentWrapper _in = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 411;BA.debugLine="If File.ExternalWritable = False Then";
if (true) break;

case 1:
//if
this.state = 10;
if (anywheresoftware.b4a.keywords.Common.File.getExternalWritable()==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 3;
}else if(parent.mostCurrent._ph.getSdkVersion()>=26 && _canrequestpackageinstalls()==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 5;
}else if(_checknonmarketappsenabled()==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 3:
//C
this.state = 10;
 //BA.debugLineNum = 412;BA.debugLine="MsgboxAsync(\"Storage card not available. Make su";
anywheresoftware.b4a.keywords.Common.MsgboxAsync(BA.ObjectToCharSequence("Storage card not available. Make sure that your device is not connected in USB storage mode."),BA.ObjectToCharSequence(""),processBA);
 //BA.debugLineNum = 413;BA.debugLine="Return False";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(anywheresoftware.b4a.keywords.Common.False));return;};
 if (true) break;

case 5:
//C
this.state = 10;
 //BA.debugLineNum = 415;BA.debugLine="MsgboxAsync(\"Please allow me to install applicat";
anywheresoftware.b4a.keywords.Common.MsgboxAsync(BA.ObjectToCharSequence("Please allow me to install applications."),BA.ObjectToCharSequence(""),processBA);
 //BA.debugLineNum = 416;BA.debugLine="Wait For Msgbox_Result(Result As Int)";
anywheresoftware.b4a.keywords.Common.WaitFor("msgbox_result", processBA, this, null);
this.state = 11;
return;
case 11:
//C
this.state = 10;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 417;BA.debugLine="Dim in As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 418;BA.debugLine="in.Initialize(\"android.settings.MANAGE_UNKNOWN_A";
_in.Initialize("android.settings.MANAGE_UNKNOWN_APP_SOURCES","package:"+anywheresoftware.b4a.keywords.Common.Application.getPackageName());
 //BA.debugLineNum = 419;BA.debugLine="StartActivity(in)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(_in.getObject()));
 //BA.debugLineNum = 420;BA.debugLine="Wait For Activity_Resume '<-- wait for Activity_";
anywheresoftware.b4a.keywords.Common.WaitFor("activity_resume", processBA, this, null);
this.state = 12;
return;
case 12:
//C
this.state = 10;
;
 //BA.debugLineNum = 421;BA.debugLine="Return CanRequestPackageInstalls";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_canrequestpackageinstalls()));return;};
 if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 423;BA.debugLine="MsgboxAsync(\"Please enable installation of non-m";
anywheresoftware.b4a.keywords.Common.MsgboxAsync(BA.ObjectToCharSequence("Please enable installation of non-market applications."+anywheresoftware.b4a.keywords.Common.CRLF+"Under Settings - Security - Unknown sources"+anywheresoftware.b4a.keywords.Common.CRLF+"Or Settings - Applications - Unknown sources"),BA.ObjectToCharSequence(""),processBA);
 //BA.debugLineNum = 425;BA.debugLine="Return False";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(anywheresoftware.b4a.keywords.Common.False));return;};
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 427;BA.debugLine="Return True";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(anywheresoftware.b4a.keywords.Common.True));return;};
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 429;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _msgbox_result(int _result) throws Exception{
}
public static boolean  _checknonmarketappsenabled() throws Exception{
anywheresoftware.b4j.object.JavaObject _context = null;
anywheresoftware.b4j.object.JavaObject _resolver = null;
anywheresoftware.b4j.object.JavaObject _global = null;
 //BA.debugLineNum = 438;BA.debugLine="Private Sub CheckNonMarketAppsEnabled As Boolean";
 //BA.debugLineNum = 439;BA.debugLine="If ph.SdkVersion >= 26 Then Return True";
if (mostCurrent._ph.getSdkVersion()>=26) { 
if (true) return anywheresoftware.b4a.keywords.Common.True;};
 //BA.debugLineNum = 440;BA.debugLine="If ph.SdkVersion < 17 Or ph.SdkVersion >= 21 Then";
if (mostCurrent._ph.getSdkVersion()<17 || mostCurrent._ph.getSdkVersion()>=21) { 
 //BA.debugLineNum = 441;BA.debugLine="Return ph.GetSettings(\"install_non_market_apps\")";
if (true) return (mostCurrent._ph.GetSettings("install_non_market_apps")).equals("1");
 }else {
 //BA.debugLineNum = 443;BA.debugLine="Dim context As JavaObject";
_context = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 444;BA.debugLine="context.InitializeContext";
_context.InitializeContext(processBA);
 //BA.debugLineNum = 445;BA.debugLine="Dim resolver As JavaObject = context.RunMethod(\"";
_resolver = new anywheresoftware.b4j.object.JavaObject();
_resolver = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_context.RunMethod("getContentResolver",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 446;BA.debugLine="Dim global As JavaObject";
_global = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 447;BA.debugLine="global.InitializeStatic(\"android.provider.Settin";
_global.InitializeStatic("android.provider.Settings.Global");
 //BA.debugLineNum = 448;BA.debugLine="Return global.RunMethod(\"getString\", Array(resol";
if (true) return (_global.RunMethod("getString",new Object[]{(Object)(_resolver.getObject()),(Object)("install_non_market_apps")})).equals((Object)("1"));
 };
 //BA.debugLineNum = 450;BA.debugLine="End Sub";
return false;
}
public static String  _clean_oldcrash() throws Exception{
int _hrs = 0;
 //BA.debugLineNum = 507;BA.debugLine="Public Sub Clean_OldCrash";
 //BA.debugLineNum = 508;BA.debugLine="logMe.DeleteOldFiles(\"*.crash\")";
mostCurrent._logme._deleteoldfiles /*String*/ (mostCurrent.activityBA,"*.crash");
 //BA.debugLineNum = 510;BA.debugLine="Dim hrs As Int = 12";
_hrs = (int) (12);
 //BA.debugLineNum = 511;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Clean_OldC";
_tmrtimercallsub._callsubdelayedplus /*String*/ (main.getObject(),"Clean_OldCrash",(int) (60000*60*_hrs));
 //BA.debugLineNum = 512;BA.debugLine="End Sub";
return "";
}
public static String  _clean_oldlogs() throws Exception{
int _hrs = 0;
 //BA.debugLineNum = 501;BA.debugLine="Public Sub Clean_OldLogs";
 //BA.debugLineNum = 502;BA.debugLine="logMe.DeleteOldFiles(\"*.log\")";
mostCurrent._logme._deleteoldfiles /*String*/ (mostCurrent.activityBA,"*.log");
 //BA.debugLineNum = 504;BA.debugLine="Dim hrs As Int = 12";
_hrs = (int) (12);
 //BA.debugLineNum = 505;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Clean_OldL";
_tmrtimercallsub._callsubdelayedplus /*String*/ (main.getObject(),"Clean_OldLogs",(int) (60000*60*_hrs));
 //BA.debugLineNum = 506;BA.debugLine="End Sub";
return "";
}
public static String  _create_menu(Object _menu) throws Exception{
 //BA.debugLineNum = 345;BA.debugLine="Sub Create_Menu (Menu As Object)";
 //BA.debugLineNum = 346;BA.debugLine="B4XPages.Delegate.Create_Menu(Menu)";
mostCurrent._b4xpages._delegate /*sadLogic.OctoTouchController.foss.b4xpagesdelegator*/ ._create_menu /*String*/ (_menu);
 //BA.debugLineNum = 347;BA.debugLine="End Sub";
return "";
}
public static String  _dim_actionbar(int _on_off) throws Exception{
anywheresoftware.b4a.agraham.reflection.Reflection _r = null;
 //BA.debugLineNum = 364;BA.debugLine="Public Sub Dim_ActionBar(On_off As Int)";
 //BA.debugLineNum = 367;BA.debugLine="Try";
try { //BA.debugLineNum = 369;BA.debugLine="If ph.SdkVersion >= gblConst.API_ANDROID_4_0 And";
if (mostCurrent._ph.getSdkVersion()>=mostCurrent._gblconst._api_android_4_0 /*int*/  && mostCurrent._ph.getSdkVersion()<mostCurrent._gblconst._api_android_4_4 /*int*/ ) { 
 //BA.debugLineNum = 370;BA.debugLine="Dim r As Reflector";
_r = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 371;BA.debugLine="r.Target = Activity";
_r.Target = (Object)(mostCurrent._activity.getObject());
 //BA.debugLineNum = 372;BA.debugLine="r.RunMethod2(\"setSystemUiVisibility\", On_off, \"";
_r.RunMethod2("setSystemUiVisibility",BA.NumberToString(_on_off),"java.lang.int");
 }else {
 //BA.debugLineNum = 374;BA.debugLine="If On_off = gblConst.ACTIONBAR_OFF Then";
if (_on_off==mostCurrent._gblconst._actionbar_off /*int*/ ) { 
 //BA.debugLineNum = 375;BA.debugLine="Activity_WindowFocusChanged(True)";
_activity_windowfocuschanged(anywheresoftware.b4a.keywords.Common.True);
 };
 };
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); };
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return "";
}
public static String  _dim_actionbar_off() throws Exception{
 //BA.debugLineNum = 384;BA.debugLine="Public Sub Dim_ActionBar_Off";
 //BA.debugLineNum = 385;BA.debugLine="Dim_ActionBar(gblConst.ACTIONBAR_OFF)";
_dim_actionbar(mostCurrent._gblconst._actionbar_off /*int*/ );
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.keywords.LayoutValues  _getrealsize() throws Exception{
anywheresoftware.b4a.keywords.LayoutValues _lv = null;
anywheresoftware.b4j.object.JavaObject _ctxt = null;
anywheresoftware.b4j.object.JavaObject _windowmanager = null;
anywheresoftware.b4j.object.JavaObject _display = null;
anywheresoftware.b4j.object.JavaObject _point = null;
 //BA.debugLineNum = 185;BA.debugLine="Private Sub GetRealSize() As LayoutValues";
 //BA.debugLineNum = 187;BA.debugLine="Dim lv As LayoutValues";
_lv = new anywheresoftware.b4a.keywords.LayoutValues();
 //BA.debugLineNum = 188;BA.debugLine="Dim ctxt As JavaObject";
_ctxt = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 189;BA.debugLine="ctxt.InitializeContext";
_ctxt.InitializeContext(processBA);
 //BA.debugLineNum = 190;BA.debugLine="Dim WindowManager As JavaObject = ctxt.RunMethodJ";
_windowmanager = new anywheresoftware.b4j.object.JavaObject();
_windowmanager = _ctxt.RunMethodJO("getSystemService",new Object[]{(Object)("window")});
 //BA.debugLineNum = 191;BA.debugLine="Dim display As JavaObject = WindowManager.RunMeth";
_display = new anywheresoftware.b4j.object.JavaObject();
_display = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_windowmanager.RunMethod("getDefaultDisplay",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 192;BA.debugLine="Dim point As JavaObject";
_point = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 193;BA.debugLine="point.InitializeNewInstance(\"android.graphics.Poi";
_point.InitializeNewInstance("android.graphics.Point",(Object[])(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 194;BA.debugLine="display.RunMethod(\"getRealSize\", Array(point))";
_display.RunMethod("getRealSize",new Object[]{(Object)(_point.getObject())});
 //BA.debugLineNum = 195;BA.debugLine="lv.Width = point.GetField(\"x\")";
_lv.Width = (int)(BA.ObjectToNumber(_point.GetField("x")));
 //BA.debugLineNum = 196;BA.debugLine="lv.Height = point.GetField(\"y\")";
_lv.Height = (int)(BA.ObjectToNumber(_point.GetField("y")));
 //BA.debugLineNum = 197;BA.debugLine="lv.Scale = 100dip / 100";
_lv.Scale = (float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))/(double)100);
 //BA.debugLineNum = 198;BA.debugLine="Return lv";
if (true) return _lv;
 //BA.debugLineNum = 200;BA.debugLine="End Sub";
return null;
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 70;BA.debugLine="Private Const mModule As String = \"Main\"";
mostCurrent._mmodule = "Main";
 //BA.debugLineNum = 71;BA.debugLine="Private ph As Phone";
mostCurrent._ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 72;BA.debugLine="Private xui As XUI";
mostCurrent._xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public static String  _initapp() throws Exception{
sadLogic.OctoTouchController.foss.dlgappupdate _oo1 = null;
sadLogic.OctoTouchController.foss.appupdate _oo = null;
 //BA.debugLineNum = 479;BA.debugLine="Private Sub InitApp";
 //BA.debugLineNum = 480;BA.debugLine="Provider.Initialize";
_provider._initialize /*String*/ (processBA);
 //BA.debugLineNum = 482;BA.debugLine="If kvs.ContainsKey(\"install_date\") = False Then";
if (_kvs._containskey /*boolean*/ ("install_date")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 483;BA.debugLine="kvs.Put(\"install_date\",DateTime.Now)";
_kvs._put /*String*/ ("install_date",(Object)(anywheresoftware.b4a.keywords.Common.DateTime.getNow()));
 //BA.debugLineNum = 484;BA.debugLine="kvs.Put(\"version_code\",Application.VersionCode)";
_kvs._put /*String*/ ("version_code",(Object)(anywheresoftware.b4a.keywords.Common.Application.getVersionCode()));
 };
 //BA.debugLineNum = 487;BA.debugLine="db.Initialize";
_db._initialize /*String*/ (processBA);
 //BA.debugLineNum = 489;BA.debugLine="Dim oo1 As dlgAppUpdate : oo1.Initialize(Null)";
_oo1 = new sadLogic.OctoTouchController.foss.dlgappupdate();
 //BA.debugLineNum = 489;BA.debugLine="Dim oo1 As dlgAppUpdate : oo1.Initialize(Null)";
_oo1._initialize /*Object*/ (mostCurrent.activityBA,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 490;BA.debugLine="oo1.CleanUpApkDownload";
_oo1._cleanupapkdownload /*String*/ ();
 //BA.debugLineNum = 492;BA.debugLine="If Application.VersionCode <> kvs.Get(\"version_co";
if (anywheresoftware.b4a.keywords.Common.Application.getVersionCode()!=((int)(BA.ObjectToNumber(_kvs._get /*Object*/ ("version_code"))))) { 
 //BA.debugLineNum = 493;BA.debugLine="Dim oo As AppUpdate : oo.Initialize : oo.RunPrgU";
_oo = new sadLogic.OctoTouchController.foss.appupdate();
 //BA.debugLineNum = 493;BA.debugLine="Dim oo As AppUpdate : oo.Initialize : oo.RunPrgU";
_oo._initialize /*String*/ (processBA);
 //BA.debugLineNum = 493;BA.debugLine="Dim oo As AppUpdate : oo.Initialize : oo.RunPrgU";
_oo._runprgupdate /*String*/ ();
 };
 //BA.debugLineNum = 498;BA.debugLine="End Sub";
return "";
}
public static String  _initlog_cleanup() throws Exception{
 //BA.debugLineNum = 513;BA.debugLine="Public Sub InitLog_Cleanup";
 //BA.debugLineNum = 515;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Clean_OldL";
_tmrtimercallsub._callsubdelayedplus /*String*/ (main.getObject(),"Clean_OldLogs",(int) (60000*13));
 //BA.debugLineNum = 516;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Clean_OldC";
_tmrtimercallsub._callsubdelayedplus /*String*/ (main.getObject(),"Clean_OldCrash",(int) (60000*17));
 //BA.debugLineNum = 517;BA.debugLine="End Sub";
return "";
}
public static String  _orientprefauto() throws Exception{
 //BA.debugLineNum = 177;BA.debugLine="Private Sub OrientPrefAuto";
 //BA.debugLineNum = 178;BA.debugLine="If Activity.width < Activity.Height Then";
if (mostCurrent._activity.getWidth()<mostCurrent._activity.getHeight()) { 
 //BA.debugLineNum = 179;BA.debugLine="ph.SetScreenOrientation(7)";
mostCurrent._ph.SetScreenOrientation(processBA,(int) (7));
 }else {
 //BA.debugLineNum = 181;BA.debugLine="ph.SetScreenOrientation(6)";
mostCurrent._ph.SetScreenOrientation(processBA,(int) (6));
 };
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4a.example.dateutils._process_globals();
main._process_globals();
clrtheme._process_globals();
config._process_globals();
filehelpers._process_globals();
fnc._process_globals();
gblconst._process_globals();
guihelpers._process_globals();
logme._process_globals();
objhelpers._process_globals();
oc._process_globals();
powerhelpers._process_globals();
startatboot._process_globals();
starter._process_globals();
strhelpers._process_globals();
b4xcollections._process_globals();
b4xpages._process_globals();
httputils2service._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 51;BA.debugLine="Public ActionBarHomeClicked As Boolean";
_actionbarhomeclicked = false;
 //BA.debugLineNum = 54;BA.debugLine="Public tmrTimerCallSub As CallSubUtils";
_tmrtimercallsub = new sadLogic.OctoTouchController.foss.callsubutils();
 //BA.debugLineNum = 55;BA.debugLine="Public kvs As KeyValueStore";
_kvs = new sadLogic.OctoTouchController.foss.keyvaluestore();
 //BA.debugLineNum = 56;BA.debugLine="Public db As InMemDB";
_db = new sadLogic.OctoTouchController.foss.inmemdb();
 //BA.debugLineNum = 57;BA.debugLine="Public Provider As FileProvider";
_provider = new sadLogic.OctoTouchController.foss.fileprovider();
 //BA.debugLineNum = 58;BA.debugLine="Public isAppClosing As Boolean = False";
_isappclosing = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 61;BA.debugLine="Private tmrMain As Timer";
_tmrmain = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 63;BA.debugLine="Private tmrScreen As Timer";
_tmrscreen = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public static String  _sendinstallintent(String _path) throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _i = null;
String _fullpath = "";
 //BA.debugLineNum = 452;BA.debugLine="Private Sub SendInstallIntent(path As String) 'ign";
 //BA.debugLineNum = 453;BA.debugLine="Dim i As Intent, fullpath As String";
_i = new anywheresoftware.b4a.objects.IntentWrapper();
_fullpath = "";
 //BA.debugLineNum = 454;BA.debugLine="If ph.SdkVersion >= 24 Then";
if (mostCurrent._ph.getSdkVersion()>=24) { 
 //BA.debugLineNum = 455;BA.debugLine="fullpath = Provider.GetFileUri(fileHelpers.GetFi";
_fullpath = BA.ObjectToString(_provider._getfileuri /*Object*/ (mostCurrent._filehelpers._getfilenamefrompath /*String*/ (mostCurrent.activityBA,mostCurrent._gblconst._apk_name /*String*/ )));
 //BA.debugLineNum = 456;BA.debugLine="i.Initialize(\"android.intent.action.INSTALL_PACK";
_i.Initialize("android.intent.action.INSTALL_PACKAGE",_fullpath);
 //BA.debugLineNum = 457;BA.debugLine="i.Flags = Bit.Or(i.Flags, 1) '--- FLAG_GRANT_REA";
_i.setFlags(anywheresoftware.b4a.keywords.Common.Bit.Or(_i.getFlags(),(int) (1)));
 }else {
 //BA.debugLineNum = 459;BA.debugLine="fullpath = \"file://\" & File.Combine(path, fileHe";
_fullpath = "file://"+anywheresoftware.b4a.keywords.Common.File.Combine(_path,mostCurrent._filehelpers._getfilenamefrompath /*String*/ (mostCurrent.activityBA,mostCurrent._gblconst._apk_name /*String*/ ));
 //BA.debugLineNum = 460;BA.debugLine="i.Initialize(i.ACTION_VIEW, fullpath)";
_i.Initialize(_i.ACTION_VIEW,_fullpath);
 //BA.debugLineNum = 461;BA.debugLine="i.SetType(\"application/vnd.android.package-archi";
_i.SetType("application/vnd.android.package-archive");
 };
 //BA.debugLineNum = 463;BA.debugLine="logMe.LogIt(\"App update fullpath: \" & fullpath, m";
mostCurrent._logme._logit /*String*/ (mostCurrent.activityBA,"App update fullpath: "+_fullpath,mostCurrent._mmodule);
 //BA.debugLineNum = 464;BA.debugLine="StartActivity(i)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(_i.getObject()));
 //BA.debugLineNum = 465;BA.debugLine="End Sub";
return "";
}
public static String  _set_screentmr() throws Exception{
String _insub = "";
 //BA.debugLineNum = 244;BA.debugLine="Public Sub Set_ScreenTmr()";
 //BA.debugLineNum = 246;BA.debugLine="If config.logTIMER_EVENTS Then logMe.LogIt(\"Set_S";
if (mostCurrent._config._logtimer_events /*boolean*/ ) { 
mostCurrent._logme._logit /*String*/ (mostCurrent.activityBA,"Set_ScreenTmr",mostCurrent._mmodule);};
 //BA.debugLineNum = 248;BA.debugLine="Dim inSub As String = \"Set_ScreenTmr\"";
_insub = "Set_ScreenTmr";
 //BA.debugLineNum = 249;BA.debugLine="tmrScreen.Enabled = False";
_tmrscreen.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 251;BA.debugLine="If config.AndroidTakeOverSleepFLAG = False Then";
if (mostCurrent._config._androidtakeoversleepflag /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 252;BA.debugLine="If config.logPOWER_EVENTS Then logMe.LogIt(\"Powe";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
mostCurrent._logme._logit /*String*/ (mostCurrent.activityBA,"Power control is off",mostCurrent._mmodule);};
 //BA.debugLineNum = 253;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 257;BA.debugLine="If (config.AndroidNotPrintingScrnOffFLAG Or confi";
if ((mostCurrent._config._androidnotprintingscrnoffflag /*boolean*/  || mostCurrent._config._androidprintingscrnoffflag /*boolean*/ )) { 
 //BA.debugLineNum = 258;BA.debugLine="If oc.isPrinting And config.AndroidPrintingScrnO";
if (mostCurrent._oc._isprinting /*boolean*/  && mostCurrent._config._androidprintingscrnoffflag /*boolean*/ ) { 
 //BA.debugLineNum = 259;BA.debugLine="If config.logPOWER_EVENTS Then";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
 //BA.debugLineNum = 260;BA.debugLine="logMe.LogIt2(\"AndroidPrintingScrnOffFLAG = Tru";
mostCurrent._logme._logit2 /*String*/ (mostCurrent.activityBA,"AndroidPrintingScrnOffFLAG = True: Min: "+BA.NumberToString(mostCurrent._config._androidprintingmintill /*int*/ ),mostCurrent._mmodule,_insub);
 };
 //BA.debugLineNum = 262;BA.debugLine="tmrScreen.Interval = config.AndroidPrintingMinT";
_tmrscreen.setInterval((long) (mostCurrent._config._androidprintingmintill /*int*/ *1000*60));
 }else {
 //BA.debugLineNum = 264;BA.debugLine="If config.logPOWER_EVENTS Then";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
 //BA.debugLineNum = 265;BA.debugLine="logMe.LogIt2(\"AndroidNotPrintingScrnOffFLAG =";
mostCurrent._logme._logit2 /*String*/ (mostCurrent.activityBA,"AndroidNotPrintingScrnOffFLAG = True: Min: "+BA.NumberToString(mostCurrent._config._androidnotprintingmintill /*int*/ ),mostCurrent._mmodule,_insub);
 };
 //BA.debugLineNum = 267;BA.debugLine="tmrScreen.Interval = config.AndroidNotPrintingM";
_tmrscreen.setInterval((long) (mostCurrent._config._androidnotprintingmintill /*int*/ *1000*60));
 };
 //BA.debugLineNum = 269;BA.debugLine="tmrScreen.Enabled = True";
_tmrscreen.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 };
 //BA.debugLineNum = 272;BA.debugLine="Dim_ActionBar(gblConst.ACTIONBAR_OFF) '--- turn o";
_dim_actionbar(mostCurrent._gblconst._actionbar_off /*int*/ );
 //BA.debugLineNum = 274;BA.debugLine="End Sub";
return "";
}
public static String  _setobj_null(Object _obj) throws Exception{
 //BA.debugLineNum = 520;BA.debugLine="Public Sub SetObj_Null(obj As Object)";
 //BA.debugLineNum = 521;BA.debugLine="obj = Null";
_obj = anywheresoftware.b4a.keywords.Common.Null;
 //BA.debugLineNum = 522;BA.debugLine="End Sub";
return "";
}
public static String  _setupfullscrn() throws Exception{
anywheresoftware.b4a.keywords.LayoutValues _lv = null;
anywheresoftware.b4j.object.JavaObject _ctxt = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4a.objects.Accessibility _ac = null;
 //BA.debugLineNum = 119;BA.debugLine="Private Sub SetupFullScrn";
 //BA.debugLineNum = 123;BA.debugLine="Dim lv As LayoutValues";
_lv = new anywheresoftware.b4a.keywords.LayoutValues();
 //BA.debugLineNum = 125;BA.debugLine="If ph.SdkVersion >= 28 Then";
if (mostCurrent._ph.getSdkVersion()>=28) { 
 //BA.debugLineNum = 127;BA.debugLine="Dim ctxt As JavaObject";
_ctxt = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 128;BA.debugLine="ctxt.InitializeContext";
_ctxt.InitializeContext(processBA);
 //BA.debugLineNum = 129;BA.debugLine="ctxt.RunMethodJO(\"getWindow\", Null).RunMethodJO(";
_ctxt.RunMethodJO("getWindow",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethodJO("getAttributes",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).SetField("layoutInDisplayCutoutMode",(Object)(1));
 };
 //BA.debugLineNum = 132;BA.debugLine="If ph.SdkVersion >= 19 Then";
if (mostCurrent._ph.getSdkVersion()>=19) { 
 //BA.debugLineNum = 133;BA.debugLine="Activity_WindowFocusChanged(True)";
_activity_windowfocuschanged(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 134;BA.debugLine="lv = GetRealSize";
_lv = _getrealsize();
 //BA.debugLineNum = 135;BA.debugLine="Dim jo As JavaObject = Activity";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(mostCurrent._activity.getObject()));
 //BA.debugLineNum = 136;BA.debugLine="jo.RunMethod(\"setBottom\", Array(lv.Height))";
_jo.RunMethod("setBottom",new Object[]{(Object)(_lv.Height)});
 //BA.debugLineNum = 137;BA.debugLine="jo.RunMethod(\"setRight\", Array(lv.Width))";
_jo.RunMethod("setRight",new Object[]{(Object)(_lv.Width)});
 //BA.debugLineNum = 138;BA.debugLine="Activity.Height = lv.Height";
mostCurrent._activity.setHeight(_lv.Height);
 //BA.debugLineNum = 139;BA.debugLine="Activity.Width = lv.Width";
mostCurrent._activity.setWidth(_lv.Width);
 }else {
 //BA.debugLineNum = 142;BA.debugLine="lv = GetDeviceLayoutValues";
_lv = anywheresoftware.b4a.keywords.Common.GetDeviceLayoutValues(mostCurrent.activityBA);
 };
 //BA.debugLineNum = 145;BA.debugLine="guiHelpers.gScreenSizeAprox = lv.ApproximateScree";
mostCurrent._guihelpers._gscreensizeaprox /*double*/  = _lv.getApproximateScreenSize();
 //BA.debugLineNum = 146;BA.debugLine="guiHelpers.gIsLandScape = Not (lv.Height > lv.Wid";
mostCurrent._guihelpers._gislandscape /*boolean*/  = anywheresoftware.b4a.keywords.Common.Not(_lv.Height>_lv.Width);
 //BA.debugLineNum = 147;BA.debugLine="guiHelpers.gWidth  = lv.Width";
mostCurrent._guihelpers._gwidth /*float*/  = (float) (_lv.Width);
 //BA.debugLineNum = 148;BA.debugLine="guiHelpers.gHeight = lv.Height";
mostCurrent._guihelpers._gheight /*float*/  = (float) (_lv.Height);
 //BA.debugLineNum = 149;BA.debugLine="Dim ac As Accessibility : guiHelpers.gFscale = ac";
_ac = new anywheresoftware.b4a.objects.Accessibility();
 //BA.debugLineNum = 149;BA.debugLine="Dim ac As Accessibility : guiHelpers.gFscale = ac";
mostCurrent._guihelpers._gfscale /*float*/  = _ac.GetUserFontScale();
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public static String  _setuserorientpref() throws Exception{
anywheresoftware.b4a.objects.collections.Map _data = null;
String _pref = "";
 //BA.debugLineNum = 155;BA.debugLine="Private Sub SetUserOrientPref";
 //BA.debugLineNum = 157;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.GENERAL";
if (anywheresoftware.b4a.keywords.Common.File.Exists(mostCurrent._xui.getDefaultFolder(),mostCurrent._gblconst._general_options_file /*String*/ )==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 158;BA.debugLine="OrientPrefAuto";
_orientprefauto();
 //BA.debugLineNum = 159;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 162;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = anywheresoftware.b4a.keywords.Common.File.ReadMap(mostCurrent._xui.getDefaultFolder(),mostCurrent._gblconst._general_options_file /*String*/ );
 //BA.debugLineNum = 163;BA.debugLine="Dim pref As String = Data.GetDefault(\"ort\",\"Auto\"";
_pref = (BA.ObjectToString(_data.GetDefault((Object)("ort"),(Object)("Auto")))).toUpperCase();
 //BA.debugLineNum = 166;BA.debugLine="Select Case True";
switch (BA.switchObjectToInt(anywheresoftware.b4a.keywords.Common.True,_pref.startsWith("PO"),_pref.startsWith("LA"))) {
case 0: {
 //BA.debugLineNum = 168;BA.debugLine="ph.SetScreenOrientation(7)";
mostCurrent._ph.SetScreenOrientation(processBA,(int) (7));
 break; }
case 1: {
 //BA.debugLineNum = 170;BA.debugLine="ph.SetScreenOrientation(6)";
mostCurrent._ph.SetScreenOrientation(processBA,(int) (6));
 break; }
default: {
 //BA.debugLineNum = 172;BA.debugLine="OrientPrefAuto";
_orientprefauto();
 break; }
}
;
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public static boolean  _show_unhandled_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 525;BA.debugLine="Public Sub Show_Unhandled_Error (Error As Exceptio";
 //BA.debugLineNum = 526;BA.debugLine="MsgboxAsync(StackTrace, Error)";
anywheresoftware.b4a.keywords.Common.MsgboxAsync(BA.ObjectToCharSequence(_stacktrace),BA.ObjectToCharSequence(_error.getObject()),processBA);
 //BA.debugLineNum = 527;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 528;BA.debugLine="End Sub";
return false;
}
public static void  _start_apkinstall(String[] _args) throws Exception{
ResumableSub_Start_ApkInstall rsub = new ResumableSub_Start_ApkInstall(null,_args);
rsub.resume(processBA, null);
}
public static class ResumableSub_Start_ApkInstall extends BA.ResumableSub {
public ResumableSub_Start_ApkInstall(sadLogic.OctoTouchController.foss.main parent,String[] _args) {
this.parent = parent;
this._args = _args;
}
sadLogic.OctoTouchController.foss.main parent;
String[] _args;
boolean _result = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 468;BA.debugLine="Wait For (CheckInstallationRequirements) Complete";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, _checkinstallationrequirements());
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Boolean) result[0];
;
 //BA.debugLineNum = 469;BA.debugLine="If Result Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 470;BA.debugLine="SendInstallIntent(args(0))";
_sendinstallintent(_args[(int) (0)]);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 472;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(boolean _result) throws Exception{
}
public static String  _tmrmain_tick() throws Exception{
 //BA.debugLineNum = 205;BA.debugLine="Private Sub tmrMain_Tick";
 //BA.debugLineNum = 207;BA.debugLine="CallSub(B4XPages.MainPage.oMasterController,\"tmrM";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (mostCurrent.activityBA)._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"tmrMain_Tick");
 //BA.debugLineNum = 208;BA.debugLine="End Sub";
return "";
}
public static String  _tmrscreenpower_tick() throws Exception{
String _insub = "";
 //BA.debugLineNum = 220;BA.debugLine="Public Sub tmrScreenPower_Tick";
 //BA.debugLineNum = 222;BA.debugLine="Set_ScreenTmr";
_set_screentmr();
 //BA.debugLineNum = 224;BA.debugLine="Dim InSub As String = \"tmrScreenPower_Tick\"";
_insub = "tmrScreenPower_Tick";
 //BA.debugLineNum = 225;BA.debugLine="If config.logPOWER_EVENTS Or config.logTIMER_EVEN";
if (mostCurrent._config._logpower_events /*boolean*/  || mostCurrent._config._logtimer_events /*boolean*/ ) { 
 //BA.debugLineNum = 226;BA.debugLine="logMe.LogIt2(\"tmrScreenPower_Tick fired: \" & tmr";
mostCurrent._logme._logit2 /*String*/ (mostCurrent.activityBA,"tmrScreenPower_Tick fired: "+BA.NumberToString(_tmrscreen.getInterval()),mostCurrent._mmodule,_insub);
 };
 //BA.debugLineNum = 228;BA.debugLine="If oc.isPrinting Then";
if (mostCurrent._oc._isprinting /*boolean*/ ) { 
 //BA.debugLineNum = 229;BA.debugLine="If config.logPOWER_EVENTS Then";
if (mostCurrent._config._logpower_events /*boolean*/ ) { 
 //BA.debugLineNum = 230;BA.debugLine="logMe.LogIt2(\"We are printing\",mModule,InSub)";
mostCurrent._logme._logit2 /*String*/ (mostCurrent.activityBA,"We are printing",mostCurrent._mmodule,_insub);
 };
 //BA.debugLineNum = 232;BA.debugLine="Set_ScreenTmr";
_set_screentmr();
 //BA.debugLineNum = 233;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 236;BA.debugLine="tmrScreen.Enabled = False";
_tmrscreen.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 237;BA.debugLine="fnc.BlankScreen";
mostCurrent._fnc._blankscreen /*String*/ (mostCurrent.activityBA);
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public static String  _tmrsplash_tick() throws Exception{
 //BA.debugLineNum = 215;BA.debugLine="Private Sub tmrSplash_Tick";
 //BA.debugLineNum = 216;BA.debugLine="CallSubDelayed(B4XPages.MainPage,\"HideSplash_Star";
anywheresoftware.b4a.keywords.Common.CallSubDelayed(processBA,(Object)(mostCurrent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (mostCurrent.activityBA)),"HideSplash_StartUp");
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public static String  _turnonoff_maintmr(boolean _enabledisable) throws Exception{
 //BA.debugLineNum = 281;BA.debugLine="Public Sub TurnOnOff_MainTmr(EnableDisable As Bool";
 //BA.debugLineNum = 282;BA.debugLine="If config.logTIMER_EVENTS Then logMe.LogIt(\"main";
if (mostCurrent._config._logtimer_events /*boolean*/ ) { 
mostCurrent._logme._logit /*String*/ (mostCurrent.activityBA,"main tmr on: "+BA.ObjectToString(_enabledisable),mostCurrent._mmodule);};
 //BA.debugLineNum = 283;BA.debugLine="tmrMain.Enabled = EnableDisable";
_tmrmain.setEnabled(_enabledisable);
 //BA.debugLineNum = 284;BA.debugLine="End Sub";
return "";
}
public static String  _turnonoff_screentmr(boolean _enabledisable) throws Exception{
 //BA.debugLineNum = 276;BA.debugLine="Public Sub TurnOnOff_ScreenTmr(EnableDisable As Bo";
 //BA.debugLineNum = 277;BA.debugLine="If config.logTIMER_EVENTS Then logMe.LogIt(\"scree";
if (mostCurrent._config._logtimer_events /*boolean*/ ) { 
mostCurrent._logme._logit /*String*/ (mostCurrent.activityBA,"screen tmr on: "+BA.ObjectToString(_enabledisable),mostCurrent._mmodule);};
 //BA.debugLineNum = 278;BA.debugLine="tmrScreen.Enabled = EnableDisable";
_tmrscreen.setEnabled(_enabledisable);
 //BA.debugLineNum = 279;BA.debugLine="End Sub";
return "";
}
public boolean _onCreateOptionsMenu(android.view.Menu menu) {
	 processBA.raiseEvent(null, "create_menu", menu);
	 return true;
	
}
}
