package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pageweatherbase{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlcurrent").vw.setLeft((int)(0d));
views.get("pnlcurrent").vw.setWidth((int)((47d / 100 * width) - (0d)));
views.get("pnlcurrent").vw.setTop((int)(0d));
views.get("pnlcurrent").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlforcast").vw.setLeft((int)((47d / 100 * width)));
views.get("pnlforcast").vw.setWidth((int)((100d / 100 * width) - ((47d / 100 * width))));
views.get("pnlforcast").vw.setTop((int)(0d));
views.get("pnlforcast").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("lvforecast").vw.setLeft((int)((10d * scale)));
views.get("lvforecast").vw.setWidth((int)((views.get("pnlforcast").vw.getWidth())-(10d * scale) - ((10d * scale))));
views.get("lvforecast").vw.setTop((int)((10d * scale)));
views.get("lvforecast").vw.setHeight((int)((views.get("pnlforcast").vw.getHeight())-(10d * scale) - ((10d * scale))));

}
}