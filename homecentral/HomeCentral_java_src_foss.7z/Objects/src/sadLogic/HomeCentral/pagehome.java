package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagehome extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pagehome");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pagehome.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.HomeCentral.customcalendar _cscal = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlclock = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlcal = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblclock = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblfeelslike = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlcurrent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrenthigh = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrdesc = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblcurrtxt = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbllocation = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncurrtemp = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgcurrent = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btncurrtemp_click() throws Exception{
 //BA.debugLineNum = 199;BA.debugLine="Private Sub btnCurrTemp_Click";
 //BA.debugLineNum = 200;BA.debugLine="mpage.useCel = Not (mpage.useCel)";
_mpage._usecel /*boolean*/  = __c.Not(_mpage._usecel /*boolean*/ );
 //BA.debugLineNum = 201;BA.debugLine="WeatherData_RefreshScrn";
_weatherdata_refreshscrn();
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public String  _build_cal() throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Private Sub Build_Cal()";
 //BA.debugLineNum = 117;BA.debugLine="If pnlMain.Visible = False Then Return";
if (_pnlmain.getVisible()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 123;BA.debugLine="pnlCal.RemoveAllViews";
_pnlcal.RemoveAllViews();
 //BA.debugLineNum = 124;BA.debugLine="csCal.Initialize(pnlCal.Width,pnlCal.Height,DateT";
_cscal._initialize /*String*/ (ba,_pnlcal.getWidth(),_pnlcal.getHeight(),__c.DateTime.getNow(),(int) (16*_guihelpers._sizefontadjust /*float*/ (ba)));
 //BA.debugLineNum = 125;BA.debugLine="csCal.callback = Me";
_cscal._callback /*Object*/  = this;
 //BA.debugLineNum = 126;BA.debugLine="csCal.eventName = \"Cal\"";
_cscal._eventname /*String*/  = "Cal";
 //BA.debugLineNum = 132;BA.debugLine="pnlCal.AddView(csCal.AsView.As(B4XView) ,0,0,pnlC";
_pnlcal.AddView((android.view.View)((_cscal._asview /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ()).getObject()),(int) (0),(int) (0),_pnlcal.getWidth(),_pnlcal.getHeight());
 //BA.debugLineNum = 133;BA.debugLine="csCal.ShowCalendar(True)";
_cscal._showcalendar /*String*/ (__c.True);
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Private Sub Build_Side_Menu";
 //BA.debugLineNum = 84;BA.debugLine="Menus.BuildSideMenu(Array As String(\"\"),Array As";
_menus._buildsidemenu /*String*/ (ba,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}));
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 12;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private csCal As CustomCalendar";
_cscal = new sadLogic.HomeCentral.customcalendar();
 //BA.debugLineNum = 15;BA.debugLine="Private pnlClock As B4XView";
_pnlclock = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private pnlCal As B4XView";
_pnlcal = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lblClock As B4XView";
_lblclock = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private lblFeelsLike As B4XView";
_lblfeelslike = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private pnlCurrent As B4XView";
_pnlcurrent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private lblCurrentHigh As B4XView";
_lblcurrenthigh = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private lblCurrDesc As B4XView";
_lblcurrdesc = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private lblCurrTXT As B4XView";
_lblcurrtxt = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private lblLocation As B4XView";
_lbllocation = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private btnCurrTemp As B4XView";
_btncurrtemp = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private imgCurrent As lmB4XImageViewX";
_imgcurrent = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 30;BA.debugLine="Private pnlCurrent As B4XView";
_pnlcurrent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _clock_event(String _s) throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Public Sub clock_event(s As String)";
 //BA.debugLineNum = 98;BA.debugLine="If pnlMain.Visible = False Then Return";
if (_pnlmain.getVisible()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 99;BA.debugLine="If csCal.CalDay <> DateTime.GetDayOfMonth(DateTim";
if (_cscal._calday /*int*/ !=__c.DateTime.GetDayOfMonth(__c.DateTime.getNow())) { 
 //BA.debugLineNum = 100;BA.debugLine="Build_Cal";
_build_cal();
 };
 //BA.debugLineNum = 102;BA.debugLine="guiHelpers.ResizeText(s,lblClock)";
_guihelpers._resizetext /*String*/ (ba,_s,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lblclock.getObject())));
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 36;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 37;BA.debugLine="pnlMain.LoadLayout(\"pageHomeBase\")";
_pnlmain.LoadLayout("pageHomeBase",ba);
 //BA.debugLineNum = 38;BA.debugLine="pnlCurrent.LoadLayout(\"viewWeatherCurrent\")";
_pnlcurrent.LoadLayout("viewWeatherCurrent",ba);
 //BA.debugLineNum = 42;BA.debugLine="mpage.EventGbl.Subscribe(gblConst.EVENT_WEATHER_U";
_mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_weather_updated /*String*/ ,this,"WeatherData_RefreshScrn");
 //BA.debugLineNum = 43;BA.debugLine="mpage.EventGbl.Subscribe(gblConst.EVENT_WEATHER_U";
_mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_weather_update_failed /*String*/ ,this,"WeatherData_Fail");
 //BA.debugLineNum = 44;BA.debugLine="mpage.EventGbl.Subscribe(gblConst.EVENT_CLOCK_CHA";
_mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_clock_change /*String*/ ,this,"clock_event");
 //BA.debugLineNum = 45;BA.debugLine="mpage.setup_on_off_scrn_event";
_mpage._setup_on_off_scrn_event /*String*/ ();
 //BA.debugLineNum = 47;BA.debugLine="guiHelpers.SetPanelsTranparent(Array As B4XView(p";
_guihelpers._setpanelstranparent /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_pnlclock,_pnlcal});
 //BA.debugLineNum = 51;BA.debugLine="guiHelpers.SkinButtonNoBorder(Array As Button(btn";
_guihelpers._skinbuttonnoborder /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btncurrtemp.getObject()))});
 //BA.debugLineNum = 52;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblCurre";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblcurrenthigh,_lbllocation,_lblcurrtxt,_lblclock,_lblfeelslike},_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 53;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblCurrD";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lblcurrdesc,_btncurrtemp},_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 55;BA.debugLine="imgCurrent.Bitmap = XUI.LoadBitmap(File.DirAssets";
_imgcurrent._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_xui.LoadBitmap(__c.File.getDirAssets(),"no weather.png"));
 //BA.debugLineNum = 56;BA.debugLine="guiHelpers.ResizeText(\"     Getting Weather Data.";
_guihelpers._resizetext /*String*/ (ba,"     Getting Weather Data...     ",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lblcurrtxt.getObject())));
 //BA.debugLineNum = 58;BA.debugLine="btnCurrTemp.TextSize = 50";
_btncurrtemp.setTextSize((float) (50));
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 88;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _render_scrn() throws Exception{
 //BA.debugLineNum = 108;BA.debugLine="Private Sub Render_Scrn()";
 //BA.debugLineNum = 109;BA.debugLine="If pnlMain.Visible = False Then Return";
if (_pnlmain.getVisible()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 110;BA.debugLine="mpage.oClock.Update_Scrn 'UpdateDateTime";
_mpage._oclock /*sadLogic.HomeCentral.clock*/ ._update_scrn /*String*/ ();
 //BA.debugLineNum = 111;BA.debugLine="Build_Cal";
_build_cal();
 //BA.debugLineNum = 112;BA.debugLine="WeatherData_RefreshScrn";
_weatherdata_refreshscrn();
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 72;BA.debugLine="Menus.SetHeader(\"Home\",\"main_menu_home.png\")";
_menus._setheader /*String*/ (ba,"Home","main_menu_home.png");
 //BA.debugLineNum = 73;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 75;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 77;BA.debugLine="If mpage.tmrTimerCallSub.Exists(Me,\"Render_Scrn\")";
if (_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._exists /*anywheresoftware.b4a.objects.Timer*/ (this,"Render_Scrn")== null) { 
 //BA.debugLineNum = 78;BA.debugLine="mpage.tmrTimerCallSub.ExistsRemoveAdd_DelayedPlu";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._existsremoveadd_delayedplus2 /*String*/ (this,"Render_Scrn",(int) (250),(Object[])(__c.Null));
 };
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public String  _sidemenu_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 204;BA.debugLine="Private Sub SideMenu_ItemClick (Index As Int, Valu";
 //BA.debugLineNum = 205;BA.debugLine="Select Case Value";
switch (BA.switchObjectToInt(_value)) {
}
;
 //BA.debugLineNum = 209;BA.debugLine="mpage.pnlSideMenu.SetVisibleAnimated(380, False)";
_mpage._pnlsidemenu /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 210;BA.debugLine="End Sub";
return "";
}
public String  _weatherdata_beforeupdated() throws Exception{
 //BA.debugLineNum = 191;BA.debugLine="Private Sub WeatherData_BeforeUpdated";
 //BA.debugLineNum = 192;BA.debugLine="guiHelpers.ResizeText(\"Updating weather...\", lblC";
_guihelpers._resizetext /*String*/ (ba,"Updating weather...",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lblcurrdesc.getObject())));
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public String  _weatherdata_fail() throws Exception{
 //BA.debugLineNum = 195;BA.debugLine="Sub WeatherData_Fail";
 //BA.debugLineNum = 196;BA.debugLine="guiHelpers.ResizeText(\"Error, trying again in 1 m";
_guihelpers._resizetext /*String*/ (ba,"Error, trying again in 1 minute",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lbllocation.getObject())));
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public void  _weatherdata_refreshscrn() throws Exception{
ResumableSub_WeatherData_RefreshScrn rsub = new ResumableSub_WeatherData_RefreshScrn(this);
rsub.resume(ba, null);
}
public static class ResumableSub_WeatherData_RefreshScrn extends BA.ResumableSub {
public ResumableSub_WeatherData_RefreshScrn(sadLogic.HomeCentral.pagehome parent) {
this.parent = parent;
}
sadLogic.HomeCentral.pagehome parent;
String _details = "";
String _lowtemp = "";
String _hightemp = "";
String _tempcurr = "";
String _precipitation = "";
String _windspeed = "";
String _feelslike = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 139;BA.debugLine="If pnlMain.Visible = False Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._pnlmain.getVisible()==parent.__c.False) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 140;BA.debugLine="If B4XPages.MainPage.DebugLog Then Log(\"WeatherDa";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._debuglog /*boolean*/ ) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
parent.__c.LogImpl("41680899","WeatherData_RefreshScrn",0);
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 142;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 19;
return;
case 19:
//C
this.state = 13;
;
 //BA.debugLineNum = 143;BA.debugLine="Dim details,lowTemp,highTemp,TempCurr,Precipitati";
_details = "";
_lowtemp = "";
_hightemp = "";
_tempcurr = "";
_precipitation = "";
_windspeed = "";
_feelslike = "";
 //BA.debugLineNum = 144;BA.debugLine="TempCurr     = IIf(mpage.useCel, mpage.WeatherDat";
_tempcurr = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qtemp_c /*int*/ )+"°c")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qtemp_f /*int*/ )+"°f"))));
 //BA.debugLineNum = 145;BA.debugLine="highTemp      = IIf(mpage.useCel, mpage.WeatherDa";
_hightemp = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._high_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._high_f /*int*/ )+"°"))));
 //BA.debugLineNum = 146;BA.debugLine="lowTemp       = IIf(mpage.useCel, mpage.WeatherDa";
_lowtemp = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._low_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._low_f /*int*/ )+"°"))));
 //BA.debugLineNum = 147;BA.debugLine="Precipitation = IIf(mpage.useMetric, mpage.Weathe";
_precipitation = BA.ObjectToString(((parent._mpage._usemetric /*boolean*/ ) ? ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qprecipitation_mm /*String*/ +"mm")) : ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qprecipitation_inches /*String*/ +"inches"))));
 //BA.debugLineNum = 148;BA.debugLine="WindSpeed   = IIf(mpage.useMetric, mpage.WeatherD";
_windspeed = BA.ObjectToString(((parent._mpage._usemetric /*boolean*/ ) ? ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwindspeed_kph /*String*/ +"km/h")) : ((Object)(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwindspeed_mph /*String*/ +"mph"))));
 //BA.debugLineNum = 149;BA.debugLine="FeelsLike      = IIf(mpage.useCel, mpage.WeatherD";
_feelslike = BA.ObjectToString(((parent._mpage._usecel /*boolean*/ ) ? ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qfeelslike_c /*int*/ )+"°")) : ((Object)(BA.NumberToString(parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qfeelslike_f /*int*/ )+"°"))));
 //BA.debugLineNum = 151;BA.debugLine="guiHelpers.ResizeText(mpage.WeatherData.qDescript";
parent._guihelpers._resizetext /*String*/ (ba,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qdescription /*String*/ ,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrdesc.getObject())));
 //BA.debugLineNum = 152;BA.debugLine="guiHelpers.ResizeText(mpage.WeatherData.qLocation";
parent._guihelpers._resizetext /*String*/ (ba,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qlocation /*String*/ ,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lbllocation.getObject())));
 //BA.debugLineNum = 153;BA.debugLine="If guiHelpers.gScreenSizeAprox > 8.5 Then";
if (true) break;

case 13:
//if
this.state = 18;
if (parent._guihelpers._gscreensizeaprox /*double*/ >8.5) { 
this.state = 15;
}else {
this.state = 17;
}if (true) break;

case 15:
//C
this.state = 18;
 //BA.debugLineNum = 154;BA.debugLine="details =   _ 			  \"Precipitation: \" & Precipita";
_details = "Precipitation: "+_precipitation+parent.__c.CRLF+"Humidity: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qhumidity /*String*/ +"%"+parent.__c.CRLF+"Pressure: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qpressure /*String*/ +parent.__c.CRLF+"Wind Speed: "+_windspeed+parent.__c.CRLF+"Wind Direction: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwinddirection /*String*/ +parent.__c.CRLF+"Cloud Cover: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qcloudcover /*String*/ +"%"+parent.__c.CRLF+"Sunrise: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunrise /*String*/ +" - Sunset: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunset /*String*/ +parent.__c.CRLF+"Last Updated At: "+parent._mpage._oclock /*sadLogic.HomeCentral.clock*/ ._formattime /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._lastupdatedat /*long*/ );
 //BA.debugLineNum = 163;BA.debugLine="guiHelpers.ResizeText(details.Trim, lblCurrTXT)";
parent._guihelpers._resizetext /*String*/ (ba,_details.trim(),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrtxt.getObject())));
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 165;BA.debugLine="details =   _ 			  \"Precipitation: \" & Precipita";
_details = "Precipitation: "+_precipitation+parent.__c.CRLF+"Humidity: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qhumidity /*String*/ +"%"+" - Pressure: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qpressure /*String*/ +parent.__c.CRLF+"Wind Speed: "+_windspeed+" - Direction: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qwinddirection /*String*/ +parent.__c.CRLF+"Cloud Cover: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qcloudcover /*String*/ +"%"+parent.__c.CRLF+"Sunrise: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunrise /*String*/ +" - Sunset: "+parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._sunset /*String*/ +parent.__c.CRLF+"Last Updated At: "+parent._mpage._oclock /*sadLogic.HomeCentral.clock*/ ._formattime /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._lastupdatedat /*long*/ );
 //BA.debugLineNum = 172;BA.debugLine="guiHelpers.ResizeText(details.Trim, lblCurrTXT)";
parent._guihelpers._resizetext /*String*/ (ba,_details.trim(),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrtxt.getObject())));
 if (true) break;

case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 174;BA.debugLine="guiHelpers.ResizeText(\"High \" & highTemp   & \"  /";
parent._guihelpers._resizetext /*String*/ (ba,"High "+_hightemp+"  /  Low "+_lowtemp,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblcurrenthigh.getObject())));
 //BA.debugLineNum = 175;BA.debugLine="guiHelpers.ResizeText(TempCurr , btnCurrTemp)";
parent._guihelpers._resizetext /*String*/ (ba,_tempcurr,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._btncurrtemp.getObject())));
 //BA.debugLineNum = 176;BA.debugLine="guiHelpers.ResizeText(\"Feels like: \" & FeelsLike";
parent._guihelpers._resizetext /*String*/ (ba,"Feels like: "+_feelslike,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(parent._lblfeelslike.getObject())));
 //BA.debugLineNum = 178;BA.debugLine="lblCurrTXT.TextSize = lblCurrTXT.TextSize - 4";
parent._lblcurrtxt.setTextSize((float) (parent._lblcurrtxt.getTextSize()-4));
 //BA.debugLineNum = 179;BA.debugLine="btnCurrTemp.TextSize = btnCurrTemp.TextSize - 9";
parent._btncurrtemp.setTextSize((float) (parent._btncurrtemp.getTextSize()-9));
 //BA.debugLineNum = 181;BA.debugLine="mpage.WeatherData.LoadWeatherIcon(mpage.WeatherDa";
parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._loadweathericon /*String*/ (parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._forcastdays /*sadLogic.HomeCentral.clsweatherdataday[]*/ [(int) (0)]._iconid /*int*/ ,parent._imgcurrent,parent._mpage._weatherdata /*sadLogic.HomeCentral.clsweatherdata*/ ._qisday /*boolean*/ );
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SIDEMENU_ITEMCLICK"))
	return _sidemenu_itemclick(((Number)args[0]).intValue(), (Object) args[1]);
return BA.SubDelegator.SubNotFound;
}
}
