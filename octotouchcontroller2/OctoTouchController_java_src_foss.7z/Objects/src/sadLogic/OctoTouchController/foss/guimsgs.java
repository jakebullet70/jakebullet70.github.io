package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class guimsgs extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.guimsgs");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.guimsgs.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.keywords.StringBuilderWrapper _msg = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public anywheresoftware.b4a.objects.collections.Map  _buildcoolingfanmnu() throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.collections.Map _po = null;
 //BA.debugLineNum = 145;BA.debugLine="Public Sub BuildCoolingFanMnu() As Map";
 //BA.debugLineNum = 146;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 147;BA.debugLine="Dim po As Map : po.Initialize";
_po = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 147;BA.debugLine="Dim po As Map : po.Initialize";
_po.Initialize();
 //BA.debugLineNum = 149;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan Off")).PopAll().getObject()),(Object)("0"));
 //BA.debugLineNum = 150;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 100%")).PopAll().getObject()),(Object)("100"));
 //BA.debugLineNum = 151;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 77%")).PopAll().getObject()),(Object)("75"));
 //BA.debugLineNum = 152;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 50%")).PopAll().getObject()),(Object)("50"));
 //BA.debugLineNum = 153;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 25%")).PopAll().getObject()),(Object)("25"));
 //BA.debugLineNum = 154;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 33%")).PopAll().getObject()),(Object)("33"));
 //BA.debugLineNum = 155;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 40%")).PopAll().getObject()),(Object)("40"));
 //BA.debugLineNum = 156;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 60%")).PopAll().getObject()),(Object)("60"));
 //BA.debugLineNum = 157;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).A";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(" Fan 85%")).PopAll().getObject()),(Object)("85"));
 //BA.debugLineNum = 159;BA.debugLine="Return po";
if (true) return _po;
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.Map  _buildfunctionsetupmenu() throws Exception{
String _txt = "";
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.collections.Map _po = null;
anywheresoftware.b4a.objects.collections.Map _data = null;
String _fname = "";
int _xx = 0;
boolean _ron = false;
boolean _won = false;
 //BA.debugLineNum = 164;BA.debugLine="Public Sub BuildFunctionSetupMenu() As Map";
 //BA.debugLineNum = 166;BA.debugLine="Dim txt As String";
_txt = "";
 //BA.debugLineNum = 167;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 168;BA.debugLine="Dim po As Map : po.Initialize";
_po = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 168;BA.debugLine="Dim po As Map : po.Initialize";
_po.Initialize();
 //BA.debugLineNum = 171;BA.debugLine="txt = \" Change Filament Wizard\"";
_txt = " Change Filament Wizard";
 //BA.debugLineNum = 172;BA.debugLine="If config.ReadWizardFilamentChangeFLAG  Then";
if (_config._readwizardfilamentchangeflag /*boolean*/ (getActivityBA())) { 
 //BA.debugLineNum = 173;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIALI";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("fl"));
 }else {
 //BA.debugLineNum = 176;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("fl"));
 };
 //BA.debugLineNum = 180;BA.debugLine="txt = \"Set Z Offset\"";
_txt = "Set Z Offset";
 //BA.debugLineNum = 181;BA.debugLine="If config.ReadZOffsetFLAG  Then";
if (_config._readzoffsetflag /*boolean*/ (getActivityBA())) { 
 //BA.debugLineNum = 182;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIALI";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("zo"));
 }else {
 //BA.debugLineNum = 185;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("zo"));
 };
 //BA.debugLineNum = 189;BA.debugLine="If oc.Klippy Then";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 190;BA.debugLine="txt = \" Screw Bed Leveling Wizard\"";
_txt = " Screw Bed Leveling Wizard";
 }else {
 //BA.debugLineNum = 192;BA.debugLine="txt = \" Manual Bed Leveling Wizard\"";
_txt = " Manual Bed Leveling Wizard";
 };
 //BA.debugLineNum = 194;BA.debugLine="If config.ReadManualBedScrewLevelFLAG  Then";
if (_config._readmanualbedscrewlevelflag /*boolean*/ (getActivityBA())) { 
 //BA.debugLineNum = 195;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIALI";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("bl"));
 }else {
 //BA.debugLineNum = 198;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("bl"));
 };
 //BA.debugLineNum = 202;BA.debugLine="If oc.Klippy Then '--- when I get a marlin printe";
if (_oc._klippy /*boolean*/ ) { 
 //BA.debugLineNum = 203;BA.debugLine="txt = \"Manual Mesh Leveling\"";
_txt = "Manual Mesh Leveling";
 //BA.debugLineNum = 204;BA.debugLine="If config.ReadManualBedMeshLevelFLAG  Then";
if (_config._readmanualbedmeshlevelflag /*boolean*/ (getActivityBA())) { 
 //BA.debugLineNum = 205;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIAL";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("mms"));
 }else {
 //BA.debugLineNum = 208;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT)";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("mms"));
 };
 };
 //BA.debugLineNum = 221;BA.debugLine="txt = \" BL/CR Touch Test Settings\"";
_txt = " BL/CR Touch Test Settings";
 //BA.debugLineNum = 222;BA.debugLine="If config.ReadBLCRtouchFLAG  Then";
if (_config._readblcrtouchflag /*boolean*/ (getActivityBA())) { 
 //BA.debugLineNum = 223;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIALI";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("blcr"));
 }else {
 //BA.debugLineNum = 226;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT).";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("blcr"));
 };
 //BA.debugLineNum = 231;BA.debugLine="Dim data As Map, fname As String";
_data = new anywheresoftware.b4a.objects.collections.Map();
_fname = "";
 //BA.debugLineNum = 232;BA.debugLine="For xx = 0 To 7";
{
final int step42 = 1;
final int limit42 = (int) (7);
_xx = (int) (0) ;
for (;_xx <= limit42 ;_xx = _xx + step42 ) {
 //BA.debugLineNum = 233;BA.debugLine="fname = xx & gblConst.GCODE_CUSTOM_SETUP_FILE";
_fname = BA.NumberToString(_xx)+_gblconst._gcode_custom_setup_file /*String*/ ;
 //BA.debugLineNum = 234;BA.debugLine="If File.Exists(xui.DefaultFolder,fname) Then";
if (__c.File.Exists(_xui.getDefaultFolder(),_fname)) { 
 //BA.debugLineNum = 235;BA.debugLine="data = File.ReadMap(xui.DefaultFolder,fname)";
_data = __c.File.ReadMap(_xui.getDefaultFolder(),_fname);
 //BA.debugLineNum = 236;BA.debugLine="txt = \" \" & data.Get(\"desc\")";
_txt = " "+BA.ObjectToString(_data.Get((Object)("desc")));
 //BA.debugLineNum = 237;BA.debugLine="Dim rOn As Boolean = data.GetDefault(\"rmenu\",Fa";
_ron = BA.ObjectToBoolean(_data.GetDefault((Object)("rmenu"),(Object)(__c.False)));
 //BA.debugLineNum = 238;BA.debugLine="Dim wOn As Boolean = data.GetDefault(\"wmenu\",Fa";
_won = BA.ObjectToBoolean(_data.GetDefault((Object)("wmenu"),(Object)(__c.False)));
 //BA.debugLineNum = 239;BA.debugLine="If rOn Or wOn Then";
if (_ron || _won) { 
 //BA.debugLineNum = 240;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.MATERIA";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (2))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe5ca)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt)).PopAll().getObject()),(Object)("g"+BA.NumberToString(_xx)));
 }else {
 //BA.debugLineNum = 243;BA.debugLine="po.Put(cs.Initialize.Typeface(Typeface.DEFAULT";
_po.Put((Object)(_cs.Initialize().Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence(_txt.trim())).PopAll().getObject()),(Object)("g"+BA.NumberToString(_xx)));
 };
 };
 }
};
 //BA.debugLineNum = 248;BA.debugLine="Return po";
if (true) return _po;
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.Map  _buildoptionsmenu(boolean _nooctoconnection) throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 84;BA.debugLine="Public Sub BuildOptionsMenu(NoOctoConnection As Bo";
 //BA.debugLineNum = 86;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 87;BA.debugLine="Dim m As Map : m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 87;BA.debugLine="Dim m As Map : m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 89;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe30b)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   General Settings")).PopAll().getObject()),(Object)("gn"));
 //BA.debugLineNum = 92;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe859)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Android Power Settings")).PopAll().getObject()),(Object)("pw"));
 //BA.debugLineNum = 112;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe8c1)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Right Side Menu Options")).PopAll().getObject()),(Object)("plg"));
 //BA.debugLineNum = 121;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe24a)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Movement Functions Menu")).PopAll().getObject()),(Object)("fn"));
 //BA.debugLineNum = 124;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe3b7)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Color Themes")).PopAll().getObject()),(Object)("thm1"));
 //BA.debugLineNum = 127;BA.debugLine="If NoOctoConnection = False Then";
if (_nooctoconnection==__c.False) { 
 //BA.debugLineNum = 128;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typefac";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe308)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Printer Connection")).PopAll().getObject()),(Object)("oc"));
 };
 //BA.debugLineNum = 132;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe24d)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Read Internal Log File")).PopAll().getObject()),(Object)("rt"));
 //BA.debugLineNum = 135;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe864)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   Check For Update")).PopAll().getObject()),(Object)("cup"));
 //BA.debugLineNum = 138;BA.debugLine="m.Put(cs.Initialize.Append(\" \").Typeface(Typeface";
_m.Put((Object)(_cs.Initialize().Append(BA.ObjectToCharSequence(" ")).Typeface(__c.Typeface.getMATERIALICONS()).VerticalAlign(__c.DipToCurrent((int) (6))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xe85a)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("   About Me (Yes, Me!)")).PopAll().getObject()),(Object)("ab"));
 //BA.debugLineNum = 141;BA.debugLine="Return m";
if (true) return _m;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.Map  _buildpluginoptionsmenu() throws Exception{
anywheresoftware.b4a.objects.collections.Map _popupmemuitems = null;
int _xx = 0;
String _fname = "";
anywheresoftware.b4a.objects.collections.Map _data = null;
String _desc = "";
 //BA.debugLineNum = 263;BA.debugLine="Public Sub BuildPluginOptionsMenu() As Map";
 //BA.debugLineNum = 268;BA.debugLine="Dim popUpMemuItems As Map = CreateMap(\"PSU Contro";
_popupmemuitems = new anywheresoftware.b4a.objects.collections.Map();
_popupmemuitems = __c.createMap(new Object[] {(Object)("PSU Control"),(Object)("psu")});
 //BA.debugLineNum = 271;BA.debugLine="For xx = 1 To 8";
{
final int step2 = 1;
final int limit2 = (int) (8);
_xx = (int) (1) ;
for (;_xx <= limit2 ;_xx = _xx + step2 ) {
 //BA.debugLineNum = 272;BA.debugLine="Dim fname As String = xx & gblConst.HTTP_ONOFF_S";
_fname = BA.NumberToString(_xx)+_gblconst._http_onoff_setup_file /*String*/ ;
 //BA.debugLineNum = 273;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = __c.File.ReadMap(_xui.getDefaultFolder(),_fname);
 //BA.debugLineNum = 274;BA.debugLine="Dim desc As String = Data.GetDefault(\"desc\",\"Gen";
_desc = BA.ObjectToString(_data.GetDefault((Object)("desc"),(Object)("Generic HTTP Control "+BA.NumberToString(_xx))));
 //BA.debugLineNum = 275;BA.debugLine="popUpMemuItems.Put(desc,xx)";
_popupmemuitems.Put((Object)(_desc),(Object)(_xx));
 }
};
 //BA.debugLineNum = 278;BA.debugLine="Return popUpMemuItems";
if (true) return _popupmemuitems;
 //BA.debugLineNum = 280;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Const mModule As String = \"guiMsgs\" 'igno";
_mmodule = "guiMsgs";
 //BA.debugLineNum = 9;BA.debugLine="Dim Msg As StringBuilder";
_msg = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _getconnectfailedmsg() throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Public Sub GetConnectFailedMsg() As String";
 //BA.debugLineNum = 27;BA.debugLine="Msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 28;BA.debugLine="Msg.Append(\"Connection Failed.\").Append(CRLF)";
_msg.Append("Connection Failed.").Append(__c.CRLF);
 //BA.debugLineNum = 29;BA.debugLine="Msg.Append(\"Is Octoprint turned on?\").Append(CRLF";
_msg.Append("Is Octoprint turned on?").Append(__c.CRLF).Append("Are Your IP And Port correct?").Append(__c.CRLF);
 //BA.debugLineNum = 30;BA.debugLine="Return Msg.ToString";
if (true) return _msg.ToString();
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public String  _getconnectiontext(boolean _connectedbuterror) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Public Sub GetConnectionText(connectedButError As";
 //BA.debugLineNum = 37;BA.debugLine="Msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 38;BA.debugLine="If B4XPages.MainPage.oMasterController.oWS.pConne";
if (_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pconnected /*boolean*/ ==__c.False && _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (getActivityBA())._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._ows /*sadLogic.OctoTouchController.foss.octowebsocket*/ ._pclosedreason /*String*/ .contains("protocol v")) { 
 //BA.debugLineNum = 40;BA.debugLine="Msg.Append(\"Connected to Octoprint but there is";
_msg.Append("Connected to Octoprint but there is an error ");
 //BA.debugLineNum = 41;BA.debugLine="Msg.Append(\"with the Octoprint socket. Please re";
_msg.Append("with the Octoprint socket. Please restart ").Append(__c.CRLF);
 //BA.debugLineNum = 42;BA.debugLine="Msg.Append(\"Octoprint and make sure sure you are";
_msg.Append("Octoprint and make sure sure you are connected ");
 //BA.debugLineNum = 43;BA.debugLine="Msg.Append(\"to the printer.\")";
_msg.Append("to the printer.");
 //BA.debugLineNum = 44;BA.debugLine="Return Msg.ToString";
if (true) return _msg.ToString();
 };
 //BA.debugLineNum = 47;BA.debugLine="If connectedButError Then";
if (_connectedbuterror) { 
 //BA.debugLineNum = 48;BA.debugLine="Msg.Append(\"Connected to Octoprint but there is";
_msg.Append("Connected to Octoprint but there is an error.");
 //BA.debugLineNum = 49;BA.debugLine="Msg.Append(\"Check that Octoprint is connected to";
_msg.Append("Check that Octoprint is connected to the printer?").Append(__c.CRLF);
 //BA.debugLineNum = 50;BA.debugLine="Msg.Append(\"Make sure you can print from the Oct";
_msg.Append("Make sure you can print from the Octoprint UI.");
 }else {
 //BA.debugLineNum = 52;BA.debugLine="Msg.Append(\"No connection to Octoprint. Is Octop";
_msg.Append("No connection to Octoprint. Is Octoprint turned on?");
 //BA.debugLineNum = 53;BA.debugLine="Msg.Append(CRLF).Append(\"Connected to the printe";
_msg.Append(__c.CRLF).Append("Connected to the printer?");
 };
 //BA.debugLineNum = 56;BA.debugLine="Return Msg.ToString";
if (true) return _msg.ToString();
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _getoctopluginwarningtxt() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Public Sub GetOctoPluginWarningTxt() As String";
 //BA.debugLineNum = 61;BA.debugLine="Msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 62;BA.debugLine="Msg.Append(\"When setting up a connection here to";
_msg.Append("When setting up a connection here to an Octoprint ");
 //BA.debugLineNum = 63;BA.debugLine="Msg.Append(\"plugin make sure it is working in Oct";
_msg.Append("plugin make sure it is working in Octoprint first ");
 //BA.debugLineNum = 64;BA.debugLine="Msg.Append(\"before you complete the setup here.\")";
_msg.Append("before you complete the setup here.").Append(__c.CRLF);
 //BA.debugLineNum = 66;BA.debugLine="Return Msg.ToString";
if (true) return _msg.ToString();
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
