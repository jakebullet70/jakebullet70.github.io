package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class conversionmod extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.conversionmod");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.conversionmod.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public float  _butter_cup2gram(float _value) throws Exception{
 //BA.debugLineNum = 135;BA.debugLine="Public Sub butter_cup2gram(value As Float) As Floa";
 //BA.debugLineNum = 136;BA.debugLine="Return (value * 226.8) '--- butter";
if (true) return (float) ((_value*226.8));
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_cup2oz(float _value) throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Public Sub butter_cup2oz(value As Float) As Float";
 //BA.debugLineNum = 130;BA.debugLine="Return (value * 8.0)";
if (true) return (float) ((_value*8.0));
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_cup2stick(float _value) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Public Sub butter_cup2stick(value As Float) As Flo";
 //BA.debugLineNum = 133;BA.debugLine="Return (value * 2.0)";
if (true) return (float) ((_value*2.0));
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_cup2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 138;BA.debugLine="Public Sub butter_cup2tbsp(value As Float) As Floa";
 //BA.debugLineNum = 139;BA.debugLine="Return (value * 16)";
if (true) return (float) ((_value*16));
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_grams2cup(float _value) throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Public Sub butter_grams2cup(value As Float) As Flo";
 //BA.debugLineNum = 123;BA.debugLine="Return (value * 0.00423)";
if (true) return (float) ((_value*0.00423));
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_grams2oz(float _value) throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Public Sub butter_grams2oz(value As Float) As Floa";
 //BA.debugLineNum = 117;BA.debugLine="Return (value *  0.0352739619)";
if (true) return (float) ((_value*0.0352739619));
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_grams2stick(float _value) throws Exception{
 //BA.debugLineNum = 119;BA.debugLine="Public Sub butter_grams2stick(value As Float) As F";
 //BA.debugLineNum = 120;BA.debugLine="Return butter_grams2cup(value) * 2";
if (true) return (float) (_butter_grams2cup(_value)*2);
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_grams2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 125;BA.debugLine="Public Sub butter_grams2tbsp(value As Float) As Fl";
 //BA.debugLineNum = 126;BA.debugLine="Return (value * 0.06763)";
if (true) return (float) ((_value*0.06763));
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_oz2cup(float _value) throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Public Sub butter_oz2cup(value As Float) As Float";
 //BA.debugLineNum = 110;BA.debugLine="Return (value * 0.12500)";
if (true) return (float) ((_value*0.12500));
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_oz2grams(float _value) throws Exception{
 //BA.debugLineNum = 103;BA.debugLine="Public Sub butter_oz2grams(value As Float) As Floa";
 //BA.debugLineNum = 104;BA.debugLine="Return (value * 28.35)";
if (true) return (float) ((_value*28.35));
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_oz2stick(float _value) throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Public Sub butter_oz2stick(value As Float) As Floa";
 //BA.debugLineNum = 107;BA.debugLine="Return value / 4.0";
if (true) return (float) (_value/(double)4.0);
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_oz2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Public Sub butter_oz2tbsp(value As Float) As Float";
 //BA.debugLineNum = 113;BA.debugLine="Return (value * 2.0)";
if (true) return (float) ((_value*2.0));
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_stick2cups(float _value) throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Public Sub butter_stick2cups(value As Float) As Fl";
 //BA.debugLineNum = 165;BA.debugLine="Return (value * 0.5)";
if (true) return (float) ((_value*0.5));
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_stick2gram(float _value) throws Exception{
 //BA.debugLineNum = 161;BA.debugLine="Public Sub butter_stick2gram(value As Float) As Fl";
 //BA.debugLineNum = 162;BA.debugLine="Return (value * 113.0) '--- butter";
if (true) return (float) ((_value*113.0));
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_stick2oz(float _value) throws Exception{
 //BA.debugLineNum = 155;BA.debugLine="Public Sub butter_stick2oz(value As Float) As Floa";
 //BA.debugLineNum = 156;BA.debugLine="Return (value * 4.0)";
if (true) return (float) ((_value*4.0));
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_stick2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 158;BA.debugLine="Public Sub butter_stick2tbsp(value As Float) As Fl";
 //BA.debugLineNum = 159;BA.debugLine="Return (value * 8.0)";
if (true) return (float) ((_value*8.0));
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_tbsp2cups(float _value) throws Exception{
 //BA.debugLineNum = 151;BA.debugLine="Public Sub butter_tbsp2cups(value As Float) As Flo";
 //BA.debugLineNum = 152;BA.debugLine="Return (value * 0.0625)";
if (true) return (float) ((_value*0.0625));
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_tbsp2gram(float _value) throws Exception{
 //BA.debugLineNum = 148;BA.debugLine="Public Sub butter_tbsp2gram(value As Float) As Flo";
 //BA.debugLineNum = 149;BA.debugLine="Return (value * 14.18) '--- butter";
if (true) return (float) ((_value*14.18));
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_tbsp2oz(float _value) throws Exception{
 //BA.debugLineNum = 142;BA.debugLine="Public Sub butter_tbsp2oz(value As Float) As Float";
 //BA.debugLineNum = 143;BA.debugLine="Return (value * 0.5)";
if (true) return (float) ((_value*0.5));
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return 0f;
}
public float  _butter_tbsp2stick(float _value) throws Exception{
 //BA.debugLineNum = 145;BA.debugLine="Public Sub butter_tbsp2stick(value As Float) As Fl";
 //BA.debugLineNum = 146;BA.debugLine="Return (value * 0.125)";
if (true) return (float) ((_value*0.125));
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
return 0f;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 5;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public float  _length_cm2inches(float _value) throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Public Sub length_cm2inches(value As Float) As Flo";
 //BA.debugLineNum = 89;BA.debugLine="Return value * 0.39370";
if (true) return (float) (_value*0.39370);
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return 0f;
}
public float  _length_cm2mm(float _value) throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Public Sub length_cm2mm(value As Float) As Float";
 //BA.debugLineNum = 86;BA.debugLine="Return (value / 0.10)";
if (true) return (float) ((_value/(double)0.10));
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return 0f;
}
public float  _length_inches2cm(float _value) throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Public Sub length_inches2cm(value As Float) As Flo";
 //BA.debugLineNum = 95;BA.debugLine="Return (value * 2.54000)";
if (true) return (float) ((_value*2.54000));
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return 0f;
}
public float  _length_inches2mm(float _value) throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Public Sub length_inches2mm(value As Float) As Flo";
 //BA.debugLineNum = 92;BA.debugLine="Return length_cm2mm(value * 2.54000)";
if (true) return _length_cm2mm((float) (_value*2.54000));
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return 0f;
}
public float  _length_mm2cm(float _value) throws Exception{
 //BA.debugLineNum = 79;BA.debugLine="Public Sub length_mm2cm(value As Float) As Float";
 //BA.debugLineNum = 80;BA.debugLine="Return (value * 0.10)";
if (true) return (float) ((_value*0.10));
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return 0f;
}
public float  _length_mm2inches(float _value) throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Public Sub length_mm2inches(value As Float) As Flo";
 //BA.debugLineNum = 83;BA.debugLine="Return length_cm2inches(length_mm2cm(value))";
if (true) return _length_cm2inches(_length_mm2cm(_value));
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return 0f;
}
public float  _temp_c2f(float _value) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Public Sub temp_c2f(value As Float) As Float";
 //BA.debugLineNum = 69;BA.debugLine="Return (value * 1.8) + 32";
if (true) return (float) ((_value*1.8)+32);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return 0f;
}
public float  _temp_f2c(float _value) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Public Sub temp_f2c(value As Float) As Float";
 //BA.debugLineNum = 72;BA.debugLine="Return (value - 32.0) * 0.5555555";
if (true) return (float) ((_value-32.0)*0.5555555);
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2floz(float _value) throws Exception{
 //BA.debugLineNum = 225;BA.debugLine="Public Sub volume_cups2floz(value As Float) As Flo";
 //BA.debugLineNum = 226;BA.debugLine="Return (value * 8.0)";
if (true) return (float) ((_value*8.0));
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2gal(float _value) throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Public Sub volume_cups2gal(value As Float) As Floa";
 //BA.debugLineNum = 223;BA.debugLine="Return (value * 0.0625)";
if (true) return (float) ((_value*0.0625));
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2liters(float _value) throws Exception{
 //BA.debugLineNum = 231;BA.debugLine="Public Sub volume_cups2liters(value As Float) As F";
 //BA.debugLineNum = 232;BA.debugLine="Return (value * 0.236588)";
if (true) return (float) ((_value*0.236588));
 //BA.debugLineNum = 233;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2ml(float _value) throws Exception{
 //BA.debugLineNum = 228;BA.debugLine="Public Sub volume_cups2ml(value As Float) As Float";
 //BA.debugLineNum = 229;BA.debugLine="Return (value * 236.588)";
if (true) return (float) ((_value*236.588));
 //BA.debugLineNum = 230;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2pints(float _value) throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Public Sub volume_cups2pints(value As Float) As Fl";
 //BA.debugLineNum = 238;BA.debugLine="Return (value * 0.5)";
if (true) return (float) ((_value*0.5));
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2quarts(float _value) throws Exception{
 //BA.debugLineNum = 234;BA.debugLine="Public Sub volume_cups2quarts(value As Float) As F";
 //BA.debugLineNum = 235;BA.debugLine="Return (value * 0.25)";
if (true) return (float) ((_value*0.25));
 //BA.debugLineNum = 236;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 240;BA.debugLine="Public Sub volume_cups2tbsp(value As Float) As Flo";
 //BA.debugLineNum = 241;BA.debugLine="Return (value * 16.0)";
if (true) return (float) ((_value*16.0));
 //BA.debugLineNum = 242;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_cups2tsp(float _value) throws Exception{
 //BA.debugLineNum = 243;BA.debugLine="Public Sub volume_cups2tsp(value As Float) As Floa";
 //BA.debugLineNum = 244;BA.debugLine="Return (value * 48.0)";
if (true) return (float) ((_value*48.0));
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2cups(float _value) throws Exception{
 //BA.debugLineNum = 200;BA.debugLine="Public Sub volume_floz2cups(value As Float) As Flo";
 //BA.debugLineNum = 201;BA.debugLine="Return (value * 0.125)";
if (true) return (float) ((_value*0.125));
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2gal(float _value) throws Exception{
 //BA.debugLineNum = 197;BA.debugLine="Public Sub volume_floz2gal(value As Float) As Floa";
 //BA.debugLineNum = 198;BA.debugLine="Return (value * 0.0078125)";
if (true) return (float) ((_value*0.0078125));
 //BA.debugLineNum = 199;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2liters(float _value) throws Exception{
 //BA.debugLineNum = 206;BA.debugLine="Public Sub volume_floz2liters(value As Float) As F";
 //BA.debugLineNum = 207;BA.debugLine="Return (value * 0.0295735)";
if (true) return (float) ((_value*0.0295735));
 //BA.debugLineNum = 208;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2ml(float _value) throws Exception{
 //BA.debugLineNum = 203;BA.debugLine="Public Sub volume_floz2ml(value As Float) As Float";
 //BA.debugLineNum = 204;BA.debugLine="Return (value * 29.5735)";
if (true) return (float) ((_value*29.5735));
 //BA.debugLineNum = 205;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2pints(float _value) throws Exception{
 //BA.debugLineNum = 212;BA.debugLine="Public Sub volume_floz2pints(value As Float) As Fl";
 //BA.debugLineNum = 213;BA.debugLine="Return (value * 0.0625)";
if (true) return (float) ((_value*0.0625));
 //BA.debugLineNum = 214;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2quarts(float _value) throws Exception{
 //BA.debugLineNum = 209;BA.debugLine="Public Sub volume_floz2quarts(value As Float) As F";
 //BA.debugLineNum = 210;BA.debugLine="Return (value * 0.03125)";
if (true) return (float) ((_value*0.03125));
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 215;BA.debugLine="Public Sub volume_floz2tbsp(value As Float) As Flo";
 //BA.debugLineNum = 216;BA.debugLine="Return (value * 2)";
if (true) return (float) ((_value*2));
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_floz2tsp(float _value) throws Exception{
 //BA.debugLineNum = 218;BA.debugLine="Public Sub volume_floz2tsp(value As Float) As Floa";
 //BA.debugLineNum = 219;BA.debugLine="Return (value * 6)";
if (true) return (float) ((_value*6));
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2cups(float _value) throws Exception{
 //BA.debugLineNum = 193;BA.debugLine="Public Sub volume_gal2cups(value As Float) As Floa";
 //BA.debugLineNum = 194;BA.debugLine="Return (value * 16.0)";
if (true) return (float) ((_value*16.0));
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2floz(float _value) throws Exception{
 //BA.debugLineNum = 172;BA.debugLine="Public Sub volume_gal2floz(value As Float) As Floa";
 //BA.debugLineNum = 173;BA.debugLine="Return (value * 128.0)";
if (true) return (float) ((_value*128.0));
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2liters(float _value) throws Exception{
 //BA.debugLineNum = 187;BA.debugLine="Public Sub volume_gal2liters(value As Float) As Fl";
 //BA.debugLineNum = 188;BA.debugLine="Return (value * 3.78541)";
if (true) return (float) ((_value*3.78541));
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2ml(float _value) throws Exception{
 //BA.debugLineNum = 190;BA.debugLine="Public Sub volume_gal2ml(value As Float) As Float";
 //BA.debugLineNum = 191;BA.debugLine="Return (value * 3785.41)";
if (true) return (float) ((_value*3785.41));
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2pints(float _value) throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Public Sub volume_gal2pints(value As Float) As Flo";
 //BA.debugLineNum = 182;BA.debugLine="Return (value * 8.0)";
if (true) return (float) ((_value*8.0));
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2quarts(float _value) throws Exception{
 //BA.debugLineNum = 184;BA.debugLine="Public Sub volume_gal2quarts(value As Float) As Fl";
 //BA.debugLineNum = 185;BA.debugLine="Return (value * 4.0)";
if (true) return (float) ((_value*4.0));
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 178;BA.debugLine="Public Sub volume_gal2tbsp(value As Float) As Floa";
 //BA.debugLineNum = 179;BA.debugLine="Return (value * 256.0)";
if (true) return (float) ((_value*256.0));
 //BA.debugLineNum = 180;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_gal2tsp(float _value) throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Public Sub volume_gal2tsp(value As Float) As Float";
 //BA.debugLineNum = 176;BA.debugLine="Return (value * 768.0)";
if (true) return (float) ((_value*768.0));
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2cups(float _value) throws Exception{
 //BA.debugLineNum = 387;BA.debugLine="Public Sub volume_liter2cups(value As Float) As Fl";
 //BA.debugLineNum = 388;BA.debugLine="Return (value * 4.22675)";
if (true) return (float) ((_value*4.22675));
 //BA.debugLineNum = 389;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2floz(float _value) throws Exception{
 //BA.debugLineNum = 375;BA.debugLine="Public Sub volume_liter2floz(value As Float) As Fl";
 //BA.debugLineNum = 376;BA.debugLine="Return (value * 33.814)";
if (true) return (float) ((_value*33.814));
 //BA.debugLineNum = 377;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2gal(float _value) throws Exception{
 //BA.debugLineNum = 372;BA.debugLine="Public Sub volume_liter2gal(value As Float) As Flo";
 //BA.debugLineNum = 373;BA.debugLine="Return (value * 0.264172)";
if (true) return (float) ((_value*0.264172));
 //BA.debugLineNum = 374;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2ml(float _value) throws Exception{
 //BA.debugLineNum = 381;BA.debugLine="Public Sub volume_liter2ml(value As Float) As Floa";
 //BA.debugLineNum = 382;BA.debugLine="Return (value * 1000.0)";
if (true) return (float) ((_value*1000.0));
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2pints(float _value) throws Exception{
 //BA.debugLineNum = 393;BA.debugLine="Public Sub volume_liter2pints(value As Float) As F";
 //BA.debugLineNum = 394;BA.debugLine="Return (value * 2.11338)";
if (true) return (float) ((_value*2.11338));
 //BA.debugLineNum = 395;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2quart(float _value) throws Exception{
 //BA.debugLineNum = 378;BA.debugLine="Public Sub volume_liter2quart(value As Float) As F";
 //BA.debugLineNum = 379;BA.debugLine="Return (value * 1.05669)";
if (true) return (float) ((_value*1.05669));
 //BA.debugLineNum = 380;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 384;BA.debugLine="Public Sub volume_liter2tbsp(value As Float) As Fl";
 //BA.debugLineNum = 385;BA.debugLine="Return (value * 67.628)";
if (true) return (float) ((_value*67.628));
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_liter2tsp(float _value) throws Exception{
 //BA.debugLineNum = 390;BA.debugLine="Public Sub volume_liter2tsp(value As Float) As Flo";
 //BA.debugLineNum = 391;BA.debugLine="Return (value * 202.884)";
if (true) return (float) ((_value*202.884));
 //BA.debugLineNum = 392;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2cups(float _value) throws Exception{
 //BA.debugLineNum = 362;BA.debugLine="Public Sub volume_ml2cups(value As Float) As Float";
 //BA.debugLineNum = 363;BA.debugLine="Return (value * 0.00422675)";
if (true) return (float) ((_value*0.00422675));
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2floz(float _value) throws Exception{
 //BA.debugLineNum = 350;BA.debugLine="Public Sub volume_ml2floz(value As Float) As Float";
 //BA.debugLineNum = 351;BA.debugLine="Return (value * 0.033814)";
if (true) return (float) ((_value*0.033814));
 //BA.debugLineNum = 352;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2gal(float _value) throws Exception{
 //BA.debugLineNum = 347;BA.debugLine="Public Sub volume_ml2gal(value As Float) As Float";
 //BA.debugLineNum = 348;BA.debugLine="Return (value * 0.000264172)";
if (true) return (float) ((_value*0.000264172));
 //BA.debugLineNum = 349;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2liters(float _value) throws Exception{
 //BA.debugLineNum = 356;BA.debugLine="Public Sub volume_ml2liters(value As Float) As Flo";
 //BA.debugLineNum = 357;BA.debugLine="Return (value * 0.001)";
if (true) return (float) ((_value*0.001));
 //BA.debugLineNum = 358;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2pints(float _value) throws Exception{
 //BA.debugLineNum = 368;BA.debugLine="Public Sub volume_ml2pints(value As Float) As Floa";
 //BA.debugLineNum = 369;BA.debugLine="Return (value * 0.00211338)";
if (true) return (float) ((_value*0.00211338));
 //BA.debugLineNum = 370;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2quart(float _value) throws Exception{
 //BA.debugLineNum = 353;BA.debugLine="Public Sub volume_ml2quart(value As Float) As Floa";
 //BA.debugLineNum = 354;BA.debugLine="Return (value * 0.00105669)";
if (true) return (float) ((_value*0.00105669));
 //BA.debugLineNum = 355;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 359;BA.debugLine="Public Sub volume_ml2tbsp(value As Float) As Float";
 //BA.debugLineNum = 360;BA.debugLine="Return (value * 0.067628)";
if (true) return (float) ((_value*0.067628));
 //BA.debugLineNum = 361;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_ml2tsp(float _value) throws Exception{
 //BA.debugLineNum = 365;BA.debugLine="Public Sub volume_ml2tsp(value As Float) As Float";
 //BA.debugLineNum = 366;BA.debugLine="Return (value * 0.202884)";
if (true) return (float) ((_value*0.202884));
 //BA.debugLineNum = 367;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2cups(float _value) throws Exception{
 //BA.debugLineNum = 262;BA.debugLine="Public Sub volume_pints2cups(value As Float) As Fl";
 //BA.debugLineNum = 263;BA.debugLine="Return (value * 2.0)";
if (true) return (float) ((_value*2.0));
 //BA.debugLineNum = 264;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2floz(float _value) throws Exception{
 //BA.debugLineNum = 250;BA.debugLine="Public Sub volume_pints2floz(value As Float) As Fl";
 //BA.debugLineNum = 251;BA.debugLine="Return (value * 16.0)";
if (true) return (float) ((_value*16.0));
 //BA.debugLineNum = 252;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2gal(float _value) throws Exception{
 //BA.debugLineNum = 247;BA.debugLine="Public Sub volume_pints2gal(value As Float) As Flo";
 //BA.debugLineNum = 248;BA.debugLine="Return (value * 0.125)";
if (true) return (float) ((_value*0.125));
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2liters(float _value) throws Exception{
 //BA.debugLineNum = 256;BA.debugLine="Public Sub volume_pints2liters(value As Float) As";
 //BA.debugLineNum = 257;BA.debugLine="Return (value * 0.473176)";
if (true) return (float) ((_value*0.473176));
 //BA.debugLineNum = 258;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2ml(float _value) throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Public Sub volume_pints2ml(value As Float) As Floa";
 //BA.debugLineNum = 254;BA.debugLine="Return (value * 473.176)";
if (true) return (float) ((_value*473.176));
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2quarts(float _value) throws Exception{
 //BA.debugLineNum = 259;BA.debugLine="Public Sub volume_pints2quarts(value As Float) As";
 //BA.debugLineNum = 260;BA.debugLine="Return (value * 0.5)";
if (true) return (float) ((_value*0.5));
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 265;BA.debugLine="Public Sub volume_pints2tbsp(value As Float) As Fl";
 //BA.debugLineNum = 266;BA.debugLine="Return (value * 32.0)";
if (true) return (float) ((_value*32.0));
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_pints2tsp(float _value) throws Exception{
 //BA.debugLineNum = 268;BA.debugLine="Public Sub volume_pints2tsp(value As Float) As Flo";
 //BA.debugLineNum = 269;BA.debugLine="Return (value * 96.0)";
if (true) return (float) ((_value*96.0));
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2cups(float _value) throws Exception{
 //BA.debugLineNum = 337;BA.debugLine="Public Sub volume_quart2cups(value As Float) As Fl";
 //BA.debugLineNum = 338;BA.debugLine="Return (value * 4.0)";
if (true) return (float) ((_value*4.0));
 //BA.debugLineNum = 339;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2floz(float _value) throws Exception{
 //BA.debugLineNum = 325;BA.debugLine="Public Sub volume_quart2floz(value As Float) As Fl";
 //BA.debugLineNum = 326;BA.debugLine="Return (value * 32)";
if (true) return (float) ((_value*32));
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2gal(float _value) throws Exception{
 //BA.debugLineNum = 322;BA.debugLine="Public Sub volume_quart2gal(value As Float) As Flo";
 //BA.debugLineNum = 323;BA.debugLine="Return (value * 0.25)";
if (true) return (float) ((_value*0.25));
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2liters(float _value) throws Exception{
 //BA.debugLineNum = 331;BA.debugLine="Public Sub volume_quart2liters(value As Float) As";
 //BA.debugLineNum = 332;BA.debugLine="Return (value * 0.946353)";
if (true) return (float) ((_value*0.946353));
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2ml(float _value) throws Exception{
 //BA.debugLineNum = 328;BA.debugLine="Public Sub volume_quart2ml(value As Float) As Floa";
 //BA.debugLineNum = 329;BA.debugLine="Return (value * 946.353)";
if (true) return (float) ((_value*946.353));
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2pints(float _value) throws Exception{
 //BA.debugLineNum = 343;BA.debugLine="Public Sub volume_quart2pints(value As Float) As F";
 //BA.debugLineNum = 344;BA.debugLine="Return (value * 2.0)";
if (true) return (float) ((_value*2.0));
 //BA.debugLineNum = 345;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 334;BA.debugLine="Public Sub volume_quart2tbsp(value As Float) As Fl";
 //BA.debugLineNum = 335;BA.debugLine="Return (value * 64.0)";
if (true) return (float) ((_value*64.0));
 //BA.debugLineNum = 336;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_quart2tsp(float _value) throws Exception{
 //BA.debugLineNum = 340;BA.debugLine="Public Sub volume_quart2tsp(value As Float) As Flo";
 //BA.debugLineNum = 341;BA.debugLine="Return (value * 192.0)";
if (true) return (float) ((_value*192.0));
 //BA.debugLineNum = 342;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2cups(float _value) throws Exception{
 //BA.debugLineNum = 312;BA.debugLine="Public Sub volume_tbsp2cups(value As Float) As Flo";
 //BA.debugLineNum = 313;BA.debugLine="Return (value * 0.0625)";
if (true) return (float) ((_value*0.0625));
 //BA.debugLineNum = 314;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2floz(float _value) throws Exception{
 //BA.debugLineNum = 300;BA.debugLine="Public Sub volume_tbsp2floz(value As Float) As Flo";
 //BA.debugLineNum = 301;BA.debugLine="Return (value * 0.5)";
if (true) return (float) ((_value*0.5));
 //BA.debugLineNum = 302;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2gal(float _value) throws Exception{
 //BA.debugLineNum = 297;BA.debugLine="Public Sub volume_tbsp2gal(value As Float) As Floa";
 //BA.debugLineNum = 298;BA.debugLine="Return (value * 0.00390625)";
if (true) return (float) ((_value*0.00390625));
 //BA.debugLineNum = 299;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2liters(float _value) throws Exception{
 //BA.debugLineNum = 306;BA.debugLine="Public Sub volume_tbsp2liters(value As Float) As F";
 //BA.debugLineNum = 307;BA.debugLine="Return (value * 0.0147868)";
if (true) return (float) ((_value*0.0147868));
 //BA.debugLineNum = 308;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2ml(float _value) throws Exception{
 //BA.debugLineNum = 303;BA.debugLine="Public Sub volume_tbsp2ml(value As Float) As Float";
 //BA.debugLineNum = 304;BA.debugLine="Return (value * 14.7868)";
if (true) return (float) ((_value*14.7868));
 //BA.debugLineNum = 305;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2pints(float _value) throws Exception{
 //BA.debugLineNum = 318;BA.debugLine="Public Sub volume_tbsp2pints(value As Float) As Fl";
 //BA.debugLineNum = 319;BA.debugLine="Return (value * 0.03125)";
if (true) return (float) ((_value*0.03125));
 //BA.debugLineNum = 320;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2quarts(float _value) throws Exception{
 //BA.debugLineNum = 309;BA.debugLine="Public Sub volume_tbsp2quarts(value As Float) As F";
 //BA.debugLineNum = 310;BA.debugLine="Return (value * 0.015625)";
if (true) return (float) ((_value*0.015625));
 //BA.debugLineNum = 311;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tbsp2tsp(float _value) throws Exception{
 //BA.debugLineNum = 315;BA.debugLine="Public Sub volume_tbsp2tsp(value As Float) As Floa";
 //BA.debugLineNum = 316;BA.debugLine="Return (value * 3.0)";
if (true) return (float) ((_value*3.0));
 //BA.debugLineNum = 317;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2cups(float _value) throws Exception{
 //BA.debugLineNum = 287;BA.debugLine="Public Sub volume_tsp2cups(value As Float) As Floa";
 //BA.debugLineNum = 288;BA.debugLine="Return (value * 0.0208333)";
if (true) return (float) ((_value*0.0208333));
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2floz(float _value) throws Exception{
 //BA.debugLineNum = 275;BA.debugLine="Public Sub volume_tsp2floz(value As Float) As Floa";
 //BA.debugLineNum = 276;BA.debugLine="Return (value * 0.166667)";
if (true) return (float) ((_value*0.166667));
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2gal(float _value) throws Exception{
 //BA.debugLineNum = 272;BA.debugLine="Public Sub volume_tsp2gal(value As Float) As Float";
 //BA.debugLineNum = 273;BA.debugLine="Return (value * 0.00130208)";
if (true) return (float) ((_value*0.00130208));
 //BA.debugLineNum = 274;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2liters(float _value) throws Exception{
 //BA.debugLineNum = 281;BA.debugLine="Public Sub volume_tsp2liters(value As Float) As Fl";
 //BA.debugLineNum = 282;BA.debugLine="Return (value * 0.00492892)";
if (true) return (float) ((_value*0.00492892));
 //BA.debugLineNum = 283;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2ml(float _value) throws Exception{
 //BA.debugLineNum = 278;BA.debugLine="Public Sub volume_tsp2ml(value As Float) As Float";
 //BA.debugLineNum = 279;BA.debugLine="Return (value * 4.92892)";
if (true) return (float) ((_value*4.92892));
 //BA.debugLineNum = 280;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2pints(float _value) throws Exception{
 //BA.debugLineNum = 293;BA.debugLine="Public Sub volume_tsp2pints(value As Float) As Flo";
 //BA.debugLineNum = 294;BA.debugLine="Return (value * 0.0104167)";
if (true) return (float) ((_value*0.0104167));
 //BA.debugLineNum = 295;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2quarts(float _value) throws Exception{
 //BA.debugLineNum = 284;BA.debugLine="Public Sub volume_tsp2quarts(value As Float) As Fl";
 //BA.debugLineNum = 285;BA.debugLine="Return (value * 0.00520833)";
if (true) return (float) ((_value*0.00520833));
 //BA.debugLineNum = 286;BA.debugLine="End Sub";
return 0f;
}
public float  _volume_tsp2tbsp(float _value) throws Exception{
 //BA.debugLineNum = 290;BA.debugLine="Public Sub volume_tsp2tbsp(value As Float) As Floa";
 //BA.debugLineNum = 291;BA.debugLine="Return (value * 0.333333)";
if (true) return (float) ((_value*0.333333));
 //BA.debugLineNum = 292;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_grams2kg(float _value) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Public Sub weight_grams2kg(value As Float) As Floa";
 //BA.debugLineNum = 50;BA.debugLine="Return (0.00100 * value)";
if (true) return (float) ((0.00100*_value));
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_grams2oz(float _value) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Public Sub weight_grams2oz(value As Float) As Floa";
 //BA.debugLineNum = 44;BA.debugLine="Return (0.03527 * value)";
if (true) return (float) ((0.03527*_value));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_grams2pounds(float _value) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Public Sub weight_grams2pounds(value As Float) As";
 //BA.debugLineNum = 47;BA.debugLine="Return (0.00220 * value)";
if (true) return (float) ((0.00220*_value));
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_kg2grams(float _value) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Public Sub weight_kg2grams(value As Float) As Floa";
 //BA.debugLineNum = 61;BA.debugLine="Return (1000.00000 * value)";
if (true) return (float) ((1000.00000*_value));
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_kg2oz(float _value) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Public Sub weight_kg2oz(value As Float) As Float";
 //BA.debugLineNum = 58;BA.debugLine="Return (35.27397 * value)";
if (true) return (float) ((35.27397*_value));
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_kg2pounds(float _value) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Public Sub weight_kg2pounds(value As Float) As Flo";
 //BA.debugLineNum = 55;BA.debugLine="Return (2.20462 * value)";
if (true) return (float) ((2.20462*_value));
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_oz2grams(float _value) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Public Sub weight_oz2grams(value As Float) As Floa";
 //BA.debugLineNum = 36;BA.debugLine="Return (28.34952 * value)";
if (true) return (float) ((28.34952*_value));
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_oz2kg(float _value) throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Public Sub weight_oz2kg(value As Float) As Float";
 //BA.debugLineNum = 39;BA.debugLine="Return (0.02835 * value)";
if (true) return (float) ((0.02835*_value));
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_oz2pounds(float _value) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Public Sub weight_oz2pounds(value As Float) As Flo";
 //BA.debugLineNum = 33;BA.debugLine="Return (0.06250 * value)";
if (true) return (float) ((0.06250*_value));
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_pounds2grams(float _value) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub weight_pounds2grams(value As Float) As";
 //BA.debugLineNum = 25;BA.debugLine="Return (453.59232 * value)";
if (true) return (float) ((453.59232*_value));
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_pounds2kg(float _value) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub weight_pounds2kg(value As Float) As Flo";
 //BA.debugLineNum = 28;BA.debugLine="Return (0.45359 * value)";
if (true) return (float) ((0.45359*_value));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return 0f;
}
public float  _weight_pounds2oz(float _value) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub weight_pounds2oz(value As Float) As Flo";
 //BA.debugLineNum = 22;BA.debugLine="Return (16.0000 * value)";
if (true) return (float) ((16.0000*_value));
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return 0f;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
