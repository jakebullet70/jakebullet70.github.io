package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clsweatherdata extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.clsweatherdata");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.clsweatherdata.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public boolean _isinitialize = false;
public long _lastupdatedat = 0L;
public String _weatherkey = "";
public anywheresoftware.b4a.objects.collections.Map _weatherapicodes = null;
public int _weatherapicode = 0;
public boolean _iserror = false;
public String _lasterrormessage = "";
public String _lastupdatedcity = "";
public String _qdescription = "";
public String _qlocation = "";
public String _qcountry = "";
public String _qprecipitation_mm = "";
public String _qprecipitation_inches = "";
public String _qcloudcover = "";
public String _qhumidity = "";
public String _qpressure = "";
public boolean _qisday = false;
public String _qwinddirection = "";
public String _qwindspeed_mph = "";
public String _qwindspeed_kph = "";
public String _qgustspeed_mph = "";
public String _qgustspeed_kph = "";
public int _qfeelslike_f = 0;
public int _qfeelslike_c = 0;
public int _qtemp_f = 0;
public int _qtemp_c = 0;
public String _qvisibility_km = "";
public String _qvisibility_miles = "";
public String _qlocaltime = "";
public long _qlocaltime_epoch = 0L;
public sadLogic.HomeCentral.clsweatherdataday[] _forcastdays = null;
public int _minutesbetweencalls = 0;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static class _typeweathercodedata{
public boolean IsInitialized;
public String DayDesc;
public String NightDesc;
public int IconID;
public void Initialize() {
IsInitialized = true;
DayDesc = "";
NightDesc = "";
IconID = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Public IsInitialize As Boolean";
_isinitialize = false;
 //BA.debugLineNum = 6;BA.debugLine="Type typeWeatherCodeData(DayDesc As String, Night";
;
 //BA.debugLineNum = 8;BA.debugLine="Public LastUpdatedAt As Long";
_lastupdatedat = 0L;
 //BA.debugLineNum = 9;BA.debugLine="Public WeatherKey As String";
_weatherkey = "";
 //BA.debugLineNum = 10;BA.debugLine="Public WeatherAPICodes As Map";
_weatherapicodes = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 11;BA.debugLine="Public WeatherAPIcode As Int";
_weatherapicode = 0;
 //BA.debugLineNum = 12;BA.debugLine="Public IsError As Boolean";
_iserror = false;
 //BA.debugLineNum = 13;BA.debugLine="Public LastErrorMessage As String";
_lasterrormessage = "";
 //BA.debugLineNum = 14;BA.debugLine="Public LastUpdatedCity As String";
_lastupdatedcity = "";
 //BA.debugLineNum = 17;BA.debugLine="Public qDescription As String";
_qdescription = "";
 //BA.debugLineNum = 18;BA.debugLine="Public qLocation, qCountry As String";
_qlocation = "";
_qcountry = "";
 //BA.debugLineNum = 19;BA.debugLine="Public qPrecipitation_mm,qPrecipitation_inches As";
_qprecipitation_mm = "";
_qprecipitation_inches = "";
 //BA.debugLineNum = 20;BA.debugLine="Public qCloudCover As String";
_qcloudcover = "";
 //BA.debugLineNum = 21;BA.debugLine="Public qHumidity As String";
_qhumidity = "";
 //BA.debugLineNum = 22;BA.debugLine="Public qPressure As String";
_qpressure = "";
 //BA.debugLineNum = 23;BA.debugLine="Public qIsDay As Boolean";
_qisday = false;
 //BA.debugLineNum = 24;BA.debugLine="Public qWindDirection As String";
_qwinddirection = "";
 //BA.debugLineNum = 25;BA.debugLine="Public qWindSpeed_mph,qWindSpeed_kph As String";
_qwindspeed_mph = "";
_qwindspeed_kph = "";
 //BA.debugLineNum = 26;BA.debugLine="Public qGustSpeed_mph,qGustSpeed_kph As String";
_qgustspeed_mph = "";
_qgustspeed_kph = "";
 //BA.debugLineNum = 27;BA.debugLine="Public qFeelsLike_f,qFeelsLike_c As Int";
_qfeelslike_f = 0;
_qfeelslike_c = 0;
 //BA.debugLineNum = 28;BA.debugLine="Public qTemp_f,qTemp_c As Int";
_qtemp_f = 0;
_qtemp_c = 0;
 //BA.debugLineNum = 29;BA.debugLine="Public qVisibility_km,qVisibility_miles As String";
_qvisibility_km = "";
_qvisibility_miles = "";
 //BA.debugLineNum = 30;BA.debugLine="Public qLocalTime As String, qLocalTime_Epoch As";
_qlocaltime = "";
_qlocaltime_epoch = 0L;
 //BA.debugLineNum = 32;BA.debugLine="Public ForcastDays(3) As clsWeatherDataDay";
_forcastdays = new sadLogic.HomeCentral.clsweatherdataday[(int) (3)];
{
int d0 = _forcastdays.length;
for (int i0 = 0;i0 < d0;i0++) {
_forcastdays[i0] = new sadLogic.HomeCentral.clsweatherdataday();
}
}
;
 //BA.debugLineNum = 33;BA.debugLine="Private MinutesBetweenCalls As Int = 45";
_minutesbetweencalls = (int) (45);
 //BA.debugLineNum = 34;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _formatdayname(String _dt) throws Exception{
String _fmtd = "";
String _fmtt = "";
String _ret = "";
long _d = 0L;
String _dn = "";
String _daynum = "";
 //BA.debugLineNum = 244;BA.debugLine="Private Sub FormatDayName(dt As String) As String";
 //BA.debugLineNum = 246;BA.debugLine="Dim fmtD As String = DateTime.DateFormat";
_fmtd = __c.DateTime.getDateFormat();
 //BA.debugLineNum = 247;BA.debugLine="Dim fmtT As String = DateTime.TimeFormat";
_fmtt = __c.DateTime.getTimeFormat();
 //BA.debugLineNum = 249;BA.debugLine="DateTime.TimeFormat = \"\"";
__c.DateTime.setTimeFormat("");
 //BA.debugLineNum = 250;BA.debugLine="DateTime.DateFormat = \"\"";
__c.DateTime.setDateFormat("");
 //BA.debugLineNum = 251;BA.debugLine="Dim ret As String = dt";
_ret = _dt;
 //BA.debugLineNum = 253;BA.debugLine="Try";
try { //BA.debugLineNum = 254;BA.debugLine="DateTime.DateFormat = \"yyyy-MM-dd\"";
__c.DateTime.setDateFormat("yyyy-MM-dd");
 //BA.debugLineNum = 255;BA.debugLine="Dim d As Long =  DateTime.DateParse(dt)";
_d = __c.DateTime.DateParse(_dt);
 //BA.debugLineNum = 256;BA.debugLine="Dim dn As String = DateUtils.GetDaysNames.Get(Da";
_dn = BA.ObjectToString(_dateutils._getdaysnames(ba).Get((int) (__c.DateTime.GetDayOfWeek(_d)-1)));
 //BA.debugLineNum = 257;BA.debugLine="Dim dayNum As String = dtHelpers.ReturnDayExt( R";
_daynum = _dthelpers._returndayext /*String*/ (ba,(int)(Double.parseDouble(__c.Regex.Split("-",_dt)[(int) (2)])));
 //BA.debugLineNum = 258;BA.debugLine="ret = dn&  \" - \" & dayNum";
_ret = _dn+" - "+_daynum;
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 260;BA.debugLine="Log(\"err-FormatDayName:\" & dt & \" -> \" &  LastEx";
__c.LogImpl("11075600","err-FormatDayName:"+_dt+" -> "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 263;BA.debugLine="DateTime.TimeFormat = fmtT";
__c.DateTime.setTimeFormat(_fmtt);
 //BA.debugLineNum = 264;BA.debugLine="DateTime.DateFormat = fmtD";
__c.DateTime.setDateFormat(_fmtd);
 //BA.debugLineNum = 265;BA.debugLine="Return ret";
if (true) return _ret;
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public String  _getdayinfoapi(int _code,int _slot) throws Exception{
sadLogic.HomeCentral.clsweatherdata._typeweathercodedata _o = null;
 //BA.debugLineNum = 269;BA.debugLine="Private Sub GetDayInfoApi(code As Int,slot As Int)";
 //BA.debugLineNum = 270;BA.debugLine="Try";
try { //BA.debugLineNum = 272;BA.debugLine="Dim o As typeWeatherCodeData";
_o = new sadLogic.HomeCentral.clsweatherdata._typeweathercodedata();
 //BA.debugLineNum = 273;BA.debugLine="o = WeatherAPICodes.Get(code).As(typeWeatherCode";
_o = ((sadLogic.HomeCentral.clsweatherdata._typeweathercodedata)(_weatherapicodes.Get((Object)(_code))));
 //BA.debugLineNum = 274;BA.debugLine="ForcastDays(slot).IconID = o.IconID";
_forcastdays[_slot]._iconid /*int*/  = _o.IconID /*int*/ ;
 //BA.debugLineNum = 276;BA.debugLine="ForcastDays(slot).Description = o.DayDesc";
_forcastdays[_slot]._description /*String*/  = _o.DayDesc /*String*/ ;
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 282;BA.debugLine="Log(LastException)";
__c.LogImpl("11141133",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 285;BA.debugLine="End Sub";
return "";
}
public boolean  _getisweatheruptodate() throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Public Sub getIsWeatherUpToDate As Boolean";
 //BA.debugLineNum = 39;BA.debugLine="If LastUpdatedAt <> 0 And dtHelpers.HoursBetween(";
if (_lastupdatedat!=0 && _dthelpers._hoursbetween /*int*/ (ba,__c.DateTime.getNow(),_lastupdatedat)>=1) { 
 //BA.debugLineNum = 40;BA.debugLine="Return False";
if (true) return __c.False;
 }else {
 //BA.debugLineNum = 42;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return false;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 58;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 59;BA.debugLine="IsInitialize = True";
_isinitialize = __c.True;
 //BA.debugLineNum = 61;BA.debugLine="LastUpdatedAt = 1";
_lastupdatedat = (long) (1);
 //BA.debugLineNum = 62;BA.debugLine="WeatherKey = gblConst.WeatherAPIKey";
_weatherkey = _gblconst._weatherapikey /*String*/ ;
 //BA.debugLineNum = 63;BA.debugLine="ReadApiCodes";
_readapicodes();
 //BA.debugLineNum = 65;BA.debugLine="mpage.EventGbl.Subscribe(gblConst.EVENT_INET_ON_C";
_mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._subscribe /*String*/ (_gblconst._event_inet_on_connect /*String*/ ,this,"Internet_OnConnected");
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public String  _internet_onconnected() throws Exception{
 //BA.debugLineNum = 84;BA.debugLine="Sub Internet_OnConnected";
 //BA.debugLineNum = 85;BA.debugLine="Log(\"Internet_OnConnected\")";
__c.LogImpl("10878977","Internet_OnConnected",0);
 //BA.debugLineNum = 86;BA.debugLine="Try_Weather_Update";
_try_weather_update();
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _loadweathericon(int _iconid,sadLogic.HomeCentral.lmb4ximageviewx _img,boolean _isday) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Public Sub LoadWeatherIcon(iconID As Int, img As l";
 //BA.debugLineNum = 48;BA.debugLine="If iconID <= 0 Then Return";
if (_iconid<=0) { 
if (true) return "";};
 //BA.debugLineNum = 52;BA.debugLine="img.Bitmap =  xui.LoadBitmap(File.DirAssets, _";
_img._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (_xui.LoadBitmap(__c.File.getDirAssets(),"weathericon/"+_config._getweathericonset /*String*/ (ba)+BA.ObjectToString(((_isday) ? ((Object)("/day/")) : ((Object)("/night/"))))+BA.NumberToString(_iconid)+".png"));
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public String  _parseweatherjob(String _s) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _current = null;
anywheresoftware.b4a.objects.collections.Map _condition = null;
anywheresoftware.b4a.objects.collections.Map _location = null;
int _forcastslot = 0;
anywheresoftware.b4a.objects.collections.Map _forecast = null;
anywheresoftware.b4a.objects.collections.List _forecastday = null;
sadLogic.HomeCentral.conversionmod _conv = null;
anywheresoftware.b4a.objects.collections.Map _colforecastday = null;
anywheresoftware.b4a.objects.collections.Map _astro = null;
anywheresoftware.b4a.objects.collections.Map _day = null;
 //BA.debugLineNum = 124;BA.debugLine="Private Sub ParseWeatherJob(s As String)";
 //BA.debugLineNum = 125;BA.debugLine="LastUpdatedAt = DateTime.Now";
_lastupdatedat = __c.DateTime.getNow();
 //BA.debugLineNum = 127;BA.debugLine="Dim parser As JSONParser : parser.Initialize(s)";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 127;BA.debugLine="Dim parser As JSONParser : parser.Initialize(s)";
_parser.Initialize(_s);
 //BA.debugLineNum = 128;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 130;BA.debugLine="Try";
try { //BA.debugLineNum = 131;BA.debugLine="Dim current As Map = root.Get(\"current\")";
_current = new anywheresoftware.b4a.objects.collections.Map();
_current = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("current"))));
 //BA.debugLineNum = 132;BA.debugLine="qFeelsLike_f  = current.Get(\"feelslike_f\")";
_qfeelslike_f = (int)(BA.ObjectToNumber(_current.Get((Object)("feelslike_f"))));
 //BA.debugLineNum = 133;BA.debugLine="qFeelsLike_c = current.Get(\"feelslike_c\")";
_qfeelslike_c = (int)(BA.ObjectToNumber(_current.Get((Object)("feelslike_c"))));
 //BA.debugLineNum = 138;BA.debugLine="qIsDay = fnct.int2bool(current.Get(\"is_day\").As(";
_qisday = _fnct._int2bool /*boolean*/ (ba,((int)(BA.ObjectToNumber(_current.Get((Object)("is_day"))))));
 //BA.debugLineNum = 139;BA.debugLine="qPrecipitation_inches = current.Get(\"precip_in\")";
_qprecipitation_inches = BA.ObjectToString(_current.Get((Object)("precip_in")));
 //BA.debugLineNum = 140;BA.debugLine="qPrecipitation_mm =  current.Get(\"precip_mm\")";
_qprecipitation_mm = BA.ObjectToString(_current.Get((Object)("precip_mm")));
 //BA.debugLineNum = 141;BA.debugLine="qWindDirection = current.Get(\"wind_dir\")";
_qwinddirection = BA.ObjectToString(_current.Get((Object)("wind_dir")));
 //BA.debugLineNum = 142;BA.debugLine="qGustSpeed_mph = current.Get(\"gust_mph\") & \"mph\"";
_qgustspeed_mph = BA.ObjectToString(_current.Get((Object)("gust_mph")))+"mph";
 //BA.debugLineNum = 143;BA.debugLine="qGustSpeed_kph = current.Get(\"gust_kph\") & \"kph\"";
_qgustspeed_kph = BA.ObjectToString(_current.Get((Object)("gust_kph")))+"kph";
 //BA.debugLineNum = 144;BA.debugLine="qTemp_c = current.Get(\"temp_c\")";
_qtemp_c = (int)(BA.ObjectToNumber(_current.Get((Object)("temp_c"))));
 //BA.debugLineNum = 145;BA.debugLine="qTemp_f  = current.Get(\"temp_f\")";
_qtemp_f = (int)(BA.ObjectToNumber(_current.Get((Object)("temp_f"))));
 //BA.debugLineNum = 146;BA.debugLine="qPressure = current.Get(\"pressure_in\")";
_qpressure = BA.ObjectToString(_current.Get((Object)("pressure_in")));
 //BA.debugLineNum = 147;BA.debugLine="qCloudCover = current.Get(\"cloud\")";
_qcloudcover = BA.ObjectToString(_current.Get((Object)("cloud")));
 //BA.debugLineNum = 148;BA.debugLine="qWindSpeed_kph  = current.Get(\"wind_kph\") & \"kph";
_qwindspeed_kph = BA.ObjectToString(_current.Get((Object)("wind_kph")))+"kph";
 //BA.debugLineNum = 149;BA.debugLine="qWindSpeed_mph  = current.Get(\"wind_mph\")";
_qwindspeed_mph = BA.ObjectToString(_current.Get((Object)("wind_mph")));
 //BA.debugLineNum = 150;BA.debugLine="qHumidity = current.Get(\"humidity\")";
_qhumidity = BA.ObjectToString(_current.Get((Object)("humidity")));
 //BA.debugLineNum = 151;BA.debugLine="qPressure = current.Get(\"pressure_mb\") & \"mb\"";
_qpressure = BA.ObjectToString(_current.Get((Object)("pressure_mb")))+"mb";
 //BA.debugLineNum = 152;BA.debugLine="qVisibility_miles = current.Get(\"vis_miles\")";
_qvisibility_miles = BA.ObjectToString(_current.Get((Object)("vis_miles")));
 //BA.debugLineNum = 153;BA.debugLine="qVisibility_km  = current.Get(\"vis_km\")";
_qvisibility_km = BA.ObjectToString(_current.Get((Object)("vis_km")));
 //BA.debugLineNum = 156;BA.debugLine="Dim condition As Map = current.Get(\"condition\")";
_condition = new anywheresoftware.b4a.objects.collections.Map();
_condition = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_current.Get((Object)("condition"))));
 //BA.debugLineNum = 159;BA.debugLine="qDescription = condition.Get(\"text\")";
_qdescription = BA.ObjectToString(_condition.Get((Object)("text")));
 //BA.debugLineNum = 162;BA.debugLine="Dim Location As Map = root.Get(\"location\")";
_location = new anywheresoftware.b4a.objects.collections.Map();
_location = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("location"))));
 //BA.debugLineNum = 163;BA.debugLine="qLocalTime = Location.Get(\"localtime\")";
_qlocaltime = BA.ObjectToString(_location.Get((Object)("localtime")));
 //BA.debugLineNum = 164;BA.debugLine="qCountry = Location.Get(\"country\")";
_qcountry = BA.ObjectToString(_location.Get((Object)("country")));
 //BA.debugLineNum = 165;BA.debugLine="qLocalTime_Epoch = Location.Get(\"localtime_epoch";
_qlocaltime_epoch = BA.ObjectToLongNumber(_location.Get((Object)("localtime_epoch")));
 //BA.debugLineNum = 166;BA.debugLine="qLocation = Location.Get(\"name\")";
_qlocation = BA.ObjectToString(_location.Get((Object)("name")));
 //BA.debugLineNum = 173;BA.debugLine="Dim ForcastSlot As Int = 0";
_forcastslot = (int) (0);
 //BA.debugLineNum = 174;BA.debugLine="Dim Forecast As Map = root.Get(\"forecast\")";
_forecast = new anywheresoftware.b4a.objects.collections.Map();
_forecast = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("forecast"))));
 //BA.debugLineNum = 175;BA.debugLine="Dim ForecastDay As List = Forecast.Get(\"forecast";
_forecastday = new anywheresoftware.b4a.objects.collections.List();
_forecastday = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_forecast.Get((Object)("forecastday"))));
 //BA.debugLineNum = 177;BA.debugLine="Dim conv As ConversionMod";
_conv = new sadLogic.HomeCentral.conversionmod();
 //BA.debugLineNum = 178;BA.debugLine="conv.Initialize";
_conv._initialize /*String*/ (ba);
 //BA.debugLineNum = 179;BA.debugLine="For Each colforecastday As Map In ForecastDay";
_colforecastday = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group37 = _forecastday;
final int groupLen37 = group37.getSize()
;int index37 = 0;
;
for (; index37 < groupLen37;index37++){
_colforecastday = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group37.Get(index37)));
 //BA.debugLineNum = 181;BA.debugLine="ForcastDays(ForcastSlot).Day = FormatDayName( c";
_forcastdays[_forcastslot]._day /*String*/  = _formatdayname(BA.ObjectToString(_colforecastday.Get((Object)("date"))));
 //BA.debugLineNum = 184;BA.debugLine="Dim astro As Map = colforecastday.Get(\"astro\")";
_astro = new anywheresoftware.b4a.objects.collections.Map();
_astro = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_colforecastday.Get((Object)("astro"))));
 //BA.debugLineNum = 187;BA.debugLine="ForcastDays(ForcastSlot).Sunrise = astro.Get(\"s";
_forcastdays[_forcastslot]._sunrise /*String*/  = BA.ObjectToString(_astro.Get((Object)("sunrise")));
 //BA.debugLineNum = 188;BA.debugLine="ForcastDays(ForcastSlot).Sunset = astro.Get(\"su";
_forcastdays[_forcastslot]._sunset /*String*/  = BA.ObjectToString(_astro.Get((Object)("sunset")));
 //BA.debugLineNum = 196;BA.debugLine="Dim day As Map = colforecastday.Get(\"day\")";
_day = new anywheresoftware.b4a.objects.collections.Map();
_day = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_colforecastday.Get((Object)("day"))));
 //BA.debugLineNum = 199;BA.debugLine="ForcastDays(ForcastSlot).uv = day.Get(\"uv\")";
_forcastdays[_forcastslot]._uv /*String*/  = BA.ObjectToString(_day.Get((Object)("uv")));
 //BA.debugLineNum = 200;BA.debugLine="ForcastDays(ForcastSlot).AverageTemp_f = day.Ge";
_forcastdays[_forcastslot]._averagetemp_f /*String*/  = BA.ObjectToString(_day.Get((Object)("avgtemp_f")));
 //BA.debugLineNum = 201;BA.debugLine="ForcastDays(ForcastSlot).AverageTemp_c = day.Ge";
_forcastdays[_forcastslot]._averagetemp_c /*String*/  = BA.ObjectToString(_day.Get((Object)("avgtemp_c")));
 //BA.debugLineNum = 202;BA.debugLine="ForcastDays(ForcastSlot).ChanceOfSnow = day.Get";
_forcastdays[_forcastslot]._chanceofsnow /*String*/  = BA.ObjectToString(_day.Get((Object)("daily_chance_of_snow")));
 //BA.debugLineNum = 203;BA.debugLine="ForcastDays(ForcastSlot).ChanceOfRain = day.Get";
_forcastdays[_forcastslot]._chanceofrain /*String*/  = BA.ObjectToString(_day.Get((Object)("daily_chance_of_rain")));
 //BA.debugLineNum = 204;BA.debugLine="ForcastDays(ForcastSlot).Low_c = day.Get(\"minte";
_forcastdays[_forcastslot]._low_c /*int*/  = (int)(BA.ObjectToNumber(_day.Get((Object)("mintemp_c"))));
 //BA.debugLineNum = 205;BA.debugLine="ForcastDays(ForcastSlot).Low_f = day.Get(\"minte";
_forcastdays[_forcastslot]._low_f /*int*/  = (int)(BA.ObjectToNumber(_day.Get((Object)("mintemp_f"))));
 //BA.debugLineNum = 206;BA.debugLine="ForcastDays(ForcastSlot).High_f = day.Get(\"maxt";
_forcastdays[_forcastslot]._high_f /*int*/  = (int)(BA.ObjectToNumber(_day.Get((Object)("maxtemp_f"))));
 //BA.debugLineNum = 207;BA.debugLine="ForcastDays(ForcastSlot).High_c = day.Get(\"maxt";
_forcastdays[_forcastslot]._high_c /*int*/  = (int)(BA.ObjectToNumber(_day.Get((Object)("maxtemp_c"))));
 //BA.debugLineNum = 209;BA.debugLine="ForcastDays(ForcastSlot).WillItRain = day.Get(\"";
_forcastdays[_forcastslot]._willitrain /*String*/  = BA.ObjectToString(_day.Get((Object)("daily_will_it_rain")));
 //BA.debugLineNum = 210;BA.debugLine="ForcastDays(ForcastSlot).WillItSnow = day.Get(\"";
_forcastdays[_forcastslot]._willitsnow /*String*/  = BA.ObjectToString(_day.Get((Object)("daily_will_it_snow")));
 //BA.debugLineNum = 211;BA.debugLine="ForcastDays(ForcastSlot).IconURL = condition.Ge";
_forcastdays[_forcastslot]._iconurl /*String*/  = BA.ObjectToString(_condition.Get((Object)("icon")));
 //BA.debugLineNum = 212;BA.debugLine="ForcastDays(ForcastSlot).Percip_inches = day.Ge";
_forcastdays[_forcastslot]._percip_inches /*String*/  = BA.ObjectToString(_day.Get((Object)("totalprecip_in")));
 //BA.debugLineNum = 213;BA.debugLine="ForcastDays(ForcastSlot).Percip_mm = day.Get(\"t";
_forcastdays[_forcastslot]._percip_mm /*String*/  = BA.ObjectToString(_day.Get((Object)("totalprecip_mm")));
 //BA.debugLineNum = 215;BA.debugLine="ForcastDays(ForcastSlot).Snow_cm = day.Get(\"tot";
_forcastdays[_forcastslot]._snow_cm /*String*/  = BA.ObjectToString(_day.Get((Object)("totalsnow_cm")));
 //BA.debugLineNum = 216;BA.debugLine="Try";
try { //BA.debugLineNum = 217;BA.debugLine="If Not (strHelpers.IsNullOrEmpty(day.Get(\"tota";
if (__c.Not(_strhelpers._isnullorempty /*boolean*/ (ba,BA.ObjectToString(_day.Get((Object)("totalsnow_cm")))))) { 
 //BA.debugLineNum = 218;BA.debugLine="ForcastDays(ForcastSlot).Snow_inches = conv.l";
_forcastdays[_forcastslot]._snow_inches /*String*/  = BA.NumberToString(_conv._length_mm2inches /*float*/ ((float) ((((double)(Double.parseDouble(_forcastdays[_forcastslot]._snow_cm /*String*/ )))*10))));
 };
 } 
       catch (Exception e63) {
			ba.setLastException(e63); //BA.debugLineNum = 221;BA.debugLine="Log(LastException)";
__c.LogImpl("11010145",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 223;BA.debugLine="ForcastDays(ForcastSlot).Humidity = day.Get(\"av";
_forcastdays[_forcastslot]._humidity /*String*/  = BA.ObjectToString(_day.Get((Object)("avghumidity")));
 //BA.debugLineNum = 226;BA.debugLine="Dim condition As Map = day.Get(\"condition\")";
_condition = new anywheresoftware.b4a.objects.collections.Map();
_condition = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_day.Get((Object)("condition"))));
 //BA.debugLineNum = 227;BA.debugLine="ForcastDays(ForcastSlot).APIcode = condition.Ge";
_forcastdays[_forcastslot]._apicode /*int*/  = (int)(BA.ObjectToNumber(_condition.Get((Object)("code"))));
 //BA.debugLineNum = 228;BA.debugLine="GetDayInfoApi(ForcastDays(ForcastSlot).APIcode,";
_getdayinfoapi(_forcastdays[_forcastslot]._apicode /*int*/ ,_forcastslot);
 //BA.debugLineNum = 230;BA.debugLine="ForcastDays(ForcastSlot).Max_Wind_kph = day.Get";
_forcastdays[_forcastslot]._max_wind_kph /*String*/  = BA.ObjectToString(_day.Get((Object)("maxwind_kph")));
 //BA.debugLineNum = 231;BA.debugLine="ForcastDays(ForcastSlot).Max_Wind_mph = day.Get";
_forcastdays[_forcastslot]._max_wind_mph /*String*/  = BA.ObjectToString(_day.Get((Object)("maxwind_mph")));
 //BA.debugLineNum = 233;BA.debugLine="ForcastSlot = ForcastSlot + 1";
_forcastslot = (int) (_forcastslot+1);
 }
};
 } 
       catch (Exception e74) {
			ba.setLastException(e74); //BA.debugLineNum = 237;BA.debugLine="Log(LastException)";
__c.LogImpl("11010161",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 240;BA.debugLine="ForcastDays(0).Day = \"Today\"";
_forcastdays[(int) (0)]._day /*String*/  = "Today";
 //BA.debugLineNum = 242;BA.debugLine="End Sub";
return "";
}
public String  _readapicodes() throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.List _root = null;
anywheresoftware.b4a.objects.collections.Map _colroot = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
sadLogic.HomeCentral.clsweatherdata._typeweathercodedata _o = null;
 //BA.debugLineNum = 69;BA.debugLine="Private Sub ReadApiCodes()";
 //BA.debugLineNum = 70;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 71;BA.debugLine="parser.Initialize(File.ReadString(File.DirAssets,";
_parser.Initialize(__c.File.ReadString(__c.File.getDirAssets(),"weatherAPI_codes.json"));
 //BA.debugLineNum = 72;BA.debugLine="Dim root As List = parser.NextArray";
_root = new anywheresoftware.b4a.objects.collections.List();
_root = _parser.NextArray();
 //BA.debugLineNum = 73;BA.debugLine="WeatherAPICodes.Initialize";
_weatherapicodes.Initialize();
 //BA.debugLineNum = 74;BA.debugLine="For Each colroot As Map In root";
_colroot = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group5 = _root;
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_colroot = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group5.Get(index5)));
 //BA.debugLineNum = 75;BA.debugLine="Dim m As Map : 	m.Initialize";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 75;BA.debugLine="Dim m As Map : 	m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 76;BA.debugLine="Dim o As typeWeatherCodeData";
_o = new sadLogic.HomeCentral.clsweatherdata._typeweathercodedata();
 //BA.debugLineNum = 77;BA.debugLine="o.DayDesc = colroot.Get(\"day\")";
_o.DayDesc /*String*/  = BA.ObjectToString(_colroot.Get((Object)("day")));
 //BA.debugLineNum = 78;BA.debugLine="o.NightDesc = colroot.Get(\"night\")";
_o.NightDesc /*String*/  = BA.ObjectToString(_colroot.Get((Object)("night")));
 //BA.debugLineNum = 79;BA.debugLine="o.IconID = colroot.Get(\"icon\")";
_o.IconID /*int*/  = (int)(BA.ObjectToNumber(_colroot.Get((Object)("icon"))));
 //BA.debugLineNum = 80;BA.debugLine="WeatherAPICodes.Put(colroot.Get(\"code\").As(Int),";
_weatherapicodes.Put((Object)(((int)(BA.ObjectToNumber(_colroot.Get((Object)("code")))))),(Object)(_o));
 }
};
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _try_weather_update() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Public Sub Try_Weather_Update";
 //BA.debugLineNum = 91;BA.debugLine="If mpage.PowerCtrl.IsScreenOff Then";
if (_mpage._powerctrl /*sadLogic.HomeCentral.powercontrol*/ ._isscreenoff /*boolean*/ ) { 
 //BA.debugLineNum = 92;BA.debugLine="LastUpdatedAt = 1";
_lastupdatedat = (long) (1);
 //BA.debugLineNum = 93;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Try";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Try_Weather_Update",(int) (60000*_minutesbetweencalls));
 //BA.debugLineNum = 94;BA.debugLine="If mpage.DebugLog Then Log(\"GetWeather - screen";
if (_mpage._debuglog /*boolean*/ ) { 
__c.LogImpl("10944516","GetWeather - screen off! not getting weather",0);};
 //BA.debugLineNum = 95;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 98;BA.debugLine="If LastUpdatedAt <> 0 Then";
if (_lastupdatedat!=0) { 
 //BA.debugLineNum = 100;BA.debugLine="mpage.EventGbl.Raise(gblConst.EVENT_WEATHER_BEFO";
_mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._raise /*String*/ (_gblconst._event_weather_before_update /*String*/ );
 //BA.debugLineNum = 101;BA.debugLine="If (LastUpdatedCity = \"\") Then";
if (((_lastupdatedcity).equals(""))) { 
 //BA.debugLineNum = 102;BA.debugLine="Update_Weather(Main.kvs.getdefault(gblConst.IN";
_update_weather(BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (_gblconst._ini_weather_default_city /*String*/ ,(Object)("seattle"))));
 }else {
 //BA.debugLineNum = 104;BA.debugLine="Update_Weather(LastUpdatedCity)";
_update_weather(_lastupdatedcity);
 };
 }else {
 //BA.debugLineNum = 108;BA.debugLine="Log(\"LastUpdatedAt=0\") '--- should never happen";
__c.LogImpl("10944530","LastUpdatedAt=0",0);
 };
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _update_weather(String _city) throws Exception{
ResumableSub_Update_Weather rsub = new ResumableSub_Update_Weather(this,_city);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Update_Weather extends BA.ResumableSub {
public ResumableSub_Update_Weather(sadLogic.HomeCentral.clsweatherdata parent,String _city) {
this.parent = parent;
this._city = _city;
}
sadLogic.HomeCentral.clsweatherdata parent;
String _city;
boolean _retval = false;
sadLogic.HomeCentral.httpjob _job = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 289;BA.debugLine="LastUpdatedAt = 1 '--- reset lastUpdated dateTime";
parent._lastupdatedat = (long) (1);
 //BA.debugLineNum = 291;BA.debugLine="If mpage.isInterNetConnected = False Then";
if (true) break;

case 1:
//if
this.state = 16;
if (parent._mpage._isinternetconnected /*boolean*/ ==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 292;BA.debugLine="Try";
if (true) break;

case 4:
//try
this.state = 15;
this.catchState = 8;
this.state = 6;
if (true) break;

case 6:
//C
this.state = 15;
this.catchState = 8;
 //BA.debugLineNum = 294;BA.debugLine="Log(\"Internet is not connected. Cannot update w";
parent.__c.LogImpl("11206663","Internet is not connected. Cannot update weather.",0);
 if (true) break;

case 8:
//C
this.state = 9;
this.catchState = 0;
 //BA.debugLineNum = 298;BA.debugLine="If mpage.DebugLog Then Log(\"GetWeather - only 1";
if (true) break;

case 9:
//if
this.state = 14;
if (parent._mpage._debuglog /*boolean*/ ) { 
this.state = 11;
;}if (true) break;

case 11:
//C
this.state = 14;
parent.__c.LogImpl("11206667","GetWeather - only 1st time OK",0);
if (true) break;

case 14:
//C
this.state = 15;
;
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 0;
;
 //BA.debugLineNum = 301;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 304;BA.debugLine="If mpage.DebugLog Then Log(\"Requesting weather da";

case 16:
//if
this.state = 21;
if (parent._mpage._debuglog /*boolean*/ ) { 
this.state = 18;
;}if (true) break;

case 18:
//C
this.state = 21;
parent.__c.LogImpl("11206673","Requesting weather data",0);
if (true) break;

case 21:
//C
this.state = 22;
;
 //BA.debugLineNum = 306;BA.debugLine="Dim retVal As Boolean,  job As HttpJob";
_retval = false;
_job = new sadLogic.HomeCentral.httpjob();
 //BA.debugLineNum = 307;BA.debugLine="job.Initialize(\"\", Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 308;BA.debugLine="job.Download($\"http://api.weatherapi.com/v1/forec";
_job._download /*String*/ (("http://api.weatherapi.com/v1/forecast.json?key="+parent.__c.SmartStringFormatter("",(Object)(parent._weatherkey))+"&q="+parent.__c.SmartStringFormatter("",(Object)(_city))+"&days=3&aqi=no&alerts=no"));
 //BA.debugLineNum = 309;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 34;
return;
case 34:
//C
this.state = 22;
_job = (sadLogic.HomeCentral.httpjob) result[0];
;
 //BA.debugLineNum = 310;BA.debugLine="retVal = job.Success";
_retval = _job._success /*boolean*/ ;
 //BA.debugLineNum = 312;BA.debugLine="If job.Success Then";
if (true) break;

case 22:
//if
this.state = 33;
if (_job._success /*boolean*/ ) { 
this.state = 24;
}else {
this.state = 32;
}if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 315;BA.debugLine="ParseWeatherJob(job.GetString)";
parent._parseweatherjob(_job._getstring /*String*/ ());
 //BA.debugLineNum = 316;BA.debugLine="mpage.EventGbl.Raise(gblConst.EVENT_WEATHER_UPDA";
parent._mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._raise /*String*/ (parent._gblconst._event_weather_updated /*String*/ );
 //BA.debugLineNum = 317;BA.debugLine="LastUpdatedAt = DateTime.Now";
parent._lastupdatedat = parent.__c.DateTime.getNow();
 //BA.debugLineNum = 318;BA.debugLine="LastUpdatedCity = city";
parent._lastupdatedcity = _city;
 //BA.debugLineNum = 319;BA.debugLine="If mpage.DebugLog Then Log(DateUtils.TicksToStri";
if (true) break;

case 25:
//if
this.state = 30;
if (parent._mpage._debuglog /*boolean*/ ) { 
this.state = 27;
;}if (true) break;

case 27:
//C
this.state = 30;
parent.__c.LogImpl("11206688",parent._dateutils._tickstostring(ba,parent.__c.DateTime.getNow())+("--> Weather Job-OK: Setting next update for "+parent.__c.SmartStringFormatter("",(Object)(parent._minutesbetweencalls))+" min"),0);
if (true) break;

case 30:
//C
this.state = 33;
;
 //BA.debugLineNum = 320;BA.debugLine="mpage.tmrTimerCallSub.ExistsRemoveAdd_DelayedPlu";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._existsremoveadd_delayedplus /*String*/ (parent,"Try_Weather_Update",(int) (60000*parent._minutesbetweencalls));
 if (true) break;

case 32:
//C
this.state = 33;
 //BA.debugLineNum = 324;BA.debugLine="Log(\"weather call failed - response code = \" & j";
parent.__c.LogImpl("11206693","weather call failed - response code = "+BA.NumberToString(_job._response /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse*/ .getStatusCode()),0);
 //BA.debugLineNum = 325;BA.debugLine="mpage.EventGbl.Raise(gblConst.EVENT_WEATHER_UPDA";
parent._mpage._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._raise /*String*/ (parent._gblconst._event_weather_update_failed /*String*/ );
 //BA.debugLineNum = 326;BA.debugLine="mpage.tmrTimerCallSub.ExistsRemoveAdd_DelayedPlu";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._existsremoveadd_delayedplus /*String*/ (parent,"Try_Weather_Update",(int) (60000*3));
 if (true) break;

case 33:
//C
this.state = -1;
;
 //BA.debugLineNum = 330;BA.debugLine="job.Release";
_job._release /*String*/ ();
 //BA.debugLineNum = 331;BA.debugLine="Return retVal";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_retval));return;};
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _jobdone(sadLogic.HomeCentral.httpjob _job) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "TRY_WEATHER_UPDATE"))
	return _try_weather_update();
return BA.SubDelegator.SubNotFound;
}
}
