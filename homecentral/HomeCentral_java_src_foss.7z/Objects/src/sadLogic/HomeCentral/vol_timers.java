package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class vol_timers {
private static vol_timers mostCurrent = new vol_timers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.MediaPlayerWrapper _mp_test = null;
public static anywheresoftware.b4a.phone.Phone _ph = null;
public static int _maxvolumemusic = 0;
public static int _maxvolumenotifaction = 0;
public static int _maxvolumesys = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _buildalarmfile(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Public Sub BuildAlarmFile(s As String) As String";
 //BA.debugLineNum = 38;BA.debugLine="Return \"ktimers_\" & s & \".ogg\".As(String).ToLower";
if (true) return "ktimers_"+_s+(".ogg").toLowerCase();
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public static void  _playsound(anywheresoftware.b4a.BA _ba,int _sbvol,String _sfile) throws Exception{
ResumableSub_PlaySound rsub = new ResumableSub_PlaySound(null,_ba,_sbvol,_sfile);
rsub.resume((_ba.processBA == null ? _ba : _ba.processBA), null);
}
public static class ResumableSub_PlaySound extends BA.ResumableSub {
public ResumableSub_PlaySound(sadLogic.HomeCentral.vol_timers parent,anywheresoftware.b4a.BA _ba,int _sbvol,String _sfile) {
this.parent = parent;
this._ba = _ba;
this._sbvol = _sbvol;
this._sfile = _sfile;
}
sadLogic.HomeCentral.vol_timers parent;
anywheresoftware.b4a.BA _ba;
int _sbvol;
String _sfile;
boolean _b = false;
int _beforevol = 0;
int _vol = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 48;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 10;
this.catchState = 9;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 9;
 //BA.debugLineNum = 50;BA.debugLine="Dim b As Boolean = False";
_b = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 51;BA.debugLine="ph.SetMute(ph.VOLUME_MUSIC,b)";
parent._ph.SetMute(parent._ph.VOLUME_MUSIC,_b);
 //BA.debugLineNum = 52;BA.debugLine="ph.SetMute(ph.VOLUME_SYSTEM,b)";
parent._ph.SetMute(parent._ph.VOLUME_SYSTEM,_b);
 //BA.debugLineNum = 53;BA.debugLine="Dim beforeVol As Int";
_beforevol = 0;
 //BA.debugLineNum = 54;BA.debugLine="Dim Vol As Int = sbVol * (\"0.\" & ph.GetMaxVolume";
_vol = (int) (_sbvol*(double)(Double.parseDouble(("0."+BA.NumberToString(parent._ph.GetMaxVolume(parent._ph.VOLUME_MUSIC))))));
 //BA.debugLineNum = 55;BA.debugLine="beforeVol = ph.GetVolume(ph.VOLUME_MUSIC) '--- s";
_beforevol = parent._ph.GetVolume(parent._ph.VOLUME_MUSIC);
 //BA.debugLineNum = 56;BA.debugLine="ph.SetVolume(ph.VOLUME_MUSIC, Vol, False)";
parent._ph.SetVolume(parent._ph.VOLUME_MUSIC,_vol,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 57;BA.debugLine="MP_Test.Initialize()";
parent._mp_test.Initialize();
 //BA.debugLineNum = 58;BA.debugLine="MP_Test.Load(File.DirAssets, sFile)";
parent._mp_test.Load(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),_sfile);
 //BA.debugLineNum = 59;BA.debugLine="MP_Test.Play";
parent._mp_test.Play();
 //BA.debugLineNum = 60;BA.debugLine="Do While MP_Test.IsPlaying";
if (true) break;

case 4:
//do while
this.state = 7;
while (parent._mp_test.IsPlaying()) {
this.state = 6;
if (true) break;
}
if (true) break;

case 6:
//C
this.state = 4;
 //BA.debugLineNum = 61;BA.debugLine="Sleep(200)";
anywheresoftware.b4a.keywords.Common.Sleep((_ba.processBA == null ? _ba : _ba.processBA),this,(int) (200));
this.state = 11;
return;
case 11:
//C
this.state = 4;
;
 if (true) break;

case 7:
//C
this.state = 10;
;
 //BA.debugLineNum = 63;BA.debugLine="ph.SetVolume(ph.VOLUME_MUSIC, beforeVol, False)";
parent._ph.SetVolume(parent._ph.VOLUME_MUSIC,_beforevol,anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 9:
//C
this.state = 10;
this.catchState = 0;
 //BA.debugLineNum = 65;BA.debugLine="guiHelpers.Show_toast2(gblConst.VOLUME_ERR,3500)";
parent.mostCurrent._guihelpers._show_toast2 /*String*/ (_ba,parent.mostCurrent._gblconst._volume_err /*String*/ ,(int) (3500));
 if (true) break;
if (true) break;

case 10:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e0);}
            }
        }
    }
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private MP_Test As MediaPlayer";
_mp_test = new anywheresoftware.b4a.objects.MediaPlayerWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 10;BA.debugLine="Private MaxVolumeMusic,MaxVolumeNotifaction,MaxVo";
_maxvolumemusic = 0;
_maxvolumenotifaction = 0;
_maxvolumesys = 0;
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static String  _savetimervolume(anywheresoftware.b4a.BA _ba,String _f,int _vol) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Public Sub SaveTimerVolume(f As String,vol As Int)";
 //BA.debugLineNum = 43;BA.debugLine="Main.kvs.Put(gblConst.INI_TIMERS_ALARM_FILE,Build";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_timers_alarm_file /*String*/ ,(Object)(_buildalarmfile(_ba,_f)));
 //BA.debugLineNum = 44;BA.debugLine="Main.kvs.Put(gblConst.INI_TIMERS_ALARM_VOLUME,vol";
mostCurrent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (mostCurrent._gblconst._ini_timers_alarm_volume /*String*/ ,(Object)(_vol));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public static String  _selectitemincbo(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xcombobox _b,String _selectfile) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Public Sub SelectItemInCBO(b As B4XComboBox,select";
 //BA.debugLineNum = 20;BA.debugLine="b.cmbBox.AddAll(Array As String( _ 				\"Beep01\",\"";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Beep01","Beep02","Beep03","Rooster","Space"}));
 //BA.debugLineNum = 22;BA.debugLine="selectFile = selectFile.ToLowerCase";
_selectfile = _selectfile.toLowerCase();
 //BA.debugLineNum = 23;BA.debugLine="If selectFile.Contains(\"beep01\") Then";
if (_selectfile.contains("beep01")) { 
 //BA.debugLineNum = 24;BA.debugLine="b.cmbBox.SelectedIndex = 0";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setSelectedIndex((int) (0));
 }else if(_selectfile.contains("beep02")) { 
 //BA.debugLineNum = 26;BA.debugLine="b.cmbBox.SelectedIndex = 1";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setSelectedIndex((int) (1));
 }else if(_selectfile.contains("beep03")) { 
 //BA.debugLineNum = 28;BA.debugLine="b.cmbBox.SelectedIndex = 2";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setSelectedIndex((int) (2));
 }else if(_selectfile.contains("rooster")) { 
 //BA.debugLineNum = 30;BA.debugLine="b.cmbBox.SelectedIndex = 3";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setSelectedIndex((int) (3));
 }else if(_selectfile.contains("space")) { 
 //BA.debugLineNum = 32;BA.debugLine="b.cmbBox.SelectedIndex = 4";
_b._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .setSelectedIndex((int) (4));
 };
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
}
