package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagefiles{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _leftw="";
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.5d);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("lblbusy").vw.setLeft((int)((50d / 100 * width) - (views.get("lblbusy").vw.getWidth() / 2)));
views.get("lblbusy").vw.setTop((int)((50d / 100 * height) - (views.get("lblbusy").vw.getHeight() / 2)));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("pnlpreview").vw.setLeft((int)(0d));
views.get("pnlpreview").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlpreview").vw.setTop((int)((0d * scale)));
views.get("pnlpreview").vw.setHeight((int)((42d / 100 * height) - ((0d * scale))));
views.get("pnlfiles").vw.setLeft((int)(0d));
views.get("pnlfiles").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlfiles").vw.setTop((int)((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight())));
views.get("pnlfiles").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight()))));
views.get("clvfiles").vw.setLeft((int)((0d * scale)));
views.get("clvfiles").vw.setWidth((int)((100d / 100 * width) - ((0d * scale))));
views.get("clvfiles").vw.setTop((int)(0d));
views.get("clvfiles").vw.setHeight((int)((views.get("pnlfiles").vw.getHeight())*.88d - (0d)));
views.get("pnlfilectrl").vw.setTop((int)((views.get("pnlfiles").vw.getHeight())*.88d));
views.get("pnlfilectrl").vw.setHeight((int)((views.get("pnlfiles").vw.getHeight()) - ((views.get("pnlfiles").vw.getHeight())*.88d)));
views.get("pnlfilectrl").vw.setLeft((int)(0d));
views.get("pnlfilectrl").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("cbosort").vw.setTop((int)(0d));
views.get("cbosort").vw.setHeight((int)((views.get("pnlfilectrl").vw.getHeight())-(4d * scale) - (0d)));
views.get("cbosort").vw.setLeft((int)(((views.get("pnlfilectrl").vw.getWidth())/2d)-(26d * scale) - (views.get("cbosort").vw.getWidth() / 2)));
views.get("lblsort2").vw.setLeft((int)((views.get("cbosort").vw.getLeft() + views.get("cbosort").vw.getWidth())+(8d * scale)));
views.get("lblsort2").vw.setHeight((int)((views.get("cbosort").vw.getHeight())));
views.get("ivpreview").vw.setTop((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(4d * scale)));
views.get("ivpreview").vw.setHeight((int)((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight())-(10d * scale) - ((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(4d * scale))));
views.get("ivpreview").vw.setLeft((int)((26d * scale)));
views.get("ivpreview").vw.setWidth((int)((views.get("pnlpreview").vw.getWidth())*.5d - ((26d * scale))));
views.get("pnlbtns").vw.setTop((int)((views.get("ivpreview").vw.getTop())+(4d * scale)));
views.get("pnlbtns").vw.setHeight((int)((views.get("ivpreview").vw.getTop() + views.get("ivpreview").vw.getHeight()) - ((views.get("ivpreview").vw.getTop())+(4d * scale))));
views.get("pnlbtns").vw.setLeft((int)((views.get("ivpreview").vw.getLeft() + views.get("ivpreview").vw.getWidth())+(2d * scale)));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlpreview").vw.getLeft() + views.get("pnlpreview").vw.getWidth()) - ((views.get("ivpreview").vw.getLeft() + views.get("ivpreview").vw.getWidth())+(2d * scale))));
views.get("btndelete").vw.setWidth((int)((views.get("pnlbtns").vw.getWidth())*.75d));
views.get("btnloadandprint").vw.setWidth((int)((views.get("btndelete").vw.getWidth())));
views.get("btnload").vw.setWidth((int)((views.get("btndelete").vw.getWidth())));
views.get("btnloadandprint").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btnloadandprint").vw.getWidth() / 2)));
views.get("btndelete").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btndelete").vw.getWidth() / 2)));
views.get("btnload").vw.setLeft((int)((views.get("pnlbtns").vw.getWidth())/2d - (views.get("btnload").vw.getWidth() / 2)));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnlbtns", "0", BA.NumberToString((6d * scale)), "center"});
views.get("pnlportraitdivide").vw.setTop((int)((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight())-(3d * scale)));
views.get("pnlportraitdivide").vw.setHeight((int)((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight()) - ((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight())-(3d * scale))));
views.get("pnlportraitdivide").vw.setLeft((int)((views.get("pnlpreview").vw.getLeft())+(4d * scale)));
views.get("pnlportraitdivide").vw.setWidth((int)((views.get("pnlpreview").vw.getLeft() + views.get("pnlpreview").vw.getWidth())-(4d * scale) - ((views.get("pnlpreview").vw.getLeft())+(4d * scale))));
views.get("pnlportraitdividetop").vw.setTop((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(1d * scale)));
views.get("pnlportraitdividetop").vw.setHeight((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(4d * scale) - ((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(1d * scale))));
views.get("pnlportraitdividetop").vw.setLeft((int)((views.get("pnlpreview").vw.getLeft())+(4d * scale)));
views.get("pnlportraitdividetop").vw.setWidth((int)((views.get("pnlpreview").vw.getLeft() + views.get("pnlpreview").vw.getWidth())-(4d * scale) - ((views.get("pnlpreview").vw.getLeft())+(4d * scale))));
;}else{ 
;
views.get("pnlportraitdivide").vw.setVisible(BA.parseBoolean("false"));
views.get("pnlportraitdividetop").vw.setTop((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())-(1d * scale)));
views.get("pnlportraitdividetop").vw.setHeight((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(2d * scale) - ((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())-(1d * scale))));
views.get("pnlportraitdividetop").vw.setLeft((int)((views.get("pnlpreview").vw.getLeft())+(4d * scale)));
views.get("pnlportraitdividetop").vw.setWidth((int)((views.get("pnlpreview").vw.getLeft() + views.get("pnlpreview").vw.getWidth())-(4d * scale) - ((views.get("pnlpreview").vw.getLeft())+(4d * scale))));
_leftw = BA.NumberToString((45d / 100 * width));
views.get("pnlpreview").vw.setLeft((int)(0d));
views.get("pnlpreview").vw.setWidth((int)(Double.parseDouble(_leftw) - (0d)));
views.get("pnlpreview").vw.setTop((int)(0d));
views.get("pnlpreview").vw.setHeight((int)((98d / 100 * height) - (0d)));
views.get("pnlfiles").vw.setTop((int)(0d));
views.get("pnlfiles").vw.setHeight((int)((98d / 100 * height) - (0d)));
views.get("pnlfiles").vw.setLeft((int)(Double.parseDouble(_leftw)));
views.get("pnlfiles").vw.setWidth((int)((100d / 100 * width) - (Double.parseDouble(_leftw))));
views.get("pnlfilectrl").vw.setHeight((int)((60d * scale)));
views.get("pnlfilectrl").vw.setLeft((int)((2d * scale)));
views.get("pnlfilectrl").vw.setWidth((int)((views.get("pnlfiles").vw.getWidth()) - ((2d * scale))));
views.get("pnlfilectrl").vw.setTop((int)((100d / 100 * height)-(60d * scale)));
views.get("pnlfilectrl").vw.setHeight((int)((98d / 100 * height) - ((100d / 100 * height)-(60d * scale))));
views.get("cbosort").vw.setTop((int)(0d));
views.get("cbosort").vw.setHeight((int)((views.get("pnlfilectrl").vw.getHeight())-(4d * scale) - (0d)));
views.get("cbosort").vw.setLeft((int)(((views.get("pnlfilectrl").vw.getWidth())*.45d)-(30d * scale) - (views.get("cbosort").vw.getWidth() / 2)));
views.get("lblsort2").vw.setTop((int)(0d));
views.get("lblsort2").vw.setHeight((int)((views.get("cbosort").vw.getHeight()) - (0d)));
views.get("lblsort2").vw.setLeft((int)((views.get("cbosort").vw.getLeft() + views.get("cbosort").vw.getWidth())+(10d * scale)));
views.get("clvfiles").vw.setLeft((int)((2d * scale)));
views.get("clvfiles").vw.setWidth((int)((views.get("pnlfiles").vw.getWidth()) - ((2d * scale))));
views.get("clvfiles").vw.setTop((int)((2d * scale)));
views.get("clvfiles").vw.setHeight((int)((views.get("pnlfilectrl").vw.getTop()) - ((2d * scale))));
views.get("pnlbtns").vw.setLeft((int)(0d));
views.get("pnlbtns").vw.setWidth((int)((views.get("pnlpreview").vw.getWidth()) - (0d)));
views.get("pnlbtns").vw.setTop((int)((views.get("pnlfilectrl").vw.getTop())));
views.get("pnlbtns").vw.setHeight((int)((views.get("pnlpreview").vw.getTop() + views.get("pnlpreview").vw.getHeight()) - ((views.get("pnlfilectrl").vw.getTop()))));
views.get("ivpreview").vw.setHeight((int)((views.get("pnlpreview").vw.getHeight())-((views.get("lblfilename").vw.getHeight())+(views.get("lblheaderfilename").vw.getHeight())+(views.get("pnlbtns").vw.getHeight())+(8d * scale))));
views.get("ivpreview").vw.setWidth((int)((views.get("ivpreview").vw.getHeight())*1.18d));
views.get("ivpreview").vw.setTop((int)((views.get("lblfilename").vw.getTop() + views.get("lblfilename").vw.getHeight())+(4d * scale)));
views.get("ivpreview").vw.setLeft((int)((views.get("pnlpreview").vw.getWidth())/2d - (views.get("ivpreview").vw.getWidth() / 2)));
views.get("lblfilename").vw.setLeft((int)((4d * scale)));
views.get("lblfilename").vw.setWidth((int)((views.get("pnlpreview").vw.getWidth())-(4d * scale) - ((4d * scale))));
//BA.debugLineNum = 108;BA.debugLine="DSE_Layout.SpreadHorizontally(pnlBtns,200dip,12dip,\"center\")"[pageFiles/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlbtns", BA.NumberToString((200d * scale)), BA.NumberToString((12d * scale)), "center"});
//BA.debugLineNum = 111;BA.debugLine="End If"[pageFiles/General script]
;};

}
}