package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgandroidpoweroptions extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgandroidpoweroptions");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgandroidpoweroptions.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.sadpreferencesdialog _mpowerdlg = null;
public sadLogic.OctoTouchController.sadpreferencesdialoghelper _prefhelper = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgAndroidPowe";
_mmodule = "dlgAndroidPowerOptions";
 //BA.debugLineNum = 9;BA.debugLine="Private mainObj As B4XMainPage";
_mainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mPowerDlg As sadPreferencesDialog";
_mpowerdlg = new sadLogic.OctoTouchController.sadpreferencesdialog();
 //BA.debugLineNum = 12;BA.debugLine="Private prefHelper As sadPreferencesDialogHelper";
_prefhelper = new sadLogic.OctoTouchController.sadpreferencesdialoghelper();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 23;BA.debugLine="mPowerDlg.Dialog.Close(xui.DialogResponse_Cancel)";
_mpowerdlg._dialog /*sadLogic.OctoTouchController.b4xdialog*/ ._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _createdefaultfile() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="public Sub CreateDefaultFile";
 //BA.debugLineNum = 29;BA.debugLine="If File.Exists(xui.DefaultFolder,gblConst.ANDROID";
if (__c.File.Exists(_xui.getDefaultFolder(),_gblconst._android_power_options_file /*String*/ )==__c.False) { 
 //BA.debugLineNum = 30;BA.debugLine="File.WriteMap(xui.DefaultFolder,gblConst.ANDROID";
__c.File.WriteMap(_xui.getDefaultFolder(),_gblconst._android_power_options_file /*String*/ ,__c.createMap(new Object[] {(Object)("TakePwr"),(Object)("true"),(Object)("NotPrintingScrnOff"),(Object)("true"),(Object)("NotPrintingMinTill"),(Object)(90),(Object)("PrintingScrnOff"),(Object)("false"),(Object)("PrintingMinTill"),(Object)(20)}));
 };
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _dlgpower_beforedialogdisplayed(Object _template) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Private Sub dlgPower_BeforeDialogDisplayed (Templa";
 //BA.debugLineNum = 105;BA.debugLine="prefHelper.SkinDialog(Template)";
_prefhelper._skindialog /*String*/ (_template);
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public boolean  _dlgpower_isvalid(anywheresoftware.b4a.objects.collections.Map _tempdata) throws Exception{
 //BA.debugLineNum = 84;BA.debugLine="Private Sub dlgPower_IsValid (TempData As Map) As";
 //BA.debugLineNum = 85;BA.debugLine="Return True '--- all is good!";
if (true) return __c.True;
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return false;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 17;BA.debugLine="Public Sub Initialize() As Object";
 //BA.debugLineNum = 18;BA.debugLine="mainObj = B4XPages.MainPage";
_mainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 19;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return null;
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgandroidpoweroptions parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgandroidpoweroptions parent;
anywheresoftware.b4a.objects.collections.Map _data = null;
float _h = 0f;
float _w = 0f;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 40;BA.debugLine="Dim Data As Map = File.ReadMap(xui.DefaultFolder,";
_data = new anywheresoftware.b4a.objects.collections.Map();
_data = parent.__c.File.ReadMap(parent._xui.getDefaultFolder(),parent._gblconst._android_power_options_file /*String*/ );
 //BA.debugLineNum = 42;BA.debugLine="Dim h,w As Float";
_h = 0f;
_w = 0f;
 //BA.debugLineNum = 43;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 14;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 13;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 44;BA.debugLine="If guiHelpers.gScreenSizeAprox >= 6 And guiHelpe";
if (true) break;

case 4:
//if
this.state = 11;
if (parent._guihelpers._gscreensizeaprox /*double*/ >=6 && parent._guihelpers._gscreensizeaprox /*double*/ <=8) { 
this.state = 6;
}else if(parent._guihelpers._gscreensizeaprox /*double*/ >=8) { 
this.state = 8;
}else {
this.state = 10;
}if (true) break;

case 6:
//C
this.state = 11;
 //BA.debugLineNum = 45;BA.debugLine="h = 55%y";
_h = (float) (parent.__c.PerYToCurrent((float) (55),ba));
 if (true) break;

case 8:
//C
this.state = 11;
 //BA.debugLineNum = 47;BA.debugLine="h = 42%y";
_h = (float) (parent.__c.PerYToCurrent((float) (42),ba));
 if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 49;BA.debugLine="h = 80%y";
_h = (float) (parent.__c.PerYToCurrent((float) (80),ba));
 if (true) break;

case 11:
//C
this.state = 14;
;
 //BA.debugLineNum = 51;BA.debugLine="w = 360dip";
_w = (float) (parent.__c.DipToCurrent((int) (360)));
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 53;BA.debugLine="h = 330dip";
_h = (float) (parent.__c.DipToCurrent((int) (330)));
 //BA.debugLineNum = 54;BA.debugLine="w = guiHelpers.gWidth * .92";
_w = (float) (parent._guihelpers._gwidth /*float*/ *.92);
 if (true) break;

case 14:
//C
this.state = 15;
;
 //BA.debugLineNum = 57;BA.debugLine="mPowerDlg.Initialize(mainObj.root, \"Android Power";
parent._mpowerdlg._initialize /*String*/ (ba,parent._mainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,(Object)("Android Power Settings"),(int) (_w),(int) (_h));
 //BA.debugLineNum = 58;BA.debugLine="prefHelper.Initialize(mPowerDlg)";
parent._prefhelper._initialize /*String*/ (ba,parent._mpowerdlg);
 //BA.debugLineNum = 59;BA.debugLine="mPowerDlg.Clear";
parent._mpowerdlg._clear /*String*/ ();
 //BA.debugLineNum = 60;BA.debugLine="mPowerDlg.LoadFromJson(File.ReadString(File.DirAs";
parent._mpowerdlg._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"dlgPower.json"));
 //BA.debugLineNum = 61;BA.debugLine="mPowerDlg.SetEventsListener(Me,\"dlgPower\")";
parent._mpowerdlg._seteventslistener /*String*/ (parent,"dlgPower");
 //BA.debugLineNum = 63;BA.debugLine="prefHelper.ThemePrefDialogForm";
parent._prefhelper._themeprefdialogform /*String*/ ();
 //BA.debugLineNum = 64;BA.debugLine="mPowerDlg.PutAtTop = False";
parent._mpowerdlg._putattop /*Object*/  = (Object)(parent.__c.False);
 //BA.debugLineNum = 65;BA.debugLine="Dim RS As ResumableSub = mPowerDlg.ShowDialog(Dat";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mpowerdlg._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_data,(Object)("OK"),(Object)("CANCEL"));
 //BA.debugLineNum = 66;BA.debugLine="prefHelper.dlgHelper.ThemeInputDialogBtnsResize";
parent._prefhelper._dlghelper /*sadLogic.OctoTouchController.sadb4xdialoghelper*/ ._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 68;BA.debugLine="Wait For (RS) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 19;
return;
case 19:
//C
this.state = 15;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 69;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 15:
//if
this.state = 18;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 17;
}if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 71;BA.debugLine="guiHelpers.Show_toast(gblConst.DATA_SAVED,1500)";
parent._guihelpers._show_toast /*String*/ (ba,parent._gblconst._data_saved /*String*/ ,(int) (1500));
 //BA.debugLineNum = 72;BA.debugLine="File.WriteMap(xui.DefaultFolder,gblConst.ANDROID";
parent.__c.File.WriteMap(parent._xui.getDefaultFolder(),parent._gblconst._android_power_options_file /*String*/ ,_data);
 //BA.debugLineNum = 73;BA.debugLine="config.ReadAndroidPowerCFG";
parent._config._readandroidpowercfg /*String*/ (ba);
 //BA.debugLineNum = 74;BA.debugLine="fnc.ProcessPowerFlags";
parent._fnc._processpowerflags /*String*/ (ba);
 if (true) break;

case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 78;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 79;BA.debugLine="mainObj.pObjCurrentDlg1 = Null";
parent._mainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
