package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewweatherforcast{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _pad="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlforecast1").vw.setLeft((int)(0d));
views.get("pnlforecast1").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlforecast1").vw.setTop((int)(0d));
views.get("pnlforecast1").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("imgforecasticon1").vw.setTop((int)((views.get("pnlforecast1").vw.getHeight())/2d - (views.get("imgforecasticon1").vw.getHeight() / 2)));
views.get("lblforecastdesc1").vw.setTop((int)((views.get("pnlforecast1").vw.getHeight())/2d - (views.get("lblforecastdesc1").vw.getHeight() / 2)));
views.get("lblforecastday1").vw.setTop((int)((views.get("lblforecastdesc1").vw.getTop()) - (views.get("lblforecastday1").vw.getHeight())));
views.get("lblforecasthigh1").vw.setTop((int)((views.get("lblforecastdesc1").vw.getTop() + views.get("lblforecastdesc1").vw.getHeight())-(6d * scale)));
views.get("lblforecastlow1").vw.setTop((int)((views.get("lblforecastdesc1").vw.getTop() + views.get("lblforecastdesc1").vw.getHeight())-(6d * scale)));
_pad = BA.NumberToString((20d * scale));
views.get("pnlforcastdivider").vw.setLeft((int)((views.get("imgforecasticon1").vw.getLeft() + views.get("imgforecasticon1").vw.getWidth())+Double.parseDouble(_pad)));
views.get("pnlforcastdivider").vw.setWidth((int)((100d / 100 * width)-Double.parseDouble(_pad) - ((views.get("imgforecasticon1").vw.getLeft() + views.get("imgforecasticon1").vw.getWidth())+Double.parseDouble(_pad))));
views.get("pnlforcastdivider").vw.setTop((int)((views.get("lblforecasthigh1").vw.getTop() + views.get("lblforecasthigh1").vw.getHeight())));
views.get("pnlforcastdivider").vw.setHeight((int)((views.get("lblforecasthigh1").vw.getTop() + views.get("lblforecasthigh1").vw.getHeight())+(10d * scale) - ((views.get("lblforecasthigh1").vw.getTop() + views.get("lblforecasthigh1").vw.getHeight()))));

}
}