package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class menus {
private static menus mostCurrent = new menus();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.Accessibility _ac = null;
public static float _scale = 0f;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static void  _buildheadermenu(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.assegmentedtab _tb,Object _callback,String _event) throws Exception{
ResumableSub_BuildHeaderMenu rsub = new ResumableSub_BuildHeaderMenu(null,_ba,_tb,_callback,_event);
rsub.resume((_ba.processBA == null ? _ba : _ba.processBA), null);
}
public static class ResumableSub_BuildHeaderMenu extends BA.ResumableSub {
public ResumableSub_BuildHeaderMenu(sadLogic.HomeCentral.menus parent,anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.assegmentedtab _tb,Object _callback,String _event) {
this.parent = parent;
this._ba = _ba;
this._tb = _tb;
this._callback = _callback;
this._event = _event;
}
sadLogic.HomeCentral.menus parent;
anywheresoftware.b4a.BA _ba;
sadLogic.HomeCentral.assegmentedtab _tb;
Object _callback;
String _event;
int _ttl = 0;
String _a = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 37;BA.debugLine="tb.Clear";
_tb._clear /*void*/ ();
 //BA.debugLineNum = 38;BA.debugLine="tb.ShowSeperators = True";
_tb._setshowseperators(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 39;BA.debugLine="tb.ImageHeight = 46dip";
_tb._setimageheight((float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (46))));
 //BA.debugLineNum = 40;BA.debugLine="tb.SelectionPanel.Color = clrTheme.Background2";
_tb._getselectionpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setColor(parent.mostCurrent._clrtheme._background2 /*int*/ );
 //BA.debugLineNum = 41;BA.debugLine="tb.ItemTextProperties.TextColor = clrTheme.txtNor";
_tb._getitemtextproperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ ().TextColor /*int*/  = parent.mostCurrent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 42;BA.debugLine="tb.ItemTextProperties.SelectedTextColor = clrThem";
_tb._getitemtextproperties /*sadLogic.HomeCentral.assegmentedtab._assegmentedtab_itemtextproperties*/ ().SelectedTextColor /*int*/  = parent.mostCurrent._clrtheme._txtaccent /*int*/ ;
 //BA.debugLineNum = 46;BA.debugLine="Sleep(0)";
anywheresoftware.b4a.keywords.Common.Sleep((_ba.processBA == null ? _ba : _ba.processBA),this,(int) (0));
this.state = 26;
return;
case 26:
//C
this.state = 1;
;
 //BA.debugLineNum = 48;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 25;
this.catchState = 24;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 24;
 //BA.debugLineNum = 49;BA.debugLine="Dim ttl As Int = 1";
_ttl = (int) (1);
 //BA.debugLineNum = 50;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"mai";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_home.png"),(Object)("hm"));
 //BA.debugLineNum = 52;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";
if (true) break;

case 4:
//if
this.state = 7;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_weather /*String*/ )))) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 53;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_weather.png"),(Object)("wt"));
 //BA.debugLineNum = 54;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;
;
 //BA.debugLineNum = 56;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";

case 7:
//if
this.state = 10;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_timers /*String*/ )))) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 57;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_timers.png"),(Object)("tm"));
 //BA.debugLineNum = 58;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;
;
 //BA.debugLineNum = 60;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";

case 10:
//if
this.state = 13;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_calc /*String*/ )))) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 61;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_calc.png"),(Object)("ca"));
 //BA.debugLineNum = 62;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;
;
 //BA.debugLineNum = 64;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";

case 13:
//if
this.state = 16;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_conv /*String*/ )))) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 65;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_conversions.png"),(Object)("cv"));
 //BA.debugLineNum = 66;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;
;
 //BA.debugLineNum = 68;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";

case 16:
//if
this.state = 19;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_photo /*String*/ )))) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 69;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_pics.png"),(Object)("ph"));
 //BA.debugLineNum = 70;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;
;
 //BA.debugLineNum = 72;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_S";

case 19:
//if
this.state = 22;
if (BA.ObjectToBoolean(parent.mostCurrent._config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(parent.mostCurrent._gblconst._keys_main_setup_page_web /*String*/ )))) { 
this.state = 21;
}if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 73;BA.debugLine="tb.AddTab2(\"\",XUI.LoadBitmap(File.DirAssets,\"ma";
_tb._addtab2 /*String*/ ("",parent._xui.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"main_menu_web.png"),(Object)("wb"));
 //BA.debugLineNum = 74;BA.debugLine="ttl = ttl + 1";
_ttl = (int) (_ttl+1);
 if (true) break;

case 22:
//C
this.state = 25;
;
 if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 0;
 //BA.debugLineNum = 78;BA.debugLine="Dim a As String = \"Snapin file needs to be rebui";
_a = "Snapin file needs to be rebuilt!!!!!!!!!!!!!!!!!!!!!";
 //BA.debugLineNum = 79;BA.debugLine="Log(a) : Log(a)";
anywheresoftware.b4a.keywords.Common.LogImpl("35323948",_a,0);
 //BA.debugLineNum = 79;BA.debugLine="Log(a) : Log(a)";
anywheresoftware.b4a.keywords.Common.LogImpl("35323948",_a,0);
 //BA.debugLineNum = 80;BA.debugLine="ExitApplication";
anywheresoftware.b4a.keywords.Common.ExitApplication();
 if (true) break;
if (true) break;

case 25:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 83;BA.debugLine="tb.mBase.Width = (ttl * 70dip) + (ttl * 4dip)";
_tb._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setWidth((int) ((_ttl*anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (70)))+(_ttl*anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4)))));
 //BA.debugLineNum = 84;BA.debugLine="tb.Base_Resize2";
_tb._base_resize2 /*String*/ ();
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e0);}
            }
        }
    }
}
public static String  _buildsidemenu(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.collections.List _lstmnus,anywheresoftware.b4a.objects.collections.List _lstretvals) throws Exception{
b4a.example3.customlistview _lvsm = null;
anywheresoftware.b4a.objects.LabelWrapper _lbl = null;
int _x = 0;
 //BA.debugLineNum = 89;BA.debugLine="Public Sub BuildSideMenu(lstMnus As List, lstRetVa";
 //BA.debugLineNum = 91;BA.debugLine="Dim lvSM As CustomListView = B4XPages.MainPage.lv";
_lvsm = mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._lvsidemenu /*b4a.example3.customlistview*/ ;
 //BA.debugLineNum = 92;BA.debugLine="lvSM.Clear";
_lvsm._clear();
 //BA.debugLineNum = 94;BA.debugLine="If lstMnus.Size = 1 And lstMnus.Get(0) = \"\" Then";
if (_lstmnus.getSize()==1 && (_lstmnus.Get((int) (0))).equals((Object)(""))) { 
 //BA.debugLineNum = 95;BA.debugLine="Return '--- no menus for this page";
if (true) return "";
 };
 //BA.debugLineNum = 98;BA.debugLine="clrTheme.SetThemeCustomListView(lvSM)";
mostCurrent._clrtheme._setthemecustomlistview /*String*/ (_ba,_lvsm);
 //BA.debugLineNum = 99;BA.debugLine="Scale = ac.GetUserFontScale";
_scale = _ac.GetUserFontScale();
 //BA.debugLineNum = 100;BA.debugLine="Dim lbl As Label : lbl.Initialize(\"\")";
_lbl = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 100;BA.debugLine="Dim lbl As Label : lbl.Initialize(\"\")";
_lbl.Initialize(_ba,"");
 //BA.debugLineNum = 101;BA.debugLine="lbl.TextSize = 20 * Scale '--- scale is returned";
_lbl.setTextSize((float) (20*_scale));
 //BA.debugLineNum = 102;BA.debugLine="If lbl.TextSize < 20 Then lbl.TextSize = 20";
if (_lbl.getTextSize()<20) { 
_lbl.setTextSize((float) (20));};
 //BA.debugLineNum = 104;BA.debugLine="Try";
try { //BA.debugLineNum = 106;BA.debugLine="For x = 0 To lstMnus.size - 1";
{
final int step13 = 1;
final int limit13 = (int) (_lstmnus.getSize()-1);
_x = (int) (0) ;
for (;_x <= limit13 ;_x = _x + step13 ) {
 //BA.debugLineNum = 107;BA.debugLine="lbl.Text = lstMnus.Get(x)";
_lbl.setText(BA.ObjectToCharSequence(_lstmnus.Get(_x)));
 //BA.debugLineNum = 108;BA.debugLine="If lstRetVals.IsInitialized = False Then";
if (_lstretvals.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 109;BA.debugLine="lvSM.AddTextItem(lbl.Text,\"\")";
_lvsm._addtextitem((Object)(_lbl.getText()),(Object)(""));
 }else {
 //BA.debugLineNum = 111;BA.debugLine="lvSM.AddTextItem(lbl.Text,lstRetVals.get(x))";
_lvsm._addtextitem((Object)(_lbl.getText()),_lstretvals.Get(_x));
 };
 }
};
 } 
       catch (Exception e22) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e22); //BA.debugLineNum = 116;BA.debugLine="Log(\"BuildSideMenu-->\" & LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("35389467","BuildSideMenu-->"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public static String  _init(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Init()";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 8;BA.debugLine="Private ac As Accessibility";
_ac = new anywheresoftware.b4a.objects.Accessibility();
 //BA.debugLineNum = 9;BA.debugLine="Private Scale As Float";
_scale = 0f;
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public static String  _setheader(anywheresoftware.b4a.BA _ba,String _txt,String _imgname) throws Exception{
 //BA.debugLineNum = 123;BA.debugLine="Public Sub SetHeader(txt As String, imgName As Str";
 //BA.debugLineNum = 124;BA.debugLine="guiHelpers.ResizeText(\"  \" & txt,B4XPages.MainPag";
mostCurrent._guihelpers._resizetext /*String*/ (_ba,"  "+_txt,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._btnhdrtxt1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject())));
 //BA.debugLineNum = 125;BA.debugLine="B4XPages.MainPage.btnHdrTxt1.TextSize = B4XPages.";
mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._btnhdrtxt1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextSize((float) (mostCurrent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (_ba)._btnhdrtxt1 /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getTextSize()-4));
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
}
