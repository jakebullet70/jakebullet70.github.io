package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadas_floatingpanel extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.sadas_floatingpanel");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.sadas_floatingpanel.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties _g_arrowproperties = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_parent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_background = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_panel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnl_arrow = null;
public String _m_openorientation = "";
public long _m_duration = 0L;
public boolean _m_arrowvisible = false;
public boolean _m_closeontap = false;
public int _backgroundcolor = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public static class _asfloatingpanel_arrowproperties{
public boolean IsInitialized;
public String ArrowOrientation;
public int Color;
public float Width;
public float Height;
public float Left;
public float Top;
public void Initialize() {
IsInitialized = true;
ArrowOrientation = "";
Color = 0;
Width = 0f;
Height = 0f;
Left = 0f;
Top = 0f;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 34;BA.debugLine="Type ASFloatingPanel_ArrowProperties(ArrowOrienta";
;
 //BA.debugLineNum = 36;BA.debugLine="Private g_ArrowProperties As ASFloatingPanel_Arro";
_g_arrowproperties = new sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties();
 //BA.debugLineNum = 38;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 39;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 40;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 41;BA.debugLine="Private xpnl_Parent As B4XView";
_xpnl_parent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private xpnl_Background As B4XView";
_xpnl_background = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private xpnl_Panel As B4XView";
_xpnl_panel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private xpnl_Arrow As B4XView";
_xpnl_arrow = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private m_OpenOrientation As String";
_m_openorientation = "";
 //BA.debugLineNum = 47;BA.debugLine="Private m_Duration As Long";
_m_duration = 0L;
 //BA.debugLineNum = 48;BA.debugLine="Private m_ArrowVisible As Boolean = False";
_m_arrowvisible = __c.False;
 //BA.debugLineNum = 49;BA.debugLine="Private m_CloseOnTap As Boolean = True";
_m_closeontap = __c.True;
 //BA.debugLineNum = 51;BA.debugLine="Public BackgroundColor As Int";
_backgroundcolor = 0;
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public void  _close() throws Exception{
ResumableSub_Close rsub = new ResumableSub_Close(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Close extends BA.ResumableSub {
public ResumableSub_Close(sadLogic.OctoTouchController.foss.sadas_floatingpanel parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.sadas_floatingpanel parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 169;BA.debugLine="If m_CloseOnTap = False Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._m_closeontap==parent.__c.False) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 170;BA.debugLine="EventClose";
parent._eventclose();
 //BA.debugLineNum = 171;BA.debugLine="If m_ArrowVisible Then xpnl_Arrow.SetVisibleAnima";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._m_arrowvisible) { 
this.state = 9;
;}if (true) break;

case 9:
//C
this.state = 12;
parent._xpnl_arrow.SetVisibleAnimated((int) (0),parent.__c.False);
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 172;BA.debugLine="xpnl_Background.SetVisibleAnimated(250,False)";
parent._xpnl_background.SetVisibleAnimated((int) (250),parent.__c.False);
 //BA.debugLineNum = 174;BA.debugLine="If m_OpenOrientation = getOpenOrientation_LeftBot";
if (true) break;

case 13:
//if
this.state = 30;
if ((parent._m_openorientation).equals(parent._getopenorientation_leftbottom())) { 
this.state = 15;
}else if((parent._m_openorientation).equals(parent._getopenorientation_rightbottom())) { 
this.state = 17;
}else if((parent._m_openorientation).equals(parent._getopenorientation_lefttop())) { 
this.state = 19;
}else if((parent._m_openorientation).equals(parent._getopenorientation_righttop())) { 
this.state = 21;
}else if((parent._m_openorientation).equals(parent._getopenorientation_leftright())) { 
this.state = 23;
}else if((parent._m_openorientation).equals(parent._getopenorientation_rightleft())) { 
this.state = 25;
}else if((parent._m_openorientation).equals(parent._getopenorientation_topbottom())) { 
this.state = 27;
}else if((parent._m_openorientation).equals(parent._getopenorientation_bottomtop())) { 
this.state = 29;
}if (true) break;

case 15:
//C
this.state = 30;
 //BA.debugLineNum = 175;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),parent._xpnl_panel.getLeft(),parent._xpnl_panel.getTop(),parent.__c.DipToCurrent((int) (1)),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 17:
//C
this.state = 30;
 //BA.debugLineNum = 177;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (parent._xpnl_panel.getLeft()+parent._xpnl_panel.getWidth()),parent._xpnl_panel.getTop(),parent.__c.DipToCurrent((int) (1)),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 19:
//C
this.state = 30;
 //BA.debugLineNum = 179;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),parent._xpnl_panel.getLeft(),(int) (parent._xpnl_panel.getTop()+parent._xpnl_panel.getHeight()),parent.__c.DipToCurrent((int) (1)),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 21:
//C
this.state = 30;
 //BA.debugLineNum = 181;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (parent._xpnl_panel.getLeft()+parent._xpnl_panel.getWidth()),(int) (parent._xpnl_panel.getTop()+parent._xpnl_panel.getHeight()),parent.__c.DipToCurrent((int) (1)),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 23:
//C
this.state = 30;
 //BA.debugLineNum = 183;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),parent._xpnl_panel.getLeft(),parent._xpnl_panel.getTop(),parent.__c.DipToCurrent((int) (1)),parent._xpnl_panel.getHeight());
 if (true) break;

case 25:
//C
this.state = 30;
 //BA.debugLineNum = 185;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (parent._xpnl_panel.getLeft()+parent._xpnl_panel.getWidth()),parent._xpnl_panel.getTop(),parent.__c.DipToCurrent((int) (1)),parent._xpnl_panel.getHeight());
 if (true) break;

case 27:
//C
this.state = 30;
 //BA.debugLineNum = 187;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),parent._xpnl_panel.getLeft(),parent._xpnl_panel.getTop(),parent._xpnl_panel.getWidth(),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 189;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,xpnl_Pan";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),parent._xpnl_panel.getLeft(),(int) (parent._xpnl_panel.getTop()+parent._xpnl_panel.getHeight()),parent._xpnl_panel.getWidth(),parent.__c.DipToCurrent((int) (1)));
 if (true) break;

case 30:
//C
this.state = -1;
;
 //BA.debugLineNum = 192;BA.debugLine="Sleep(250)";
parent.__c.Sleep(ba,this,(int) (250));
this.state = 31;
return;
case 31:
//C
this.state = -1;
;
 //BA.debugLineNum = 193;BA.debugLine="xpnl_Background.RemoveViewFromParent";
parent._xpnl_background.RemoveViewFromParent();
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties  _createasfloatingpanel_arrowproperties(String _arroworientation,int _color,float _width,float _height,float _left,float _top) throws Exception{
sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties _t1 = null;
 //BA.debugLineNum = 292;BA.debugLine="Public Sub CreateASFloatingPanel_ArrowProperties (";
 //BA.debugLineNum = 293;BA.debugLine="Dim t1 As ASFloatingPanel_ArrowProperties";
_t1 = new sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties();
 //BA.debugLineNum = 294;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 295;BA.debugLine="t1.ArrowOrientation = ArrowOrientation";
_t1.ArrowOrientation /*String*/  = _arroworientation;
 //BA.debugLineNum = 296;BA.debugLine="t1.Color = Color";
_t1.Color /*int*/  = _color;
 //BA.debugLineNum = 297;BA.debugLine="t1.Width = Width";
_t1.Width /*float*/  = _width;
 //BA.debugLineNum = 298;BA.debugLine="t1.Height = Height";
_t1.Height /*float*/  = _height;
 //BA.debugLineNum = 299;BA.debugLine="t1.Left = Left";
_t1.Left /*float*/  = _left;
 //BA.debugLineNum = 300;BA.debugLine="t1.Top = Top";
_t1.Top /*float*/  = _top;
 //BA.debugLineNum = 301;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 302;BA.debugLine="End Sub";
return null;
}
public String  _eventclose() throws Exception{
 //BA.debugLineNum = 284;BA.debugLine="Private Sub EventClose";
 //BA.debugLineNum = 285;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Close\"";
if (_xui.SubExists(ba,_mcallback,_meventname+"_Close",(int) (0))) { 
 //BA.debugLineNum = 286;BA.debugLine="CallSub(mCallBack, mEventName & \"_Close\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Close");
 };
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
return "";
}
public String  _getarroworientation_bottom() throws Exception{
 //BA.debugLineNum = 268;BA.debugLine="Public Sub getArrowOrientation_Bottom As String";
 //BA.debugLineNum = 269;BA.debugLine="Return \"Bottom\"";
if (true) return "Bottom";
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return "";
}
public String  _getarroworientation_left() throws Exception{
 //BA.debugLineNum = 272;BA.debugLine="Public Sub getArrowOrientation_Left As String";
 //BA.debugLineNum = 273;BA.debugLine="Return \"Left\"";
if (true) return "Left";
 //BA.debugLineNum = 274;BA.debugLine="End Sub";
return "";
}
public String  _getarroworientation_right() throws Exception{
 //BA.debugLineNum = 276;BA.debugLine="Public Sub getArrowOrientation_Right As String";
 //BA.debugLineNum = 277;BA.debugLine="Return \"Right\"";
if (true) return "Right";
 //BA.debugLineNum = 278;BA.debugLine="End Sub";
return "";
}
public String  _getarroworientation_top() throws Exception{
 //BA.debugLineNum = 264;BA.debugLine="Public Sub getArrowOrientation_Top As String";
 //BA.debugLineNum = 265;BA.debugLine="Return \"Top\"";
if (true) return "Top";
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties  _getarrowproperties() throws Exception{
 //BA.debugLineNum = 216;BA.debugLine="Public Sub getArrowProperties As ASFloatingPanel_A";
 //BA.debugLineNum = 217;BA.debugLine="Return g_ArrowProperties";
if (true) return _g_arrowproperties;
 //BA.debugLineNum = 218;BA.debugLine="End Sub";
return null;
}
public boolean  _getarrowvisible() throws Exception{
 //BA.debugLineNum = 208;BA.debugLine="Public Sub getArrowVisible As Boolean";
 //BA.debugLineNum = 209;BA.debugLine="Return m_ArrowVisible";
if (true) return _m_arrowvisible;
 //BA.debugLineNum = 210;BA.debugLine="End Sub";
return false;
}
public String  _getopenorientation_bottomtop() throws Exception{
 //BA.debugLineNum = 258;BA.debugLine="Public Sub getOpenOrientation_BottomTop As String";
 //BA.debugLineNum = 259;BA.debugLine="Return \"BottomTop\"";
if (true) return "BottomTop";
 //BA.debugLineNum = 260;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_leftbottom() throws Exception{
 //BA.debugLineNum = 230;BA.debugLine="Public Sub getOpenOrientation_LeftBottom As String";
 //BA.debugLineNum = 231;BA.debugLine="Return \"LeftBottom\"";
if (true) return "LeftBottom";
 //BA.debugLineNum = 232;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_leftright() throws Exception{
 //BA.debugLineNum = 246;BA.debugLine="Public Sub getOpenOrientation_LeftRight As String";
 //BA.debugLineNum = 247;BA.debugLine="Return \"LeftRight\"";
if (true) return "LeftRight";
 //BA.debugLineNum = 248;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_lefttop() throws Exception{
 //BA.debugLineNum = 238;BA.debugLine="Public Sub getOpenOrientation_LeftTop As String";
 //BA.debugLineNum = 239;BA.debugLine="Return \"LeftTop\"";
if (true) return "LeftTop";
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_none() throws Exception{
 //BA.debugLineNum = 226;BA.debugLine="Public Sub getOpenOrientation_None As String";
 //BA.debugLineNum = 227;BA.debugLine="Return \"None\"";
if (true) return "None";
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_rightbottom() throws Exception{
 //BA.debugLineNum = 234;BA.debugLine="Public Sub getOpenOrientation_RightBottom As Strin";
 //BA.debugLineNum = 235;BA.debugLine="Return \"RightBottom\"";
if (true) return "RightBottom";
 //BA.debugLineNum = 236;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_rightleft() throws Exception{
 //BA.debugLineNum = 250;BA.debugLine="Public Sub getOpenOrientation_RightLeft As String";
 //BA.debugLineNum = 251;BA.debugLine="Return \"RightLeft\"";
if (true) return "RightLeft";
 //BA.debugLineNum = 252;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_righttop() throws Exception{
 //BA.debugLineNum = 242;BA.debugLine="Public Sub getOpenOrientation_RightTop As String";
 //BA.debugLineNum = 243;BA.debugLine="Return \"RightTop\"";
if (true) return "RightTop";
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _getopenorientation_topbottom() throws Exception{
 //BA.debugLineNum = 254;BA.debugLine="Public Sub getOpenOrientation_TopBottom As String";
 //BA.debugLineNum = 255;BA.debugLine="Return \"TopBottom\"";
if (true) return "TopBottom";
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getpanel() throws Exception{
 //BA.debugLineNum = 196;BA.debugLine="Public Sub getPanel As B4XView";
 //BA.debugLineNum = 197;BA.debugLine="Return xpnl_Panel";
if (true) return _xpnl_panel;
 //BA.debugLineNum = 198;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname,anywheresoftware.b4a.objects.B4XViewWrapper _parent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 55;BA.debugLine="Public Sub Initialize(Callback As Object, EventNam";
 //BA.debugLineNum = 56;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 57;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 58;BA.debugLine="xpnl_Parent = Parent";
_xpnl_parent = _parent;
 //BA.debugLineNum = 59;BA.debugLine="m_OpenOrientation = getOpenOrientation_LeftBottom";
_m_openorientation = _getopenorientation_leftbottom();
 //BA.debugLineNum = 60;BA.debugLine="m_Duration = 150";
_m_duration = (long) (150);
 //BA.debugLineNum = 61;BA.debugLine="BackgroundColor = xui.Color_ARGB(152,0,0,0)";
_backgroundcolor = _xui.Color_ARGB((int) (152),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 62;BA.debugLine="xpnl_Panel = xui.CreatePanel(\"\")";
_xpnl_panel = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 64;BA.debugLine="g_ArrowProperties = CreateASFloatingPanel_ArrowPr";
_g_arrowproperties = _createasfloatingpanel_arrowproperties(_getarroworientation_top(),_xui.Color_ARGB((int) (255),(int) (32),(int) (33),(int) (37)),(float) (__c.DipToCurrent((int) (20))),(float) (__c.DipToCurrent((int) (10))),(float) (-1),(float) (-1));
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _presize(float _width,float _height) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Public Sub PreSize(Width As Float,Height As Float)";
 //BA.debugLineNum = 68;BA.debugLine="xpnl_Panel.Visible = False";
_xpnl_panel.setVisible(__c.False);
 //BA.debugLineNum = 69;BA.debugLine="xpnl_Panel.SetLayoutAnimated(0,0,0,Width,Height)";
_xpnl_panel.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_width),(int) (_height));
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _setarrowproperties(sadLogic.OctoTouchController.foss.sadas_floatingpanel._asfloatingpanel_arrowproperties _properties) throws Exception{
 //BA.debugLineNum = 220;BA.debugLine="Public Sub setArrowProperties(Properties As ASFloa";
 //BA.debugLineNum = 221;BA.debugLine="g_ArrowProperties = Properties";
_g_arrowproperties = _properties;
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
return "";
}
public String  _setarrowvisible(boolean _visible) throws Exception{
 //BA.debugLineNum = 212;BA.debugLine="Public Sub setArrowVisible(Visible As Boolean)";
 //BA.debugLineNum = 213;BA.debugLine="m_ArrowVisible = Visible";
_m_arrowvisible = _visible;
 //BA.debugLineNum = 214;BA.debugLine="End Sub";
return "";
}
public String  _setduration(long _duration) throws Exception{
 //BA.debugLineNum = 204;BA.debugLine="Public Sub setDuration(Duration As Long)";
 //BA.debugLineNum = 205;BA.debugLine="m_Duration = Duration";
_m_duration = _duration;
 //BA.debugLineNum = 206;BA.debugLine="End Sub";
return "";
}
public String  _setopenorientation(String _orientation) throws Exception{
 //BA.debugLineNum = 200;BA.debugLine="Public Sub setOpenOrientation(Orientation As Strin";
 //BA.debugLineNum = 201;BA.debugLine="m_OpenOrientation = Orientation";
_m_openorientation = _orientation;
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public void  _show(float _left,float _top,float _width,float _height) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_left,_top,_width,_height);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.sadas_floatingpanel parent,float _left,float _top,float _width,float _height) {
this.parent = parent;
this._left = _left;
this._top = _top;
this._width = _width;
this._height = _height;
}
sadLogic.OctoTouchController.foss.sadas_floatingpanel parent;
float _left;
float _top;
float _width;
float _height;
anywheresoftware.b4a.objects.B4XCanvas _xcv = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XPath _p = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 73;BA.debugLine="xpnl_Background = xui.CreatePanel(\"xpnl_Backgroun";
parent._xpnl_background = parent._xui.CreatePanel(ba,"xpnl_Background");
 //BA.debugLineNum = 74;BA.debugLine="xpnl_Parent.AddView(xpnl_Background,0,0,xpnl_Pare";
parent._xpnl_parent.AddView((android.view.View)(parent._xpnl_background.getObject()),(int) (0),(int) (0),parent._xpnl_parent.getWidth(),parent._xpnl_parent.getHeight());
 //BA.debugLineNum = 75;BA.debugLine="xpnl_Background.Color = BackgroundColor";
parent._xpnl_background.setColor(parent._backgroundcolor);
 //BA.debugLineNum = 77;BA.debugLine="xpnl_Panel.RemoveViewFromParent";
parent._xpnl_panel.RemoveViewFromParent();
 //BA.debugLineNum = 78;BA.debugLine="xpnl_Background.AddView(xpnl_Panel,Left,Top,0,0)";
parent._xpnl_background.AddView((android.view.View)(parent._xpnl_panel.getObject()),(int) (_left),(int) (_top),(int) (0),(int) (0));
 //BA.debugLineNum = 80;BA.debugLine="If m_OpenOrientation = getOpenOrientation_LeftBot";
if (true) break;

case 1:
//if
this.state = 20;
if ((parent._m_openorientation).equals(parent._getopenorientation_leftbottom())) { 
this.state = 3;
}else if((parent._m_openorientation).equals(parent._getopenorientation_rightbottom())) { 
this.state = 5;
}else if((parent._m_openorientation).equals(parent._getopenorientation_none())) { 
this.state = 7;
}else if((parent._m_openorientation).equals(parent._getopenorientation_lefttop())) { 
this.state = 9;
}else if((parent._m_openorientation).equals(parent._getopenorientation_righttop())) { 
this.state = 11;
}else if((parent._m_openorientation).equals(parent._getopenorientation_leftright())) { 
this.state = 13;
}else if((parent._m_openorientation).equals(parent._getopenorientation_rightleft())) { 
this.state = 15;
}else if((parent._m_openorientation).equals(parent._getopenorientation_topbottom())) { 
this.state = 17;
}else if((parent._m_openorientation).equals(parent._getopenorientation_bottomtop())) { 
this.state = 19;
}if (true) break;

case 3:
//C
this.state = 20;
 //BA.debugLineNum = 81;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 5:
//C
this.state = 20;
 //BA.debugLineNum = 83;BA.debugLine="xpnl_Panel.Left = xpnl_Panel.Left + Width";
parent._xpnl_panel.setLeft((int) (parent._xpnl_panel.getLeft()+_width));
 //BA.debugLineNum = 84;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 7:
//C
this.state = 20;
 //BA.debugLineNum = 86;BA.debugLine="xpnl_Panel.SetLayoutAnimated(0,Left,Top,Width,He";
parent._xpnl_panel.SetLayoutAnimated((int) (0),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 9:
//C
this.state = 20;
 //BA.debugLineNum = 88;BA.debugLine="xpnl_Panel.Top = Top + Height";
parent._xpnl_panel.setTop((int) (_top+_height));
 //BA.debugLineNum = 89;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 11:
//C
this.state = 20;
 //BA.debugLineNum = 91;BA.debugLine="xpnl_Panel.Top = Top + Height";
parent._xpnl_panel.setTop((int) (_top+_height));
 //BA.debugLineNum = 92;BA.debugLine="xpnl_Panel.Left = Left + Width";
parent._xpnl_panel.setLeft((int) (_left+_width));
 //BA.debugLineNum = 93;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 13:
//C
this.state = 20;
 //BA.debugLineNum = 95;BA.debugLine="xpnl_Panel.Top = Top";
parent._xpnl_panel.setTop((int) (_top));
 //BA.debugLineNum = 96;BA.debugLine="xpnl_Panel.Height = Height";
parent._xpnl_panel.setHeight((int) (_height));
 //BA.debugLineNum = 97;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 15:
//C
this.state = 20;
 //BA.debugLineNum = 99;BA.debugLine="xpnl_Panel.Top = Top";
parent._xpnl_panel.setTop((int) (_top));
 //BA.debugLineNum = 100;BA.debugLine="xpnl_Panel.Left = Left + Width";
parent._xpnl_panel.setLeft((int) (_left+_width));
 //BA.debugLineNum = 101;BA.debugLine="xpnl_Panel.Height = Height";
parent._xpnl_panel.setHeight((int) (_height));
 //BA.debugLineNum = 102;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 17:
//C
this.state = 20;
 //BA.debugLineNum = 104;BA.debugLine="xpnl_Panel.Top = Top";
parent._xpnl_panel.setTop((int) (_top));
 //BA.debugLineNum = 105;BA.debugLine="xpnl_Panel.Width = Width";
parent._xpnl_panel.setWidth((int) (_width));
 //BA.debugLineNum = 106;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 108;BA.debugLine="xpnl_Panel.Top = Top + Height";
parent._xpnl_panel.setTop((int) (_top+_height));
 //BA.debugLineNum = 109;BA.debugLine="xpnl_Panel.Width = Width";
parent._xpnl_panel.setWidth((int) (_width));
 //BA.debugLineNum = 110;BA.debugLine="xpnl_Panel.SetLayoutAnimated(m_Duration,Left,Top";
parent._xpnl_panel.SetLayoutAnimated((int) (parent._m_duration),(int) (_left),(int) (_top),(int) (_width),(int) (_height));
 if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 113;BA.debugLine="xpnl_Panel.SetColorAndBorder(xui.Color_ARGB(255,3";
parent._xpnl_panel.SetColorAndBorder(parent._xui.Color_ARGB((int) (255),(int) (32),(int) (33),(int) (37)),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (10)));
 //BA.debugLineNum = 114;BA.debugLine="xpnl_Panel.Visible = True";
parent._xpnl_panel.setVisible(parent.__c.True);
 //BA.debugLineNum = 116;BA.debugLine="Sleep(m_Duration)";
parent.__c.Sleep(ba,this,(int) (parent._m_duration));
this.state = 35;
return;
case 35:
//C
this.state = 21;
;
 //BA.debugLineNum = 118;BA.debugLine="If m_ArrowVisible Then";
if (true) break;

case 21:
//if
this.state = 34;
if (parent._m_arrowvisible) { 
this.state = 23;
}if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 120;BA.debugLine="xpnl_Arrow = xui.CreatePanel(\"\")";
parent._xpnl_arrow = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 121;BA.debugLine="xpnl_Arrow.Color = xui.Color_Transparent";
parent._xpnl_arrow.setColor(parent._xui.Color_Transparent);
 //BA.debugLineNum = 122;BA.debugLine="xpnl_Background.AddView(xpnl_Arrow,xpnl_Panel.Le";
parent._xpnl_background.AddView((android.view.View)(parent._xpnl_arrow.getObject()),(int) (parent._xpnl_panel.getLeft()+parent._g_arrowproperties.Width /*float*/ ),(int) (parent._xpnl_panel.getTop()-parent._g_arrowproperties.Height /*float*/ ),(int) (parent._g_arrowproperties.Width /*float*/ ),(int) (parent._g_arrowproperties.Height /*float*/ ));
 //BA.debugLineNum = 124;BA.debugLine="Dim xCV As B4XCanvas";
_xcv = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 125;BA.debugLine="xCV.Initialize(xpnl_Arrow)";
_xcv.Initialize(parent._xpnl_arrow);
 //BA.debugLineNum = 127;BA.debugLine="xCV.ClearRect(xCV.TargetRect)";
_xcv.ClearRect(_xcv.getTargetRect());
 //BA.debugLineNum = 128;BA.debugLine="Dim p As B4XPath";
_p = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 130;BA.debugLine="Select g_ArrowProperties.ArrowOrientation";
if (true) break;

case 24:
//select
this.state = 33;
switch (BA.switchObjectToInt(parent._g_arrowproperties.ArrowOrientation /*String*/ ,parent._getarroworientation_top(),parent._getarroworientation_bottom(),parent._getarroworientation_right(),parent._getarroworientation_left())) {
case 0: {
this.state = 26;
if (true) break;
}
case 1: {
this.state = 28;
if (true) break;
}
case 2: {
this.state = 30;
if (true) break;
}
case 3: {
this.state = 32;
if (true) break;
}
}
if (true) break;

case 26:
//C
this.state = 33;
 //BA.debugLineNum = 134;BA.debugLine="p.Initialize(xpnl_Arrow.Width/2,0).LineTo(0,xp";
_p.Initialize((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0)).LineTo((float) (0),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0));
 //BA.debugLineNum = 136;BA.debugLine="xpnl_Arrow.SetLayoutAnimated(0,xpnl_Panel.Left";
parent._xpnl_arrow.SetLayoutAnimated((int) (0),(int) (parent._xpnl_panel.getLeft()+parent._g_arrowproperties.Left /*float*/ ),(int) (parent._xpnl_panel.getTop()-parent._g_arrowproperties.Height /*float*/ +parent._g_arrowproperties.Top /*float*/ ),(int) (parent._g_arrowproperties.Width /*float*/ ),(int) (parent._g_arrowproperties.Height /*float*/ ));
 if (true) break;

case 28:
//C
this.state = 33;
 //BA.debugLineNum = 138;BA.debugLine="p.Initialize(0, 0).LineTo(xpnl_Arrow.Width, 0)";
_p.Initialize((float) (0),(float) (0)).LineTo((float) (parent._xpnl_arrow.getWidth()),(float) (0)).LineTo((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (0),(float) (0));
 //BA.debugLineNum = 139;BA.debugLine="xpnl_Arrow.SetLayoutAnimated(0,xpnl_Panel.Left";
parent._xpnl_arrow.SetLayoutAnimated((int) (0),(int) (parent._xpnl_panel.getLeft()+parent._g_arrowproperties.Left /*float*/ ),(int) (parent._xpnl_panel.getTop()+parent._xpnl_panel.getHeight()),(int) (parent._g_arrowproperties.Width /*float*/ ),(int) (parent._g_arrowproperties.Height /*float*/ ));
 if (true) break;

case 30:
//C
this.state = 33;
 //BA.debugLineNum = 141;BA.debugLine="p.Initialize(xpnl_Arrow.Width/2,0).LineTo(0,xp";
_p.Initialize((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0)).LineTo((float) (0),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0));
 //BA.debugLineNum = 142;BA.debugLine="xpnl_Arrow.SetLayoutAnimated(0,xpnl_Panel.Left";
parent._xpnl_arrow.SetLayoutAnimated((int) (0),(int) (parent._xpnl_panel.getLeft()+parent._xpnl_panel.getWidth()-parent._g_arrowproperties.Height /*float*/ /(double)2),(int) (parent._xpnl_panel.getTop()+parent._g_arrowproperties.Top /*float*/ ),(int) (parent._g_arrowproperties.Width /*float*/ ),(int) (parent._g_arrowproperties.Height /*float*/ ));
 //BA.debugLineNum = 143;BA.debugLine="xpnl_Arrow.Rotation = 90";
parent._xpnl_arrow.setRotation((float) (90));
 if (true) break;

case 32:
//C
this.state = 33;
 //BA.debugLineNum = 146;BA.debugLine="p.Initialize(xpnl_Arrow.Width/2,0).LineTo(0,xp";
_p.Initialize((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0)).LineTo((float) (0),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()),(float) (parent._xpnl_arrow.getHeight())).LineTo((float) (parent._xpnl_arrow.getWidth()/(double)2),(float) (0));
 //BA.debugLineNum = 147;BA.debugLine="xpnl_Arrow.SetLayoutAnimated(0,xpnl_Panel.Left";
parent._xpnl_arrow.SetLayoutAnimated((int) (0),(int) (parent._xpnl_panel.getLeft()-parent._g_arrowproperties.Width /*float*/ +parent._g_arrowproperties.Height /*float*/ /(double)2),(int) (parent._xpnl_panel.getTop()+parent._g_arrowproperties.Top /*float*/ ),(int) (parent._g_arrowproperties.Width /*float*/ ),(int) (parent._g_arrowproperties.Height /*float*/ ));
 //BA.debugLineNum = 148;BA.debugLine="xpnl_Arrow.Rotation = -90";
parent._xpnl_arrow.setRotation((float) (-90));
 if (true) break;

case 33:
//C
this.state = 34;
;
 //BA.debugLineNum = 151;BA.debugLine="xCV.DrawPath(p, g_ArrowProperties.Color, True, 0";
_xcv.DrawPath(_p,parent._g_arrowproperties.Color /*int*/ ,parent.__c.True,(float) (0));
 //BA.debugLineNum = 152;BA.debugLine="xCV.Invalidate";
_xcv.Invalidate();
 if (true) break;

case 34:
//C
this.state = -1;
;
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _xpnl_background_click() throws Exception{
 //BA.debugLineNum = 163;BA.debugLine="Private Sub xpnl_Background_Click";
 //BA.debugLineNum = 165;BA.debugLine="Close";
_close();
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "GETPANEL"))
	return _getpanel();
return BA.SubDelegator.SubNotFound;
}
}
