package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dthelpers {
private static dthelpers mostCurrent = new dthelpers();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public static String  _changetime12to24hours(anywheresoftware.b4a.BA _ba,String _s) throws Exception{
String _ret = "";
float _f1 = 0f;
String _f2 = "";
 //BA.debugLineNum = 168;BA.debugLine="Public Sub ChangeTime12To24Hours(s As String) As S";
 //BA.debugLineNum = 169;BA.debugLine="Try";
try { //BA.debugLineNum = 185;BA.debugLine="s = s.Replace(\":\",\".\").Replace(\" \",\"\") '--- remo";
_s = _s.replace(":",".").replace(" ","");
 //BA.debugLineNum = 186;BA.debugLine="Dim ret As String";
_ret = "";
 //BA.debugLineNum = 188;BA.debugLine="If s.Contains(\"AM\") Or s.Contains(\"am\") Then";
if (_s.contains("AM") || _s.contains("am")) { 
 //BA.debugLineNum = 189;BA.debugLine="Return s.Replace(\"AM\",\"\").Replace(\"am\",\"\").Trim";
if (true) return _s.replace("AM","").replace("am","").trim();
 }else {
 //BA.debugLineNum = 191;BA.debugLine="ret = s.Replace(\"PM\",\"\").Replace(\"pm\",\"\").Trim";
_ret = _s.replace("PM","").replace("pm","").trim();
 //BA.debugLineNum = 192;BA.debugLine="Dim f1 As Float = 12 + ret";
_f1 = (float) (12+(double)(Double.parseDouble(_ret)));
 //BA.debugLineNum = 193;BA.debugLine="Dim f2 As String = Round2(f1,2)";
_f2 = BA.NumberToString(anywheresoftware.b4a.keywords.Common.Round2(_f1,(int) (2)));
 //BA.debugLineNum = 194;BA.debugLine="If f2.Length = 4 Then f2 = f2 & \"0\"";
if (_f2.length()==4) { 
_f2 = _f2+"0";};
 //BA.debugLineNum = 195;BA.debugLine="Return f2";
if (true) return _f2;
 };
 } 
       catch (Exception e14) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e14); //BA.debugLineNum = 199;BA.debugLine="Return \"12:00\"";
if (true) return "12:00";
 };
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
return "";
}
public static String  _changetime12to24hours2(anywheresoftware.b4a.BA _ba,String _a) throws Exception{
long _b = 0L;
 //BA.debugLineNum = 152;BA.debugLine="Public Sub ChangeTime12To24Hours2(a As String) As";
 //BA.debugLineNum = 153;BA.debugLine="Try";
try { //BA.debugLineNum = 155;BA.debugLine="a = a.ToUpperCase.replace(\"PM\",\" PM\").Replace(\"A";
_a = _a.toUpperCase().replace("PM"," PM").replace("AM"," AM");
 //BA.debugLineNum = 156;BA.debugLine="DateTime.TimeFormat = \"hh:mm a\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("hh:mm a");
 //BA.debugLineNum = 157;BA.debugLine="Dim b As Long = DateTime.TimeParse(a)";
_b = anywheresoftware.b4a.keywords.Common.DateTime.TimeParse(_a);
 //BA.debugLineNum = 159;BA.debugLine="Return  FormatTime( \"k:mm\",b)";
if (true) return _formattime(_ba,"k:mm",(int) (_b));
 } 
       catch (Exception e7) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e7); //BA.debugLineNum = 161;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("26411017",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 //BA.debugLineNum = 163;BA.debugLine="Return \"12:00\"";
if (true) return "12:00";
 };
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static long  _changetime12to24hours3(anywheresoftware.b4a.BA _ba,String _a) throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Public Sub ChangeTime12To24Hours3(a As String) As";
 //BA.debugLineNum = 134;BA.debugLine="Try";
try { //BA.debugLineNum = 136;BA.debugLine="a = a.ToUpperCase.replace(\"PM\",\" PM\").Replace(\"A";
_a = _a.toUpperCase().replace("PM"," PM").replace("AM"," AM");
 //BA.debugLineNum = 137;BA.debugLine="DateTime.TimeFormat = \"h:mm a\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("h:mm a");
 //BA.debugLineNum = 138;BA.debugLine="Return DateTime.TimeParse(a)";
if (true) return anywheresoftware.b4a.keywords.Common.DateTime.TimeParse(_a);
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 140;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("26345479",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 //BA.debugLineNum = 142;BA.debugLine="Return \"12:00\"";
if (true) return (long)(Double.parseDouble("12:00"));
 };
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return 0L;
}
public static String  _formattime(anywheresoftware.b4a.BA _ba,String _mask,int _ticks) throws Exception{
String _ret = "";
String _fmtd = "";
String _fmtt = "";
 //BA.debugLineNum = 116;BA.debugLine="Public Sub FormatTime(mask As String,ticks As Int)";
 //BA.debugLineNum = 117;BA.debugLine="Dim ret As String";
_ret = "";
 //BA.debugLineNum = 118;BA.debugLine="Dim fmtD As String = DateTime.DateFormat";
_fmtd = anywheresoftware.b4a.keywords.Common.DateTime.getDateFormat();
 //BA.debugLineNum = 119;BA.debugLine="Dim fmtT As String = DateTime.TimeFormat";
_fmtt = anywheresoftware.b4a.keywords.Common.DateTime.getTimeFormat();
 //BA.debugLineNum = 120;BA.debugLine="DateTime.TimeFormat = mask";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat(_mask);
 //BA.debugLineNum = 121;BA.debugLine="DateTime.DateFormat = \"\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("");
 //BA.debugLineNum = 123;BA.debugLine="ret = DateUtils.TicksToString(ticks)";
_ret = mostCurrent._dateutils._tickstostring(_ba,(long) (_ticks));
 //BA.debugLineNum = 125;BA.debugLine="DateTime.TimeFormat = fmtT";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat(_fmtt);
 //BA.debugLineNum = 126;BA.debugLine="DateTime.DateFormat = fmtD";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat(_fmtd);
 //BA.debugLineNum = 127;BA.debugLine="Return ret";
if (true) return _ret;
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public static long  _getlastdayofmonth(anywheresoftware.b4a.BA _ba,long _thisdate) throws Exception{
int _dayofmonth = 0;
long _firstdayofmonth = 0L;
long _lastdayofmonth = 0L;
 //BA.debugLineNum = 69;BA.debugLine="Public Sub GetLastDayOfMonth(thisDate As Long) As";
 //BA.debugLineNum = 71;BA.debugLine="Dim DayOfMonth As Int = DateTime.GetDayOfMonth(th";
_dayofmonth = anywheresoftware.b4a.keywords.Common.DateTime.GetDayOfMonth(_thisdate);
 //BA.debugLineNum = 72;BA.debugLine="Dim FirstDayOfMonth As Long = DateTime.Add(thisDa";
_firstdayofmonth = anywheresoftware.b4a.keywords.Common.DateTime.Add(_thisdate,(int) (0),(int) (0),(int) ((_dayofmonth*-1)+1));
 //BA.debugLineNum = 73;BA.debugLine="Dim LastDayOfMonth As Long = DateTime.Add(FirstDa";
_lastdayofmonth = anywheresoftware.b4a.keywords.Common.DateTime.Add(_firstdayofmonth,(int) (0),(int) (1),(int) (-1));
 //BA.debugLineNum = 75;BA.debugLine="Return LastDayOfMonth";
if (true) return _lastdayofmonth;
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return 0L;
}
public static int  _hoursbetween(anywheresoftware.b4a.BA _ba,long _d1,long _d2) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Public Sub HoursBetween(d1 As Long, d2 As Long) As";
 //BA.debugLineNum = 66;BA.debugLine="Return ((d1 - d2) / DateTime.TicksPerHour)";
if (true) return (int) (((_d1-_d2)/(double)anywheresoftware.b4a.keywords.Common.DateTime.TicksPerHour));
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return 0;
}
public static boolean  _isitdaytime(anywheresoftware.b4a.BA _ba,String _sunrise,String _sunset,String _citylocaltime) throws Exception{
float _sunrise1 = 0f;
float _sunset1 = 0f;
float _curtime = 0f;
String _tmpcur = "";
String _tmpsunset = "";
String _tmpsunrise = "";
 //BA.debugLineNum = 80;BA.debugLine="Public Sub IsItDayTime(sunrise As String, sunset A";
 //BA.debugLineNum = 83;BA.debugLine="Try";
try { //BA.debugLineNum = 86;BA.debugLine="Dim sunrise1,sunset1,curTime As Float";
_sunrise1 = 0f;
_sunset1 = 0f;
_curtime = 0f;
 //BA.debugLineNum = 87;BA.debugLine="CityLocalTime = CityLocalTime.SubString(10).trim";
_citylocaltime = _citylocaltime.substring((int) (10)).trim();
 //BA.debugLineNum = 88;BA.debugLine="Log(CityLocalTime)";
anywheresoftware.b4a.keywords.Common.LogImpl("26214408",_citylocaltime,0);
 //BA.debugLineNum = 90;BA.debugLine="DateTime.TimeFormat = \"H:mm\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("H:mm");
 //BA.debugLineNum = 91;BA.debugLine="Dim tmpCur As String = DateTime.Time(DateTime.Tim";
_tmpcur = anywheresoftware.b4a.keywords.Common.DateTime.Time(anywheresoftware.b4a.keywords.Common.DateTime.TimeParse(_citylocaltime));
 //BA.debugLineNum = 92;BA.debugLine="Dim tmpSunset As String = ChangeTime12To24Hours(s";
_tmpsunset = _changetime12to24hours(_ba,_sunset);
 //BA.debugLineNum = 93;BA.debugLine="Dim tmpSunrise As String = ChangeTime12To24Hours(";
_tmpsunrise = _changetime12to24hours(_ba,_sunrise);
 //BA.debugLineNum = 95;BA.debugLine="sunrise1 = tmpSunrise.Replace(\":\",\".\")";
_sunrise1 = (float)(Double.parseDouble(_tmpsunrise.replace(":",".")));
 //BA.debugLineNum = 96;BA.debugLine="sunset1 = tmpSunset.Replace(\":\",\".\")";
_sunset1 = (float)(Double.parseDouble(_tmpsunset.replace(":",".")));
 //BA.debugLineNum = 97;BA.debugLine="curTime = tmpCur.Replace(\":\",\".\")";
_curtime = (float)(Double.parseDouble(_tmpcur.replace(":",".")));
 //BA.debugLineNum = 101;BA.debugLine="If curTime > (sunrise1 + .5) And curTime < (sunse";
if (_curtime>(_sunrise1+.5) && _curtime<(_sunset1+1)) { 
 //BA.debugLineNum = 102;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 104;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 } 
       catch (Exception e18) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e18); //BA.debugLineNum = 109;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("26214429",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 //BA.debugLineNum = 110;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return false;
}
public static boolean  _istimebetween(anywheresoftware.b4a.BA _ba,long _currenttime,long _starttime,long _endtime) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="public Sub IsTimeBetween(CurrentTime As Long, Star";
 //BA.debugLineNum = 25;BA.debugLine="If StartTime <= EndTime Then";
if (_starttime<=_endtime) { 
 //BA.debugLineNum = 28;BA.debugLine="If CurrentTime >= StartTime And CurrentTime <= E";
if (_currenttime>=_starttime && _currenttime<=_endtime) { 
 //BA.debugLineNum = 29;BA.debugLine="Log(\"before midnight: Time is in range.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("25952261","before midnight: Time is in range.",0);
 //BA.debugLineNum = 30;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 32;BA.debugLine="Log(\"before midnight: Time is outside range.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("25952264","before midnight: Time is outside range.",0);
 //BA.debugLineNum = 33;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 }else {
 //BA.debugLineNum = 38;BA.debugLine="If CurrentTime >= StartTime Or CurrentTime <= En";
if (_currenttime>=_starttime || _currenttime<=_endtime) { 
 //BA.debugLineNum = 39;BA.debugLine="Log(\"after midnight: Time is in range.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("25952271","after midnight: Time is in range.",0);
 //BA.debugLineNum = 40;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 42;BA.debugLine="Log(\"after midnight: Time is outside range.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("25952274","after midnight: Time is outside range.",0);
 //BA.debugLineNum = 43;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 };
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 16;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public static String  _returndayext(anywheresoftware.b4a.BA _ba,int _n) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Public Sub ReturnDayExt(n As Int) As String";
 //BA.debugLineNum = 56;BA.debugLine="Select Case n";
switch (_n) {
case 1: {
 //BA.debugLineNum = 57;BA.debugLine="Case 1 : Return n & \"st\"";
if (true) return BA.NumberToString(_n)+"st";
 break; }
case 2: {
 //BA.debugLineNum = 58;BA.debugLine="Case 2 : Return n & \"nd\"";
if (true) return BA.NumberToString(_n)+"nd";
 break; }
case 3: {
 //BA.debugLineNum = 59;BA.debugLine="Case 3 : Return n & \"rd\"";
if (true) return BA.NumberToString(_n)+"rd";
 break; }
}
;
 //BA.debugLineNum = 62;BA.debugLine="Return n & \"th\"";
if (true) return BA.NumberToString(_n)+"th";
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static long  _strtime2ticks(anywheresoftware.b4a.BA _ba,String _hours,String _minutes) throws Exception{
 //BA.debugLineNum = 20;BA.debugLine="Public Sub StrTime2Ticks(hours As String, minutes";
 //BA.debugLineNum = 21;BA.debugLine="Return (hours * DateTime.TicksPerHour) + (minutes";
if (true) return (long) (((double)(Double.parseDouble(_hours))*anywheresoftware.b4a.keywords.Common.DateTime.TicksPerHour)+((double)(Double.parseDouble(_minutes))*anywheresoftware.b4a.keywords.Common.DateTime.TicksPerMinute));
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return 0L;
}
}
