package sadLogic.OctoTouchController.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_pagemovement{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _wd="";
String _qu="";
String _pad="";
String _btnsizew="";
String _btnsizeh="";
String _ms="";
String _h1="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlcenter").vw.setLeft((int)(0d));
views.get("pnlcenter").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlcenter").vw.setTop((int)(0d));
views.get("pnlcenter").vw.setHeight((int)((100d / 100 * height) - (0d)));
if ((BA.ObjectToBoolean( String.valueOf(!anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
_wd = ".64";
views.get("pnljogmovement").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnljogmovement").vw.setWidth((int)((views.get("pnlcenter").vw.getWidth())*Double.parseDouble(_wd) - ((views.get("pnlcenter").vw.getLeft()))));
views.get("pnljogmovement").vw.setTop((int)(0d));
views.get("pnljogmovement").vw.setHeight((int)((views.get("pnlcenter").vw.getHeight()) - (0d)));
views.get("pnljogmovementheader").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnljogmovementheader").vw.setWidth((int)((views.get("pnlcenter").vw.getWidth())*Double.parseDouble(_wd) - ((views.get("pnlcenter").vw.getLeft()))));
views.get("pnljogmovementheader").vw.setTop((int)(0d));
views.get("pnljogmovementheader").vw.setHeight((int)((views.get("pnljogmovement").vw.getHeight())*.13d - (0d)));
views.get("pnljogmovement1").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement1").vw.setHeight((int)((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
views.get("pnljogmovement2").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement2").vw.setHeight((int)((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
views.get("pnljogmovement3").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement3").vw.setHeight((int)((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
views.get("pnljogmovementz").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovementz").vw.setHeight((int)((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
_qu = BA.NumberToString((views.get("pnljogmovement").vw.getWidth())/4d);
views.get("pnljogmovement1").vw.setLeft((int)(0d));
views.get("pnljogmovement1").vw.setWidth((int)(Double.parseDouble(_qu) - (0d)));
views.get("pnljogmovement2").vw.setLeft((int)(Double.parseDouble(_qu)));
views.get("pnljogmovement2").vw.setWidth((int)(Double.parseDouble(_qu)*2d - (Double.parseDouble(_qu))));
views.get("pnljogmovement3").vw.setLeft((int)(Double.parseDouble(_qu)*2d));
views.get("pnljogmovement3").vw.setWidth((int)(Double.parseDouble(_qu)*3d - (Double.parseDouble(_qu)*2d)));
views.get("pnljogmovementz").vw.setLeft((int)(Double.parseDouble(_qu)*3d));
views.get("pnljogmovementz").vw.setWidth((int)(Double.parseDouble(_qu)*4d - (Double.parseDouble(_qu)*3d)));
views.get("lblheaderxy").vw.setTop((int)(0d));
views.get("lblheaderxy").vw.setHeight((int)((views.get("pnljogmovementheader").vw.getHeight()) - (0d)));
views.get("lblheaderz").vw.setTop((int)(0d));
views.get("lblheaderz").vw.setHeight((int)((views.get("pnljogmovementheader").vw.getHeight()) - (0d)));
views.get("lblheaderxy").vw.setLeft((int)(0d));
views.get("lblheaderxy").vw.setWidth((int)(Double.parseDouble(_qu)*3d - (0d)));
views.get("lblheaderz").vw.setLeft((int)(Double.parseDouble(_qu)*3d));
views.get("lblheaderz").vw.setWidth((int)((views.get("pnljogmovementheader").vw.getLeft() + views.get("pnljogmovementheader").vw.getWidth()) - (Double.parseDouble(_qu)*3d)));
_pad = BA.NumberToString((8d * scale));
views.get("pnlgeneral").vw.setLeft((int)((views.get("pnljogmovement").vw.getLeft() + views.get("pnljogmovement").vw.getWidth())+Double.parseDouble(_pad)));
views.get("pnlgeneral").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnljogmovement").vw.getLeft() + views.get("pnljogmovement").vw.getWidth())+Double.parseDouble(_pad))));
views.get("pnlgeneral").vw.setTop((int)(0d));
views.get("pnlgeneral").vw.setHeight((int)((views.get("pnlcenter").vw.getHeight()) - (0d)));
views.get("lblgeneral").vw.setLeft((int)(0d));
views.get("lblgeneral").vw.setWidth((int)((views.get("pnlgeneral").vw.getWidth()) - (0d)));
views.get("lblgeneral").vw.setTop((int)(0d));
views.get("lblgeneral").vw.setHeight((int)((views.get("pnlgeneral").vw.getHeight())*.13d - (0d)));
views.get("pnlgeneral1").vw.setLeft((int)(0d));
views.get("pnlgeneral1").vw.setWidth((int)((views.get("pnlgeneral").vw.getWidth())/2d - (0d)));
views.get("pnlgeneral1").vw.setTop((int)((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight())));
views.get("pnlgeneral1").vw.setHeight((int)((views.get("pnlgeneral").vw.getTop() + views.get("pnlgeneral").vw.getHeight()) - ((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight()))));
views.get("pnlgeneral2").vw.setLeft((int)((views.get("pnlgeneral").vw.getWidth())/2d));
views.get("pnlgeneral2").vw.setWidth((int)((views.get("pnlgeneral").vw.getLeft() + views.get("pnlgeneral").vw.getWidth()) - ((views.get("pnlgeneral").vw.getWidth())/2d)));
views.get("pnlgeneral2").vw.setTop((int)((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight())));
views.get("pnlgeneral2").vw.setHeight((int)((views.get("pnlgeneral").vw.getTop() + views.get("pnlgeneral").vw.getHeight()) - ((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight()))));
_btnsizew = BA.NumberToString(Math.max((80d * scale),(views.get("pnljogmovement1").vw.getWidth())-(20d * scale)));
_btnsizeh = BA.NumberToString(Math.max((80d * scale),(views.get("pnlgeneral1").vw.getHeight())/3d-(20d * scale)));
views.get("btnfn").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnmoff").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnheat").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnfn").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnmoff").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnheat").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnfn").vw.setLeft((int)(((views.get("pnlgeneral1").vw.getWidth())/2d) - (views.get("btnfn").vw.getWidth() / 2)));
views.get("btnmoff").vw.setLeft((int)(((views.get("pnlgeneral1").vw.getWidth())/2d) - (views.get("btnmoff").vw.getWidth() / 2)));
views.get("btnheat").vw.setLeft((int)(((views.get("pnlgeneral1").vw.getWidth())/2d) - (views.get("btnheat").vw.getWidth() / 2)));
views.get("btnextrude").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnretract").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnlength").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
views.get("btnextrude").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnretract").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnlength").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnextrude").vw.setLeft((int)((views.get("pnlgeneral1").vw.getWidth())/2d - (views.get("btnextrude").vw.getWidth() / 2)));
views.get("btnlength").vw.setLeft((int)((views.get("pnlgeneral1").vw.getWidth())/2d - (views.get("btnlength").vw.getWidth() / 2)));
views.get("btnretract").vw.setLeft((int)((views.get("pnlgeneral1").vw.getWidth())/2d - (views.get("btnretract").vw.getWidth() / 2)));
_ms = BA.NumberToString(((views.get("pnlgeneral2").vw.getHeight())/3d)-(10d * scale));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnlgeneral2", _ms, BA.NumberToString((2d * scale)), "center"});
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnlgeneral1", _ms, BA.NumberToString((2d * scale)), "center"});
_btnsizew = BA.NumberToString(Math.max((80d * scale),(views.get("pnljogmovement1").vw.getWidth())-(20d * scale)));
views.get("btnxyback").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnxyhome").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnxyforward").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnxyback").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnxyback").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyback").vw.getWidth() / 2)));
views.get("btnxyhome").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnxyhome").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyhome").vw.getWidth() / 2)));
views.get("btnxyforward").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnxyforward").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyforward").vw.getWidth() / 2)));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnljogmovement2", _ms, BA.NumberToString((2d * scale)), "center"});
views.get("btnxyleft").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnxyright").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnxyleft").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnxyleft").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyleft").vw.getWidth() / 2)));
views.get("btnxyright").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnxyright").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyright").vw.getWidth() / 2)));
views.get("btnzup").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnzhome").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnzdown").vw.setHeight((int)((views.get("btnextrude").vw.getHeight())));
views.get("btnzup").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnzup").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzup").vw.getWidth() / 2)));
views.get("btnzhome").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnzhome").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzhome").vw.getWidth() / 2)));
views.get("btnzdown").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
views.get("btnzdown").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzdown").vw.getWidth() / 2)));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnljogmovementz", _ms, BA.NumberToString((2d * scale)), "center"});
views.get("lblmovepopup").vw.setLeft((int)((2d * scale)));
views.get("lblmovepopup").vw.setWidth((int)((views.get("pnljogmovement1").vw.getLeft() + views.get("pnljogmovement1").vw.getWidth()) - ((2d * scale))));
;}else{ 
;
views.get("pnljogmovement").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnljogmovement").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 83;BA.debugLine="pnlJogMovement.SetTopAndBottom(0,pnlCenter.Height  * .5)"[pageMovement/General script]
views.get("pnljogmovement").vw.setTop((int)(0d));
views.get("pnljogmovement").vw.setHeight((int)((views.get("pnlcenter").vw.getHeight())*.5d - (0d)));
//BA.debugLineNum = 86;BA.debugLine="pnlGeneral.SetLeftAndRight(pnlCenter.Left,pnlCenter.Right)"[pageMovement/General script]
views.get("pnlgeneral").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnlgeneral").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 87;BA.debugLine="pnlGeneral.SetTopAndBottom(pnlJogMovement.Bottom,pnlCenter.Bottom)"[pageMovement/General script]
views.get("pnlgeneral").vw.setTop((int)((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight())));
views.get("pnlgeneral").vw.setHeight((int)((views.get("pnlcenter").vw.getTop() + views.get("pnlcenter").vw.getHeight()) - ((views.get("pnljogmovement").vw.getTop() + views.get("pnljogmovement").vw.getHeight()))));
//BA.debugLineNum = 88;BA.debugLine="lblGeneral.SetLeftAndRight(pnlCenter.Left,pnlCenter.Right)"[pageMovement/General script]
views.get("lblgeneral").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("lblgeneral").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 89;BA.debugLine="lblGeneral.SetTopAndBottom(0,pnlGeneral.Height * .13)"[pageMovement/General script]
views.get("lblgeneral").vw.setTop((int)(0d));
views.get("lblgeneral").vw.setHeight((int)((views.get("pnlgeneral").vw.getHeight())*.13d - (0d)));
//BA.debugLineNum = 91;BA.debugLine="pnlGeneral1.SetLeftAndRight(pnlCenter.Left,pnlCenter.Right)"[pageMovement/General script]
views.get("pnlgeneral1").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnlgeneral1").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 92;BA.debugLine="pnlGeneral2.SetLeftAndRight(pnlCenter.Left,pnlCenter.Right)"[pageMovement/General script]
views.get("pnlgeneral2").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnlgeneral2").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 94;BA.debugLine="h1 = (pnlGeneral.Height / 2) +  (lblGeneral.Height/2)"[pageMovement/General script]
_h1 = BA.NumberToString(((views.get("pnlgeneral").vw.getHeight())/2d)+((views.get("lblgeneral").vw.getHeight())/2d));
//BA.debugLineNum = 95;BA.debugLine="pnlGeneral1.SetTopAndBottom(lblGeneral.Bottom,h1)"[pageMovement/General script]
views.get("pnlgeneral1").vw.setTop((int)((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight())));
views.get("pnlgeneral1").vw.setHeight((int)(Double.parseDouble(_h1) - ((views.get("lblgeneral").vw.getTop() + views.get("lblgeneral").vw.getHeight()))));
//BA.debugLineNum = 96;BA.debugLine="pnlGeneral2.SetTopAndBottom(pnlGeneral1.Bottom,pnlGeneral.Height)"[pageMovement/General script]
views.get("pnlgeneral2").vw.setTop((int)((views.get("pnlgeneral1").vw.getTop() + views.get("pnlgeneral1").vw.getHeight())));
views.get("pnlgeneral2").vw.setHeight((int)((views.get("pnlgeneral").vw.getHeight()) - ((views.get("pnlgeneral1").vw.getTop() + views.get("pnlgeneral1").vw.getHeight()))));
//BA.debugLineNum = 98;BA.debugLine="btnsizeH = Max(80dip,pnlGeneral1.Height -20dip)"[pageMovement/General script]
_btnsizeh = BA.NumberToString(Math.max((80d * scale),(views.get("pnlgeneral1").vw.getHeight())-(20d * scale)));
//BA.debugLineNum = 100;BA.debugLine="btnFN.Height    = btnsizeH : btnMOff.Height = btnsizeH : btnHeat.Height = btnsizeH"[pageMovement/General script]
views.get("btnfn").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 100;BA.debugLine="btnFN.Height    = btnsizeH : btnMOff.Height = btnsizeH : btnHeat.Height = btnsizeH"[pageMovement/General script]
views.get("btnmoff").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 100;BA.debugLine="btnFN.Height    = btnsizeH : btnMOff.Height = btnsizeH : btnHeat.Height = btnsizeH"[pageMovement/General script]
views.get("btnheat").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 101;BA.debugLine="btnFN.VerticalCenter  = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnfn").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnfn").vw.getHeight() / 2)));
//BA.debugLineNum = 102;BA.debugLine="btnMOff.VerticalCenter = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnmoff").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnmoff").vw.getHeight() / 2)));
//BA.debugLineNum = 103;BA.debugLine="btnHeat.VerticalCenter = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnheat").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnheat").vw.getHeight() / 2)));
//BA.debugLineNum = 105;BA.debugLine="btnExtrude.Height = btnsizeH : btnExtrude.VerticalCenter = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnextrude").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 105;BA.debugLine="btnExtrude.Height = btnsizeH : btnExtrude.VerticalCenter = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnextrude").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnextrude").vw.getHeight() / 2)));
//BA.debugLineNum = 106;BA.debugLine="btnRetract.Height = btnsizeH : btnRetract.VerticalCenter  = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnretract").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 106;BA.debugLine="btnRetract.Height = btnsizeH : btnRetract.VerticalCenter  = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnretract").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnretract").vw.getHeight() / 2)));
//BA.debugLineNum = 107;BA.debugLine="btnLength.Height  = btnsizeH : btnLength.VerticalCenter   = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnlength").vw.setHeight((int)(Double.parseDouble(_btnsizeh)));
//BA.debugLineNum = 107;BA.debugLine="btnLength.Height  = btnsizeH : btnLength.VerticalCenter   = pnlGeneral1.Height / 2"[pageMovement/General script]
views.get("btnlength").vw.setTop((int)((views.get("pnlgeneral1").vw.getHeight())/2d - (views.get("btnlength").vw.getHeight() / 2)));
//BA.debugLineNum = 109;BA.debugLine="ms = (pnlGeneral2.Width / 3) - 12dip"[pageMovement/General script]
_ms = BA.NumberToString(((views.get("pnlgeneral2").vw.getWidth())/3d)-(12d * scale));
//BA.debugLineNum = 110;BA.debugLine="DSE_Layout.SpreadHorizontally(pnlGeneral1,ms,6dip,\"center\")"[pageMovement/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlgeneral1", _ms, BA.NumberToString((6d * scale)), "center"});
//BA.debugLineNum = 111;BA.debugLine="DSE_Layout.SpreadHorizontally(pnlGeneral2,ms,6dip,\"center\")"[pageMovement/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlgeneral2", _ms, BA.NumberToString((6d * scale)), "center"});
//BA.debugLineNum = 114;BA.debugLine="pnlJogMovementHeader.SetLeftAndRight	(pnlCenter.Left,pnlCenter.Right)"[pageMovement/General script]
views.get("pnljogmovementheader").vw.setLeft((int)((views.get("pnlcenter").vw.getLeft())));
views.get("pnljogmovementheader").vw.setWidth((int)((views.get("pnlcenter").vw.getLeft() + views.get("pnlcenter").vw.getWidth()) - ((views.get("pnlcenter").vw.getLeft()))));
//BA.debugLineNum = 115;BA.debugLine="pnlJogMovementHeader.SetTopAndBottom(0,lblGeneral.Height)"[pageMovement/General script]
views.get("pnljogmovementheader").vw.setTop((int)(0d));
views.get("pnljogmovementheader").vw.setHeight((int)((views.get("lblgeneral").vw.getHeight()) - (0d)));
//BA.debugLineNum = 116;BA.debugLine="lblHeaderXY.SetTopAndBottom(0,pnlJogMovementHeader.Height)"[pageMovement/General script]
views.get("lblheaderxy").vw.setTop((int)(0d));
views.get("lblheaderxy").vw.setHeight((int)((views.get("pnljogmovementheader").vw.getHeight()) - (0d)));
//BA.debugLineNum = 117;BA.debugLine="lblHeaderZ.SetTopAndBottom(0,pnlJogMovementHeader.Height)"[pageMovement/General script]
views.get("lblheaderz").vw.setTop((int)(0d));
views.get("lblheaderz").vw.setHeight((int)((views.get("pnljogmovementheader").vw.getHeight()) - (0d)));
//BA.debugLineNum = 119;BA.debugLine="pnlJogMovement1.SetTopAndBottom(pnlJogMovementHeader.Bottom,pnlJogMovement.Height)"[pageMovement/General script]
views.get("pnljogmovement1").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement1").vw.setHeight((int)((views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
//BA.debugLineNum = 120;BA.debugLine="pnlJogMovement2.SetTopAndBottom(pnlJogMovementHeader.Bottom,pnlJogMovement.Height)"[pageMovement/General script]
views.get("pnljogmovement2").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement2").vw.setHeight((int)((views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
//BA.debugLineNum = 121;BA.debugLine="pnlJogMovement3.SetTopAndBottom(pnlJogMovementHeader.Bottom,pnlJogMovement.Height)"[pageMovement/General script]
views.get("pnljogmovement3").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovement3").vw.setHeight((int)((views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
//BA.debugLineNum = 122;BA.debugLine="pnlJogMovementZ.SetTopAndBottom(pnlJogMovementHeader.Bottom,pnlJogMovement.Height)"[pageMovement/General script]
views.get("pnljogmovementz").vw.setTop((int)((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight())));
views.get("pnljogmovementz").vw.setHeight((int)((views.get("pnljogmovement").vw.getHeight()) - ((views.get("pnljogmovementheader").vw.getTop() + views.get("pnljogmovementheader").vw.getHeight()))));
//BA.debugLineNum = 124;BA.debugLine="qu = pnlJogMovement.Width / 4"[pageMovement/General script]
_qu = BA.NumberToString((views.get("pnljogmovement").vw.getWidth())/4d);
//BA.debugLineNum = 125;BA.debugLine="pnlJogMovement1.SetLeftAndRight(0,qu)"[pageMovement/General script]
views.get("pnljogmovement1").vw.setLeft((int)(0d));
views.get("pnljogmovement1").vw.setWidth((int)(Double.parseDouble(_qu) - (0d)));
//BA.debugLineNum = 126;BA.debugLine="pnlJogMovement2.SetLeftAndRight(qu,qu*2)"[pageMovement/General script]
views.get("pnljogmovement2").vw.setLeft((int)(Double.parseDouble(_qu)));
views.get("pnljogmovement2").vw.setWidth((int)(Double.parseDouble(_qu)*2d - (Double.parseDouble(_qu))));
//BA.debugLineNum = 127;BA.debugLine="pnlJogMovement3.SetLeftAndRight(qu*2,qu*3)"[pageMovement/General script]
views.get("pnljogmovement3").vw.setLeft((int)(Double.parseDouble(_qu)*2d));
views.get("pnljogmovement3").vw.setWidth((int)(Double.parseDouble(_qu)*3d - (Double.parseDouble(_qu)*2d)));
//BA.debugLineNum = 128;BA.debugLine="pnlJogMovementZ.SetLeftAndRight(qu*3,qu*4)"[pageMovement/General script]
views.get("pnljogmovementz").vw.setLeft((int)(Double.parseDouble(_qu)*3d));
views.get("pnljogmovementz").vw.setWidth((int)(Double.parseDouble(_qu)*4d - (Double.parseDouble(_qu)*3d)));
//BA.debugLineNum = 130;BA.debugLine="lblHeaderXY.SetLeftAndRight(0,qu*3)"[pageMovement/General script]
views.get("lblheaderxy").vw.setLeft((int)(0d));
views.get("lblheaderxy").vw.setWidth((int)(Double.parseDouble(_qu)*3d - (0d)));
//BA.debugLineNum = 131;BA.debugLine="lblHeaderZ.SetLeftAndRight(qu*3,qu*4)"[pageMovement/General script]
views.get("lblheaderz").vw.setLeft((int)(Double.parseDouble(_qu)*3d));
views.get("lblheaderz").vw.setWidth((int)(Double.parseDouble(_qu)*4d - (Double.parseDouble(_qu)*3d)));
//BA.debugLineNum = 133;BA.debugLine="btnsizeH = pnlJogMovement1.Height / 3 - 10dip"[pageMovement/General script]
_btnsizeh = BA.NumberToString((views.get("pnljogmovement1").vw.getHeight())/3d-(10d * scale));
//BA.debugLineNum = 134;BA.debugLine="btnsizeW = Max(76dip,pnlJogMovement1.Width -10dip)"[pageMovement/General script]
_btnsizew = BA.NumberToString(Math.max((76d * scale),(views.get("pnljogmovement1").vw.getWidth())-(10d * scale)));
//BA.debugLineNum = 135;BA.debugLine="btnXYback.Width = btnsizeW     : btnXYback.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyback").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 135;BA.debugLine="btnXYback.Width = btnsizeW     : btnXYback.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyback").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyback").vw.getWidth() / 2)));
//BA.debugLineNum = 136;BA.debugLine="btnXYhome.Width = btnsizeW    : btnXYhome.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyhome").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 136;BA.debugLine="btnXYhome.Width = btnsizeW    : btnXYhome.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyhome").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyhome").vw.getWidth() / 2)));
//BA.debugLineNum = 137;BA.debugLine="btnXYforward.Width = btnsizeW : btnXYforward.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyforward").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 137;BA.debugLine="btnXYforward.Width = btnsizeW : btnXYforward.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyforward").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyforward").vw.getWidth() / 2)));
//BA.debugLineNum = 138;BA.debugLine="DSE_Layout.SpreadVertically(pnlJogMovement2 ,btnsizeH,2dip,\"center\")"[pageMovement/General script]
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadvertically", width, height, views, new Object[] {"pnljogmovement2", _btnsizeh, BA.NumberToString((2d * scale)), "center"});
//BA.debugLineNum = 140;BA.debugLine="btnXYleft.Width = btnsizeW : btnXYleft.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyleft").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 140;BA.debugLine="btnXYleft.Width = btnsizeW : btnXYleft.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyleft").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyleft").vw.getWidth() / 2)));
//BA.debugLineNum = 141;BA.debugLine="btnXYright.Width = btnsizeW : btnXYright.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyright").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 141;BA.debugLine="btnXYright.Width = btnsizeW : btnXYright.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnxyright").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnxyright").vw.getWidth() / 2)));
//BA.debugLineNum = 143;BA.debugLine="btnZup.Width = btnsizeW : btnZup.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzup").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 143;BA.debugLine="btnZup.Width = btnsizeW : btnZup.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzup").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzup").vw.getWidth() / 2)));
//BA.debugLineNum = 144;BA.debugLine="btnZhome.Width = btnsizeW : btnZhome.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzhome").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 144;BA.debugLine="btnZhome.Width = btnsizeW : btnZhome.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzhome").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzhome").vw.getWidth() / 2)));
//BA.debugLineNum = 145;BA.debugLine="btnZdown.Width = btnsizeW : btnZdown.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzdown").vw.setWidth((int)(Double.parseDouble(_btnsizew)));
//BA.debugLineNum = 145;BA.debugLine="btnZdown.Width = btnsizeW : btnZdown.HorizontalCenter  = pnlJogMovement1.Width / 2"[pageMovement/General script]
views.get("btnzdown").vw.setLeft((int)((views.get("pnljogmovement1").vw.getWidth())/2d - (views.get("btnzdown").vw.getWidth() / 2)));
//BA.debugLineNum = 147;BA.debugLine="lblMovePopup.SetLeftAndRight(2dip,pnlJogMovement1.Right)"[pageMovement/General script]
views.get("lblmovepopup").vw.setLeft((int)((2d * scale)));
views.get("lblmovepopup").vw.setWidth((int)((views.get("pnljogmovement1").vw.getLeft() + views.get("pnljogmovement1").vw.getWidth()) - ((2d * scale))));
//BA.debugLineNum = 151;BA.debugLine="End If"[pageMovement/General script]
;};

}
}