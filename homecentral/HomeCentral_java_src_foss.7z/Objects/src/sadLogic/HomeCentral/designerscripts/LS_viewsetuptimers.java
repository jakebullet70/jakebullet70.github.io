package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewsetuptimers{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("panel1").vw.setLeft((int)(0d));
views.get("panel1").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("panel1").vw.setTop((int)(0d));
views.get("panel1").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("lstpresets").vw.setLeft((int)((3d * scale)));
views.get("lstpresets").vw.setWidth((int)((75d / 100 * width) - ((3d * scale))));
views.get("lstpresets").vw.setTop((int)((3d * scale)));
views.get("lstpresets").vw.setHeight((int)((50d / 100 * height) - ((3d * scale))));
views.get("pnlbtns").vw.setLeft((int)((75d / 100 * width)));
views.get("pnlbtns").vw.setWidth((int)((100d / 100 * width)-(6d * scale) - ((75d / 100 * width))));
views.get("btnadd").vw.setWidth((int)((views.get("pnlbtns").vw.getWidth())-(9d * scale)));
views.get("btnremove").vw.setWidth((int)((views.get("pnlbtns").vw.getWidth())-(9d * scale)));
views.get("pnlvolsnd").vw.setLeft((int)(0d));
views.get("pnlvolsnd").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlvolsnd").vw.setTop((int)((views.get("lstpresets").vw.getTop() + views.get("lstpresets").vw.getHeight())));
views.get("pnlvolsnd").vw.setHeight((int)((92d / 100 * height) - ((views.get("lstpresets").vw.getTop() + views.get("lstpresets").vw.getHeight()))));
views.get("pnltimervol").vw.setLeft((int)((10d * scale)));
views.get("pnltimervol").vw.setWidth((int)((100d / 100 * width)-(10d * scale) - ((10d * scale))));
views.get("lbltmrvol").vw.setLeft((int)((views.get("pnltimervol").vw.getWidth())-(4d * scale) - (views.get("lbltmrvol").vw.getWidth())));
views.get("sbtimervol").vw.setLeft((int)((6d * scale)));
views.get("sbtimervol").vw.setWidth((int)((views.get("lbltmrvol").vw.getLeft())-(6d * scale) - ((6d * scale))));
views.get("pnladdnew").vw.setLeft((int)(0d));
views.get("pnladdnew").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnladdnew").vw.setTop((int)((views.get("lstpresets").vw.getTop() + views.get("lstpresets").vw.getHeight())));
views.get("pnladdnew").vw.setHeight((int)((92d / 100 * height) - ((views.get("lstpresets").vw.getTop() + views.get("lstpresets").vw.getHeight()))));
views.get("pnladdnew").vw.setVisible(BA.parseBoolean("false"));

}
}