package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlglistbox extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlglistbox");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlglistbox.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _mtitle = null;
public Object _mcallback = null;
public String _meventname = "";
public Object _mtag = null;
public sadLogic.HomeCentral.b4xdialog _mdialog = null;
public boolean _ismenu = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 12;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Private mTitle As Object";
_mtitle = new Object();
 //BA.debugLineNum = 14;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 15;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 16;BA.debugLine="Private mTag As Object = Null 'ignore";
_mtag = __c.Null;
 //BA.debugLineNum = 18;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 20;BA.debugLine="Public IsMenu As Boolean = False";
_ismenu = __c.False;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _gettagfrommap(String _item,anywheresoftware.b4a.objects.collections.Map _d) throws Exception{
int _xx = 0;
 //BA.debugLineNum = 81;BA.debugLine="Private Sub GetTagFromMap(item As String,d As Map)";
 //BA.debugLineNum = 84;BA.debugLine="For xx = 0 To d.Size - 1";
{
final int step1 = 1;
final int limit1 = (int) (_d.getSize()-1);
_xx = (int) (0) ;
for (;_xx <= limit1 ;_xx = _xx + step1 ) {
 //BA.debugLineNum = 85;BA.debugLine="If d.GetKeyAt(xx).As(String).Contains(item) Then";
if ((BA.ObjectToString(_d.GetKeyAt(_xx))).contains(_item)) { 
 //BA.debugLineNum = 86;BA.debugLine="Return d.GetValueAt(xx)";
if (true) return BA.ObjectToString(_d.GetValueAt(_xx));
 };
 }
};
 //BA.debugLineNum = 89;BA.debugLine="Return \"\"";
if (true) return "";
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,Object _title,Object _callback,String _eventname,sadLogic.HomeCentral.b4xdialog _dlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 29;BA.debugLine="Public Sub Initialize( title As Object, Callback A";
 //BA.debugLineNum = 31;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 32;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 33;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 34;BA.debugLine="mDialog = dlg";
_mdialog = _dlg;
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public String  _settag(Object _v) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Public Sub setTag(v As Object)";
 //BA.debugLineNum = 26;BA.debugLine="mTag = v";
_mtag = _v;
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public void  _show(float _height,float _width,anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_height,_width,_data);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlglistbox parent,float _height,float _width,anywheresoftware.b4a.objects.collections.Map _data) {
this.parent = parent;
this._height = _height;
this._width = _width;
this._data = _data;
}
sadLogic.HomeCentral.dlglistbox parent;
float _height;
float _width;
anywheresoftware.b4a.objects.collections.Map _data;
sadLogic.HomeCentral.b4xlisttemplate _listtemplate = null;
sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 43;BA.debugLine="mDialog.Initialize(mpage.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 44;BA.debugLine="Dim ListTemplate As B4XListTemplate : ListTemplat";
_listtemplate = new sadLogic.HomeCentral.b4xlisttemplate();
 //BA.debugLineNum = 44;BA.debugLine="Dim ListTemplate As B4XListTemplate : ListTemplat";
_listtemplate._initialize /*String*/ (ba);
 //BA.debugLineNum = 45;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 46;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 49;BA.debugLine="ListTemplate.CustomListView1.DefaultTextBackgroun";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._clrtheme._background /*int*/ ;
 //BA.debugLineNum = 52;BA.debugLine="ListTemplate.Resize(width, height)";
_listtemplate._resize /*String*/ ((int) (_width),(int) (_height));
 //BA.debugLineNum = 53;BA.debugLine="ListTemplate.CustomListView1.AsView.width = width";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._asview().setWidth((int) (_width));
 //BA.debugLineNum = 54;BA.debugLine="ListTemplate.CustomListView1.AsView.Height = heig";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._asview().setHeight((int) (_height));
 //BA.debugLineNum = 55;BA.debugLine="ListTemplate.CustomListView1.PressedColor = clrTh";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._pressedcolor = parent._clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 56;BA.debugLine="ListTemplate.CustomListView1.DefaultTextColor = c";
_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._clrtheme._txtnormal /*int*/ ;
 //BA.debugLineNum = 57;BA.debugLine="ListTemplate.options = objHelpers.Map2List(data,T";
_listtemplate._options /*anywheresoftware.b4a.objects.collections.List*/  = parent._objhelpers._map2list /*anywheresoftware.b4a.objects.collections.List*/ (ba,_data,parent.__c.True);
 //BA.debugLineNum = 60;BA.debugLine="Dim l As B4XView = ListTemplate.CustomListView1.D";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_listtemplate._customlistview1 /*b4a.example3.customlistview*/ ._designerlabel.getObject()));
 //BA.debugLineNum = 61;BA.debugLine="l.Font = xui.CreateDefaultFont(NumberFormat2(30 /";
_l.setFont(parent._xui.CreateDefaultFont((float)(Double.parseDouble(parent.__c.NumberFormat2(30/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))));
 //BA.debugLineNum = 63;BA.debugLine="dlgHelper.ThemeDialogForm( mTitle)";
_dlghelper._themedialogform /*String*/ (parent._mtitle);
 //BA.debugLineNum = 64;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowTemplate(Lis";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_listtemplate),(Object)(""),(Object)(""),((parent._ismenu) ? ((Object)("CLOSE")) : ((Object)("CANCEL"))));
 //BA.debugLineNum = 65;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
_dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 68;BA.debugLine="Wait For(rs) complete(i As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 7;
return;
case 7:
//C
this.state = 1;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 69;BA.debugLine="If i = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_i==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 70;BA.debugLine="CallSub3(mCallback,mEventName,GetTagFromMap(List";
parent.__c.CallSubNew3(ba,parent._mcallback,parent._meventname,(Object)(parent._gettagfrommap(_listtemplate._selecteditem /*String*/ ,_data)),parent._mtag);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 72;BA.debugLine="CallSub3(mCallback,mEventName,\"\",\"\")";
parent.__c.CallSubNew3(ba,parent._mcallback,parent._meventname,(Object)(""),(Object)(""));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 75;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Main,\"Di";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
