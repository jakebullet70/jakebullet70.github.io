package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dse_layout extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dse_layout");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dse_layout.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _mnumofviews = 0;
public int _i = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private mNumOfViews As Int = 0, i As Int = 0";
_mnumofviews = (int) (0);
_i = (int) (0);
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public int  _getnumofviews(anywheresoftware.b4a.objects.B4XViewWrapper _pnl) throws Exception{
int _newnumofviews = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _v = null;
 //BA.debugLineNum = 19;BA.debugLine="Private Sub GetNumOfViews(pnl As B4XView) As Int '";
 //BA.debugLineNum = 25;BA.debugLine="Dim newNumOfViews As Int = 0 '--- added,sadLogic";
_newnumofviews = (int) (0);
 //BA.debugLineNum = 26;BA.debugLine="For i = 0 To pnl.NumberOfViews -1";
{
final int step2 = 1;
final int limit2 = (int) (_pnl.getNumberOfViews()-1);
_i = (int) (0) ;
for (;_i <= limit2 ;_i = _i + step2 ) {
 //BA.debugLineNum = 27;BA.debugLine="Dim v As B4XView = pnl.GetView(i)";
_v = new anywheresoftware.b4a.objects.B4XViewWrapper();
_v = _pnl.GetView(_i);
 //BA.debugLineNum = 28;BA.debugLine="If v.Visible = False Then Continue";
if (_v.getVisible()==__c.False) { 
if (true) continue;};
 //BA.debugLineNum = 29;BA.debugLine="newNumOfViews = newNumOfViews + 1";
_newnumofviews = (int) (_newnumofviews+1);
 }
};
 //BA.debugLineNum = 31;BA.debugLine="Return newNumOfViews";
if (true) return _newnumofviews;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _spreadhorizontally(anywheresoftware.b4a.keywords.DesignerArgs _designerargs) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
int _maxsize = 0;
int _mingap = 0;
String _align = "";
 //BA.debugLineNum = 37;BA.debugLine="Public Sub SpreadHorizontally (DesignerArgs As Des";
 //BA.debugLineNum = 38;BA.debugLine="Dim pnl As B4XView = DesignerArgs.GetViewFromArgs";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_designerargs.GetViewFromArgs((int) (0))));
 //BA.debugLineNum = 39;BA.debugLine="Dim Maxsize As Int = DesignerArgs.Arguments.Get(1";
_maxsize = (int)(BA.ObjectToNumber(_designerargs.getArguments().Get((int) (1))));
 //BA.debugLineNum = 40;BA.debugLine="Dim MinGap  As Int = DesignerArgs.Arguments.Get(2";
_mingap = (int)(BA.ObjectToNumber(_designerargs.getArguments().Get((int) (2))));
 //BA.debugLineNum = 41;BA.debugLine="Dim align  As String  = DesignerArgs.Arguments.Ge";
_align = BA.ObjectToString(_designerargs.getArguments().Get((int) (3)));
 //BA.debugLineNum = 42;BA.debugLine="SpreadHorizontally2(pnl,Maxsize,MinGap,align)";
_spreadhorizontally2(_pnl,_maxsize,_mingap,_align);
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _spreadhorizontally2(anywheresoftware.b4a.objects.B4XViewWrapper _pnl,int _maxsize,int _mingap,String _align) throws Exception{
boolean _change = false;
int _allwidth = 0;
int _allitemswidth = 0;
int _itemwidth = 0;
int _gap = 0;
int _qq = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _v = null;
int _lastright = 0;
int _alignposition = 0;
 //BA.debugLineNum = 51;BA.debugLine="Public Sub SpreadHorizontally2(pnl As B4XView, Max";
 //BA.debugLineNum = 56;BA.debugLine="Dim Change As Boolean = Maxsize >= 0";
_change = _maxsize>=0;
 //BA.debugLineNum = 58;BA.debugLine="If pnl.IsInitialized = False Then Return";
if (_pnl.IsInitialized()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 59;BA.debugLine="If Maxsize = 0 Then Maxsize = 0x7fffffff";
if (_maxsize==0) { 
_maxsize = ((int)0x7fffffff);};
 //BA.debugLineNum = 60;BA.debugLine="mNumOfViews = GetNumOfViews(pnl)";
_mnumofviews = _getnumofviews(_pnl);
 //BA.debugLineNum = 62;BA.debugLine="Dim AllWidth As Int = pnl.Width";
_allwidth = _pnl.getWidth();
 //BA.debugLineNum = 63;BA.debugLine="Dim AllItemsWidth As Int";
_allitemswidth = 0;
 //BA.debugLineNum = 64;BA.debugLine="If Change Then";
if (_change) { 
 //BA.debugLineNum = 67;BA.debugLine="Dim itemwidth As Int = Min(AllWidth / mNumOfView";
_itemwidth = (int) (__c.Min(_allwidth/(double)_mnumofviews-_mingap,_maxsize));
 //BA.debugLineNum = 68;BA.debugLine="Dim gap As Int = (AllWidth - mNumOfViews * itemw";
_gap = (int) ((_allwidth-_mnumofviews*_itemwidth)/(double)_mnumofviews);
 }else {
 //BA.debugLineNum = 70;BA.debugLine="For qq = 0 To pnl.NumberOfViews -1";
{
final int step11 = 1;
final int limit11 = (int) (_pnl.getNumberOfViews()-1);
_qq = (int) (0) ;
for (;_qq <= limit11 ;_qq = _qq + step11 ) {
 //BA.debugLineNum = 71;BA.debugLine="Dim v As B4XView = pnl.GetView(qq)";
_v = new anywheresoftware.b4a.objects.B4XViewWrapper();
_v = _pnl.GetView(_qq);
 //BA.debugLineNum = 72;BA.debugLine="If v.Visible = False Then Continue '--- added,s";
if (_v.getVisible()==__c.False) { 
if (true) continue;};
 //BA.debugLineNum = 73;BA.debugLine="AllItemsWidth = AllItemsWidth + v.Width";
_allitemswidth = (int) (_allitemswidth+_v.getWidth());
 //BA.debugLineNum = 74;BA.debugLine="If AllItemsWidth > AllWidth Then Return ' If to";
if (_allitemswidth>_allwidth) { 
if (true) return "";};
 }
};
 //BA.debugLineNum = 77;BA.debugLine="Dim gap As Int = (AllWidth - AllItemsWidth) / (m";
_gap = (int) ((_allwidth-_allitemswidth)/(double)(_mnumofviews+1));
 };
 //BA.debugLineNum = 80;BA.debugLine="Dim lastright As Int = gap";
_lastright = _gap;
 //BA.debugLineNum = 81;BA.debugLine="Dim alignposition As Int = -1";
_alignposition = (int) (-1);
 //BA.debugLineNum = 82;BA.debugLine="i = 0";
_i = (int) (0);
 //BA.debugLineNum = 83;BA.debugLine="For qq = 0 To pnl.NumberOfViews - 1";
{
final int step22 = 1;
final int limit22 = (int) (_pnl.getNumberOfViews()-1);
_qq = (int) (0) ;
for (;_qq <= limit22 ;_qq = _qq + step22 ) {
 //BA.debugLineNum = 84;BA.debugLine="Dim v As B4XView = pnl.GetView(qq)";
_v = new anywheresoftware.b4a.objects.B4XViewWrapper();
_v = _pnl.GetView(_qq);
 //BA.debugLineNum = 85;BA.debugLine="If v.Visible = False Then Continue '--- added,sa";
if (_v.getVisible()==__c.False) { 
if (true) continue;};
 //BA.debugLineNum = 86;BA.debugLine="If Change Then";
if (_change) { 
 //BA.debugLineNum = 87;BA.debugLine="v.SetLayoutAnimated(0, (i + 0.5) * gap + i * it";
_v.SetLayoutAnimated((int) (0),(int) ((_i+0.5)*_gap+_i*_itemwidth),_v.getTop(),_itemwidth,_v.getHeight());
 //BA.debugLineNum = 88;BA.debugLine="Select align.Trim.ToLowerCase";
switch (BA.switchObjectToInt(_align.trim().toLowerCase(),"top","bottom","center","centre")) {
case 0: {
 //BA.debugLineNum = 90;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = _v.getTop();};
 //BA.debugLineNum = 91;BA.debugLine="v.top = alignposition";
_v.setTop(_alignposition);
 break; }
case 1: {
 //BA.debugLineNum = 93;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getTop()+_v.getHeight());};
 //BA.debugLineNum = 94;BA.debugLine="v.top = alignposition - v.Height";
_v.setTop((int) (_alignposition-_v.getHeight()));
 break; }
case 2: 
case 3: {
 //BA.debugLineNum = 96;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getTop()+(_v.getHeight()/(double)2));};
 //BA.debugLineNum = 97;BA.debugLine="v.top = alignposition - (v.Height/2)";
_v.setTop((int) (_alignposition-(_v.getHeight()/(double)2)));
 break; }
default: {
 break; }
}
;
 }else {
 //BA.debugLineNum = 101;BA.debugLine="v.SetLayoutAnimated(0, lastright, v.Top, v.Widt";
_v.SetLayoutAnimated((int) (0),_lastright,_v.getTop(),_v.getWidth(),_v.getHeight());
 //BA.debugLineNum = 102;BA.debugLine="lastright =  gap + v.Left + v.Width";
_lastright = (int) (_gap+_v.getLeft()+_v.getWidth());
 //BA.debugLineNum = 103;BA.debugLine="Select align.Trim.ToLowerCase";
switch (BA.switchObjectToInt(_align.trim().toLowerCase(),"top","bottom","center","centre")) {
case 0: {
 //BA.debugLineNum = 105;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = _v.getTop();};
 //BA.debugLineNum = 106;BA.debugLine="v.top = alignposition";
_v.setTop(_alignposition);
 break; }
case 1: {
 //BA.debugLineNum = 108;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getTop()+_v.getHeight());};
 //BA.debugLineNum = 109;BA.debugLine="v.top = alignposition - v.Height";
_v.setTop((int) (_alignposition-_v.getHeight()));
 break; }
case 2: 
case 3: {
 //BA.debugLineNum = 111;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getTop()+(_v.getHeight()/(double)2));};
 //BA.debugLineNum = 112;BA.debugLine="v.top = alignposition - (v.Height/2)";
_v.setTop((int) (_alignposition-(_v.getHeight()/(double)2)));
 break; }
default: {
 break; }
}
;
 };
 //BA.debugLineNum = 116;BA.debugLine="i = i + 1";
_i = (int) (_i+1);
 }
};
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}
public String  _spreadvertically(anywheresoftware.b4a.keywords.DesignerArgs _designerargs) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
int _maxsize = 0;
int _mingap = 0;
String _align = "";
 //BA.debugLineNum = 125;BA.debugLine="Public Sub SpreadVertically (DesignerArgs As Desig";
 //BA.debugLineNum = 126;BA.debugLine="Dim pnl As B4XView = DesignerArgs.GetViewFromArgs";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_designerargs.GetViewFromArgs((int) (0))));
 //BA.debugLineNum = 127;BA.debugLine="Dim Maxsize As Int = DesignerArgs.Arguments.Get(1";
_maxsize = (int)(BA.ObjectToNumber(_designerargs.getArguments().Get((int) (1))));
 //BA.debugLineNum = 128;BA.debugLine="Dim MinGap  As Int = DesignerArgs.Arguments.Get(2";
_mingap = (int)(BA.ObjectToNumber(_designerargs.getArguments().Get((int) (2))));
 //BA.debugLineNum = 129;BA.debugLine="Dim align  As String  = DesignerArgs.Arguments.Ge";
_align = BA.ObjectToString(_designerargs.getArguments().Get((int) (3)));
 //BA.debugLineNum = 130;BA.debugLine="SpreadVertically2(pnl,Maxsize,MinGap,align)";
_spreadvertically2(_pnl,_maxsize,_mingap,_align);
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public String  _spreadvertically2(anywheresoftware.b4a.objects.B4XViewWrapper _pnl,int _maxsize,int _mingap,String _align) throws Exception{
boolean _change = false;
int _allheight = 0;
int _allitemsheight = 0;
int _itemheight = 0;
int _gap = 0;
int _qq = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _v = null;
int _lasttop = 0;
int _alignposition = 0;
 //BA.debugLineNum = 139;BA.debugLine="Public Sub SpreadVertically2 (pnl As B4XView, Maxs";
 //BA.debugLineNum = 144;BA.debugLine="Dim Change As Boolean = Maxsize >= 0";
_change = _maxsize>=0;
 //BA.debugLineNum = 146;BA.debugLine="If pnl.IsInitialized = False Then Return";
if (_pnl.IsInitialized()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 147;BA.debugLine="If Maxsize = 0 Then Maxsize = 0x7fffffff";
if (_maxsize==0) { 
_maxsize = ((int)0x7fffffff);};
 //BA.debugLineNum = 148;BA.debugLine="Dim AllHeight As Int = pnl.Height";
_allheight = _pnl.getHeight();
 //BA.debugLineNum = 149;BA.debugLine="Dim AllItemsHeight As Int";
_allitemsheight = 0;
 //BA.debugLineNum = 151;BA.debugLine="mNumOfViews = GetNumOfViews(pnl)";
_mnumofviews = _getnumofviews(_pnl);
 //BA.debugLineNum = 153;BA.debugLine="If Change Then";
if (_change) { 
 //BA.debugLineNum = 156;BA.debugLine="Dim itemHeight As Int = Min(AllHeight / mNumOfVi";
_itemheight = (int) (__c.Min(_allheight/(double)_mnumofviews-_mingap,_maxsize));
 //BA.debugLineNum = 157;BA.debugLine="Dim gap As Int = (AllHeight - mNumOfViews * item";
_gap = (int) ((_allheight-_mnumofviews*_itemheight)/(double)_mnumofviews);
 }else {
 //BA.debugLineNum = 159;BA.debugLine="For qq = 0 To pnl.NumberOfViews - 1";
{
final int step11 = 1;
final int limit11 = (int) (_pnl.getNumberOfViews()-1);
_qq = (int) (0) ;
for (;_qq <= limit11 ;_qq = _qq + step11 ) {
 //BA.debugLineNum = 160;BA.debugLine="Dim v As B4XView = pnl.GetView(qq)";
_v = new anywheresoftware.b4a.objects.B4XViewWrapper();
_v = _pnl.GetView(_qq);
 //BA.debugLineNum = 161;BA.debugLine="If v.Visible = False Then Continue '--- added,s";
if (_v.getVisible()==__c.False) { 
if (true) continue;};
 //BA.debugLineNum = 162;BA.debugLine="AllItemsHeight = AllItemsHeight + v.Height";
_allitemsheight = (int) (_allitemsheight+_v.getHeight());
 //BA.debugLineNum = 163;BA.debugLine="If AllItemsHeight > AllHeight Then Return ' If";
if (_allitemsheight>_allheight) { 
if (true) return "";};
 }
};
 //BA.debugLineNum = 165;BA.debugLine="Dim gap As Int = (AllHeight - AllItemsHeight) /";
_gap = (int) ((_allheight-_allitemsheight)/(double)(_mnumofviews+1));
 };
 //BA.debugLineNum = 169;BA.debugLine="Dim lasttop As Int = gap";
_lasttop = _gap;
 //BA.debugLineNum = 170;BA.debugLine="Dim alignposition As Int = -1";
_alignposition = (int) (-1);
 //BA.debugLineNum = 172;BA.debugLine="i = 0";
_i = (int) (0);
 //BA.debugLineNum = 173;BA.debugLine="For qq = 0 To pnl.NumberOfViews - 1";
{
final int step22 = 1;
final int limit22 = (int) (_pnl.getNumberOfViews()-1);
_qq = (int) (0) ;
for (;_qq <= limit22 ;_qq = _qq + step22 ) {
 //BA.debugLineNum = 174;BA.debugLine="Dim v As B4XView = pnl.GetView(qq)";
_v = new anywheresoftware.b4a.objects.B4XViewWrapper();
_v = _pnl.GetView(_qq);
 //BA.debugLineNum = 175;BA.debugLine="If v.Visible = False Then Continue '--- added, s";
if (_v.getVisible()==__c.False) { 
if (true) continue;};
 //BA.debugLineNum = 176;BA.debugLine="If Change Then";
if (_change) { 
 //BA.debugLineNum = 177;BA.debugLine="v.SetLayoutAnimated(0, v.Left, (i + 0.5) * gap";
_v.SetLayoutAnimated((int) (0),_v.getLeft(),(int) ((_i+0.5)*_gap+_i*_itemheight),_v.getWidth(),_itemheight);
 //BA.debugLineNum = 178;BA.debugLine="Select align.Trim.ToLowerCase";
switch (BA.switchObjectToInt(_align.trim().toLowerCase(),"left","right","center")) {
case 0: {
 //BA.debugLineNum = 180;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = _v.getLeft();};
 //BA.debugLineNum = 181;BA.debugLine="v.Left = alignposition";
_v.setLeft(_alignposition);
 break; }
case 1: {
 //BA.debugLineNum = 183;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getLeft()+_v.getWidth());};
 //BA.debugLineNum = 184;BA.debugLine="v.Left = alignposition";
_v.setLeft(_alignposition);
 break; }
case 2: {
 //BA.debugLineNum = 186;BA.debugLine="If alignposition = -1 Then";
if (_alignposition==-1) { 
 //BA.debugLineNum = 187;BA.debugLine="alignposition = v.Left+(v.Width/2)";
_alignposition = (int) (_v.getLeft()+(_v.getWidth()/(double)2));
 };
 //BA.debugLineNum = 189;BA.debugLine="v.Left = alignposition - (v.Width/2)";
_v.setLeft((int) (_alignposition-(_v.getWidth()/(double)2)));
 break; }
default: {
 break; }
}
;
 }else {
 //BA.debugLineNum = 193;BA.debugLine="v.SetLayoutAnimated(0, v.Left, lasttop, v.Width";
_v.SetLayoutAnimated((int) (0),_v.getLeft(),_lasttop,_v.getWidth(),_v.getHeight());
 //BA.debugLineNum = 194;BA.debugLine="lasttop = v.Top + v.Height + gap";
_lasttop = (int) (_v.getTop()+_v.getHeight()+_gap);
 //BA.debugLineNum = 195;BA.debugLine="Select align.Trim.ToLowerCase";
switch (BA.switchObjectToInt(_align.trim().toLowerCase(),"left","right","center")) {
case 0: {
 //BA.debugLineNum = 197;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = _v.getLeft();};
 //BA.debugLineNum = 198;BA.debugLine="v.Left = alignposition";
_v.setLeft(_alignposition);
 break; }
case 1: {
 //BA.debugLineNum = 200;BA.debugLine="If alignposition = -1 Then alignposition = v.";
if (_alignposition==-1) { 
_alignposition = (int) (_v.getLeft()+_v.getWidth());};
 //BA.debugLineNum = 201;BA.debugLine="v.Left = alignposition";
_v.setLeft(_alignposition);
 break; }
case 2: {
 //BA.debugLineNum = 203;BA.debugLine="If alignposition = -1 Then";
if (_alignposition==-1) { 
 //BA.debugLineNum = 204;BA.debugLine="alignposition = v.Left+(v.Width/2)";
_alignposition = (int) (_v.getLeft()+(_v.getWidth()/(double)2));
 };
 //BA.debugLineNum = 206;BA.debugLine="v.Left = alignposition - (v.Width/2)";
_v.setLeft((int) (_alignposition-(_v.getWidth()/(double)2)));
 break; }
default: {
 break; }
}
;
 };
 //BA.debugLineNum = 210;BA.debugLine="i = i + 1";
_i = (int) (_i+1);
 }
};
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
