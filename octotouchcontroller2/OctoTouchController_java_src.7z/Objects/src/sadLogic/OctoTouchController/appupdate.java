package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class appupdate extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.appupdate");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.appupdate.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Const mModule As String = \"AppUpdate\" 'ig";
_mmodule = "AppUpdate";
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _runprgupdate() throws Exception{
int _prevver = 0;
 //BA.debugLineNum = 16;BA.debugLine="Public Sub RunPrgUpdate";
 //BA.debugLineNum = 21;BA.debugLine="Log(\"RunPrgUpdate\")";
__c.LogImpl("2293765","RunPrgUpdate",0);
 //BA.debugLineNum = 22;BA.debugLine="fileHelpers.DeleteFiles(xui.DefaultFolder,\"*.log\"";
_filehelpers._deletefiles /*String*/ (getActivityBA(),_xui.getDefaultFolder(),"*.log");
 //BA.debugLineNum = 23;BA.debugLine="fileHelpers.DeleteFiles(xui.DefaultFolder,\"*.cras";
_filehelpers._deletefiles /*String*/ (getActivityBA(),_xui.getDefaultFolder(),"*.crash");
 //BA.debugLineNum = 24;BA.debugLine="fileHelpers.DeleteFiles(xui.DefaultFolder,\"sad_*.";
_filehelpers._deletefiles /*String*/ (getActivityBA(),_xui.getDefaultFolder(),"sad_*.png");
 //BA.debugLineNum = 26;BA.debugLine="Dim PrevVer As Int = Main.kvs.Get(\"version_code\")";
_prevver = ((int)(BA.ObjectToNumber(_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._get /*Object*/ ("version_code"))));
 //BA.debugLineNum = 81;BA.debugLine="Main.kvs.Put(\"version_code\",Application.VersionCo";
_main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ ("version_code",(Object)(__c.Application.getVersionCode()));
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
