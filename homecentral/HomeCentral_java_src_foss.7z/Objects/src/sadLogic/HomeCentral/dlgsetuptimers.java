package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgsetuptimers extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgsetuptimers");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgsetuptimers.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xdialog _dlg = null;
public anywheresoftware.b4a.objects.IME _ime = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnremove = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnadd = null;
public sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
public int _currentrecid = 0;
public sadLogic.HomeCentral.b4xcombobox _cbosounds = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btntest = null;
public anywheresoftware.b4a.objects.LabelWrapper _label3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltmrvol = null;
public sadLogic.HomeCentral.b4xseekbar _sbtimervol = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltimervol = null;
public anywheresoftware.b4a.objects.ListViewWrapper _lstpresets = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlvolsnd = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnladdnew = null;
public sadLogic.HomeCentral.b4xfloattextfield _txtdescription = null;
public sadLogic.HomeCentral.b4xfloattextfield _txttime = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnnewsave = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnnewcancel = null;
public sadLogic.HomeCentral.listviewselector _olv_helper = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _btnadd_click() throws Exception{
 //BA.debugLineNum = 150;BA.debugLine="Private Sub btnAdd_Click";
 //BA.debugLineNum = 151;BA.debugLine="ShowAddNew(True)";
_showaddnew(__c.True);
 //BA.debugLineNum = 152;BA.debugLine="txtDescription.Text = \"\" : txtTime.Text = \"\"";
_txtdescription._settext /*String*/ ("");
 //BA.debugLineNum = 152;BA.debugLine="txtDescription.Text = \"\" : txtTime.Text = \"\"";
_txttime._settext /*String*/ ("");
 //BA.debugLineNum = 153;BA.debugLine="txtTime.RequestFocusAndShowKeyboard";
_txttime._requestfocusandshowkeyboard /*String*/ ();
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
public String  _btncancel_click() throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="Private Sub btnCancel_Click";
 //BA.debugLineNum = 158;BA.debugLine="ShowAddNew(False)";
_showaddnew(__c.False);
 //BA.debugLineNum = 159;BA.debugLine="IME.HideKeyboard";
_ime.HideKeyboard(ba);
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return "";
}
public void  _btnremove_click() throws Exception{
ResumableSub_btnRemove_Click rsub = new ResumableSub_btnRemove_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnRemove_Click extends BA.ResumableSub {
public ResumableSub_btnRemove_Click(sadLogic.HomeCentral.dlgsetuptimers parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetuptimers parent;
sadLogic.HomeCentral.dlgthemedmsgbox _o = null;
int _i = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 133;BA.debugLine="If lstPresets.Size = 1 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._lstpresets.getSize()==1) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 134;BA.debugLine="guiHelpers.Show_toast(\"Cannot delete last entry\"";
parent._guihelpers._show_toast /*String*/ (ba,"Cannot delete last entry");
 //BA.debugLineNum = 135;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 138;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o = new sadLogic.HomeCentral.dlgthemedmsgbox();
 //BA.debugLineNum = 138;BA.debugLine="Dim o As dlgThemedMsgBox : o.Initialize";
_o._initialize /*String*/ (ba);
 //BA.debugLineNum = 139;BA.debugLine="Wait For (o.Show(\"Are you sure you want to delete";
parent.__c.WaitFor("complete", ba, this, _o._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Are you sure you want to delete this entry?","Question?","YES","","CANCEL"));
this.state = 9;
return;
case 9:
//C
this.state = 5;
_i = (Integer) result[0];
;
 //BA.debugLineNum = 140;BA.debugLine="If i = XUI.DialogResponse_Cancel Then";
if (true) break;

case 5:
//if
this.state = 8;
if (_i==parent._xui.DialogResponse_Cancel) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 141;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 144;BA.debugLine="kt.timers_delete(CurrentRecID)";
parent._kt._timers_delete /*String*/ (ba,BA.NumberToString(parent._currentrecid));
 //BA.debugLineNum = 145;BA.debugLine="guiHelpers.Show_toast(\"Entry deleted\")";
parent._guihelpers._show_toast /*String*/ (ba,"Entry deleted");
 //BA.debugLineNum = 146;BA.debugLine="LoadGrid";
parent._loadgrid();
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _i) throws Exception{
}
public void  _btnsave_click() throws Exception{
ResumableSub_btnSave_Click rsub = new ResumableSub_btnSave_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnSave_Click extends BA.ResumableSub {
public ResumableSub_btnSave_Click(sadLogic.HomeCentral.dlgsetuptimers parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetuptimers parent;
String _vt = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 164;BA.debugLine="IME.HideKeyboard";
parent._ime.HideKeyboard(ba);
 //BA.debugLineNum = 165;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 8;
return;
case 8:
//C
this.state = 1;
;
 //BA.debugLineNum = 166;BA.debugLine="Dim vt As String = ValidateTime(txtTime.Text)";
_vt = parent._validatetime(parent._txttime._gettext /*String*/ ());
 //BA.debugLineNum = 167;BA.debugLine="If vt.Length = 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_vt.length()==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 168;BA.debugLine="ShowErrMsg(\"Time is not valid\",txtTime)";
parent._showerrmsg("Time is not valid",parent._txttime);
 //BA.debugLineNum = 170;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 172;BA.debugLine="If txtDescription.TextField.Text.Length = 0 Then";

case 4:
//if
this.state = 7;
if (parent._txtdescription._gettextfield /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getText().length()==0) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 173;BA.debugLine="ShowErrMsg(\"Description is not valid\",txtDescrip";
parent._showerrmsg("Description is not valid",parent._txtdescription);
 //BA.debugLineNum = 174;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 176;BA.debugLine="ShowAddNew(False)";
parent._showaddnew(parent.__c.False);
 //BA.debugLineNum = 177;BA.debugLine="guiHelpers.Show_toast(\"Saved\")";
parent._guihelpers._show_toast /*String*/ (ba,"Saved");
 //BA.debugLineNum = 178;BA.debugLine="kt.timers_insert_new(txtDescription.Text.Trim,vt)";
parent._kt._timers_insert_new /*String*/ (ba,parent._txtdescription._gettext /*String*/ ().trim(),_vt);
 //BA.debugLineNum = 179;BA.debugLine="LoadGrid";
parent._loadgrid();
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _btntest_click() throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Private Sub btnTest_Click";
 //BA.debugLineNum = 113;BA.debugLine="vol_timers.PlaySound(sbTimerVol.Value,vol_timers.";
_vol_timers._playsound /*void*/ (ba,_sbtimervol._getvalue /*int*/ (),_vol_timers._buildalarmfile /*String*/ (ba,_cbosounds._getselecteditem /*String*/ ()));
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
public String  _cbosounds_selectedindexchanged(int _index) throws Exception{
 //BA.debugLineNum = 117;BA.debugLine="Private Sub cboSounds_SelectedIndexChanged (Index";
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private dlg As B4XDialog";
_dlg = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 13;BA.debugLine="Private IME As IME";
_ime = new anywheresoftware.b4a.objects.IME();
 //BA.debugLineNum = 14;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 15;BA.debugLine="Private btnRemove,btnAdd As B4XView";
_btnremove = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btnadd = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 19;BA.debugLine="Private CurrentRecID As Int";
_currentrecid = 0;
 //BA.debugLineNum = 21;BA.debugLine="Private cboSounds As B4XComboBox";
_cbosounds = new sadLogic.HomeCentral.b4xcombobox();
 //BA.debugLineNum = 22;BA.debugLine="Private btnTest As Button";
_btntest = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private Label3,Label1 As Label";
_label3 = new anywheresoftware.b4a.objects.LabelWrapper();
_label1 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private lblTmrVol As Label";
_lbltmrvol = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private sbTimerVol As B4XSeekBar";
_sbtimervol = new sadLogic.HomeCentral.b4xseekbar();
 //BA.debugLineNum = 28;BA.debugLine="Private pnlTimerVol As Panel";
_pnltimervol = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private lstPresets As ListView";
_lstpresets = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private pnlVolSnd,pnlAddNew As Panel";
_pnlvolsnd = new anywheresoftware.b4a.objects.PanelWrapper();
_pnladdnew = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private txtDescription,txtTime As B4XFloatTextFie";
_txtdescription = new sadLogic.HomeCentral.b4xfloattextfield();
_txttime = new sadLogic.HomeCentral.b4xfloattextfield();
 //BA.debugLineNum = 33;BA.debugLine="Private btnNewSave,btnNewCancel As Button";
_btnnewsave = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnnewcancel = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private oLV_helper As listViewSelector";
_olv_helper = new sadLogic.HomeCentral.listviewselector();
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dialog) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 41;BA.debugLine="Public Sub Initialize(Dialog As B4XDialog)";
 //BA.debugLineNum = 42;BA.debugLine="dlg = Dialog";
_dlg = _dialog;
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _loaddata() throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Private Sub LoadData()";
 //BA.debugLineNum = 89;BA.debugLine="vol_timers.SelectItemInCBO(cboSounds,Main.kvs.Get";
_vol_timers._selectitemincbo /*String*/ (ba,_cbosounds,BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_timers_alarm_file /*String*/ )));
 //BA.debugLineNum = 90;BA.debugLine="LoadGrid";
_loadgrid();
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public String  _loadgrid() throws Exception{
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor = null;
int _i = 0;
 //BA.debugLineNum = 93;BA.debugLine="Private Sub LoadGrid";
 //BA.debugLineNum = 94;BA.debugLine="lstPresets.Clear";
_lstpresets.Clear();
 //BA.debugLineNum = 95;BA.debugLine="Dim cursor As Cursor = kt.timers_get_all";
_cursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
_cursor = _kt._timers_get_all /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ (ba);
 //BA.debugLineNum = 96;BA.debugLine="For i = 0 To cursor.RowCount - 1";
{
final int step3 = 1;
final int limit3 = (int) (_cursor.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
 //BA.debugLineNum = 97;BA.debugLine="cursor.Position = i";
_cursor.setPosition(_i);
 //BA.debugLineNum = 98;BA.debugLine="lstPresets.AddSingleLine2(cursor.GetString(\"time";
_lstpresets.AddSingleLine2(BA.ObjectToCharSequence(_cursor.GetString("time")+"-"+_cursor.GetString("description")),(Object)(_cursor.GetString("id")));
 }
};
 //BA.debugLineNum = 101;BA.debugLine="oLV_helper.	ProgrammaticallyClickAndHighlight(0)";
_olv_helper._programmaticallyclickandhighlight /*void*/ ((int) (0));
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _lstpresets_itemclick(int _position,Object _value) throws Exception{
 //BA.debugLineNum = 125;BA.debugLine="Sub lstPresets_ItemClick (Position As Int, Value A";
 //BA.debugLineNum = 126;BA.debugLine="oLV_helper.ItemClick (Position , Value )";
_olv_helper._itemclick /*String*/ (_position,_value);
 //BA.debugLineNum = 127;BA.debugLine="CurrentRecID = Value";
_currentrecid = (int)(BA.ObjectToNumber(_value));
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public String  _savedata() throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Private Sub SaveData()";
 //BA.debugLineNum = 107;BA.debugLine="vol_timers.SaveTimerVolume(cboSounds.SelectedItem";
_vol_timers._savetimervolume /*String*/ (ba,_cbosounds._getselecteditem /*String*/ (),_sbtimervol._getvalue /*int*/ ());
 //BA.debugLineNum = 108;BA.debugLine="CallSubDelayed(mpage.oPageCurrent,\"Build_Side_Men";
__c.CallSubDelayed(ba,_mpage._opagecurrent /*Object*/ ,"Build_Side_Menu");
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public String  _sbtimervol_valuechanged(int _value) throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Private Sub sbTimerVol_ValueChanged (Value As Int)";
 //BA.debugLineNum = 121;BA.debugLine="lblTmrVol.Text = Value & \"%\"";
_lbltmrvol.setText(BA.ObjectToCharSequence(BA.NumberToString(_value)+"%"));
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgsetuptimers parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgsetuptimers parent;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 48;BA.debugLine="dlg.Initialize((B4XPages.MainPage.Root))";
parent._dlg._initialize /*String*/ (ba,(parent._b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ));
 //BA.debugLineNum = 49;BA.debugLine="dlgHelper.Initialize(dlg)";
parent._dlghelper._initialize /*String*/ (ba,parent._dlg);
 //BA.debugLineNum = 51;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 52;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,  550dip,  480dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (550)),parent.__c.DipToCurrent((int) (480)));
 //BA.debugLineNum = 53;BA.debugLine="p.LoadLayout(\"viewSetupTimers\")";
_p.LoadLayout("viewSetupTimers",ba);
 //BA.debugLineNum = 57;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnAdd,btnR";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnadd.getObject())),(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnremove.getObject())),parent._btntest,parent._btnnewcancel,parent._btnnewsave});
 //BA.debugLineNum = 58;BA.debugLine="guiHelpers.ReSkinB4XComboBox(Array As B4XComboBox";
parent._guihelpers._reskinb4xcombobox /*String*/ (ba,new sadLogic.HomeCentral.b4xcombobox[]{parent._cbosounds});
 //BA.debugLineNum = 59;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(Label1,L";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._label1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._label3.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lbltmrvol.getObject()))},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 60;BA.debugLine="guiHelpers.ReSkinB4XSeekBar(Array As B4XSeekBar(s";
parent._guihelpers._reskinb4xseekbar /*String*/ (ba,new sadLogic.HomeCentral.b4xseekbar[]{parent._sbtimervol});
 //BA.debugLineNum = 61;BA.debugLine="guiHelpers.SetPanelsBorder(Array As B4XView(pnlTi";
parent._guihelpers._setpanelsborder /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._pnltimervol.getObject()))},parent._clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 62;BA.debugLine="guiHelpers.ResizeText(\"100%\",lblTmrVol)";
parent._guihelpers._resizetext /*String*/ (ba,"100%",parent._lbltmrvol);
 //BA.debugLineNum = 63;BA.debugLine="guiHelpers.SetTextColorB4XFloatTextField(Array As";
parent._guihelpers._settextcolorb4xfloattextfield /*String*/ (ba,new sadLogic.HomeCentral.b4xfloattextfield[]{parent._txtdescription,parent._txttime});
 //BA.debugLineNum = 66;BA.debugLine="sbTimerVol.Value 	= Main.kvs.Get(gblConst.INI_TIM";
parent._sbtimervol._setvalue /*int*/ ((int)(BA.ObjectToNumber(parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (parent._gblconst._ini_timers_alarm_volume /*String*/ ))));
 //BA.debugLineNum = 67;BA.debugLine="sbTimerVol_ValueChanged(sbTimerVol.Value)";
parent._sbtimervol_valuechanged(parent._sbtimervol._getvalue /*int*/ ());
 //BA.debugLineNum = 69;BA.debugLine="IME.Initialize(\"\")";
parent._ime.Initialize("");
 //BA.debugLineNum = 71;BA.debugLine="oLV_helper.Initialize(lstPresets)";
parent._olv_helper._initialize /*String*/ (ba,parent._lstpresets);
 //BA.debugLineNum = 72;BA.debugLine="LoadData";
parent._loaddata();
 //BA.debugLineNum = 74;BA.debugLine="dlgHelper.ThemeDialogForm(\"Timers Setup\")";
parent._dlghelper._themedialogform /*String*/ ((Object)("Timers Setup"));
 //BA.debugLineNum = 75;BA.debugLine="Dim rs As ResumableSub = dlg.ShowCustom(p, \"SAVE\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dlg._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("SAVE"),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 76;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
parent._dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 77;BA.debugLine="dlgHelper.NoCloseOn2ndDialog";
parent._dlghelper._nocloseon2nddialog /*String*/ ();
 //BA.debugLineNum = 78;BA.debugLine="btnTest.BringToFront";
parent._btntest.BringToFront();
 //BA.debugLineNum = 80;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 81;BA.debugLine="If Result = XUI.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 82;BA.debugLine="SaveData";
parent._savedata();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _showaddnew(boolean _showme) throws Exception{
ResumableSub_ShowAddNew rsub = new ResumableSub_ShowAddNew(this,_showme);
rsub.resume(ba, null);
}
public static class ResumableSub_ShowAddNew extends BA.ResumableSub {
public ResumableSub_ShowAddNew(sadLogic.HomeCentral.dlgsetuptimers parent,boolean _showme) {
this.parent = parent;
this._showme = _showme;
}
sadLogic.HomeCentral.dlgsetuptimers parent;
boolean _showme;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 190;BA.debugLine="pnlAddNew.Visible = ShowMe";
parent._pnladdnew.setVisible(_showme);
 //BA.debugLineNum = 191;BA.debugLine="pnlVolSnd.Visible = Not (ShowMe)";
parent._pnlvolsnd.setVisible(parent.__c.Not(_showme));
 //BA.debugLineNum = 192;BA.debugLine="guiHelpers.EnableDisableViews(Array As B4XView(bt";
parent._guihelpers._enabledisableviews /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{parent._btnadd,parent._btnremove,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._lstpresets.getObject()))},parent._pnlvolsnd.getVisible());
 //BA.debugLineNum = 193;BA.debugLine="If ShowMe Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_showme) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 194;BA.debugLine="pnlVolSnd.SendToBack";
parent._pnlvolsnd.SendToBack();
 //BA.debugLineNum = 195;BA.debugLine="pnlAddNew.BringToFront";
parent._pnladdnew.BringToFront();
 //BA.debugLineNum = 196;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_on /*int*/ ));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 198;BA.debugLine="pnlVolSnd.BringToFront";
parent._pnlvolsnd.BringToFront();
 //BA.debugLineNum = 199;BA.debugLine="pnlAddNew.SendToBack";
parent._pnladdnew.SendToBack();
 //BA.debugLineNum = 200;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR";
parent.__c.CallSubNew2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 202;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _showerrmsg(String _txt,sadLogic.HomeCentral.b4xfloattextfield _o) throws Exception{
ResumableSub_ShowErrMsg rsub = new ResumableSub_ShowErrMsg(this,_txt,_o);
rsub.resume(ba, null);
}
public static class ResumableSub_ShowErrMsg extends BA.ResumableSub {
public ResumableSub_ShowErrMsg(sadLogic.HomeCentral.dlgsetuptimers parent,String _txt,sadLogic.HomeCentral.b4xfloattextfield _o) {
this.parent = parent;
this._txt = _txt;
this._o = _o;
}
sadLogic.HomeCentral.dlgsetuptimers parent;
String _txt;
sadLogic.HomeCentral.b4xfloattextfield _o;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 184;BA.debugLine="guiHelpers.Show_toast2(txt,1500)";
parent._guihelpers._show_toast2 /*String*/ (ba,_txt,(int) (1500));
 //BA.debugLineNum = 185;BA.debugLine="Sleep(1500)";
parent.__c.Sleep(ba,this,(int) (1500));
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 186;BA.debugLine="o.RequestFocusAndShowKeyboard";
_o._requestfocusandshowkeyboard /*String*/ ();
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _validatetime(String _txt) throws Exception{
String[] _h = null;
int _x = 0;
 //BA.debugLineNum = 205;BA.debugLine="Private Sub ValidateTime(txt As String) As String";
 //BA.debugLineNum = 207;BA.debugLine="txt = txt.Trim";
_txt = _txt.trim();
 //BA.debugLineNum = 208;BA.debugLine="If fnct.CountChar(txt,\":\") <> 2 Then Return \"\"";
if (_fnct._countchar /*int*/ (ba,_txt,BA.ObjectToChar(":"))!=2) { 
if (true) return "";};
 //BA.debugLineNum = 209;BA.debugLine="Dim h() As String = Regex.Split(\":\",txt)";
_h = __c.Regex.Split(":",_txt);
 //BA.debugLineNum = 210;BA.debugLine="If h.Length <> 3 Then Return \"\"";
if (_h.length!=3) { 
if (true) return "";};
 //BA.debugLineNum = 211;BA.debugLine="For x = 0 To 2";
{
final int step5 = 1;
final int limit5 = (int) (2);
_x = (int) (0) ;
for (;_x <= limit5 ;_x = _x + step5 ) {
 //BA.debugLineNum = 212;BA.debugLine="If Not (IsNumber(h(x))) Then Return \"\"";
if (__c.Not(__c.IsNumber(_h[_x]))) { 
if (true) return "";};
 //BA.debugLineNum = 213;BA.debugLine="h(x) = kt.PadZero(h(x))";
_h[_x] = _kt._padzero /*String*/ (ba,(int)(Double.parseDouble(_h[_x])));
 }
};
 //BA.debugLineNum = 215;BA.debugLine="If h(0) > 23 Or h(1) > 59 Or h(2) > 23 Then Retur";
if ((double)(Double.parseDouble(_h[(int) (0)]))>23 || (double)(Double.parseDouble(_h[(int) (1)]))>59 || (double)(Double.parseDouble(_h[(int) (2)]))>23) { 
if (true) return "";};
 //BA.debugLineNum = 216;BA.debugLine="Return h(0) & \":\" & h(1) & \":\" & h(2)";
if (true) return _h[(int) (0)]+":"+_h[(int) (1)]+":"+_h[(int) (2)];
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
