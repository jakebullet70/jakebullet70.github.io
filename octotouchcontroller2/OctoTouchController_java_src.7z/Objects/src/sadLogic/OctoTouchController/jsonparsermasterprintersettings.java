package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jsonparsermasterprintersettings extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.jsonparsermasterprintersettings");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.jsonparsermasterprintersettings.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.collections.Map _mapheatingpresets = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private Const mModule As String = \"JsonParserMast";
_mmodule = "JsonParserMasterPrinterSettings";
 //BA.debugLineNum = 9;BA.debugLine="Public mapHeatingPresets As Map";
_mapheatingpresets = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _getpresetheatersettings(String _masterjsontxt) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Public Sub GetPresetHeaterSettings(MasterJsonTXT A";
 //BA.debugLineNum = 23;BA.debugLine="ParseMasterSettings(MasterJsonTXT)";
_parsemastersettings(_masterjsontxt);
 //BA.debugLineNum = 26;BA.debugLine="Return mapHeatingPresets";
if (true) return _mapheatingpresets;
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public String  _parsemastersettings(String _jsontxt) throws Exception{
String _insub = "";
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _temperature = null;
anywheresoftware.b4a.objects.collections.List _profiles = null;
anywheresoftware.b4a.objects.collections.Map _colprofiles = null;
String _pbedtemp = "";
String _pnamedesc = "";
String _pextrudertemp = "";
 //BA.debugLineNum = 31;BA.debugLine="Private Sub ParseMasterSettings(jsonTXT As String)";
 //BA.debugLineNum = 33;BA.debugLine="Dim inSub As String	= \"ParseMasterSettings\"";
_insub = "ParseMasterSettings";
 //BA.debugLineNum = 34;BA.debugLine="Dim parser As JSONParser : parser.Initialize(json";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 34;BA.debugLine="Dim parser As JSONParser : parser.Initialize(json";
_parser.Initialize(_jsontxt);
 //BA.debugLineNum = 36;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 39;BA.debugLine="Dim temperature As Map = root.Get(\"temperature\")";
_temperature = new anywheresoftware.b4a.objects.collections.Map();
_temperature = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("temperature"))));
 //BA.debugLineNum = 43;BA.debugLine="mapHeatingPresets.Initialize";
_mapheatingpresets.Initialize();
 //BA.debugLineNum = 44;BA.debugLine="Try";
try { //BA.debugLineNum = 45;BA.debugLine="Dim profiles As List = temperature.Get(\"profiles";
_profiles = new anywheresoftware.b4a.objects.collections.List();
_profiles = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_temperature.Get((Object)("profiles"))));
 //BA.debugLineNum = 46;BA.debugLine="For Each colprofiles As Map In profiles";
_colprofiles = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group9 = _profiles;
final int groupLen9 = group9.getSize()
;int index9 = 0;
;
for (; index9 < groupLen9;index9++){
_colprofiles = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(group9.Get(index9)));
 //BA.debugLineNum = 47;BA.debugLine="Dim pBedTemp As String = colprofiles.Get(\"bed\")";
_pbedtemp = BA.ObjectToString(_colprofiles.Get((Object)("bed")));
 //BA.debugLineNum = 49;BA.debugLine="Dim pNameDesc As String = colprofiles.Get(\"name";
_pnamedesc = BA.ObjectToString(_colprofiles.Get((Object)("name")));
 //BA.debugLineNum = 50;BA.debugLine="Dim pExtruderTemp As String = colprofiles.Get(\"";
_pextrudertemp = BA.ObjectToString(_colprofiles.Get((Object)("extruder")));
 //BA.debugLineNum = 51;BA.debugLine="mapHeatingPresets.Put(pNameDesc,pExtruderTemp &";
_mapheatingpresets.Put((Object)(_pnamedesc),(Object)(_pextrudertemp+"!!"+_pbedtemp));
 }
};
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 56;BA.debugLine="logMe.LogIt2(LastException,mModule,inSub)";
_logme._logit2 /*String*/ (getActivityBA(),BA.ObjectToString(__c.LastException(getActivityBA())),_mmodule,_insub);
 };
 //BA.debugLineNum = 60;BA.debugLine="Return";
if (true) return "";
 //BA.debugLineNum = 515;BA.debugLine="End Sub";
return "";
}
public String  _parseprinterprofile(String _jsontxt) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
anywheresoftware.b4a.objects.collections.Map _volume = null;
anywheresoftware.b4a.objects.collections.Map _extruder = null;
 //BA.debugLineNum = 521;BA.debugLine="Public Sub ParsePrinterProfile(jsonTXT As String)";
 //BA.debugLineNum = 523;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 524;BA.debugLine="parser.Initialize(jsonTXT)";
_parser.Initialize(_jsontxt);
 //BA.debugLineNum = 525;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 527;BA.debugLine="Try";
try { //BA.debugLineNum = 528;BA.debugLine="Dim volume As Map = root.Get(\"volume\")";
_volume = new anywheresoftware.b4a.objects.collections.Map();
_volume = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("volume"))));
 //BA.debugLineNum = 529;BA.debugLine="oc.PrinterWidth = volume.Get(\"width\")";
_oc._printerwidth /*double*/  = (double)(BA.ObjectToNumber(_volume.Get((Object)("width"))));
 //BA.debugLineNum = 530;BA.debugLine="oc.PrinterDepth = volume.Get(\"depth\")";
_oc._printerdepth /*double*/  = (double)(BA.ObjectToNumber(_volume.Get((Object)("depth"))));
 //BA.debugLineNum = 531;BA.debugLine="oc.PrinterCustomBoundingBox  = (volume.Get(\"cust";
_oc._printercustomboundingbox /*boolean*/  = ((BA.ObjectToBoolean(_volume.Get((Object)("custom_box")))));
 } 
       catch (Exception e10) {
			ba.setLastException(e10); //BA.debugLineNum = 533;BA.debugLine="oc.PrinterWidth = 0";
_oc._printerwidth /*double*/  = 0;
 //BA.debugLineNum = 534;BA.debugLine="oc.PrinterDepth = 0";
_oc._printerdepth /*double*/  = 0;
 //BA.debugLineNum = 535;BA.debugLine="Log(LastException)";
__c.LogImpl("34537486",BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 //BA.debugLineNum = 572;BA.debugLine="oc.PrinterProfileName = root.Get(\"name\")";
_oc._printerprofilename /*String*/  = BA.ObjectToString(_root.Get((Object)("name")));
 //BA.debugLineNum = 573;BA.debugLine="oc.PrinterProfileModel = root.Get(\"model\")";
_oc._printerprofilemodel /*String*/  = BA.ObjectToString(_root.Get((Object)("model")));
 //BA.debugLineNum = 575;BA.debugLine="Dim extruder As Map = root.Get(\"extruder\")";
_extruder = new anywheresoftware.b4a.objects.collections.Map();
_extruder = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_root.Get((Object)("extruder"))));
 //BA.debugLineNum = 584;BA.debugLine="oc.PrinterProfileNozzleCount = extruder.Get(\"coun";
_oc._printerprofilenozzlecount /*int*/  = (int)(BA.ObjectToNumber(_extruder.Get((Object)("count"))));
 //BA.debugLineNum = 586;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
