package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadclvselections extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.sadclvselections");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.sadclvselections.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _mode_single_item_temp = 0;
public int _mode_single_item_permanent = 0;
public int _mode_multiple_items = 0;
public int _mcurrentmode = 0;
public sadLogic.OctoTouchController.b4xset _selecteditems = null;
public int _selectioncolor = 0;
public b4a.example3.customlistview _mclv = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public int _unselectedcolor = 0;
public boolean _singlemode = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public MODE_SINGLE_ITEM_TEMP = 1, MODE_SINGLE_ITE";
_mode_single_item_temp = (int) (1);
_mode_single_item_permanent = (int) (2);
_mode_multiple_items = (int) (3);
 //BA.debugLineNum = 10;BA.debugLine="Private mCurrentMode As Int";
_mcurrentmode = 0;
 //BA.debugLineNum = 11;BA.debugLine="Public SelectedItems As B4XSet";
_selecteditems = new sadLogic.OctoTouchController.b4xset();
 //BA.debugLineNum = 12;BA.debugLine="Public SelectionColor As Int";
_selectioncolor = 0;
 //BA.debugLineNum = 13;BA.debugLine="Private mCLV As CustomListView";
_mclv = new b4a.example3.customlistview();
 //BA.debugLineNum = 14;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 15;BA.debugLine="Private UnselectedColor As Int = xui.Color_Transp";
_unselectedcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 16;BA.debugLine="Private SingleMode As Boolean";
_singlemode = false;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _clear() throws Exception{
int _i = 0;
 //BA.debugLineNum = 83;BA.debugLine="Public Sub Clear";
 //BA.debugLineNum = 84;BA.debugLine="If SelectedItems.Size = 0 Then Return";
if (_selecteditems._getsize /*int*/ ()==0) { 
if (true) return "";};
 //BA.debugLineNum = 85;BA.debugLine="For Each i As Int In SelectedItems.AsList";
{
final anywheresoftware.b4a.BA.IterableList group2 = _selecteditems._aslist /*anywheresoftware.b4a.objects.collections.List*/ ();
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_i = (int)(BA.ObjectToNumber(group2.Get(index2)));
 //BA.debugLineNum = 86;BA.debugLine="mCLV.GetPanel(i).Color = UnselectedColor";
_mclv._getpanel(_i).setColor(_unselectedcolor);
 }
};
 //BA.debugLineNum = 88;BA.debugLine="SelectedItems.Clear";
_selecteditems._clear /*String*/ ();
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public int  _getmode() throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Public Sub getMode As Int";
 //BA.debugLineNum = 63;BA.debugLine="Return mCurrentMode";
if (true) return _mcurrentmode;
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4a.example3.customlistview _clv) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize (CLV As CustomListView)";
 //BA.debugLineNum = 20;BA.debugLine="mCLV = CLV";
_mclv = _clv;
 //BA.debugLineNum = 21;BA.debugLine="SelectionColor = CLV.PressedColor";
_selectioncolor = _clv._pressedcolor;
 //BA.debugLineNum = 22;BA.debugLine="SelectedItems = B4XCollections.CreateSet";
_selecteditems = _b4xcollections._createset /*sadLogic.OctoTouchController.b4xset*/ (ba);
 //BA.debugLineNum = 23;BA.debugLine="mCurrentMode = MODE_SINGLE_ITEM_TEMP";
_mcurrentmode = _mode_single_item_temp;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _itemclicked(int _index) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Public Sub ItemClicked (Index As Int)";
 //BA.debugLineNum = 27;BA.debugLine="If mCurrentMode = MODE_SINGLE_ITEM_TEMP Then Retu";
if (_mcurrentmode==_mode_single_item_temp) { 
if (true) return "";};
 //BA.debugLineNum = 32;BA.debugLine="If SelectedItems.Contains(Index) And mCurrentMode";
if (_selecteditems._contains /*boolean*/ ((Object)(_index)) && _mcurrentmode!=_mode_single_item_permanent) { 
 //BA.debugLineNum = 33;BA.debugLine="SelectedItems.Remove(Index)";
_selecteditems._remove /*String*/ ((Object)(_index));
 //BA.debugLineNum = 34;BA.debugLine="mCLV.GetPanel(Index).Color = UnselectedColor";
_mclv._getpanel(_index).setColor(_unselectedcolor);
 }else {
 //BA.debugLineNum = 36;BA.debugLine="If SingleMode And SelectedItems.Size > 0 Then";
if (_singlemode && _selecteditems._getsize /*int*/ ()>0) { 
 //BA.debugLineNum = 37;BA.debugLine="Clear";
_clear();
 };
 //BA.debugLineNum = 39;BA.debugLine="mCLV.GetPanel(Index).Color = SelectionColor";
_mclv._getpanel(_index).setColor(_selectioncolor);
 //BA.debugLineNum = 40;BA.debugLine="SelectedItems.Add(Index)";
_selecteditems._add /*String*/ ((Object)(_index));
 };
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public String  _refresh() throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Public Sub Refresh";
 //BA.debugLineNum = 48;BA.debugLine="VisibleRangeChanged(0, mCLV.Size - 1)";
_visiblerangechanged((int) (0),(int) (_mclv._getsize()-1));
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public void  _selectandmakevisible(int _index) throws Exception{
ResumableSub_SelectAndMakeVisible rsub = new ResumableSub_SelectAndMakeVisible(this,_index);
rsub.resume(ba, null);
}
public static class ResumableSub_SelectAndMakeVisible extends BA.ResumableSub {
public ResumableSub_SelectAndMakeVisible(sadLogic.OctoTouchController.sadclvselections parent,int _index) {
this.parent = parent;
this._index = _index;
}
sadLogic.OctoTouchController.sadclvselections parent;
int _index;
int _target = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 92;BA.debugLine="Dim Target As Int = Max(0, Index - (mCLV.LastVisi";
_target = (int) (parent.__c.Max(0,_index-(parent._mclv._getlastvisibleindex()-parent._mclv._getfirstvisibleindex()-1)/(double)2));
 //BA.debugLineNum = 93;BA.debugLine="If mCurrentMode = MODE_SINGLE_ITEM_TEMP Then";
if (true) break;

case 1:
//if
this.state = 17;
if (parent._mcurrentmode==parent._mode_single_item_temp) { 
this.state = 3;
}else {
this.state = 9;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 94;BA.debugLine="If mCLV.FirstVisibleIndex > Index Or mCLV.LastVi";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._mclv._getfirstvisibleindex()>_index || parent._mclv._getlastvisibleindex()<_index) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 95;BA.debugLine="mCLV.JumpToItem(Target)";
parent._mclv._jumptoitem(_target);
 if (true) break;

case 7:
//C
this.state = 17;
;
 //BA.debugLineNum = 97;BA.debugLine="Dim p As B4XView = mCLV.GetPanel(Index)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._mclv._getpanel(_index);
 //BA.debugLineNum = 98;BA.debugLine="p.SetColorAnimated(50, UnselectedColor, Selectio";
_p.SetColorAnimated((int) (50),parent._unselectedcolor,parent._selectioncolor);
 //BA.debugLineNum = 99;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 18;
return;
case 18:
//C
this.state = 17;
;
 //BA.debugLineNum = 100;BA.debugLine="p.SetColorAnimated(200, SelectionColor, Unselect";
_p.SetColorAnimated((int) (200),parent._selectioncolor,parent._unselectedcolor);
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 102;BA.debugLine="If SelectedItems.Contains(Index) = False Then";
if (true) break;

case 10:
//if
this.state = 13;
if (parent._selecteditems._contains /*boolean*/ ((Object)(_index))==parent.__c.False) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 103;BA.debugLine="ItemClicked(Index)";
parent._itemclicked(_index);
 if (true) break;
;
 //BA.debugLineNum = 105;BA.debugLine="If mCLV.FirstVisibleIndex > Index Or mCLV.LastVi";

case 13:
//if
this.state = 16;
if (parent._mclv._getfirstvisibleindex()>_index || parent._mclv._getlastvisibleindex()<_index) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 106;BA.debugLine="mCLV.ScrollToItem(Target)";
parent._mclv._scrolltoitem(_target);
 if (true) break;

case 16:
//C
this.state = 17;
;
 if (true) break;

case 17:
//C
this.state = -1;
;
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _setmode(int _m) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Public Sub setMode (m As Int)";
 //BA.debugLineNum = 67;BA.debugLine="mCurrentMode = m";
_mcurrentmode = _m;
 //BA.debugLineNum = 68;BA.debugLine="Clear";
_clear();
 //BA.debugLineNum = 69;BA.debugLine="If mCurrentMode = MODE_SINGLE_ITEM_TEMP Then";
if (_mcurrentmode==_mode_single_item_temp) { 
 //BA.debugLineNum = 70;BA.debugLine="mCLV.PressedColor = SelectionColor";
_mclv._pressedcolor = _selectioncolor;
 }else {
 //BA.debugLineNum = 72;BA.debugLine="mCLV.PressedColor = xui.Color_Transparent";
_mclv._pressedcolor = _xui.Color_Transparent;
 };
 //BA.debugLineNum = 74;BA.debugLine="Select mCurrentMode";
switch (BA.switchObjectToInt(_mcurrentmode,_mode_single_item_permanent,_mode_multiple_items)) {
case 0: {
 //BA.debugLineNum = 76;BA.debugLine="SingleMode = True";
_singlemode = __c.True;
 break; }
case 1: {
 //BA.debugLineNum = 78;BA.debugLine="SingleMode = False";
_singlemode = __c.False;
 break; }
}
;
 //BA.debugLineNum = 80;BA.debugLine="Refresh";
_refresh();
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public String  _visiblerangechanged(int _firstindex,int _lastindex) throws Exception{
int _i = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
 //BA.debugLineNum = 51;BA.debugLine="Public Sub VisibleRangeChanged (FirstIndex As Int,";
 //BA.debugLineNum = 52;BA.debugLine="For i = Max(0, FirstIndex - 5) To Min(mCLV.Size -";
{
final int step1 = 1;
final int limit1 = (int) (__c.Min(_mclv._getsize()-1,_lastindex+5));
_i = (int) (__c.Max(0,_firstindex-5)) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 53;BA.debugLine="Dim p As B4XView = mCLV.GetPanel(i)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _mclv._getpanel(_i);
 //BA.debugLineNum = 54;BA.debugLine="If SelectedItems.Contains(i) Then";
if (_selecteditems._contains /*boolean*/ ((Object)(_i))) { 
 //BA.debugLineNum = 55;BA.debugLine="p.Color = SelectionColor";
_p.setColor(_selectioncolor);
 }else {
 //BA.debugLineNum = 57;BA.debugLine="p.Color = UnselectedColor";
_p.setColor(_unselectedcolor);
 };
 }
};
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
