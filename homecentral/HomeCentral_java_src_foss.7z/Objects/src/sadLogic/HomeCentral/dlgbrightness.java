package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgbrightness extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgbrightness");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgbrightness.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public Object _mcallback = null;
public String _meventname = "";
public sadLogic.HomeCentral.sadroundslider _sadroundslider1 = null;
public sadLogic.HomeCentral.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private const mModule As String = \"dlgBrightness\"";
_mmodule = "dlgBrightness";
 //BA.debugLineNum = 12;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 13;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 14;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 15;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 16;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 18;BA.debugLine="Private sadRoundSlider1 As sadRoundSlider";
_sadroundslider1 = new sadLogic.HomeCentral.sadroundslider();
 //BA.debugLineNum = 19;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 20;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 25;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,String _title,Object _callback,String _eventname,sadLogic.HomeCentral.b4xdialog _dlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 28;BA.debugLine="Public Sub Initialize(title As String, Callback As";
 //BA.debugLineNum = 29;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 30;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 31;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 32;BA.debugLine="mDialog = dlg";
_mdialog = _dlg;
 //BA.debugLineNum = 33;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public void  _show(int _defaultvalue) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_defaultvalue);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgbrightness parent,int _defaultvalue) {
this.parent = parent;
this._defaultvalue = _defaultvalue;
}
sadLogic.HomeCentral.dlgbrightness parent;
int _defaultvalue;
sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _h = 0f;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 41;BA.debugLine="mDialog.Initialize(mpage.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 42;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 43;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 45;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 46;BA.debugLine="Dim h As Float = 380dip";
_h = (float) (parent.__c.DipToCurrent((int) (380)));
 //BA.debugLineNum = 48;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 380dip,h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (380)),(int) (_h));
 //BA.debugLineNum = 49;BA.debugLine="p.LoadLayout(\"viewRoundSlider\")";
_p.LoadLayout("viewRoundSlider",ba);
 //BA.debugLineNum = 51;BA.debugLine="pnlMain.Color = clrTheme.Background";
parent._pnlmain.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 52;BA.debugLine="sadRoundSlider1.Value = defaultValue";
parent._sadroundslider1._setvalue /*int*/ (_defaultvalue);
 //BA.debugLineNum = 53;BA.debugLine="sadRoundSlider1.xlbl.TextColor = clrTheme.Backgro";
parent._sadroundslider1._xlbl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setTextColor(parent._clrtheme._backgroundheader /*int*/ );
 //BA.debugLineNum = 54;BA.debugLine="sadRoundSlider1.xlbl.Font = xui.CreateDefaultFont";
parent._sadroundslider1._xlbl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setFont(parent._xui.CreateDefaultFont((float) (52)));
 //BA.debugLineNum = 55;BA.debugLine="sadRoundSlider1.ValueColor = clrTheme.Background2";
parent._sadroundslider1._valuecolor /*int*/  = parent._clrtheme._background2 /*int*/ ;
 //BA.debugLineNum = 56;BA.debugLine="sadRoundSlider1.SetCircleColor(clrTheme.Backgroun";
parent._sadroundslider1._setcirclecolor /*String*/ (parent._clrtheme._backgroundheader /*int*/ ,parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 57;BA.debugLine="sadRoundSlider1.SetThumbColor(clrTheme.Background";
parent._sadroundslider1._setthumbcolor /*String*/ (parent._clrtheme._backgroundheader /*int*/ ,parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 58;BA.debugLine="sadRoundSlider1.Draw";
parent._sadroundslider1._draw /*String*/ ();
 //BA.debugLineNum = 60;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 61;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"O";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("OK"),(Object)(""),(Object)("CANCEL"));
 //BA.debugLineNum = 62;BA.debugLine="dlgHelper.ThemeDialogBtnsResize";
_dlghelper._themedialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 64;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 65;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 66;BA.debugLine="CallSub2(mCallback,mEventName,sadRoundSlider1.Va";
parent.__c.CallSubNew2(ba,parent._mcallback,parent._meventname,(Object)(((float) (parent._sadroundslider1._getvalue /*int*/ ()))));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
