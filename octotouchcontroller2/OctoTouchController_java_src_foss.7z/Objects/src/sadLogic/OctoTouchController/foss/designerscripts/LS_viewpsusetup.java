package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewpsusetup{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)(0d));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("panel1").vw.setLeft((int)((50d / 100 * width) - (views.get("panel1").vw.getWidth() / 2)));
views.get("panel2").vw.setLeft((int)((50d / 100 * width) - (views.get("panel2").vw.getWidth() / 2)));
views.get("panel3").vw.setLeft((int)((50d / 100 * width) - (views.get("panel3").vw.getWidth() / 2)));
views.get("panel4").vw.setLeft((int)((50d / 100 * width) - (views.get("panel4").vw.getWidth() / 2)));
views.get("panel2").vw.setHeight((int)((100d / 100 * height)/4d));
views.get("panel3").vw.setHeight((int)((100d / 100 * height)/4d));
views.get("panel4").vw.setHeight((int)((100d / 100 * height)/4d));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("panel2").vw.setLeft((int)(0d));
views.get("panel2").vw.setWidth((int)((views.get("pnlmain").vw.getWidth()) - (0d)));
views.get("panel3").vw.setLeft((int)(0d));
views.get("panel3").vw.setWidth((int)((views.get("pnlmain").vw.getWidth()) - (0d)));
views.get("panel4").vw.setLeft((int)(0d));
views.get("panel4").vw.setWidth((int)((views.get("pnlmain").vw.getWidth()) - (0d)));
views.get("swpsuocto").vw.setLeft((int)((2d * scale)));
views.get("swsonoff").vw.setLeft((int)((2d * scale)));
views.get("lblpsuinfo2").vw.setLeft((int)((views.get("swpsuocto").vw.getLeft() + views.get("swpsuocto").vw.getWidth())));
views.get("lblpsuinfo2").vw.setWidth((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - ((views.get("swpsuocto").vw.getLeft() + views.get("swpsuocto").vw.getWidth()))));
views.get("lblsonoffinfo2").vw.setLeft((int)((views.get("lblpsuinfo2").vw.getLeft())));
views.get("lblsonoffinfo2").vw.setWidth((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - ((views.get("lblpsuinfo2").vw.getLeft()))));
views.get("txtprinterip").vw.setWidth((int)((views.get("panel4").vw.getWidth())-(12d * scale)));
;};

}
}