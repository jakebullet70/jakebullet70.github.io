package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clock extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.clock");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.clock.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public boolean _donotshow = false;
public anywheresoftware.b4a.objects.Timer _tmrclock = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="Public DoNotShow As Boolean = False";
_donotshow = __c.False;
 //BA.debugLineNum = 10;BA.debugLine="Private tmrClock As Timer";
_tmrclock = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _formattime(long _t) throws Exception{
String _fmtd = "";
String _fmtt = "";
String _retme = "";
 //BA.debugLineNum = 48;BA.debugLine="Public Sub FormatTime(t As Long) As String";
 //BA.debugLineNum = 49;BA.debugLine="Dim fmtD As String = DateTime.DateFormat";
_fmtd = __c.DateTime.getDateFormat();
 //BA.debugLineNum = 50;BA.debugLine="Dim fmtT As String = DateTime.TimeFormat";
_fmtt = __c.DateTime.getTimeFormat();
 //BA.debugLineNum = 51;BA.debugLine="DateTime.TimeFormat = gblConst.LOCALE_CLOCK";
__c.DateTime.setTimeFormat(_gblconst._locale_clock /*String*/ );
 //BA.debugLineNum = 52;BA.debugLine="DateTime.DateFormat = \"\"";
__c.DateTime.setDateFormat("");
 //BA.debugLineNum = 54;BA.debugLine="Dim retMe As String = DateUtils.TicksToString(t)";
_retme = _dateutils._tickstostring(getActivityBA(),_t);
 //BA.debugLineNum = 56;BA.debugLine="DateTime.TimeFormat = fmtT";
__c.DateTime.setTimeFormat(_fmtt);
 //BA.debugLineNum = 57;BA.debugLine="DateTime.DateFormat = fmtD";
__c.DateTime.setDateFormat(_fmtd);
 //BA.debugLineNum = 59;BA.debugLine="Return retMe";
if (true) return _retme;
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
int _mn = 0;
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 15;BA.debugLine="Dim mn As Int = 1000 * 60";
_mn = (int) (1000*60);
 //BA.debugLineNum = 20;BA.debugLine="tmrClock.Initialize(\"tmrClock\",mn)";
_tmrclock.Initialize(ba,"tmrClock",(long) (_mn));
 //BA.debugLineNum = 21;BA.debugLine="StartClock";
_startclock();
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _startclock() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Public Sub StartClock()";
 //BA.debugLineNum = 32;BA.debugLine="tmrClock.Enabled = True";
_tmrclock.setEnabled(__c.True);
 //BA.debugLineNum = 33;BA.debugLine="Update_Scrn";
_update_scrn();
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public String  _stopclock() throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Public Sub StopClock()";
 //BA.debugLineNum = 29;BA.debugLine="tmrClock.Enabled = False";
_tmrclock.setEnabled(__c.False);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _tmrclock_tick() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Private Sub tmrClock_Tick";
 //BA.debugLineNum = 25;BA.debugLine="Update_Scrn";
_update_scrn();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _update_scrn() throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Public Sub Update_Scrn";
 //BA.debugLineNum = 37;BA.debugLine="If DoNotShow Then";
if (_donotshow) { 
 //BA.debugLineNum = 38;BA.debugLine="Log(\"Clock.Update_Scrn = DoNotShow\")";
__c.LogImpl("8650754","Clock.Update_Scrn = DoNotShow",0);
 //BA.debugLineNum = 39;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 43;BA.debugLine="B4XPages.MainPage.EventGbl.Raise2(gblConst.EVENT_";
_b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (getActivityBA())._eventgbl /*sadLogic.HomeCentral.eventcontroller*/ ._raise2 /*String*/ (_gblconst._event_clock_change /*String*/ ,(Object)(_formattime(__c.DateTime.getNow())));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
