package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewmovementmm{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _bf="";
String _w1="";
String _h1="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmovemm").vw.setLeft((int)(0d));
views.get("pnlmovemm").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmovemm").vw.setTop((int)(0d));
views.get("pnlmovemm").vw.setHeight((int)((100d / 100 * height) - (0d)));
_bf = BA.NumberToString((18d * scale));
_w1 = BA.NumberToString((views.get("pnlmovemm").vw.getWidth())/2d-Double.parseDouble(_bf));
_h1 = BA.NumberToString((views.get("pnlmovemm").vw.getHeight())/2d-Double.parseDouble(_bf));
views.get("btnmovemm0").vw.setWidth((int)(Double.parseDouble(_w1)));
views.get("btnmovemm0").vw.setHeight((int)(Double.parseDouble(_h1)));
views.get("btnmovemm0").vw.setTop((int)((views.get("pnlmovemm").vw.getHeight())/4d - (views.get("btnmovemm0").vw.getHeight() / 2)));
views.get("btnmovemm1").vw.setWidth((int)(Double.parseDouble(_w1)));
views.get("btnmovemm1").vw.setHeight((int)(Double.parseDouble(_h1)));
views.get("btnmovemm1").vw.setTop((int)((views.get("pnlmovemm").vw.getHeight())/4d - (views.get("btnmovemm1").vw.getHeight() / 2)));
views.get("btnmovemm1").vw.setLeft((int)((views.get("pnlmovemm").vw.getWidth())-(Double.parseDouble(_bf)/2d) - (views.get("btnmovemm1").vw.getWidth())));
views.get("btnmovemm2").vw.setWidth((int)(Double.parseDouble(_w1)));
views.get("btnmovemm2").vw.setHeight((int)(Double.parseDouble(_h1)));
views.get("btnmovemm2").vw.setTop((int)((views.get("pnlmovemm").vw.getTop() + views.get("pnlmovemm").vw.getHeight())-Double.parseDouble(_bf)/2d - (views.get("btnmovemm2").vw.getHeight())));
views.get("btnmovemm2").vw.setLeft((int)((views.get("btnmovemm0").vw.getLeft())));
views.get("btnmovemm3").vw.setWidth((int)(Double.parseDouble(_w1)));
views.get("btnmovemm3").vw.setHeight((int)(Double.parseDouble(_h1)));
views.get("btnmovemm3").vw.setTop((int)((views.get("pnlmovemm").vw.getTop() + views.get("pnlmovemm").vw.getHeight())-Double.parseDouble(_bf)/2d - (views.get("btnmovemm3").vw.getHeight())));
views.get("btnmovemm3").vw.setLeft((int)((views.get("btnmovemm1").vw.getLeft())));

}
}