package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgfilamentctrl extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgfilamentctrl");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgfilamentctrl.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.OctoTouchController.foss.soundsbeeps _obeepme = null;
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.OctoTouchController.foss.autotextsizelabel _lblstatus = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnstuff = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltemp = null;
public boolean _mtmroff = false;
public String _mloadunload = "";
public anywheresoftware.b4a.objects.collections.Map _mdata = null;
public String _tmp = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlworking = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnunload = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnload = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpark = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnheat = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chkheatoff = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnback = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsetup = null;
public boolean _pcalledm600weareprinting = false;
public anywheresoftware.b4a.objects.ButtonWrapper _btnhome = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public String  _btnctrl_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _btn = null;
 //BA.debugLineNum = 342;BA.debugLine="Private Sub btnCtrl_Click";
 //BA.debugLineNum = 343;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 343;BA.debugLine="Dim btn As B4XView : btn = Sender";
_btn = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 344;BA.debugLine="mLoadUnload = \"\" : mTmrOff = True";
_mloadunload = "";
 //BA.debugLineNum = 344;BA.debugLine="mLoadUnload = \"\" : mTmrOff = True";
_mtmroff = __c.True;
 //BA.debugLineNum = 345;BA.debugLine="btnStuff.Text = \"Continue\" ': btnStuff.Visible =";
_btnstuff.setText(BA.ObjectToCharSequence("Continue"));
 //BA.debugLineNum = 346;BA.debugLine="Select Case btn.Tag";
switch (BA.switchObjectToInt(_btn.getTag(),(Object)("ht"),(Object)("pk"),(Object)("ld"),(Object)("ul"),(Object)("bk"))) {
case 0: {
 //BA.debugLineNum = 347;BA.debugLine="Case \"ht\" 	: PromptHeater";
_promptheater();
 break; }
case 1: {
 //BA.debugLineNum = 348;BA.debugLine="Case \"pk\"	: ParkNozzle";
_parknozzle();
 break; }
case 2: {
 //BA.debugLineNum = 350;BA.debugLine="mLoadUnload = \"load\"";
_mloadunload = "load";
 //BA.debugLineNum = 351;BA.debugLine="ShowWorkingPnl";
_showworkingpnl();
 break; }
case 3: {
 //BA.debugLineNum = 354;BA.debugLine="ShowWorkingPnl";
_showworkingpnl();
 break; }
case 4: {
 //BA.debugLineNum = 357;BA.debugLine="ShowMainPnl";
_showmainpnl();
 break; }
}
;
 //BA.debugLineNum = 360;BA.debugLine="End Sub";
return "";
}
public String  _btnhome_click() throws Exception{
 //BA.debugLineNum = 441;BA.debugLine="Private Sub btnHome_Click";
 //BA.debugLineNum = 442;BA.debugLine="SendMGcode(\"G28\")";
_sendmgcode("G28");
 //BA.debugLineNum = 443;BA.debugLine="End Sub";
return "";
}
public String  _btnsetup_click() throws Exception{
 //BA.debugLineNum = 436;BA.debugLine="Private Sub btnSetup_Click";
 //BA.debugLineNum = 437;BA.debugLine="mMainObj.pDlgFilSetup.Initialize";
_mmainobj._pdlgfilsetup /*sadLogic.OctoTouchController.foss.dlgfilamentsetup*/ ._initialize /*Object*/ (ba);
 //BA.debugLineNum = 438;BA.debugLine="mMainObj.pDlgFilSetup.Show";
_mmainobj._pdlgfilsetup /*sadLogic.OctoTouchController.foss.dlgfilamentsetup*/ ._show /*void*/ ();
 //BA.debugLineNum = 439;BA.debugLine="End Sub";
return "";
}
public void  _btnstuff_click() throws Exception{
ResumableSub_btnStuff_Click rsub = new ResumableSub_btnStuff_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnStuff_Click extends BA.ResumableSub {
public ResumableSub_btnStuff_Click(sadLogic.OctoTouchController.foss.dlgfilamentctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgfilamentctrl parent;
String _insub = "";
String _not_set_up = "";
String[] _alen = null;
String _speeds = "";
String _speed1 = "";
String _speed2 = "";
String _slen = "";
boolean _first = false;
String _partlen = "";
int _islast = 0;
String[] group52;
int index52;
int groupLen52;
String[] group83;
int index83;
int groupLen83;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 171;BA.debugLine="Dim inSub As String = \"btnStuff_Click\"";
_insub = "btnStuff_Click";
 //BA.debugLineNum = 174;BA.debugLine="If btnStuff.Text.StartsWith(\"E\") Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._btnstuff.getText().startsWith("E")) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 175;BA.debugLine="SendMGcode(\"G1 E10 F60\") '--- Extrude 10mm more";
parent._sendmgcode("G1 E10 F60");
 //BA.debugLineNum = 176;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Extruding 10mm..."),(Object)(1000));
 //BA.debugLineNum = 177;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 181;BA.debugLine="Dim NOT_SET_UP As String = \"Filament load / unloa";
_not_set_up = "Filament load / unload wizard not setup";
 //BA.debugLineNum = 185;BA.debugLine="Dim aLen() As String, speeds As String";
_alen = new String[(int) (0)];
java.util.Arrays.fill(_alen,"");
_speeds = "";
 //BA.debugLineNum = 186;BA.debugLine="If mLoadUnload = \"load\" Then";
if (true) break;

case 5:
//if
this.state = 10;
if ((parent._mloadunload).equals("load")) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 187;BA.debugLine="speeds = mData.Get(gblConst.filLoadSpeed)";
_speeds = BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filloadspeed /*String*/ )));
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 189;BA.debugLine="speeds = mData.Get(gblConst.filUnLoadSpeed)";
_speeds = BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filunloadspeed /*String*/ )));
 if (true) break;
;
 //BA.debugLineNum = 192;BA.debugLine="If strHelpers.IsNullOrEmpty(speeds) Then";

case 10:
//if
this.state = 13;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,_speeds)) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 193;BA.debugLine="guiHelpers.Show_toast2(NOT_SET_UP,3000)";
parent._guihelpers._show_toast2 /*String*/ (ba,_not_set_up,(int) (3000));
 //BA.debugLineNum = 194;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 197;BA.debugLine="Try";

case 13:
//try
this.state = 27;
this.catchState = 26;
this.state = 15;
if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 26;
 //BA.debugLineNum = 198;BA.debugLine="Dim speed1, speed2 As String";
_speed1 = "";
_speed2 = "";
 //BA.debugLineNum = 199;BA.debugLine="If mData.Get(gblConst.filUnLoadSpeed).As(String)";
if (true) break;

case 16:
//if
this.state = 21;
if ((BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filunloadspeed /*String*/ )))).contains(",")) { 
this.state = 18;
}else {
this.state = 20;
}if (true) break;

case 18:
//C
this.state = 21;
 //BA.debugLineNum = 200;BA.debugLine="speed1 = Regex.split(\",\", speeds)(0)";
_speed1 = parent.__c.Regex.Split(",",_speeds)[(int) (0)];
 //BA.debugLineNum = 201;BA.debugLine="speed2 = Regex.split(\",\", speeds)(1)";
_speed2 = parent.__c.Regex.Split(",",_speeds)[(int) (1)];
 if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 203;BA.debugLine="speed1 = mData.Get(gblConst.filUnLoadSpeed)";
_speed1 = BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filunloadspeed /*String*/ )));
 //BA.debugLineNum = 204;BA.debugLine="speed2 = speed1";
_speed2 = _speed1;
 if (true) break;
;
 //BA.debugLineNum = 206;BA.debugLine="If strHelpers.IsNullOrEmpty(speed1) Then";

case 21:
//if
this.state = 24;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,_speed1)) { 
this.state = 23;
}if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 207;BA.debugLine="guiHelpers.Show_toast2(NOT_SET_UP,3000)";
parent._guihelpers._show_toast2 /*String*/ (ba,_not_set_up,(int) (3000));
 //BA.debugLineNum = 208;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 24:
//C
this.state = 27;
;
 if (true) break;

case 26:
//C
this.state = 27;
this.catchState = 0;
 //BA.debugLineNum = 212;BA.debugLine="guiHelpers.Show_toast2(NOT_SET_UP,3000)";
parent._guihelpers._show_toast2 /*String*/ (ba,_not_set_up,(int) (3000));
 //BA.debugLineNum = 214;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,inSub";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,_insub);
 //BA.debugLineNum = 218;BA.debugLine="Return";
if (true) return ;
 if (true) break;
if (true) break;

case 27:
//C
this.state = 28;
this.catchState = 0;
;
 //BA.debugLineNum = 222;BA.debugLine="Dim sLen As String, first As Boolean = True";
_slen = "";
_first = parent.__c.True;
 //BA.debugLineNum = 223;BA.debugLine="If mLoadUnload <> \"load\" Then";
if (true) break;

case 28:
//if
this.state = 72;
if ((parent._mloadunload).equals("load") == false) { 
this.state = 30;
}else {
this.state = 55;
}if (true) break;

case 30:
//C
this.state = 31;
 //BA.debugLineNum = 225;BA.debugLine="Try";
if (true) break;

case 31:
//try
this.state = 53;
this.catchState = 52;
this.state = 33;
if (true) break;

case 33:
//C
this.state = 34;
this.catchState = 52;
 //BA.debugLineNum = 228;BA.debugLine="btnStuff.Visible = False";
parent._btnstuff.setVisible(parent.__c.False);
 //BA.debugLineNum = 229;BA.debugLine="SendMGcode(\"M117 UnLoading filament\")";
parent._sendmgcode("M117 UnLoading filament");
 //BA.debugLineNum = 230;BA.debugLine="SetStatusLabel(\"UnLoad filament\") : Sleep(200)";
parent._setstatuslabel("UnLoad filament");
 //BA.debugLineNum = 230;BA.debugLine="SetStatusLabel(\"UnLoad filament\") : Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 73;
return;
case 73:
//C
this.state = 34;
;
 //BA.debugLineNum = 231;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent._sendmgcode("M83");
 //BA.debugLineNum = 231;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 74;
return;
case 74:
//C
this.state = 34;
;
 //BA.debugLineNum = 233;BA.debugLine="If mData.Get(gblConst.filSmallExtBeforeUload).A";
if (true) break;

case 34:
//if
this.state = 37;
if ((BA.ObjectToBoolean(parent._mdata.Get((Object)(parent._gblconst._filsmallextbeforeuload /*String*/ ))))==parent.__c.True) { 
this.state = 36;
}if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 234;BA.debugLine="SendMGcode($\"G1 E5 F${speed1}\"$) : Sleep(500)";
parent._sendmgcode(("G1 E5 F"+parent.__c.SmartStringFormatter("",(Object)(_speed1))+""));
 //BA.debugLineNum = 234;BA.debugLine="SendMGcode($\"G1 E5 F${speed1}\"$) : Sleep(500)";
parent.__c.Sleep(ba,this,(int) (500));
this.state = 75;
return;
case 75:
//C
this.state = 37;
;
 if (true) break;

case 37:
//C
this.state = 38;
;
 //BA.debugLineNum = 237;BA.debugLine="sLen = mData.Get(gblConst.filUnLoadLen)";
_slen = BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filunloadlen /*String*/ )));
 //BA.debugLineNum = 238;BA.debugLine="If sLen.Contains(\",\") Then '--- multi lengths a";
if (true) break;

case 38:
//if
this.state = 47;
if (_slen.contains(",")) { 
this.state = 40;
}else {
this.state = 46;
}if (true) break;

case 40:
//C
this.state = 41;
 //BA.debugLineNum = 239;BA.debugLine="aLen = Regex.Split(\",\",sLen)";
_alen = parent.__c.Regex.Split(",",_slen);
 //BA.debugLineNum = 240;BA.debugLine="For Each partLen As String In aLen";
if (true) break;

case 41:
//for
this.state = 44;
group52 = _alen;
index52 = 0;
groupLen52 = group52.length;
this.state = 76;
if (true) break;

case 76:
//C
this.state = 44;
if (index52 < groupLen52) {
this.state = 43;
_partlen = group52[index52];}
if (true) break;

case 77:
//C
this.state = 76;
index52++;
if (true) break;

case 43:
//C
this.state = 77;
 //BA.debugLineNum = 241;BA.debugLine="SendMGcode($\"G1 E-${partLen} F${IIf(first,spe";
parent._sendmgcode(("G1 E-"+parent.__c.SmartStringFormatter("",(Object)(_partlen))+" F"+parent.__c.SmartStringFormatter("",((_first) ? ((Object)(_speed1)) : ((Object)(_speed2))))+""));
 //BA.debugLineNum = 241;BA.debugLine="SendMGcode($\"G1 E-${partLen} F${IIf(first,spe";
parent.__c.Sleep(ba,this,(int) (400));
this.state = 78;
return;
case 78:
//C
this.state = 77;
;
 //BA.debugLineNum = 242;BA.debugLine="first = False";
_first = parent.__c.False;
 if (true) break;
if (true) break;

case 44:
//C
this.state = 47;
;
 if (true) break;

case 46:
//C
this.state = 47;
 //BA.debugLineNum = 245;BA.debugLine="SendMGcode($\"G1 E-${sLen} F${speed2}\"$) : Slee";
parent._sendmgcode(("G1 E-"+parent.__c.SmartStringFormatter("",(Object)(_slen))+" F"+parent.__c.SmartStringFormatter("",(Object)(_speed2))+""));
 //BA.debugLineNum = 245;BA.debugLine="SendMGcode($\"G1 E-${sLen} F${speed2}\"$) : Slee";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 79;
return;
case 79:
//C
this.state = 47;
;
 if (true) break;
;
 //BA.debugLineNum = 248;BA.debugLine="If pCalledM600WeArePrinting = False Then";

case 47:
//if
this.state = 50;
if (parent._pcalledm600weareprinting==parent.__c.False) { 
this.state = 49;
}if (true) break;

case 49:
//C
this.state = 50;
 //BA.debugLineNum = 249;BA.debugLine="SendMGcode(\"M18 E\") : Sleep(100)";
parent._sendmgcode("M18 E");
 //BA.debugLineNum = 249;BA.debugLine="SendMGcode(\"M18 E\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 80;
return;
case 80:
//C
this.state = 50;
;
 if (true) break;

case 50:
//C
this.state = 53;
;
 if (true) break;

case 52:
//C
this.state = 53;
this.catchState = 0;
 //BA.debugLineNum = 253;BA.debugLine="guiHelpers.Show_toast2(LastException.Message,30";
parent._guihelpers._show_toast2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),(int) (3000));
 //BA.debugLineNum = 255;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,inSu";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,_insub);
 if (true) break;
if (true) break;

case 53:
//C
this.state = 72;
this.catchState = 0;
;
 //BA.debugLineNum = 261;BA.debugLine="Sleep(600)";
parent.__c.Sleep(ba,this,(int) (600));
this.state = 81;
return;
case 81:
//C
this.state = 72;
;
 //BA.debugLineNum = 262;BA.debugLine="ShowMainPnl";
parent._showmainpnl();
 if (true) break;

case 55:
//C
this.state = 56;
 //BA.debugLineNum = 266;BA.debugLine="Try";
if (true) break;

case 56:
//try
this.state = 71;
this.catchState = 70;
this.state = 58;
if (true) break;

case 58:
//C
this.state = 59;
this.catchState = 70;
 //BA.debugLineNum = 269;BA.debugLine="SetStatusLabel(\"Filament load\") : Sleep(100)";
parent._setstatuslabel("Filament load");
 //BA.debugLineNum = 269;BA.debugLine="SetStatusLabel(\"Filament load\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 82;
return;
case 82:
//C
this.state = 59;
;
 //BA.debugLineNum = 270;BA.debugLine="SendMGcode(\"M117 Load filament\")";
parent._sendmgcode("M117 Load filament");
 //BA.debugLineNum = 271;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent._sendmgcode("M83");
 //BA.debugLineNum = 271;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 83;
return;
case 83:
//C
this.state = 59;
;
 //BA.debugLineNum = 272;BA.debugLine="sLen = mData.Get(gblConst.filLoadLen)";
_slen = BA.ObjectToString(parent._mdata.Get((Object)(parent._gblconst._filloadlen /*String*/ )));
 //BA.debugLineNum = 273;BA.debugLine="Dim first As Boolean = True";
_first = parent.__c.True;
 //BA.debugLineNum = 274;BA.debugLine="If sLen.Contains(\",\") Then '--- multi lengths a";
if (true) break;

case 59:
//if
this.state = 68;
if (_slen.contains(",")) { 
this.state = 61;
}else {
this.state = 67;
}if (true) break;

case 61:
//C
this.state = 62;
 //BA.debugLineNum = 275;BA.debugLine="aLen = Regex.Split(\",\",sLen)";
_alen = parent.__c.Regex.Split(",",_slen);
 //BA.debugLineNum = 276;BA.debugLine="Dim isLast As Int = 0";
_islast = (int) (0);
 //BA.debugLineNum = 277;BA.debugLine="For Each partLen As String In aLen";
if (true) break;

case 62:
//for
this.state = 65;
group83 = _alen;
index83 = 0;
groupLen83 = group83.length;
this.state = 84;
if (true) break;

case 84:
//C
this.state = 65;
if (index83 < groupLen83) {
this.state = 64;
_partlen = group83[index83];}
if (true) break;

case 85:
//C
this.state = 84;
index83++;
if (true) break;

case 64:
//C
this.state = 85;
 //BA.debugLineNum = 278;BA.debugLine="SendMGcode($\"G1 E${partLen} F${IIf(isLast = a";
parent._sendmgcode(("G1 E"+parent.__c.SmartStringFormatter("",(Object)(_partlen))+" F"+parent.__c.SmartStringFormatter("",((_islast==_alen.length-1) ? ((Object)(_speed2)) : ((Object)(_speed1))))+""));
 //BA.debugLineNum = 278;BA.debugLine="SendMGcode($\"G1 E${partLen} F${IIf(isLast = a";
parent.__c.Sleep(ba,this,(int) (400));
this.state = 86;
return;
case 86:
//C
this.state = 85;
;
 //BA.debugLineNum = 279;BA.debugLine="isLast = isLast + 1";
_islast = (int) (_islast+1);
 if (true) break;
if (true) break;

case 65:
//C
this.state = 68;
;
 if (true) break;

case 67:
//C
this.state = 68;
 //BA.debugLineNum = 282;BA.debugLine="SendMGcode($\"G1 E${sLen} F${speed2}\"$) : Sleep";
parent._sendmgcode(("G1 E"+parent.__c.SmartStringFormatter("",(Object)(_slen))+" F"+parent.__c.SmartStringFormatter("",(Object)(_speed2))+""));
 //BA.debugLineNum = 282;BA.debugLine="SendMGcode($\"G1 E${sLen} F${speed2}\"$) : Sleep";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 87;
return;
case 87:
//C
this.state = 68;
;
 if (true) break;

case 68:
//C
this.state = 71;
;
 //BA.debugLineNum = 284;BA.debugLine="btnStuff.Text = \"Extrude\" & CRLF & \"10mm More\"";
parent._btnstuff.setText(BA.ObjectToCharSequence("Extrude"+parent.__c.CRLF+"10mm More"));
 if (true) break;

case 70:
//C
this.state = 71;
this.catchState = 0;
 //BA.debugLineNum = 287;BA.debugLine="guiHelpers.Show_toast2(LastException.Message,30";
parent._guihelpers._show_toast2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),(int) (3000));
 //BA.debugLineNum = 289;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,inSu";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,_insub);
 if (true) break;
if (true) break;

case 71:
//C
this.state = 72;
this.catchState = 0;
;
 if (true) break;

case 72:
//C
this.state = -1;
;
 //BA.debugLineNum = 298;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _buildchkbox() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Private Sub BuildChkbox";
 //BA.debugLineNum = 64;BA.debugLine="chkHeatOff.Initialize(\"TurnOffHeat\")";
_chkheatoff.Initialize(ba,"TurnOffHeat");
 //BA.debugLineNum = 65;BA.debugLine="chkHeatOff.Text = \" Heater off on close\"";
_chkheatoff.setText(BA.ObjectToCharSequence(" Heater off on close"));
 //BA.debugLineNum = 66;BA.debugLine="chkHeatOff.TextColor = clrTheme.txtNormal";
_chkheatoff.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 67;BA.debugLine="chkHeatOff.TextSize = 18";
_chkheatoff.setTextSize((float) (18));
 //BA.debugLineNum = 68;BA.debugLine="guiHelpers.SetCBDrawable(chkHeatOff, clrTheme.txt";
_guihelpers._setcbdrawable /*String*/ (ba,_chkheatoff,_clrtheme._txtnormal /*int*/ ,(int) (1),_clrtheme._txtnormal /*int*/ ,BA.ObjectToString(__c.Chr((int) (8730))),__c.Colors.LightGray,__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 69;BA.debugLine="mDialog.Base.AddView(chkHeatOff,10dip,mDialog.Bas";
_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .AddView((android.view.View)(_chkheatoff.getObject()),__c.DipToCurrent((int) (10)),(int) (_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getHeight()-__c.DipToCurrent((int) (50))),(int) ((_mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getWidth()-_mdialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel).getWidth()-__c.DipToCurrent((int) (16)))),__c.DipToCurrent((int) (36)));
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 48;BA.debugLine="pnlMain.Color = clrTheme.Background : pnlWorking.";
_pnlmain.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 48;BA.debugLine="pnlMain.Color = clrTheme.Background : pnlWorking.";
_pnlworking.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 50;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnUnload,b";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnunload,_btnload,_btnpark,_btnheat,_btnstuff,_btnsetup});
 //BA.debugLineNum = 51;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnUnload,";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnunload,_btnload,_btnpark,_btnheat,_btnstuff},(float) ((double)(Double.parseDouble(__c.NumberFormat2(_btnstuff.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))-(double)(BA.ObjectToNumber(((_guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 54;BA.debugLine="btnStuff.TextSize = btnStuff.TextSize - 2 '---";
_btnstuff.setTextSize((float) (_btnstuff.getTextSize()-2));
 //BA.debugLineNum = 56;BA.debugLine="guiHelpers.SkinButton_Pugin(Array As Button(btnBa";
_guihelpers._skinbutton_pugin /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(_btnback.getObject())),_btnsetup});
 //BA.debugLineNum = 57;BA.debugLine="btnBack.BringToFront";
_btnback.BringToFront();
 //BA.debugLineNum = 59;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblTemp,";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbltemp.getObject())),_lblstatus._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ()});
 //BA.debugLineNum = 60;BA.debugLine="ShowMainPnl";
_showmainpnl();
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private const mModule As String = \"dlgFilamentCtr";
_mmodule = "dlgFilamentCtrl";
 //BA.debugLineNum = 12;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 13;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 14;BA.debugLine="Private oBeepMe As SoundsBeeps";
_obeepme = new sadLogic.OctoTouchController.foss.soundsbeeps();
 //BA.debugLineNum = 16;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 17;BA.debugLine="Private pnlMain As B4XView, lblStatus As AutoText";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lblstatus = new sadLogic.OctoTouchController.foss.autotextsizelabel();
 //BA.debugLineNum = 18;BA.debugLine="Private btnStuff As Button, lblTemp As Label";
_btnstuff = new anywheresoftware.b4a.objects.ButtonWrapper();
_lbltemp = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private mTmrOff As Boolean = False, mLoadUnload A";
_mtmroff = __c.False;
_mloadunload = "";
 //BA.debugLineNum = 21;BA.debugLine="Private mData As Map, tmp As String";
_mdata = new anywheresoftware.b4a.objects.collections.Map();
_tmp = "";
 //BA.debugLineNum = 23;BA.debugLine="Private pnlWorking As B4XView";
_pnlworking = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private btnUnload,btnLoad,btnPark,btnHeat As Butt";
_btnunload = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnload = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpark = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnheat = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private chkHeatOff As CheckBox";
_chkheatoff = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private btnBack As B4XView";
_btnback = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private btnSetup As Button";
_btnsetup = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Public pCalledM600WeArePrinting As Boolean = Fals";
_pcalledm600weareprinting = __c.False;
 //BA.debugLineNum = 31;BA.debugLine="Private btnHome As Button";
_btnhome = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Public Sub Close_Me  '--- class method, called fro";
 //BA.debugLineNum = 43;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,boolean _calledm600weareprinting) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Initialize(CalledM600WeArePrinting As B";
 //BA.debugLineNum = 35;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba);
 //BA.debugLineNum = 36;BA.debugLine="mData = File.ReadMap(xui.DefaultFolder,gblConst.F";
_mdata = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._filament_change_file /*String*/ );
 //BA.debugLineNum = 37;BA.debugLine="oBeepMe.Initialize";
_obeepme._initialize /*String*/ (ba);
 //BA.debugLineNum = 38;BA.debugLine="pCalledM600WeArePrinting = CalledM600WeArePrintin";
_pcalledm600weareprinting = _calledm600weareprinting;
 //BA.debugLineNum = 39;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return null;
}
public String  _loadunloadfil() throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Private Sub LoadUnLoadFil";
 //BA.debugLineNum = 157;BA.debugLine="mData = File.ReadMap(xui.DefaultFolder,gblConst.F";
_mdata = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._filament_change_file /*String*/ );
 //BA.debugLineNum = 159;BA.debugLine="oBeepMe.Beeps(300,500,5)";
_obeepme._beeps /*void*/ ((long) (300),(long) (500),(int) (5));
 //BA.debugLineNum = 160;BA.debugLine="btnStuff.Visible = True";
_btnstuff.setVisible(__c.True);
 //BA.debugLineNum = 161;BA.debugLine="If mLoadUnload.ToLowerCase = \"load\" Then";
if ((_mloadunload.toLowerCase()).equals("load")) { 
 //BA.debugLineNum = 162;BA.debugLine="SetStatusLabel(\"Insert filament and touch the 'C";
_setstatuslabel("Insert filament and touch the 'Continue' button to load");
 }else {
 //BA.debugLineNum = 164;BA.debugLine="SetStatusLabel(\"Touch The 'Continue' button to s";
_setstatuslabel("Touch The 'Continue' button to start unload");
 };
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _parknozzle() throws Exception{
ResumableSub_ParkNozzle rsub = new ResumableSub_ParkNozzle(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ParkNozzle extends BA.ResumableSub {
public ResumableSub_ParkNozzle(sadLogic.OctoTouchController.foss.dlgfilamentctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgfilamentctrl parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 305;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\", \"";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Parking Nozzle..."),(Object)(2600));
 //BA.debugLineNum = 307;BA.debugLine="If mData.GetDefault(gblConst.filPauseBeforePark,F";
if (true) break;

case 1:
//if
this.state = 4;
if ((BA.ObjectToBoolean(parent._mdata.GetDefault((Object)(parent._gblconst._filpausebeforepark /*String*/ ),(Object)(parent.__c.False))))==parent.__c.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 308;BA.debugLine="SendMGcode(\"M0\") : Sleep(100)";
parent._sendmgcode("M0");
 //BA.debugLineNum = 308;BA.debugLine="SendMGcode(\"M0\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 12;
return;
case 12:
//C
this.state = 4;
;
 if (true) break;
;
 //BA.debugLineNum = 311;BA.debugLine="If mData.GetDefault(gblConst.filRetractBeforePark";

case 4:
//if
this.state = 7;
if ((BA.ObjectToBoolean(parent._mdata.GetDefault((Object)(parent._gblconst._filretractbeforepark /*String*/ ),(Object)(parent.__c.False))))==parent.__c.True) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 312;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent._sendmgcode("M83");
 //BA.debugLineNum = 312;BA.debugLine="SendMGcode(\"M83\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 13;
return;
case 13:
//C
this.state = 7;
;
 //BA.debugLineNum = 313;BA.debugLine="SendMGcode(\"G1 E-5 F50\") : Sleep(100)";
parent._sendmgcode("G1 E-5 F50");
 //BA.debugLineNum = 313;BA.debugLine="SendMGcode(\"G1 E-5 F50\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 14;
return;
case 14:
//C
this.state = 7;
;
 if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 316;BA.debugLine="SendMGcode(\"G91\") : Sleep(100)";
parent._sendmgcode("G91");
 //BA.debugLineNum = 316;BA.debugLine="SendMGcode(\"G91\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 15;
return;
case 15:
//C
this.state = 8;
;
 //BA.debugLineNum = 318;BA.debugLine="tmp = $\"G0 Z${mData.Get(gblConst.filZLiftRel)} F$";
parent._tmp = ("G0 Z"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._filzliftrel /*String*/ )))+" F"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._filparkspeed /*String*/ )))+"");
 //BA.debugLineNum = 319;BA.debugLine="SendMGcode(tmp) : Sleep(100)";
parent._sendmgcode(parent._tmp);
 //BA.debugLineNum = 319;BA.debugLine="SendMGcode(tmp) : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 16;
return;
case 16:
//C
this.state = 8;
;
 //BA.debugLineNum = 321;BA.debugLine="If mData.GetDefault(mData.Get(gblConst.filHomeBef";
if (true) break;

case 8:
//if
this.state = 11;
if ((BA.ObjectToBoolean(parent._mdata.GetDefault(parent._mdata.Get((Object)(parent._gblconst._filhomebeforepark /*String*/ )),(Object)(parent.__c.False))))==parent.__c.True) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 322;BA.debugLine="SendMGcode(\"G28 X0 Y0\") : Sleep(100)";
parent._sendmgcode("G28 X0 Y0");
 //BA.debugLineNum = 322;BA.debugLine="SendMGcode(\"G28 X0 Y0\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 17;
return;
case 17:
//C
this.state = 11;
;
 if (true) break;

case 11:
//C
this.state = -1;
;
 //BA.debugLineNum = 325;BA.debugLine="SendMGcode(\"G90\") : Sleep(100)";
parent._sendmgcode("G90");
 //BA.debugLineNum = 325;BA.debugLine="SendMGcode(\"G90\") : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 18;
return;
case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 327;BA.debugLine="tmp = $\"G0 Y${mData.Get(gblConst.filYPark)} X${mD";
parent._tmp = ("G0 Y"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._filypark /*String*/ )))+" X"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._filxpark /*String*/ )))+" F"+parent.__c.SmartStringFormatter("",parent._mdata.Get((Object)(parent._gblconst._filparkspeed /*String*/ )))+"");
 //BA.debugLineNum = 328;BA.debugLine="SendMGcode(tmp) : Sleep(100)";
parent._sendmgcode(parent._tmp);
 //BA.debugLineNum = 328;BA.debugLine="SendMGcode(tmp) : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 19;
return;
case 19:
//C
this.state = -1;
;
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _processheattempchange(String _value,Object _tag) throws Exception{
sadLogic.OctoTouchController.foss.heaterroutines _oo = null;
 //BA.debugLineNum = 392;BA.debugLine="Private Sub ProcessHeatTempChange(value As String,";
 //BA.debugLineNum = 395;BA.debugLine="If value.Length = 0 Then";
if (_value.length()==0) { 
 //BA.debugLineNum = 396;BA.debugLine="mTmrOff = True";
_mtmroff = __c.True;
 //BA.debugLineNum = 397;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 400;BA.debugLine="If value = \"ev\" Then";
if ((_value).equals("ev")) { 
 //BA.debugLineNum = 402;BA.debugLine="Dim oo As HeaterRoutines : oo.Initialize";
_oo = new sadLogic.OctoTouchController.foss.heaterroutines();
 //BA.debugLineNum = 402;BA.debugLine="Dim oo As HeaterRoutines : oo.Initialize";
_oo._initialize /*String*/ (ba);
 //BA.debugLineNum = 403;BA.debugLine="oo.ChangeTempTool";
_oo._changetemptool /*String*/ ();
 //BA.debugLineNum = 404;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 407;BA.debugLine="If value.EndsWith(\"off\") Then value = 0 '--- tool";
if (_value.endsWith("off")) { 
_value = BA.NumberToString(0);};
 //BA.debugLineNum = 408;BA.debugLine="If fnc.CheckTempRange(\"tool\", value) = False Then";
if (_fnc._checktemprange /*boolean*/ (ba,"tool",(int)(Double.parseDouble(_value)))==__c.False) { 
 //BA.debugLineNum = 409;BA.debugLine="guiHelpers.Show_toast(\"Invalid Temperature\",1800";
_guihelpers._show_toast /*String*/ (ba,"Invalid Temperature",(int) (1800));
 //BA.debugLineNum = 410;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 416;BA.debugLine="mMainObj.oMasterController.cn.PostRequest( _";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",_value).replace("!VAL1!",BA.NumberToString(0)));
 //BA.debugLineNum = 418;BA.debugLine="oc.Tool1Target = \"1\"";
_oc._tool1target /*String*/  = "1";
 //BA.debugLineNum = 421;BA.debugLine="If value = 0 Then";
if ((_value).equals(BA.NumberToString(0))) { 
 //BA.debugLineNum = 422;BA.debugLine="guiHelpers.Show_toast2(\"Tool turned off\",1200)";
_guihelpers._show_toast2 /*String*/ (ba,"Tool turned off",(int) (1200));
 }else {
 //BA.debugLineNum = 424;BA.debugLine="guiHelpers.Show_toast2(\"Tool set to: \" & value &";
_guihelpers._show_toast2 /*String*/ (ba,"Tool set to: "+_value+_gblconst._degree_symbol /*String*/ +"C",(int) (2200));
 };
 //BA.debugLineNum = 427;BA.debugLine="mTmrOff = False";
_mtmroff = __c.False;
 //BA.debugLineNum = 429;BA.debugLine="End Sub";
return "";
}
public void  _promptheater() throws Exception{
ResumableSub_PromptHeater rsub = new ResumableSub_PromptHeater(this);
rsub.resume(ba, null);
}
public static class ResumableSub_PromptHeater extends BA.ResumableSub {
public ResumableSub_PromptHeater(sadLogic.OctoTouchController.foss.dlgfilamentctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgfilamentctrl parent;
sadLogic.OctoTouchController.foss.dlglistbox _o1 = null;
String _value = "";
Object _tag = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 384;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.foss.dlglistbox();
 //BA.debugLineNum = 385;BA.debugLine="mMainObj.pObjCurrentDlg2 = o1.Initialize(\"Filamen";
parent._mmainobj._pobjcurrentdlg2 /*Object*/  = _o1._initialize /*Object*/ (ba,(Object)("Filament Change"),parent,"HeatTempChange_Tool",parent._mmainobj._pobjcurrentdlg2 /*Object*/ );
 //BA.debugLineNum = 386;BA.debugLine="o1.Show(250dip,270dip,mMainObj.oMasterController.";
_o1._show /*void*/ ((float) (parent.__c.DipToCurrent((int) (250))),(float) (parent.__c.DipToCurrent((int) (270))),parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._maptoolheatvaluesonly /*anywheresoftware.b4a.objects.collections.Map*/ );
 //BA.debugLineNum = 387;BA.debugLine="Wait For HeatTempChange_Tool(value As String, tag";
parent.__c.WaitFor("heattempchange_tool", ba, this, null);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_value = (String) result[0];
_tag = (Object) result[1];
;
 //BA.debugLineNum = 388;BA.debugLine="ProcessHeatTempChange(value,tag)";
parent._processheattempchange(_value,_tag);
 //BA.debugLineNum = 389;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _heattempchange_tool(String _value,Object _tag) throws Exception{
}
public String  _sendmgcode(String _code) throws Exception{
 //BA.debugLineNum = 333;BA.debugLine="Private Sub SendMGcode(code As String)";
 //BA.debugLineNum = 334;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cPOS";
_mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_oc._cpost_gcode_command /*String*/ .replace("!CMD!",_code));
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return "";
}
public String  _setstatuslabel(String _txt) throws Exception{
 //BA.debugLineNum = 338;BA.debugLine="Private Sub SetStatusLabel(txt As String)";
 //BA.debugLineNum = 339;BA.debugLine="lblStatus.Text = txt & CRLF";
_lblstatus._settext /*Object*/ ((Object)(_txt+__c.CRLF));
 //BA.debugLineNum = 340;BA.debugLine="End Sub";
return "";
}
public String  _settempmonitortimer() throws Exception{
 //BA.debugLineNum = 150;BA.debugLine="Private Sub SetTempMonitorTimer";
 //BA.debugLineNum = 151;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"tmrTe";
_main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ (this,"tmrTempCheck_Tick",(int) (1000));
 //BA.debugLineNum = 152;BA.debugLine="End Sub";
return "";
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgfilamentctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgfilamentctrl parent;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 81;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 82;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 83;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 85;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 88;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 89;BA.debugLine="p.SetLayoutAnimated(0, 0, 0,  _ 					IIf(guiHelp";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <6) ? ((Object)(parent.__c.DipToCurrent((int) (460)))) : ((Object)(parent.__c.DipToCurrent((int) (560))))))),(int)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <6) ? ((Object)(parent._guihelpers._maxverticalheight_landscape /*float*/ (ba))) : ((Object)(parent.__c.DipToCurrent((int) (280))))))));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 92;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 90%x, _ 							IIf(";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.PerXToCurrent((float) (90),ba),(int)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <5.1) ? ((Object)(parent.__c.DipToCurrent((int) (320)))) : ((Object)(parent.__c.DipToCurrent((int) (360))))))));
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 97;BA.debugLine="p.LoadLayout(\"viewFilamentCtrl\")";
_p.LoadLayout("viewFilamentCtrl",ba);
 //BA.debugLineNum = 98;BA.debugLine="BuildGUI";
parent._buildgui();
 //BA.debugLineNum = 100;BA.debugLine="dlgHelper.ThemeDialogForm(\"Filament Change\")";
_dlghelper._themedialogform /*String*/ ((Object)("Filament Change"));
 //BA.debugLineNum = 101;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 102;BA.debugLine="mDialog.Base.Parent.Tag = \"\" 'this will prevent t";
parent._mdialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getParent().setTag((Object)(""));
 //BA.debugLineNum = 104;BA.debugLine="If pCalledM600WeArePrinting = True Then";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._pcalledm600weareprinting==parent.__c.True) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 105;BA.debugLine="btnPark.Enabled = False";
parent._btnpark.setEnabled(parent.__c.False);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 107;BA.debugLine="BuildChkbox";
parent._buildchkbox();
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 110;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 112;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 17;
return;
case 17:
//C
this.state = 13;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 114;BA.debugLine="If pCalledM600WeArePrinting = False And chkHeatOf";
if (true) break;

case 13:
//if
this.state = 16;
if (parent._pcalledm600weareprinting==parent.__c.False && parent._chkheatoff.getChecked()) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 115;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Tool Heater Off"),(Object)(1600));
 //BA.debugLineNum = 116;BA.debugLine="mMainObj.oMasterController.cn.PostRequest(oc.cCM";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._ccmd_set_tool_temp /*String*/ .replace("!VAL0!",BA.NumberToString(0)).replace("!VAL1!",BA.NumberToString(0)));
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 119;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 120;BA.debugLine="CallSub(Main,\"Set_ScreenTmr\") '--- reset the powe";
parent.__c.CallSubNew(ba,(Object)(parent._main.getObject()),"Set_ScreenTmr");
 //BA.debugLineNum = 121;BA.debugLine="mTmrOff = True '--- if temp tmr is running will t";
parent._mtmroff = parent.__c.True;
 //BA.debugLineNum = 122;BA.debugLine="mMainObj.pObjCurrentDlg2 = Null";
parent._mmainobj._pobjcurrentdlg2 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 123;BA.debugLine="mMainObj.pObjCurrentDlg1 = Null";
parent._mmainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _showmainpnl() throws Exception{
 //BA.debugLineNum = 376;BA.debugLine="Private Sub ShowMainPnl";
 //BA.debugLineNum = 377;BA.debugLine="pnlMain.Visible = True : pnlWorking.Visible = Fal";
_pnlmain.setVisible(__c.True);
 //BA.debugLineNum = 377;BA.debugLine="pnlMain.Visible = True : pnlWorking.Visible = Fal";
_pnlworking.setVisible(__c.False);
 //BA.debugLineNum = 378;BA.debugLine="pnlMain.BringToFront";
_pnlmain.BringToFront();
 //BA.debugLineNum = 379;BA.debugLine="End Sub";
return "";
}
public String  _showworkingpnl() throws Exception{
String _tool_not_heating = "";
 //BA.debugLineNum = 362;BA.debugLine="Private Sub ShowWorkingPnl";
 //BA.debugLineNum = 363;BA.debugLine="Dim Const TOOL_NOT_HEATING As String = \"0\" & gblC";
_tool_not_heating = "0"+_gblconst._degree_symbol /*String*/ +"C";
 //BA.debugLineNum = 364;BA.debugLine="If oc.Tool1Target = TOOL_NOT_HEATING Then";
if ((_oc._tool1target /*String*/ ).equals(_tool_not_heating)) { 
 //BA.debugLineNum = 365;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
__c.CallSubDelayed3(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Tool heater not set"),(Object)(3000));
 //BA.debugLineNum = 366;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 368;BA.debugLine="lblTemp.Text = \"heating\"";
_lbltemp.setText(BA.ObjectToCharSequence("heating"));
 //BA.debugLineNum = 369;BA.debugLine="mTmrOff = False";
_mtmroff = __c.False;
 //BA.debugLineNum = 370;BA.debugLine="pnlMain.Visible = False : pnlWorking.Visible = Tr";
_pnlmain.setVisible(__c.False);
 //BA.debugLineNum = 370;BA.debugLine="pnlMain.Visible = False : pnlWorking.Visible = Tr";
_pnlworking.setVisible(__c.True);
 //BA.debugLineNum = 371;BA.debugLine="pnlWorking.BringToFront";
_pnlworking.BringToFront();
 //BA.debugLineNum = 372;BA.debugLine="btnStuff.Visible = False";
_btnstuff.setVisible(__c.False);
 //BA.debugLineNum = 373;BA.debugLine="SetStatusLabel(\"Waiting for temperature...\")";
_setstatuslabel("Waiting for temperature...");
 //BA.debugLineNum = 374;BA.debugLine="SetTempMonitorTimer '--- turn on the timer and mo";
_settempmonitortimer();
 //BA.debugLineNum = 375;BA.debugLine="End Sub";
return "";
}
public void  _tmrtempcheck_tick() throws Exception{
ResumableSub_tmrTempCheck_Tick rsub = new ResumableSub_tmrTempCheck_Tick(this);
rsub.resume(ba, null);
}
public static class ResumableSub_tmrTempCheck_Tick extends BA.ResumableSub {
public ResumableSub_tmrTempCheck_Tick(sadLogic.OctoTouchController.foss.dlgfilamentctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgfilamentctrl parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 133;BA.debugLine="If mTmrOff Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._mtmroff) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 134;BA.debugLine="lblTemp.Text = oc.Tool1Actual";
parent._lbltemp.setText(BA.ObjectToCharSequence(parent._oc._tool1actual /*String*/ ));
 //BA.debugLineNum = 136;BA.debugLine="If oc.Tool1TargetReal = 0 Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._oc._tool1targetreal /*float*/ ==0) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 137;BA.debugLine="SetTempMonitorTimer";
parent._settempmonitortimer();
 //BA.debugLineNum = 138;BA.debugLine="Return '--- waiting for target var to be set fro";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 141;BA.debugLine="If oc.Tool1ActualReal >= oc.Tool1TargetReal Then";

case 10:
//if
this.state = 15;
if (parent._oc._tool1actualreal /*float*/ >=parent._oc._tool1targetreal /*float*/ ) { 
this.state = 12;
}else {
this.state = 14;
}if (true) break;

case 12:
//C
this.state = 15;
 //BA.debugLineNum = 142;BA.debugLine="Sleep(999) '--- settle for a second";
parent.__c.Sleep(ba,this,(int) (999));
this.state = 16;
return;
case 16:
//C
this.state = 15;
;
 //BA.debugLineNum = 143;BA.debugLine="LoadUnLoadFil";
parent._loadunloadfil();
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 145;BA.debugLine="SetTempMonitorTimer";
parent._settempmonitortimer();
 if (true) break;

case 15:
//C
this.state = -1;
;
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _turnoffheat_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 74;BA.debugLine="Private Sub TurnOffHeat_CheckedChange(Checked As B";
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
