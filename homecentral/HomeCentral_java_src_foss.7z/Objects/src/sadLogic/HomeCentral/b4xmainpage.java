package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.bctoast _toast = null;
public sadLogic.HomeCentral.ddd _dutils = null;
public boolean _debuglog = false;
public boolean _promptexittwice = false;
public short _quietexitnow = (short)0;
public anywheresoftware.b4a.sql.SQL _sql = null;
public boolean _isinternetconnected = false;
public sadLogic.HomeCentral.eventcontroller _eventgbl = null;
public sadLogic.HomeCentral.sadcallsubutils _tmrtimercallsub = null;
public sadLogic.HomeCentral.powercontrol _powerctrl = null;
public boolean _take_over_power = false;
public sadLogic.HomeCentral.clsweatherdata _weatherdata = null;
public boolean _usemetric = false;
public boolean _usecel = false;
public sadLogic.HomeCentral.b4xdialog _dialog2 = null;
public sadLogic.HomeCentral.b4xdialog _dialog = null;
public sadLogic.HomeCentral.b4xdialog _dialogmsgbox = null;
public sadLogic.HomeCentral.sadpreferencesdialog _prefdlg = null;
public sadLogic.HomeCentral.clock _oclock = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbg = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnltimers = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlcalculator = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlhome = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlweather = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlconversions = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlphotos = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlweb = null;
public Object _opagecurrent = null;
public sadLogic.HomeCentral.pageweb _opageweb = null;
public sadLogic.HomeCentral.pageconversions _opageconversion = null;
public sadLogic.HomeCentral.pagephotos _opagephoto = null;
public sadLogic.HomeCentral.pagektimers _opagetimers = null;
public sadLogic.HomeCentral.pagecalculator _opagecalculator = null;
public sadLogic.HomeCentral.pagehome _opagehome = null;
public sadLogic.HomeCentral.pageweather _opageweather = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlheader = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgsoundbutton = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgmenubutton = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnhdrtxt1 = null;
public b4a.example3.customlistview _lvsidemenu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmenufooter = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsetupmaster = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnaboutme = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsidemenu = null;
public sadLogic.HomeCentral.assegmentedtab _segtabmenu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmnumenu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmenuhdrspacer2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmenuhdrspacer1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlscrnoff = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsidemenutouchoverlay = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnscreenoff = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _alarm_fired_before_start() throws Exception{
 //BA.debugLineNum = 496;BA.debugLine="Private Sub Alarm_Fired_Before_Start";
 //BA.debugLineNum = 497;BA.debugLine="Log(\"Alarm_Fired_Before_Start\")";
__c.LogImpl("7012353","Alarm_Fired_Before_Start",0);
 //BA.debugLineNum = 498;BA.debugLine="If PowerCtrl.IsScreenOff Then";
if (_powerctrl._isscreenoff /*boolean*/ ) { 
 //BA.debugLineNum = 499;BA.debugLine="pnlScrnOff_Click";
_pnlscrnoff_click();
 };
 //BA.debugLineNum = 503;BA.debugLine="IfPhotoShow_TurnOff";
_ifphotoshow_turnoff();
 //BA.debugLineNum = 505;BA.debugLine="End Sub";
return "";
}
public String  _alarm_fired_start(int _x) throws Exception{
 //BA.debugLineNum = 507;BA.debugLine="Public Sub Alarm_Fired_Start(x As Int)";
 //BA.debugLineNum = 508;BA.debugLine="Log(\"Alarm_Fired_Start\")";
__c.LogImpl("7077889","Alarm_Fired_Start",0);
 //BA.debugLineNum = 510;BA.debugLine="oPageTimers.AlarmStart(x)";
_opagetimers._alarmstart /*String*/ (_x);
 //BA.debugLineNum = 511;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _b4xpage_closerequest() throws Exception{
ResumableSub_B4XPage_CloseRequest rsub = new ResumableSub_B4XPage_CloseRequest(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_B4XPage_CloseRequest extends BA.ResumableSub {
public ResumableSub_B4XPage_CloseRequest(sadLogic.HomeCentral.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.HomeCentral.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 140;BA.debugLine="Log(\"B4XPage_CloseRequest\")";
parent.__c.LogImpl("5636097","B4XPage_CloseRequest",0);
 //BA.debugLineNum = 141;BA.debugLine="If CheckForVisibleDialogsAndClose = True Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._checkforvisibledialogsandclose()==parent.__c.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 142;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 145;BA.debugLine="If pnlSideMenu.Visible Then";

case 4:
//if
this.state = 7;
if (parent._pnlsidemenu.getVisible()) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 146;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
parent._pnlsidemenu.SetVisibleAnimated((int) (380),parent.__c.False);
 //BA.debugLineNum = 147;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
;
 //BA.debugLineNum = 150;BA.debugLine="If PromptExitTwice = False Then";

case 7:
//if
this.state = 10;
if (parent._promptexittwice==parent.__c.False) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 151;BA.debugLine="Show_Toast2(\"Tap again to exit\",2200)";
parent._show_toast2("Tap again to exit",(int) (2200));
 //BA.debugLineNum = 152;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Prompt_Ex";
parent._tmrtimercallsub._callsubdelayedplus /*String*/ (parent,"Prompt_Exit_Reset",(int) (2200));
 //BA.debugLineNum = 153;BA.debugLine="PromptExitTwice = True";
parent._promptexittwice = parent.__c.True;
 //BA.debugLineNum = 154;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 165;BA.debugLine="StopAllServicesOnExit";
parent._stopallservicesonexit();
 //BA.debugLineNum = 166;BA.debugLine="B4XPages.GetNativeParent(Me).Finish";
parent._b4xpages._getnativeparent /*anywheresoftware.b4a.objects.ActivityWrapper*/ (ba,parent).Finish();
 //BA.debugLineNum = 167;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 11;
return;
case 11:
//C
this.state = -1;
;
 //BA.debugLineNum = 169;BA.debugLine="Log(\"B4XPage_CloseRequest  end\")";
parent.__c.LogImpl("5636126","B4XPage_CloseRequest  end",0);
 //BA.debugLineNum = 170;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 102;BA.debugLine="Private Sub B4XPage_Created(Root1 As B4XView)";
 //BA.debugLineNum = 104;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 105;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 106;BA.debugLine="Toast.Initialize(Root)";
_toast._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 107;BA.debugLine="dUtils.Initialize '--- DDD desgner utils";
_dutils._initialize /*String*/ (ba);
 //BA.debugLineNum = 108;BA.debugLine="oClock.Initialize";
_oclock._initialize /*String*/ (ba);
 //BA.debugLineNum = 110;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 111;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 117;BA.debugLine="If config.Is1stRun Then CallSubDelayed(Me,\"Show_1";
if (_config._is1strun /*boolean*/ ) { 
__c.CallSubDelayed(ba,this,"Show_1stRun");};
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _btnaboutme_click() throws Exception{
sadLogic.HomeCentral.dlgabout _o = null;
 //BA.debugLineNum = 382;BA.debugLine="Private Sub btnAboutMe_Click";
 //BA.debugLineNum = 383;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
_pnlsidemenu.SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 384;BA.debugLine="Dim o As dlgAbout : o.Initialize(Dialog)";
_o = new sadLogic.HomeCentral.dlgabout();
 //BA.debugLineNum = 384;BA.debugLine="Dim o As dlgAbout : o.Initialize(Dialog)";
_o._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 385;BA.debugLine="o.Show";
_o._show /*void*/ ();
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return "";
}
public void  _btnhdrtxt1_click() throws Exception{
ResumableSub_btnHdrTxt1_Click rsub = new ResumableSub_btnHdrTxt1_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnHdrTxt1_Click extends BA.ResumableSub {
public ResumableSub_btnHdrTxt1_Click(sadLogic.HomeCentral.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.HomeCentral.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 351;BA.debugLine="QuietExitNow = QuietExitNow + 1";
parent._quietexitnow = (short) (parent._quietexitnow+1);
 //BA.debugLineNum = 352;BA.debugLine="If QuietExitNow > 3 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._quietexitnow>3) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 354;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 8;
return;
case 8:
//C
this.state = 4;
;
 //BA.debugLineNum = 358;BA.debugLine="Sleep(0):   StopAllServicesOnExit : Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 9;
return;
case 9:
//C
this.state = 4;
;
 //BA.debugLineNum = 358;BA.debugLine="Sleep(0):   StopAllServicesOnExit : Sleep(0)";
parent._stopallservicesonexit();
 //BA.debugLineNum = 358;BA.debugLine="Sleep(0):   StopAllServicesOnExit : Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 10;
return;
case 10:
//C
this.state = 4;
;
 //BA.debugLineNum = 359;BA.debugLine="B4XPages.ClosePage(Me) : Sleep(100)";
parent._b4xpages._closepage /*String*/ (ba,parent);
 //BA.debugLineNum = 359;BA.debugLine="B4XPages.ClosePage(Me) : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 11;
return;
case 11:
//C
this.state = 4;
;
 //BA.debugLineNum = 360;BA.debugLine="B4XPages.GetNativeParent(Me).Finish : Sleep(100)";
parent._b4xpages._getnativeparent /*anywheresoftware.b4a.objects.ActivityWrapper*/ (ba,parent).Finish();
 //BA.debugLineNum = 360;BA.debugLine="B4XPages.GetNativeParent(Me).Finish : Sleep(100)";
parent.__c.Sleep(ba,this,(int) (100));
this.state = 12;
return;
case 12:
//C
this.state = 4;
;
 //BA.debugLineNum = 361;BA.debugLine="ExitApplication";
parent.__c.ExitApplication();
 //BA.debugLineNum = 372;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 374;BA.debugLine="If tmrTimerCallSub.Exists(Me,\"Prompt_Exit_Quiet\")";

case 4:
//if
this.state = 7;
if (parent._tmrtimercallsub._exists /*anywheresoftware.b4a.objects.Timer*/ (parent,"Prompt_Exit_Quiet")== null) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 375;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Prompt_Ex";
parent._tmrtimercallsub._callsubdelayedplus /*String*/ (parent,"Prompt_Exit_Quiet",(int) (2200));
 if (true) break;

case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 377;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _btnscreenoff_click() throws Exception{
 //BA.debugLineNum = 679;BA.debugLine="Private Sub btnScreenOff_Click";
 //BA.debugLineNum = 680;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
_pnlsidemenu.SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 681;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
_pnlsidemenutouchoverlay_show(__c.False);
 //BA.debugLineNum = 682;BA.debugLine="TurnScreen_Off";
_turnscreen_off();
 //BA.debugLineNum = 683;BA.debugLine="End Sub";
return "";
}
public String  _btnsetupmaster_click() throws Exception{
sadLogic.HomeCentral.guimsgs _gui = null;
sadLogic.HomeCentral.dlglistbox _o1 = null;
 //BA.debugLineNum = 425;BA.debugLine="Private Sub btnSetupMaster_Click";
 //BA.debugLineNum = 427;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
_pnlsidemenu.SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 431;BA.debugLine="If oPageCurrent = oPageTimers Then";
if ((_opagecurrent).equals((Object)(_opagetimers))) { 
 //BA.debugLineNum = 432;BA.debugLine="SetupMainMenu_Event(\"tm\",Null) : Return";
_setupmainmenu_event("tm",__c.Null);
 //BA.debugLineNum = 432;BA.debugLine="SetupMainMenu_Event(\"tm\",Null) : Return";
if (true) return "";
 }else if((_opagecurrent).equals((Object)(_opageweather))) { 
 //BA.debugLineNum = 434;BA.debugLine="SetupMainMenu_Event(\"wth\",Null) : 	Return";
_setupmainmenu_event("wth",__c.Null);
 //BA.debugLineNum = 434;BA.debugLine="SetupMainMenu_Event(\"wth\",Null) : 	Return";
if (true) return "";
 }else if((_opagecurrent).equals((Object)(_opageweb))) { 
 //BA.debugLineNum = 436;BA.debugLine="SetupMainMenu_Event(\"wb\",Null) : Return";
_setupmainmenu_event("wb",__c.Null);
 //BA.debugLineNum = 436;BA.debugLine="SetupMainMenu_Event(\"wb\",Null) : Return";
if (true) return "";
 }else if((_opagecurrent).equals((Object)(_opagehome)) == false) { 
 //BA.debugLineNum = 438;BA.debugLine="guiHelpers.Show_toast(\"No setup for this page\")";
_guihelpers._show_toast /*String*/ (ba,"No setup for this page");
 //BA.debugLineNum = 439;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
_pnlsidemenutouchoverlay_show(__c.False);
 //BA.debugLineNum = 440;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 444;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.HomeCentral.guimsgs();
 //BA.debugLineNum = 444;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 445;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.HomeCentral.dlglistbox();
 //BA.debugLineNum = 447;BA.debugLine="o1.Initialize(\"Setup Menu\",Me,\"SetupMainMenu_Even";
_o1._initialize /*Object*/ (ba,(Object)("Setup Menu"),this,"SetupMainMenu_Event",_dialog);
 //BA.debugLineNum = 448;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 449;BA.debugLine="o1.Show(440dip,380dip,gui.BuildMainSetup())";
_o1._show /*void*/ ((float) (__c.DipToCurrent((int) (440))),(float) (__c.DipToCurrent((int) (380))),_gui._buildmainsetup /*anywheresoftware.b4a.objects.collections.Map*/ ());
 //BA.debugLineNum = 451;BA.debugLine="End Sub";
return "";
}
public void  _buildgui() throws Exception{
ResumableSub_BuildGUI rsub = new ResumableSub_BuildGUI(this);
rsub.resume(ba, null);
}
public static class ResumableSub_BuildGUI extends BA.ResumableSub {
public ResumableSub_BuildGUI(sadLogic.HomeCentral.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.HomeCentral.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 198;BA.debugLine="guiHelpers.SetVisible(Array As B4XView(pnlWEB,pnl";
parent._guihelpers._setvisible /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{parent._pnlweb,parent._pnltimers,parent._pnlsidemenu,parent._pnlweather,parent._pnlcalculator,parent._pnlconversions,parent._pnlphotos},parent.__c.False);
 //BA.debugLineNum = 199;BA.debugLine="pnlScrnOff.SetLayoutAnimated(0,0,0,100%x,100%y) '";
parent._pnlscrnoff.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.PerXToCurrent((float) (100),ba),parent.__c.PerYToCurrent((float) (100),ba));
 //BA.debugLineNum = 200;BA.debugLine="pnlScrnOff.Color = Colors.ARGB(255,0,0,0) '--- sc";
parent._pnlscrnoff.setColor(parent.__c.Colors.ARGB((int) (255),(int) (0),(int) (0),(int) (0)));
 //BA.debugLineNum = 201;BA.debugLine="pnlScrnOff_Click";
parent._pnlscrnoff_click();
 //BA.debugLineNum = 202;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
parent._pnlsidemenutouchoverlay_show(parent.__c.False);
 //BA.debugLineNum = 204;BA.debugLine="guiHelpers.SkinButtonNoBorder(Array As Button(btn";
parent._guihelpers._skinbuttonnoborder /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btnaboutme,parent._btnsetupmaster,(anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(parent._btnhdrtxt1.getObject())),parent._btnscreenoff});
 //BA.debugLineNum = 206;BA.debugLine="guiHelpers.ResizeText(\"<  Screen Off  >\",btnScree";
parent._guihelpers._resizetext /*String*/ (ba,"<  Screen Off  >",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent._btnscreenoff.getObject()))).getObject())));
 //BA.debugLineNum = 209;BA.debugLine="pnlBG.SetColorAndBorder(clrTheme.Background,0dip,";
parent._pnlbg.SetColorAndBorder(parent._clrtheme._background /*int*/ ,parent.__c.DipToCurrent((int) (0)),parent._xui.Color_Transparent,parent.__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 210;BA.debugLine="pnlMenuFooter.SetColorAndBorder(xui.Color_Transpa";
parent._pnlmenufooter.SetColorAndBorder(parent._xui.Color_Transparent,parent.__c.DipToCurrent((int) (0)),parent._xui.Color_Transparent,parent.__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 211;BA.debugLine="pnlSideMenu.SetColorAndBorder(clrTheme.Background";
parent._pnlsidemenu.SetColorAndBorder(parent._clrtheme._backgroundheader /*int*/ ,parent.__c.DipToCurrent((int) (2)),parent._clrtheme._background2 /*int*/ ,parent.__c.DipToCurrent((int) (4)));
 //BA.debugLineNum = 213;BA.debugLine="pnlMenuHdrSpacer1.SetColorAndBorder(clrTheme.Back";
parent._pnlmenuhdrspacer1.SetColorAndBorder(parent._clrtheme._background /*int*/ ,parent.__c.DipToCurrent((int) (1)),parent._clrtheme._background /*int*/ ,parent.__c.DipToCurrent((int) (3)));
 //BA.debugLineNum = 214;BA.debugLine="pnlMenuHdrSpacer2.SetColorAndBorder(clrTheme.Back";
parent._pnlmenuhdrspacer2.SetColorAndBorder(parent._clrtheme._background /*int*/ ,parent.__c.DipToCurrent((int) (1)),parent._clrtheme._background /*int*/ ,parent.__c.DipToCurrent((int) (3)));
 //BA.debugLineNum = 216;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblMnuMe";
parent._guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{parent._lblmnumenu},parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 218;BA.debugLine="Menus.Init";
parent._menus._init /*String*/ (ba);
 //BA.debugLineNum = 219;BA.debugLine="Menus.BuildHeaderMenu(segTabMenu,Me,\"segTabMenu\")";
parent._menus._buildheadermenu /*void*/ (ba,parent._segtabmenu,parent,"segTabMenu");
 //BA.debugLineNum = 221;BA.debugLine="pnlHeader.SetColorAndBorder(clrTheme.BackgroundHe";
parent._pnlheader.SetColorAndBorder(parent._clrtheme._backgroundheader /*int*/ ,(int) (0),parent._xui.Color_Transparent,(int) (0));
 //BA.debugLineNum = 223;BA.debugLine="imgMenuButton.Bitmap = guiHelpers.ChangeColorBase";
parent._imgmenubutton._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (parent._guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"main_menu_menu.png"),parent._clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 224;BA.debugLine="imgSoundButton.Bitmap = guiHelpers.ChangeColorBas";
parent._imgsoundbutton._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (parent._guihelpers._changecolorbasedonalphalevel /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ (ba,parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"main_menu_volume.png"),parent._clrtheme._txtnormal /*int*/ ));
 //BA.debugLineNum = 226;BA.debugLine="pnlSideMenuTouchOverlay.Width = pnlHome.Width - p";
parent._pnlsidemenutouchoverlay.setWidth((int) (parent._pnlhome.getWidth()-parent._pnlsidemenu.getWidth()));
 //BA.debugLineNum = 228;BA.debugLine="Toast.pnl.Color = clrTheme.txtNormal";
parent._toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 229;BA.debugLine="Toast.DefaultTextColor = clrTheme.BackgroundHeade";
parent._toast._defaulttextcolor /*int*/  = parent._clrtheme._backgroundheader /*int*/ ;
 //BA.debugLineNum = 230;BA.debugLine="Toast.MaxHeight = 120dip";
parent._toast._maxheight /*int*/  = parent.__c.DipToCurrent((int) (120));
 //BA.debugLineNum = 232;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 233;BA.debugLine="segTabMenu_TabChanged(-2)";
parent._segtabmenu_tabchanged((int) (-2));
 //BA.debugLineNum = 234;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Main,\"Dim_Acti";
parent._tmrtimercallsub._callsubdelayedplus /*String*/ ((Object)(parent._main.getObject()),"Dim_ActionBar_Off",(int) (300));
 //BA.debugLineNum = 236;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _change_pages2(String _value) throws Exception{
int _x = 0;
 //BA.debugLineNum = 265;BA.debugLine="Private Sub Change_Pages2(value As String)";
 //BA.debugLineNum = 266;BA.debugLine="For x = 0 To segTabMenu.Size - 1";
{
final int step1 = 1;
final int limit1 = (int) (_segtabmenu._getsize /*int*/ ()-1);
_x = (int) (0) ;
for (;_x <= limit1 ;_x = _x + step1 ) {
 //BA.debugLineNum = 267;BA.debugLine="If segTabMenu.GetValue(x) = value Then";
if ((_segtabmenu._getvalue /*Object*/ (_x)).equals((Object)(_value))) { 
 //BA.debugLineNum = 268;BA.debugLine="segTabMenu.SelectedIndex(x,500) : '--- fires ev";
_segtabmenu._selectedindex /*String*/ (_x,(int) (500));
 };
 }
};
 //BA.debugLineNum = 271;BA.debugLine="End Sub";
return "";
}
public void  _check4_update() throws Exception{
ResumableSub_Check4_Update rsub = new ResumableSub_Check4_Update(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Check4_Update extends BA.ResumableSub {
public ResumableSub_Check4_Update(sadLogic.HomeCentral.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.HomeCentral.b4xmainpage parent;
sadLogic.HomeCentral.dlgappupdate _obj = null;
boolean _yes = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 483;BA.debugLine="Dim obj As dlgAppUpdate : obj.Initialize(Null)";
_obj = new sadLogic.HomeCentral.dlgappupdate();
 //BA.debugLineNum = 483;BA.debugLine="Dim obj As dlgAppUpdate : obj.Initialize(Null)";
_obj._initialize /*String*/ (ba,(sadLogic.HomeCentral.b4xdialog)(parent.__c.Null));
 //BA.debugLineNum = 484;BA.debugLine="Wait For (obj.CheckIfNewDownloadAvail()) Complete";
parent.__c.WaitFor("complete", ba, this, _obj._checkifnewdownloadavail /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 5;
return;
case 5:
//C
this.state = 1;
_yes = (Boolean) result[0];
;
 //BA.debugLineNum = 485;BA.debugLine="If yes Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_yes) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 486;BA.debugLine="guiHelpers.Show_toast2(\"App update available\", 3";
parent._guihelpers._show_toast2 /*String*/ (ba,"App update available",(int) (3600));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 489;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(boolean _yes) throws Exception{
}
public String  _check4update() throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Public Sub Check4Update";
 //BA.debugLineNum = 179;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_SE";
if ((_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_scrn_check_4_updates /*String*/ ))).equals((Object)(__c.True))) { 
 //BA.debugLineNum = 180;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Check4_Up";
_tmrtimercallsub._callsubdelayedplus /*String*/ (this,"Check4_Update",(int) (8000));
 };
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return "";
}
public boolean  _checkforvisibledialogsandclose() throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub CheckForVisibleDialogsAndClose() As Bo";
 //BA.debugLineNum = 122;BA.debugLine="If PrefDlg.IsInitialized And PrefDlg.Dialog.Visib";
if (_prefdlg.IsInitialized /*boolean*/ () && _prefdlg._dialog /*sadLogic.HomeCentral.b4xdialog*/ ._getvisible /*boolean*/ ()) { 
 //BA.debugLineNum = 123;BA.debugLine="PrefDlg.Dialog.Close(xui.DialogResponse_Cancel)";
_prefdlg._dialog /*sadLogic.HomeCentral.b4xdialog*/ ._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 123;BA.debugLine="PrefDlg.Dialog.Close(xui.DialogResponse_Cancel)";
if (true) return __c.True;
 };
 //BA.debugLineNum = 125;BA.debugLine="If Dialog.IsInitialized And Dialog.Visible Then";
if (_dialog.IsInitialized /*boolean*/ () && _dialog._getvisible /*boolean*/ ()) { 
 //BA.debugLineNum = 126;BA.debugLine="Dialog.Close(xui.DialogResponse_Cancel) : 			Ret";
_dialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 126;BA.debugLine="Dialog.Close(xui.DialogResponse_Cancel) : 			Ret";
if (true) return __c.True;
 };
 //BA.debugLineNum = 128;BA.debugLine="If Dialog2.IsInitialized And Dialog2.Visible Then";
if (_dialog2.IsInitialized /*boolean*/ () && _dialog2._getvisible /*boolean*/ ()) { 
 //BA.debugLineNum = 129;BA.debugLine="Dialog2.Close(xui.DialogResponse_Cancel) : 			Re";
_dialog2._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 129;BA.debugLine="Dialog2.Close(xui.DialogResponse_Cancel) : 			Re";
if (true) return __c.True;
 };
 //BA.debugLineNum = 131;BA.debugLine="If DialogMSGBOX.IsInitialized And DialogMSGBOX.Vi";
if (_dialogmsgbox.IsInitialized /*boolean*/ () && _dialogmsgbox._getvisible /*boolean*/ ()) { 
 //BA.debugLineNum = 132;BA.debugLine="DialogMSGBOX.Close(xui.DialogResponse_Cancel) :";
_dialogmsgbox._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 132;BA.debugLine="DialogMSGBOX.Close(xui.DialogResponse_Cancel) :";
if (true) return __c.True;
 };
 //BA.debugLineNum = 134;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return false;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 13;BA.debugLine="Public Root As B4XView, xui As XUI, Toast As BCTo";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
_toast = new sadLogic.HomeCentral.bctoast();
 //BA.debugLineNum = 14;BA.debugLine="Private dUtils As DDD";
_dutils = new sadLogic.HomeCentral.ddd();
 //BA.debugLineNum = 16;BA.debugLine="Public DebugLog As Boolean = False";
_debuglog = __c.False;
 //BA.debugLineNum = 17;BA.debugLine="Private PromptExitTwice As Boolean = False";
_promptexittwice = __c.False;
 //BA.debugLineNum = 18;BA.debugLine="Private QuietExitNow As Short = 0";
_quietexitnow = (short) (0);
 //BA.debugLineNum = 20;BA.debugLine="Public sql As SQL";
_sql = new anywheresoftware.b4a.sql.SQL();
 //BA.debugLineNum = 21;BA.debugLine="Public isInterNetConnected As Boolean = True";
_isinternetconnected = __c.True;
 //BA.debugLineNum = 22;BA.debugLine="Public EventGbl As EventController";
_eventgbl = new sadLogic.HomeCentral.eventcontroller();
 //BA.debugLineNum = 23;BA.debugLine="Public tmrTimerCallSub As sadCallSubUtils";
_tmrtimercallsub = new sadLogic.HomeCentral.sadcallsubutils();
 //BA.debugLineNum = 24;BA.debugLine="Public PowerCtrl As PowerControl :";
_powerctrl = new sadLogic.HomeCentral.powercontrol();
 //BA.debugLineNum = 25;BA.debugLine="Public Const TAKE_OVER_POWER As Boolean = True";
_take_over_power = __c.True;
 //BA.debugLineNum = 28;BA.debugLine="Public WeatherData As clsWeatherData";
_weatherdata = new sadLogic.HomeCentral.clsweatherdata();
 //BA.debugLineNum = 29;BA.debugLine="Public useMetric,useCel As Boolean";
_usemetric = false;
_usecel = false;
 //BA.debugLineNum = 31;BA.debugLine="Public Dialog2,Dialog,DialogMSGBOX As B4XDialog";
_dialog2 = new sadLogic.HomeCentral.b4xdialog();
_dialog = new sadLogic.HomeCentral.b4xdialog();
_dialogmsgbox = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 32;BA.debugLine="Public PrefDlg As sadPreferencesDialog";
_prefdlg = new sadLogic.HomeCentral.sadpreferencesdialog();
 //BA.debugLineNum = 34;BA.debugLine="Public oClock As Clock";
_oclock = new sadLogic.HomeCentral.clock();
 //BA.debugLineNum = 37;BA.debugLine="Private pnlBG As B4XView";
_pnlbg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private pnlTimers,pnlCalculator,pnlHome,pnlWeathe";
_pnltimers = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlcalculator = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlhome = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlweather = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlconversions = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlphotos = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlweb = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Public oPageCurrent As Object = Null, oPageWEB As";
_opagecurrent = __c.Null;
_opageweb = new sadLogic.HomeCentral.pageweb();
 //BA.debugLineNum = 41;BA.debugLine="Public oPageConversion As pageConversions,oPagePh";
_opageconversion = new sadLogic.HomeCentral.pageconversions();
_opagephoto = new sadLogic.HomeCentral.pagephotos();
_opagetimers = new sadLogic.HomeCentral.pagektimers();
 //BA.debugLineNum = 42;BA.debugLine="Public oPageCalculator As pageCalculator,  oPageH";
_opagecalculator = new sadLogic.HomeCentral.pagecalculator();
_opagehome = new sadLogic.HomeCentral.pagehome();
_opageweather = new sadLogic.HomeCentral.pageweather();
 //BA.debugLineNum = 50;BA.debugLine="Private pnlHeader As B4XView";
_pnlheader = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Private imgSoundButton,imgMenuButton As lmB4XImag";
_imgsoundbutton = new sadLogic.HomeCentral.lmb4ximageviewx();
_imgmenubutton = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 52;BA.debugLine="Public btnHdrTxt1 As B4XView";
_btnhdrtxt1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 55;BA.debugLine="Public lvSideMenu As CustomListView";
_lvsidemenu = new b4a.example3.customlistview();
 //BA.debugLineNum = 56;BA.debugLine="Private pnlMenuFooter As B4XView";
_pnlmenufooter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 57;BA.debugLine="Private btnSetupMaster As Button";
_btnsetupmaster = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 58;BA.debugLine="Private btnAboutMe As Button";
_btnaboutme = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 59;BA.debugLine="Public pnlSideMenu As B4XView";
_pnlsidemenu = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Public segTabMenu As ASSegmentedTab";
_segtabmenu = new sadLogic.HomeCentral.assegmentedtab();
 //BA.debugLineNum = 61;BA.debugLine="Private lblMnuMenu As B4XView";
_lblmnumenu = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 62;BA.debugLine="Private pnlMenuHdrSpacer2,pnlMenuHdrSpacer1 As B4";
_pnlmenuhdrspacer2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlmenuhdrspacer1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 64;BA.debugLine="Private pnlScrnOff,pnlSideMenuTouchOverlay As B4X";
_pnlscrnoff = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsidemenutouchoverlay = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 65;BA.debugLine="Private btnScreenOff As Button";
_btnscreenoff = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _ifphotoshow_turnoff() throws Exception{
 //BA.debugLineNum = 669;BA.debugLine="Private Sub IfPhotoShow_TurnOff";
 //BA.debugLineNum = 677;BA.debugLine="End Sub";
return "";
}
public void  _imgmenubutton_click() throws Exception{
ResumableSub_imgMenuButton_Click rsub = new ResumableSub_imgMenuButton_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_imgMenuButton_Click extends BA.ResumableSub {
public ResumableSub_imgMenuButton_Click(sadLogic.HomeCentral.b4xmainpage parent) {
this.parent = parent;
}
sadLogic.HomeCentral.b4xmainpage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 247;BA.debugLine="If pnlSideMenu.Visible = False Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._pnlsidemenu.getVisible()==parent.__c.False) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 248;BA.debugLine="guiHelpers.AnimateB4xView(\"RIGHT\",pnlSideMenu)";
parent._guihelpers._animateb4xview /*String*/ (ba,"RIGHT",parent._pnlsidemenu);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 250;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
parent._pnlsidemenu.SetVisibleAnimated((int) (380),parent.__c.False);
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 257;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 11;
return;
case 11:
//C
this.state = 7;
;
 //BA.debugLineNum = 258;BA.debugLine="If pnlSideMenu.Visible Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._pnlsidemenu.getVisible()) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 259;BA.debugLine="pnlSideMenu.BringToFront";
parent._pnlsidemenu.BringToFront();
 //BA.debugLineNum = 260;BA.debugLine="pnlHeader.BringToFront";
parent._pnlheader.BringToFront();
 //BA.debugLineNum = 261;BA.debugLine="pnlSideMenuTouchOverlay_show(True)";
parent._pnlsidemenutouchoverlay_show(parent.__c.True);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _imgsoundbutton_click() throws Exception{
anywheresoftware.b4a.phone.Phone _ph = null;
sadLogic.HomeCentral.dlgvolume _o1 = null;
 //BA.debugLineNum = 393;BA.debugLine="Private Sub imgSoundButton_Click";
 //BA.debugLineNum = 395;BA.debugLine="Try";
try { //BA.debugLineNum = 396;BA.debugLine="If oPageCurrent <> oPageTimers Then";
if ((_opagecurrent).equals((Object)(_opagetimers)) == false) { 
 //BA.debugLineNum = 397;BA.debugLine="guiHelpers.Show_toast2(\"System Volume\",2000)";
_guihelpers._show_toast2 /*String*/ (ba,"System Volume",(int) (2000));
 //BA.debugLineNum = 398;BA.debugLine="Dim ph As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 399;BA.debugLine="ph.SetVolume(ph.VOLUME_SYSTEM,ph.GetMaxVolume(p";
_ph.SetVolume(_ph.VOLUME_SYSTEM,_ph.GetMaxVolume(_ph.VOLUME_SYSTEM),__c.True);
 //BA.debugLineNum = 400;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 404;BA.debugLine="Dim o1 As dlgVolume : o1.Initialize(Dialog) '---";
_o1 = new sadLogic.HomeCentral.dlgvolume();
 //BA.debugLineNum = 404;BA.debugLine="Dim o1 As dlgVolume : o1.Initialize(Dialog) '---";
_o1._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 405;BA.debugLine="o1.Show(\"kt\")";
_o1._show /*void*/ ("kt");
 } 
       catch (Exception e12) {
			ba.setLastException(e12); //BA.debugLineNum = 408;BA.debugLine="guiHelpers.Show_toast2(gblConst.VOLUME_ERR,4500)";
_guihelpers._show_toast2 /*String*/ (ba,_gblconst._volume_err /*String*/ ,(int) (4500));
 //BA.debugLineNum = 409;BA.debugLine="Log(LastException)";
__c.LogImpl("6553616",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 411;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 68;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 70;BA.debugLine="Log(\"MainPage Init\")";
__c.LogImpl("5439490","MainPage Init",0);
 //BA.debugLineNum = 72;BA.debugLine="tmrTimerCallSub.Initialize";
_tmrtimercallsub._initialize /*String*/ (ba);
 //BA.debugLineNum = 73;BA.debugLine="EventGbl.Initialize";
_eventgbl._initialize /*String*/ (ba);
 //BA.debugLineNum = 74;BA.debugLine="Main.kvs.Initialize(xui.DefaultFolder,gblConst.AP";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._initialize /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._app_name /*String*/ +"_settings.db3");
 //BA.debugLineNum = 75;BA.debugLine="sql = Main.kvs.oSql '<--- pointer so we can use t";
_sql = _main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getosql /*anywheresoftware.b4a.sql.SQL*/ ();
 //BA.debugLineNum = 77;BA.debugLine="Log(\"-------------------->  Runnung  <-----------";
__c.LogImpl("5439497","-------------------->  Runnung  <-----------------------",0);
 //BA.debugLineNum = 79;BA.debugLine="config.Init";
_config._init /*String*/ (ba);
 //BA.debugLineNum = 81;BA.debugLine="clrTheme.Init(config.MainSetupData.Get(gblConst.K";
_clrtheme._init /*String*/ (ba,BA.ObjectToString(_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_page_theme /*String*/ ))));
 //BA.debugLineNum = 84;BA.debugLine="WeatherData.Initialize";
_weatherdata._initialize /*String*/ (ba);
 //BA.debugLineNum = 85;BA.debugLine="useCel 	 	  = Main.kvs.GetDefault(gblConst.INI_WE";
_usecel = BA.ObjectToBoolean(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (_gblconst._ini_weather_use_celsius /*String*/ ,(Object)(__c.True)));
 //BA.debugLineNum = 86;BA.debugLine="useMetric = Main.kvs.GetDefault(gblConst.INI_WEAT";
_usemetric = BA.ObjectToBoolean(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (_gblconst._ini_weather_use_metric /*String*/ ,(Object)(__c.False)));
 //BA.debugLineNum = 87;BA.debugLine="StartPowerCrap";
_startpowercrap();
 //BA.debugLineNum = 88;BA.debugLine="If ( File.Exists(xui.DefaultFolder,gblConst.FILE_";
if ((__c.File.Exists(_xui.getDefaultFolder(),_gblconst._file_auto_start_flag /*String*/ ))) { 
 //BA.debugLineNum = 89;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"Kill_Star";
_tmrtimercallsub._callsubdelayedplus /*String*/ (this,"Kill_StartAtBoot_Service",(int) (60000));
 };
 //BA.debugLineNum = 91;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"ShowVer\",2";
_tmrtimercallsub._callsubdelayedplus /*String*/ (this,"ShowVer",(int) (2300));
 //BA.debugLineNum = 92;BA.debugLine="Check4Update";
_check4update();
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public boolean  _is_nighttime() throws Exception{
b4a.example.dateutils._period _t1 = null;
b4a.example.dateutils._period _t2 = null;
long _now = 0L;
float _nowtime = 0f;
float _end_time = 0f;
float _start_time = 0f;
 //BA.debugLineNum = 582;BA.debugLine="Private Sub Is_NightTime() As Boolean";
 //BA.debugLineNum = 583;BA.debugLine="Dim t1, t2 As Period";
_t1 = new b4a.example.dateutils._period();
_t2 = new b4a.example.dateutils._period();
 //BA.debugLineNum = 584;BA.debugLine="t1 = config.MainSetupData.Get(gblConst.KEYS_MAIN_";
_t1 = (b4a.example.dateutils._period)(_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_scrn_ctrl_morning_time /*String*/ )));
 //BA.debugLineNum = 585;BA.debugLine="t2 = config.MainSetupData.Get(gblConst.KEYS_MAIN_";
_t2 = (b4a.example.dateutils._period)(_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_scrn_ctrl_evening_time /*String*/ )));
 //BA.debugLineNum = 591;BA.debugLine="Dim now As Long = DateTime.now, nowTime As Float";
_now = __c.DateTime.getNow();
_nowtime = 0f;
 //BA.debugLineNum = 593;BA.debugLine="Try";
try { //BA.debugLineNum = 594;BA.debugLine="nowTime   = DateTime.GetHour(now) & \".\" & strHel";
_nowtime = (float)(Double.parseDouble(BA.NumberToString(__c.DateTime.GetHour(_now))+"."+_strhelpers._padleft /*String*/ (ba,BA.NumberToString(__c.DateTime.GetMinute(_now)),"0",(int) (2))));
 //BA.debugLineNum = 595;BA.debugLine="Dim end_Time    As Float = t2.Hours & \".\" & strH";
_end_time = (float)(Double.parseDouble(BA.NumberToString(_t2.Hours)+"."+_strhelpers._padleft /*String*/ (ba,BA.NumberToString(_t2.Minutes),"0",(int) (2))));
 //BA.debugLineNum = 596;BA.debugLine="Dim start_Time As Float = t1.Hours & \".\"  & strH";
_start_time = (float)(Double.parseDouble(BA.NumberToString(_t1.Hours)+"."+_strhelpers._padleft /*String*/ (ba,BA.NumberToString(_t1.Minutes),"0",(int) (2))));
 //BA.debugLineNum = 602;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 605;BA.debugLine="If (nowTime >= end_Time And nowTime < start_Time";
if ((_nowtime>=_end_time && _nowtime<_start_time)) { 
 //BA.debugLineNum = 606;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 608;BA.debugLine="Return False";
if (true) return __c.False;
 } 
       catch (Exception e15) {
			ba.setLastException(e15); //BA.debugLineNum = 611;BA.debugLine="LogIt.LogWrite(\"ScreenOnOff_Clock_Event-Parsing";
_logit._logwrite /*String*/ (ba,"ScreenOnOff_Clock_Event-Parsing err: "+BA.ObjectToString(__c.LastException(ba)),(int) (1));
 };
 //BA.debugLineNum = 613;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 615;BA.debugLine="End Sub";
return false;
}
public String  _kill_startatboot_service() throws Exception{
 //BA.debugLineNum = 536;BA.debugLine="Private Sub Kill_StartAtBoot_Service";
 //BA.debugLineNum = 537;BA.debugLine="Log(\"StartAtBoot service killed!\")";
__c.LogImpl("7274497","StartAtBoot service killed!",0);
 //BA.debugLineNum = 540;BA.debugLine="StopService(\"startAtBoot\")";
__c.StopService(ba,(Object)("startAtBoot"));
 //BA.debugLineNum = 541;BA.debugLine="End Sub";
return "";
}
public String  _lvsidemenu_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 414;BA.debugLine="Private Sub lvSideMenu_ItemClick (Index As Int, Va";
 //BA.debugLineNum = 416;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
_pnlsidemenutouchoverlay_show(__c.False);
 //BA.debugLineNum = 417;BA.debugLine="ResetScrn_SleepCounter '--- reset the power / scr";
_resetscrn_sleepcounter();
 //BA.debugLineNum = 418;BA.debugLine="If SubExists(oPageCurrent,\"SideMenu_ItemClick\") T";
if (__c.SubExists(ba,_opagecurrent,"SideMenu_ItemClick")) { 
 //BA.debugLineNum = 419;BA.debugLine="CallSubDelayed3(oPageCurrent,\"SideMenu_ItemClick";
__c.CallSubDelayed3(ba,_opagecurrent,"SideMenu_ItemClick",(Object)(_index),_value);
 };
 //BA.debugLineNum = 422;BA.debugLine="End Sub";
return "";
}
public void  _pnlblankscreen_show(boolean _show_me) throws Exception{
ResumableSub_pnlBlankScreen_show rsub = new ResumableSub_pnlBlankScreen_show(this,_show_me);
rsub.resume(ba, null);
}
public static class ResumableSub_pnlBlankScreen_show extends BA.ResumableSub {
public ResumableSub_pnlBlankScreen_show(sadLogic.HomeCentral.b4xmainpage parent,boolean _show_me) {
this.parent = parent;
this._show_me = _show_me;
}
sadLogic.HomeCentral.b4xmainpage parent;
boolean _show_me;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 686;BA.debugLine="If show_me = True Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_show_me==parent.__c.True) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 687;BA.debugLine="pnlScrnOff.Visible = True";
parent._pnlscrnoff.setVisible(parent.__c.True);
 //BA.debugLineNum = 688;BA.debugLine="pnlScrnOff.As(Panel).Elevation = 8dip";
((anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnlscrnoff.getObject()))).setElevation((float) (parent.__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 689;BA.debugLine="pnlScrnOff.BringToFront";
parent._pnlscrnoff.BringToFront();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 692;BA.debugLine="pnlScrnOff.Visible = False";
parent._pnlscrnoff.setVisible(parent.__c.False);
 //BA.debugLineNum = 693;BA.debugLine="pnlScrnOff.As(Panel).Elevation = -8dip";
((anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnlscrnoff.getObject()))).setElevation((float) (-parent.__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 694;BA.debugLine="pnlScrnOff.SendToBack";
parent._pnlscrnoff.SendToBack();
 //BA.debugLineNum = 695;BA.debugLine="pnlHeader.BringToFront";
parent._pnlheader.BringToFront();
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 697;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 698;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _pnlscrnoff_click() throws Exception{
 //BA.debugLineNum = 638;BA.debugLine="Private Sub pnlScrnOff_Click";
 //BA.debugLineNum = 640;BA.debugLine="pnlBlankScreen_show(False)";
_pnlblankscreen_show(__c.False);
 //BA.debugLineNum = 641;BA.debugLine="PowerCtrl.Screen_On(TAKE_OVER_POWER) '=== This is";
_powerctrl._screen_on /*String*/ (_take_over_power);
 //BA.debugLineNum = 642;BA.debugLine="If WeatherData.LastUpdatedAt = 1 Then";
if (_weatherdata._lastupdatedat /*long*/ ==1) { 
 //BA.debugLineNum = 643;BA.debugLine="WeatherData.Try_Weather_Update";
_weatherdata._try_weather_update /*String*/ ();
 };
 //BA.debugLineNum = 645;BA.debugLine="pnlHeader.BringToFront";
_pnlheader.BringToFront();
 //BA.debugLineNum = 646;BA.debugLine="ResetScrn_SleepCounter";
_resetscrn_sleepcounter();
 //BA.debugLineNum = 647;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
__c.CallSubDelayed2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 650;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_SE";
if ((_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_scrn_ctrl_on /*String*/ ))).equals((Object)(__c.True)) && _is_nighttime()) { 
 //BA.debugLineNum = 651;BA.debugLine="EventGbl.Unsubscribe(gblConst.EVENT_CLOCK_CHANGE";
_eventgbl._unsubscribe /*String*/ (_gblconst._event_clock_change /*String*/ ,this);
 //BA.debugLineNum = 653;BA.debugLine="tmrTimerCallSub.CallSubDelayedPlus(Me,\"setup_on_";
_tmrtimercallsub._callsubdelayedplus /*String*/ (this,"setup_on_off_scrn_event",(int) (60000*5));
 //BA.debugLineNum = 654;BA.debugLine="guiHelpers.Show_toast2(\"Night time screen off ov";
_guihelpers._show_toast2 /*String*/ (ba,"Night time screen off overide - 5 minutes",(int) (3500));
 };
 //BA.debugLineNum = 657;BA.debugLine="End Sub";
return "";
}
public String  _pnlsidemenutouchoverlay_click() throws Exception{
 //BA.debugLineNum = 514;BA.debugLine="Private Sub pnlSideMenuTouchOverlay_Click";
 //BA.debugLineNum = 516;BA.debugLine="If pnlSideMenu.Visible Then";
if (_pnlsidemenu.getVisible()) { 
 //BA.debugLineNum = 517;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False)";
_pnlsidemenu.SetVisibleAnimated((int) (380),__c.False);
 };
 //BA.debugLineNum = 519;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
_pnlsidemenutouchoverlay_show(__c.False);
 //BA.debugLineNum = 520;BA.debugLine="CallSubDelayed(Me,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,this,"ResetScrn_SleepCounter");
 //BA.debugLineNum = 521;BA.debugLine="End Sub";
return "";
}
public void  _pnlsidemenutouchoverlay_show(boolean _show_me) throws Exception{
ResumableSub_pnlSideMenuTouchOverlay_show rsub = new ResumableSub_pnlSideMenuTouchOverlay_show(this,_show_me);
rsub.resume(ba, null);
}
public static class ResumableSub_pnlSideMenuTouchOverlay_show extends BA.ResumableSub {
public ResumableSub_pnlSideMenuTouchOverlay_show(sadLogic.HomeCentral.b4xmainpage parent,boolean _show_me) {
this.parent = parent;
this._show_me = _show_me;
}
sadLogic.HomeCentral.b4xmainpage parent;
boolean _show_me;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 524;BA.debugLine="If show_me = True Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_show_me==parent.__c.True) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 525;BA.debugLine="pnlSideMenuTouchOverlay.Visible = True";
parent._pnlsidemenutouchoverlay.setVisible(parent.__c.True);
 //BA.debugLineNum = 526;BA.debugLine="pnlSideMenuTouchOverlay.As(Panel).Elevation = 8d";
((anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnlsidemenutouchoverlay.getObject()))).setElevation((float) (parent.__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 527;BA.debugLine="pnlSideMenuTouchOverlay.BringToFront";
parent._pnlsidemenutouchoverlay.BringToFront();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 529;BA.debugLine="pnlSideMenuTouchOverlay.Visible = False";
parent._pnlsidemenutouchoverlay.setVisible(parent.__c.False);
 //BA.debugLineNum = 530;BA.debugLine="pnlSideMenuTouchOverlay.As(Panel).Elevation = -8";
((anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnlsidemenutouchoverlay.getObject()))).setElevation((float) (-parent.__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 531;BA.debugLine="pnlSideMenuTouchOverlay.SendToBack";
parent._pnlsidemenutouchoverlay.SendToBack();
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 533;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 534;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _process_dayscreenonoff(boolean _off) throws Exception{
 //BA.debugLineNum = 625;BA.debugLine="Private Sub Process_dayScreenOnOff(off As Boolean)";
 //BA.debugLineNum = 627;BA.debugLine="If off And pnlScrnOff.Visible Then";
if (_off && _pnlscrnoff.getVisible()) { 
 //BA.debugLineNum = 628;BA.debugLine="Log(\"(sub: Process_dayScreenOnOff) check - alrea";
__c.LogImpl("7733251","(sub: Process_dayScreenOnOff) check - already off",0);
 //BA.debugLineNum = 629;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 631;BA.debugLine="If off Then";
if (_off) { 
 //BA.debugLineNum = 632;BA.debugLine="TurnScreen_Off : 	ResetScrn_SleepCounter";
_turnscreen_off();
 //BA.debugLineNum = 632;BA.debugLine="TurnScreen_Off : 	ResetScrn_SleepCounter";
_resetscrn_sleepcounter();
 }else {
 //BA.debugLineNum = 634;BA.debugLine="pnlScrnOff_Click : 	'ResetScrn_SleepCounter - ca";
_pnlscrnoff_click();
 };
 //BA.debugLineNum = 636;BA.debugLine="End Sub";
return "";
}
public String  _prompt_exit_quiet() throws Exception{
 //BA.debugLineNum = 345;BA.debugLine="Private Sub Prompt_Exit_Quiet";
 //BA.debugLineNum = 348;BA.debugLine="QuietExitNow = 0";
_quietexitnow = (short) (0);
 //BA.debugLineNum = 349;BA.debugLine="End Sub";
return "";
}
public String  _prompt_exit_reset() throws Exception{
 //BA.debugLineNum = 339;BA.debugLine="Private Sub Prompt_Exit_Reset";
 //BA.debugLineNum = 342;BA.debugLine="PromptExitTwice = False";
_promptexittwice = __c.False;
 //BA.debugLineNum = 343;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 344;BA.debugLine="End Sub";
return "";
}
public String  _resetscrn_sleepcounter() throws Exception{
 //BA.debugLineNum = 554;BA.debugLine="Public Sub ResetScrn_SleepCounter";
 //BA.debugLineNum = 556;BA.debugLine="If pnlScrnOff.IsInitialized And pnlScrnOff.Visibl";
if (_pnlscrnoff.IsInitialized() && _pnlscrnoff.getVisible()==__c.True) { 
 //BA.debugLineNum = 561;BA.debugLine="tmrTimerCallSub.ExistsRemove(Me,\"TurnScreen_Off\"";
_tmrtimercallsub._existsremove /*String*/ (this,"TurnScreen_Off");
 //BA.debugLineNum = 563;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 565;BA.debugLine="If config.getScreenOffTime <> 0 Then";
if (_config._getscreenofftime /*int*/ (ba)!=0) { 
 //BA.debugLineNum = 566;BA.debugLine="tmrTimerCallSub.ExistsRemoveAdd_DelayedPlus(Me,\"";
_tmrtimercallsub._existsremoveadd_delayedplus /*String*/ (this,"TurnScreen_Off",(int) (60000*_config._getscreenofftime /*int*/ (ba)));
 }else {
 //BA.debugLineNum = 569;BA.debugLine="tmrTimerCallSub.ExistsRemove(Me,\"TurnScreen_Off\"";
_tmrtimercallsub._existsremove /*String*/ (this,"TurnScreen_Off");
 };
 //BA.debugLineNum = 572;BA.debugLine="End Sub";
return "";
}
public String  _save_home_web_addr(String _txt) throws Exception{
 //BA.debugLineNum = 474;BA.debugLine="Private Sub save_home_web_addr(txt As String)";
 //BA.debugLineNum = 476;BA.debugLine="If strHelpers.IsNullOrEmpty(txt) Then Return";
if (_strhelpers._isnullorempty /*boolean*/ (ba,_txt)) { 
if (true) return "";};
 //BA.debugLineNum = 477;BA.debugLine="Main.kvs.Put(gblConst.INI_WEB_HOME,txt)";
_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (_gblconst._ini_web_home /*String*/ ,(Object)(_txt));
 //BA.debugLineNum = 478;BA.debugLine="End Sub";
return "";
}
public String  _screenonoff_clock_event(Object _ttime) throws Exception{
 //BA.debugLineNum = 617;BA.debugLine="Public Sub ScreenOnOff_Clock_Event(ttime As Object";
 //BA.debugLineNum = 622;BA.debugLine="Process_dayScreenOnOff(Is_NightTime)";
_process_dayscreenonoff(_is_nighttime());
 //BA.debugLineNum = 623;BA.debugLine="End Sub";
return "";
}
public String  _segtabmenu_tabchanged(int _index) throws Exception{
String _value = "";
 //BA.debugLineNum = 273;BA.debugLine="Private Sub segTabMenu_TabChanged(index As Int)";
 //BA.debugLineNum = 275;BA.debugLine="Dim value As String";
_value = "";
 //BA.debugLineNum = 276;BA.debugLine="If index = -2 Then  '--- 1st run";
if (_index==-2) { 
 //BA.debugLineNum = 277;BA.debugLine="value = \"hm\"";
_value = "hm";
 }else {
 //BA.debugLineNum = 279;BA.debugLine="pnlSideMenu.SetVisibleAnimated(380, False) '---";
_pnlsidemenu.SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 280;BA.debugLine="value = segTabMenu.Getvalue(index)";
_value = BA.ObjectToString(_segtabmenu._getvalue /*Object*/ (_index));
 };
 //BA.debugLineNum = 284;BA.debugLine="If oPageCurrent <> Null Then";
if (_opagecurrent!= null) { 
 //BA.debugLineNum = 285;BA.debugLine="CallSub(oPageCurrent,\"Lost_Focus\")";
__c.CallSubNew(ba,_opagecurrent,"Lost_Focus");
 };
 //BA.debugLineNum = 288;BA.debugLine="Select Case value";
switch (BA.switchObjectToInt(_value,"cv","hm","wt","ca","ph","tm","wb")) {
case 0: {
 //BA.debugLineNum = 291;BA.debugLine="If oPageConversion.IsInitialized = False Then o";
if (_opageconversion.IsInitialized /*boolean*/ ()==__c.False) { 
_opageconversion._initialize /*String*/ (ba,_pnlconversions);};
 //BA.debugLineNum = 292;BA.debugLine="oPageCurrent = oPageConversion";
_opagecurrent = (Object)(_opageconversion);
 break; }
case 1: {
 //BA.debugLineNum = 295;BA.debugLine="If oPageHome.IsInitialized = False Then oPageHo";
if (_opagehome.IsInitialized /*boolean*/ ()==__c.False) { 
_opagehome._initialize /*String*/ (ba,_pnlhome);};
 //BA.debugLineNum = 296;BA.debugLine="oPageCurrent = oPageHome";
_opagecurrent = (Object)(_opagehome);
 break; }
case 2: {
 //BA.debugLineNum = 299;BA.debugLine="If oPageWeather.IsInitialized = False Then oPag";
if (_opageweather.IsInitialized /*boolean*/ ()==__c.False) { 
_opageweather._initialize /*String*/ (ba,_pnlweather);};
 //BA.debugLineNum = 300;BA.debugLine="oPageCurrent = oPageWeather";
_opagecurrent = (Object)(_opageweather);
 break; }
case 3: {
 //BA.debugLineNum = 303;BA.debugLine="If oPageCalculator.IsInitialized = False Then o";
if (_opagecalculator.IsInitialized /*boolean*/ ()==__c.False) { 
_opagecalculator._initialize /*String*/ (ba,_pnlcalculator);};
 //BA.debugLineNum = 304;BA.debugLine="oPageCurrent = oPageCalculator";
_opagecurrent = (Object)(_opagecalculator);
 break; }
case 4: {
 //BA.debugLineNum = 307;BA.debugLine="If oPagePhoto.IsInitialized = False Then oPageP";
if (_opagephoto.IsInitialized /*boolean*/ ()==__c.False) { 
_opagephoto._initialize /*String*/ (ba,_pnlphotos);};
 //BA.debugLineNum = 308;BA.debugLine="oPageCurrent = oPagePhoto";
_opagecurrent = (Object)(_opagephoto);
 break; }
case 5: {
 //BA.debugLineNum = 311;BA.debugLine="If oPageTimers.IsInitialized = False Then oPage";
if (_opagetimers.IsInitialized /*boolean*/ ()==__c.False) { 
_opagetimers._initialize /*String*/ (ba,_pnltimers);};
 //BA.debugLineNum = 312;BA.debugLine="oPageCurrent = oPageTimers";
_opagecurrent = (Object)(_opagetimers);
 break; }
case 6: {
 //BA.debugLineNum = 315;BA.debugLine="If oPageWEB.IsInitialized = False Then oPageWEB";
if (_opageweb.IsInitialized /*boolean*/ ()==__c.False) { 
_opageweb._initialize /*String*/ (ba,_pnlweb);};
 //BA.debugLineNum = 316;BA.debugLine="oPageCurrent = oPageWEB";
_opagecurrent = (Object)(_opageweb);
 break; }
}
;
 //BA.debugLineNum = 321;BA.debugLine="CallSub(oPageCurrent,\"Set_Focus\")";
__c.CallSubNew(ba,_opagecurrent,"Set_Focus");
 //BA.debugLineNum = 322;BA.debugLine="ResetScrn_SleepCounter";
_resetscrn_sleepcounter();
 //BA.debugLineNum = 323;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 325;BA.debugLine="End Sub";
return "";
}
public String  _setup_on_off_scrn_event() throws Exception{
 //BA.debugLineNum = 574;BA.debugLine="Public Sub setup_on_off_scrn_event()";
 //BA.debugLineNum = 575;BA.debugLine="If config.MainSetupData.Get(gblConst.KEYS_MAIN_SE";
if ((_config._mainsetupdata /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)(_gblconst._keys_main_setup_scrn_ctrl_on /*String*/ ))).equals((Object)(__c.True))) { 
 //BA.debugLineNum = 576;BA.debugLine="EventGbl.Subscribe(gblConst.EVENT_CLOCK_CHANGE,";
_eventgbl._subscribe /*String*/ (_gblconst._event_clock_change /*String*/ ,this,"ScreenOnOff_Clock_Event");
 }else {
 //BA.debugLineNum = 578;BA.debugLine="EventGbl.Unsubscribe(gblConst.EVENT_CLOCK_CHANGE";
_eventgbl._unsubscribe /*String*/ (_gblconst._event_clock_change /*String*/ ,this);
 };
 //BA.debugLineNum = 580;BA.debugLine="End Sub";
return "";
}
public String  _setupmainmenu_event(String _t,Object _o) throws Exception{
sadLogic.HomeCentral.dlgappupdate _up = null;
sadLogic.HomeCentral.dlgsetupweather _o1 = null;
sadLogic.HomeCentral.dlgsetupmain _o2 = null;
sadLogic.HomeCentral.dlgtextinput _o3 = null;
sadLogic.HomeCentral.dlgsetuptimers _o4 = null;
 //BA.debugLineNum = 453;BA.debugLine="Private Sub SetupMainMenu_Event(t As String,o As O";
 //BA.debugLineNum = 454;BA.debugLine="pnlSideMenuTouchOverlay_show(False)";
_pnlsidemenutouchoverlay_show(__c.False);
 //BA.debugLineNum = 455;BA.debugLine="CallSubDelayed(Me,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,this,"ResetScrn_SleepCounter");
 //BA.debugLineNum = 456;BA.debugLine="Select Case t";
switch (BA.switchObjectToInt(_t,"up","wth","gn","wb","tm")) {
case 0: {
 //BA.debugLineNum = 458;BA.debugLine="Dim up As dlgAppUpdate : up.Initialize(Dialog)";
_up = new sadLogic.HomeCentral.dlgappupdate();
 //BA.debugLineNum = 458;BA.debugLine="Dim up As dlgAppUpdate : up.Initialize(Dialog)";
_up._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 458;BA.debugLine="Dim up As dlgAppUpdate : up.Initialize(Dialog)";
_up._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ();
 break; }
case 1: {
 //BA.debugLineNum = 460;BA.debugLine="Dim o1 As dlgSetupWeather : o1.Initialize(Dialo";
_o1 = new sadLogic.HomeCentral.dlgsetupweather();
 //BA.debugLineNum = 460;BA.debugLine="Dim o1 As dlgSetupWeather : o1.Initialize(Dialo";
_o1._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 460;BA.debugLine="Dim o1 As dlgSetupWeather : o1.Initialize(Dialo";
_o1._show /*void*/ ();
 break; }
case 2: {
 //BA.debugLineNum = 462;BA.debugLine="Dim o2 As dlgSetupMain : o2.Initialize(PrefDlg)";
_o2 = new sadLogic.HomeCentral.dlgsetupmain();
 //BA.debugLineNum = 462;BA.debugLine="Dim o2 As dlgSetupMain : o2.Initialize(PrefDlg)";
_o2._initialize /*String*/ (ba,_prefdlg);
 //BA.debugLineNum = 462;BA.debugLine="Dim o2 As dlgSetupMain : o2.Initialize(PrefDlg)";
_o2._show /*void*/ ();
 break; }
case 3: {
 //BA.debugLineNum = 464;BA.debugLine="Dim o3 As dlgTextInput";
_o3 = new sadLogic.HomeCentral.dlgtextinput();
 //BA.debugLineNum = 465;BA.debugLine="o3.Initialize(\"Home Page\",\"Address\",B4XPages.Ma";
_o3._initialize /*String*/ (ba,"Home Page","Address",(Object)(_b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba)),"save_home_web_addr");
 //BA.debugLineNum = 466;BA.debugLine="o3.txtEdit = Main.kvs.Get(gblConst.INI_WEB_HOME";
_o3._txtedit /*String*/  = BA.ObjectToString(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._get /*Object*/ (_gblconst._ini_web_home /*String*/ ))+"";
 //BA.debugLineNum = 466;BA.debugLine="o3.txtEdit = Main.kvs.Get(gblConst.INI_WEB_HOME";
_o3._show /*void*/ ();
 break; }
case 4: {
 //BA.debugLineNum = 468;BA.debugLine="Dim o4 As dlgSetupTimers : o4.Initialize(Dialog";
_o4 = new sadLogic.HomeCentral.dlgsetuptimers();
 //BA.debugLineNum = 468;BA.debugLine="Dim o4 As dlgSetupTimers : o4.Initialize(Dialog";
_o4._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 468;BA.debugLine="Dim o4 As dlgSetupTimers : o4.Initialize(Dialog";
_o4._show /*void*/ ();
 break; }
default: {
 break; }
}
;
 //BA.debugLineNum = 472;BA.debugLine="End Sub";
return "";
}
public String  _show_1strun() throws Exception{
sadLogic.HomeCentral.dlg1strun _o = null;
 //BA.debugLineNum = 388;BA.debugLine="Private Sub Show_1stRun";
 //BA.debugLineNum = 389;BA.debugLine="Dim o As dlg1stRun : o.Initialize(Dialog) :	o.Sho";
_o = new sadLogic.HomeCentral.dlg1strun();
 //BA.debugLineNum = 389;BA.debugLine="Dim o As dlg1stRun : o.Initialize(Dialog) :	o.Sho";
_o._initialize /*String*/ (ba,_dialog);
 //BA.debugLineNum = 389;BA.debugLine="Dim o As dlg1stRun : o.Initialize(Dialog) :	o.Sho";
_o._show /*void*/ ();
 //BA.debugLineNum = 390;BA.debugLine="End Sub";
return "";
}
public String  _show_toast(String _message) throws Exception{
 //BA.debugLineNum = 331;BA.debugLine="Public Sub Show_Toast(Message As String)";
 //BA.debugLineNum = 332;BA.debugLine="Show_Toast2(Message,2500)";
_show_toast2(_message,(int) (2500));
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
return "";
}
public String  _show_toast2(String _msg,int _ms) throws Exception{
 //BA.debugLineNum = 334;BA.debugLine="Public Sub Show_Toast2(msg As String, ms As Int)";
 //BA.debugLineNum = 336;BA.debugLine="Toast.DurationMs = ms";
_toast._durationms /*int*/  = _ms;
 //BA.debugLineNum = 337;BA.debugLine="Toast.Show($\"[TextSize=30][b][FontAwesome=0xF05A/";
_toast._show /*void*/ (("[TextSize=30][b][FontAwesome=0xF05A/]  "+__c.SmartStringFormatter("",(Object)(_msg))+"[/b][/TextSize]"));
 //BA.debugLineNum = 338;BA.debugLine="End Sub";
return "";
}
public String  _showver() throws Exception{
 //BA.debugLineNum = 491;BA.debugLine="Public Sub ShowVer";
 //BA.debugLineNum = 492;BA.debugLine="guiHelpers.Show_toast2(\"Version: V\" & Application";
_guihelpers._show_toast2 /*String*/ (ba,"Version: V"+__c.Application.getVersionName(),(int) (2200));
 //BA.debugLineNum = 493;BA.debugLine="End Sub";
return "";
}
public String  _startpowercrap() throws Exception{
 //BA.debugLineNum = 550;BA.debugLine="Private Sub StartPowerCrap";
 //BA.debugLineNum = 551;BA.debugLine="PowerCtrl.Initialize(True)";
_powerctrl._initialize /*String*/ (ba,__c.True);
 //BA.debugLineNum = 552;BA.debugLine="ResetScrn_SleepCounter";
_resetscrn_sleepcounter();
 //BA.debugLineNum = 553;BA.debugLine="End Sub";
return "";
}
public String  _stopallservicesonexit() throws Exception{
 //BA.debugLineNum = 186;BA.debugLine="Private Sub StopAllServicesOnExit";
 //BA.debugLineNum = 187;BA.debugLine="Log(\"  StopAllServicesOnExit-Release power locks\"";
__c.LogImpl("5767169","  StopAllServicesOnExit-Release power locks",0);
 //BA.debugLineNum = 188;BA.debugLine="PowerCtrl.ReleaseLocks";
_powerctrl._releaselocks /*String*/ ();
 //BA.debugLineNum = 189;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 190;BA.debugLine="tmrTimerCallSub.Destroy '--- should not need this";
_tmrtimercallsub._destroy /*String*/ ();
 //BA.debugLineNum = 191;BA.debugLine="StopService(\"httputils2service\")";
__c.StopService(ba,(Object)("httputils2service"));
 //BA.debugLineNum = 192;BA.debugLine="StopService(\"Starter\")";
__c.StopService(ba,(Object)("Starter"));
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return "";
}
public String  _turnscreen_dim() throws Exception{
 //BA.debugLineNum = 543;BA.debugLine="Public Sub TurnScreen_Dim";
 //BA.debugLineNum = 544;BA.debugLine="PowerCtrl.DimTheScrnBySettingBrightness '--- call";
_powerctrl._dimthescrnbysettingbrightness /*String*/ ();
 //BA.debugLineNum = 545;BA.debugLine="pnlScrnOff.Color = Colors.ARGB(128,0,0,0)";
_pnlscrnoff.setColor(__c.Colors.ARGB((int) (128),(int) (0),(int) (0),(int) (0)));
 //BA.debugLineNum = 546;BA.debugLine="pnlBlankScreen_show(True)";
_pnlblankscreen_show(__c.True);
 //BA.debugLineNum = 547;BA.debugLine="End Sub";
return "";
}
public String  _turnscreen_off() throws Exception{
 //BA.debugLineNum = 658;BA.debugLine="Public Sub TurnScreen_Off";
 //BA.debugLineNum = 660;BA.debugLine="CheckForVisibleDialogsAndClose";
_checkforvisibledialogsandclose();
 //BA.debugLineNum = 661;BA.debugLine="pnlBlankScreen_show(True)";
_pnlblankscreen_show(__c.True);
 //BA.debugLineNum = 662;BA.debugLine="PowerCtrl.Screen_Off";
_powerctrl._screen_off /*String*/ ();
 //BA.debugLineNum = 664;BA.debugLine="IfPhotoShow_TurnOff";
_ifphotoshow_turnoff();
 //BA.debugLineNum = 666;BA.debugLine="CallSub2(Main,\"Dim_ActionBar\",gblConst.ACTIONBAR_";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"Dim_ActionBar",(Object)(_gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 667;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "ALARM_FIRED_BEFORE_START"))
	return _alarm_fired_before_start();
if (BA.fastSubCompare(sub, "ALARM_FIRED_START"))
	return _alarm_fired_start(((Number)args[0]).intValue());
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
if (BA.fastSubCompare(sub, "CHANGE_PAGES2"))
	return _change_pages2((String) args[0]);
if (BA.fastSubCompare(sub, "KILL_STARTATBOOT_SERVICE"))
	return _kill_startatboot_service();
if (BA.fastSubCompare(sub, "PROMPT_EXIT_QUIET"))
	return _prompt_exit_quiet();
if (BA.fastSubCompare(sub, "PROMPT_EXIT_RESET"))
	return _prompt_exit_reset();
if (BA.fastSubCompare(sub, "RESETSCRN_SLEEPCOUNTER"))
	return _resetscrn_sleepcounter();
if (BA.fastSubCompare(sub, "SEGTABMENU_TABCHANGED"))
	return _segtabmenu_tabchanged(((Number)args[0]).intValue());
if (BA.fastSubCompare(sub, "SETUP_ON_OFF_SCRN_EVENT"))
	return _setup_on_off_scrn_event();
if (BA.fastSubCompare(sub, "SHOW_1STRUN"))
	return _show_1strun();
if (BA.fastSubCompare(sub, "SHOW_TOAST"))
	return _show_toast((String) args[0]);
if (BA.fastSubCompare(sub, "SHOW_TOAST2"))
	return _show_toast2((String) args[0], ((Number)args[1]).intValue());
if (BA.fastSubCompare(sub, "SHOWVER"))
	return _showver();
return BA.SubDelegator.SubNotFound;
}
}
