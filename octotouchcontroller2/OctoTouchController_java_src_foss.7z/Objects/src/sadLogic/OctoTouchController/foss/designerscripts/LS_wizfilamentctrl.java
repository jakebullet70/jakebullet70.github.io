package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_wizfilamentctrl{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _pad="";
views.get("pnlmain").vw.setLeft((int)(0d));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
if ((BA.ObjectToBoolean( String.valueOf(anywheresoftware.b4a.keywords.LayoutBuilder.isPortrait())))) { 
;
views.get("pnlheader").vw.setLeft((int)(0d));
views.get("pnlheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlstart").vw.setLeft((int)(0d));
views.get("pnlstart").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlaction").vw.setLeft((int)(0d));
views.get("pnlaction").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlheader").vw.setTop((int)(0d));
views.get("pnlheader").vw.setHeight((int)((56d * scale) - (0d)));
views.get("lblheader").vw.setLeft((int)(0d));
views.get("lblheader").vw.setWidth((int)((80d / 100 * width) - (0d)));
views.get("lblheader").vw.setTop((int)(0d));
views.get("lblheader").vw.setHeight((int)((views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("lbltemp").vw.setTop((int)(0d));
views.get("lbltemp").vw.setHeight((int)((views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("lbltemp").vw.setLeft((int)((views.get("lblheader").vw.getLeft() + views.get("lblheader").vw.getWidth())));
views.get("lbltemp").vw.setWidth((int)((views.get("pnlheader").vw.getWidth()) - ((views.get("lblheader").vw.getLeft() + views.get("lblheader").vw.getWidth()))));
views.get("pnlmainbtns").vw.setLeft((int)(0d));
views.get("pnlmainbtns").vw.setWidth((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - (0d)));
views.get("pnlmainbtns").vw.setTop((int)((views.get("pnlmain").vw.getHeight())-(60d * scale)));
views.get("pnlmainbtns").vw.setHeight((int)((views.get("pnlmain").vw.getHeight()) - ((views.get("pnlmain").vw.getHeight())-(60d * scale))));
views.get("pnlstart").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlstart").vw.setHeight((int)((views.get("pnlmain").vw.getHeight())/2d - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlaction").vw.setTop((int)((views.get("pnlstart").vw.getTop() + views.get("pnlstart").vw.getHeight())));
views.get("pnlaction").vw.setHeight((int)((views.get("pnlmainbtns").vw.getTop()) - ((views.get("pnlstart").vw.getTop() + views.get("pnlstart").vw.getHeight()))));
;}else{ 
;
views.get("pnlheader").vw.setTop((int)(0d));
views.get("pnlheader").vw.setHeight((int)((50d * scale) - (0d)));
views.get("lblheader").vw.setLeft((int)(0d));
views.get("lblheader").vw.setWidth((int)((80d / 100 * width) - (0d)));
views.get("lblheader").vw.setTop((int)(0d));
views.get("lblheader").vw.setHeight((int)((views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("lbltemp").vw.setTop((int)(0d));
views.get("lbltemp").vw.setHeight((int)((views.get("pnlheader").vw.getHeight()) - (0d)));
views.get("lbltemp").vw.setLeft((int)((views.get("lblheader").vw.getLeft() + views.get("lblheader").vw.getWidth())));
views.get("lbltemp").vw.setWidth((int)((views.get("pnlheader").vw.getWidth()) - ((views.get("lblheader").vw.getLeft() + views.get("lblheader").vw.getWidth()))));
views.get("pnlstart").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlstart").vw.setHeight((int)((views.get("pnlmain").vw.getTop() + views.get("pnlmain").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlaction").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
views.get("pnlaction").vw.setHeight((int)((views.get("pnlmain").vw.getTop() + views.get("pnlmain").vw.getHeight()) - ((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight()))));
views.get("pnlstart").vw.setLeft((int)(0d));
views.get("pnlstart").vw.setWidth((int)((views.get("pnlmain").vw.getWidth())/2d - (0d)));
views.get("pnlaction").vw.setLeft((int)((views.get("pnlmain").vw.getWidth())/2d));
views.get("pnlaction").vw.setWidth((int)((views.get("pnlmain").vw.getWidth()) - ((views.get("pnlmain").vw.getWidth())/2d)));
_pad = BA.NumberToString((10d * scale));
views.get("lblstatus").vw.setLeft((int)((views.get("pnlstart").vw.getLeft())+Double.parseDouble(_pad)));
views.get("lblstatus").vw.setWidth((int)((views.get("pnlstart").vw.getLeft() + views.get("pnlstart").vw.getWidth())-Double.parseDouble(_pad) - ((views.get("pnlstart").vw.getLeft())+Double.parseDouble(_pad))));
views.get("lblstatus").vw.setTop((int)(Double.parseDouble(_pad)*2d));
views.get("lblstatus").vw.setHeight((int)((views.get("pnlstart").vw.getHeight())/2d - (Double.parseDouble(_pad)*2d)));
;};

}
}