package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgappupdate extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.dlgappupdate");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.dlgappupdate.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _basepnl = null;
public sadLogic.HomeCentral.b4xdialog _mdialog = null;
public sadLogic.HomeCentral.autotextsizelabel _lblaction = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblpb = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncontinue = null;
public int _days_between_checks = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public void  _btnctrl_click() throws Exception{
ResumableSub_btnCtrl_Click rsub = new ResumableSub_btnCtrl_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnCtrl_Click extends BA.ResumableSub {
public ResumableSub_btnCtrl_Click(sadLogic.HomeCentral.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgappupdate parent;
anywheresoftware.b4a.objects.B4XViewWrapper _btn = null;
String _downloaddir = "";
sadLogic.HomeCentral.httpjob _j = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
String _err = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 178;BA.debugLine="Dim btn As B4XView = mDialog.GetButton(xui.Dialog";
_btn = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btn = parent._mdialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 179;BA.debugLine="btn.Visible = False";
_btn.setVisible(parent.__c.False);
 //BA.debugLineNum = 180;BA.debugLine="btnContinue.Visible = False";
parent._btncontinue.setVisible(parent.__c.False);
 //BA.debugLineNum = 182;BA.debugLine="lblAction.Text = \"Downloading Update...\"";
parent._lblaction._settext /*Object*/ ((Object)("Downloading Update..."));
 //BA.debugLineNum = 185;BA.debugLine="Dim DownloadDir As String = GetDownloadDir 'ignor";
_downloaddir = parent._getdownloaddir();
 //BA.debugLineNum = 187;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j = new sadLogic.HomeCentral.httpjob();
 //BA.debugLineNum = 187;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 189;BA.debugLine="j.Download(gblConst.APK_NAME)";
_j._download /*String*/ (parent._gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 190;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 13;
return;
case 13:
//C
this.state = 1;
_j = (sadLogic.HomeCentral.httpjob) result[0];
;
 //BA.debugLineNum = 191;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 14;
return;
case 14:
//C
this.state = 1;
;
 //BA.debugLineNum = 193;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 12;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 12;
 //BA.debugLineNum = 195;BA.debugLine="lblAction.Text = \"Writing file...\"";
parent._lblaction._settext /*Object*/ ((Object)("Writing file..."));
 //BA.debugLineNum = 196;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 15;
return;
case 15:
//C
this.state = 12;
;
 //BA.debugLineNum = 198;BA.debugLine="Dim out As OutputStream = File.OpenOutput(Downlo";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
_out = parent.__c.File.OpenOutput(_downloaddir,parent._filehelpers._getfilenamefrompath /*String*/ (ba,parent._gblconst._apk_name /*String*/ ),parent.__c.False);
 //BA.debugLineNum = 201;BA.debugLine="File.Copy2(j.GetInputStream, out)";
parent.__c.File.Copy2((java.io.InputStream)(_j._getinputstream /*anywheresoftware.b4a.objects.streams.File.InputStreamWrapper*/ ().getObject()),(java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 202;BA.debugLine="out.Close '<------ very important";
_out.Close();
 //BA.debugLineNum = 203;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 204;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 16;
return;
case 16:
//C
this.state = 12;
;
 //BA.debugLineNum = 206;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus2(Main,\"";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus2 /*String*/ ((Object)(parent._main.getObject()),"Start_ApkInstall",(int) (300),(Object[])(new String[]{_downloaddir}));
 //BA.debugLineNum = 208;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel) '<--- c";
parent._mdialog._close /*boolean*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 209;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 213;BA.debugLine="Dim err As String = \"\"";
_err = "";
 //BA.debugLineNum = 215;BA.debugLine="If j.ErrorMessage.Contains(\"File not\") Then err";
if (true) break;

case 6:
//if
this.state = 11;
if (_j._errormessage /*String*/ .contains("File not")) { 
this.state = 8;
;}if (true) break;

case 8:
//C
this.state = 11;
_err = "File not found";
if (true) break;

case 11:
//C
this.state = 12;
;
 //BA.debugLineNum = 216;BA.debugLine="lblAction.Text = \"Download failed\" & CRLF & err";
parent._lblaction._settext /*Object*/ ((Object)("Download failed"+parent.__c.CRLF+_err));
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 220;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(sadLogic.HomeCentral.httpjob _j) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _checkifnewdownloadavail() throws Exception{
ResumableSub_CheckIfNewDownloadAvail rsub = new ResumableSub_CheckIfNewDownloadAvail(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_CheckIfNewDownloadAvail extends BA.ResumableSub {
public ResumableSub_CheckIfNewDownloadAvail(sadLogic.HomeCentral.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgappupdate parent;
long _olddate = 0L;
int _days = 0;
sadLogic.HomeCentral.httpdownloadstr _sm = null;
String _txt = "";
String[] _parts = null;
String _vercode = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 36;BA.debugLine="Dim oldDate As Long = Main.kvs.GetDefault(gblCons";
_olddate = BA.ObjectToLongNumber(parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getdefault /*Object*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(0)));
 //BA.debugLineNum = 37;BA.debugLine="If oldDate = 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_olddate==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 38;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTim";
parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 39;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 47;BA.debugLine="Dim days As Int = DateUtils.PeriodBetweenInDays(o";
_days = (parent._dateutils._periodbetweenindays(ba,_olddate,parent.__c.DateTime.getNow())).Days;
 //BA.debugLineNum = 49;BA.debugLine="LogIt.LogWrite(\"update check - days between: \" &";
parent._logit._logwrite /*String*/ (ba,"update check - days between: "+BA.NumberToString(_days),(int) (0));
 //BA.debugLineNum = 50;BA.debugLine="If days < DAYS_BETWEEN_CHECKS Then";
if (true) break;

case 5:
//if
this.state = 8;
if (_days<parent._days_between_checks) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 51;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 8:
//C
this.state = 9;
;
 //BA.debugLineNum = 55;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm = new sadLogic.HomeCentral.httpdownloadstr();
 //BA.debugLineNum = 55;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm._initialize /*String*/ (ba);
 //BA.debugLineNum = 56;BA.debugLine="Wait For (sm.SendRequest(gblConst.APK_FILE_INFO))";
parent.__c.WaitFor("complete", ba, this, _sm._sendrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._gblconst._apk_file_info /*String*/ ));
this.state = 19;
return;
case 19:
//C
this.state = 9;
_txt = (String) result[0];
;
 //BA.debugLineNum = 58;BA.debugLine="If txt.Contains(\"vcode=\") = False Then";
if (true) break;

case 9:
//if
this.state = 12;
if (_txt.contains("vcode=")==parent.__c.False) { 
this.state = 11;
}if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 59;BA.debugLine="Return False '--- no connection? bad ver info?";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 62;BA.debugLine="txt = txt.Replace(Chr(13),\"\") '<-- strip the chr(";
_txt = _txt.replace(BA.ObjectToString(parent.__c.Chr((int) (13))),"");
 //BA.debugLineNum = 64;BA.debugLine="Try";
if (true) break;

case 13:
//try
this.state = 18;
this.catchState = 17;
this.state = 15;
if (true) break;

case 15:
//C
this.state = 18;
this.catchState = 17;
 //BA.debugLineNum = 66;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTim";
parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 67;BA.debugLine="Dim parts() As String = Regex.Split(CRLF,txt)";
_parts = parent.__c.Regex.Split(parent.__c.CRLF,_txt);
 //BA.debugLineNum = 68;BA.debugLine="Dim VerCode As String = Regex.Split(\"=\",parts(0)";
_vercode = parent.__c.Regex.Split("=",_parts[(int) (0)])[(int) (1)];
 //BA.debugLineNum = 70;BA.debugLine="Return (VerCode.As(Int) > Application.VersionCod";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)((((int)(Double.parseDouble(_vercode)))>parent.__c.Application.getVersionCode())));return;};
 if (true) break;

case 17:
//C
this.state = 18;
this.catchState = 0;
 //BA.debugLineNum = 73;BA.debugLine="LogIt.LogWrite(LastException.Message,2)";
parent._logit._logwrite /*String*/ (ba,parent.__c.LastException(ba).getMessage(),(int) (2));
 //BA.debugLineNum = 74;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
if (true) break;

case 18:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(String _txt) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private const mModule As String = \"dlgAppUpdate\"'";
_mmodule = "dlgAppUpdate";
 //BA.debugLineNum = 10;BA.debugLine="Private mMainObj As B4XView, xui As XUI";
_mmainobj = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 13;BA.debugLine="Private BasePnl As B4XView, mDialog As B4XDialog";
_basepnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_mdialog = new sadLogic.HomeCentral.b4xdialog();
 //BA.debugLineNum = 14;BA.debugLine="Private lblAction As AutoTextSizeLabel,lblPB As L";
_lblaction = new sadLogic.HomeCentral.autotextsizelabel();
_lblpb = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private btnContinue As Button";
_btncontinue = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private Const DAYS_BETWEEN_CHECKS As Int = 26";
_days_between_checks = (int) (26);
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _cleanupapkdownload() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Public Sub CleanUpApkDownload";
 //BA.debugLineNum = 24;BA.debugLine="fileHelpers.SafeKill(Main.Provider.SharedFolder,g";
_filehelpers._safekill /*String*/ (ba,_main._provider /*sadLogic.HomeCentral.fileprovider*/ ._sharedfolder /*String*/ ,_gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 25;BA.debugLine="fileHelpers.SafeKill(Main.Provider.SharedFolder,g";
_filehelpers._safekill /*String*/ (ba,_main._provider /*sadLogic.HomeCentral.fileprovider*/ ._sharedfolder /*String*/ ,_gblconst._apk_file_info /*String*/ );
 //BA.debugLineNum = 26;BA.debugLine="fileHelpers.SafeKill(xui.DefaultFolder,gblConst.A";
_filehelpers._safekill /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 27;BA.debugLine="fileHelpers.SafeKill(xui.DefaultFolder,gblConst.A";
_filehelpers._safekill /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._apk_file_info /*String*/ );
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 90;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public String  _getdownloaddir() throws Exception{
String _dl = "";
 //BA.debugLineNum = 225;BA.debugLine="Private Sub GetDownloadDir() As String";
 //BA.debugLineNum = 228;BA.debugLine="Dim dl As String";
_dl = "";
 //BA.debugLineNum = 229;BA.debugLine="Try";
try { //BA.debugLineNum = 231;BA.debugLine="dl = Main.Provider.SharedFolder";
_dl = _main._provider /*sadLogic.HomeCentral.fileprovider*/ ._sharedfolder /*String*/ ;
 //BA.debugLineNum = 232;BA.debugLine="File.WriteString(dl,\"t.t\",\"test\")";
__c.File.WriteString(_dl,"t.t","test");
 //BA.debugLineNum = 233;BA.debugLine="File.Delete(dl,\"t.t\")";
__c.File.Delete(_dl,"t.t");
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 237;BA.debugLine="dl = xui.DefaultFolder";
_dl = _xui.getDefaultFolder();
 //BA.debugLineNum = 238;BA.debugLine="LogIt.LogWrite(\"Main.Provider.SharedFolder ERROR";
_logit._logwrite /*String*/ (ba,"Main.Provider.SharedFolder ERROR!",(int) (2));
 };
 //BA.debugLineNum = 242;BA.debugLine="Log(\"App update folder: \" & dl)";
__c.LogImpl("21364753","App update folder: "+_dl,0);
 //BA.debugLineNum = 243;BA.debugLine="Return dl '--- all good";
if (true) return _dl;
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public void  _grab_verinfo() throws Exception{
ResumableSub_Grab_VerInfo rsub = new ResumableSub_Grab_VerInfo(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Grab_VerInfo extends BA.ResumableSub {
public ResumableSub_Grab_VerInfo(sadLogic.HomeCentral.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgappupdate parent;
sadLogic.HomeCentral.httpdownloadstr _sm = null;
String _txt = "";
String[] _parts = null;
String _vercode = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 133;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 15;
return;
case 15:
//C
this.state = 1;
;
 //BA.debugLineNum = 135;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTime";
parent._main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 137;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm = new sadLogic.HomeCentral.httpdownloadstr();
 //BA.debugLineNum = 137;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm._initialize /*String*/ (ba);
 //BA.debugLineNum = 138;BA.debugLine="Wait For (sm.SendRequest(gblConst.APK_FILE_INFO))";
parent.__c.WaitFor("complete", ba, this, _sm._sendrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._gblconst._apk_file_info /*String*/ ));
this.state = 16;
return;
case 16:
//C
this.state = 1;
_txt = (String) result[0];
;
 //BA.debugLineNum = 140;BA.debugLine="If txt.Contains(\"vcode=\") = False Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_txt.contains("vcode=")==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 141;BA.debugLine="lblAction.BaseLabel.Height = lblAction.BaseLabel";
parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setHeight((int) (parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getHeight()+parent.__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 142;BA.debugLine="lblAction.Text = \"Error talking to update server";
parent._lblaction._settext /*Object*/ ((Object)("Error talking to update server."));
 //BA.debugLineNum = 143;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 147;BA.debugLine="txt = txt.Replace(Chr(13),\"\") '--- strip the chr(";
_txt = _txt.replace(BA.ObjectToString(parent.__c.Chr((int) (13))),"");
 //BA.debugLineNum = 149;BA.debugLine="Try";
if (true) break;

case 5:
//try
this.state = 14;
this.catchState = 13;
this.state = 7;
if (true) break;

case 7:
//C
this.state = 8;
this.catchState = 13;
 //BA.debugLineNum = 151;BA.debugLine="Dim parts() As String = Regex.Split(CRLF,txt)";
_parts = parent.__c.Regex.Split(parent.__c.CRLF,_txt);
 //BA.debugLineNum = 152;BA.debugLine="Dim VerCode As String = Regex.Split(\"=\",parts(0)";
_vercode = parent.__c.Regex.Split("=",_parts[(int) (0)])[(int) (1)];
 //BA.debugLineNum = 154;BA.debugLine="If VerCode.As(Int) <= Application.VersionCode Th";
if (true) break;

case 8:
//if
this.state = 11;
if (((int)(Double.parseDouble(_vercode)))<=parent.__c.Application.getVersionCode()) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 155;BA.debugLine="lblAction.Text = \"No update found.\"";
parent._lblaction._settext /*Object*/ ((Object)("No update found."));
 //BA.debugLineNum = 156;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 14;
;
 //BA.debugLineNum = 159;BA.debugLine="lblAction.BaseLabel.Top = lblAction.BaseLabel.To";
parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setTop((int) (parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getTop()-parent.__c.DipToCurrent((int) (6))));
 //BA.debugLineNum = 160;BA.debugLine="lblAction.Text = $\"Update found: V${Regex.Split(";
parent._lblaction._settext /*Object*/ ((Object)(("Update found: V"+parent.__c.SmartStringFormatter("",(Object)(parent.__c.Regex.Split("=",_parts[(int) (1)])[(int) (1)]))+"")));
 //BA.debugLineNum = 161;BA.debugLine="btnContinue.Visible = True";
parent._btncontinue.setVisible(parent.__c.True);
 //BA.debugLineNum = 162;BA.debugLine="btnContinue.Text = \"Download\"";
parent._btncontinue.setText(BA.ObjectToCharSequence("Download"));
 if (true) break;

case 13:
//C
this.state = 14;
this.catchState = 0;
 //BA.debugLineNum = 166;BA.debugLine="LogIt.LogWrite(\"GrabVerInfo-\" & LastException,2)";
parent._logit._logwrite /*String*/ (ba,"GrabVerInfo-"+BA.ObjectToString(parent.__c.LastException(ba)),(int) (2));
 //BA.debugLineNum = 167;BA.debugLine="lblAction.Text = \"Error parsing update file.\"";
parent._lblaction._settext /*Object*/ ((Object)("Error parsing update file."));
 if (true) break;
if (true) break;

case 14:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 172;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.HomeCentral.b4xdialog _dlg) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 81;BA.debugLine="Public Sub Initialize(dlg As B4XDialog)";
 //BA.debugLineNum = 83;BA.debugLine="mDialog = dlg";
_mdialog = _dlg;
 //BA.debugLineNum = 84;BA.debugLine="mMainObj = mpage.Root";
_mmainobj = _mpage._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ;
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.HomeCentral.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.HomeCentral.dlgappupdate parent;
sadLogic.HomeCentral.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 96;BA.debugLine="CleanUpApkDownload";
parent._cleanupapkdownload();
 //BA.debugLineNum = 97;BA.debugLine="BasePnl = xui.CreatePanel(\"\")";
parent._basepnl = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 98;BA.debugLine="BasePnl.SetLayoutAnimated(0, 0, 0, IIf(guiHelpers";
parent._basepnl.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (360)))) : ((Object)(parent.__c.PerXToCurrent((float) (96),ba)))))),parent.__c.DipToCurrent((int) (260)));
 //BA.debugLineNum = 99;BA.debugLine="BasePnl.LoadLayout(\"viewAppUpdate\")";
parent._basepnl.LoadLayout("viewAppUpdate",ba);
 //BA.debugLineNum = 101;BA.debugLine="lblAction.TextColor = clrTheme.txtNormal";
parent._lblaction._settextcolor /*int*/ (parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 102;BA.debugLine="lblAction.Text = \"Checking for update...\"";
parent._lblaction._settext /*Object*/ ((Object)("Checking for update..."));
 //BA.debugLineNum = 103;BA.debugLine="btnContinue.Visible = False";
parent._btncontinue.setVisible(parent.__c.False);
 //BA.debugLineNum = 104;BA.debugLine="lblPB.Visible   = False";
parent._lblpb.setVisible(parent.__c.False);
 //BA.debugLineNum = 105;BA.debugLine="lblPB.TextColor = clrTheme.txtNormal";
parent._lblpb.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 106;BA.debugLine="BasePnl.Color = clrTheme.Background";
parent._basepnl.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 109;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnContinue";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btncontinue});
 //BA.debugLineNum = 110;BA.debugLine="btnContinue.TextSize = NumberFormat2(btnContinue.";
parent._btncontinue.setTextSize((float) ((double)(Double.parseDouble(parent.__c.NumberFormat2(parent._btncontinue.getTextSize()/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))-(double)(BA.ObjectToNumber(((parent._guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 113;BA.debugLine="mDialog.Initialize(mMainObj)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj);
 //BA.debugLineNum = 114;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.HomeCentral.sadb4xdialoghelper();
 //BA.debugLineNum = 115;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 117;BA.debugLine="dlgHelper.ThemeDialogForm(\"App Update\")";
_dlghelper._themedialogform /*String*/ ((Object)("App Update"));
 //BA.debugLineNum = 118;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(BaseP";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._basepnl,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 119;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 122;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Grab";
parent._mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Grab_VerInfo",(int) (250));
 //BA.debugLineNum = 125;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 126;BA.debugLine="Return Result";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
