package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class sadb4xdraweradvanced extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.sadb4xdraweradvanced");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.sadb4xdraweradvanced.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _extrawidth = 0;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public int _msidewidth_left = 0;
public int _msidewidth_right = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _mleftpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mrightpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mdarkpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbasepanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mcenterpanel = null;
public float _touchxstart = 0f;
public float _touchystart = 0f;
public boolean _isopenleft = false;
public boolean _isopenright = false;
public boolean _handlinglswipe = false;
public boolean _handlingrswipe = false;
public boolean _startatscrimleft = false;
public boolean _startatscrimright = false;
public boolean _menabled = false;
public boolean _mrightpanelenabled = false;
public boolean _mleftpanelenabled = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public boolean  _base_onintercepttouchevent(int _action,float _x,float _y,Object _motionevent) throws Exception{
float _dx = 0f;
float _dy = 0f;
 //BA.debugLineNum = 150;BA.debugLine="Private Sub Base_OnInterceptTouchEvent (Action As";
 //BA.debugLineNum = 151;BA.debugLine="If mEnabled = False Then Return False";
if (_menabled==__c.False) { 
if (true) return __c.False;};
 //BA.debugLineNum = 152;BA.debugLine="If IsOpenLeft = False And IsOpenRight = False And";
if (_isopenleft==__c.False && _isopenright==__c.False && _mleftpanel.getLeft()+_mleftpanel.getWidth()+_extrawidth<_x && _x<_mrightpanel.getLeft()-_extrawidth) { 
 //BA.debugLineNum = 153;BA.debugLine="HandlingLSwipe = False";
_handlinglswipe = __c.False;
 //BA.debugLineNum = 154;BA.debugLine="HandlingRSwipe = False";
_handlingrswipe = __c.False;
 //BA.debugLineNum = 155;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 157;BA.debugLine="If IsOpenLeft And x > mLeftPanel.Left + mLeftPane";
if (_isopenleft && _x>_mleftpanel.getLeft()+_mleftpanel.getWidth()) { 
 //BA.debugLineNum = 159;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 161;BA.debugLine="If IsOpenRight And x < mRightPanel.Left Then";
if (_isopenright && _x<_mrightpanel.getLeft()) { 
 //BA.debugLineNum = 163;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 165;BA.debugLine="If HandlingLSwipe Or HandlingRSwipe Then Return T";
if (_handlinglswipe || _handlingrswipe) { 
if (true) return __c.True;};
 //BA.debugLineNum = 166;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_mbasepanel.TOUCH_ACTION_DOWN,_mbasepanel.TOUCH_ACTION_MOVE)) {
case 0: {
 //BA.debugLineNum = 168;BA.debugLine="TouchXStart = X";
_touchxstart = _x;
 //BA.debugLineNum = 169;BA.debugLine="TouchYStart = Y";
_touchystart = _y;
 //BA.debugLineNum = 170;BA.debugLine="HandlingLSwipe = False";
_handlinglswipe = __c.False;
 //BA.debugLineNum = 171;BA.debugLine="HandlingRSwipe = False";
_handlingrswipe = __c.False;
 break; }
case 1: {
 //BA.debugLineNum = 173;BA.debugLine="Dim dx As Float = Abs(x - TouchXStart)";
_dx = (float) (__c.Abs(_x-_touchxstart));
 //BA.debugLineNum = 174;BA.debugLine="Dim dy As Float = Abs(y - TouchYStart)";
_dy = (float) (__c.Abs(_y-_touchystart));
 //BA.debugLineNum = 175;BA.debugLine="If dy < 20dip And dx > 10dip Then";
if (_dy<__c.DipToCurrent((int) (20)) && _dx>__c.DipToCurrent((int) (10))) { 
 //BA.debugLineNum = 176;BA.debugLine="If (( x <= ExtraWidth And IsOpenRight = False";
if (((_x<=_extrawidth && _isopenright==__c.False) || _isopenleft)) { 
 //BA.debugLineNum = 177;BA.debugLine="HandlingLSwipe = True";
_handlinglswipe = __c.True;
 };
 //BA.debugLineNum = 179;BA.debugLine="If (( x >= mBasePanel.Width - ExtraWidth And I";
if (((_x>=_mbasepanel.getWidth()-_extrawidth && _isopenleft==__c.False) || _isopenright)) { 
 //BA.debugLineNum = 180;BA.debugLine="HandlingRSwipe = True";
_handlingrswipe = __c.True;
 };
 };
 break; }
}
;
 //BA.debugLineNum = 184;BA.debugLine="Return HandlingLSwipe Or HandlingRSwipe";
if (true) return _handlinglswipe || _handlingrswipe;
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return false;
}
public boolean  _base_ontouchevent(int _action,float _x,float _y,Object _motionevent) throws Exception{
int _leftpanelrightside = 0;
int _rightpanelleftside = 0;
float _dx = 0f;
 //BA.debugLineNum = 89;BA.debugLine="Private Sub Base_OnTouchEvent (Action As Int, X As";
 //BA.debugLineNum = 90;BA.debugLine="If mEnabled = False Then Return False";
if (_menabled==__c.False) { 
if (true) return __c.False;};
 //BA.debugLineNum = 92;BA.debugLine="If x <= ExtraWidth And Not(IsOpenRight) And mLeft";
if (_x<=_extrawidth && __c.Not(_isopenright) && _mleftpanelenabled==__c.False) { 
 //BA.debugLineNum = 93;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 96;BA.debugLine="If x > =  mBasePanel.Width - ExtraWidth And Not(I";
if (_x>=_mbasepanel.getWidth()-_extrawidth && __c.Not(_isopenleft) && _mrightpanelenabled==__c.False) { 
 //BA.debugLineNum = 97;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 100;BA.debugLine="Dim LeftPanelRightSide As Int = mLeftPanel.Left +";
_leftpanelrightside = (int) (_mleftpanel.getLeft()+_mleftpanel.getWidth());
 //BA.debugLineNum = 101;BA.debugLine="Dim RightPanelLeftSide As Int = mRightPanel.Left";
_rightpanelleftside = _mrightpanel.getLeft();
 //BA.debugLineNum = 103;BA.debugLine="If HandlingLSwipe = False And HandlingRSwipe = Fa";
if (_handlinglswipe==__c.False && _handlingrswipe==__c.False) { 
 //BA.debugLineNum = 104;BA.debugLine="If LeftPanelRightSide < x And x < RightPanelLeft";
if (_leftpanelrightside<_x && _x<_rightpanelleftside) { 
 //BA.debugLineNum = 105;BA.debugLine="If IsOpenLeft Then";
if (_isopenleft) { 
 //BA.debugLineNum = 106;BA.debugLine="TouchXStart = X";
_touchxstart = _x;
 //BA.debugLineNum = 107;BA.debugLine="If Action = mBasePanel.TOUCH_ACTION_UP Then se";
if (_action==_mbasepanel.TOUCH_ACTION_UP) { 
_setleftopen(__c.False);};
 //BA.debugLineNum = 108;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 110;BA.debugLine="If IsOpenRight Then";
if (_isopenright) { 
 //BA.debugLineNum = 111;BA.debugLine="TouchXStart = X";
_touchxstart = _x;
 //BA.debugLineNum = 112;BA.debugLine="If Action = mBasePanel.TOUCH_ACTION_UP Then se";
if (_action==_mbasepanel.TOUCH_ACTION_UP) { 
_setrightopen(__c.False);};
 //BA.debugLineNum = 113;BA.debugLine="Return True";
if (true) return __c.True;
 };
 //BA.debugLineNum = 115;BA.debugLine="If IsOpenLeft = False And x > LeftPanelRightSid";
if (_isopenleft==__c.False && _x>_leftpanelrightside+_extrawidth && _isopenright==__c.False && _x<_rightpanelleftside-_extrawidth) { 
 //BA.debugLineNum = 116;BA.debugLine="Return False";
if (true) return __c.False;
 };
 };
 };
 //BA.debugLineNum = 120;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_mbasepanel.TOUCH_ACTION_MOVE,_mbasepanel.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 122;BA.debugLine="Dim dx As Float = x - TouchXStart";
_dx = (float) (_x-_touchxstart);
 //BA.debugLineNum = 123;BA.debugLine="TouchXStart = X";
_touchxstart = _x;
 //BA.debugLineNum = 124;BA.debugLine="If HandlingLSwipe Or ( x <= ExtraWidth And Abs(";
if (_handlinglswipe || (_x<=_extrawidth && __c.Abs(_dx)>__c.DipToCurrent((int) (3)) && __c.Not(_isopenright))) { 
 //BA.debugLineNum = 125;BA.debugLine="HandlingLSwipe = True";
_handlinglswipe = __c.True;
 //BA.debugLineNum = 126;BA.debugLine="LeftChangeOffset(mLeftPanel.Left + dx, True, F";
_leftchangeoffset((float) (_mleftpanel.getLeft()+_dx),__c.True,__c.False);
 };
 //BA.debugLineNum = 128;BA.debugLine="If HandlingRSwipe Or ( x >= mBasePanel.Width -";
if (_handlingrswipe || (_x>=_mbasepanel.getWidth()-_extrawidth && __c.Abs(_dx)>__c.DipToCurrent((int) (3)) && __c.Not(_isopenleft))) { 
 //BA.debugLineNum = 129;BA.debugLine="HandlingRSwipe = True";
_handlingrswipe = __c.True;
 //BA.debugLineNum = 130;BA.debugLine="RightChangeOffset(mRightPanel.Left + dx, True,";
_rightchangeoffset((float) (_mrightpanel.getLeft()+_dx),__c.True,__c.False);
 }else if(_isopenright) { 
 //BA.debugLineNum = 132;BA.debugLine="HandlingRSwipe = True";
_handlingrswipe = __c.True;
 //BA.debugLineNum = 133;BA.debugLine="RightChangeOffset(mRightPanel.Left + dx, True,";
_rightchangeoffset((float) (_mrightpanel.getLeft()+_dx),__c.True,__c.False);
 };
 break; }
case 1: {
 //BA.debugLineNum = 136;BA.debugLine="If HandlingLSwipe Then";
if (_handlinglswipe) { 
 //BA.debugLineNum = 137;BA.debugLine="LeftChangeOffset(mLeftPanel.Left, False, False";
_leftchangeoffset((float) (_mleftpanel.getLeft()),__c.False,__c.False);
 };
 //BA.debugLineNum = 139;BA.debugLine="If HandlingRSwipe Then";
if (_handlingrswipe) { 
 //BA.debugLineNum = 140;BA.debugLine="RightChangeOffset(mRightPanel.Left, False, Fal";
_rightchangeoffset((float) (_mrightpanel.getLeft()),__c.False,__c.False);
 };
 //BA.debugLineNum = 142;BA.debugLine="HandlingLSwipe = False";
_handlinglswipe = __c.False;
 //BA.debugLineNum = 143;BA.debugLine="HandlingRSwipe = False";
_handlingrswipe = __c.False;
 break; }
}
;
 //BA.debugLineNum = 146;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
return false;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 33;BA.debugLine="Public ExtraWidth As Int = 30dip";
_extrawidth = __c.DipToCurrent((int) (30));
 //BA.debugLineNum = 35;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 36;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 37;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 38;BA.debugLine="Private mSideWidth_Left,mSideWidth_Right As Int";
_msidewidth_left = 0;
_msidewidth_right = 0;
 //BA.debugLineNum = 39;BA.debugLine="Private mLeftPanel As B4XView";
_mleftpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private mRightPanel As B4XView";
_mrightpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private mDarkPanel As B4XView";
_mdarkpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private mBasePanel As B4XView";
_mbasepanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private mCenterPanel As B4XView";
_mcenterpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private TouchXStart, TouchYStart As Float 'ignore";
_touchxstart = 0f;
_touchystart = 0f;
 //BA.debugLineNum = 45;BA.debugLine="Private IsOpenLeft As Boolean";
_isopenleft = false;
 //BA.debugLineNum = 46;BA.debugLine="Private IsOpenRight As Boolean";
_isopenright = false;
 //BA.debugLineNum = 47;BA.debugLine="Private HandlingLSwipe As Boolean";
_handlinglswipe = false;
 //BA.debugLineNum = 48;BA.debugLine="Private HandlingRSwipe As Boolean";
_handlingrswipe = false;
 //BA.debugLineNum = 49;BA.debugLine="Private StartAtScrimLeft,StartAtScrimRight As Boo";
_startatscrimleft = false;
_startatscrimright = false;
 //BA.debugLineNum = 50;BA.debugLine="Private mEnabled As Boolean = True";
_menabled = __c.True;
 //BA.debugLineNum = 51;BA.debugLine="Private mRightPanelEnabled As Boolean = False";
_mrightpanelenabled = __c.False;
 //BA.debugLineNum = 52;BA.debugLine="Private mLeftPanelEnabled As Boolean = True";
_mleftpanelenabled = __c.True;
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getcenterpanel() throws Exception{
 //BA.debugLineNum = 299;BA.debugLine="Public Sub getCenterPanel As B4XView";
 //BA.debugLineNum = 300;BA.debugLine="Return mCenterPanel";
if (true) return _mcenterpanel;
 //BA.debugLineNum = 301;BA.debugLine="End Sub";
return null;
}
public boolean  _getgestureenabled() throws Exception{
 //BA.debugLineNum = 350;BA.debugLine="Public Sub getGestureEnabled As Boolean";
 //BA.debugLineNum = 351;BA.debugLine="Return mEnabled";
if (true) return _menabled;
 //BA.debugLineNum = 352;BA.debugLine="End Sub";
return false;
}
public boolean  _getleftopen() throws Exception{
 //BA.debugLineNum = 262;BA.debugLine="Public Sub getLeftOpen As Boolean";
 //BA.debugLineNum = 263;BA.debugLine="Return IsOpenLeft";
if (true) return _isopenleft;
 //BA.debugLineNum = 264;BA.debugLine="End Sub";
return false;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getleftpanel() throws Exception{
 //BA.debugLineNum = 277;BA.debugLine="Public Sub getLeftPanel As B4XView";
 //BA.debugLineNum = 278;BA.debugLine="Return mLeftPanel";
if (true) return _mleftpanel;
 //BA.debugLineNum = 279;BA.debugLine="End Sub";
return null;
}
public boolean  _getleftpanelenabled() throws Exception{
 //BA.debugLineNum = 358;BA.debugLine="Public Sub getLeftPanelEnabled As Boolean";
 //BA.debugLineNum = 359;BA.debugLine="Return mLeftPanelEnabled";
if (true) return _mleftpanelenabled;
 //BA.debugLineNum = 360;BA.debugLine="End Sub";
return false;
}
public boolean  _getrightopen() throws Exception{
 //BA.debugLineNum = 281;BA.debugLine="Public Sub getRightOpen As Boolean";
 //BA.debugLineNum = 282;BA.debugLine="Return IsOpenRight";
if (true) return _isopenright;
 //BA.debugLineNum = 283;BA.debugLine="End Sub";
return false;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getrightpanel() throws Exception{
 //BA.debugLineNum = 295;BA.debugLine="Public Sub getRightPanel As B4XView";
 //BA.debugLineNum = 296;BA.debugLine="Return mRightPanel";
if (true) return _mrightpanel;
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return null;
}
public boolean  _getrightpanelenabled() throws Exception{
 //BA.debugLineNum = 366;BA.debugLine="Public Sub getRightPanelEnabled As Boolean";
 //BA.debugLineNum = 367;BA.debugLine="Return mRightPanelEnabled";
if (true) return _mrightpanelenabled;
 //BA.debugLineNum = 368;BA.debugLine="End Sub";
return false;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname,anywheresoftware.b4a.objects.B4XViewWrapper _parent,int _sidewidth) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.objects.TouchPanelCreator _creator = null;
anywheresoftware.b4a.objects.PanelWrapper _pl = null;
anywheresoftware.b4a.objects.PanelWrapper _pr = null;
 //BA.debugLineNum = 56;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 57;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 58;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 59;BA.debugLine="mSideWidth_Left = SideWidth";
_msidewidth_left = _sidewidth;
 //BA.debugLineNum = 60;BA.debugLine="mSideWidth_Right = SideWidth";
_msidewidth_right = _sidewidth;
 //BA.debugLineNum = 62;BA.debugLine="Dim creator As TouchPanelCreator";
_creator = new anywheresoftware.b4a.objects.TouchPanelCreator();
 //BA.debugLineNum = 63;BA.debugLine="mBasePanel = creator.CreateTouchPanel(\"base\")";
_mbasepanel = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_creator.CreateTouchPanel(ba,"base").getObject()));
 //BA.debugLineNum = 65;BA.debugLine="Parent.AddView(mBasePanel, 0, 0, Parent.Width, Pa";
_parent.AddView((android.view.View)(_mbasepanel.getObject()),(int) (0),(int) (0),_parent.getWidth(),_parent.getHeight());
 //BA.debugLineNum = 66;BA.debugLine="mCenterPanel = xui.CreatePanel(\"\")";
_mcenterpanel = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 67;BA.debugLine="mBasePanel.AddView(mCenterPanel, 0, 0, mBasePanel";
_mbasepanel.AddView((android.view.View)(_mcenterpanel.getObject()),(int) (0),(int) (0),_mbasepanel.getWidth(),_mbasepanel.getHeight());
 //BA.debugLineNum = 68;BA.debugLine="mDarkPanel = xui.CreatePanel(\"dark\")";
_mdarkpanel = _xui.CreatePanel(ba,"dark");
 //BA.debugLineNum = 69;BA.debugLine="mBasePanel.AddView(mDarkPanel, 0, 0, mBasePanel.W";
_mbasepanel.AddView((android.view.View)(_mdarkpanel.getObject()),(int) (0),(int) (0),_mbasepanel.getWidth(),_mbasepanel.getHeight());
 //BA.debugLineNum = 70;BA.debugLine="mLeftPanel = xui.CreatePanel(\"LeftPanel\")";
_mleftpanel = _xui.CreatePanel(ba,"LeftPanel");
 //BA.debugLineNum = 71;BA.debugLine="mBasePanel.AddView(mLeftPanel, -SideWidth, 0, Sid";
_mbasepanel.AddView((android.view.View)(_mleftpanel.getObject()),(int) (-_sidewidth),(int) (0),_sidewidth,_mbasepanel.getHeight());
 //BA.debugLineNum = 72;BA.debugLine="mRightPanel = xui.CreatePanel(\"RightPanel\")";
_mrightpanel = _xui.CreatePanel(ba,"RightPanel");
 //BA.debugLineNum = 73;BA.debugLine="mBasePanel.AddView(mRightPanel, mBasePanel.Width,";
_mbasepanel.AddView((android.view.View)(_mrightpanel.getObject()),_mbasepanel.getWidth(),(int) (0),_sidewidth,_mbasepanel.getHeight());
 //BA.debugLineNum = 75;BA.debugLine="Dim pL As Panel = mLeftPanel";
_pl = new anywheresoftware.b4a.objects.PanelWrapper();
_pl = (anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(_mleftpanel.getObject()));
 //BA.debugLineNum = 76;BA.debugLine="pL.Elevation = 4dip";
_pl.setElevation((float) (__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 77;BA.debugLine="Dim pR As Panel = mRightPanel";
_pr = new anywheresoftware.b4a.objects.PanelWrapper();
_pr = (anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(_mrightpanel.getObject()));
 //BA.debugLineNum = 78;BA.debugLine="pR.Elevation = 4dip";
_pr.setElevation((float) (__c.DipToCurrent((int) (4))));
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public String  _leftchangeoffset(float _x,boolean _currentlytouching,boolean _noanimation) throws Exception{
int _visibleoffset = 0;
int _dx = 0;
int _duration = 0;
 //BA.debugLineNum = 189;BA.debugLine="Private Sub LeftChangeOffset (x As Float, Currentl";
 //BA.debugLineNum = 190;BA.debugLine="If mLeftPanelEnabled Then";
if (_mleftpanelenabled) { 
 //BA.debugLineNum = 191;BA.debugLine="x = Max(-mSideWidth_Left, Min(0, x))";
_x = (float) (__c.Max(-_msidewidth_left,__c.Min(0,_x)));
 //BA.debugLineNum = 192;BA.debugLine="Dim VisibleOffset As Int = mSideWidth_Left + x";
_visibleoffset = (int) (_msidewidth_left+_x);
 //BA.debugLineNum = 194;BA.debugLine="If CurrentlyTouching = False Then";
if (_currentlytouching==__c.False) { 
 //BA.debugLineNum = 195;BA.debugLine="If (IsOpenLeft And VisibleOffset < 0.8 * mSideW";
if ((_isopenleft && _visibleoffset<0.8*_msidewidth_left) || (_isopenleft==__c.False && _visibleoffset<0.2*_msidewidth_left)) { 
 //BA.debugLineNum = 196;BA.debugLine="x = -mSideWidth_Left";
_x = (float) (-_msidewidth_left);
 //BA.debugLineNum = 197;BA.debugLine="IsOpenLeft = False";
_isopenleft = __c.False;
 //BA.debugLineNum = 198;BA.debugLine="SetIsOpen(False)";
_setisopen(__c.False);
 }else {
 //BA.debugLineNum = 200;BA.debugLine="x = 0";
_x = (float) (0);
 //BA.debugLineNum = 201;BA.debugLine="IsOpenLeft = True";
_isopenleft = __c.True;
 //BA.debugLineNum = 202;BA.debugLine="SetIsOpen(True)";
_setisopen(__c.True);
 };
 //BA.debugLineNum = 204;BA.debugLine="VisibleOffset = mSideWidth_Left + x";
_visibleoffset = (int) (_msidewidth_left+_x);
 //BA.debugLineNum = 205;BA.debugLine="Dim dx As Int = Abs(mLeftPanel.Left - x)";
_dx = (int) (__c.Abs(_mleftpanel.getLeft()-_x));
 //BA.debugLineNum = 206;BA.debugLine="Dim duration As Int = Max(0, 200 * dx / mSideWi";
_duration = (int) (__c.Max(0,200*_dx/(double)_msidewidth_left));
 //BA.debugLineNum = 207;BA.debugLine="If NoAnimation Then duration = 0";
if (_noanimation) { 
_duration = (int) (0);};
 //BA.debugLineNum = 208;BA.debugLine="mLeftPanel.SetLayoutAnimated(duration, x, 0, mL";
_mleftpanel.SetLayoutAnimated(_duration,(int) (_x),(int) (0),_mleftpanel.getWidth(),_mleftpanel.getHeight());
 //BA.debugLineNum = 209;BA.debugLine="mDarkPanel.SetColorAnimated(duration, mDarkPane";
_mdarkpanel.SetColorAnimated(_duration,_mdarkpanel.getColor(),_offsettocolor(_visibleoffset,__c.True));
 }else {
 //BA.debugLineNum = 212;BA.debugLine="mDarkPanel.Color = OffsetToColor(VisibleOffset,";
_mdarkpanel.setColor(_offsettocolor(_visibleoffset,__c.True));
 //BA.debugLineNum = 213;BA.debugLine="mLeftPanel.Left = x";
_mleftpanel.setLeft((int) (_x));
 };
 };
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return "";
}
public String  _leftpanel_click() throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Private Sub LeftPanel_Click";
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public int  _offsettocolor(int _x,boolean _leftpanel) throws Exception{
float _visible = 0f;
 //BA.debugLineNum = 257;BA.debugLine="Private Sub OffsetToColor (x As Int,LeftPanel As B";
 //BA.debugLineNum = 258;BA.debugLine="Dim Visible As Float = x / IIf(LeftPanel,mSideWid";
_visible = (float) (_x/(double)(double)(BA.ObjectToNumber(((_leftpanel) ? ((Object)(_msidewidth_left)) : ((Object)(_msidewidth_right))))));
 //BA.debugLineNum = 259;BA.debugLine="Return xui.Color_ARGB(100 * Visible, 0, 0, 0)";
if (true) return _xui.Color_ARGB((int) (100*_visible),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 260;BA.debugLine="End Sub";
return 0;
}
public String  _resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 303;BA.debugLine="Public Sub Resize(Width As Int, Height As Int)";
 //BA.debugLineNum = 304;BA.debugLine="If IsOpenLeft Then LeftChangeOffset(-mSideWidth_L";
if (_isopenleft) { 
_leftchangeoffset((float) (-_msidewidth_left),__c.False,__c.True);};
 //BA.debugLineNum = 305;BA.debugLine="If IsOpenRight Then RightChangeOffset(Width, Fals";
if (_isopenright) { 
_rightchangeoffset((float) (_width),__c.False,__c.True);};
 //BA.debugLineNum = 306;BA.debugLine="mBasePanel.SetLayoutAnimated(0, 0, 0, Width, Heig";
_mbasepanel.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 307;BA.debugLine="mLeftPanel.SetLayoutAnimated(0, mLeftPanel.Left,";
_mleftpanel.SetLayoutAnimated((int) (0),_mleftpanel.getLeft(),(int) (0),_msidewidth_left,_mbasepanel.getHeight());
 //BA.debugLineNum = 308;BA.debugLine="mRightPanel.SetLayoutAnimated(0, mRightPanel.Left";
_mrightpanel.SetLayoutAnimated((int) (0),_mrightpanel.getLeft(),(int) (0),_msidewidth_right,_mbasepanel.getHeight());
 //BA.debugLineNum = 309;BA.debugLine="mDarkPanel.SetLayoutAnimated(0, 0, 0, Width, Heig";
_mdarkpanel.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 310;BA.debugLine="mCenterPanel.SetLayoutAnimated(0, 0, 0, Width, He";
_mcenterpanel.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 311;BA.debugLine="End Sub";
return "";
}
public String  _rightchangeoffset(float _x,boolean _currentlytouching,boolean _noanimation) throws Exception{
int _visibleoffset = 0;
int _dx = 0;
int _duration = 0;
 //BA.debugLineNum = 218;BA.debugLine="Private Sub RightChangeOffset (x As Float, Current";
 //BA.debugLineNum = 219;BA.debugLine="If mRightPanelEnabled Then";
if (_mrightpanelenabled) { 
 //BA.debugLineNum = 220;BA.debugLine="x = Max(mBasePanel.Width-mSideWidth_Right, Min(m";
_x = (float) (__c.Max(_mbasepanel.getWidth()-_msidewidth_right,__c.Min(_mbasepanel.getWidth(),_x)));
 //BA.debugLineNum = 221;BA.debugLine="Dim VisibleOffset As Int = mBasePanel.Width - x";
_visibleoffset = (int) (_mbasepanel.getWidth()-_x);
 //BA.debugLineNum = 223;BA.debugLine="If CurrentlyTouching = False Then";
if (_currentlytouching==__c.False) { 
 //BA.debugLineNum = 224;BA.debugLine="If (IsOpenRight And VisibleOffset < 0.8 * mSide";
if ((_isopenright && _visibleoffset<0.8*_msidewidth_right) || (_isopenright==__c.False && _visibleoffset<0.2*_msidewidth_right)) { 
 //BA.debugLineNum = 225;BA.debugLine="x = mBasePanel.Width";
_x = (float) (_mbasepanel.getWidth());
 //BA.debugLineNum = 226;BA.debugLine="IsOpenRight = False";
_isopenright = __c.False;
 //BA.debugLineNum = 227;BA.debugLine="SetIsOpen(False)";
_setisopen(__c.False);
 }else {
 //BA.debugLineNum = 229;BA.debugLine="x = mBasePanel.Width-mSideWidth_Right";
_x = (float) (_mbasepanel.getWidth()-_msidewidth_right);
 //BA.debugLineNum = 230;BA.debugLine="IsOpenRight = True";
_isopenright = __c.True;
 //BA.debugLineNum = 231;BA.debugLine="SetIsOpen(True)";
_setisopen(__c.True);
 };
 //BA.debugLineNum = 233;BA.debugLine="VisibleOffset = mBasePanel.Width - x";
_visibleoffset = (int) (_mbasepanel.getWidth()-_x);
 //BA.debugLineNum = 234;BA.debugLine="Dim dx As Int = Abs(mRightPanel.Left - x)";
_dx = (int) (__c.Abs(_mrightpanel.getLeft()-_x));
 //BA.debugLineNum = 235;BA.debugLine="Dim duration As Int = Max(0, 200 * dx / mSideWi";
_duration = (int) (__c.Max(0,200*_dx/(double)_msidewidth_right));
 //BA.debugLineNum = 236;BA.debugLine="If NoAnimation Then duration = 0";
if (_noanimation) { 
_duration = (int) (0);};
 //BA.debugLineNum = 237;BA.debugLine="mRightPanel.SetLayoutAnimated(duration, x, 0, m";
_mrightpanel.SetLayoutAnimated(_duration,(int) (_x),(int) (0),_mrightpanel.getWidth(),_mrightpanel.getHeight());
 //BA.debugLineNum = 238;BA.debugLine="mDarkPanel.SetColorAnimated(duration, mDarkPane";
_mdarkpanel.SetColorAnimated(_duration,_mdarkpanel.getColor(),_offsettocolor(_visibleoffset,__c.False));
 }else {
 //BA.debugLineNum = 241;BA.debugLine="mDarkPanel.Color = OffsetToColor(VisibleOffset,";
_mdarkpanel.setColor(_offsettocolor(_visibleoffset,__c.False));
 //BA.debugLineNum = 242;BA.debugLine="mRightPanel.Left = x";
_mrightpanel.setLeft((int) (_x));
 };
 };
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public String  _setgestureenabled(boolean _b) throws Exception{
 //BA.debugLineNum = 354;BA.debugLine="Public Sub setGestureEnabled (b As Boolean)";
 //BA.debugLineNum = 355;BA.debugLine="mEnabled = b";
_menabled = _b;
 //BA.debugLineNum = 356;BA.debugLine="End Sub";
return "";
}
public String  _setisopen(boolean _newstate) throws Exception{
 //BA.debugLineNum = 248;BA.debugLine="Private Sub SetIsOpen (NewState As Boolean)";
 //BA.debugLineNum = 252;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_StateC";
if (_xui.SubExists(ba,_mcallback,_meventname+"_StateChanged",(int) (1))) { 
 //BA.debugLineNum = 253;BA.debugLine="CallSubDelayed2(mCallBack,  mEventName & \"_State";
__c.CallSubDelayed2(ba,_mcallback,_meventname+"_StateChanged",(Object)(_newstate));
 };
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return "";
}
public String  _setleftopen(boolean _b) throws Exception{
float _x = 0f;
 //BA.debugLineNum = 267;BA.debugLine="Public Sub setLeftOpen (b As Boolean)";
 //BA.debugLineNum = 268;BA.debugLine="If mLeftPanelEnabled Then";
if (_mleftpanelenabled) { 
 //BA.debugLineNum = 269;BA.debugLine="If b = IsOpenLeft Then Return";
if (_b==_isopenleft) { 
if (true) return "";};
 //BA.debugLineNum = 270;BA.debugLine="If b Then setRightOpen(False)";
if (_b) { 
_setrightopen(__c.False);};
 //BA.debugLineNum = 271;BA.debugLine="Dim x As Float";
_x = 0f;
 //BA.debugLineNum = 272;BA.debugLine="If b Then x = 0 Else x = -mSideWidth_Left";
if (_b) { 
_x = (float) (0);}
else {
_x = (float) (-_msidewidth_left);};
 //BA.debugLineNum = 273;BA.debugLine="LeftChangeOffset(x, False, False)";
_leftchangeoffset(_x,__c.False,__c.False);
 };
 //BA.debugLineNum = 275;BA.debugLine="End Sub";
return "";
}
public String  _setleftpanelenabled(boolean _b) throws Exception{
 //BA.debugLineNum = 362;BA.debugLine="Public Sub setLeftPanelEnabled(b As Boolean)";
 //BA.debugLineNum = 363;BA.debugLine="mLeftPanelEnabled = b";
_mleftpanelenabled = _b;
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return "";
}
public String  _setrightopen(boolean _b) throws Exception{
float _x = 0f;
 //BA.debugLineNum = 285;BA.debugLine="Public Sub setRightOpen (b As Boolean)";
 //BA.debugLineNum = 286;BA.debugLine="If mRightPanelEnabled Then";
if (_mrightpanelenabled) { 
 //BA.debugLineNum = 287;BA.debugLine="If b = IsOpenRight Then Return";
if (_b==_isopenright) { 
if (true) return "";};
 //BA.debugLineNum = 288;BA.debugLine="If b Then setLeftOpen(False)";
if (_b) { 
_setleftopen(__c.False);};
 //BA.debugLineNum = 289;BA.debugLine="Dim x As Float";
_x = 0f;
 //BA.debugLineNum = 290;BA.debugLine="If b Then x = mBasePanel.Width-mSideWidth_Right";
if (_b) { 
_x = (float) (_mbasepanel.getWidth()-_msidewidth_right);}
else {
_x = (float) (_mbasepanel.getWidth());};
 //BA.debugLineNum = 291;BA.debugLine="RightChangeOffset(x, False, False)";
_rightchangeoffset(_x,__c.False,__c.False);
 };
 //BA.debugLineNum = 293;BA.debugLine="End Sub";
return "";
}
public String  _setrightpanelenabled(boolean _b) throws Exception{
 //BA.debugLineNum = 370;BA.debugLine="Public Sub setRightPanelEnabled(b As Boolean)";
 //BA.debugLineNum = 371;BA.debugLine="mRightPanelEnabled = b";
_mrightpanelenabled = _b;
 //BA.debugLineNum = 372;BA.debugLine="End Sub";
return "";
}
public String  _setsidewidth(float _width,boolean _smooth) throws Exception{
long _duration = 0L;
 //BA.debugLineNum = 313;BA.debugLine="Public Sub SetSideWidth(Width As Float,Smooth As B";
 //BA.debugLineNum = 314;BA.debugLine="mSideWidth_Left = Width";
_msidewidth_left = (int) (_width);
 //BA.debugLineNum = 315;BA.debugLine="mSideWidth_Right = Width";
_msidewidth_right = (int) (_width);
 //BA.debugLineNum = 316;BA.debugLine="Dim Duration As Long = IIf(Smooth,250,0)";
_duration = BA.ObjectToLongNumber(((_smooth) ? ((Object)(250)) : ((Object)(0))));
 //BA.debugLineNum = 318;BA.debugLine="If IsOpenLeft Then";
if (_isopenleft) { 
 //BA.debugLineNum = 319;BA.debugLine="mLeftPanel.SetLayoutAnimated(Duration,mLeftPanel";
_mleftpanel.SetLayoutAnimated((int) (_duration),_mleftpanel.getLeft(),_mleftpanel.getTop(),_msidewidth_left,_mleftpanel.getHeight());
 }else if(_isopenright) { 
 //BA.debugLineNum = 321;BA.debugLine="mRightPanel.SetLayoutAnimated(Duration,mBasePane";
_mrightpanel.SetLayoutAnimated((int) (_duration),(int) (_mbasepanel.getWidth()-_msidewidth_right),_mrightpanel.getTop(),_msidewidth_right,_mrightpanel.getHeight());
 }else {
 //BA.debugLineNum = 323;BA.debugLine="mLeftPanel.SetLayoutAnimated(0,-mSideWidth_Left,";
_mleftpanel.SetLayoutAnimated((int) (0),(int) (-_msidewidth_left),_mleftpanel.getTop(),_msidewidth_left,_mleftpanel.getHeight());
 //BA.debugLineNum = 324;BA.debugLine="mRightPanel.SetLayoutAnimated(0,mBasePanel.Width";
_mrightpanel.SetLayoutAnimated((int) (0),_mbasepanel.getWidth(),_mrightpanel.getTop(),_msidewidth_right,_mrightpanel.getHeight());
 };
 //BA.debugLineNum = 326;BA.debugLine="End Sub";
return "";
}
public String  _setsidewidth_left(float _width,boolean _smooth) throws Exception{
long _duration = 0L;
 //BA.debugLineNum = 328;BA.debugLine="Public Sub SetSideWidth_Left(Width As Float,Smooth";
 //BA.debugLineNum = 329;BA.debugLine="mSideWidth_Left = Width";
_msidewidth_left = (int) (_width);
 //BA.debugLineNum = 330;BA.debugLine="Dim Duration As Long = IIf(Smooth,250,0)";
_duration = BA.ObjectToLongNumber(((_smooth) ? ((Object)(250)) : ((Object)(0))));
 //BA.debugLineNum = 332;BA.debugLine="If IsOpenLeft Then";
if (_isopenleft) { 
 //BA.debugLineNum = 333;BA.debugLine="mLeftPanel.SetLayoutAnimated(Duration,mLeftPanel";
_mleftpanel.SetLayoutAnimated((int) (_duration),_mleftpanel.getLeft(),_mleftpanel.getTop(),_msidewidth_left,_mleftpanel.getHeight());
 }else {
 //BA.debugLineNum = 335;BA.debugLine="mLeftPanel.SetLayoutAnimated(0,-mSideWidth_Left,";
_mleftpanel.SetLayoutAnimated((int) (0),(int) (-_msidewidth_left),_mleftpanel.getTop(),_msidewidth_left,_mleftpanel.getHeight());
 };
 //BA.debugLineNum = 337;BA.debugLine="End Sub";
return "";
}
public String  _setsidewidth_right(float _width,boolean _smooth) throws Exception{
long _duration = 0L;
 //BA.debugLineNum = 339;BA.debugLine="Public Sub SetSideWidth_Right(Width As Float,Smoot";
 //BA.debugLineNum = 340;BA.debugLine="mSideWidth_Right = Width";
_msidewidth_right = (int) (_width);
 //BA.debugLineNum = 341;BA.debugLine="Dim Duration As Long = IIf(Smooth,250,0)";
_duration = BA.ObjectToLongNumber(((_smooth) ? ((Object)(250)) : ((Object)(0))));
 //BA.debugLineNum = 343;BA.debugLine="If IsOpenRight Then";
if (_isopenright) { 
 //BA.debugLineNum = 344;BA.debugLine="mRightPanel.SetLayoutAnimated(Duration,mBasePane";
_mrightpanel.SetLayoutAnimated((int) (_duration),(int) (_mbasepanel.getWidth()-_msidewidth_right),_mrightpanel.getTop(),_msidewidth_right,_mrightpanel.getHeight());
 }else {
 //BA.debugLineNum = 346;BA.debugLine="mRightPanel.SetLayoutAnimated(0,mBasePanel.Width";
_mrightpanel.SetLayoutAnimated((int) (0),_mbasepanel.getWidth(),_mrightpanel.getTop(),_msidewidth_right,_mrightpanel.getHeight());
 };
 //BA.debugLineNum = 348;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
