package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgoctosetup extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgoctosetup");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgoctosetup.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _mtitle = "";
public String _meventname = "";
public sadLogic.OctoTouchController.b4xloadingindicator _b4xloadingindicator1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncheckconnection = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btngetoctokey = null;
public sadLogic.OctoTouchController.b4xfloattextfield _txtoctokey = null;
public sadLogic.OctoTouchController.b4xfloattextfield _txtprinterdesc = null;
public sadLogic.OctoTouchController.b4xfloattextfield _txtprinterip = null;
public sadLogic.OctoTouchController.b4xfloattextfield _txtprinterport = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public boolean _validconnection = false;
public sadLogic.OctoTouchController.checkoctoconnection _oconnectioncheck = null;
public sadLogic.OctoTouchController.requestapikey _ogetoctokey = null;
public sadLogic.OctoTouchController.b4xdialog _dialog = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public void  _btncheckconnection_click() throws Exception{
ResumableSub_btnCheckConnection_Click rsub = new ResumableSub_btnCheckConnection_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnCheckConnection_Click extends BA.ResumableSub {
public ResumableSub_btnCheckConnection_Click(sadLogic.OctoTouchController.dlgoctosetup parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgoctosetup parent;
String _msg = "";
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
float _w = 0f;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 189;BA.debugLine="Dim msg As String = CheckInputs";
_msg = parent._checkinputs();
 //BA.debugLineNum = 190;BA.debugLine="If msg.Length <> 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_msg.length()!=0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 191;BA.debugLine="B4XLoadingIndicator1.Hide";
parent._b4xloadingindicator1._hide /*String*/ ();
 //BA.debugLineNum = 192;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 193;BA.debugLine="Dim w As Float = IIf(guiHelpers.gIsLandScape,460";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (460)))) : ((Object)(parent.__c.PerXToCurrent((float) (94),ba))))));
 //BA.debugLineNum = 194;BA.debugLine="mb.Initialize(mMainObj.Root,\"Problem\",w, 220dip,";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Problem",_w,(float) (parent.__c.DipToCurrent((int) (220))),parent.__c.False);
 //BA.debugLineNum = 195;BA.debugLine="Wait For (mb.Show(msg,gblConst.MB_ICON_WARNING,\"";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_msg,parent._gblconst._mb_icon_warning /*String*/ ,"","","OK"));
this.state = 5;
return;
case 5:
//C
this.state = 4;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 196;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 200;BA.debugLine="pnlMain.Enabled = False";
parent._pnlmain.setEnabled(parent.__c.False);
 //BA.debugLineNum = 202;BA.debugLine="EnableDisableBtns(False)";
parent._enabledisablebtns(parent.__c.False);
 //BA.debugLineNum = 203;BA.debugLine="B4XLoadingIndicator1.Show";
parent._b4xloadingindicator1._show /*String*/ ();
 //BA.debugLineNum = 204;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 6;
return;
case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 207;BA.debugLine="guiHelpers.Show_toast(\"Checking Connection...\",80";
parent._guihelpers._show_toast /*String*/ (ba,"Checking Connection...",(int) (800));
 //BA.debugLineNum = 209;BA.debugLine="oConnectionCheck.Initialize(Me,\"connect\")";
parent._oconnectioncheck._initialize /*String*/ (ba,parent,"connect");
 //BA.debugLineNum = 213;BA.debugLine="oConnectionCheck.Check(txtPrinterIP.Text,txtPrint";
parent._oconnectioncheck._check /*void*/ (parent._txtprinterip._gettext /*String*/ (),parent._txtprinterport._gettext /*String*/ (),parent._txtoctokey._gettext /*String*/ ());
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public void  _btngetoctokey_click() throws Exception{
ResumableSub_btnGetOctoKey_Click rsub = new ResumableSub_btnGetOctoKey_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnGetOctoKey_Click extends BA.ResumableSub {
public ResumableSub_btnGetOctoKey_Click(sadLogic.OctoTouchController.dlgoctosetup parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgoctosetup parent;
float _w = 0f;
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
int _res = 0;
anywheresoftware.b4a.keywords.StringBuilderWrapper _msg = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 247;BA.debugLine="If txtPrinterPort.Text.Length = 0 Then txtPrinter";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._txtprinterport._gettext /*String*/ ().length()==0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._txtprinterport._settext /*String*/ ("80");
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 249;BA.debugLine="Dim w As Float";
_w = 0f;
 //BA.debugLineNum = 250;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 7:
//if
this.state = 12;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 251;BA.debugLine="w = 500dip";
_w = (float) (parent.__c.DipToCurrent((int) (500)));
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 253;BA.debugLine="w = 94%x";
_w = (float) (parent.__c.PerXToCurrent((float) (94),ba));
 if (true) break;
;
 //BA.debugLineNum = 256;BA.debugLine="If txtPrinterIP.Text.Length = 0 Then";

case 12:
//if
this.state = 15;
if (parent._txtprinterip._gettext /*String*/ ().length()==0) { 
this.state = 14;
}if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 258;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 259;BA.debugLine="mb.Initialize(mMainObj.Root,\"Problem\",w, 200dip,";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Problem",_w,(float) (parent.__c.DipToCurrent((int) (200))),parent.__c.False);
 //BA.debugLineNum = 260;BA.debugLine="Wait For (mb.Show(\"Please check if your IP and P";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Please check if your IP and Port Are Set",parent._gblconst._mb_icon_warning /*String*/ ,"","","OK"));
this.state = 20;
return;
case 20:
//C
this.state = 15;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 262;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 265;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 265;BA.debugLine="Dim msg As StringBuilder : msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 266;BA.debugLine="msg.Append(\"You are about to request a API key fr";
_msg.Append("You are about to request a API key from Octoprint. ");
 //BA.debugLineNum = 267;BA.debugLine="msg.Append(\"Press the OK button and go to your Oc";
_msg.Append("Press the OK button and go to your Octoprint web interface. ");
 //BA.debugLineNum = 268;BA.debugLine="msg.Append(\"You will need to click OK in Octoprin";
_msg.Append("You will need to click OK in Octoprint to confirm that this app can have access").Append(parent.__c.CRLF+parent.__c.CRLF);
 //BA.debugLineNum = 269;BA.debugLine="msg.Append(\"Press OK when ready\") '.Append(CRLF)";
_msg.Append("Press OK when ready");
 //BA.debugLineNum = 271;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 272;BA.debugLine="mb.Initialize(mMainObj.Root,\"Request Octo Key\", w";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Request Octo Key",_w,(float) (parent.__c.DipToCurrent((int) (220))),parent.__c.False);
 //BA.debugLineNum = 273;BA.debugLine="Wait For (mb.Show(msg.ToString,gblConst.MB_ICON_I";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_msg.ToString(),parent._gblconst._mb_icon_info /*String*/ ,"OK","","CANCEL"));
this.state = 21;
return;
case 21:
//C
this.state = 16;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 276;BA.debugLine="If res <> xui.DialogResponse_Positive Then";
if (true) break;

case 16:
//if
this.state = 19;
if (_res!=parent._xui.DialogResponse_Positive) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 277;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 19:
//C
this.state = -1;
;
 //BA.debugLineNum = 282;BA.debugLine="pnlMain.Enabled = False";
parent._pnlmain.setEnabled(parent.__c.False);
 //BA.debugLineNum = 283;BA.debugLine="B4XLoadingIndicator1.Show";
parent._b4xloadingindicator1._show /*String*/ ();
 //BA.debugLineNum = 284;BA.debugLine="EnableDisableBtns(False)";
parent._enabledisablebtns(parent.__c.False);
 //BA.debugLineNum = 285;BA.debugLine="Sleep(300)";
parent.__c.Sleep(ba,this,(int) (300));
this.state = 22;
return;
case 22:
//C
this.state = -1;
;
 //BA.debugLineNum = 288;BA.debugLine="oGetOctoKey.Initialize(Me,\"RequestAPI\",gblConst.A";
parent._ogetoctokey._initialize /*String*/ (ba,parent,"RequestAPI",parent._gblconst._app_title /*String*/ .replace("™","").trim(),parent._txtprinterip._gettext /*String*/ (),parent._txtprinterport._gettext /*String*/ ());
 //BA.debugLineNum = 290;BA.debugLine="oGetOctoKey.RequestAvailable";
parent._ogetoctokey._requestavailable /*void*/ ();
 //BA.debugLineNum = 292;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _build_gui() throws Exception{
 //BA.debugLineNum = 114;BA.debugLine="private Sub Build_GUI";
 //BA.debugLineNum = 116;BA.debugLine="pnlMain.Color = clrTheme.Background";
_pnlmain.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 117;BA.debugLine="guiHelpers.SetTextColorB4XFloatTextField( _ 			Ar";
_guihelpers._settextcolorb4xfloattextfield /*String*/ (ba,new sadLogic.OctoTouchController.b4xfloattextfield[]{_txtprinterdesc,_txtprinterip,_txtprinterport});
 //BA.debugLineNum = 120;BA.debugLine="txtPrinterDesc.HintText = \"Printer Description\"";
_txtprinterdesc._hinttext /*String*/  = "Printer Description";
 //BA.debugLineNum = 121;BA.debugLine="txtPrinterDesc.NextField = txtPrinterIP";
_txtprinterdesc._setnextfield /*sadLogic.OctoTouchController.b4xfloattextfield*/ (_txtprinterip);
 //BA.debugLineNum = 123;BA.debugLine="txtPrinterIP.HintText = \"Octoprint IP\"";
_txtprinterip._hinttext /*String*/  = "Octoprint IP";
 //BA.debugLineNum = 124;BA.debugLine="txtPrinterIP.NextField = txtPrinterPort";
_txtprinterip._setnextfield /*sadLogic.OctoTouchController.b4xfloattextfield*/ (_txtprinterport);
 //BA.debugLineNum = 126;BA.debugLine="txtPrinterPort.HintText = \"Octoprint Port\"";
_txtprinterport._hinttext /*String*/  = "Octoprint Port";
 //BA.debugLineNum = 131;BA.debugLine="btnCheckConnection.Text= \"Validate Connection\"";
_btncheckconnection.setText(BA.ObjectToCharSequence("Validate Connection"));
 //BA.debugLineNum = 132;BA.debugLine="btnGetOctoKey.Text = \"Request Octoprint Key\"";
_btngetoctokey.setText(BA.ObjectToCharSequence("Request Octoprint Key"));
 //BA.debugLineNum = 133;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnCheckCon";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btncheckconnection,_btngetoctokey});
 //BA.debugLineNum = 135;BA.debugLine="btnCheckConnection.TextSize = NumberFormat2(btnCh";
_btncheckconnection.setTextSize((float)(Double.parseDouble(__c.NumberFormat2(_btncheckconnection.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False))));
 //BA.debugLineNum = 136;BA.debugLine="btnGetOctoKey.TextSize = NumberFormat2(btnGetOcto";
_btngetoctokey.setTextSize((float)(Double.parseDouble(__c.NumberFormat2(_btngetoctokey.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False))));
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _checkinputs() throws Exception{
String _msg = "";
 //BA.debugLineNum = 354;BA.debugLine="Private Sub CheckInputs() As String";
 //BA.debugLineNum = 356;BA.debugLine="Dim msg As String";
_msg = "";
 //BA.debugLineNum = 358;BA.debugLine="Do While True";
while (__c.True) {
 //BA.debugLineNum = 361;BA.debugLine="If txtPrinterIP.Text.Length = 0  Then";
if (_txtprinterip._gettext /*String*/ ().length()==0) { 
 //BA.debugLineNum = 362;BA.debugLine="msg = \"Missing IP address\" : Exit";
_msg = "Missing IP address";
 //BA.debugLineNum = 362;BA.debugLine="msg = \"Missing IP address\" : Exit";
if (true) break;
 };
 //BA.debugLineNum = 365;BA.debugLine="If txtPrinterPort.Text.Length = 0  Then";
if (_txtprinterport._gettext /*String*/ ().length()==0) { 
 //BA.debugLineNum = 366;BA.debugLine="txtPrinterPort.Text = \"80\"";
_txtprinterport._settext /*String*/ ("80");
 };
 //BA.debugLineNum = 371;BA.debugLine="If txtOctoKey.Text.Length = 0 Then";
if (_txtoctokey._gettext /*String*/ ().length()==0) { 
 //BA.debugLineNum = 372;BA.debugLine="msg = \"Missing Octoprint Key\" : Exit";
_msg = "Missing Octoprint Key";
 //BA.debugLineNum = 372;BA.debugLine="msg = \"Missing Octoprint Key\" : Exit";
if (true) break;
 };
 //BA.debugLineNum = 376;BA.debugLine="If txtPrinterDesc.Text.Length = 0 Then";
if (_txtprinterdesc._gettext /*String*/ ().length()==0) { 
 //BA.debugLineNum = 377;BA.debugLine="msg = \"Missing Printer Description\" : Exit";
_msg = "Missing Printer Description";
 //BA.debugLineNum = 377;BA.debugLine="msg = \"Missing Printer Description\" : Exit";
if (true) break;
 };
 //BA.debugLineNum = 380;BA.debugLine="Exit";
if (true) break;
 }
;
 //BA.debugLineNum = 383;BA.debugLine="Return msg";
if (true) return _msg;
 //BA.debugLineNum = 385;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 14;BA.debugLine="Private const mModule As String = \"dlgOctoSetup\"'";
_mmodule = "dlgOctoSetup";
 //BA.debugLineNum = 15;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 16;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 17;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 18;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 20;BA.debugLine="Private B4XLoadingIndicator1 As B4XLoadingIndicat";
_b4xloadingindicator1 = new sadLogic.OctoTouchController.b4xloadingindicator();
 //BA.debugLineNum = 21;BA.debugLine="Private btnCheckConnection As Button";
_btncheckconnection = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private btnGetOctoKey As Button";
_btngetoctokey = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private txtOctoKey As B4XFloatTextField";
_txtoctokey = new sadLogic.OctoTouchController.b4xfloattextfield();
 //BA.debugLineNum = 25;BA.debugLine="Private txtPrinterDesc As B4XFloatTextField";
_txtprinterdesc = new sadLogic.OctoTouchController.b4xfloattextfield();
 //BA.debugLineNum = 26;BA.debugLine="Private txtPrinterIP As B4XFloatTextField";
_txtprinterip = new sadLogic.OctoTouchController.b4xfloattextfield();
 //BA.debugLineNum = 27;BA.debugLine="Private txtPrinterPort As B4XFloatTextField";
_txtprinterport = new sadLogic.OctoTouchController.b4xfloattextfield();
 //BA.debugLineNum = 28;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private ValidConnection As Boolean = False";
_validconnection = __c.False;
 //BA.debugLineNum = 31;BA.debugLine="Private oConnectionCheck As CheckOctoConnection";
_oconnectioncheck = new sadLogic.OctoTouchController.checkoctoconnection();
 //BA.debugLineNum = 32;BA.debugLine="Private oGetOctoKey As RequestApiKey";
_ogetoctokey = new sadLogic.OctoTouchController.requestapikey();
 //BA.debugLineNum = 34;BA.debugLine="Private Dialog As B4XDialog";
_dialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 50;BA.debugLine="Dialog.Close(xui.DialogResponse_Cancel)";
_dialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public void  _connect_complete(Object _result,Object _success) throws Exception{
ResumableSub_connect_Complete rsub = new ResumableSub_connect_Complete(this,_result,_success);
rsub.resume(ba, null);
}
public static class ResumableSub_connect_Complete extends BA.ResumableSub {
public ResumableSub_connect_Complete(sadLogic.OctoTouchController.dlgoctosetup parent,Object _result,Object _success) {
this.parent = parent;
this._result = _result;
this._success = _success;
}
sadLogic.OctoTouchController.dlgoctosetup parent;
Object _result;
Object _success;
float _w = 0f;
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
sadLogic.OctoTouchController.guimsgs _gui = null;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 222;BA.debugLine="pnlMain.Enabled = True";
parent._pnlmain.setEnabled(parent.__c.True);
 //BA.debugLineNum = 223;BA.debugLine="B4XLoadingIndicator1.Hide";
parent._b4xloadingindicator1._hide /*String*/ ();
 //BA.debugLineNum = 225;BA.debugLine="ValidConnection = success.As(Boolean)";
parent._validconnection = (BA.ObjectToBoolean(_success));
 //BA.debugLineNum = 226;BA.debugLine="EnableDisableBtns(True)";
parent._enabledisablebtns(parent.__c.True);
 //BA.debugLineNum = 227;BA.debugLine="SetSaveButtonState";
parent._setsavebuttonstate();
 //BA.debugLineNum = 229;BA.debugLine="If ValidConnection Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._validconnection) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 230;BA.debugLine="guiHelpers.Show_toast(\"Connection OK\",3000)";
parent._guihelpers._show_toast /*String*/ (ba,"Connection OK",(int) (3000));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 233;BA.debugLine="Dim w As Float = IIf(guiHelpers.gIsLandScape,500";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (500)))) : ((Object)(parent.__c.PerXToCurrent((float) (90),ba))))));
 //BA.debugLineNum = 235;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Roo";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 235;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Roo";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Problem",_w,(float) (parent.__c.DipToCurrent((int) (220))),parent.__c.False);
 //BA.debugLineNum = 236;BA.debugLine="Dim gui As guiMsgs  : gui.Initialize";
_gui = new sadLogic.OctoTouchController.guimsgs();
 //BA.debugLineNum = 236;BA.debugLine="Dim gui As guiMsgs  : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 237;BA.debugLine="Wait For (mb.Show(gui.GetConnectFailedMsg,gblCon";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_gui._getconnectfailedmsg /*String*/ (),parent._gblconst._mb_icon_warning /*String*/ ,"","","OK"));
this.state = 7;
return;
case 7:
//C
this.state = 6;
_res = (Integer) result[0];
;
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _enabledisablebtns(boolean _en) throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Private Sub EnableDisableBtns(en As Boolean)";
 //BA.debugLineNum = 178;BA.debugLine="guiHelpers.EnableDisableViews(Array As B4XView( _";
_guihelpers._enabledisableviews /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_dialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive),_dialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Cancel),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btncheckconnection.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btngetoctokey.getObject()))},_en);
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,String _title,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 40;BA.debugLine="Public Sub Initialize( title As String, EventName";
 //BA.debugLineNum = 42;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 43;BA.debugLine="mTitle = title";
_mtitle = _title;
 //BA.debugLineNum = 44;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 46;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return null;
}
public String  _invalidateconnection() throws Exception{
 //BA.debugLineNum = 404;BA.debugLine="Private Sub InvalidateConnection";
 //BA.debugLineNum = 405;BA.debugLine="ValidConnection = False";
_validconnection = __c.False;
 //BA.debugLineNum = 406;BA.debugLine="SetSaveButtonState";
_setsavebuttonstate();
 //BA.debugLineNum = 407;BA.debugLine="End Sub";
return "";
}
public String  _readsettingsfile() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 411;BA.debugLine="private Sub ReadSettingsFile";
 //BA.debugLineNum = 414;BA.debugLine="Dim m As Map = File.ReadMap(xui.DefaultFolder,gbl";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._printer_setup_file /*String*/ );
 //BA.debugLineNum = 415;BA.debugLine="If m.IsInitialized = False Then Return";
if (_m.IsInitialized()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 418;BA.debugLine="txtOctoKey.Text = m.Get( gblConst.PRINTER_OCTO_KE";
_txtoctokey._settext /*String*/ (BA.ObjectToString(_m.Get((Object)(_gblconst._printer_octo_key /*String*/ ))));
 //BA.debugLineNum = 419;BA.debugLine="txtPrinterDesc.Text = m.Get( gblConst.PRINTER_DES";
_txtprinterdesc._settext /*String*/ (BA.ObjectToString(_m.Get((Object)(_gblconst._printer_desc /*String*/ ))));
 //BA.debugLineNum = 420;BA.debugLine="txtPrinterIP.Text = m.Get( gblConst.PRINTER_IP)";
_txtprinterip._settext /*String*/ (BA.ObjectToString(_m.Get((Object)(_gblconst._printer_ip /*String*/ ))));
 //BA.debugLineNum = 421;BA.debugLine="txtPrinterPort.Text = m.Get( gblConst.PRINTER_POR";
_txtprinterport._settext /*String*/ (BA.ObjectToString(_m.Get((Object)(_gblconst._printer_port /*String*/ ))));
 //BA.debugLineNum = 423;BA.debugLine="End Sub";
return "";
}
public void  _requestapi_requestcomplete(Object _result,Object _success) throws Exception{
ResumableSub_RequestAPI_RequestComplete rsub = new ResumableSub_RequestAPI_RequestComplete(this,_result,_success);
rsub.resume(ba, null);
}
public static class ResumableSub_RequestAPI_RequestComplete extends BA.ResumableSub {
public ResumableSub_RequestAPI_RequestComplete(sadLogic.OctoTouchController.dlgoctosetup parent,Object _result,Object _success) {
this.parent = parent;
this._result = _result;
this._success = _success;
}
sadLogic.OctoTouchController.dlgoctosetup parent;
Object _result;
Object _success;
sadLogic.OctoTouchController.octowebsocket _ws = null;
boolean _b = false;
String _msg = "";
float _w = 0f;
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 299;BA.debugLine="pnlMain.Enabled = True";
parent._pnlmain.setEnabled(parent.__c.True);
 //BA.debugLineNum = 300;BA.debugLine="B4XLoadingIndicator1.Hide";
parent._b4xloadingindicator1._hide /*String*/ ();
 //BA.debugLineNum = 302;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 18;
this.catchState = 17;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 17;
 //BA.debugLineNum = 303;BA.debugLine="If Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (BA.ObjectToBoolean(_success)) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 305;BA.debugLine="txtOctoKey.Text = result.As(String)";
parent._txtoctokey._settext /*String*/ ((BA.ObjectToString(_result)));
 //BA.debugLineNum = 306;BA.debugLine="ValidConnection = True";
parent._validconnection = parent.__c.True;
 //BA.debugLineNum = 307;BA.debugLine="guiHelpers.Show_toast(\"Requested API key OK!\",1";
parent._guihelpers._show_toast /*String*/ (ba,"Requested API key OK!",(int) (1800));
 //BA.debugLineNum = 309;BA.debugLine="oc.OctoIp = txtPrinterIP.Text";
parent._oc._octoip /*String*/  = parent._txtprinterip._gettext /*String*/ ();
 //BA.debugLineNum = 310;BA.debugLine="oc.OctoKey = txtOctoKey.Text";
parent._oc._octokey /*String*/  = parent._txtoctokey._gettext /*String*/ ();
 //BA.debugLineNum = 311;BA.debugLine="oc.OctoPort = txtPrinterPort.text";
parent._oc._octoport /*String*/  = parent._txtprinterport._gettext /*String*/ ();
 //BA.debugLineNum = 315;BA.debugLine="Dim ws As OctoWebSocket : ws.Initialize";
_ws = new sadLogic.OctoTouchController.octowebsocket();
 //BA.debugLineNum = 315;BA.debugLine="Dim ws As OctoWebSocket : ws.Initialize";
_ws._initialize /*sadLogic.OctoTouchController.octowebsocket*/ (ba);
 //BA.debugLineNum = 318;BA.debugLine="Wait For (ws.ProviderInstall) Complete (b As Bo";
parent.__c.WaitFor("complete", ba, this, _ws._providerinstall /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 19;
return;
case 19:
//C
this.state = 7;
_b = (Boolean) result[0];
;
 //BA.debugLineNum = 320;BA.debugLine="Wait For (ws.Connect_Socket) Complete (msg As S";
parent.__c.WaitFor("complete", ba, this, _ws._connect_socket /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 20;
return;
case 20:
//C
this.state = 7;
_msg = (String) result[0];
;
 //BA.debugLineNum = 321;BA.debugLine="If msg = \"\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_msg).equals("")) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 325;BA.debugLine="Log(\"------------- Socket FAILED ------\")";
parent.__c.LogImpl("24707101","------------- Socket FAILED ------",0);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 329;BA.debugLine="Log(\"------------- Socket OK ------\")";
parent.__c.LogImpl("24707105","------------- Socket OK ------",0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 //BA.debugLineNum = 331;BA.debugLine="ws.wSocket.Close";
_ws._wsocket /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .Close();
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 334;BA.debugLine="Dim w As Float = IIf(guiHelpers.gIsLandScape,50";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (500)))) : ((Object)(parent.__c.PerXToCurrent((float) (94),ba))))));
 //BA.debugLineNum = 335;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Ro";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 335;BA.debugLine="Dim mb As dlgMsgBox : mb.Initialize(mMainObj.Ro";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Problem",_w,(float) (parent.__c.DipToCurrent((int) (220))),parent.__c.False);
 //BA.debugLineNum = 336;BA.debugLine="Wait For (mb.Show(result.As(String),gblConst.MB";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((BA.ObjectToString(_result)),parent._gblconst._mb_icon_warning /*String*/ ,"","","OK"));
this.state = 21;
return;
case 21:
//C
this.state = 15;
_res = (Integer) result[0];
;
 if (true) break;

case 15:
//C
this.state = 18;
;
 if (true) break;

case 17:
//C
this.state = 18;
this.catchState = 0;
 //BA.debugLineNum = 341;BA.debugLine="logMe.LogIt2(LastException,mModule,\"RequestAPI_R";
parent._logme._logit2 /*String*/ (ba,BA.ObjectToString(parent.__c.LastException(ba)),parent._mmodule,"RequestAPI_RequestComplete");
 if (true) break;
if (true) break;

case 18:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 345;BA.debugLine="EnableDisableBtns(True)";
parent._enabledisablebtns(parent.__c.True);
 //BA.debugLineNum = 346;BA.debugLine="SetSaveButtonState";
parent._setsavebuttonstate();
 //BA.debugLineNum = 348;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _save_settings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _outmap = null;
 //BA.debugLineNum = 141;BA.debugLine="private Sub Save_settings";
 //BA.debugLineNum = 145;BA.debugLine="Dim outMap As Map = CreateMap( _ 						gblConst.P";
_outmap = new anywheresoftware.b4a.objects.collections.Map();
_outmap = __c.createMap(new Object[] {(Object)(_gblconst._printer_desc /*String*/ ),(Object)(_txtprinterdesc._gettext /*String*/ ()),(Object)(_gblconst._printer_ip /*String*/ ),(Object)(_txtprinterip._gettext /*String*/ ()),(Object)(_gblconst._printer_port /*String*/ ),(Object)(_txtprinterport._gettext /*String*/ ()),(Object)(_gblconst._printer_octo_key /*String*/ ),(Object)(_txtoctokey._gettext /*String*/ ())});
 //BA.debugLineNum = 150;BA.debugLine="guiHelpers.Show_toast(gblConst.DATA_SAVED,2500)";
_guihelpers._show_toast /*String*/ (ba,_gblconst._data_saved /*String*/ ,(int) (2500));
 //BA.debugLineNum = 151;BA.debugLine="fileHelpers.SafeKill(gblConst.PRINTER_SETUP_FILE)";
_filehelpers._safekill /*String*/ (ba,_gblconst._printer_setup_file /*String*/ );
 //BA.debugLineNum = 152;BA.debugLine="File.WriteMap(xui.DefaultFolder,gblConst.PRINTER_";
__c.File.WriteMap(_xui.getDefaultFolder(),_gblconst._printer_setup_file /*String*/ ,_outmap);
 //BA.debugLineNum = 153;BA.debugLine="oc.IsConnectionValid = True";
_oc._isconnectionvalid /*boolean*/  = __c.True;
 //BA.debugLineNum = 156;BA.debugLine="If mMainObj.oPageFiles.IsInitialized Then";
if (_mmainobj._opagefiles /*sadLogic.OctoTouchController.pagefiles*/ .IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 157;BA.debugLine="mMainObj.oPageFiles.FileEvent = True";
_mmainobj._opagefiles /*sadLogic.OctoTouchController.pagefiles*/ ._fileevent /*boolean*/  = __c.True;
 };
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public String  _setsavebuttonstate() throws Exception{
 //BA.debugLineNum = 166;BA.debugLine="Private Sub SetSaveButtonState";
 //BA.debugLineNum = 167;BA.debugLine="Try";
try { //BA.debugLineNum = 168;BA.debugLine="guiHelpers.EnableDisableViews( _ 			Array As B4X";
_guihelpers._enabledisableviews /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_dialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_xui.DialogResponse_Positive)},_validconnection);
 } 
       catch (Exception e4) {
			ba.setLastException(e4); };
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public void  _show(boolean _firstrun) throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this,_firstrun);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgoctosetup parent,boolean _firstrun) {
this.parent = parent;
this._firstrun = _firstrun;
}
sadLogic.OctoTouchController.dlgoctosetup parent;
boolean _firstrun;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _w = 0f;
float _h = 0f;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 57;BA.debugLine="mMainObj.pPrinterCfgDlgShowingFLAG = True";
parent._mmainobj._pprintercfgdlgshowingflag /*boolean*/  = parent.__c.True;
 //BA.debugLineNum = 60;BA.debugLine="Dialog.Initialize(mMainObj.Root)";
parent._dialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 61;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 62;BA.debugLine="dlgHelper.Initialize(Dialog)";
_dlghelper._initialize /*String*/ (ba,parent._dialog);
 //BA.debugLineNum = 64;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 65;BA.debugLine="Dim w, h As Float";
_w = 0f;
_h = 0f;
 //BA.debugLineNum = 67;BA.debugLine="If guiHelpers.gScreenSizeAprox < 8 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gscreensizeaprox /*double*/ <8) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 68;BA.debugLine="w = 92%x";
_w = (float) (parent.__c.PerXToCurrent((float) (92),ba));
 //BA.debugLineNum = 69;BA.debugLine="h = IIf(guiHelpers.gIsLandScape,74%y,62%y)";
_h = (float)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.PerYToCurrent((float) (74),ba))) : ((Object)(parent.__c.PerYToCurrent((float) (62),ba))))));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 71;BA.debugLine="w = 74%x : h = 70%y";
_w = (float) (parent.__c.PerXToCurrent((float) (74),ba));
 //BA.debugLineNum = 71;BA.debugLine="w = 74%x : h = 70%y";
_h = (float) (parent.__c.PerYToCurrent((float) (70),ba));
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 74;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, w, h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_w),(int) (_h));
 //BA.debugLineNum = 75;BA.debugLine="p.LoadLayout(\"viewOctoSetup\")";
_p.LoadLayout("viewOctoSetup",ba);
 //BA.debugLineNum = 77;BA.debugLine="Build_GUI";
parent._build_gui();
 //BA.debugLineNum = 79;BA.debugLine="dlgHelper.ThemeDialogForm(mTitle)";
_dlghelper._themedialogform /*String*/ ((Object)(parent._mtitle));
 //BA.debugLineNum = 80;BA.debugLine="Dim rs As ResumableSub = Dialog.ShowCustom(p, \"SA";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._dialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)("SAVE"),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 81;BA.debugLine="Dialog.Base.Parent.Tag = \"\" 'this will prevent th";
parent._dialog._base /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getParent().setTag((Object)(""));
 //BA.debugLineNum = 82;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 84;BA.debugLine="If firstRun = False Then";
if (true) break;

case 7:
//if
this.state = 12;
if (_firstrun==parent.__c.False) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 85;BA.debugLine="ReadSettingsFile";
parent._readsettingsfile();
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 87;BA.debugLine="txtPrinterDesc.Text = \"Default\"";
parent._txtprinterdesc._settext /*String*/ ("Default");
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 89;BA.debugLine="InvalidateConnection";
parent._invalidateconnection();
 //BA.debugLineNum = 90;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_on /*int*/ ));
 //BA.debugLineNum = 93;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Show_";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus /*String*/ (parent,"Show_KB",(int) (100));
 //BA.debugLineNum = 95;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 17;
return;
case 17:
//C
this.state = 13;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 97;BA.debugLine="mMainObj.pPrinterCfgDlgShowingFLAG = False";
parent._mmainobj._pprintercfgdlgshowingflag /*boolean*/  = parent.__c.False;
 //BA.debugLineNum = 99;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 13:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 15;
}if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 100;BA.debugLine="Save_settings";
parent._save_settings();
 //BA.debugLineNum = 101;BA.debugLine="CallSub(mMainObj,mEventName)";
parent.__c.CallSubNew(ba,(Object)(parent._mmainobj),parent._meventname);
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 104;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _show_kb() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Private Sub Show_KB";
 //BA.debugLineNum = 110;BA.debugLine="txtPrinterDesc.RequestFocusAndShowKeyboard";
_txtprinterdesc._requestfocusandshowkeyboard /*String*/ ();
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _txtoctokey_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 400;BA.debugLine="Private Sub txtOctoKey_TextChanged (Old As String,";
 //BA.debugLineNum = 401;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 402;BA.debugLine="End Sub";
return "";
}
public String  _txtprinterdesc_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 388;BA.debugLine="Private Sub txtPrinterDesc_TextChanged (Old As Str";
 //BA.debugLineNum = 389;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 390;BA.debugLine="End Sub";
return "";
}
public String  _txtprinterip_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 392;BA.debugLine="Private Sub txtPrinterIP_TextChanged (Old As Strin";
 //BA.debugLineNum = 393;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 394;BA.debugLine="End Sub";
return "";
}
public String  _txtprinterport_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 396;BA.debugLine="Private Sub txtPrinterPort_TextChanged (Old As Str";
 //BA.debugLineNum = 397;BA.debugLine="InvalidateConnection";
_invalidateconnection();
 //BA.debugLineNum = 398;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
if (BA.fastSubCompare(sub, "SHOW_KB"))
	return _show_kb();
return BA.SubDelegator.SubNotFound;
}
}
