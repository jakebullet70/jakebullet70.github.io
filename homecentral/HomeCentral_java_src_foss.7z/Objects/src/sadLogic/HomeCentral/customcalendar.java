package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class customcalendar extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.customcalendar");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.customcalendar.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _callback = null;
public String _eventname = "";
public int[] _hilightdates = null;
public anywheresoftware.b4a.objects.B4XViewWrapper[] _btdays = null;
public anywheresoftware.b4a.objects.B4XViewWrapper[] _lbldaytitle = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltitle = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbackground = null;
public String[] _nmmonth = null;
public String[] _nmfullday = null;
public String[] _nmfullmonth = null;
public int _calmonth = 0;
public int _calyear = 0;
public int _calday = 0;
public int _relativtextsize = 0;
public long _sometime = 0L;
public int _ocalnum = 0;
public anywheresoftware.b4a.objects.collections.List _ocallst = null;
public anywheresoftware.b4a.objects.collections.Map _ocaldaysmap = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public anywheresoftware.b4a.objects.B4XViewWrapper  _asview() throws Exception{
 //BA.debugLineNum = 345;BA.debugLine="Public Sub AsView As B4XView";
 //BA.debugLineNum = 346;BA.debugLine="Return pnl";
if (true) return _pnl;
 //BA.debugLineNum = 347;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Public callback As Object";
_callback = new Object();
 //BA.debugLineNum = 14;BA.debugLine="Public eventName As String";
_eventname = "";
 //BA.debugLineNum = 15;BA.debugLine="Public hilightDates() As Int";
_hilightdates = new int[(int) (0)];
;
 //BA.debugLineNum = 17;BA.debugLine="Private btDays(42) As B4XView 'Button      'Days";
_btdays = new anywheresoftware.b4a.objects.B4XViewWrapper[(int) (42)];
{
int d0 = _btdays.length;
for (int i0 = 0;i0 < d0;i0++) {
_btdays[i0] = new anywheresoftware.b4a.objects.B4XViewWrapper();
}
}
;
 //BA.debugLineNum = 19;BA.debugLine="Private lblDayTitle(8) As B4XView     'Day of Wee";
_lbldaytitle = new anywheresoftware.b4a.objects.B4XViewWrapper[(int) (8)];
{
int d0 = _lbldaytitle.length;
for (int i0 = 0;i0 < d0;i0++) {
_lbldaytitle[i0] = new anywheresoftware.b4a.objects.B4XViewWrapper();
}
}
;
 //BA.debugLineNum = 20;BA.debugLine="Private lblTitle As B4XView         'Date";
_lbltitle = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private pnl,pnlbackGround As B4XView";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbackground = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Public NmMonth(12) As String : NmMonth = Array As";
_nmmonth = new String[(int) (12)];
java.util.Arrays.fill(_nmmonth,"");
 //BA.debugLineNum = 26;BA.debugLine="Public NmMonth(12) As String : NmMonth = Array As";
_nmmonth = new String[]{"Jan","Feb","Mar","April","May","June","July","Aug","Sept","Oct","Nov","Dec"};
 //BA.debugLineNum = 28;BA.debugLine="Public NmFullday() As String";
_nmfullday = new String[(int) (0)];
java.util.Arrays.fill(_nmfullday,"");
 //BA.debugLineNum = 29;BA.debugLine="Public NmFullMonth() As String";
_nmfullmonth = new String[(int) (0)];
java.util.Arrays.fill(_nmfullmonth,"");
 //BA.debugLineNum = 32;BA.debugLine="Private CalMonth, CalYear As Int";
_calmonth = 0;
_calyear = 0;
 //BA.debugLineNum = 33;BA.debugLine="Public CalDay As Int";
_calday = 0;
 //BA.debugLineNum = 35;BA.debugLine="Private RelativTextSize As Int";
_relativtextsize = 0;
 //BA.debugLineNum = 36;BA.debugLine="Private SomeTime As Long";
_sometime = 0L;
 //BA.debugLineNum = 38;BA.debugLine="Public oCalNum As Int";
_ocalnum = 0;
 //BA.debugLineNum = 39;BA.debugLine="Public oCalLST As List";
_ocallst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 40;BA.debugLine="Public oCalDaysMAP As Map";
_ocaldaysmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public String  _dayname(int _n) throws Exception{
String _s = "";
 //BA.debugLineNum = 233;BA.debugLine="Public Sub dayName(n As Int) As String";
 //BA.debugLineNum = 234;BA.debugLine="Dim S As String";
_s = "";
 //BA.debugLineNum = 235;BA.debugLine="S = NmFullday(n)";
_s = _nmfullday[_n];
 //BA.debugLineNum = 236;BA.debugLine="Return S.SubString2(0,3)";
if (true) return _s.substring((int) (0),(int) (3));
 //BA.debugLineNum = 237;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,int _ww,int _hh,long _begindate,int _txtsize) throws Exception{
innerInitialize(_ba);
int _mx = 0;
int _my = 0;
int _tx = 0;
int _ty = 0;
int _i = 0;
int _j = 0;
int _z = 0;
int _v1 = 0;
 //BA.debugLineNum = 56;BA.debugLine="Public Sub Initialize( Ww As Int,Hh As Int, BeginD";
 //BA.debugLineNum = 58;BA.debugLine="NmFullday =  objHelpers.List2StrArray( DateUtils.";
_nmfullday = _objhelpers._list2strarray /*String[]*/ (ba,_dateutils._getdaysnames(ba));
 //BA.debugLineNum = 59;BA.debugLine="NmFullMonth = objHelpers.List2StrArray(DateUtils.";
_nmfullmonth = _objhelpers._list2strarray /*String[]*/ (ba,_dateutils._getmonthsnames(ba));
 //BA.debugLineNum = 61;BA.debugLine="oCalLST.Initialize";
_ocallst.Initialize();
 //BA.debugLineNum = 62;BA.debugLine="oCalDaysMAP.Initialize";
_ocaldaysmap.Initialize();
 //BA.debugLineNum = 64;BA.debugLine="pnl = XUI.CreatePanel(\"pnl\")";
_pnl = _xui.CreatePanel(ba,"pnl");
 //BA.debugLineNum = 66;BA.debugLine="pnl.Color = XUI.Color_Transparent";
_pnl.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 67;BA.debugLine="Dim mx,my,tx,ty As Int";
_mx = 0;
_my = 0;
_tx = 0;
_ty = 0;
 //BA.debugLineNum = 68;BA.debugLine="Dim i,j,z As Int";
_i = 0;
_j = 0;
_z = 0;
 //BA.debugLineNum = 69;BA.debugLine="RelativTextSize = txtSize";
_relativtextsize = _txtsize;
 //BA.debugLineNum = 71;BA.debugLine="mx=(Ww/7)'-8";
_mx = (int) ((_ww/(double)7));
 //BA.debugLineNum = 74;BA.debugLine="my=(Hh/8)'-9";
_my = (int) ((_hh/(double)8));
 //BA.debugLineNum = 76;BA.debugLine="If my > mx Then my = mx";
if (_my>_mx) { 
_my = _mx;};
 //BA.debugLineNum = 77;BA.debugLine="If ((my * 9) + 10dip) > Hh Then my = ((Hh - 10dip";
if (((_my*9)+__c.DipToCurrent((int) (10)))>_hh) { 
_my = (int) (((_hh-__c.DipToCurrent((int) (10)))/(double)9));};
 //BA.debugLineNum = 79;BA.debugLine="tx = (Ww - ((mx * 7) + 8dip)) / 2";
_tx = (int) ((_ww-((_mx*7)+__c.DipToCurrent((int) (8))))/(double)2);
 //BA.debugLineNum = 80;BA.debugLine="ty = (Hh - ((my * 9) + 8dip)) / 2";
_ty = (int) ((_hh-((_my*9)+__c.DipToCurrent((int) (8))))/(double)2);
 //BA.debugLineNum = 82;BA.debugLine="pnlbackGround = XUI.CreatePanel(\"\")";
_pnlbackground = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 83;BA.debugLine="pnlbackGround.Color = XUI.Color_Transparent";
_pnlbackground.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 84;BA.debugLine="pnl.addview(pnlbackGround,tx,ty,(mx *  7) + 8dip,";
_pnl.AddView((android.view.View)(_pnlbackground.getObject()),_tx,_ty,(int) ((_mx*7)+__c.DipToCurrent((int) (8))),(int) ((_my*9)+__c.DipToCurrent((int) (8))));
 //BA.debugLineNum = 85;BA.debugLine="pnl.Visible = False";
_pnl.setVisible(__c.False);
 //BA.debugLineNum = 87;BA.debugLine="lblTitle = XUIViewsUtils.CreateLabel";
_lbltitle = _xuiviewsutils._createlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (ba);
 //BA.debugLineNum = 89;BA.debugLine="pnlbackGround.addView(lblTitle,1dip,1dip,pnlbackG";
_pnlbackground.AddView((android.view.View)(_lbltitle.getObject()),__c.DipToCurrent((int) (1)),__c.DipToCurrent((int) (1)),(int) (_pnlbackground.getWidth()-__c.DipToCurrent((int) (2))),(int) (_my-__c.DipToCurrent((int) (6))));
 //BA.debugLineNum = 90;BA.debugLine="lblTitle.Font = XUI.CreateDefaultBoldFont(lblTitl";
_lbltitle.setFont(_xui.CreateDefaultBoldFont(_lbltitle.getFont().getSize()));
 //BA.debugLineNum = 93;BA.debugLine="lblTitle.Color = XUI.Color_Transparent";
_lbltitle.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 94;BA.debugLine="lblTitle.TextColor =  clrTheme.txtNormal'  g.GetC";
_lbltitle.setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 95;BA.debugLine="lblTitle.SetTextAlignment(\"CENTER\",\"CENTER\")";
_lbltitle.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 100;BA.debugLine="For i = 0 To 6 'Days name buttons";
{
final int step26 = 1;
final int limit26 = (int) (6);
_i = (int) (0) ;
for (;_i <= limit26 ;_i = _i + step26 ) {
 //BA.debugLineNum = 102;BA.debugLine="lblDayTitle(i) = XUIViewsUtils.CreateLabel";
_lbldaytitle[_i] = _xuiviewsutils._createlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (ba);
 //BA.debugLineNum = 103;BA.debugLine="lblDayTitle(i).SetTextAlignment(\"CENTER\",\"CENTER";
_lbldaytitle[_i].SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 104;BA.debugLine="lblDayTitle(i).TextSize = (RelativTextSize)";
_lbldaytitle[_i].setTextSize((float) ((_relativtextsize)));
 //BA.debugLineNum = 105;BA.debugLine="lblDayTitle(i).TextColor = clrTheme.txtNormal";
_lbldaytitle[_i].setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 106;BA.debugLine="pnlbackGround.AddView( lblDayTitle(i), (i * mx)";
_pnlbackground.AddView((android.view.View)(_lbldaytitle[_i].getObject()),(int) ((_i*_mx)+((_i+1)*__c.DipToCurrent((int) (1)))),(int) ((1*_my)+__c.DipToCurrent((int) (1))),(int) (_mx+__c.DipToCurrent((int) (2))),_my);
 //BA.debugLineNum = 107;BA.debugLine="guiHelpers.ResizeText(dayName(i),lblDayTitle(i))";
_guihelpers._resizetext /*String*/ (ba,_dayname(_i),(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lbldaytitle[_i].getObject())));
 }
};
 //BA.debugLineNum = 110;BA.debugLine="For j = 0 To 5 'Days buttons";
{
final int step34 = 1;
final int limit34 = (int) (5);
_j = (int) (0) ;
for (;_j <= limit34 ;_j = _j + step34 ) {
 //BA.debugLineNum = 111;BA.debugLine="For i = 0 To 6";
{
final int step35 = 1;
final int limit35 = (int) (6);
_i = (int) (0) ;
for (;_i <= limit35 ;_i = _i + step35 ) {
 //BA.debugLineNum = 112;BA.debugLine="z = (j*7)+i";
_z = (int) ((_j*7)+_i);
 //BA.debugLineNum = 113;BA.debugLine="btDays(z) = XUIViewsUtils.CreateLabel";
_btdays[_z] = _xuiviewsutils._createlabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (ba);
 //BA.debugLineNum = 114;BA.debugLine="btDays(z).SetTextAlignment(\"CENTER\",\"CENTER\")";
_btdays[_z].SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 115;BA.debugLine="btDays(z).Color = XUI.Color_Transparent";
_btdays[_z].setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 116;BA.debugLine="btDays(z).tag = 0";
_btdays[_z].setTag((Object)(0));
 //BA.debugLineNum = 119;BA.debugLine="Dim v1 As Int = my / 30 '6           '   left";
_v1 = (int) (_my/(double)30);
 //BA.debugLineNum = 120;BA.debugLine="pnlbackGround.AddView(btDays(z),(i * mx) + (( i";
_pnlbackground.AddView((android.view.View)(_btdays[_z].getObject()),(int) ((_i*_mx)+((_i+1)*__c.DipToCurrent((int) (1)))),(int) (((_j+2)*(_my+_v1+__c.DipToCurrent((int) (1))))),_mx,(int) ((_my+_v1)));
 }
};
 }
};
 //BA.debugLineNum = 124;BA.debugLine="PrintDate(BeginDate)";
_printdate(_begindate);
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public String  _lbldaytitle_click() throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Private Sub lblDayTitle_Click";
 //BA.debugLineNum = 46;BA.debugLine="lblTitle_Click";
_lbltitle_click();
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _lbltitle_click() throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Private Sub lblTitle_Click";
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public int  _lengthmonth(int _yearnum,int _monthnum) throws Exception{
 //BA.debugLineNum = 340;BA.debugLine="Public Sub LengthMonth(yearNum As Int,monthNum As";
 //BA.debugLineNum = 341;BA.debugLine="Return DateUtils.NumberOfDaysInMonth(monthNum,yea";
if (true) return _dateutils._numberofdaysinmonth(ba,_monthnum,_yearnum);
 //BA.debugLineNum = 343;BA.debugLine="End Sub";
return 0;
}
public String  _printdate(long _dts) throws Exception{
int _nbj = 0;
int _nday = 0;
int _mn1 = 0;
int _mn2 = 0;
int _cdd = 0;
int _cmm = 0;
int _caa = 0;
String _s = "";
int _i = 0;
int _nb = 0;
int _z = 0;
int _m2 = 0;
int _m3 = 0;
 //BA.debugLineNum = 239;BA.debugLine="Private Sub PrintDate(dts As Long)";
 //BA.debugLineNum = 240;BA.debugLine="Dim nbj,nday As Int";
_nbj = 0;
_nday = 0;
 //BA.debugLineNum = 241;BA.debugLine="Dim mn1,mn2 As Int";
_mn1 = 0;
_mn2 = 0;
 //BA.debugLineNum = 242;BA.debugLine="Dim cdd, cmm, caa As Int";
_cdd = 0;
_cmm = 0;
_caa = 0;
 //BA.debugLineNum = 244;BA.debugLine="cdd = DateTime.GetDayOfMonth(DateTime.Now)";
_cdd = __c.DateTime.GetDayOfMonth(__c.DateTime.getNow());
 //BA.debugLineNum = 245;BA.debugLine="cmm = DateTime.GetMonth(DateTime.Now)";
_cmm = __c.DateTime.GetMonth(__c.DateTime.getNow());
 //BA.debugLineNum = 246;BA.debugLine="caa = DateTime.GetYear(DateTime.Now)";
_caa = __c.DateTime.GetYear(__c.DateTime.getNow());
 //BA.debugLineNum = 248;BA.debugLine="CalDay   = DateTime.GetDayOfMonth(dts)";
_calday = __c.DateTime.GetDayOfMonth(_dts);
 //BA.debugLineNum = 249;BA.debugLine="CalYear  = DateTime.GetYear(dts)";
_calyear = __c.DateTime.GetYear(_dts);
 //BA.debugLineNum = 250;BA.debugLine="CalMonth = DateTime.GetMonth(dts)";
_calmonth = __c.DateTime.GetMonth(_dts);
 //BA.debugLineNum = 256;BA.debugLine="Dim s As String = NmFullMonth(CalMonth-1)  & \"  \"";
_s = _nmfullmonth[(int) (_calmonth-1)]+"  "+_dthelpers._returndayext /*String*/ (ba,_calday)+"  "+BA.NumberToString(_calyear);
 //BA.debugLineNum = 260;BA.debugLine="guiHelpers.ResizeText(s,lblTitle)";
_guihelpers._resizetext /*String*/ (ba,_s,(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lbltitle.getObject())));
 //BA.debugLineNum = 271;BA.debugLine="mn1 = CalMonth - 1 'prev month";
_mn1 = (int) (_calmonth-1);
 //BA.debugLineNum = 272;BA.debugLine="If mn1 < 1 Then mn1 = 12";
if (_mn1<1) { 
_mn1 = (int) (12);};
 //BA.debugLineNum = 276;BA.debugLine="mn2 = CalMonth + 1 'next month";
_mn2 = (int) (_calmonth+1);
 //BA.debugLineNum = 277;BA.debugLine="If mn2 > 12 Then mn2 = 1";
if (_mn2>12) { 
_mn2 = (int) (1);};
 //BA.debugLineNum = 281;BA.debugLine="nbj = LengthMonth(CalYear,CalMonth)";
_nbj = _lengthmonth(_calyear,_calmonth);
 //BA.debugLineNum = 282;BA.debugLine="SomeTime = DateTime.DateParse(CalMonth & \"/01/\" &";
_sometime = __c.DateTime.DateParse(BA.NumberToString(_calmonth)+"/01/"+BA.NumberToString(_calyear));
 //BA.debugLineNum = 284;BA.debugLine="nday = (DateTime.GetDayOfWeek(SomeTime)-1)";
_nday = (int) ((__c.DateTime.GetDayOfWeek(_sometime)-1));
 //BA.debugLineNum = 286;BA.debugLine="Dim i,nb As Int";
_i = 0;
_nb = 0;
 //BA.debugLineNum = 287;BA.debugLine="nb = nday";
_nb = _nday;
 //BA.debugLineNum = 289;BA.debugLine="If nb = 0 Then nb = 7 'decal next line dim 1";
if (_nb==0) { 
_nb = (int) (7);};
 //BA.debugLineNum = 291;BA.debugLine="For i = 0 To 41";
{
final int step22 = 1;
final int limit22 = (int) (41);
_i = (int) (0) ;
for (;_i <= limit22 ;_i = _i + step22 ) {
 //BA.debugLineNum = 292;BA.debugLine="btDays(i).TextColor = clrTheme.txtNormal";
_btdays[_i].setTextColor(_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 294;BA.debugLine="btDays(i).Text = \"\"";
_btdays[_i].setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 295;BA.debugLine="btDays(i).Tag = 0";
_btdays[_i].setTag((Object)(0));
 //BA.debugLineNum = 296;BA.debugLine="btDays(i).TextSize = lblDayTitle(1).TextSize 'Re";
_btdays[_i].setTextSize(_lbldaytitle[(int) (1)].getTextSize());
 }
};
 //BA.debugLineNum = 299;BA.debugLine="Dim z As Int";
_z = 0;
 //BA.debugLineNum = 300;BA.debugLine="For i = (nb) To (nb - 1 + nbj)";
{
final int step29 = 1;
final int limit29 = (int) ((_nb-1+_nbj));
_i = (_nb) ;
for (;_i <= limit29 ;_i = _i + step29 ) {
 //BA.debugLineNum = 301;BA.debugLine="z = i-nb+1";
_z = (int) (_i-_nb+1);
 //BA.debugLineNum = 303;BA.debugLine="btDays(i).Text=z";
_btdays[_i].setText(BA.ObjectToCharSequence(_z));
 //BA.debugLineNum = 304;BA.debugLine="btDays(i).Tag=z";
_btdays[_i].setTag((Object)(_z));
 //BA.debugLineNum = 308;BA.debugLine="If (cmm = CalMonth) And (caa = CalYear) Then";
if ((_cmm==_calmonth) && (_caa==_calyear)) { 
 //BA.debugLineNum = 309;BA.debugLine="If (z = cdd) Then";
if ((_z==_cdd)) { 
 //BA.debugLineNum = 311;BA.debugLine="btDays(i).TextColor = clrTheme.txtAccent";
_btdays[_i].setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 312;BA.debugLine="btDays(i).Color = clrTheme.Background2";
_btdays[_i].setColor(_clrtheme._background2 /*int*/ );
 };
 };
 }
};
 //BA.debugLineNum = 319;BA.debugLine="Dim m2,m3 As Int";
_m2 = 0;
_m3 = 0;
 //BA.debugLineNum = 321;BA.debugLine="m2 = LengthMonth(CalYear,mn1)";
_m2 = _lengthmonth(_calyear,_mn1);
 //BA.debugLineNum = 322;BA.debugLine="m3 = m2 - (nb - 1)";
_m3 = (int) (_m2-(_nb-1));
 //BA.debugLineNum = 323;BA.debugLine="For i=0 To (nb - 1) 'Prev month";
{
final int step43 = 1;
final int limit43 = (int) ((_nb-1));
_i = (int) (0) ;
for (;_i <= limit43 ;_i = _i + step43 ) {
 //BA.debugLineNum = 324;BA.debugLine="btDays(i).TextColor= clrTheme.btnDisableText";
_btdays[_i].setTextColor(_clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 326;BA.debugLine="btDays(i).Text=m3+i";
_btdays[_i].setText(BA.ObjectToCharSequence(_m3+_i));
 //BA.debugLineNum = 327;BA.debugLine="btDays(i).Tag=100+m3+i";
_btdays[_i].setTag((Object)(100+_m3+_i));
 }
};
 //BA.debugLineNum = 330;BA.debugLine="For i = (nb + nbj) To 41 'Next month";
{
final int step48 = 1;
final int limit48 = (int) (41);
_i = (int) ((_nb+_nbj)) ;
for (;_i <= limit48 ;_i = _i + step48 ) {
 //BA.debugLineNum = 331;BA.debugLine="btDays(i).TextColor=clrTheme.btnDisableText";
_btdays[_i].setTextColor(_clrtheme._btndisabletext /*int*/ );
 //BA.debugLineNum = 333;BA.debugLine="btDays(i).Text=i-(nb+nbj)+1";
_btdays[_i].setText(BA.ObjectToCharSequence(_i-(_nb+_nbj)+1));
 //BA.debugLineNum = 334;BA.debugLine="btDays(i).Tag=200+(i-(nb+nbj)+1)";
_btdays[_i].setTag((Object)(200+(_i-(_nb+_nbj)+1)));
 }
};
 //BA.debugLineNum = 337;BA.debugLine="End Sub";
return "";
}
public String  _settextsize(int _value) throws Exception{
 //BA.debugLineNum = 350;BA.debugLine="Public Sub SetTextSize(value As Int)";
 //BA.debugLineNum = 351;BA.debugLine="RelativTextSize = value";
_relativtextsize = _value;
 //BA.debugLineNum = 353;BA.debugLine="End Sub";
return "";
}
public String  _showcalendar(boolean _b) throws Exception{
 //BA.debugLineNum = 229;BA.debugLine="Public Sub ShowCalendar(b As Boolean)";
 //BA.debugLineNum = 230;BA.debugLine="pnl.Visible = b";
_pnl.setVisible(_b);
 //BA.debugLineNum = 231;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
