package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgappupdate extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgappupdate");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgappupdate.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _basepnl = null;
public sadLogic.OctoTouchController.b4xdialog _mdialog = null;
public sadLogic.OctoTouchController.autotextsizelabel _lblaction = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblpb = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncontinue = null;
public int _days_between_checks = 0;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public void  _btnctrl_click() throws Exception{
ResumableSub_btnCtrl_Click rsub = new ResumableSub_btnCtrl_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnCtrl_Click extends BA.ResumableSub {
public ResumableSub_btnCtrl_Click(sadLogic.OctoTouchController.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgappupdate parent;
anywheresoftware.b4a.objects.B4XViewWrapper _btn = null;
String _downloaddir = "";
sadLogic.OctoTouchController.httpjob _j = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
String _err = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 178;BA.debugLine="Dim btn As B4XView = mDialog.GetButton(xui.Dialog";
_btn = new anywheresoftware.b4a.objects.B4XViewWrapper();
_btn = parent._mdialog._getbutton /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 179;BA.debugLine="btn.Visible = False";
_btn.setVisible(parent.__c.False);
 //BA.debugLineNum = 180;BA.debugLine="btnContinue.Visible = False";
parent._btncontinue.setVisible(parent.__c.False);
 //BA.debugLineNum = 182;BA.debugLine="lblAction.Text = \"Downloading Update...\"";
parent._lblaction._settext /*Object*/ ((Object)("Downloading Update..."));
 //BA.debugLineNum = 185;BA.debugLine="Dim DownloadDir As String = GetDownloadDir 'ignor";
_downloaddir = parent._getdownloaddir();
 //BA.debugLineNum = 187;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j = new sadLogic.OctoTouchController.httpjob();
 //BA.debugLineNum = 187;BA.debugLine="Dim j As HttpJob : j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 189;BA.debugLine="j.Download(gblConst.APK_NAME)";
_j._download /*String*/ (parent._gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 190;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 13;
return;
case 13:
//C
this.state = 1;
_j = (sadLogic.OctoTouchController.httpjob) result[0];
;
 //BA.debugLineNum = 191;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 14;
return;
case 14:
//C
this.state = 1;
;
 //BA.debugLineNum = 193;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 12;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 12;
 //BA.debugLineNum = 195;BA.debugLine="lblAction.Text = \"Writing file...\"";
parent._lblaction._settext /*Object*/ ((Object)("Writing file..."));
 //BA.debugLineNum = 196;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 15;
return;
case 15:
//C
this.state = 12;
;
 //BA.debugLineNum = 198;BA.debugLine="Dim out As OutputStream = File.OpenOutput(Downlo";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
_out = parent.__c.File.OpenOutput(_downloaddir,parent._filehelpers._getfilenamefrompath /*String*/ (ba,parent._gblconst._apk_name /*String*/ ),parent.__c.False);
 //BA.debugLineNum = 201;BA.debugLine="File.Copy2(j.GetInputStream, out)";
parent.__c.File.Copy2((java.io.InputStream)(_j._getinputstream /*anywheresoftware.b4a.objects.streams.File.InputStreamWrapper*/ ().getObject()),(java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 202;BA.debugLine="out.Close '<------ very important";
_out.Close();
 //BA.debugLineNum = 203;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 204;BA.debugLine="Sleep(200)";
parent.__c.Sleep(ba,this,(int) (200));
this.state = 16;
return;
case 16:
//C
this.state = 12;
;
 //BA.debugLineNum = 206;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus2(Main,\"S";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubdelayedplus2 /*String*/ ((Object)(parent._main.getObject()),"Start_ApkInstall",(int) (300),(Object[])(new String[]{_downloaddir}));
 //BA.debugLineNum = 208;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel) '<--- c";
parent._mdialog._close /*boolean*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 209;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 213;BA.debugLine="Dim err As String = \"\"";
_err = "";
 //BA.debugLineNum = 215;BA.debugLine="If j.ErrorMessage.Contains(\"File not\") Then err";
if (true) break;

case 6:
//if
this.state = 11;
if (_j._errormessage /*String*/ .contains("File not")) { 
this.state = 8;
;}if (true) break;

case 8:
//C
this.state = 11;
_err = "File not found";
if (true) break;

case 11:
//C
this.state = 12;
;
 //BA.debugLineNum = 216;BA.debugLine="lblAction.Text = \"Download failed\" & CRLF & err";
parent._lblaction._settext /*Object*/ ((Object)("Download failed"+parent.__c.CRLF+_err));
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 220;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(sadLogic.OctoTouchController.httpjob _j) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _checkifnewdownloadavail() throws Exception{
ResumableSub_CheckIfNewDownloadAvail rsub = new ResumableSub_CheckIfNewDownloadAvail(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_CheckIfNewDownloadAvail extends BA.ResumableSub {
public ResumableSub_CheckIfNewDownloadAvail(sadLogic.OctoTouchController.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgappupdate parent;
String _insub = "";
long _olddate = 0L;
int _days = 0;
sadLogic.OctoTouchController.httpdownloadstr _sm = null;
String _txt = "";
String[] _parts = null;
String _vercode = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 32;BA.debugLine="Dim inSub As String = \"CheckIfNewDownloadAvail\"";
_insub = "CheckIfNewDownloadAvail";
 //BA.debugLineNum = 34;BA.debugLine="Dim oldDate As Long = Main.kvs.GetDefault(gblCons";
_olddate = BA.ObjectToLongNumber(parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._getdefault /*Object*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(0)));
 //BA.debugLineNum = 35;BA.debugLine="If oldDate = 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_olddate==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 36;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTim";
parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 37;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 45;BA.debugLine="Dim days As Int = DateUtils.PeriodBetweenInDays(o";
_days = (parent._dateutils._periodbetweenindays(ba,_olddate,parent.__c.DateTime.getNow())).Days;
 //BA.debugLineNum = 46;BA.debugLine="logMe.LogIt(\"update check - days between: \" & day";
parent._logme._logit /*String*/ (ba,"update check - days between: "+BA.NumberToString(_days),"");
 //BA.debugLineNum = 47;BA.debugLine="If days < DAYS_BETWEEN_CHECKS Then";
if (true) break;

case 5:
//if
this.state = 8;
if (_days<parent._days_between_checks) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 48;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 8:
//C
this.state = 9;
;
 //BA.debugLineNum = 52;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm = new sadLogic.OctoTouchController.httpdownloadstr();
 //BA.debugLineNum = 52;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm._initialize /*String*/ (ba);
 //BA.debugLineNum = 53;BA.debugLine="Wait For (sm.SendRequest(gblConst.APK_FILE_INFO))";
parent.__c.WaitFor("complete", ba, this, _sm._sendrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._gblconst._apk_file_info /*String*/ ));
this.state = 19;
return;
case 19:
//C
this.state = 9;
_txt = (String) result[0];
;
 //BA.debugLineNum = 55;BA.debugLine="If txt.Contains(\"vcode=\") = False Then";
if (true) break;

case 9:
//if
this.state = 12;
if (_txt.contains("vcode=")==parent.__c.False) { 
this.state = 11;
}if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 56;BA.debugLine="Return False '--- no connection? bad ver info?";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 59;BA.debugLine="txt = txt.Replace(Chr(13),\"\") '<-- strip the chr(";
_txt = _txt.replace(BA.ObjectToString(parent.__c.Chr((int) (13))),"");
 //BA.debugLineNum = 61;BA.debugLine="Try";
if (true) break;

case 13:
//try
this.state = 18;
this.catchState = 17;
this.state = 15;
if (true) break;

case 15:
//C
this.state = 18;
this.catchState = 17;
 //BA.debugLineNum = 63;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTim";
parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 64;BA.debugLine="Dim parts() As String = Regex.Split(CRLF,txt)";
_parts = parent.__c.Regex.Split(parent.__c.CRLF,_txt);
 //BA.debugLineNum = 65;BA.debugLine="Dim VerCode As String = Regex.Split(\"=\",parts(0)";
_vercode = parent.__c.Regex.Split("=",_parts[(int) (0)])[(int) (1)];
 //BA.debugLineNum = 67;BA.debugLine="Return (VerCode.As(Int) > Application.VersionCod";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)((((int)(Double.parseDouble(_vercode)))>parent.__c.Application.getVersionCode())));return;};
 if (true) break;

case 17:
//C
this.state = 18;
this.catchState = 0;
 //BA.debugLineNum = 71;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,inSub";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,_insub);
 //BA.debugLineNum = 72;BA.debugLine="Return False";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.False));return;};
 if (true) break;
if (true) break;

case 18:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(String _txt) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgAppUpdate\"'";
_mmodule = "dlgAppUpdate";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XView, xui As XUI";
_mmainobj = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private BasePnl As B4XView, mDialog As B4XDialog";
_basepnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_mdialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 12;BA.debugLine="Private lblAction As AutoTextSizeLabel,lblPB As L";
_lblaction = new sadLogic.OctoTouchController.autotextsizelabel();
_lblpb = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private btnContinue As Button";
_btncontinue = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private Const DAYS_BETWEEN_CHECKS As Int = 15";
_days_between_checks = (int) (15);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _cleanupapkdownload() throws Exception{
 //BA.debugLineNum = 20;BA.debugLine="Public Sub CleanUpApkDownload";
 //BA.debugLineNum = 22;BA.debugLine="fileHelpers.SafeKill2(Main.Provider.SharedFolder,";
_filehelpers._safekill2 /*String*/ (ba,_main._provider /*sadLogic.OctoTouchController.fileprovider*/ ._sharedfolder /*String*/ ,_gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 23;BA.debugLine="fileHelpers.SafeKill2(Main.Provider.SharedFolder,";
_filehelpers._safekill2 /*String*/ (ba,_main._provider /*sadLogic.OctoTouchController.fileprovider*/ ._sharedfolder /*String*/ ,_gblconst._apk_file_info /*String*/ );
 //BA.debugLineNum = 24;BA.debugLine="fileHelpers.SafeKill2(xui.DefaultFolder,gblConst.";
_filehelpers._safekill2 /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._apk_name /*String*/ );
 //BA.debugLineNum = 25;BA.debugLine="fileHelpers.SafeKill2(xui.DefaultFolder,gblConst.";
_filehelpers._safekill2 /*String*/ (ba,_xui.getDefaultFolder(),_gblconst._apk_file_info /*String*/ );
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 87;BA.debugLine="mDialog.Close(-1)";
_mdialog._close /*boolean*/ ((int) (-1));
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _getdownloaddir() throws Exception{
String _dl = "";
 //BA.debugLineNum = 225;BA.debugLine="Private Sub GetDownloadDir() As String";
 //BA.debugLineNum = 228;BA.debugLine="Dim dl As String";
_dl = "";
 //BA.debugLineNum = 229;BA.debugLine="Try";
try { //BA.debugLineNum = 231;BA.debugLine="dl = Main.Provider.SharedFolder";
_dl = _main._provider /*sadLogic.OctoTouchController.fileprovider*/ ._sharedfolder /*String*/ ;
 //BA.debugLineNum = 232;BA.debugLine="File.WriteString(dl,\"t.t\",\"test\")";
__c.File.WriteString(_dl,"t.t","test");
 //BA.debugLineNum = 233;BA.debugLine="File.Delete(dl,\"t.t\")";
__c.File.Delete(_dl,"t.t");
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 237;BA.debugLine="dl = xui.DefaultFolder";
_dl = _xui.getDefaultFolder();
 };
 //BA.debugLineNum = 241;BA.debugLine="logMe.LogIt(\"App update folder: \" & dl, mModule)";
_logme._logit /*String*/ (ba,"App update folder: "+_dl,_mmodule);
 //BA.debugLineNum = 242;BA.debugLine="Return dl '--- all good";
if (true) return _dl;
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public void  _grabverinfo() throws Exception{
ResumableSub_GrabVerInfo rsub = new ResumableSub_GrabVerInfo(this);
rsub.resume(ba, null);
}
public static class ResumableSub_GrabVerInfo extends BA.ResumableSub {
public ResumableSub_GrabVerInfo(sadLogic.OctoTouchController.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgappupdate parent;
sadLogic.OctoTouchController.httpdownloadstr _sm = null;
String _txt = "";
String[] _parts = null;
String _vercode = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 133;BA.debugLine="Main.kvs.Put(gblConst.CHECK_VERSION_DATE,DateTime";
parent._main._kvs /*sadLogic.OctoTouchController.keyvaluestore*/ ._put /*String*/ (parent._gblconst._check_version_date /*String*/ ,(Object)(parent.__c.DateTime.getNow()));
 //BA.debugLineNum = 135;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm = new sadLogic.OctoTouchController.httpdownloadstr();
 //BA.debugLineNum = 135;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm._initialize /*String*/ (ba);
 //BA.debugLineNum = 136;BA.debugLine="Wait For (sm.SendRequest(gblConst.APK_FILE_INFO))";
parent.__c.WaitFor("complete", ba, this, _sm._sendrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._gblconst._apk_file_info /*String*/ ));
this.state = 15;
return;
case 15:
//C
this.state = 1;
_txt = (String) result[0];
;
 //BA.debugLineNum = 138;BA.debugLine="If txt.Contains(\"vcode=\") = False Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_txt.contains("vcode=")==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 139;BA.debugLine="lblAction.BaseLabel.Height = lblAction.BaseLabel";
parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setHeight((int) (parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getHeight()+parent.__c.DipToCurrent((int) (20))));
 //BA.debugLineNum = 140;BA.debugLine="lblAction.Text = \"Error talking to update server";
parent._lblaction._settext /*Object*/ ((Object)("Error talking to update server."));
 //BA.debugLineNum = 141;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 145;BA.debugLine="txt = txt.Replace(Chr(13),\"\") '--- strip the chr(";
_txt = _txt.replace(BA.ObjectToString(parent.__c.Chr((int) (13))),"");
 //BA.debugLineNum = 147;BA.debugLine="Try";
if (true) break;

case 5:
//try
this.state = 14;
this.catchState = 13;
this.state = 7;
if (true) break;

case 7:
//C
this.state = 8;
this.catchState = 13;
 //BA.debugLineNum = 149;BA.debugLine="Dim parts() As String = Regex.Split(CRLF,txt)";
_parts = parent.__c.Regex.Split(parent.__c.CRLF,_txt);
 //BA.debugLineNum = 150;BA.debugLine="Dim VerCode As String = Regex.Split(\"=\",parts(0)";
_vercode = parent.__c.Regex.Split("=",_parts[(int) (0)])[(int) (1)];
 //BA.debugLineNum = 152;BA.debugLine="If VerCode.As(Int) <= Application.VersionCode Th";
if (true) break;

case 8:
//if
this.state = 11;
if (((int)(Double.parseDouble(_vercode)))<=parent.__c.Application.getVersionCode()) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 153;BA.debugLine="lblAction.Text = \"No update found.\"";
parent._lblaction._settext /*Object*/ ((Object)("No update found."));
 //BA.debugLineNum = 154;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 14;
;
 //BA.debugLineNum = 157;BA.debugLine="lblAction.BaseLabel.Top = lblAction.BaseLabel.To";
parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().setTop((int) (parent._lblaction._getbaselabel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getTop()-parent.__c.DipToCurrent((int) (6))));
 //BA.debugLineNum = 158;BA.debugLine="lblAction.Text = $\"Update found: V${Regex.Split(";
parent._lblaction._settext /*Object*/ ((Object)(("Update found: V"+parent.__c.SmartStringFormatter("",(Object)(parent.__c.Regex.Split("=",_parts[(int) (1)])[(int) (1)]))+"")));
 //BA.debugLineNum = 159;BA.debugLine="btnContinue.Visible = True";
parent._btncontinue.setVisible(parent.__c.True);
 //BA.debugLineNum = 160;BA.debugLine="btnContinue.Text = \"Download\"";
parent._btncontinue.setText(BA.ObjectToCharSequence("Download"));
 if (true) break;

case 13:
//C
this.state = 14;
this.catchState = 0;
 //BA.debugLineNum = 164;BA.debugLine="logMe.LogIt2(LastException.Message,mModule,\"Grab";
parent._logme._logit2 /*String*/ (ba,parent.__c.LastException(ba).getMessage(),parent._mmodule,"GrabVerInfo");
 //BA.debugLineNum = 165;BA.debugLine="lblAction.Text = \"Error parsing update file.\"";
parent._lblaction._settext /*Object*/ ((Object)("Error parsing update file."));
 if (true) break;
if (true) break;

case 14:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _parentobj) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 79;BA.debugLine="Public Sub Initialize(parentObj As B4XView) As Obj";
 //BA.debugLineNum = 81;BA.debugLine="mMainObj = parentObj";
_mmainobj = _parentobj;
 //BA.debugLineNum = 82;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgappupdate parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgappupdate parent;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 92;BA.debugLine="CleanUpApkDownload";
parent._cleanupapkdownload();
 //BA.debugLineNum = 93;BA.debugLine="BasePnl = xui.CreatePanel(\"\")";
parent._basepnl = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 94;BA.debugLine="BasePnl.SetLayoutAnimated(0, 0, 0, IIf(guiHelpers";
parent._basepnl.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int)(BA.ObjectToNumber(((parent._guihelpers._gislandscape /*boolean*/ ) ? ((Object)(parent.__c.DipToCurrent((int) (360)))) : ((Object)(parent.__c.PerXToCurrent((float) (96),ba)))))),parent.__c.DipToCurrent((int) (260)));
 //BA.debugLineNum = 95;BA.debugLine="BasePnl.LoadLayout(\"viewAppUpdate\")";
parent._basepnl.LoadLayout("viewAppUpdate",ba);
 //BA.debugLineNum = 97;BA.debugLine="lblAction.TextColor = clrTheme.txtNormal";
parent._lblaction._settextcolor /*int*/ (parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 98;BA.debugLine="lblAction.Text = \"Checking for update...\"";
parent._lblaction._settext /*Object*/ ((Object)("Checking for update..."));
 //BA.debugLineNum = 99;BA.debugLine="btnContinue.Visible = False";
parent._btncontinue.setVisible(parent.__c.False);
 //BA.debugLineNum = 100;BA.debugLine="lblPB.Visible   = False";
parent._lblpb.setVisible(parent.__c.False);
 //BA.debugLineNum = 101;BA.debugLine="lblPB.TextColor = clrTheme.txtNormal";
parent._lblpb.setTextColor(parent._clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 102;BA.debugLine="BasePnl.Color = clrTheme.Background";
parent._basepnl.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 105;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnContinue";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btncontinue});
 //BA.debugLineNum = 106;BA.debugLine="btnContinue.TextSize = NumberFormat2(btnContinue.";
parent._btncontinue.setTextSize((float) ((double)(Double.parseDouble(parent.__c.NumberFormat2(parent._btncontinue.getTextSize()/(double)parent._guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),parent.__c.False)))-(double)(BA.ObjectToNumber(((parent._guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 109;BA.debugLine="mDialog.Initialize(mMainObj)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj);
 //BA.debugLineNum = 110;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 111;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 113;BA.debugLine="dlgHelper.ThemeDialogForm(\"App Update\")";
_dlghelper._themedialogform /*String*/ ((Object)("App Update"));
 //BA.debugLineNum = 114;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(BaseP";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._basepnl,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 115;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 118;BA.debugLine="Main.tmrTimerCallSub.CallSubPlus(Me,\"GrabVerInfo\"";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.callsubutils*/ ._callsubplus /*String*/ (parent,"GrabVerInfo",(int) (250));
 //BA.debugLineNum = 121;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 122;BA.debugLine="B4XPages.MainPage.pObjCurrentDlg1 = Null";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 125;BA.debugLine="Return Result";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
