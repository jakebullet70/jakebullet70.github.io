package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class lmb4ximageviewx extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.lmb4ximageviewx");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.lmb4ximageviewx.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbase = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlover = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xpnlover = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _tag = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _iv = null;
public String _mresizemode = "";
public boolean _mround = false;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _mbitmap = null;
public int _mbackgroundcolor = 0;
public int _mclickanimationcolor = 0;
public int _mcornersradius = 0;
public boolean _mclickanimation = false;
public String _mtag2 = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 108;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 109;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 55;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 56;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 57;BA.debugLine="Public mBase As B4XView";
_mbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 62;BA.debugLine="Private pnlOver As Panel";
_pnlover = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 64;BA.debugLine="Private xpnlOver As B4XView";
_xpnlover = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 66;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 67;BA.debugLine="Public Tag As Object";
_tag = new Object();
 //BA.debugLineNum = 68;BA.debugLine="Private iv As B4XView";
_iv = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 69;BA.debugLine="Private mResizeMode As String";
_mresizemode = "";
 //BA.debugLineNum = 70;BA.debugLine="Private mRound As Boolean";
_mround = false;
 //BA.debugLineNum = 71;BA.debugLine="Private mBitmap As B4XBitmap";
_mbitmap = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 72;BA.debugLine="Public mBackgroundColor As Int";
_mbackgroundcolor = 0;
 //BA.debugLineNum = 73;BA.debugLine="Public mClickAnimationColor As Int";
_mclickanimationcolor = 0;
 //BA.debugLineNum = 74;BA.debugLine="Private mCornersRadius As Int";
_mcornersradius = 0;
 //BA.debugLineNum = 75;BA.debugLine="Private mClickAnimation As Boolean";
_mclickanimation = false;
 //BA.debugLineNum = 76;BA.debugLine="Private mTag2 As String = \"\"";
_mtag2 = "";
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _clear() throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Public Sub Clear";
 //BA.debugLineNum = 250;BA.debugLine="mBitmap = Null";
_mbitmap = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.Null));
 //BA.debugLineNum = 251;BA.debugLine="iv.SetBitmap(Null)";
_iv.SetBitmap((android.graphics.Bitmap)(__c.Null));
 //BA.debugLineNum = 252;BA.debugLine="End Sub";
return "";
}
public String  _click_animation() throws Exception{
 //BA.debugLineNum = 339;BA.debugLine="private Sub Click_Animation";
 //BA.debugLineNum = 340;BA.debugLine="CreateHaloEffect(pnlOver,mClickAnimationColor)";
_createhaloeffect((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_pnlover.getObject())),_mclickanimationcolor);
 //BA.debugLineNum = 341;BA.debugLine="End Sub";
return "";
}
public String  _createhaloeffect(anywheresoftware.b4a.objects.B4XViewWrapper _parent,int _clr) throws Exception{
anywheresoftware.b4a.objects.B4XCanvas _cvs = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int _radius = 0;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp = null;
 //BA.debugLineNum = 343;BA.debugLine="Private Sub CreateHaloEffect (Parent As B4XView,cl";
 //BA.debugLineNum = 344;BA.debugLine="Dim cvs As B4XCanvas";
_cvs = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 345;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 346;BA.debugLine="Dim radius As Int = 220dip";
_radius = __c.DipToCurrent((int) (220));
 //BA.debugLineNum = 347;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, radius * 2, radius *";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_radius*2),(int) (_radius*2));
 //BA.debugLineNum = 348;BA.debugLine="cvs.Initialize(p)";
_cvs.Initialize(_p);
 //BA.debugLineNum = 349;BA.debugLine="cvs.DrawCircle(cvs.TargetRect.CenterX, cvs.Target";
_cvs.DrawCircle(_cvs.getTargetRect().getCenterX(),_cvs.getTargetRect().getCenterY(),(float) (_cvs.getTargetRect().getWidth()/(double)2),_clr,__c.True,(float) (0));
 //BA.debugLineNum = 350;BA.debugLine="Dim bmp As B4XBitmap = cvs.CreateBitmap";
_bmp = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_bmp = _cvs.CreateBitmap();
 //BA.debugLineNum = 352;BA.debugLine="CreateHaloEffectHelper(Parent,bmp, radius)";
_createhaloeffecthelper(_parent,_bmp,_radius);
 //BA.debugLineNum = 354;BA.debugLine="End Sub";
return "";
}
public void  _createhaloeffecthelper(anywheresoftware.b4a.objects.B4XViewWrapper _parent,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp,int _radius) throws Exception{
ResumableSub_CreateHaloEffectHelper rsub = new ResumableSub_CreateHaloEffectHelper(this,_parent,_bmp,_radius);
rsub.resume(ba, null);
}
public static class ResumableSub_CreateHaloEffectHelper extends BA.ResumableSub {
public ResumableSub_CreateHaloEffectHelper(sadLogic.HomeCentral.lmb4ximageviewx parent,anywheresoftware.b4a.objects.B4XViewWrapper _parent,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp,int _radius) {
this.parent = parent;
this._parent = _parent;
this._bmp = _bmp;
this._radius = _radius;
}
sadLogic.HomeCentral.lmb4ximageviewx parent;
anywheresoftware.b4a.objects.B4XViewWrapper _parent;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp;
int _radius;
float _x = 0f;
float _y = 0f;
anywheresoftware.b4a.objects.ImageViewWrapper _iv1 = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int _duration = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 357;BA.debugLine="Dim x As Float = Parent.Width / 2";
_x = (float) (_parent.getWidth()/(double)2);
 //BA.debugLineNum = 358;BA.debugLine="Dim y As Float = Parent.Height / 2";
_y = (float) (_parent.getHeight()/(double)2);
 //BA.debugLineNum = 359;BA.debugLine="Dim iv1 As ImageView";
_iv1 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 360;BA.debugLine="iv1.Initialize(\"\")";
_iv1.Initialize(ba,"");
 //BA.debugLineNum = 361;BA.debugLine="Dim p As B4XView = iv1";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_iv1.getObject()));
 //BA.debugLineNum = 362;BA.debugLine="p.SetBitmap(bmp)";
_p.SetBitmap((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 363;BA.debugLine="Parent.AddView(p, x, y, 0, 0)";
_parent.AddView((android.view.View)(_p.getObject()),(int) (_x),(int) (_y),(int) (0),(int) (0));
 //BA.debugLineNum = 364;BA.debugLine="Dim duration As Int = 660";
_duration = (int) (660);
 //BA.debugLineNum = 365;BA.debugLine="p.SetLayoutAnimated(duration, x - radius, y - rad";
_p.SetLayoutAnimated(_duration,(int) (_x-_radius),(int) (_y-_radius),(int) (2*_radius),(int) (2*_radius));
 //BA.debugLineNum = 366;BA.debugLine="p.SetVisibleAnimated(duration, False)";
_p.SetVisibleAnimated(_duration,parent.__c.False);
 //BA.debugLineNum = 367;BA.debugLine="Sleep(duration)";
parent.__c.Sleep(ba,this,_duration);
this.state = 1;
return;
case 1:
//C
this.state = -1;
;
 //BA.debugLineNum = 368;BA.debugLine="p.RemoveViewFromParent";
_p.RemoveViewFromParent();
 //BA.debugLineNum = 369;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _designercreateview(Object _base,anywheresoftware.b4a.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
anywheresoftware.b4a.objects.ImageViewWrapper _iiv = null;
 //BA.debugLineNum = 86;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 87;BA.debugLine="mBase = Base";
_mbase = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 88;BA.debugLine="Tag = mBase.Tag";
_tag = _mbase.getTag();
 //BA.debugLineNum = 89;BA.debugLine="mBase.Tag = Me";
_mbase.setTag(this);
 //BA.debugLineNum = 90;BA.debugLine="Dim iiv As ImageView";
_iiv = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 91;BA.debugLine="iiv.Initialize(\"iv\")";
_iiv.Initialize(ba,"iv");
 //BA.debugLineNum = 92;BA.debugLine="iv = iiv";
_iv = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_iiv.getObject()));
 //BA.debugLineNum = 93;BA.debugLine="mClickAnimation=Props.Get(\"ClickAnimation\")";
_mclickanimation = BA.ObjectToBoolean(_props.Get((Object)("ClickAnimation")));
 //BA.debugLineNum = 94;BA.debugLine="mRound =Props.Get(\"Round\")";
_mround = BA.ObjectToBoolean(_props.Get((Object)("Round")));
 //BA.debugLineNum = 95;BA.debugLine="mResizeMode = Props.Get(\"ResizeMode\")";
_mresizemode = BA.ObjectToString(_props.Get((Object)("ResizeMode")));
 //BA.debugLineNum = 96;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props.";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 97;BA.debugLine="mClickAnimationColor = xui.PaintOrColorToColor(Pr";
_mclickanimationcolor = _xui.PaintOrColorToColor(_props.Get((Object)("ClickAnimationColor")));
 //BA.debugLineNum = 98;BA.debugLine="mCornersRadius = DipToCurrent(Props.GetDefault(\"C";
_mcornersradius = __c.DipToCurrent((int)(BA.ObjectToNumber(_props.GetDefault((Object)("CornersRadius"),(Object)(0)))));
 //BA.debugLineNum = 99;BA.debugLine="mBase.AddView(iv, 0, 0, mBase.Width, mBase.Height";
_mbase.AddView((android.view.View)(_iv.getObject()),(int) (0),(int) (0),_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 100;BA.debugLine="xpnlOver = xui.CreatePanel(\"pnlOver\")";
_xpnlover = _xui.CreatePanel(ba,"pnlOver");
 //BA.debugLineNum = 101;BA.debugLine="xpnlOver.SetLayoutAnimated(0, 0, 0, mBase.Width,";
_xpnlover.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 102;BA.debugLine="xpnlOver.Color = xui.Color_Transparent";
_xpnlover.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 103;BA.debugLine="pnlOver = xpnlOver";
_pnlover = (anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(_xpnlover.getObject()));
 //BA.debugLineNum = 104;BA.debugLine="mBase.AddView(pnlOver, 0, 0, mBase.Width, mBase.H";
_mbase.AddView((android.view.View)(_pnlover.getObject()),(int) (0),(int) (0),_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 105;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _getbitmap() throws Exception{
 //BA.debugLineNum = 166;BA.debugLine="Public Sub getBitmap As B4XBitmap";
 //BA.debugLineNum = 167;BA.debugLine="Return mBitmap";
if (true) return _mbitmap;
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return null;
}
public boolean  _getclickanimation() throws Exception{
 //BA.debugLineNum = 123;BA.debugLine="Public Sub getClickAnimation As Boolean";
 //BA.debugLineNum = 124;BA.debugLine="Return mClickAnimation";
if (true) return _mclickanimation;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return false;
}
public int  _getcornersradius() throws Exception{
 //BA.debugLineNum = 141;BA.debugLine="Public Sub getCornersRadius As Int";
 //BA.debugLineNum = 142;BA.debugLine="Return mCornersRadius";
if (true) return _mcornersradius;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return 0;
}
public double  _getheight() throws Exception{
 //BA.debugLineNum = 198;BA.debugLine="Public Sub getHeight As Double";
 //BA.debugLineNum = 199;BA.debugLine="Return mBase.Height";
if (true) return _mbase.getHeight();
 //BA.debugLineNum = 200;BA.debugLine="End Sub";
return 0;
}
public double  _getleft() throws Exception{
 //BA.debugLineNum = 174;BA.debugLine="Public Sub getLeft As Double";
 //BA.debugLineNum = 175;BA.debugLine="Return mBase.Left";
if (true) return _mbase.getLeft();
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
return 0;
}
public String  _getresizemode() throws Exception{
 //BA.debugLineNum = 151;BA.debugLine="Public Sub getResizeMode As String";
 //BA.debugLineNum = 152;BA.debugLine="Return mResizeMode";
if (true) return _mresizemode;
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public boolean  _getroundedimage() throws Exception{
 //BA.debugLineNum = 131;BA.debugLine="Public Sub getRoundedImage As Boolean";
 //BA.debugLineNum = 132;BA.debugLine="Return mRound";
if (true) return _mround;
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return false;
}
public String  _gettag2() throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Public Sub getTag2 As String";
 //BA.debugLineNum = 116;BA.debugLine="Return mTag2";
if (true) return _mtag2;
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public double  _gettop() throws Exception{
 //BA.debugLineNum = 182;BA.debugLine="Public Sub getTop As Double";
 //BA.debugLineNum = 183;BA.debugLine="Return mBase.Top";
if (true) return _mbase.getTop();
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return 0;
}
public double  _getwidth() throws Exception{
 //BA.debugLineNum = 190;BA.debugLine="Public Sub getWidth As Double";
 //BA.debugLineNum = 191;BA.debugLine="Return mBase.Width";
if (true) return _mbase.getWidth();
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 80;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 81;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 82;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _load(String _dir,String _filename) throws Exception{
 //BA.debugLineNum = 240;BA.debugLine="Public Sub Load (Dir As String, FileName As String";
 //BA.debugLineNum = 242;BA.debugLine="setBitmap(LoadBitmapSample(Dir, FileName, mBase.W";
_setbitmap((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmapSample(_dir,_filename,_mbase.getWidth(),_mbase.getHeight()).getObject())));
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public String  _pnlover_click() throws Exception{
String _subfullname = "";
 //BA.debugLineNum = 321;BA.debugLine="Private Sub pnlOver_Click";
 //BA.debugLineNum = 322;BA.debugLine="Dim SubFullName As String = mEventName & \"_Click";
_subfullname = _meventname+"_Click";
 //BA.debugLineNum = 323;BA.debugLine="If SubExists(mCallBack, SubFullName) Then";
if (__c.SubExists(ba,_mcallback,_subfullname)) { 
 //BA.debugLineNum = 324;BA.debugLine="If mClickAnimation Then Click_Animation";
if (_mclickanimation) { 
_click_animation();};
 //BA.debugLineNum = 325;BA.debugLine="CallSub(mCallBack, SubFullName)";
__c.CallSubNew(ba,_mcallback,_subfullname);
 };
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return "";
}
public String  _pnlover_longclick() throws Exception{
String _subfullname = "";
 //BA.debugLineNum = 329;BA.debugLine="Private Sub pnlOver_LongClick";
 //BA.debugLineNum = 330;BA.debugLine="Dim SubFullName As String = mEventName & \"_LongC";
_subfullname = _meventname+"_LongClick";
 //BA.debugLineNum = 331;BA.debugLine="If SubExists(mCallBack, SubFullName) Then";
if (__c.SubExists(ba,_mcallback,_subfullname)) { 
 //BA.debugLineNum = 332;BA.debugLine="If mClickAnimation Then Click_Animation";
if (_mclickanimation) { 
_click_animation();};
 //BA.debugLineNum = 333;BA.debugLine="CallSub(mCallBack, SubFullName)";
__c.CallSubNew(ba,_mcallback,_subfullname);
 };
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return "";
}
public String  _setbitmap(anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp) throws Exception{
 //BA.debugLineNum = 160;BA.debugLine="Public Sub setBitmap(Bmp As B4XBitmap)";
 //BA.debugLineNum = 161;BA.debugLine="mBitmap = Bmp";
_mbitmap = _bmp;
 //BA.debugLineNum = 162;BA.debugLine="SetBitmapAndFill(iv, Bmp)";
_setbitmapandfill(_iv,_bmp);
 //BA.debugLineNum = 163;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public String  _setbitmapandfill(anywheresoftware.b4a.objects.B4XViewWrapper _imageview,anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp) throws Exception{
anywheresoftware.b4a.objects.ImageViewWrapper _iiv = null;
 //BA.debugLineNum = 259;BA.debugLine="Private Sub SetBitmapAndFill (ImageView As B4XView";
 //BA.debugLineNum = 260;BA.debugLine="ImageView.SetBitmap(Bmp)";
_imageview.SetBitmap((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 261;BA.debugLine="Dim iiv As ImageView = ImageView";
_iiv = new anywheresoftware.b4a.objects.ImageViewWrapper();
_iiv = (anywheresoftware.b4a.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ImageViewWrapper(), (android.widget.ImageView)(_imageview.getObject()));
 //BA.debugLineNum = 263;BA.debugLine="iiv.Gravity = Gravity.FILL";
_iiv.setGravity(__c.Gravity.FILL);
 //BA.debugLineNum = 269;BA.debugLine="End Sub";
return "";
}
public String  _setclickanimation(boolean _b) throws Exception{
 //BA.debugLineNum = 126;BA.debugLine="Public Sub setClickAnimation (b As Boolean)";
 //BA.debugLineNum = 127;BA.debugLine="mClickAnimation = b";
_mclickanimation = _b;
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public String  _setcornersradius(int _i) throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Public Sub setCornersRadius (i As Int)";
 //BA.debugLineNum = 145;BA.debugLine="mCornersRadius = i";
_mcornersradius = _i;
 //BA.debugLineNum = 146;BA.debugLine="UpdateClip";
_updateclip();
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
return "";
}
public String  _setheight(double _height) throws Exception{
 //BA.debugLineNum = 194;BA.debugLine="Public Sub setHeight(Height As Double)";
 //BA.debugLineNum = 195;BA.debugLine="mBase.Height = Height";
_mbase.setHeight((int) (_height));
 //BA.debugLineNum = 196;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public String  _setleft(double _left) throws Exception{
 //BA.debugLineNum = 170;BA.debugLine="Public Sub setLeft(Left As Double)";
 //BA.debugLineNum = 171;BA.debugLine="mBase.Left = Left";
_mbase.setLeft((int) (_left));
 //BA.debugLineNum = 172;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public String  _setresizemode(String _s) throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Public Sub setResizeMode(s As String)";
 //BA.debugLineNum = 155;BA.debugLine="If s = mResizeMode Then Return";
if ((_s).equals(_mresizemode)) { 
if (true) return "";};
 //BA.debugLineNum = 156;BA.debugLine="mResizeMode = s";
_mresizemode = _s;
 //BA.debugLineNum = 157;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public String  _setroundedimage(boolean _b) throws Exception{
 //BA.debugLineNum = 134;BA.debugLine="Public Sub setRoundedImage (b As Boolean)";
 //BA.debugLineNum = 135;BA.debugLine="If b = mRound Then Return";
if (_b==_mround) { 
if (true) return "";};
 //BA.debugLineNum = 136;BA.debugLine="mRound = b";
_mround = _b;
 //BA.debugLineNum = 137;BA.debugLine="UpdateClip";
_updateclip();
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _settag2(String _s) throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Public Sub setTag2 (s As String)";
 //BA.debugLineNum = 119;BA.debugLine="mTag2 = s";
_mtag2 = _s;
 //BA.debugLineNum = 120;BA.debugLine="End Sub";
return "";
}
public String  _settop(double _top) throws Exception{
 //BA.debugLineNum = 178;BA.debugLine="Public Sub setTop(Top As Double)";
 //BA.debugLineNum = 179;BA.debugLine="mBase.Top = Top";
_mbase.setTop((int) (_top));
 //BA.debugLineNum = 180;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return "";
}
public String  _setwidth(double _width) throws Exception{
 //BA.debugLineNum = 186;BA.debugLine="Public Sub setWidth(Width As Double)";
 //BA.debugLineNum = 187;BA.debugLine="mBase.Width = Width";
_mbase.setWidth((int) (_width));
 //BA.debugLineNum = 188;BA.debugLine="Update";
_update();
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
return "";
}
public String  _update() throws Exception{
float _imageviewwidth = 0f;
float _imageviewheight = 0f;
float _bmpratio = 0f;
float _r = 0f;
 //BA.debugLineNum = 206;BA.debugLine="Public Sub Update";
 //BA.debugLineNum = 207;BA.debugLine="If mBitmap.IsInitialized = False Then Return";
if (_mbitmap.IsInitialized()==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 208;BA.debugLine="UpdateClip";
_updateclip();
 //BA.debugLineNum = 209;BA.debugLine="Dim ImageViewWidth, ImageViewHeight As Float";
_imageviewwidth = 0f;
_imageviewheight = 0f;
 //BA.debugLineNum = 210;BA.debugLine="Dim bmpRatio As Float = mBitmap.Width / mBitmap.H";
_bmpratio = (float) (_mbitmap.getWidth()/(double)_mbitmap.getHeight());
 //BA.debugLineNum = 211;BA.debugLine="Select mResizeMode";
switch (BA.switchObjectToInt(_mresizemode,"FILL","FIT","FILL_WIDTH","FILL_HEIGHT","FILL_NO_DISTORTIONS","NONE")) {
case 0: {
 //BA.debugLineNum = 213;BA.debugLine="ImageViewWidth = mBase.Width";
_imageviewwidth = (float) (_mbase.getWidth());
 //BA.debugLineNum = 214;BA.debugLine="ImageViewHeight = mBase.Height";
_imageviewheight = (float) (_mbase.getHeight());
 break; }
case 1: {
 //BA.debugLineNum = 216;BA.debugLine="Dim r As Float = Min(mBase.Width / mBitmap.Widt";
_r = (float) (__c.Min(_mbase.getWidth()/(double)_mbitmap.getWidth(),_mbase.getHeight()/(double)_mbitmap.getHeight()));
 //BA.debugLineNum = 217;BA.debugLine="ImageViewWidth = mBitmap.Width * r";
_imageviewwidth = (float) (_mbitmap.getWidth()*_r);
 //BA.debugLineNum = 218;BA.debugLine="ImageViewHeight = mBitmap.Height * r";
_imageviewheight = (float) (_mbitmap.getHeight()*_r);
 break; }
case 2: {
 //BA.debugLineNum = 220;BA.debugLine="ImageViewWidth = mBase.Width";
_imageviewwidth = (float) (_mbase.getWidth());
 //BA.debugLineNum = 221;BA.debugLine="ImageViewHeight = ImageViewWidth / bmpRatio";
_imageviewheight = (float) (_imageviewwidth/(double)_bmpratio);
 break; }
case 3: {
 //BA.debugLineNum = 223;BA.debugLine="ImageViewHeight = mBase.Height";
_imageviewheight = (float) (_mbase.getHeight());
 //BA.debugLineNum = 224;BA.debugLine="ImageViewWidth = ImageViewHeight * bmpRatio";
_imageviewwidth = (float) (_imageviewheight*_bmpratio);
 break; }
case 4: {
 //BA.debugLineNum = 226;BA.debugLine="Dim r As Float = Max(mBase.Width / mBitmap.Widt";
_r = (float) (__c.Max(_mbase.getWidth()/(double)_mbitmap.getWidth(),_mbase.getHeight()/(double)_mbitmap.getHeight()));
 //BA.debugLineNum = 227;BA.debugLine="ImageViewWidth = mBitmap.Width * r";
_imageviewwidth = (float) (_mbitmap.getWidth()*_r);
 //BA.debugLineNum = 228;BA.debugLine="ImageViewHeight = mBitmap.Height * r";
_imageviewheight = (float) (_mbitmap.getHeight()*_r);
 break; }
case 5: {
 //BA.debugLineNum = 230;BA.debugLine="ImageViewWidth = mBitmap.Width";
_imageviewwidth = (float) (_mbitmap.getWidth());
 //BA.debugLineNum = 231;BA.debugLine="ImageViewHeight = mBitmap.Height";
_imageviewheight = (float) (_mbitmap.getHeight());
 break; }
default: {
 //BA.debugLineNum = 233;BA.debugLine="Log(\"Invalid resize mode: \"  & mResizeMode)";
__c.LogImpl("34275355","Invalid resize mode: "+_mresizemode,0);
 break; }
}
;
 //BA.debugLineNum = 235;BA.debugLine="iv.SetLayoutAnimated(0, Round(mBase.Width / 2 - I";
_iv.SetLayoutAnimated((int) (0),(int) (__c.Round(_mbase.getWidth()/(double)2-_imageviewwidth/(double)2)),(int) (__c.Round(_mbase.getHeight()/(double)2-_imageviewheight/(double)2)),(int) (__c.Round(_imageviewwidth)),(int) (__c.Round(_imageviewheight)));
 //BA.debugLineNum = 236;BA.debugLine="pnlOver.SetLayoutAnimated(0, iv.Left, iv.Top, iv.";
_pnlover.SetLayoutAnimated((int) (0),_iv.getLeft(),_iv.getTop(),_iv.getWidth(),_iv.getHeight());
 //BA.debugLineNum = 237;BA.debugLine="End Sub";
return "";
}
public String  _updateclip() throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 271;BA.debugLine="Private Sub UpdateClip";
 //BA.debugLineNum = 272;BA.debugLine="If mRound Then";
if (_mround) { 
 //BA.debugLineNum = 273;BA.debugLine="mBase.SetColorAndBorder(mBackgroundColor, 0, 0,";
_mbase.SetColorAndBorder(_mbackgroundcolor,(int) (0),(int) (0),(int) (__c.Min(_mbase.getWidth()/(double)2,_mbase.getHeight()/(double)2)));
 //BA.debugLineNum = 274;BA.debugLine="xpnlOver.SetColorAndBorder(xui.Color_Transparent";
_xpnlover.SetColorAndBorder(_xui.Color_Transparent,(int) (0),(int) (0),(int) (__c.Min(_mbase.getWidth()/(double)2,_mbase.getHeight()/(double)2)));
 }else {
 //BA.debugLineNum = 276;BA.debugLine="mBase.SetColorAndBorder(mBackgroundColor, 0, 0,";
_mbase.SetColorAndBorder(_mbackgroundcolor,(int) (0),(int) (0),_mcornersradius);
 //BA.debugLineNum = 277;BA.debugLine="xpnlOver.SetColorAndBorder(xui.Color_Transparent";
_xpnlover.SetColorAndBorder(_xui.Color_Transparent,(int) (0),(int) (0),_mcornersradius);
 };
 //BA.debugLineNum = 299;BA.debugLine="Try";
try { //BA.debugLineNum = 300;BA.debugLine="Dim jo As JavaObject = mBase";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_mbase.getObject()));
 //BA.debugLineNum = 301;BA.debugLine="jo.RunMethod(\"setClipToOutline\", Array(mRound Or";
_jo.RunMethod("setClipToOutline",new Object[]{(Object)(_mround || _mcornersradius>0)});
 } 
       catch (Exception e12) {
			ba.setLastException(e12); };
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
