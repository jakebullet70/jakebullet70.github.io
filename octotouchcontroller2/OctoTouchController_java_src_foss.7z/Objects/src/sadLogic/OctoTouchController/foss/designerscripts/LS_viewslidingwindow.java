package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewslidingwindow{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _h="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmaindrawer").vw.setLeft((int)(0d));
views.get("pnlmaindrawer").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlmaindrawer").vw.setTop((int)(0d));
views.get("pnlmaindrawer").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlbtnsdrawer").vw.setLeft((int)((views.get("pnlmaindrawer").vw.getLeft())));
views.get("pnlbtnsdrawer").vw.setWidth((int)((views.get("pnlmaindrawer").vw.getLeft() + views.get("pnlmaindrawer").vw.getWidth()) - ((views.get("pnlmaindrawer").vw.getLeft()))));
views.get("pnlbtnsdrawer").vw.setTop((int)(0d));
views.get("pnlbtnsdrawer").vw.setHeight((int)((100d * scale) - (0d)));
views.get("pnllinebreakdrawer").vw.setLeft((int)((views.get("pnlmaindrawer").vw.getLeft())+(10d * scale)));
views.get("pnllinebreakdrawer").vw.setWidth((int)((views.get("pnlmaindrawer").vw.getLeft() + views.get("pnlmaindrawer").vw.getWidth())-(10d * scale) - ((views.get("pnlmaindrawer").vw.getLeft())+(10d * scale))));
views.get("pnllinebreakdrawer").vw.setTop((int)((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight())));
views.get("pnllinebreakdrawer").vw.setHeight((int)((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight())+(2d * scale) - ((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight()))));
_h = BA.NumberToString((6d * scale));
views.get("btnfrestart").vw.setTop((int)(Double.parseDouble(_h)));
views.get("btnfrestart").vw.setHeight((int)((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight())-Double.parseDouble(_h) - (Double.parseDouble(_h))));
views.get("btnstop").vw.setTop((int)(Double.parseDouble(_h)));
views.get("btnstop").vw.setHeight((int)((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight())-Double.parseDouble(_h) - (Double.parseDouble(_h))));
views.get("btnrestart").vw.setTop((int)(Double.parseDouble(_h)));
views.get("btnrestart").vw.setHeight((int)((views.get("pnlbtnsdrawer").vw.getTop() + views.get("pnlbtnsdrawer").vw.getHeight())-Double.parseDouble(_h) - (Double.parseDouble(_h))));
anywheresoftware.b4a.keywords.DesignerArgs.callsub(ba, parent, lv, props, "dse_layout", "spreadhorizontally", width, height, views, new Object[] {"pnlbtnsdrawer", BA.NumberToString((80d * scale)), BA.NumberToString((6d * scale)), "center"});
views.get("clvdrawer").vw.setLeft((int)((4d * scale)));
views.get("clvdrawer").vw.setWidth((int)((views.get("pnlmaindrawer").vw.getWidth())-(4d * scale) - ((4d * scale))));
views.get("clvdrawer").vw.setTop((int)((views.get("pnllinebreakdrawer").vw.getTop() + views.get("pnllinebreakdrawer").vw.getHeight())+(2d * scale)));
views.get("clvdrawer").vw.setHeight((int)((views.get("pnlmaindrawer").vw.getTop() + views.get("pnlmaindrawer").vw.getHeight())-(4d * scale) - ((views.get("pnllinebreakdrawer").vw.getTop() + views.get("pnllinebreakdrawer").vw.getHeight())+(2d * scale))));

}
}