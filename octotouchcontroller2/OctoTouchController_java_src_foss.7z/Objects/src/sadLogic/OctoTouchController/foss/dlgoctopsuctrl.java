package sadLogic.OctoTouchController.foss;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgoctopsuctrl extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.foss.dlgoctopsuctrl");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.foss.dlgoctopsuctrl.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.foss.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.OctoTouchController.foss.b4xdialog _mdialog = null;
public String _mpsu_type = "";
public anywheresoftware.b4a.objects.ButtonWrapper _btnoff = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnon = null;
public String _mipaddr = "";
public boolean _mrunmasterctrlrstart = false;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.foss.main _main = null;
public sadLogic.OctoTouchController.foss.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.foss.config _config = null;
public sadLogic.OctoTouchController.foss.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.foss.fnc _fnc = null;
public sadLogic.OctoTouchController.foss.gblconst _gblconst = null;
public sadLogic.OctoTouchController.foss.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.foss.logme _logme = null;
public sadLogic.OctoTouchController.foss.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.foss.oc _oc = null;
public sadLogic.OctoTouchController.foss.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.foss.startatboot _startatboot = null;
public sadLogic.OctoTouchController.foss.starter _starter = null;
public sadLogic.OctoTouchController.foss.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.foss.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.foss.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.foss.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.foss.xuiviewsutils _xuiviewsutils = null;
public void  _btnctrl_click() throws Exception{
ResumableSub_btnCtrl_Click rsub = new ResumableSub_btnCtrl_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnCtrl_Click extends BA.ResumableSub {
public ResumableSub_btnCtrl_Click(sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent;
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
String _s = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 111;BA.debugLine="Dim o As B4XView : o = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 111;BA.debugLine="Dim o As B4XView : o = Sender";
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 112;BA.debugLine="guiHelpers.Show_toast(\"Working...\",2800)";
parent._guihelpers._show_toast /*String*/ (ba,"Working...",(int) (2800));
 //BA.debugLineNum = 113;BA.debugLine="Wait For (SendCmd(o.Tag)) Complete(s As String)";
parent.__c.WaitFor("complete", ba, this, parent._sendcmd(BA.ObjectToString(_o.getTag())));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_s = (String) result[0];
;
 //BA.debugLineNum = 114;BA.debugLine="If mRunMasterCtrlrStart = True And o.Tag = \"on\" T";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._mrunmasterctrlrstart==parent.__c.True && (_o.getTag()).equals((Object)("on"))) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 115;BA.debugLine="Main.tmrTimerCallSub.CallSubDelayedPlus(B4XPages";
parent._main._tmrtimercallsub /*sadLogic.OctoTouchController.foss.callsubutils*/ ._callsubdelayedplus /*String*/ ((Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ),"Start",(int) (3000));
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 117;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel) '--- clo";
parent._mdialog._close /*boolean*/ (parent._xui.DialogResponse_Cancel);
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(String _s) throws Exception{
}
public String  _buildgui() throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
 //BA.debugLineNum = 77;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 79;BA.debugLine="pnlMain.Color = clrTheme.Background";
_pnlmain.setColor(_clrtheme._background /*int*/ );
 //BA.debugLineNum = 81;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnOff,btnO";
_guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnoff,_btnon});
 //BA.debugLineNum = 83;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 84;BA.debugLine="cs.Initialize";
_cs.Initialize();
 //BA.debugLineNum = 85;BA.debugLine="btnOff.Text = cs.Typeface(Typeface.FONTAWESOME).V";
_btnoff.setText(BA.ObjectToCharSequence(_cs.Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (3))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf204)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("    Off")).PopAll().getObject()));
 //BA.debugLineNum = 87;BA.debugLine="cs.Initialize";
_cs.Initialize();
 //BA.debugLineNum = 88;BA.debugLine="btnOn.Text  = cs.Typeface(Typeface.FONTAWESOME).V";
_btnon.setText(BA.ObjectToCharSequence(_cs.Typeface(__c.Typeface.getFONTAWESOME()).VerticalAlign(__c.DipToCurrent((int) (3))).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf205)))).Typeface(__c.Typeface.DEFAULT).Append(BA.ObjectToCharSequence("    On")).PopAll().getObject()));
 //BA.debugLineNum = 91;BA.debugLine="guiHelpers.SetTextSize(Array As Button(btnOff,btn";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btnoff,_btnon},(float) ((double)(Double.parseDouble(__c.NumberFormat2(_btnoff.getTextSize()/(double)_guihelpers._gfscale /*float*/ ,(int) (1),(int) (0),(int) (0),__c.False)))-(double)(BA.ObjectToNumber(((_guihelpers._gfscale /*float*/ >1) ? ((Object)(2)) : ((Object)(0)))))));
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgOctoPsuCtrl";
_mmodule = "dlgOctoPsuCtrl";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.foss.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.foss.b4xdialog();
 //BA.debugLineNum = 15;BA.debugLine="Private mPSU_Type As String = \"\"";
_mpsu_type = "";
 //BA.debugLineNum = 17;BA.debugLine="Private btnOff,btnOn As Button";
_btnoff = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnon = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Public mIPaddr As String";
_mipaddr = "";
 //BA.debugLineNum = 19;BA.debugLine="Public mRunMasterCtrlrStart As Boolean = False";
_mrunmasterctrlrstart = __c.False;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 35;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.foss.b4xmainpage _mobj) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize(mobj As B4XMainPage) As Obje";
 //BA.debugLineNum = 27;BA.debugLine="If mobj = Null Then Return Null";
if (_mobj== null) { 
if (true) return __c.Null;};
 //BA.debugLineNum = 28;BA.debugLine="mMainObj = mobj";
_mmainobj = _mobj;
 //BA.debugLineNum = 29;BA.debugLine="ReadSettingsCfg";
_readsettingscfg();
 //BA.debugLineNum = 30;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return null;
}
public String  _readsettingscfg() throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Public Sub ReadSettingsCfg";
 //BA.debugLineNum = 99;BA.debugLine="mIPaddr = Main.kvs.GetDefault(gblConst.PWR_SONOFF";
_mipaddr = BA.ObjectToString(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._getdefault /*Object*/ (_gblconst._pwr_sonoff_ip /*String*/ ,(Object)("")));
 //BA.debugLineNum = 100;BA.debugLine="If Main.kvs.Get(gblConst.PWR_SONOFF_PLUGIN).As(Bo";
if ((BA.ObjectToBoolean(_main._kvs /*sadLogic.OctoTouchController.foss.keyvaluestore*/ ._get /*Object*/ (_gblconst._pwr_sonoff_plugin /*String*/ )))==__c.True) { 
 //BA.debugLineNum = 101;BA.debugLine="mPSU_Type = \"sonoff\"";
_mpsu_type = "sonoff";
 }else {
 //BA.debugLineNum = 103;BA.debugLine="mPSU_Type = \"octo_k\"";
_mpsu_type = "octo_k";
 };
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendcmd(String _cmd) throws Exception{
ResumableSub_SendCmd rsub = new ResumableSub_SendCmd(this,_cmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendCmd extends BA.ResumableSub {
public ResumableSub_SendCmd(sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent,String _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent;
String _cmd;
String _msg = "";
sadLogic.OctoTouchController.foss.httpdownloadstr _sm = null;
String _s = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 124;BA.debugLine="Dim msg As String = $\"Sending Power '${cmd.ToUppe";
_msg = ("Sending Power '"+parent.__c.SmartStringFormatter("",(Object)(_cmd.toUpperCase()))+"' Command");
 //BA.debugLineNum = 125;BA.debugLine="If strHelpers.IsNullOrEmpty(mPSU_Type) Then ReadS";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._strhelpers._isnullorempty /*boolean*/ (ba,parent._mpsu_type)) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._readsettingscfg();
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 127;BA.debugLine="Select Case mPSU_Type";
if (true) break;

case 7:
//select
this.state = 24;
switch (BA.switchObjectToInt(parent._mpsu_type,"sonoff","octo_k")) {
case 0: {
this.state = 9;
if (true) break;
}
case 1: {
this.state = 15;
if (true) break;
}
default: {
this.state = 23;
if (true) break;
}
}
if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 129;BA.debugLine="If mIPaddr = \"\" Then";
if (true) break;

case 10:
//if
this.state = 13;
if ((parent._mipaddr).equals("")) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 130;BA.debugLine="guiHelpers.Show_toast(\"Missing SonOff IP addre";
parent._guihelpers._show_toast /*String*/ (ba,"Missing SonOff IP address",(int) (2000));
 //BA.debugLineNum = 131;BA.debugLine="Return 'ignore";
if (true) {
parent.__c.ReturnFromResumableSub(this,null);return;};
 if (true) break;

case 13:
//C
this.state = 24;
;
 //BA.debugLineNum = 133;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm = new sadLogic.OctoTouchController.foss.httpdownloadstr();
 //BA.debugLineNum = 133;BA.debugLine="Dim sm As HttpDownloadStr : sm.Initialize";
_sm._initialize /*String*/ (ba);
 //BA.debugLineNum = 134;BA.debugLine="Wait For (sm.SendRequest($\"http://${mIPaddr}/cm";
parent.__c.WaitFor("complete", ba, this, _sm._sendrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (("http://"+parent.__c.SmartStringFormatter("",(Object)(parent._mipaddr))+"/cm?cmnd=Power%20"+parent.__c.SmartStringFormatter("",(Object)(_cmd))+"")));
this.state = 32;
return;
case 32:
//C
this.state = 24;
_s = (String) result[0];
;
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 137;BA.debugLine="If oc.isConnected Then";
if (true) break;

case 16:
//if
this.state = 21;
if (parent._oc._isconnected /*boolean*/ ) { 
this.state = 18;
}else {
this.state = 20;
}if (true) break;

case 18:
//C
this.state = 21;
 //BA.debugLineNum = 138;BA.debugLine="mMainObj.oMasterController.cn.PostRequest( _";
parent._mmainobj._omastercontroller /*sadLogic.OctoTouchController.foss.mastercontroller*/ ._getcn /*sadLogic.OctoTouchController.foss.httpoctorestapi*/ ()._postrequest /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._oc._cpsu_control_k /*String*/ .replace("!ONOFF!",BA.ObjectToString((((_cmd.toLowerCase()).equals("on")) ? ((Object)("On")) : ((Object)("Off"))))));
 if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 141;BA.debugLine="guiHelpers.Show_toast2(\"Octoprint not connecte";
parent._guihelpers._show_toast2 /*String*/ (ba,"Octoprint not connected",(int) (2000));
 if (true) break;

case 21:
//C
this.state = 24;
;
 if (true) break;

case 23:
//C
this.state = 24;
 //BA.debugLineNum = 145;BA.debugLine="msg = \"PSU control config problem\"";
_msg = "PSU control config problem";
 if (true) break;
;
 //BA.debugLineNum = 149;BA.debugLine="If cmd.ToLowerCase = \"off\" Then";

case 24:
//if
this.state = 31;
if ((_cmd.toLowerCase()).equals("off")) { 
this.state = 26;
}if (true) break;

case 26:
//C
this.state = 27;
 //BA.debugLineNum = 151;BA.debugLine="If mMainObj.oPageCurrent <> mMainObj.oPageMenu T";
if (true) break;

case 27:
//if
this.state = 30;
if ((parent._mmainobj._opagecurrent /*Object*/ ).equals((Object)(parent._mmainobj._opagemenu /*sadLogic.OctoTouchController.foss.pagemenu*/ )) == false) { 
this.state = 29;
}if (true) break;

case 29:
//C
this.state = 30;
 //BA.debugLineNum = 152;BA.debugLine="CallSub2(mMainObj,\"Switch_Pages\",gblConst.PAGE_";
parent.__c.CallSubNew2(ba,(Object)(parent._mmainobj),"Switch_Pages",(Object)(parent._gblconst._page_menu /*String*/ ));
 if (true) break;

case 30:
//C
this.state = 31;
;
 if (true) break;

case 31:
//C
this.state = -1;
;
 //BA.debugLineNum = 156;BA.debugLine="guiHelpers.Show_toast(msg,2500)";
parent._guihelpers._show_toast /*String*/ (ba,_msg,(int) (2500));
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.foss.dlgoctopsuctrl parent;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _h = 0f;
sadLogic.OctoTouchController.foss.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 41;BA.debugLine="mDialog.Initialize(mMainObj.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 43;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 44;BA.debugLine="Dim h As Float";
_h = 0f;
 //BA.debugLineNum = 45;BA.debugLine="If guiHelpers.gScreenSizeAprox > 7 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gscreensizeaprox /*double*/ >7) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 46;BA.debugLine="h = 280dip";
_h = (float) (parent.__c.DipToCurrent((int) (280)));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 48;BA.debugLine="h = 240dip";
_h = (float) (parent.__c.DipToCurrent((int) (240)));
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 50;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, 260dip,h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),parent.__c.DipToCurrent((int) (260)),(int) (_h));
 //BA.debugLineNum = 51;BA.debugLine="p.LoadLayout(\"viewPsuCtrl\")";
_p.LoadLayout("viewPsuCtrl",ba);
 //BA.debugLineNum = 53;BA.debugLine="BuildGUI";
parent._buildgui();
 //BA.debugLineNum = 56;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.foss.sadb4xdialoghelper();
 //BA.debugLineNum = 57;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 58;BA.debugLine="dlgHelper.ThemeDialogForm(\"Power Control\")";
_dlghelper._themedialogform /*String*/ ((Object)("Power Control"));
 //BA.debugLineNum = 59;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 60;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 62;BA.debugLine="If oc.Tool1ActualReal > 50 Then";
if (true) break;

case 7:
//if
this.state = 10;
if (parent._oc._tool1actualreal /*float*/ >50) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 63;BA.debugLine="CallSubDelayed3(B4XPages.MainPage,\"Show_Toast\",";
parent.__c.CallSubDelayed3(ba,(Object)(parent._b4xpages._mainpage /*sadLogic.OctoTouchController.foss.b4xmainpage*/ (ba)),"Show_Toast",(Object)("Warning! Tool Temperature Is Hot"),(Object)(4300));
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 66;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 11;
return;
case 11:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 67;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 71;BA.debugLine="mMainObj.pObjCurrentDlg1 = Null";
parent._mmainobj._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
