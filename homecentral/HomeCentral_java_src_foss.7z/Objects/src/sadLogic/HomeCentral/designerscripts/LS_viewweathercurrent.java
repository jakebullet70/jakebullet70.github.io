package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewweathercurrent{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlcurrentquickinfo").vw.setLeft((int)(0d));
views.get("pnlcurrentquickinfo").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lblcurrenthigh").vw.setLeft((int)(0d));
views.get("lblcurrenthigh").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lblcurrdesc").vw.setLeft((int)(0d));
views.get("lblcurrdesc").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lbllocation").vw.setLeft((int)(0d));
views.get("lbllocation").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lblcurrtxt").vw.setLeft((int)(0d));
views.get("lblcurrtxt").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lblcurrtxt").vw.setTop((int)((views.get("pnlcurrentquickinfo").vw.getTop() + views.get("pnlcurrentquickinfo").vw.getHeight())));
views.get("lblcurrtxt").vw.setHeight((int)((100d / 100 * height) - ((views.get("pnlcurrentquickinfo").vw.getTop() + views.get("pnlcurrentquickinfo").vw.getHeight()))));
views.get("lblfeelslike").vw.setTop((int)((views.get("lblcurrdesc").vw.getTop()) - (views.get("lblfeelslike").vw.getHeight())));
views.get("lblfeelslike").vw.setLeft((int)((views.get("btncurrtemp").vw.getLeft())));
views.get("lblfeelslike").vw.setWidth((int)((views.get("btncurrtemp").vw.getLeft() + views.get("btncurrtemp").vw.getWidth()) - ((views.get("btncurrtemp").vw.getLeft()))));

}
}