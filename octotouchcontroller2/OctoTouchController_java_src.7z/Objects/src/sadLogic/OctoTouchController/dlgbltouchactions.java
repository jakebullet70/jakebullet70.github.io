package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgbltouchactions extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgbltouchactions");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgbltouchactions.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmain = null;
public sadLogic.OctoTouchController.b4xdialog _mdialog = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnup = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnselfttest = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsave = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnralarm = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndn = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpbed = null;
public anywheresoftware.b4a.objects.collections.Map _mapfile = null;
public String _gcode = "";
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public String  _btnctrl_click() throws Exception{
anywheresoftware.b4a.objects.ButtonWrapper _b = null;
 //BA.debugLineNum = 72;BA.debugLine="Private Sub btnCtrl_Click";
 //BA.debugLineNum = 74;BA.debugLine="Dim b As Button : b = Sender";
_b = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 74;BA.debugLine="Dim b As Button : b = Sender";
_b = (anywheresoftware.b4a.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ButtonWrapper(), (android.widget.Button)(__c.Sender(ba)));
 //BA.debugLineNum = 76;BA.debugLine="Select Case b.tag";
switch (BA.switchObjectToInt(_b.getTag(),(Object)("up"),(Object)("dn"),(Object)("st"),(Object)("ra"),(Object)("pb"),(Object)("sv"))) {
case 0: {
 //BA.debugLineNum = 77;BA.debugLine="Case \"up\" : gcode = mapFile.Get(gblConst.probeUP";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._probeup /*String*/ )));
 break; }
case 1: {
 //BA.debugLineNum = 78;BA.debugLine="Case \"dn\" : gcode = mapFile.Get(gblConst.probeDN";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._probedn /*String*/ )));
 break; }
case 2: {
 //BA.debugLineNum = 79;BA.debugLine="Case \"st\" : gcode = mapFile.Get(gblConst.probeTe";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._probetest /*String*/ )));
 break; }
case 3: {
 //BA.debugLineNum = 80;BA.debugLine="Case \"ra\" : gcode = mapFile.Get(gblConst.probeRe";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._proberelalarm /*String*/ )));
 break; }
case 4: {
 //BA.debugLineNum = 81;BA.debugLine="Case \"pb\" : gcode = mapFile.Get(gblConst.probeBe";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._probebed /*String*/ )));
 break; }
case 5: {
 //BA.debugLineNum = 82;BA.debugLine="Case \"sv\" : gcode = mapFile.Get(gblConst.probeSa";
_gcode = BA.ObjectToString(_mapfile.Get((Object)(_gblconst._probesave /*String*/ )));
 break; }
}
;
 //BA.debugLineNum = 86;BA.debugLine="CallSubDelayed2(B4XPages.MainPage,\"Send_Gcode\",gc";
__c.CallSubDelayed2(ba,(Object)(_b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)),"Send_Gcode",(Object)(_gcode));
 //BA.debugLineNum = 87;BA.debugLine="guiHelpers.Show_toast(\"Command sent\",1200)";
_guihelpers._show_toast /*String*/ (ba,"Command sent",(int) (1200));
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgBLTouchActi";
_mmodule = "dlgBLTouchActions";
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private pnlMain As Panel";
_pnlmain = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private mDialog As B4XDialog";
_mdialog = new sadLogic.OctoTouchController.b4xdialog();
 //BA.debugLineNum = 14;BA.debugLine="Private btnUp,btnSelftTest,btnSave,btnrAlarm,btnD";
_btnup = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnselfttest = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnsave = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnralarm = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndn = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpbed = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private mapFile As Map, gcode As String";
_mapfile = new anywheresoftware.b4a.objects.collections.Map();
_gcode = "";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _close_me() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Close_Me";
 //BA.debugLineNum = 24;BA.debugLine="mDialog.Close(xui.DialogResponse_Cancel)";
_mdialog._close /*boolean*/ (_xui.DialogResponse_Cancel);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize() As Object";
 //BA.debugLineNum = 19;BA.debugLine="mapFile = File.ReadMap(xui.DefaultFolder,gblConst";
_mapfile = __c.File.ReadMap(_xui.getDefaultFolder(),_gblconst._blcr_touch_file /*String*/ );
 //BA.debugLineNum = 20;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgbltouchactions parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgbltouchactions parent;
sadLogic.OctoTouchController.sadb4xdialoghelper _dlghelper = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _w = 0f;
float _h = 0f;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 30;BA.debugLine="mDialog.Initialize(B4XPages.MainPage.Root)";
parent._mdialog._initialize /*String*/ (ba,parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ );
 //BA.debugLineNum = 31;BA.debugLine="Dim dlgHelper As sadB4XDialogHelper";
_dlghelper = new sadLogic.OctoTouchController.sadb4xdialoghelper();
 //BA.debugLineNum = 32;BA.debugLine="dlgHelper.Initialize(mDialog)";
_dlghelper._initialize /*String*/ (ba,parent._mdialog);
 //BA.debugLineNum = 34;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._xui.CreatePanel(ba,"");
 //BA.debugLineNum = 36;BA.debugLine="Log(guiHelpers.gScreenSizeAprox)";
parent.__c.LogImpl("16187400",BA.NumberToString(parent._guihelpers._gscreensizeaprox /*double*/ ),0);
 //BA.debugLineNum = 38;BA.debugLine="Dim w,h As Float";
_w = 0f;
_h = 0f;
 //BA.debugLineNum = 39;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 40;BA.debugLine="w = IIf(guiHelpers.gScreenSizeAprox < 6,460dip,6";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <6) ? ((Object)(parent.__c.DipToCurrent((int) (460)))) : ((Object)(parent.__c.DipToCurrent((int) (640)))))));
 //BA.debugLineNum = 41;BA.debugLine="h = IIf(guiHelpers.gScreenSizeAprox < 4.6,guiHel";
_h = (float)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <4.6) ? ((Object)(parent._guihelpers._gheight /*float*/ *.7)) : ((Object)(parent.__c.DipToCurrent((int) (290)))))));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 43;BA.debugLine="w = IIf(guiHelpers.gScreenSizeAprox < 6,guiHelp";
_w = (float)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ <6) ? ((Object)(parent._guihelpers._gwidth /*float*/ -parent.__c.DipToCurrent((int) (40)))) : ((Object)(parent.__c.DipToCurrent((int) (520)))))));
 //BA.debugLineNum = 44;BA.debugLine="h = 310dip";
_h = (float) (parent.__c.DipToCurrent((int) (310)));
 if (true) break;
;
 //BA.debugLineNum = 46;BA.debugLine="If guiHelpers.gScreenSizeAprox > 8 Then '-- table";

case 6:
//if
this.state = 9;
if (parent._guihelpers._gscreensizeaprox /*double*/ >8) { 
this.state = 8;
}if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 47;BA.debugLine="h = 370dip";
_h = (float) (parent.__c.DipToCurrent((int) (370)));
 if (true) break;

case 9:
//C
this.state = -1;
;
 //BA.debugLineNum = 51;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, w,h)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),(int) (_w),(int) (_h));
 //BA.debugLineNum = 52;BA.debugLine="p.LoadLayout(\"dlgBLCRtouch\")";
_p.LoadLayout("dlgBLCRtouch",ba);
 //BA.debugLineNum = 53;BA.debugLine="pnlMain.Color = clrTheme.Background";
parent._pnlmain.setColor(parent._clrtheme._background /*int*/ );
 //BA.debugLineNum = 54;BA.debugLine="guiHelpers.SkinButton(Array As Button(btnDn,btnPB";
parent._guihelpers._skinbutton /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{parent._btndn,parent._btnpbed,parent._btnralarm,parent._btnsave,parent._btnselfttest,parent._btnup});
 //BA.debugLineNum = 57;BA.debugLine="dlgHelper.ThemeDialogForm(\"BL/CR Touch Menu\")";
_dlghelper._themedialogform /*String*/ ((Object)("BL/CR Touch Menu"));
 //BA.debugLineNum = 58;BA.debugLine="Dim rs As ResumableSub = mDialog.ShowCustom(p, \"\"";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = parent._mdialog._showcustom /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_p,(Object)(""),(Object)(""),(Object)("CLOSE"));
 //BA.debugLineNum = 59;BA.debugLine="dlgHelper.ThemeInputDialogBtnsResize";
_dlghelper._themeinputdialogbtnsresize /*String*/ ();
 //BA.debugLineNum = 61;BA.debugLine="Wait For (rs) Complete (Result As Int)";
parent.__c.WaitFor("complete", ba, this, _rs);
this.state = 10;
return;
case 10:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 63;BA.debugLine="CallSubDelayed2(Main,\"Dim_ActionBar\",gblConst.ACT";
parent.__c.CallSubDelayed2(ba,(Object)(parent._main.getObject()),"Dim_ActionBar",(Object)(parent._gblconst._actionbar_off /*int*/ ));
 //BA.debugLineNum = 64;BA.debugLine="B4XPages.MainPage.pObjCurrentDlg1 = Null";
parent._b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba)._pobjcurrentdlg1 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "CLOSE_ME"))
	return _close_me();
return BA.SubDelegator.SubNotFound;
}
}
