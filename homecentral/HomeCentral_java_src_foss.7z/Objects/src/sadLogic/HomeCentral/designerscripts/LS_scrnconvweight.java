package sadLogic.HomeCentral.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_scrnconvweight{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _items="";
String _lblsize="";
String _txtsize="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlweight").vw.setLeft((int)(0d));
views.get("pnlweight").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlweight").vw.setTop((int)(0d));
views.get("pnlweight").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlweightf").vw.setLeft((int)((views.get("pnlweight").vw.getLeft())+(60d * scale)));
views.get("pnlweightf").vw.setWidth((int)((views.get("pnlweight").vw.getLeft() + views.get("pnlweight").vw.getWidth())-(60d * scale) - ((views.get("pnlweight").vw.getLeft())+(60d * scale))));
views.get("pnlweightf").vw.setTop((int)((views.get("pnlweight").vw.getTop())+(50d * scale)));
views.get("pnlweightf").vw.setHeight((int)((views.get("pnlweight").vw.getTop() + views.get("pnlweight").vw.getHeight())-(20d * scale) - ((views.get("pnlweight").vw.getTop())+(50d * scale))));
_items = BA.NumberToString((views.get("pnlweightf").vw.getHeight())/4d);
_lblsize = BA.NumberToString(Double.parseDouble(_items)*.40d);
_txtsize = BA.NumberToString(Double.parseDouble(_items)*.60d);
views.get("lbloz").vw.setLeft((int)(0d));
views.get("lbloz").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("lbloz").vw.setTop((int)(0d));
views.get("lbloz").vw.setHeight((int)(Double.parseDouble(_lblsize) - (0d)));
views.get("txtoz").vw.setLeft((int)(0d));
views.get("txtoz").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("txtoz").vw.setTop((int)((views.get("lbloz").vw.getTop() + views.get("lbloz").vw.getHeight())));
views.get("txtoz").vw.setHeight((int)(Double.parseDouble(_lblsize)+Double.parseDouble(_txtsize) - ((views.get("lbloz").vw.getTop() + views.get("lbloz").vw.getHeight()))));
views.get("lblpounds").vw.setLeft((int)(0d));
views.get("lblpounds").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("lblpounds").vw.setTop((int)((views.get("txtoz").vw.getTop() + views.get("txtoz").vw.getHeight())));
views.get("lblpounds").vw.setHeight((int)((views.get("txtoz").vw.getTop() + views.get("txtoz").vw.getHeight())+Double.parseDouble(_lblsize) - ((views.get("txtoz").vw.getTop() + views.get("txtoz").vw.getHeight()))));
views.get("txtpounds").vw.setLeft((int)(0d));
views.get("txtpounds").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("txtpounds").vw.setTop((int)((views.get("lblpounds").vw.getTop() + views.get("lblpounds").vw.getHeight())));
views.get("txtpounds").vw.setHeight((int)((Double.parseDouble(_lblsize)*2d)+(Double.parseDouble(_txtsize)*2d) - ((views.get("lblpounds").vw.getTop() + views.get("lblpounds").vw.getHeight()))));
views.get("lblgrams").vw.setLeft((int)(0d));
views.get("lblgrams").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("lblgrams").vw.setTop((int)((views.get("txtpounds").vw.getTop() + views.get("txtpounds").vw.getHeight())));
views.get("lblgrams").vw.setHeight((int)((views.get("txtpounds").vw.getTop() + views.get("txtpounds").vw.getHeight())+Double.parseDouble(_lblsize) - ((views.get("txtpounds").vw.getTop() + views.get("txtpounds").vw.getHeight()))));
views.get("txtgrams").vw.setLeft((int)(0d));
views.get("txtgrams").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("txtgrams").vw.setTop((int)((views.get("lblgrams").vw.getTop() + views.get("lblgrams").vw.getHeight())));
views.get("txtgrams").vw.setHeight((int)((Double.parseDouble(_lblsize)*3d)+(Double.parseDouble(_txtsize)*3d) - ((views.get("lblgrams").vw.getTop() + views.get("lblgrams").vw.getHeight()))));
views.get("lblkg").vw.setLeft((int)(0d));
views.get("lblkg").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("lblkg").vw.setTop((int)((views.get("txtgrams").vw.getTop() + views.get("txtgrams").vw.getHeight())));
views.get("lblkg").vw.setHeight((int)((views.get("txtgrams").vw.getTop() + views.get("txtgrams").vw.getHeight())+Double.parseDouble(_lblsize) - ((views.get("txtgrams").vw.getTop() + views.get("txtgrams").vw.getHeight()))));
views.get("txtkg").vw.setLeft((int)(0d));
views.get("txtkg").vw.setWidth((int)((views.get("pnlweightf").vw.getWidth()) - (0d)));
views.get("txtkg").vw.setTop((int)((views.get("lblkg").vw.getTop() + views.get("lblkg").vw.getHeight())));
views.get("txtkg").vw.setHeight((int)((Double.parseDouble(_lblsize)*4d)+(Double.parseDouble(_txtsize)*4d) - ((views.get("lblkg").vw.getTop() + views.get("lblkg").vw.getHeight()))));

}
}