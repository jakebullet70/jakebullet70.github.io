package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pagektimers extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.pagektimers");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.pagektimers.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public sadLogic.HomeCentral.b4xmainpage _mpage = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlmain = null;
public sadLogic.HomeCentral.kitchentmrs _clsktimers = null;
public String _msalarmfirerollover = "";
public anywheresoftware.b4a.objects.Timer _mtmralarmfire = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbllisthdr = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimersdesc1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimersdesc2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimersdesc3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimersdesc4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimersdesc5 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimerstime1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimerstime2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimerstime3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimerstime4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbltimerstime5 = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgtimers5 = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgtimers4 = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgtimers3 = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgtimers2 = null;
public sadLogic.HomeCentral.lmb4ximageviewx _imgtimers1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtnsbottom = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtnstop = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnllcd = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblsec = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblmin = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblhrs = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldots1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldots2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbtnsmenu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplittermnu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlhrsminsecslbl = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbllabelsec = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbllabelmin = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbllabelhr = null;
public anywheresoftware.b4a.keywords.constants.TypefaceWrapper _timerfont = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitter4 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrs5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrs1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrm5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrm1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrh5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndecrh1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincs5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincs1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincrh5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincrh1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincm5 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnincm1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnreset = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnpause = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplittertopbtn2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitterbottombtn1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplittertopbtn1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlsplitterbottombtn2 = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _adjusttime(b4a.example.dateutils._period _per) throws Exception{
 //BA.debugLineNum = 459;BA.debugLine="Private Sub AdjustTime(per As Period)";
 //BA.debugLineNum = 461;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).endTim";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].endTime /*long*/  = _dateutils._addperiod(ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].endTime /*long*/ ,_per);
 //BA.debugLineNum = 463;BA.debugLine="End Sub";
return "";
}
public String  _alarmstart(int _xx) throws Exception{
 //BA.debugLineNum = 465;BA.debugLine="Public Sub AlarmStart(xx As Int)";
 //BA.debugLineNum = 466;BA.debugLine="Log(\"-----------------------------PageKTimers ---";
__c.LogImpl("43450369","-----------------------------PageKTimers ---> AlarmStart-"+BA.NumberToString(_xx),0);
 //BA.debugLineNum = 467;BA.debugLine="TimerSelect(xx)";
_timerselect(_xx);
 //BA.debugLineNum = 469;BA.debugLine="clsKTimers.timers(xx).Firing = True";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_xx].Firing /*boolean*/  = __c.True;
 //BA.debugLineNum = 470;BA.debugLine="clsKTimers.moAlarm(xx).Initialize(clsKTimers.time";
_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_xx]._initialize /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ );
 //BA.debugLineNum = 471;BA.debugLine="clsKTimers.moAlarm(xx).AlarmStart(xx)";
_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_xx]._alarmstart /*String*/ (_xx);
 //BA.debugLineNum = 473;BA.debugLine="msAlarmFireRollover = gblConst.TIMERS_IMG_STOP";
_msalarmfirerollover = _gblconst._timers_img_stop /*String*/ ;
 //BA.debugLineNum = 474;BA.debugLine="mTmrAlarmFire.Enabled = True";
_mtmralarmfire.setEnabled(__c.True);
 //BA.debugLineNum = 477;BA.debugLine="If mpage.oPageCurrent <> mpage.oPageTimers Then";
if ((_mpage._opagecurrent /*Object*/ ).equals((Object)(_mpage._opagetimers /*sadLogic.HomeCentral.pagektimers*/ )) == false) { 
 //BA.debugLineNum = 478;BA.debugLine="CallSubDelayed2(mpage,\"Change_Pages2\",\"tm\") '---";
__c.CallSubDelayed2(ba,(Object)(_mpage),"Change_Pages2",(Object)("tm"));
 };
 //BA.debugLineNum = 481;BA.debugLine="UpdateListOfTimers(xx)";
_updatelistoftimers(_xx);
 //BA.debugLineNum = 482;BA.debugLine="CallSubDelayed(Me,\"ClearLarge_TimerTxt\")";
__c.CallSubDelayed(ba,this,"ClearLarge_TimerTxt");
 //BA.debugLineNum = 485;BA.debugLine="End Sub";
return "";
}
public String  _btndecr_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
String _txt = "";
int _i = 0;
b4a.example.dateutils._period _per = null;
 //BA.debugLineNum = 334;BA.debugLine="Private Sub btnDecr_Click";
 //BA.debugLineNum = 335;BA.debugLine="Dim o As B4XView = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 336;BA.debugLine="Dim txt As String = o.text";
_txt = _o.getText();
 //BA.debugLineNum = 337;BA.debugLine="Dim I As Int,  per As Period";
_i = 0;
_per = new b4a.example.dateutils._period();
 //BA.debugLineNum = 338;BA.debugLine="Select Case o.tag";
switch (BA.switchObjectToInt(_o.getTag(),(Object)("s"),(Object)("m"),(Object)("h"))) {
case 0: {
 //BA.debugLineNum = 340;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 341;BA.debugLine="I = kt.xStr2Int(lblSec.Text) - 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblsec.getText())-5);
 //BA.debugLineNum = 342;BA.debugLine="If I <= 0 Then";
if (_i<=0) { 
 //BA.debugLineNum = 343;BA.debugLine="lblSec.Text = \"00\" : Return";
_lblsec.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 343;BA.debugLine="lblSec.Text = \"00\" : Return";
if (true) return "";
 }else {
 //BA.debugLineNum = 345;BA.debugLine="lblSec.Text = kt.xIntsStr(I)";
_lblsec.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 346;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 347;BA.debugLine="per.Seconds = -5 : 	AdjustTime(per)";
_per.Seconds = (int) (-5);
 //BA.debugLineNum = 347;BA.debugLine="per.Seconds = -5 : 	AdjustTime(per)";
_adjusttime(_per);
 };
 };
 }else {
 //BA.debugLineNum = 351;BA.debugLine="I = kt.xStr2Int(lblSec.Text) - 1";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblsec.getText())-1);
 //BA.debugLineNum = 352;BA.debugLine="If I <= 0 Then";
if (_i<=0) { 
 //BA.debugLineNum = 353;BA.debugLine="lblSec.Text = \"00\" : Return";
_lblsec.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 353;BA.debugLine="lblSec.Text = \"00\" : Return";
if (true) return "";
 }else {
 //BA.debugLineNum = 355;BA.debugLine="lblSec.Text = kt.xIntsStr(I)";
_lblsec.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 356;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 357;BA.debugLine="per.Seconds = -1 : AdjustTime(per)";
_per.Seconds = (int) (-1);
 //BA.debugLineNum = 357;BA.debugLine="per.Seconds = -1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 };
 break; }
case 1: {
 //BA.debugLineNum = 363;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 364;BA.debugLine="i = kt.xStr2Int(lblMin.Text) - 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblmin.getText())-5);
 //BA.debugLineNum = 365;BA.debugLine="If i <= 0 Then";
if (_i<=0) { 
 //BA.debugLineNum = 366;BA.debugLine="lblMin.Text = \"00\"";
_lblmin.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 367;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 368;BA.debugLine="per.Minutes = kt.returnNegNum(5 - Abs(i)) :";
_per.Minutes = _kt._returnnegnum /*int*/ (ba,(int) (5-__c.Abs(_i)));
 //BA.debugLineNum = 368;BA.debugLine="per.Minutes = kt.returnNegNum(5 - Abs(i)) :";
_adjusttime(_per);
 };
 }else {
 //BA.debugLineNum = 371;BA.debugLine="lblMin.Text = kt.xIntsStr(i)";
_lblmin.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 372;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 373;BA.debugLine="per.Minutes = -5 : AdjustTime(per)";
_per.Minutes = (int) (-5);
 //BA.debugLineNum = 373;BA.debugLine="per.Minutes = -5 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 }else {
 //BA.debugLineNum = 377;BA.debugLine="i = kt.xStr2Int(lblMin.Text) - 1 '--- 1 has be";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblmin.getText())-1);
 //BA.debugLineNum = 378;BA.debugLine="If i < 0 Then";
if (_i<0) { 
 //BA.debugLineNum = 379;BA.debugLine="lblMin.Text = \"00\"";
_lblmin.setText(BA.ObjectToCharSequence("00"));
 }else {
 //BA.debugLineNum = 381;BA.debugLine="lblMin.Text = kt.xIntsStr(i)";
_lblmin.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 382;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 383;BA.debugLine="per.Minutes = -1 : AdjustTime(per)";
_per.Minutes = (int) (-1);
 //BA.debugLineNum = 383;BA.debugLine="per.Minutes = -1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 };
 break; }
case 2: {
 //BA.debugLineNum = 389;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 390;BA.debugLine="I = kt.xStr2Int(lblHrs.Text) - 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblhrs.getText())-5);
 //BA.debugLineNum = 391;BA.debugLine="If I <= 0 Then";
if (_i<=0) { 
 //BA.debugLineNum = 392;BA.debugLine="lblHrs.Text = \"00\"";
_lblhrs.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 393;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 394;BA.debugLine="per.Hours = kt.returnNegNum(5 - Abs(I)) : Ad";
_per.Hours = _kt._returnnegnum /*int*/ (ba,(int) (5-__c.Abs(_i)));
 //BA.debugLineNum = 394;BA.debugLine="per.Hours = kt.returnNegNum(5 - Abs(I)) : Ad";
_adjusttime(_per);
 };
 }else {
 //BA.debugLineNum = 397;BA.debugLine="lblHrs.Text = kt.xIntsStr(I)";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 398;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 399;BA.debugLine="per.Hours = -5 : AdjustTime(per)";
_per.Hours = (int) (-5);
 //BA.debugLineNum = 399;BA.debugLine="per.Hours = -5 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 }else {
 //BA.debugLineNum = 403;BA.debugLine="I = kt.xStr2Int(lblHrs.Text) - 1 '--- 1 has be";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblhrs.getText())-1);
 //BA.debugLineNum = 404;BA.debugLine="If I < 0 Then";
if (_i<0) { 
 //BA.debugLineNum = 405;BA.debugLine="lblHrs.Text = \"00\"";
_lblhrs.setText(BA.ObjectToCharSequence("00"));
 }else {
 //BA.debugLineNum = 407;BA.debugLine="lblHrs.Text = kt.xIntsStr(I)";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 408;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer)";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 409;BA.debugLine="per.Hours = -1 : AdjustTime(per)";
_per.Hours = (int) (-1);
 //BA.debugLineNum = 409;BA.debugLine="per.Hours = -1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 };
 break; }
}
;
 //BA.debugLineNum = 415;BA.debugLine="End Sub";
return "";
}
public String  _btnincr_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
String _txt = "";
int _i = 0;
b4a.example.dateutils._period _per = null;
 //BA.debugLineNum = 274;BA.debugLine="Private Sub btnIncr_Click";
 //BA.debugLineNum = 275;BA.debugLine="Dim o As B4XView = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 276;BA.debugLine="Dim txt As String = o.text";
_txt = _o.getText();
 //BA.debugLineNum = 277;BA.debugLine="Dim I As Int,  per As Period";
_i = 0;
_per = new b4a.example.dateutils._period();
 //BA.debugLineNum = 278;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 279;BA.debugLine="Select Case o.tag";
switch (BA.switchObjectToInt(_o.getTag(),(Object)("s"),(Object)("m"),(Object)("h"))) {
case 0: {
 //BA.debugLineNum = 281;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 282;BA.debugLine="I = kt.xStr2Int(lblSec.Text) + 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblsec.getText())+5);
 //BA.debugLineNum = 283;BA.debugLine="If I > 59 Then Return";
if (_i>59) { 
if (true) return "";};
 //BA.debugLineNum = 284;BA.debugLine="lblSec.Text = kt.xIntsStr(I)";
_lblsec.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 285;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 286;BA.debugLine="per.Seconds = 5 : AdjustTime(per)";
_per.Seconds = (int) (5);
 //BA.debugLineNum = 286;BA.debugLine="per.Seconds = 5 : AdjustTime(per)";
_adjusttime(_per);
 };
 }else {
 //BA.debugLineNum = 289;BA.debugLine="I = kt.xStr2Int(lblSec.Text) + 1";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblsec.getText())+1);
 //BA.debugLineNum = 290;BA.debugLine="If I > 59 Then Return";
if (_i>59) { 
if (true) return "";};
 //BA.debugLineNum = 291;BA.debugLine="lblSec.Text = kt.xIntsStr(I)";
_lblsec.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 292;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 293;BA.debugLine="per.Seconds = 1 : AdjustTime(per)";
_per.Seconds = (int) (1);
 //BA.debugLineNum = 293;BA.debugLine="per.Seconds = 1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 break; }
case 1: {
 //BA.debugLineNum = 298;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 299;BA.debugLine="I = kt.xStr2Int(lblMin.Text) + 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblmin.getText())+5);
 //BA.debugLineNum = 300;BA.debugLine="If I > 59 Then Return";
if (_i>59) { 
if (true) return "";};
 //BA.debugLineNum = 301;BA.debugLine="lblMin.Text = kt.xIntsStr(I)";
_lblmin.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 302;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 303;BA.debugLine="per.Minutes = 5 : AdjustTime(per)";
_per.Minutes = (int) (5);
 //BA.debugLineNum = 303;BA.debugLine="per.Minutes = 5 : AdjustTime(per)";
_adjusttime(_per);
 };
 }else {
 //BA.debugLineNum = 306;BA.debugLine="I = kt.xStr2Int(lblMin.Text) + 1";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblmin.getText())+1);
 //BA.debugLineNum = 307;BA.debugLine="If I > 59 Then Return";
if (_i>59) { 
if (true) return "";};
 //BA.debugLineNum = 308;BA.debugLine="lblMin.Text = kt.xIntsStr(I)";
_lblmin.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 309;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 310;BA.debugLine="per.Minutes = 1 : AdjustTime(per)";
_per.Minutes = (int) (1);
 //BA.debugLineNum = 310;BA.debugLine="per.Minutes = 1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 break; }
case 2: {
 //BA.debugLineNum = 315;BA.debugLine="If txt.Contains(\"5\") Then '--- 5 has been press";
if (_txt.contains("5")) { 
 //BA.debugLineNum = 316;BA.debugLine="I = kt.xStr2Int(lblHrs.Text) + 5";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblhrs.getText())+5);
 //BA.debugLineNum = 317;BA.debugLine="If I > 23 Then Return";
if (_i>23) { 
if (true) return "";};
 //BA.debugLineNum = 318;BA.debugLine="lblHrs.Text = kt.xIntsStr(I)";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 319;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 320;BA.debugLine="per.Hours = 5 : AdjustTime(per)";
_per.Hours = (int) (5);
 //BA.debugLineNum = 320;BA.debugLine="per.Hours = 5 : AdjustTime(per)";
_adjusttime(_per);
 };
 }else {
 //BA.debugLineNum = 323;BA.debugLine="I = kt.xStr2Int(lblHrs.Text) + 1";
_i = (int) (_kt._xstr2int /*int*/ (ba,_lblhrs.getText())+1);
 //BA.debugLineNum = 324;BA.debugLine="If I > 23 Then Return";
if (_i>23) { 
if (true) return "";};
 //BA.debugLineNum = 325;BA.debugLine="lblHrs.Text = kt.xIntsStr(I)";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._xintsstr /*String*/ (ba,_i)));
 //BA.debugLineNum = 326;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/ ) { 
 //BA.debugLineNum = 327;BA.debugLine="per.Hours = 1 : AdjustTime(per)";
_per.Hours = (int) (1);
 //BA.debugLineNum = 327;BA.debugLine="per.Hours = 1 : AdjustTime(per)";
_adjusttime(_per);
 };
 };
 break; }
}
;
 //BA.debugLineNum = 332;BA.debugLine="End Sub";
return "";
}
public String  _btnresetpause_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _o = null;
 //BA.debugLineNum = 177;BA.debugLine="Private Sub btnResetPause_Click";
 //BA.debugLineNum = 178;BA.debugLine="Dim o As B4XView = Sender";
_o = new anywheresoftware.b4a.objects.B4XViewWrapper();
_o = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba)));
 //BA.debugLineNum = 180;BA.debugLine="Select Case  o.Text";
switch (BA.switchObjectToInt(_o.getText(),"Reset","Start","Pause")) {
case 0: {
 //BA.debugLineNum = 182;BA.debugLine="If clsKTimers.moAlarm(clsKTimers.CurrentTimer).";
if (_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_clsktimers._currenttimer /*int*/ ]._mbactive /*boolean*/ ) { 
 //BA.debugLineNum = 184;BA.debugLine="TimerSelect(clsKTimers.CurrentTimer)";
_timerselect(_clsktimers._currenttimer /*int*/ );
 };
 //BA.debugLineNum = 186;BA.debugLine="kt.Clear_Timer(clsKTimers.CurrentTimer)";
_kt._clear_timer /*String*/ (ba,_clsktimers._currenttimer /*int*/ );
 //BA.debugLineNum = 189;BA.debugLine="ClearLarge_TimerTxt";
_clearlarge_timertxt();
 //BA.debugLineNum = 190;BA.debugLine="Update_ListOfTimersIMG(clsKTimers.CurrentTimer,";
_update_listoftimersimg(_clsktimers._currenttimer /*int*/ ,_gblconst._timers_img_stop /*String*/ );
 //BA.debugLineNum = 191;BA.debugLine="UpdateListOfTimers(clsKTimers.CurrentTimer)";
_updatelistoftimers(_clsktimers._currenttimer /*int*/ );
 //BA.debugLineNum = 193;BA.debugLine="UpdateListOfTimersDesc(clsKTimers.CurrentTimer,";
_updatelistoftimersdesc(_clsktimers._currenttimer /*int*/ ,"Open");
 break; }
case 1: {
 //BA.debugLineNum = 196;BA.debugLine="If clsKTimers.timers(clsKTimers.CurrentTimer).p";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].paused /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 197;BA.debugLine="If IsTimerBlank Then";
if (_istimerblank()) { 
 //BA.debugLineNum = 198;BA.debugLine="guiHelpers.Show_toast(\"Cannot start timer. Ti";
_guihelpers._show_toast /*String*/ (ba,"Cannot start timer. Timer is blank");
 //BA.debugLineNum = 199;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 201;BA.debugLine="StartTimer(\"Open\")";
_starttimer("Open");
 }else {
 //BA.debugLineNum = 204;BA.debugLine="StartTimer(\"\") '--- restarts the timer";
_starttimer("");
 };
 break; }
case 2: {
 //BA.debugLineNum = 208;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).acti";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/  = __c.False;
 //BA.debugLineNum = 209;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).paus";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].paused /*boolean*/  = __c.True;
 //BA.debugLineNum = 210;BA.debugLine="Update_ListOfTimersIMG(clsKTimers.CurrentTimer,";
_update_listoftimersimg(_clsktimers._currenttimer /*int*/ ,_gblconst._timers_img_pause /*String*/ );
 //BA.debugLineNum = 211;BA.debugLine="btnPause.Text = \"Start\"";
_btnpause.setText(BA.ObjectToCharSequence("Start"));
 break; }
}
;
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public String  _build_side_menu() throws Exception{
 //BA.debugLineNum = 519;BA.debugLine="Private Sub Build_Side_Menu";
 //BA.debugLineNum = 520;BA.debugLine="Menus.BuildSideMenu(Array As String(\"Presets\"),Ar";
_menus._buildsidemenu /*String*/ (ba,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Presets"}),anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"pr"}));
 //BA.debugLineNum = 521;BA.debugLine="End Sub";
return "";
}
public String  _buildgui() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Private Sub BuildGUI";
 //BA.debugLineNum = 62;BA.debugLine="TimerFont = Typeface.LoadFromAssets(\"Digital.ttf\"";
_timerfont = (anywheresoftware.b4a.keywords.constants.TypefaceWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.constants.TypefaceWrapper(), (android.graphics.Typeface)(__c.Typeface.LoadFromAssets("Digital.ttf")));
 //BA.debugLineNum = 63;BA.debugLine="lblHrs.Typeface = TimerFont :lblMin.Typeface = Ti";
_lblhrs.setTypeface((android.graphics.Typeface)(_timerfont.getObject()));
 //BA.debugLineNum = 63;BA.debugLine="lblHrs.Typeface = TimerFont :lblMin.Typeface = Ti";
_lblmin.setTypeface((android.graphics.Typeface)(_timerfont.getObject()));
 //BA.debugLineNum = 63;BA.debugLine="lblHrs.Typeface = TimerFont :lblMin.Typeface = Ti";
_lblsec.setTypeface((android.graphics.Typeface)(_timerfont.getObject()));
 //BA.debugLineNum = 64;BA.debugLine="lblDots1.Typeface = TimerFont:lblDots2.Typeface =";
_lbldots1.setTypeface((android.graphics.Typeface)(_timerfont.getObject()));
 //BA.debugLineNum = 64;BA.debugLine="lblDots1.Typeface = TimerFont:lblDots2.Typeface =";
_lbldots2.setTypeface((android.graphics.Typeface)(_timerfont.getObject()));
 //BA.debugLineNum = 66;BA.debugLine="guiHelpers.ResizeText(\"00\",lblHrs) : 	lblHrs.Text";
_guihelpers._resizetext /*String*/ (ba,"00",_lblhrs);
 //BA.debugLineNum = 66;BA.debugLine="guiHelpers.ResizeText(\"00\",lblHrs) : 	lblHrs.Text";
_lblhrs.setTextSize((float) (_lblhrs.getTextSize()-6));
 //BA.debugLineNum = 67;BA.debugLine="lblMin.TextSize = lblHrs.TextSize : lblSec.TextSi";
_lblmin.setTextSize(_lblhrs.getTextSize());
 //BA.debugLineNum = 67;BA.debugLine="lblMin.TextSize = lblHrs.TextSize : lblSec.TextSi";
_lblsec.setTextSize(_lblhrs.getTextSize());
 //BA.debugLineNum = 69;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblListH";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lbllisthdr,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblhrs.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblmin.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lblsec.getObject()))},_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 71;BA.debugLine="guiHelpers.SetPanelsDividers(Array As B4XView(pnl";
_guihelpers._setpanelsdividers /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_pnlsplittermnu,_pnlsplitter,_pnlsplitter1,_pnlsplitter2,_pnlsplitter3,_pnlsplitter4,_pnlsplittertopbtn2,_pnlsplitterbottombtn1,_pnlsplittertopbtn1,_pnlsplitterbottombtn2},_clrtheme._dividercolor /*int*/ );
 //BA.debugLineNum = 75;BA.debugLine="guiHelpers.SetTextColor(Array As B4XView(lblLabel";
_guihelpers._settextcolor /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbllabelsec.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbllabelmin.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbllabelhr.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbldots1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbldots2.getObject())),_lbltimersdesc1,_lbltimersdesc2,_lbltimersdesc3,_lbltimersdesc4,_lbltimersdesc5,_lbltimerstime1,_lbltimerstime2,_lbltimerstime3,_lbltimerstime4,_lbltimerstime5},_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 79;BA.debugLine="guiHelpers.ResizeText(\"Open\",lblTimersDesc3)";
_guihelpers._resizetext /*String*/ (ba,"Open",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_lbltimersdesc3.getObject())));
 //BA.debugLineNum = 80;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(lblTimers";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{_lbltimersdesc1,_lbltimersdesc2,_lbltimersdesc3,_lbltimersdesc4,_lbltimersdesc5,_lbltimerstime1,_lbltimerstime2,_lbltimerstime3,_lbltimerstime4,_lbltimerstime5},_lbltimersdesc3.getTextSize());
 //BA.debugLineNum = 83;BA.debugLine="guiHelpers.ResizeText(lblLabelHr.Text,lblLabelHr)";
_guihelpers._resizetext /*String*/ (ba,_lbllabelhr.getText(),_lbllabelhr);
 //BA.debugLineNum = 83;BA.debugLine="guiHelpers.ResizeText(lblLabelHr.Text,lblLabelHr)";
_lbllabelsec.setTextSize(_lbllabelhr.getTextSize());
 //BA.debugLineNum = 83;BA.debugLine="guiHelpers.ResizeText(lblLabelHr.Text,lblLabelHr)";
_lbllabelmin.setTextSize(_lbllabelhr.getTextSize());
 //BA.debugLineNum = 85;BA.debugLine="guiHelpers.SkinButtonNoBorder(Array As Button(btn";
_guihelpers._skinbuttonnoborder /*String*/ (ba,new anywheresoftware.b4a.objects.ButtonWrapper[]{_btndecrs5,_btndecrs1,_btndecrm5,_btndecrm1,_btndecrh5,_btndecrh1,_btnincs5,_btnincs1,_btnincrh5,_btnincrh1,_btnincm5,_btnincm1,_btnreset,_btnpause});
 //BA.debugLineNum = 88;BA.debugLine="guiHelpers.ResizeText(\"+5\",BtnIncS5)";
_guihelpers._resizetext /*String*/ (ba,"+5",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_btnincs5.getObject())));
 //BA.debugLineNum = 89;BA.debugLine="guiHelpers.SetTextSize(Array As B4XView(BtnIncS5,";
_guihelpers._settextsize /*String*/ (ba,new anywheresoftware.b4a.objects.B4XViewWrapper[]{(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincs5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrs5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrs1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrm1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrm5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrh1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btndecrh5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincs1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincm1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincm5.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincrh1.getObject())),(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_btnincrh5.getObject()))},(float) (_btnincs5.getTextSize()-4));
 //BA.debugLineNum = 92;BA.debugLine="guiHelpers.ResizeText(\"Pause\",btnPause)";
_guihelpers._resizetext /*String*/ (ba,"Pause",(anywheresoftware.b4a.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.LabelWrapper(), (android.widget.TextView)(_btnpause.getObject())));
 //BA.debugLineNum = 93;BA.debugLine="btnReset.Text = \"Reset\" : btnReset.TextSize = btn";
_btnreset.setText(BA.ObjectToCharSequence("Reset"));
 //BA.debugLineNum = 93;BA.debugLine="btnReset.Text = \"Reset\" : btnReset.TextSize = btn";
_btnreset.setTextSize(_btnpause.getTextSize());
 //BA.debugLineNum = 94;BA.debugLine="kt.SetImages(Array As lmB4XImageViewX(imgTimers1,";
_kt._setimages /*String*/ (ba,new sadLogic.HomeCentral.lmb4ximageviewx[]{_imgtimers1,_imgtimers2,_imgtimers3,_imgtimers4,_imgtimers5},_gblconst._timers_img_stop /*String*/ );
 //BA.debugLineNum = 96;BA.debugLine="clsKTimers.CurrentTimer = 0";
_clsktimers._currenttimer /*int*/  = (int) (0);
 //BA.debugLineNum = 97;BA.debugLine="TimerSelect(0)";
_timerselect((int) (0));
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _buildtimerstr4list(String _hr,String _nnmin,String _sec) throws Exception{
 //BA.debugLineNum = 501;BA.debugLine="Private Sub BuildTimerStr4List(hr As String,nnMin";
 //BA.debugLineNum = 502;BA.debugLine="Return (hr & \":\" & nnMin & \":\" & sec)";
if (true) return (_hr+":"+_nnmin+":"+_sec);
 //BA.debugLineNum = 503;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private XUI As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private mpage As B4XMainPage = B4XPages.MainPage";
_mpage = _b4xpages._mainpage /*sadLogic.HomeCentral.b4xmainpage*/ (ba);
 //BA.debugLineNum = 11;BA.debugLine="Private pnlMain As B4XView";
_pnlmain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Public clsKTimers As KitchenTmrs '--- RENAME afte";
_clsktimers = new sadLogic.HomeCentral.kitchentmrs();
 //BA.debugLineNum = 14;BA.debugLine="Private msAlarmFireRollover As String";
_msalarmfirerollover = "";
 //BA.debugLineNum = 15;BA.debugLine="Private mTmrAlarmFire As Timer";
_mtmralarmfire = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 17;BA.debugLine="Private lblListHdr As B4XView";
_lbllisthdr = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private lblTimersDesc1,lblTimersDesc2,lblTimersDe";
_lbltimersdesc1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimersdesc2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimersdesc3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimersdesc4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimersdesc5 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private lblTimersTime1,lblTimersTime2,lblTimersTi";
_lbltimerstime1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimerstime2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimerstime3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimerstime4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbltimerstime5 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private imgTimers5,imgTimers4,imgTimers3,imgTimer";
_imgtimers5 = new sadLogic.HomeCentral.lmb4ximageviewx();
_imgtimers4 = new sadLogic.HomeCentral.lmb4ximageviewx();
_imgtimers3 = new sadLogic.HomeCentral.lmb4ximageviewx();
_imgtimers2 = new sadLogic.HomeCentral.lmb4ximageviewx();
_imgtimers1 = new sadLogic.HomeCentral.lmb4ximageviewx();
 //BA.debugLineNum = 22;BA.debugLine="Private pnlBtnsBottom,pnlBtnsTop As B4XView";
_pnlbtnsbottom = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlbtnstop = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private pnlLCD As B4XView";
_pnllcd = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private lblSec,lblMin,lblHrs As Label";
_lblsec = new anywheresoftware.b4a.objects.LabelWrapper();
_lblmin = new anywheresoftware.b4a.objects.LabelWrapper();
_lblhrs = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private lblDots1 ,lblDots2 As Label";
_lbldots1 = new anywheresoftware.b4a.objects.LabelWrapper();
_lbldots2 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private pnlBtnsMenu As B4XView";
_pnlbtnsmenu = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private pnlSplitterMnu As B4XView";
_pnlsplittermnu = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private pnlHrsMinSecsLbl As B4XView";
_pnlhrsminsecslbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private lblLabelSec,lblLabelMin,lblLabelHr As Lab";
_lbllabelsec = new anywheresoftware.b4a.objects.LabelWrapper();
_lbllabelmin = new anywheresoftware.b4a.objects.LabelWrapper();
_lbllabelhr = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private TimerFont As Typeface";
_timerfont = new anywheresoftware.b4a.keywords.constants.TypefaceWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private pnlSplitter,pnlSplitter1,pnlSplitter2,pnl";
_pnlsplitter = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitter1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitter2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitter3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitter4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private btnDecrS5,btnDecrS1,btnDecrM5,btnDecrM1 ,";
_btndecrs5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndecrs1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndecrm5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndecrm1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndecrh5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btndecrh1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private BtnIncS5,BtnIncS1,btnIncrH5,btnIncrH1,Btn";
_btnincs5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnincs1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnincrh5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnincrh1 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnincm5 = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnincm1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private btnReset,btnPause As Button";
_btnreset = new anywheresoftware.b4a.objects.ButtonWrapper();
_btnpause = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private pnlSplitterTopBtn2,pnlSplitterBottomBtn1,";
_pnlsplittertopbtn2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitterbottombtn1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplittertopbtn1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnlsplitterbottombtn2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _clearlarge_timertxt() throws Exception{
 //BA.debugLineNum = 418;BA.debugLine="Public Sub ClearLarge_TimerTxt";
 //BA.debugLineNum = 419;BA.debugLine="lblHrs.TextColor =  clrTheme.txtAccent";
_lblhrs.setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 420;BA.debugLine="lblHrs.Text = \"00\": lblMin.Text = \"00\" : lblSec.T";
_lblhrs.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 420;BA.debugLine="lblHrs.Text = \"00\": lblMin.Text = \"00\" : lblSec.T";
_lblmin.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 420;BA.debugLine="lblHrs.Text = \"00\": lblMin.Text = \"00\" : lblSec.T";
_lblsec.setText(BA.ObjectToCharSequence("00"));
 //BA.debugLineNum = 421;BA.debugLine="End Sub";
return "";
}
public long  _getendtime() throws Exception{
long _nendtime = 0L;
b4a.example.dateutils._period _p1 = null;
b4a.example.dateutils._period _p2 = null;
b4a.example.dateutils._period _p3 = null;
 //BA.debugLineNum = 126;BA.debugLine="Private Sub GetEndTime() As Long";
 //BA.debugLineNum = 128;BA.debugLine="Dim nEndTime As Long,  p1,p2,p3 As Period";
_nendtime = 0L;
_p1 = new b4a.example.dateutils._period();
_p2 = new b4a.example.dateutils._period();
_p3 = new b4a.example.dateutils._period();
 //BA.debugLineNum = 129;BA.debugLine="p1.Hours   = lblHrs.Text : nEndTime = DateUtils.A";
_p1.Hours = (int)(Double.parseDouble(_lblhrs.getText()));
 //BA.debugLineNum = 129;BA.debugLine="p1.Hours   = lblHrs.Text : nEndTime = DateUtils.A";
_nendtime = _dateutils._addperiod(ba,__c.DateTime.getNow(),_p1);
 //BA.debugLineNum = 130;BA.debugLine="p2.Minutes = lblMin.Text : nEndTime = DateUtils.A";
_p2.Minutes = (int)(Double.parseDouble(_lblmin.getText()));
 //BA.debugLineNum = 130;BA.debugLine="p2.Minutes = lblMin.Text : nEndTime = DateUtils.A";
_nendtime = _dateutils._addperiod(ba,_nendtime,_p2);
 //BA.debugLineNum = 131;BA.debugLine="p3.Seconds = lblSec.Text : nEndTime = DateUtils.A";
_p3.Seconds = (int)(Double.parseDouble(_lblsec.getText()));
 //BA.debugLineNum = 131;BA.debugLine="p3.Seconds = lblSec.Text : nEndTime = DateUtils.A";
_nendtime = _dateutils._addperiod(ba,_nendtime,_p3);
 //BA.debugLineNum = 132;BA.debugLine="Return nEndTime";
if (true) return _nendtime;
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return 0L;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _p) throws Exception{
innerInitialize(_ba);
int _x = 0;
 //BA.debugLineNum = 41;BA.debugLine="Public Sub Initialize(p As B4XView)";
 //BA.debugLineNum = 43;BA.debugLine="pnlMain = p";
_pnlmain = _p;
 //BA.debugLineNum = 44;BA.debugLine="p.LoadLayout(\"pageKitchenTimersBase\")";
_p.LoadLayout("pageKitchenTimersBase",ba);
 //BA.debugLineNum = 45;BA.debugLine="clsKTimers.Initialize";
_clsktimers._initialize /*String*/ (ba);
 //BA.debugLineNum = 46;BA.debugLine="mTmrAlarmFire.Initialize(\"tmrAlarmFire\",400)";
_mtmralarmfire.Initialize(ba,"tmrAlarmFire",(long) (400));
 //BA.debugLineNum = 47;BA.debugLine="mTmrAlarmFire.Enabled = False";
_mtmralarmfire.setEnabled(__c.False);
 //BA.debugLineNum = 49;BA.debugLine="BuildGUI";
_buildgui();
 //BA.debugLineNum = 51;BA.debugLine="For x = 1 To 5 '--- init the timers";
{
final int step7 = 1;
final int limit7 = (int) (5);
_x = (int) (1) ;
for (;_x <= limit7 ;_x = _x + step7 ) {
 //BA.debugLineNum = 52;BA.debugLine="clsKTimers.timers(x).Initialize";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].Initialize();
 //BA.debugLineNum = 53;BA.debugLine="kt.Clear_Timer(x)";
_kt._clear_timer /*String*/ (ba,_x);
 //BA.debugLineNum = 54;BA.debugLine="TimerUnSelect(x)";
_timerunselect(_x);
 }
};
 //BA.debugLineNum = 56;BA.debugLine="TimerSelect(1)";
_timerselect((int) (1));
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public boolean  _istimerblank() throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Private Sub IsTimerBlank() As Boolean";
 //BA.debugLineNum = 119;BA.debugLine="If (kt.xStr2Int(lblHrs.Text) = 0 And lblMin.Text";
if ((_kt._xstr2int /*int*/ (ba,_lblhrs.getText())==0 && (_lblmin.getText()).equals("00") && (_lblsec.getText()).equals("00"))) { 
 //BA.debugLineNum = 120;BA.debugLine="Return True";
if (true) return __c.True;
 }else {
 //BA.debugLineNum = 122;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return false;
}
public String  _lost_focus() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Public Sub Lost_focus()";
 //BA.debugLineNum = 110;BA.debugLine="pnlMain.SetVisibleAnimated(500,False)";
_pnlmain.SetVisibleAnimated((int) (500),__c.False);
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _page_setup() throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Private Sub Page_Setup";
 //BA.debugLineNum = 107;BA.debugLine="guiHelpers.Show_toast2(\"TODO\",3500)";
_guihelpers._show_toast2 /*String*/ (ba,"TODO",(int) (3500));
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public String  _pnltimers_click() throws Exception{
 //BA.debugLineNum = 505;BA.debugLine="Private Sub pnlTimers_Click";
 //BA.debugLineNum = 507;BA.debugLine="TimerSelect(Sender.As(Panel).Tag.As(Int))";
_timerselect(((int)(BA.ObjectToNumber(((anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(__c.Sender(ba)))).getTag()))));
 //BA.debugLineNum = 508;BA.debugLine="End Sub";
return "";
}
public String  _presets_event(String _id,Object _o) throws Exception{
anywheresoftware.b4a.sql.SQL.CursorWrapper _cur = null;
 //BA.debugLineNum = 540;BA.debugLine="Private Sub Presets_Event(id As String,o As Object";
 //BA.debugLineNum = 541;BA.debugLine="If strHelpers.IsNullOrEmpty(id) Then Return";
if (_strhelpers._isnullorempty /*boolean*/ (ba,_id)) { 
if (true) return "";};
 //BA.debugLineNum = 543;BA.debugLine="Dim cur As Cursor = Main.kvs.oSql.ExecQuery(\"SELE";
_cur = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
_cur = (anywheresoftware.b4a.sql.SQL.CursorWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.sql.SQL.CursorWrapper(), (android.database.Cursor)(_main._kvs /*sadLogic.HomeCentral.sadkeyvaluestore*/ ._getosql /*anywheresoftware.b4a.sql.SQL*/ ().ExecQuery("SELECT * FROM timers WHERE id ="+_id)));
 //BA.debugLineNum = 544;BA.debugLine="cur.Position = 0";
_cur.setPosition((int) (0));
 //BA.debugLineNum = 546;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nHr =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nHr /*int*/  = (int)(Double.parseDouble(__c.Regex.Split(":",_cur.GetString("time"))[(int) (0)]));
 //BA.debugLineNum = 547;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nMin =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nMin /*int*/  = (int)(Double.parseDouble(__c.Regex.Split(":",_cur.GetString("time"))[(int) (1)]));
 //BA.debugLineNum = 548;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nSec =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nSec /*int*/  = (int)(Double.parseDouble(__c.Regex.Split(":",_cur.GetString("time"))[(int) (2)]));
 //BA.debugLineNum = 550;BA.debugLine="lblHrs.Text = kt.PadZero(clsKTimers.timers(clsKTi";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nHr /*int*/ )));
 //BA.debugLineNum = 551;BA.debugLine="lblMin.Text = kt.PadZero(clsKTimers.timers(clsKTi";
_lblmin.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nMin /*int*/ )));
 //BA.debugLineNum = 552;BA.debugLine="lblSec.Text = kt.PadZero(clsKTimers.timers(clsKTi";
_lblsec.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nSec /*int*/ )));
 //BA.debugLineNum = 554;BA.debugLine="StartTimer(cur.GetString(\"description\"))";
_starttimer(_cur.GetString("description"));
 //BA.debugLineNum = 556;BA.debugLine="End Sub";
return "";
}
public String  _set_focus() throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Public Sub Set_focus()";
 //BA.debugLineNum = 102;BA.debugLine="mpage.tmrTimerCallSub.CallSubDelayedPlus(Me,\"Buil";
_mpage._tmrtimercallsub /*sadLogic.HomeCentral.sadcallsubutils*/ ._callsubdelayedplus /*String*/ (this,"Build_Side_Menu",(int) (250));
 //BA.debugLineNum = 103;BA.debugLine="Menus.SetHeader(\"Timers\",\"main_menu_timers.png\")";
_menus._setheader /*String*/ (ba,"Timers","main_menu_timers.png");
 //BA.debugLineNum = 104;BA.debugLine="pnlMain.SetVisibleAnimated(500,True)";
_pnlmain.SetVisibleAnimated((int) (500),__c.True);
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public String  _show_presets() throws Exception{
sadLogic.HomeCentral.guimsgs _gui = null;
sadLogic.HomeCentral.dlglistbox _o1 = null;
 //BA.debugLineNum = 524;BA.debugLine="Private Sub Show_Presets";
 //BA.debugLineNum = 529;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui = new sadLogic.HomeCentral.guimsgs();
 //BA.debugLineNum = 529;BA.debugLine="Dim gui As guiMsgs : gui.Initialize";
_gui._initialize /*String*/ (ba);
 //BA.debugLineNum = 530;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.HomeCentral.dlglistbox();
 //BA.debugLineNum = 532;BA.debugLine="o1.Initialize(\"Timer Presets\",Me,\"Presets_Event\",";
_o1._initialize /*Object*/ (ba,(Object)("Timer Presets"),this,"Presets_Event",_mpage._dialog /*sadLogic.HomeCentral.b4xdialog*/ );
 //BA.debugLineNum = 533;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = __c.True;
 //BA.debugLineNum = 534;BA.debugLine="o1.Show(440dip,430dip,gui.BuildPresets())";
_o1._show /*void*/ ((float) (__c.DipToCurrent((int) (440))),(float) (__c.DipToCurrent((int) (430))),_gui._buildpresets /*anywheresoftware.b4a.objects.collections.Map*/ ());
 //BA.debugLineNum = 537;BA.debugLine="End Sub";
return "";
}
public String  _sidemenu_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 511;BA.debugLine="Private Sub SideMenu_ItemClick (Index As Int, Valu";
 //BA.debugLineNum = 513;BA.debugLine="Select Case Value";
switch (BA.switchObjectToInt(_value,(Object)("pr"))) {
case 0: {
 //BA.debugLineNum = 514;BA.debugLine="Case \"pr\" : Show_Presets";
_show_presets();
 break; }
}
;
 //BA.debugLineNum = 516;BA.debugLine="mpage.pnlSideMenu.SetVisibleAnimated(380, False)";
_mpage._pnlsidemenu /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .SetVisibleAnimated((int) (380),__c.False);
 //BA.debugLineNum = 517;BA.debugLine="End Sub";
return "";
}
public String  _starttimer(String _txt) throws Exception{
 //BA.debugLineNum = 146;BA.debugLine="Private Sub StartTimer(txt As String)";
 //BA.debugLineNum = 149;BA.debugLine="If IsTimerBlank Then Return";
if (_istimerblank()) { 
if (true) return "";};
 //BA.debugLineNum = 151;BA.debugLine="If txt <> \"\" Then";
if ((_txt).equals("") == false) { 
 //BA.debugLineNum = 152;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).txt =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].txt /*String*/  = _txt;
 }else {
 //BA.debugLineNum = 154;BA.debugLine="txt = clsKTimers.timers(clsKTimers.CurrentTimer)";
_txt = _clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].txt /*String*/ ;
 };
 //BA.debugLineNum = 157;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).active";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].active /*boolean*/  = __c.True;
 //BA.debugLineNum = 158;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nHr =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nHr /*int*/  = (int)(Double.parseDouble(_lblhrs.getText()));
 //BA.debugLineNum = 159;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nSec =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nSec /*int*/  = (int)(Double.parseDouble(_lblsec.getText()));
 //BA.debugLineNum = 160;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).nMin =";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].nMin /*int*/  = (int)(Double.parseDouble(_lblmin.getText()));
 //BA.debugLineNum = 161;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).endTim";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].endTime /*long*/  = _getendtime();
 //BA.debugLineNum = 162;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).Firing";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].Firing /*boolean*/  = __c.False;
 //BA.debugLineNum = 163;BA.debugLine="clsKTimers.timers(clsKTimers.CurrentTimer).paused";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_clsktimers._currenttimer /*int*/ ].paused /*boolean*/  = __c.False;
 //BA.debugLineNum = 165;BA.debugLine="UpdateListOfTimersDesc(clsKTimers.CurrentTimer,tx";
_updatelistoftimersdesc(_clsktimers._currenttimer /*int*/ ,_txt);
 //BA.debugLineNum = 166;BA.debugLine="UpdateListOfTimers(clsKTimers.CurrentTimer)";
_updatelistoftimers(_clsktimers._currenttimer /*int*/ );
 //BA.debugLineNum = 167;BA.debugLine="Update_ListOfTimersIMG(clsKTimers.CurrentTimer,gb";
_update_listoftimersimg(_clsktimers._currenttimer /*int*/ ,_gblconst._timers_img_go /*String*/ );
 //BA.debugLineNum = 169;BA.debugLine="CallSub(clsKTimers,\"tmr_TimersCheck\")";
__c.CallSubNew(ba,(Object)(_clsktimers),"tmr_TimersCheck");
 //BA.debugLineNum = 171;BA.debugLine="btnPause.Text = \"Pause\"";
_btnpause.setText(BA.ObjectToCharSequence("Pause"));
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return "";
}
public String  _timerselect(int _x) throws Exception{
 //BA.debugLineNum = 236;BA.debugLine="Private Sub TimerSelect(x As Int)";
 //BA.debugLineNum = 240;BA.debugLine="TimerSetColor(clsKTimers.CurrentTimer,clrTheme.tx";
_timersetcolor(_clsktimers._currenttimer /*int*/ ,_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 241;BA.debugLine="TimerSetColor(x,clrTheme.txtAccent)";
_timersetcolor(_x,_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 243;BA.debugLine="clsKTimers.CurrentTimer = x";
_clsktimers._currenttimer /*int*/  = _x;
 //BA.debugLineNum = 244;BA.debugLine="lblHrs.Text = kt.PadZero(clsKTimers.timers(x).nHr";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nHr /*int*/ )));
 //BA.debugLineNum = 245;BA.debugLine="lblMin.Text = kt.PadZero(clsKTimers.timers(x).nMi";
_lblmin.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nMin /*int*/ )));
 //BA.debugLineNum = 246;BA.debugLine="lblSec.Text = kt.PadZero(clsKTimers.timers(x).nSe";
_lblsec.setText(BA.ObjectToCharSequence(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nSec /*int*/ )));
 //BA.debugLineNum = 248;BA.debugLine="If clsKTimers.timers(x).active Then";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].active /*boolean*/ ) { 
 //BA.debugLineNum = 250;BA.debugLine="btnPause.Text = \"Pause\"";
_btnpause.setText(BA.ObjectToCharSequence("Pause"));
 }else {
 //BA.debugLineNum = 253;BA.debugLine="lblHrs.TextColor =  clrTheme.txtAccent";
_lblhrs.setTextColor(_clrtheme._txtaccent /*int*/ );
 //BA.debugLineNum = 254;BA.debugLine="btnPause.Text =\"Start\"";
_btnpause.setText(BA.ObjectToCharSequence("Start"));
 };
 //BA.debugLineNum = 258;BA.debugLine="If clsKTimers.moAlarm(x).IsInitialized Then";
if (_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_x].IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 259;BA.debugLine="If clsKTimers.moAlarm(x).mbActive Then";
if (_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_x]._mbactive /*boolean*/ ) { 
 //BA.debugLineNum = 260;BA.debugLine="clsKTimers.timers(x).Firing = False";
_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].Firing /*boolean*/  = __c.False;
 //BA.debugLineNum = 261;BA.debugLine="clsKTimers.moAlarm(x).AlarmStop(x)";
_clsktimers._moalarm /*sadLogic.HomeCentral.clskalarms[]*/ [_x]._alarmstop /*String*/ (_x);
 //BA.debugLineNum = 263;BA.debugLine="CallSubDelayed2(Me,\"Clear_Timer\",x)";
__c.CallSubDelayed2(ba,this,"Clear_Timer",(Object)(_x));
 //BA.debugLineNum = 264;BA.debugLine="Update_ListOfTimersIMG(x,gblConst.TIMERS_IMG_ST";
_update_listoftimersimg(_x,_gblconst._timers_img_stop /*String*/ );
 };
 };
 //BA.debugLineNum = 268;BA.debugLine="If kt.AnyTimersFiring() = False Then mTmrAlarmFir";
if (_kt._anytimersfiring /*boolean*/ (ba)==__c.False) { 
_mtmralarmfire.setEnabled(__c.False);};
 //BA.debugLineNum = 269;BA.debugLine="CallSubDelayed(mpage,\"ResetScrn_SleepCounter\")";
__c.CallSubDelayed(ba,(Object)(_mpage),"ResetScrn_SleepCounter");
 //BA.debugLineNum = 271;BA.debugLine="End Sub";
return "";
}
public String  _timersetcolor(int _n,int _clr) throws Exception{
 //BA.debugLineNum = 226;BA.debugLine="Private Sub TimerSetColor(n As Int,clr As Int)";
 //BA.debugLineNum = 227;BA.debugLine="Select Case n";
switch (_n) {
case 1: {
 //BA.debugLineNum = 228;BA.debugLine="Case 1 : lblTimersDesc1.TextColor=clr : lblTimer";
_lbltimersdesc1.setTextColor(_clr);
 //BA.debugLineNum = 228;BA.debugLine="Case 1 : lblTimersDesc1.TextColor=clr : lblTimer";
_lbltimerstime1.setTextColor(_clr);
 break; }
case 2: {
 //BA.debugLineNum = 229;BA.debugLine="Case 2 : lblTimersDesc2.TextColor=clr : lblTimer";
_lbltimersdesc2.setTextColor(_clr);
 //BA.debugLineNum = 229;BA.debugLine="Case 2 : lblTimersDesc2.TextColor=clr : lblTimer";
_lbltimerstime2.setTextColor(_clr);
 break; }
case 3: {
 //BA.debugLineNum = 230;BA.debugLine="Case 3 : lblTimersDesc3.TextColor=clr : lblTimer";
_lbltimersdesc3.setTextColor(_clr);
 //BA.debugLineNum = 230;BA.debugLine="Case 3 : lblTimersDesc3.TextColor=clr : lblTimer";
_lbltimerstime3.setTextColor(_clr);
 break; }
case 4: {
 //BA.debugLineNum = 231;BA.debugLine="Case 4 : lblTimersDesc4.TextColor=clr : lblTimer";
_lbltimersdesc4.setTextColor(_clr);
 //BA.debugLineNum = 231;BA.debugLine="Case 4 : lblTimersDesc4.TextColor=clr : lblTimer";
_lbltimerstime4.setTextColor(_clr);
 break; }
case 5: {
 //BA.debugLineNum = 232;BA.debugLine="Case 5 : lblTimersDesc5.TextColor=clr : lblTimer";
_lbltimersdesc5.setTextColor(_clr);
 //BA.debugLineNum = 232;BA.debugLine="Case 5 : lblTimersDesc5.TextColor=clr : lblTimer";
_lbltimerstime5.setTextColor(_clr);
 break; }
}
;
 //BA.debugLineNum = 234;BA.debugLine="End Sub";
return "";
}
public String  _timerunselect(int _n) throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Private Sub TimerUnSelect(n As Int)";
 //BA.debugLineNum = 223;BA.debugLine="TimerSetColor(n,clrTheme.txtNormal)";
_timersetcolor(_n,_clrtheme._txtnormal /*int*/ );
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
return "";
}
public String  _tmralarmfire_tick() throws Exception{
String _spic = "";
int _xx = 0;
 //BA.debugLineNum = 558;BA.debugLine="Sub tmrAlarmFire_Tick";
 //BA.debugLineNum = 562;BA.debugLine="Dim sPic As String";
_spic = "";
 //BA.debugLineNum = 563;BA.debugLine="If msAlarmFireRollover = gblConst.TIMERS_IMG_GO T";
if ((_msalarmfirerollover).equals(_gblconst._timers_img_go /*String*/ )) { 
 //BA.debugLineNum = 564;BA.debugLine="sPic = gblConst.TIMERS_IMG_STOP";
_spic = _gblconst._timers_img_stop /*String*/ ;
 }else {
 //BA.debugLineNum = 566;BA.debugLine="sPic = gblConst.TIMERS_IMG_GO";
_spic = _gblconst._timers_img_go /*String*/ ;
 };
 //BA.debugLineNum = 569;BA.debugLine="Dim xx As Int";
_xx = 0;
 //BA.debugLineNum = 570;BA.debugLine="For xx = 1 To 5";
{
final int step8 = 1;
final int limit8 = (int) (5);
_xx = (int) (1) ;
for (;_xx <= limit8 ;_xx = _xx + step8 ) {
 //BA.debugLineNum = 571;BA.debugLine="If clsKTimers.timers(xx).Firing Then";
if (_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_xx].Firing /*boolean*/ ) { 
 //BA.debugLineNum = 572;BA.debugLine="Select Case xx";
switch (_xx) {
case 1: {
 //BA.debugLineNum = 573;BA.debugLine="Case 1 : imgTimers1.Bitmap = LoadBitmap(File.D";
_imgtimers1._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 2: {
 //BA.debugLineNum = 574;BA.debugLine="Case 2 : imgTimers2.Bitmap = LoadBitmap(File.D";
_imgtimers2._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 3: {
 //BA.debugLineNum = 575;BA.debugLine="Case 3 : imgTimers3.Bitmap = LoadBitmap(File.D";
_imgtimers3._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 4: {
 //BA.debugLineNum = 576;BA.debugLine="Case 4 : imgTimers4.Bitmap = LoadBitmap(File.D";
_imgtimers4._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 5: {
 //BA.debugLineNum = 577;BA.debugLine="Case 5 : imgTimers5.Bitmap = LoadBitmap(File.D";
_imgtimers5._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
}
;
 };
 }
};
 //BA.debugLineNum = 582;BA.debugLine="msAlarmFireRollover = sPic";
_msalarmfirerollover = _spic;
 //BA.debugLineNum = 583;BA.debugLine="End Sub";
return "";
}
public String  _update_listoftimersimg(int _xx,String _spic) throws Exception{
 //BA.debugLineNum = 438;BA.debugLine="Public Sub Update_ListOfTimersIMG(xx As Int, sPic";
 //BA.debugLineNum = 440;BA.debugLine="Select Case xx";
switch (_xx) {
case 1: {
 //BA.debugLineNum = 441;BA.debugLine="Case 1 : imgTimers1.Bitmap = LoadBitmap(File.Dir";
_imgtimers1._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 2: {
 //BA.debugLineNum = 442;BA.debugLine="Case 2 : imgTimers2.Bitmap = LoadBitmap(File.Dir";
_imgtimers2._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 3: {
 //BA.debugLineNum = 443;BA.debugLine="Case 3 : imgTimers3.Bitmap = LoadBitmap(File.Dir";
_imgtimers3._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 4: {
 //BA.debugLineNum = 444;BA.debugLine="Case 4 : imgTimers4.Bitmap = LoadBitmap(File.Dir";
_imgtimers4._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
case 5: {
 //BA.debugLineNum = 445;BA.debugLine="Case 5 : imgTimers5.Bitmap = LoadBitmap(File.Dir";
_imgtimers5._setbitmap /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper*/ ((anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),_spic).getObject())));
 break; }
}
;
 //BA.debugLineNum = 448;BA.debugLine="Select Case sPic";
switch (BA.switchObjectToInt(_spic,_gblconst._timers_img_stop /*String*/ ,_gblconst._timers_img_pause /*String*/ ,_gblconst._timers_img_go /*String*/ )) {
case 0: 
case 1: {
 //BA.debugLineNum = 450;BA.debugLine="btnPause.Text = \"Start\"";
_btnpause.setText(BA.ObjectToCharSequence("Start"));
 break; }
case 2: {
 //BA.debugLineNum = 453;BA.debugLine="btnPause.Text = \"Pause\"";
_btnpause.setText(BA.ObjectToCharSequence("Pause"));
 break; }
}
;
 //BA.debugLineNum = 457;BA.debugLine="End Sub";
return "";
}
public String  _updatelistoftimers(int _x) throws Exception{
String _s = "";
 //BA.debugLineNum = 488;BA.debugLine="Public Sub UpdateListOfTimers(x As Int)";
 //BA.debugLineNum = 489;BA.debugLine="Dim s As String = BuildTimerStr4List( _ 			kt.Pad";
_s = _buildtimerstr4list(_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nHr /*int*/ ),_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nMin /*int*/ ),_kt._padzero /*String*/ (ba,_clsktimers._timers /*sadLogic.HomeCentral.kt._typtimers[]*/ [_x].nSec /*int*/ ));
 //BA.debugLineNum = 492;BA.debugLine="Select Case x";
switch (_x) {
case 1: {
 //BA.debugLineNum = 493;BA.debugLine="Case 1 : lblTimersTime1.Text = s";
_lbltimerstime1.setText(BA.ObjectToCharSequence(_s));
 break; }
case 2: {
 //BA.debugLineNum = 494;BA.debugLine="Case 2 : lblTimersTime2.Text = s";
_lbltimerstime2.setText(BA.ObjectToCharSequence(_s));
 break; }
case 3: {
 //BA.debugLineNum = 495;BA.debugLine="Case 3 : lblTimersTime3.Text = s";
_lbltimerstime3.setText(BA.ObjectToCharSequence(_s));
 break; }
case 4: {
 //BA.debugLineNum = 496;BA.debugLine="Case 4 : lblTimersTime4.Text = s";
_lbltimerstime4.setText(BA.ObjectToCharSequence(_s));
 break; }
case 5: {
 //BA.debugLineNum = 497;BA.debugLine="Case 5 : lblTimersTime5.Text = s";
_lbltimerstime5.setText(BA.ObjectToCharSequence(_s));
 break; }
}
;
 //BA.debugLineNum = 500;BA.debugLine="End Sub";
return "";
}
public String  _updatelistoftimersdesc(int _x,String _txt) throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Private Sub UpdateListOfTimersDesc(x As Int, txt A";
 //BA.debugLineNum = 137;BA.debugLine="Select Case x";
switch (_x) {
case 1: {
 //BA.debugLineNum = 138;BA.debugLine="Case 1 : lblTimersDesc1.Text = txt";
_lbltimersdesc1.setText(BA.ObjectToCharSequence(_txt));
 break; }
case 2: {
 //BA.debugLineNum = 139;BA.debugLine="Case 2 : lblTimersDesc2.Text = txt";
_lbltimersdesc2.setText(BA.ObjectToCharSequence(_txt));
 break; }
case 3: {
 //BA.debugLineNum = 140;BA.debugLine="Case 3 : lblTimersDesc3.Text = txt";
_lbltimersdesc3.setText(BA.ObjectToCharSequence(_txt));
 break; }
case 4: {
 //BA.debugLineNum = 141;BA.debugLine="Case 4 : lblTimersDesc4.Text = txt";
_lbltimersdesc4.setText(BA.ObjectToCharSequence(_txt));
 break; }
case 5: {
 //BA.debugLineNum = 142;BA.debugLine="Case 5 : lblTimersDesc5.Text = txt";
_lbltimersdesc5.setText(BA.ObjectToCharSequence(_txt));
 break; }
}
;
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return "";
}
public String  _updaterunning_tmr(String _s) throws Exception{
String[] _tm = null;
 //BA.debugLineNum = 423;BA.debugLine="Public Sub UpdateRunning_Tmr(S As String)";
 //BA.debugLineNum = 424;BA.debugLine="If S.Length = 7 Then S = \"0\" & S";
if (_s.length()==7) { 
_s = "0"+_s;};
 //BA.debugLineNum = 425;BA.debugLine="Dim tm() As String = Regex.Split(\":\",S)";
_tm = __c.Regex.Split(":",_s);
 //BA.debugLineNum = 427;BA.debugLine="lblSec.Text = tm(2)";
_lblsec.setText(BA.ObjectToCharSequence(_tm[(int) (2)]));
 //BA.debugLineNum = 428;BA.debugLine="lblMin.Text = tm(1)";
_lblmin.setText(BA.ObjectToCharSequence(_tm[(int) (1)]));
 //BA.debugLineNum = 429;BA.debugLine="If kt.xStr2Int( tm(0) ) = 0  Then";
if (_kt._xstr2int /*int*/ (ba,_tm[(int) (0)])==0) { 
 //BA.debugLineNum = 430;BA.debugLine="lblHrs.TextColor = clrTheme.txtAccent";
_lblhrs.setTextColor(_clrtheme._txtaccent /*int*/ );
 }else {
 //BA.debugLineNum = 432;BA.debugLine="lblHrs.TextColor = clrTheme.txtAccent";
_lblhrs.setTextColor(_clrtheme._txtaccent /*int*/ );
 };
 //BA.debugLineNum = 434;BA.debugLine="lblHrs.Text = kt.xStr2Int(tm(0))";
_lblhrs.setText(BA.ObjectToCharSequence(_kt._xstr2int /*int*/ (ba,_tm[(int) (0)])));
 //BA.debugLineNum = 436;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "BUILD_SIDE_MENU"))
	return _build_side_menu();
if (BA.fastSubCompare(sub, "CLEARLARGE_TIMERTXT"))
	return _clearlarge_timertxt();
if (BA.fastSubCompare(sub, "LOST_FOCUS"))
	return _lost_focus();
if (BA.fastSubCompare(sub, "SET_FOCUS"))
	return _set_focus();
if (BA.fastSubCompare(sub, "SIDEMENU_ITEMCLICK"))
	return _sidemenu_itemclick(((Number)args[0]).intValue(), (Object) args[1]);
if (BA.fastSubCompare(sub, "UPDATE_LISTOFTIMERSIMG"))
	return _update_listoftimersimg(((Number)args[0]).intValue(), (String) args[1]);
if (BA.fastSubCompare(sub, "UPDATELISTOFTIMERS"))
	return _updatelistoftimers(((Number)args[0]).intValue());
if (BA.fastSubCompare(sub, "UPDATERUNNING_TMR"))
	return _updaterunning_tmr((String) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
