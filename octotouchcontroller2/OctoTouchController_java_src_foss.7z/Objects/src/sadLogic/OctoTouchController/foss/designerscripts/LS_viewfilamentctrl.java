package sadLogic.OctoTouchController.foss.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_viewfilamentctrl{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _allwidth="";
String _n="";
String _maxsize="";
String _mingap="";
String _w="";
String _gap="";
String _i="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlmain").vw.setLeft((int)((0d / 100 * width)));
views.get("pnlmain").vw.setWidth((int)((100d / 100 * width) - ((0d / 100 * width))));
views.get("pnlmain").vw.setTop((int)(0d));
views.get("pnlmain").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlworking").vw.setLeft((int)(0d));
views.get("pnlworking").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlworking").vw.setTop((int)(0d));
views.get("pnlworking").vw.setHeight((int)((100d / 100 * height) - (0d)));
views.get("pnlworking").vw.setVisible(BA.parseBoolean("false"));
views.get("pnlmain").vw.setVisible(BA.parseBoolean("true"));
views.get("btnheat").vw.setTop((int)((views.get("pnlmain").vw.getHeight())/3.2d - (views.get("btnheat").vw.getHeight() / 2)));
views.get("btnload").vw.setTop((int)((views.get("btnheat").vw.getTop())));
views.get("btnpark").vw.setTop((int)((views.get("btnheat").vw.getTop() + views.get("btnheat").vw.getHeight())+(20d * scale)));
views.get("btnunload").vw.setTop((int)((views.get("btnpark").vw.getTop())));
views.get("btnsetup").vw.setTop((int)(0d));
views.get("btnsetup").vw.setLeft((int)((views.get("pnlmain").vw.getLeft() + views.get("pnlmain").vw.getWidth()) - (views.get("btnsetup").vw.getWidth())));
views.get("btnhome").vw.setTop((int)(0d));
views.get("btnhome").vw.setLeft((int)((views.get("pnlmain").vw.getLeft())));
_allwidth = BA.NumberToString((views.get("pnlmain").vw.getWidth())-(2d * scale));
_n = "2";
_maxsize = BA.NumberToString((112d * scale));
_mingap = BA.NumberToString((18d * scale));
_w = BA.NumberToString(Math.min(Double.parseDouble(_allwidth)/Double.parseDouble(_n)-Double.parseDouble(_mingap),Double.parseDouble(_maxsize)));
_gap = BA.NumberToString((Double.parseDouble(_allwidth)-Double.parseDouble(_n)*Double.parseDouble(_w))/Double.parseDouble(_n));
_i = "0";
views.get("btnheat").vw.setLeft((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w)));
views.get("btnheat").vw.setWidth((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+(Double.parseDouble(_i)+1d)*Double.parseDouble(_w) - ((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w))));
_i = "1";
views.get("btnload").vw.setLeft((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w)));
views.get("btnload").vw.setWidth((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+(Double.parseDouble(_i)+1d)*Double.parseDouble(_w) - ((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w))));
_i = "0";
views.get("btnpark").vw.setLeft((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w)));
views.get("btnpark").vw.setWidth((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+(Double.parseDouble(_i)+1d)*Double.parseDouble(_w) - ((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w))));
_i = "1";
views.get("btnunload").vw.setLeft((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w)));
views.get("btnunload").vw.setWidth((int)((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+(Double.parseDouble(_i)+1d)*Double.parseDouble(_w) - ((Double.parseDouble(_i)+0.5d)*Double.parseDouble(_gap)+Double.parseDouble(_i)*Double.parseDouble(_w))));
views.get("btnback").vw.setLeft((int)((views.get("pnlworking").vw.getLeft())));
views.get("btnback").vw.setTop((int)((views.get("pnlworking").vw.getTop() + views.get("pnlworking").vw.getHeight())-(views.get("btnback").vw.getHeight())));
views.get("lblstatus").vw.setLeft((int)((views.get("pnlmain").vw.getWidth())/2d - (views.get("lblstatus").vw.getWidth() / 2)));
views.get("lblstatus").vw.setTop((int)((views.get("pnlmain").vw.getHeight())/2.9d - (views.get("lblstatus").vw.getHeight() / 2)));
views.get("btnstuff").vw.setLeft((int)((views.get("pnlmain").vw.getWidth())/2d - (views.get("btnstuff").vw.getWidth() / 2)));
views.get("btnstuff").vw.setTop((int)((views.get("lblstatus").vw.getTop() + views.get("lblstatus").vw.getHeight())+(13d * scale)));
views.get("lbltemp").vw.setLeft((int)((views.get("pnlworking").vw.getWidth())-(10d * scale) - (views.get("lbltemp").vw.getWidth())));
views.get("lbltemp").vw.setTop((int)((views.get("pnlmain").vw.getTop() + views.get("pnlmain").vw.getHeight())-(8d * scale) - (views.get("lbltemp").vw.getHeight())));
views.get("lblstatus").vw.setLeft((int)((10d * scale)));
views.get("lblstatus").vw.setWidth((int)((views.get("pnlmain").vw.getWidth())-(10d * scale) - ((10d * scale))));

}
}