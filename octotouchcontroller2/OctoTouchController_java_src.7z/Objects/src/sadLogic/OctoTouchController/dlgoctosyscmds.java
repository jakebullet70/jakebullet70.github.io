package sadLogic.OctoTouchController;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class dlgoctosyscmds extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.OctoTouchController.dlgoctosyscmds");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.OctoTouchController.dlgoctosyscmds.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _mmodule = "";
public sadLogic.OctoTouchController.b4xmainpage _mmainobj = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.collections.Map _popupmnu = null;
public sadLogic.OctoTouchController.octosyscmds _ooctocmds = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.OctoTouchController.main _main = null;
public sadLogic.OctoTouchController.clrtheme _clrtheme = null;
public sadLogic.OctoTouchController.config _config = null;
public sadLogic.OctoTouchController.filehelpers _filehelpers = null;
public sadLogic.OctoTouchController.fnc _fnc = null;
public sadLogic.OctoTouchController.gblconst _gblconst = null;
public sadLogic.OctoTouchController.guihelpers _guihelpers = null;
public sadLogic.OctoTouchController.logme _logme = null;
public sadLogic.OctoTouchController.objhelpers _objhelpers = null;
public sadLogic.OctoTouchController.oc _oc = null;
public sadLogic.OctoTouchController.powerhelpers _powerhelpers = null;
public sadLogic.OctoTouchController.startatboot _startatboot = null;
public sadLogic.OctoTouchController.starter _starter = null;
public sadLogic.OctoTouchController.strhelpers _strhelpers = null;
public sadLogic.OctoTouchController.b4xcollections _b4xcollections = null;
public sadLogic.OctoTouchController.b4xpages _b4xpages = null;
public sadLogic.OctoTouchController.httputils2service _httputils2service = null;
public sadLogic.OctoTouchController.xuiviewsutils _xuiviewsutils = null;
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _askthem(String _txt,String _btntext,String _prompttxt) throws Exception{
ResumableSub_AskThem rsub = new ResumableSub_AskThem(this,_txt,_btntext,_prompttxt);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_AskThem extends BA.ResumableSub {
public ResumableSub_AskThem(sadLogic.OctoTouchController.dlgoctosyscmds parent,String _txt,String _btntext,String _prompttxt) {
this.parent = parent;
this._txt = _txt;
this._btntext = _btntext;
this._prompttxt = _prompttxt;
}
sadLogic.OctoTouchController.dlgoctosyscmds parent;
String _txt;
String _btntext;
String _prompttxt;
anywheresoftware.b4a.keywords.StringBuilderWrapper _s = null;
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
float _w = 0f;
float _h = 0f;
int _res = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 114;BA.debugLine="Dim s As StringBuilder : 	s.Initialize";
_s = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 114;BA.debugLine="Dim s As StringBuilder : 	s.Initialize";
_s.Initialize();
 //BA.debugLineNum = 115;BA.debugLine="s.Append($\"You are about to ${promptTxt}.\"$)";
_s.Append(("You are about to "+parent.__c.SmartStringFormatter("",(Object)(_prompttxt))+"."));
 //BA.debugLineNum = 116;BA.debugLine="s.Append(\"This action may disrupt any print jobs";
_s.Append("This action may disrupt any print jobs ");
 //BA.debugLineNum = 117;BA.debugLine="s.Append(\"that are currently running. Do you wish";
_s.Append("that are currently running. Do you wish to continue?");
 //BA.debugLineNum = 118;BA.debugLine="txt = s.ToString '--- not using the octoprint pro";
_txt = _s.ToString();
 //BA.debugLineNum = 119;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 120;BA.debugLine="Dim w,h As Float";
_w = 0f;
_h = 0f;
 //BA.debugLineNum = 121;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 122;BA.debugLine="w = 80%x : h = 80%y";
_w = (float) (parent.__c.PerXToCurrent((float) (80),ba));
 //BA.debugLineNum = 122;BA.debugLine="w = 80%x : h = 80%y";
_h = (float) (parent.__c.PerYToCurrent((float) (80),ba));
 //BA.debugLineNum = 123;BA.debugLine="txt = strHelpers.WordWrap(txt,42)";
_txt = parent._strhelpers._wordwrap /*String*/ (ba,_txt,(int) (42));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 125;BA.debugLine="w = 96%x : h = 56%y";
_w = (float) (parent.__c.PerXToCurrent((float) (96),ba));
 //BA.debugLineNum = 125;BA.debugLine="w = 96%x : h = 56%y";
_h = (float) (parent.__c.PerYToCurrent((float) (56),ba));
 //BA.debugLineNum = 126;BA.debugLine="txt = strHelpers.WordWrap(txt,32)";
_txt = parent._strhelpers._wordwrap /*String*/ (ba,_txt,(int) (32));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 128;BA.debugLine="mb.Initialize(mMainObj.Root,\"Question\", w, h,Fals";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Question",_w,_h,parent.__c.False);
 //BA.debugLineNum = 129;BA.debugLine="Wait For (mb.Show(txt, gblConst.MB_ICON_WARNING,\"";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_txt,parent._gblconst._mb_icon_warning /*String*/ ,"",_btntext,"CANCEL"));
this.state = 7;
return;
case 7:
//C
this.state = -1;
_res = (Integer) result[0];
;
 //BA.debugLineNum = 130;BA.debugLine="Return res";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_res));return;};
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _res) throws Exception{
}
public int  _buildmenu() throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Private Sub BuildMenu() As Int";
 //BA.debugLineNum = 93;BA.debugLine="popUpMnu.Initialize";
_popupmnu.Initialize();
 //BA.debugLineNum = 95;BA.debugLine="If oOctoCmds.mapRestart.Size 	<> 0 Then popUpMnu.";
if (_ooctocmds._maprestart /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()!=0) { 
_popupmnu.Put((Object)("Restart Octoprint"),(Object)("ro"));};
 //BA.debugLineNum = 96;BA.debugLine="If oOctoCmds.mapReboot.Size 	<> 0 Then popUpMnu.P";
if (_ooctocmds._mapreboot /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()!=0) { 
_popupmnu.Put((Object)("Reboot System"),(Object)("rb"));};
 //BA.debugLineNum = 97;BA.debugLine="If oOctoCmds.mapShutdown.Size 	<> 0 Then popUpMnu";
if (_ooctocmds._mapshutdown /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()!=0) { 
_popupmnu.Put((Object)("Shutdown System"),(Object)("sd"));};
 //BA.debugLineNum = 109;BA.debugLine="Return popUpMnu.Size";
if (true) return _popupmnu.getSize();
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return 0;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private const mModule As String = \"dlgOctoSysCmds";
_mmodule = "dlgOctoSysCmds";
 //BA.debugLineNum = 9;BA.debugLine="Private mMainObj As B4XMainPage";
_mmainobj = new sadLogic.OctoTouchController.b4xmainpage();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private popUpMnu As Map";
_popupmnu = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 14;BA.debugLine="Private oOctoCmds As OctoSysCmds";
_ooctocmds = new sadLogic.OctoTouchController.octosyscmds();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba,sadLogic.OctoTouchController.httpoctorestapi _cn) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(cn As HttpOctoRestAPI) As Ob";
 //BA.debugLineNum = 19;BA.debugLine="mMainObj = B4XPages.MainPage";
_mmainobj = _b4xpages._mainpage /*sadLogic.OctoTouchController.b4xmainpage*/ (ba);
 //BA.debugLineNum = 20;BA.debugLine="oOctoCmds.Initialize(cn)";
_ooctocmds._initialize /*String*/ (ba,_cn);
 //BA.debugLineNum = 21;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return null;
}
public void  _show() throws Exception{
ResumableSub_Show rsub = new ResumableSub_Show(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Show extends BA.ResumableSub {
public ResumableSub_Show(sadLogic.OctoTouchController.dlgoctosyscmds parent) {
this.parent = parent;
}
sadLogic.OctoTouchController.dlgoctosyscmds parent;
sadLogic.OctoTouchController.dlgmsgbox _mb = null;
float _h = 0f;
float _w = 0f;
String _txt = "";
int _result = 0;
sadLogic.OctoTouchController.dlglistbox _o1 = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 28;BA.debugLine="Wait For (oOctoCmds.GetSysCmds) Complete() 'ignor";
parent.__c.WaitFor("complete", ba, this, parent._ooctocmds._getsyscmds /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 17;
return;
case 17:
//C
this.state = 1;
;
 //BA.debugLineNum = 40;BA.debugLine="If BuildMenu = 0 Then";
if (true) break;

case 1:
//if
this.state = 10;
if (parent._buildmenu()==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 41;BA.debugLine="Dim mb As dlgMsgBox";
_mb = new sadLogic.OctoTouchController.dlgmsgbox();
 //BA.debugLineNum = 42;BA.debugLine="Dim h,w As Float";
_h = 0f;
_w = 0f;
 //BA.debugLineNum = 43;BA.debugLine="Dim txt As String = \"System commands are not con";
_txt = "System commands are not configured "+parent.__c.CRLF+"or system is turned off.";
 //BA.debugLineNum = 44;BA.debugLine="h = 200dip";
_h = (float) (parent.__c.DipToCurrent((int) (200)));
 //BA.debugLineNum = 45;BA.debugLine="If guiHelpers.gIsLandScape Then";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 46;BA.debugLine="w = 500dip";
_w = (float) (parent.__c.DipToCurrent((int) (500)));
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 48;BA.debugLine="txt = strHelpers.WordWrap(txt,24) ' V2 TODO - t";
_txt = parent._strhelpers._wordwrap /*String*/ (ba,_txt,(int) (24));
 //BA.debugLineNum = 49;BA.debugLine="w = guiHelpers.gWidth-40dip";
_w = (float) (parent._guihelpers._gwidth /*float*/ -parent.__c.DipToCurrent((int) (40)));
 if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 51;BA.debugLine="mb.Initialize(mMainObj.root,\"Warning\",w,h,False)";
_mb._initialize /*String*/ (ba,parent._mmainobj._root /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ,"Warning",_w,_h,parent.__c.False);
 //BA.debugLineNum = 52;BA.debugLine="Wait For (mb.Show(txt, gblConst.MB_ICON_INFO,\"\",";
parent.__c.WaitFor("complete", ba, this, _mb._show /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_txt,parent._gblconst._mb_icon_info /*String*/ ,"","","OK"));
this.state = 18;
return;
case 18:
//C
this.state = 10;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 53;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 56;BA.debugLine="Dim o1 As dlgListbox";
_o1 = new sadLogic.OctoTouchController.dlglistbox();
 //BA.debugLineNum = 57;BA.debugLine="mMainObj.pObjCurrentDlg2 = o1.Initialize(\"System";
parent._mmainobj._pobjcurrentdlg2 /*Object*/  = _o1._initialize /*Object*/ (ba,(Object)("System Menu"),parent,"SysMenu_Event",parent._mmainobj._pobjcurrentdlg2 /*Object*/ );
 //BA.debugLineNum = 58;BA.debugLine="o1.IsMenu = True";
_o1._ismenu /*boolean*/  = parent.__c.True;
 //BA.debugLineNum = 59;BA.debugLine="If guiHelpers.gIsLandScape Then '- TODO needs ref";
if (true) break;

case 11:
//if
this.state = 16;
if (parent._guihelpers._gislandscape /*boolean*/ ) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 60;BA.debugLine="o1.Show(IIf(guiHelpers.gScreenSizeAprox > 6,320d";
_o1._show /*void*/ ((float)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ >6) ? ((Object)(parent.__c.DipToCurrent((int) (320)))) : ((Object)(parent.__c.DipToCurrent((int) (240))))))),(float) (parent.__c.DipToCurrent((int) (280))),parent._popupmnu);
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 62;BA.debugLine="o1.Show(IIf(guiHelpers.gScreenSizeAprox > 6,436d";
_o1._show /*void*/ ((float)(BA.ObjectToNumber(((parent._guihelpers._gscreensizeaprox /*double*/ >6) ? ((Object)(parent.__c.DipToCurrent((int) (436)))) : ((Object)(parent.__c.DipToCurrent((int) (340))))))),(float) (parent.__c.DipToCurrent((int) (280))),parent._popupmnu);
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _sysmenu_event(String _value,Object _tag) throws Exception{
ResumableSub_SysMenu_Event rsub = new ResumableSub_SysMenu_Event(this,_value,_tag);
rsub.resume(ba, null);
}
public static class ResumableSub_SysMenu_Event extends BA.ResumableSub {
public ResumableSub_SysMenu_Event(sadLogic.OctoTouchController.dlgoctosyscmds parent,String _value,Object _tag) {
this.parent = parent;
this._value = _value;
this._tag = _tag;
}
sadLogic.OctoTouchController.dlgoctosyscmds parent;
String _value;
Object _tag;
int _ret = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 70;BA.debugLine="If value.Length = 0 Then Return";
if (true) break;

case 1:
//if
this.state = 6;
if (_value.length()==0) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 72;BA.debugLine="Select Case value";
if (true) break;

case 7:
//select
this.state = 32;
switch (BA.switchObjectToInt(_value,"ro","sd","rb")) {
case 0: {
this.state = 9;
if (true) break;
}
case 1: {
this.state = 17;
if (true) break;
}
case 2: {
this.state = 25;
if (true) break;
}
}
if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 75;BA.debugLine="Wait For (AskThem(oOctoCmds.mapRestart.Get(\"con";
parent.__c.WaitFor("complete", ba, this, parent._askthem(BA.ObjectToString(parent._ooctocmds._maprestart /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("confirm"))),"RESTART","restart Octoprint"));
this.state = 33;
return;
case 33:
//C
this.state = 10;
_ret = (Integer) result[0];
;
 //BA.debugLineNum = 76;BA.debugLine="If ret <> xui.DialogResponse_Cancel Then oOctoC";
if (true) break;

case 10:
//if
this.state = 15;
if (_ret!=parent._xui.DialogResponse_Cancel) { 
this.state = 12;
;}if (true) break;

case 12:
//C
this.state = 15;
parent._ooctocmds._restart /*String*/ ();
if (true) break;

case 15:
//C
this.state = 32;
;
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 79;BA.debugLine="Wait For (AskThem(oOctoCmds.mapShutdown.Get(\"co";
parent.__c.WaitFor("complete", ba, this, parent._askthem(BA.ObjectToString(parent._ooctocmds._mapshutdown /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("confirm"))),"SHUTDOWN","shutdown the computer"));
this.state = 34;
return;
case 34:
//C
this.state = 18;
_ret = (Integer) result[0];
;
 //BA.debugLineNum = 80;BA.debugLine="If ret <> xui.DialogResponse_Cancel Then oOctoC";
if (true) break;

case 18:
//if
this.state = 23;
if (_ret!=parent._xui.DialogResponse_Cancel) { 
this.state = 20;
;}if (true) break;

case 20:
//C
this.state = 23;
parent._ooctocmds._shutdown /*String*/ ();
if (true) break;

case 23:
//C
this.state = 32;
;
 if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 83;BA.debugLine="Wait For (AskThem(oOctoCmds.mapReboot.Get(\"conf";
parent.__c.WaitFor("complete", ba, this, parent._askthem(BA.ObjectToString(parent._ooctocmds._mapreboot /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("confirm"))),"REBOOT","reboot the computer"));
this.state = 35;
return;
case 35:
//C
this.state = 26;
_ret = (Integer) result[0];
;
 //BA.debugLineNum = 84;BA.debugLine="If ret <> xui.DialogResponse_Cancel Then oOctoC";
if (true) break;

case 26:
//if
this.state = 31;
if (_ret!=parent._xui.DialogResponse_Cancel) { 
this.state = 28;
;}if (true) break;

case 28:
//C
this.state = 31;
parent._ooctocmds._reboot /*String*/ ();
if (true) break;

case 31:
//C
this.state = 32;
;
 if (true) break;

case 32:
//C
this.state = -1;
;
 //BA.debugLineNum = 87;BA.debugLine="mMainObj.pObjCurrentDlg2 = Null";
parent._mmainobj._pobjcurrentdlg2 /*Object*/  = parent.__c.Null;
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
