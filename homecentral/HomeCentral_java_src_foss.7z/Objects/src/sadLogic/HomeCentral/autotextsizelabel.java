package sadLogic.HomeCentral;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class autotextsizelabel extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "sadLogic.HomeCentral.autotextsizelabel");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", sadLogic.HomeCentral.autotextsizelabel.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mlbl = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mautopnl = null;
public int _maxsize = 0;
public int _minsize = 0;
public anywheresoftware.b4a.objects.Accessibility _ac = null;
public float _scaler = 0f;
public Object _tag = null;
public b4a.example.dateutils _dateutils = null;
public sadLogic.HomeCentral.main _main = null;
public sadLogic.HomeCentral.clrtheme _clrtheme = null;
public sadLogic.HomeCentral.config _config = null;
public sadLogic.HomeCentral.dthelpers _dthelpers = null;
public sadLogic.HomeCentral.filehelpers _filehelpers = null;
public sadLogic.HomeCentral.fnct _fnct = null;
public sadLogic.HomeCentral.gblconst _gblconst = null;
public sadLogic.HomeCentral.guihelpers _guihelpers = null;
public sadLogic.HomeCentral.kt _kt = null;
public sadLogic.HomeCentral.logit _logit = null;
public sadLogic.HomeCentral.menus _menus = null;
public sadLogic.HomeCentral.objhelpers _objhelpers = null;
public sadLogic.HomeCentral.startatboot _startatboot = null;
public sadLogic.HomeCentral.starter _starter = null;
public sadLogic.HomeCentral.strhelpers _strhelpers = null;
public sadLogic.HomeCentral.vol_timers _vol_timers = null;
public sadLogic.HomeCentral.b4xpages _b4xpages = null;
public sadLogic.HomeCentral.b4xcollections _b4xcollections = null;
public sadLogic.HomeCentral.httputils2service _httputils2service = null;
public sadLogic.HomeCentral.xuiviewsutils _xuiviewsutils = null;
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 69;BA.debugLine="mBase.Width = Width";
_mbase.setWidth((int) (_width));
 //BA.debugLineNum = 70;BA.debugLine="mBase.Height = Height";
_mbase.setHeight((int) (_height));
 //BA.debugLineNum = 71;BA.debugLine="mlbl.Width = Width";
_mlbl.setWidth((int) (_width));
 //BA.debugLineNum = 72;BA.debugLine="mlbl.Height = Height";
_mlbl.setHeight((int) (_height));
 //BA.debugLineNum = 73;BA.debugLine="mautopnl.Width = Width";
_mautopnl.setWidth((int) (_width));
 //BA.debugLineNum = 74;BA.debugLine="mautopnl.Height = Height";
_mautopnl.setHeight((int) (_height));
 //BA.debugLineNum = 76;BA.debugLine="setText(mlbl.Text)";
_settext((Object)(_mlbl.getText()));
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public boolean  _checksize(float _size,boolean _multiplelines) throws Exception{
anywheresoftware.b4a.objects.StringUtils _su = null;
anywheresoftware.b4a.objects.StringUtils _stuti = null;
 //BA.debugLineNum = 125;BA.debugLine="Private Sub CheckSize(size As Float, multipleLines";
 //BA.debugLineNum = 126;BA.debugLine="mlbl.TextSize = size";
_mlbl.setTextSize(_size);
 //BA.debugLineNum = 127;BA.debugLine="If multipleLines Then";
if (_multiplelines) { 
 //BA.debugLineNum = 129;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 130;BA.debugLine="Return su.MeasureMultilineTextHeight(mlbl,mlbl.T";
if (true) return _su.MeasureMultilineTextHeight((android.widget.TextView)(_mlbl.getObject()),BA.ObjectToCharSequence(_mlbl.getText()))>_mlbl.getHeight();
 }else {
 //BA.debugLineNum = 145;BA.debugLine="Dim stuti As StringUtils";
_stuti = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 146;BA.debugLine="Return MeasureTextWidth(mlbl.Text,mlbl.Font) > m";
if (true) return _measuretextwidth(_mlbl.getText(),_mlbl.getFont())>_mlbl.getWidth() || _stuti.MeasureMultilineTextHeight((android.widget.TextView)(_mlbl.getObject()),BA.ObjectToCharSequence(_mlbl.getText()))>_mlbl.getHeight();
 };
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return false;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 26;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 27;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 28;BA.debugLine="Private mBase As B4XView 'ignore";
_mbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private mlbl As B4XView";
_mlbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 31;BA.debugLine="Private mautopnl As B4XView";
_mautopnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private maxSize As Int = 28";
_maxsize = (int) (28);
 //BA.debugLineNum = 33;BA.debugLine="Private minSize As Int = 5";
_minsize = (int) (5);
 //BA.debugLineNum = 34;BA.debugLine="Private ac As Accessibility";
_ac = new anywheresoftware.b4a.objects.Accessibility();
 //BA.debugLineNum = 35;BA.debugLine="Private scaler As Float";
_scaler = 0f;
 //BA.debugLineNum = 36;BA.debugLine="Public Tag As Object";
_tag = new Object();
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4a.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _parent = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 47;BA.debugLine="mBase = Base";
_mbase = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 48;BA.debugLine="mlbl = Lbl";
_mlbl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_lbl.getObject()));
 //BA.debugLineNum = 49;BA.debugLine="mBase.Tag = Me";
_mbase.setTag(this);
 //BA.debugLineNum = 50;BA.debugLine="Tag = mBase.Tag";
_tag = _mbase.getTag();
 //BA.debugLineNum = 52;BA.debugLine="mautopnl = xui.CreatePanel(\"mautopnl\")";
_mautopnl = _xui.CreatePanel(ba,"mautopnl");
 //BA.debugLineNum = 54;BA.debugLine="Dim parent As B4XView = mBase.Parent";
_parent = new anywheresoftware.b4a.objects.B4XViewWrapper();
_parent = _mbase.getParent();
 //BA.debugLineNum = 55;BA.debugLine="parent.AddView(mlbl, mBase.Left, mBase.Top, mBase";
_parent.AddView((android.view.View)(_mlbl.getObject()),_mbase.getLeft(),_mbase.getTop(),_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 56;BA.debugLine="parent.AddView(mautopnl,0,0,mBase.Width,mBase.Hei";
_parent.AddView((android.view.View)(_mautopnl.getObject()),(int) (0),(int) (0),_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 57;BA.debugLine="mBase.RemoveAllViews";
_mbase.RemoveAllViews();
 //BA.debugLineNum = 60;BA.debugLine="Base_Resize(mBase.width,mBase.height)";
_base_resize(_mbase.getWidth(),_mbase.getHeight());
 //BA.debugLineNum = 63;BA.debugLine="scaler = IIf(Props.Get(\"ignoreUserFontScale\").As(";
_scaler = (float)(BA.ObjectToNumber((((BA.ObjectToBoolean(_props.Get((Object)("ignoreUserFontScale"))))) ? ((Object)(_ac.GetUserFontScale())) : ((Object)(1)))));
 //BA.debugLineNum = 64;BA.debugLine="maxSize = Props.Get(\"maxSize\") / scaler";
_maxsize = (int) ((double)(BA.ObjectToNumber(_props.Get((Object)("maxSize"))))/(double)_scaler);
 //BA.debugLineNum = 65;BA.debugLine="minSize = Props.Get(\"minSize\") / scaler";
_minsize = (int) ((double)(BA.ObjectToNumber(_props.Get((Object)("minSize"))))/(double)_scaler);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getbaselabel() throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Public Sub getBaseLabel As B4XView";
 //BA.debugLineNum = 107;BA.debugLine="Return mlbl";
if (true) return _mlbl;
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return null;
}
public Object  _gettext() throws Exception{
 //BA.debugLineNum = 103;BA.debugLine="Public Sub getText As Object";
 //BA.debugLineNum = 104;BA.debugLine="Return mlbl.Text";
if (true) return (Object)(_mlbl.getText());
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return null;
}
public int  _gettextcolor() throws Exception{
 //BA.debugLineNum = 113;BA.debugLine="Public Sub getTextColor() As Int";
 //BA.debugLineNum = 114;BA.debugLine="Return mlbl.TextColor";
if (true) return _mlbl.getTextColor();
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 40;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 41;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 42;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _mautopnl_click() throws Exception{
 //BA.debugLineNum = 157;BA.debugLine="Private Sub mautopnl_Click";
 //BA.debugLineNum = 158;BA.debugLine="mautopnl_click_handler(Sender)";
_mautopnl_click_handler((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba))));
 //BA.debugLineNum = 159;BA.debugLine="End Sub";
return "";
}
public String  _mautopnl_click_handler(anywheresoftware.b4a.objects.B4XViewWrapper _senderpanel) throws Exception{
 //BA.debugLineNum = 167;BA.debugLine="private Sub mautopnl_click_handler(SenderPanel As";
 //BA.debugLineNum = 168;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Click\"";
if (_xui.SubExists(ba,_mcallback,_meventname+"_Click",(int) (0))) { 
 //BA.debugLineNum = 169;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public String  _mautopnl_longclick() throws Exception{
 //BA.debugLineNum = 161;BA.debugLine="Private Sub mautopnl_LongClick";
 //BA.debugLineNum = 162;BA.debugLine="mautopnl_longclick_handler(Sender)";
_mautopnl_longclick_handler((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(__c.Sender(ba))));
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return "";
}
public String  _mautopnl_longclick_handler(anywheresoftware.b4a.objects.B4XViewWrapper _senderpanel) throws Exception{
 //BA.debugLineNum = 173;BA.debugLine="private Sub mautopnl_longclick_handler(SenderPanel";
 //BA.debugLineNum = 174;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_LongCl";
if (_xui.SubExists(ba,_mcallback,_meventname+"_LongClick",(int) (0))) { 
 //BA.debugLineNum = 175;BA.debugLine="CallSub(mCallBack, mEventName & \"_LongClick\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_LongClick");
 };
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public int  _measuretextheight(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _font1) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmp = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvs = null;
 //BA.debugLineNum = 204;BA.debugLine="Private Sub MeasureTextHeight(Text As String, Font";
 //BA.debugLineNum = 206;BA.debugLine="Private bmp As Bitmap";
_bmp = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 207;BA.debugLine="bmp.InitializeMutable(1, 1)'ignore";
_bmp.InitializeMutable((int) (1),(int) (1));
 //BA.debugLineNum = 208;BA.debugLine="Private cvs As Canvas";
_cvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 209;BA.debugLine="cvs.Initialize2(bmp)";
_cvs.Initialize2((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 210;BA.debugLine="Return cvs.MeasureStringHeight(Text, Font1.ToNati";
if (true) return (int) (_cvs.MeasureStringHeight(_text,(android.graphics.Typeface)(_font1.ToNativeFont().getObject()),_font1.getSize()));
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return 0;
}
public int  _measuretextwidth(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _font1) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmp = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvs = null;
 //BA.debugLineNum = 183;BA.debugLine="Private Sub MeasureTextWidth(Text As String, Font1";
 //BA.debugLineNum = 185;BA.debugLine="Private bmp As Bitmap";
_bmp = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 186;BA.debugLine="bmp.InitializeMutable(1, 1)'ignore";
_bmp.InitializeMutable((int) (1),(int) (1));
 //BA.debugLineNum = 187;BA.debugLine="Private cvs As Canvas";
_cvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 188;BA.debugLine="cvs.Initialize2(bmp)";
_cvs.Initialize2((android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 189;BA.debugLine="Return cvs.MeasureStringWidth(Text, Font1.ToNativ";
if (true) return (int) (_cvs.MeasureStringWidth(_text,(android.graphics.Typeface)(_font1.ToNativeFont().getObject()),_font1.getSize()));
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return 0;
}
public String  _refreshview() throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Public Sub RefreshView";
 //BA.debugLineNum = 121;BA.debugLine="setText(mlbl.Text)";
_settext((Object)(_mlbl.getText()));
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public void  _settext(Object _value) throws Exception{
ResumableSub_setText rsub = new ResumableSub_setText(this,_value);
rsub.resume(ba, null);
}
public static class ResumableSub_setText extends BA.ResumableSub {
public ResumableSub_setText(sadLogic.HomeCentral.autotextsizelabel parent,Object _value) {
this.parent = parent;
this._value = _value;
}
sadLogic.HomeCentral.autotextsizelabel parent;
Object _value;
boolean _multiplelines = false;
float _size = 0f;
double step4;
double limit4;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 81;BA.debugLine="mlbl.Text = value";
parent._mlbl.setText(BA.ObjectToCharSequence(_value));
 //BA.debugLineNum = 82;BA.debugLine="Dim multipleLines As Boolean = mlbl.Text.Contains";
_multiplelines = parent._mlbl.getText().contains(parent.__c.CRLF);
 //BA.debugLineNum = 83;BA.debugLine="Dim size As Float";
_size = 0f;
 //BA.debugLineNum = 84;BA.debugLine="For size = minSize To maxSize";
if (true) break;

case 1:
//for
this.state = 10;
step4 = 1;
limit4 = (float) (parent._maxsize);
_size = (float) (parent._minsize) ;
this.state = 17;
if (true) break;

case 17:
//C
this.state = 10;
if ((step4 > 0 && _size <= limit4) || (step4 < 0 && _size >= limit4)) this.state = 3;
if (true) break;

case 18:
//C
this.state = 17;
_size = ((float)(0 + _size + step4)) ;
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 85;BA.debugLine="If CheckSize(size, multipleLines) Then Exit";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._checksize(_size,_multiplelines)) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
this.state = 10;
if (true) break;
if (true) break;

case 9:
//C
this.state = 18;
;
 if (true) break;
if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 87;BA.debugLine="size = size - 0.5";
_size = (float) (_size-0.5);
 //BA.debugLineNum = 88;BA.debugLine="If CheckSize(size, multipleLines) Then size = siz";
if (true) break;

case 11:
//if
this.state = 16;
if (parent._checksize(_size,_multiplelines)) { 
this.state = 13;
;}if (true) break;

case 13:
//C
this.state = 16;
_size = (float) (_size-0.5);
if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 89;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 19;
return;
case 19:
//C
this.state = -1;
;
 //BA.debugLineNum = 90;BA.debugLine="mlbl.TextSize = size";
parent._mlbl.setTextSize(_size);
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _settextcolor(int _clr) throws Exception{
 //BA.debugLineNum = 110;BA.debugLine="Public Sub setTextColor(clr As Int)";
 //BA.debugLineNum = 111;BA.debugLine="mlbl.TextColor = clr";
_mlbl.setTextColor(_clr);
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
